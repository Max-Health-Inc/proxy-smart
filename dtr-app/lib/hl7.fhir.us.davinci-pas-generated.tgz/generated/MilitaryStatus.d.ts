import { Extension } from "fhir/r4";
export interface MilitaryStatus extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-militaryStatus";
}
export declare function validateMilitaryStatus(resource: MilitaryStatus): Promise<{
    errors: string[];
    warnings: string[];
}>;
