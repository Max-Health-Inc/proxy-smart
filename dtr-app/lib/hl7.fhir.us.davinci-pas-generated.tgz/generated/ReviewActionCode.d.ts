import { Extension } from "fhir/r4";
export interface ReviewActionCode extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-reviewActionCode";
}
export declare function validateReviewActionCode(resource: ReviewActionCode): Promise<{
    errors: string[];
    warnings: string[];
}>;
