import { ReviewActionCode } from "./ReviewActionCode";
import { Extension } from "fhir/r4";
export interface ReviewAction extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-reviewAction";
    extension?: (Extension | ReviewActionCode)[];
}
export declare function validateReviewAction(resource: ReviewAction): Promise<{
    errors: string[];
    warnings: string[];
}>;
