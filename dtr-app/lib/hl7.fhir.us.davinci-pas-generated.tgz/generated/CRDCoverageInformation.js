import fhirpath from "fhirpath";
import fhirpath_r4_model from "fhirpath/fhir-context/r4/index.js";
export async function validateCRDCoverageInformation(resource) {
    const errors = [];
    const warnings = [];
    const result0 = await Promise.resolve(fhirpath.evaluate(resource, "Extension.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result0.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result1 = await Promise.resolve(fhirpath.evaluate(resource, "Extension.all(extension.where(url='questionnaire').exists() implies extension.where(url = 'doc-needed').exists())", { resource }, fhirpath_r4_model));
    if (!result1.every(Boolean)) {
        errors.push("Constraint violation: Questionnaire is only allowed when doc-needed exists");
    }
    const result2 = await Promise.resolve(fhirpath.evaluate(resource, "Extension.all(extension.where(url = 'covered' and value = 'not-covered').exists() implies extension.where(url = 'pa-needed').exists().not())", { resource }, fhirpath_r4_model));
    if (!result2.every(Boolean)) {
        errors.push("Constraint violation: If covered is set to 'not-covered', then 'pa-needed' must not exist.");
    }
    const result3 = await Promise.resolve(fhirpath.evaluate(resource, "Extension.all(extension.where((url = 'covered' or url = 'pa-needed' or url = 'doc-needed') and value = 'conditional').count() >= 1 implies extension.where(url = 'info-needed').exists())", { resource }, fhirpath_r4_model));
    if (!result3.every(Boolean)) {
        errors.push("Constraint violation: 'info-needed' SHALL exist if and only if at least one of 'covered', 'pa-needed', or 'doc-needed' is set to 'conditional'.");
    }
    const result4 = await Promise.resolve(fhirpath.evaluate(resource, "Extension.all(extension.where(url = 'pa-needed' and value = 'satisfied') and extension.where(url = 'doc-purpose').exists() implies extension.where(url = 'doc-purpose').all(value != 'withpa'))", { resource }, fhirpath_r4_model));
    if (!result4.every(Boolean)) {
        errors.push("Constraint violation: If 'pa-needed' is 'satisfied', then 'Doc-purpose' can't be 'withpa'.");
    }
    const result5 = await Promise.resolve(fhirpath.evaluate(resource, "Extension.all(extension.where(url = 'pa-needed' and value = 'satisfied').exists() = extension.where(url = 'satisfied-pa-id').exists())", { resource }, fhirpath_r4_model));
    if (!result5.every(Boolean)) {
        errors.push("Constraint violation: 'satisfied-pa-id' must exist if and only if 'pa-needed' is set to 'satisfied'.");
    }
    const result6 = await Promise.resolve(fhirpath.evaluate(resource, "Extension.all(extension.where(url = 'info-needed' and value = 'Other').exists() implies extension.where(url = 'reason').exists())", { resource }, fhirpath_r4_model));
    if (!result6.every(Boolean)) {
        errors.push("Constraint violation: If 'info-needed' is Other, then reason must be specified");
    }
    const result7 = await Promise.resolve(fhirpath.evaluate(resource, "extension.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result7.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result8 = await Promise.resolve(fhirpath.evaluate(resource, "value.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result8.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result9 = await Promise.resolve(fhirpath.evaluate(resource, "Element.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result9.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result10 = await Promise.resolve(fhirpath.evaluate(resource, "extension.count() >= 4", { resource }, fhirpath_r4_model));
    if (!result10.every(Boolean)) {
        errors.push("Constraint violation: extension must contain at least 4 elements");
    }
    const result11 = await Promise.resolve(fhirpath.evaluate(resource, "url.exists()", { resource }, fhirpath_r4_model));
    if (!result11.every(Boolean)) {
        errors.push("Constraint violation: url must be present");
    }
    const result12 = await Promise.resolve(fhirpath.evaluate(resource, "extension.count() >= 1", { resource }, fhirpath_r4_model));
    if (!result12.every(Boolean)) {
        errors.push("Constraint violation: extension must contain at least one element");
    }
    const result13 = await Promise.resolve(fhirpath.evaluate(resource, "extension.count() <= 1", { resource }, fhirpath_r4_model));
    if (!result13.every(Boolean)) {
        errors.push("Constraint violation: extension must contain at most one element");
    }
    // Fixed value constraint for url
    if (resource.url !== undefined && resource.url !== "http://hl7.org/fhir/us/davinci-crd/StructureDefinition/ext-coverage-information") {
        errors.push("url must have the fixed value 'http://hl7.org/fhir/us/davinci-crd/StructureDefinition/ext-coverage-information'");
    }
    // Slice validation for extension:coverage skipped: no pattern/value discriminator found
    // Discriminator types 'type', 'profile', 'exists', 'position' are not yet supported
    // Slice validation for extension:covered skipped: no pattern/value discriminator found
    // Discriminator types 'type', 'profile', 'exists', 'position' are not yet supported
    // Slice validation for extension:date skipped: no pattern/value discriminator found
    // Discriminator types 'type', 'profile', 'exists', 'position' are not yet supported
    // Slice validation for extension:coverage-assertion-id skipped: no pattern/value discriminator found
    // Discriminator types 'type', 'profile', 'exists', 'position' are not yet supported
    // Slice validation for extension.extension:code skipped: no pattern/value discriminator found
    // Discriminator types 'type', 'profile', 'exists', 'position' are not yet supported
    // Slice validation for extension.extension:value skipped: no pattern/value discriminator found
    // Discriminator types 'type', 'profile', 'exists', 'position' are not yet supported
    return { errors, warnings };
}
