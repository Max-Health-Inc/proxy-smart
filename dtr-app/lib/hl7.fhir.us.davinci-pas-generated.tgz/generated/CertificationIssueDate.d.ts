import { Extension } from "fhir/r4";
export interface CertificationIssueDate extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemCertificationIssueDate";
}
export declare function validateCertificationIssueDate(resource: CertificationIssueDate): Promise<{
    errors: string[];
    warnings: string[];
}>;
