import { Address, Location } from "fhir/r4";
export interface PASLocation extends Location {
    /** Must Support */
    name: string;
    /** Must Support */
    address: Address;
}
export declare function validatePASLocation(resource: PASLocation): Promise<{
    errors: string[];
    warnings: string[];
}>;
