import { Bundle, BundleEntry, FhirResource } from "fhir/r4";
export interface PASResponseBundleEntry extends BundleEntry {
    /** Must Support */
    resource: FhirResource;
}
export interface PASResponseBundle extends Bundle {
    type: "collection";
    /** Must Support */
    entry: PASResponseBundleEntry[];
}
export declare function validatePASResponseBundle(resource: PASResponseBundle): Promise<{
    errors: string[];
    warnings: string[];
}>;
