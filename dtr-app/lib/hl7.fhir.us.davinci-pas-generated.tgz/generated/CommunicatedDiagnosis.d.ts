import { Extension } from "fhir/r4";
export interface CommunicatedDiagnosis extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-communicatedDiagnosis";
}
export declare function validateCommunicatedDiagnosis(resource: CommunicatedDiagnosis): Promise<{
    errors: string[];
    warnings: string[];
}>;
