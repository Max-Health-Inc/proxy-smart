import { PASTask } from "./PASTask.js";
export declare class PASTaskClass {
    private resource;
    /** Pattern constraints for profile fields (used by random() generator) */
    protected static readonly _fieldPatterns: {
        intent: string;
        reasonCode: {
            coding: {
                system: string;
                code: string;
            }[];
        };
        type: {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "AttachmentsNeeded.type": string;
        "QuestionnairesNeeded.type": string;
        "PayerURL.type": string;
        _refReq_requester: {
            identifier: boolean;
        };
        _refReq_owner: {
            identifier: boolean;
        };
        _refReq_input: {
            type: boolean;
            valueBase64Binary: boolean;
            valueUrl: boolean;
            extension: {
                profile: string;
            };
            valueCodeableConcept: boolean;
            "valueProfile-identifier": boolean;
        };
        _refReq_output: {
            type: boolean;
            valueBase64Binary: boolean;
        };
    };
    /** Fields that are forbidden (max=0) in this profile - must not be generated */
    protected static readonly _forbiddenFields: string[];
    /** ValueSet bindings for coded fields - maps field name to ValueSet URL */
    static readonly valueSetBindings: Record<string, string>;
    /** Code resolver for ValueSet bindings - returns a random valid code from a ValueSet by URL */
    protected static readonly _codeResolver: ((url: string) => {
        code: string;
        system: string;
        display?: string;
    } | undefined) | undefined;
    constructor(resource: PASTask);
    /** Validate current resource instance. */
    validate(): Promise<{
        errors: string[];
        warnings: string[];
    }>;
    getResource(): PASTask;
    setResource(resource: PASTask): void;
    /**
     * Returns a plain JSON clone of the underlying resource ONLY if the last validation succeeded with zero errors.
     * Call validate() first; otherwise this method throws to prevent accidental use of invalid / unchecked data.
     */
    toJSON(): Promise<PASTask>;
    /**
     * Create an empty instance for parity testing: for true FHIR resources, includes only resourceType; for datatypes, returns an empty object.
     * Note: meta.profile (when applicable) will be ensured by the constructor when wrapping this resource.
     */
    static empty(overrides?: Partial<PASTask>): PASTask;
    /**
     * Create a minimal randomized instance of PASTask.
     * Populates id, resourceType (if applicable) and primitive required (min>0) top-level fields with placeholders.
     */
    static random(overrides?: Partial<PASTask>, opts?: {
        seed?: number;
    }): PASTask;
    /** Convenience: returns a class instance wrapping a randomized resource. */
    static randomClass(overrides?: Partial<PASTask>, opts?: {
        seed?: number;
    }): PASTaskClass;
}
