import { Extension } from "fhir/r4";
export interface ItemPreAuthIssueDate extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemPreAuthIssueDate";
}
export declare function validateItemPreAuthIssueDate(resource: ItemPreAuthIssueDate): Promise<{
    errors: string[];
    warnings: string[];
}>;
