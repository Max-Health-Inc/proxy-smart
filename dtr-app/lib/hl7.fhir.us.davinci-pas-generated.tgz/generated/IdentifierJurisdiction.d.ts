import { Extension } from "fhir/r4";
export interface IdentifierJurisdiction extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-identifierJurisdiction";
}
export declare function validateIdentifierJurisdiction(resource: IdentifierJurisdiction): Promise<{
    errors: string[];
    warnings: string[];
}>;
