import fhirpath from "fhirpath";
import fhirpath_r4_model from "fhirpath/fhir-context/r4/index.js";
export async function validatePASCoverage(resource) {
    const errors = [];
    const warnings = [];
    const result0 = await Promise.resolve(fhirpath.evaluate(resource, "Coverage.all(contained.contained.empty())", { resource }, fhirpath_r4_model));
    if (!result0.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL NOT contain nested Resources");
    }
    const result1 = await Promise.resolve(fhirpath.evaluate(resource, "Coverage.all(contained.meta.versionId.empty() and contained.meta.lastUpdated.empty())", { resource }, fhirpath_r4_model));
    if (!result1.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a meta.versionId or a meta.lastUpdated");
    }
    const result2 = await Promise.resolve(fhirpath.evaluate(resource, "Coverage.all(contained.meta.security.empty())", { resource }, fhirpath_r4_model));
    if (!result2.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a security label");
    }
    const result3 = await Promise.resolve(fhirpath.evaluate(resource, "Coverage.all(text.`div`.exists())", { resource }, fhirpath_r4_model));
    if (!result3.every(Boolean)) {
        warnings.push("Constraint violation: A resource should have narrative for robust management");
    }
    const result4 = await Promise.resolve(fhirpath.evaluate(resource, "meta.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result4.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result5 = await Promise.resolve(fhirpath.evaluate(resource, "implicitRules.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result5.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result6 = await Promise.resolve(fhirpath.evaluate(resource, "language.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result6.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result7 = await Promise.resolve(fhirpath.evaluate(resource, "text.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result7.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result8 = await Promise.resolve(fhirpath.evaluate(resource, "extension.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result8.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result9 = await Promise.resolve(fhirpath.evaluate(resource, "modifierExtension.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result9.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result10 = await Promise.resolve(fhirpath.evaluate(resource, "identifier.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result10.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result11 = await Promise.resolve(fhirpath.evaluate(resource, "status.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result11.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result12 = await Promise.resolve(fhirpath.evaluate(resource, "type.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result12.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result13 = await Promise.resolve(fhirpath.evaluate(resource, "policyHolder.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result13.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result14 = await Promise.resolve(fhirpath.evaluate(resource, "subscriber.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result14.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result15 = await Promise.resolve(fhirpath.evaluate(resource, "subscriberId.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result15.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result16 = await Promise.resolve(fhirpath.evaluate(resource, "beneficiary.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result16.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result17 = await Promise.resolve(fhirpath.evaluate(resource, "dependent.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result17.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result18 = await Promise.resolve(fhirpath.evaluate(resource, "relationship.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result18.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result19 = await Promise.resolve(fhirpath.evaluate(resource, "period.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result19.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result20 = await Promise.resolve(fhirpath.evaluate(resource, "payor.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result20.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result21 = await Promise.resolve(fhirpath.evaluate(resource, "class.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result21.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result22 = await Promise.resolve(fhirpath.evaluate(resource, "order.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result22.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result23 = await Promise.resolve(fhirpath.evaluate(resource, "network.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result23.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result24 = await Promise.resolve(fhirpath.evaluate(resource, "costToBeneficiary.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result24.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result25 = await Promise.resolve(fhirpath.evaluate(resource, "subrogation.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result25.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result26 = await Promise.resolve(fhirpath.evaluate(resource, "contract.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result26.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result27 = await Promise.resolve(fhirpath.evaluate(resource, "DomainResource.all(contained.contained.empty())", { resource }, fhirpath_r4_model));
    if (!result27.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL NOT contain nested Resources");
    }
    const result28 = await Promise.resolve(fhirpath.evaluate(resource, "DomainResource.all(contained.meta.versionId.empty() and contained.meta.lastUpdated.empty())", { resource }, fhirpath_r4_model));
    if (!result28.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a meta.versionId or a meta.lastUpdated");
    }
    const result29 = await Promise.resolve(fhirpath.evaluate(resource, "DomainResource.all(contained.meta.security.empty())", { resource }, fhirpath_r4_model));
    if (!result29.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a security label");
    }
    const result30 = await Promise.resolve(fhirpath.evaluate(resource, "DomainResource.all(text.`div`.exists())", { resource }, fhirpath_r4_model));
    if (!result30.every(Boolean)) {
        warnings.push("Constraint violation: A resource should have narrative for robust management");
    }
    const result31 = await Promise.resolve(fhirpath.evaluate(resource, "status.exists()", { resource }, fhirpath_r4_model));
    if (!result31.every(Boolean)) {
        errors.push("Constraint violation: status must be present");
    }
    const result32 = await Promise.resolve(fhirpath.evaluate(resource, "beneficiary.exists()", { resource }, fhirpath_r4_model));
    if (!result32.every(Boolean)) {
        errors.push("Constraint violation: beneficiary must be present");
    }
    const result33 = await Promise.resolve(fhirpath.evaluate(resource, "payor.count() >= 1", { resource }, fhirpath_r4_model));
    if (!result33.every(Boolean)) {
        errors.push("Constraint violation: payor must contain at least one element");
    }
    // Fixed value constraint for status
    if (resource.status !== undefined && resource.status !== "active") {
        errors.push("status must have the fixed value 'active'");
    }
    return { errors, warnings };
}
