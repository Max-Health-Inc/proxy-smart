import { Extension } from "fhir/r4";
export interface ItemPreAuthPeriod extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemPreAuthPeriod";
}
export declare function validateItemPreAuthPeriod(resource: ItemPreAuthPeriod): Promise<{
    errors: string[];
    warnings: string[];
}>;
