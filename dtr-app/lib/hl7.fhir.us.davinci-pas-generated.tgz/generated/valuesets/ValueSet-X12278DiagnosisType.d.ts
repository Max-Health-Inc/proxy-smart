/**
 * ValueSet: X12278DiagnosisType
 * URL: http://hl7.org/fhir/us/davinci-pas/ValueSet/X12278DiagnosisType
 * Size: 3 concepts
 */
export declare const X12278DiagnosisTypeConcepts: readonly [{
    readonly code: "admitting";
    readonly system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes";
}, {
    readonly code: "principal";
    readonly system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes";
}, {
    readonly code: "patientreasonforvisit";
    readonly system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes";
}];
/** Union type of all valid codes in this ValueSet */
export type X12278DiagnosisTypeCode = "admitting" | "principal" | "patientreasonforvisit";
/** Type representing a concept from this ValueSet */
export type X12278DiagnosisTypeConcept = typeof X12278DiagnosisTypeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidX12278DiagnosisTypeCode(code: string): code is X12278DiagnosisTypeCode;
/**
 * Get concept details by code
 */
export declare function getX12278DiagnosisTypeConcept(code: string): X12278DiagnosisTypeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const X12278DiagnosisTypeCodes: ("admitting" | "principal" | "patientreasonforvisit")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomX12278DiagnosisTypeCode(): X12278DiagnosisTypeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomX12278DiagnosisTypeConcept(): X12278DiagnosisTypeConcept;
