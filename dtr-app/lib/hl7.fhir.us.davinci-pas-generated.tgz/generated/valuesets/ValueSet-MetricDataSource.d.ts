/**
 * ValueSet: MetricDataSource
 * URL: http://hl7.org/fhir/us/davinci-pas/ValueSet/MetricDataSource
 * Size: 3 concepts
 */
export declare const MetricDataSourceConcepts: readonly [{
    readonly code: "payer-src";
    readonly system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes";
}, {
    readonly code: "provider-src";
    readonly system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes";
}, {
    readonly code: "intermediary-src";
    readonly system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes";
}];
/** Union type of all valid codes in this ValueSet */
export type MetricDataSourceCode = "payer-src" | "provider-src" | "intermediary-src";
/** Type representing a concept from this ValueSet */
export type MetricDataSourceConcept = typeof MetricDataSourceConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidMetricDataSourceCode(code: string): code is MetricDataSourceCode;
/**
 * Get concept details by code
 */
export declare function getMetricDataSourceConcept(code: string): MetricDataSourceConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const MetricDataSourceCodes: ("provider-src" | "payer-src" | "intermediary-src")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomMetricDataSourceCode(): MetricDataSourceCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomMetricDataSourceConcept(): MetricDataSourceConcept;
