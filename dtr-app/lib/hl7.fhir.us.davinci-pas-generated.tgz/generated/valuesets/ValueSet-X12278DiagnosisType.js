/**
 * ValueSet: X12278DiagnosisType
 * URL: http://hl7.org/fhir/us/davinci-pas/ValueSet/X12278DiagnosisType
 * Size: 3 concepts
 */
export const X12278DiagnosisTypeConcepts = [
    { code: "admitting", system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes" },
    { code: "principal", system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes" },
    { code: "patientreasonforvisit", system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidX12278DiagnosisTypeCode(code) {
    return X12278DiagnosisTypeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getX12278DiagnosisTypeConcept(code) {
    return X12278DiagnosisTypeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const X12278DiagnosisTypeCodes = X12278DiagnosisTypeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomX12278DiagnosisTypeCode() {
    return X12278DiagnosisTypeCodes[Math.floor(Math.random() * X12278DiagnosisTypeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomX12278DiagnosisTypeConcept() {
    return X12278DiagnosisTypeConcepts[Math.floor(Math.random() * X12278DiagnosisTypeConcepts.length)];
}
