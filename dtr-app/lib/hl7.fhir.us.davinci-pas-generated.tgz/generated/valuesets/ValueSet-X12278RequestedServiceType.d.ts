/**
 * ValueSet: X12278RequestedServiceType
 * URL: http://hl7.org/fhir/us/davinci-pas/ValueSet/X12278RequestedServiceType
 * Size: 1 concepts
 */
export declare const X12278RequestedServiceTypeConcepts: readonly [{
    readonly code: "not-applicable";
    readonly system: "http://terminology.hl7.org/CodeSystem/data-absent-reason";
}];
/** Union type of all valid codes in this ValueSet */
export type X12278RequestedServiceTypeCode = "not-applicable";
/** Type representing a concept from this ValueSet */
export type X12278RequestedServiceTypeConcept = typeof X12278RequestedServiceTypeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidX12278RequestedServiceTypeCode(code: string): code is X12278RequestedServiceTypeCode;
/**
 * Get concept details by code
 */
export declare function getX12278RequestedServiceTypeConcept(code: string): X12278RequestedServiceTypeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const X12278RequestedServiceTypeCodes: "not-applicable"[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomX12278RequestedServiceTypeCode(): X12278RequestedServiceTypeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomX12278RequestedServiceTypeConcept(): X12278RequestedServiceTypeConcept;
