/**
 * ValueSet: X12278RequestedServiceType
 * URL: http://hl7.org/fhir/us/davinci-pas/ValueSet/X12278RequestedServiceType
 * Size: 1 concepts
 */
export const X12278RequestedServiceTypeConcepts = [
    { code: "not-applicable", system: "http://terminology.hl7.org/CodeSystem/data-absent-reason" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidX12278RequestedServiceTypeCode(code) {
    return X12278RequestedServiceTypeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getX12278RequestedServiceTypeConcept(code) {
    return X12278RequestedServiceTypeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const X12278RequestedServiceTypeCodes = X12278RequestedServiceTypeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomX12278RequestedServiceTypeCode() {
    return X12278RequestedServiceTypeCodes[Math.floor(Math.random() * X12278RequestedServiceTypeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomX12278RequestedServiceTypeConcept() {
    return X12278RequestedServiceTypeConcepts[Math.floor(Math.random() * X12278RequestedServiceTypeConcepts.length)];
}
