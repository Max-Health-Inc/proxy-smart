/**
 * ValueSet Registry
 * Central registry of all loaded ValueSets with explicit codes
 */
import * as MetricDataSource from './ValueSet-MetricDataSource.js';
import * as PASCommunicationRequestMedium from './ValueSet-PASCommunicationRequestMedium.js';
import * as PASInformationChangeMode from './ValueSet-PASInformationChangeMode.js';
import * as PASSupportingInfoType from './ValueSet-PASSupportingInfoType.js';
import * as PASTaskCodes from './ValueSet-PASTaskCodes.js';
import * as X12278DiagnosisType from './ValueSet-X12278DiagnosisType.js';
import * as X12278RequestedServiceType from './ValueSet-X12278RequestedServiceType.js';
export const ValueSetRegistry = {
    MetricDataSource,
    PASCommunicationRequestMedium,
    PASInformationChangeMode,
    PASSupportingInfoType,
    PASTaskCodes,
    X12278DiagnosisType,
    X12278RequestedServiceType,
};
export function getValueSet(name) {
    return ValueSetRegistry[name];
}
/** Map from ValueSet URL to registry name */
export const ValueSetUrlMap = {
    'http://hl7.org/fhir/us/davinci-pas/ValueSet/MetricDataSource': 'MetricDataSource',
    'http://hl7.org/fhir/us/davinci-pas/ValueSet/PASCommunicationRequestMedium': 'PASCommunicationRequestMedium',
    'http://hl7.org/fhir/us/davinci-pas/ValueSet/PASInformationChangeMode': 'PASInformationChangeMode',
    'http://hl7.org/fhir/us/davinci-pas/ValueSet/PASSupportingInfoType': 'PASSupportingInfoType',
    'http://hl7.org/fhir/us/davinci-pas/ValueSet/PASTaskCodes': 'PASTaskCodes',
    'http://hl7.org/fhir/us/davinci-pas/ValueSet/X12278DiagnosisType': 'X12278DiagnosisType',
    'http://hl7.org/fhir/us/davinci-pas/ValueSet/X12278RequestedServiceType': 'X12278RequestedServiceType',
};
function stripVersionFromUrl(url) {
    const pipeIndex = url.indexOf('|');
    return pipeIndex >= 0 ? url.substring(0, pipeIndex) : url;
}
/**
 * Get a random code from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A random code string, or undefined if ValueSet not found
 */
export function getRandomCodeByUrl(url) {
    const cleanUrl = stripVersionFromUrl(url);
    const name = ValueSetUrlMap[cleanUrl];
    if (!name)
        return undefined;
    const vs = ValueSetRegistry[name];
    // Each ValueSet exports random<Name>Code() function
    const randomFn = vs['random' + name + 'Code'];
    return randomFn?.();
}
/**
 * Get a random concept (code, system, display) from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A concept object with code, system, and optional display, or undefined if ValueSet not found
 */
export function getRandomConceptByUrl(url) {
    const cleanUrl = stripVersionFromUrl(url);
    const name = ValueSetUrlMap[cleanUrl];
    if (!name)
        return undefined;
    const vs = ValueSetRegistry[name];
    // Each ValueSet exports random<Name>Concept() function
    const randomFn = vs['random' + name + 'Concept'];
    return randomFn?.();
}
