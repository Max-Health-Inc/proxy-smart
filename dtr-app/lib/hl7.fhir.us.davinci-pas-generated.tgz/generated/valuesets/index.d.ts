/**
 * ValueSet Registry
 * Central registry of all loaded ValueSets with explicit codes
 */
import * as MetricDataSource from './ValueSet-MetricDataSource.js';
import * as PASCommunicationRequestMedium from './ValueSet-PASCommunicationRequestMedium.js';
import * as PASInformationChangeMode from './ValueSet-PASInformationChangeMode.js';
import * as PASSupportingInfoType from './ValueSet-PASSupportingInfoType.js';
import * as PASTaskCodes from './ValueSet-PASTaskCodes.js';
import * as X12278DiagnosisType from './ValueSet-X12278DiagnosisType.js';
import * as X12278RequestedServiceType from './ValueSet-X12278RequestedServiceType.js';
export declare const ValueSetRegistry: {
    readonly MetricDataSource: typeof MetricDataSource;
    readonly PASCommunicationRequestMedium: typeof PASCommunicationRequestMedium;
    readonly PASInformationChangeMode: typeof PASInformationChangeMode;
    readonly PASSupportingInfoType: typeof PASSupportingInfoType;
    readonly PASTaskCodes: typeof PASTaskCodes;
    readonly X12278DiagnosisType: typeof X12278DiagnosisType;
    readonly X12278RequestedServiceType: typeof X12278RequestedServiceType;
};
export type ValueSetName = keyof typeof ValueSetRegistry;
export declare function getValueSet(name: ValueSetName): typeof MetricDataSource | typeof PASCommunicationRequestMedium | typeof PASInformationChangeMode | typeof PASSupportingInfoType | typeof PASTaskCodes | typeof X12278DiagnosisType | typeof X12278RequestedServiceType;
/** Map from ValueSet URL to registry name */
export declare const ValueSetUrlMap: Record<string, ValueSetName>;
/**
 * Get a random code from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A random code string, or undefined if ValueSet not found
 */
export declare function getRandomCodeByUrl(url: string): string | undefined;
/**
 * Get a random concept (code, system, display) from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A concept object with code, system, and optional display, or undefined if ValueSet not found
 */
export declare function getRandomConceptByUrl(url: string): {
    code: string;
    system: string;
    display?: string;
} | undefined;
