import { Extension } from "fhir/r4";
export interface ItemAuthorizedProvider extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemAuthorizedProvider";
}
export declare function validateItemAuthorizedProvider(resource: ItemAuthorizedProvider): Promise<{
    errors: string[];
    warnings: string[];
}>;
