import { Extension } from "fhir/r4";
export interface RequestedService extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-requestedService";
}
export declare function validateRequestedService(resource: RequestedService): Promise<{
    errors: string[];
    warnings: string[];
}>;
