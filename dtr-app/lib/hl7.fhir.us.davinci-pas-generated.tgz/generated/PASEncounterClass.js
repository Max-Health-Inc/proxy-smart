import { validatePASEncounter } from "./PASEncounter.js";
// Only import helpers actually referenced below (dynamic based on required fields)
import { randomId, setRandomSeed, enrichResource, skeletonCodeableConcept, skeletonReference } from "./RandomSupport.js";
function ensureProfile(res, profile) {
    if (!res.meta) {
        res.meta = { profile: [profile] };
        return;
    }
    if (!res.meta.profile) {
        res.meta.profile = [profile];
        return;
    }
    if (!res.meta.profile.includes(profile)) {
        res.meta.profile = [...res.meta.profile, profile];
    }
}
// Internal helper (emitted per class file) to clone without resorting to 'any'.
function safeClone(value) {
    // Use native structuredClone if present; otherwise fallback to JSON round-trip.
    // We intentionally avoid casting through any to satisfy no-explicit-any lint rule.
    const g = globalThis;
    // Narrow globalThis to an object potentially containing structuredClone.
    if (typeof g.structuredClone === 'function') {
        return g.structuredClone(value);
    }
    return JSON.parse(JSON.stringify(value)); // best-effort deep clone
}
export class PASEncounterClass {
    constructor(resource) {
        this.resource = resource;
        ensureProfile(this.resource, 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-encounter');
    }
    /** Validate current resource instance. */
    async validate() {
        return validatePASEncounter(this.resource);
    }
    getResource() {
        return this.resource;
    }
    setResource(resource) {
        this.resource = resource;
        ensureProfile(this.resource, 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-encounter');
    }
    /**
     * Returns a plain JSON clone of the underlying resource ONLY if the last validation succeeded with zero errors.
     * Call validate() first; otherwise this method throws to prevent accidental use of invalid / unchecked data.
     */
    async toJSON() {
        return safeClone(this.resource);
    }
    /**
     * Create an empty instance for parity testing: for true FHIR resources, includes only resourceType; for datatypes, returns an empty object.
     * Note: meta.profile (when applicable) will be ensured by the constructor when wrapping this resource.
     */
    static empty(overrides = {}) {
        // For Resource profiles, include only resourceType. For Extension profiles, include url so the instance is minimally meaningful.
        const base = {
            resourceType: 'Encounter',
        };
        return { ...base, ...overrides };
    }
    /**
     * Create a minimal randomized instance of PASEncounter.
     * Populates id, resourceType (if applicable) and primitive required (min>0) top-level fields with placeholders.
     */
    static random(overrides = {}, opts) {
        if (opts?.seed !== undefined) {
            // Direct call (no dynamic require) to ensure deterministic seeding works under ESM.
            setRandomSeed(opts.seed);
        }
        // Start with a Partial to avoid unsafe casting errors; we'll assert at the end.
        const base = { resourceType: 'Encounter', id: randomId(), status: "planned", class: { system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", code: "IMP", display: "inpatient encounter" }, type: [skeletonCodeableConcept('http://terminology.hl7.org/CodeSystem/v3-ActCode', ['IMP'])], subject: skeletonReference(), };
        // Always include meta.profile with this profile's canonical URL if available & only for resource profiles
        ensureProfile(base, 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-encounter');
        // Enrich the base resource with common fields using centralized enrichment logic
        enrichResource(base, 'Encounter', 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-encounter', PASEncounterClass._fieldPatterns, PASEncounterClass._forbiddenFields, PASEncounterClass.valueSetBindings, PASEncounterClass._codeResolver);
        // Cast through unknown to acknowledge dynamic enrichment
        return { ...base, ...overrides };
    }
    /** Convenience: returns a class instance wrapping a randomized resource. */
    static randomClass(overrides = {}, opts) {
        return new PASEncounterClass(this.random(overrides, opts));
    }
}
/** Pattern constraints for profile fields (used by random() generator) */
PASEncounterClass._fieldPatterns = {
    "nursingHomeResidentialStatus.url": "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-nursingHomeResidentialStatus",
    "status": "planned",
    "_refReq_extension": {
        "url": true
    },
    "_refReq_identifier": {
        "system": true,
        "value": true
    },
    "_refReq_statusHistory": {
        "status": true,
        "period": true
    },
    "_refReq_classHistory": {
        "class": true,
        "period": true
    },
    "_refReq_diagnosis": {
        "condition": true
    },
    "_refReq_location": {
        "location": true
    }
};
/** Fields that are forbidden (max=0) in this profile - must not be generated */
PASEncounterClass._forbiddenFields = [];
/** ValueSet bindings for coded fields - maps field name to ValueSet URL */
PASEncounterClass.valueSetBindings = {
    "language": "http://hl7.org/fhir/ValueSet/languages",
    "extension.value[x]": "https://valueset.x12.org/x217/005010/request/2000E/CL1/1/04/00/1345",
    "identifier.use": "http://hl7.org/fhir/ValueSet/identifier-use|4.0.1",
    "identifier.type": "http://hl7.org/fhir/ValueSet/identifier-type",
    "status": "http://hl7.org/fhir/ValueSet/encounter-status|4.0.1",
    "statusHistory.status": "http://hl7.org/fhir/ValueSet/encounter-status|4.0.1",
    "class": "http://terminology.hl7.org/ValueSet/v3-ActEncounterCode",
    "classHistory.class": "http://terminology.hl7.org/ValueSet/v3-ActEncounterCode",
    "type": "https://valueset.x12.org/x217/005010/request/2000E/CL1/1/01/00/1315",
    "serviceType": "http://hl7.org/fhir/ValueSet/service-type",
    "priority": "http://terminology.hl7.org/ValueSet/v3-ActPriority",
    "participant.type": "http://hl7.org/fhir/ValueSet/encounter-participant-type",
    "reasonCode": "http://hl7.org/fhir/ValueSet/encounter-reason",
    "diagnosis.use": "http://hl7.org/fhir/ValueSet/diagnosis-role",
    "hospitalization.admitSource": "https://valueset.x12.org/x217/005010/request/2000E/CL1/1/02/00/1314",
    "hospitalization.reAdmission": "http://terminology.hl7.org/ValueSet/v2-0092",
    "hospitalization.dietPreference": "http://hl7.org/fhir/ValueSet/encounter-diet",
    "hospitalization.specialCourtesy": "http://hl7.org/fhir/ValueSet/encounter-special-courtesy",
    "hospitalization.specialArrangement": "http://hl7.org/fhir/ValueSet/encounter-special-arrangements",
    "hospitalization.dischargeDisposition": "http://hl7.org/fhir/ValueSet/encounter-discharge-disposition",
    "location.status": "http://hl7.org/fhir/ValueSet/encounter-location-status|4.0.1",
    "location.physicalType": "http://hl7.org/fhir/ValueSet/location-physical-type"
};
/** Code resolver for ValueSet bindings - returns a random valid code from a ValueSet by URL */
PASEncounterClass._codeResolver = (() => {
    // Try to dynamically import the ValueSetRegistry - it may not exist if no ValueSets were generated
    try {
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        const registry = require('./valuesets/index.js');
        if (registry && typeof registry.getRandomConceptByUrl === 'function') {
            return registry.getRandomConceptByUrl;
        }
    }
    catch { /* ValueSetRegistry not available */ }
    return undefined;
})();
