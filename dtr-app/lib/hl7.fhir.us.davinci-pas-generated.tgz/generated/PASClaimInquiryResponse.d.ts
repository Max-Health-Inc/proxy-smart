import { AdministrationReferenceNumber } from "./AdministrationReferenceNumber";
import { AuthorizationNumber } from "./AuthorizationNumber";
import { CommunicatedDiagnosis } from "./CommunicatedDiagnosis";
import { ErrorElement } from "./ErrorElement";
import { ErrorFollowupAction } from "./ErrorFollowupAction";
import { ErrorPath } from "./ErrorPath";
import { ItemAuthorizedDetail } from "./ItemAuthorizedDetail";
import { ItemAuthorizedProvider } from "./ItemAuthorizedProvider";
import { ItemPreAuthIssueDate } from "./ItemPreAuthIssueDate";
import { ItemPreAuthPeriod } from "./ItemPreAuthPeriod";
import { ItemRequestedServiceDate } from "./ItemRequestedServiceDate";
import { ItemTraceNumber } from "./ItemTraceNumber";
import { BackboneElement, ClaimResponse, ClaimResponseError, ClaimResponseItem, CodeableConcept, Coding, Extension } from "fhir/r4";
import { ReviewAction } from "./ReviewAction";
export interface ExtensionErrorPath extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-errorPath';
}
export interface ExtensionErrorElement extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-errorElement';
}
export interface ExtensionErrorFollowupAction extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-errorFollowupAction';
}
export interface ExtensionCommunicatedDiagnosis extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-communicatedDiagnosis';
}
export interface ExtensionItemAuthorizedProvider extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemAuthorizedProvider';
}
export interface ExtensionItemAuthorizedDetail extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemAuthorizedDetail';
}
export interface ExtensionItemRequestedServiceDate extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemRequestedServiceDate';
}
export interface ExtensionAdministrationReferenceNumber extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-administrationReferenceNumber';
}
export interface ExtensionAuthorizationNumber extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-authorizationNumber';
}
export interface ExtensionItemPreAuthPeriod extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemPreAuthPeriod';
}
export interface ExtensionItemPreAuthIssueDate extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemPreAuthIssueDate';
}
export interface ExtensionItemTraceNumber extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemTraceNumber';
}
export interface ExtensionReviewAction extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-reviewAction';
}
export interface PASClaimInquiryResponseItemAdjudicationCategoryCoding extends Coding {
    system: "http://terminology.hl7.org/CodeSystem/adjudication";
    code: "submitted";
}
export interface PASClaimInquiryResponseItemAdjudication extends BackboneElement {
    category: {
        coding: PASClaimInquiryResponseItemAdjudicationCategoryCoding[];
    };
    extension?: (Extension | ReviewAction)[];
}
export interface PASClaimInquiryResponseItem extends ClaimResponseItem {
    /** Must Support */
    adjudication: PASClaimInquiryResponseItemAdjudication[];
    extension?: (Extension | ItemTraceNumber | ItemPreAuthIssueDate | ItemPreAuthPeriod | AuthorizationNumber | AdministrationReferenceNumber | ItemRequestedServiceDate | ItemAuthorizedDetail | ItemAuthorizedProvider | CommunicatedDiagnosis)[];
}
export interface PASClaimInquiryResponseError extends ClaimResponseError {
    /** Must Support */
    code: CodeableConcept;
    extension?: (Extension | ErrorFollowupAction | ErrorElement | ErrorPath)[];
}
export interface PASClaimInquiryResponse extends ClaimResponse {
    status: "active";
    use: "preauthorization";
    /** Must Support */
    item?: PASClaimInquiryResponseItem[];
    /** Must Support */
    error?: PASClaimInquiryResponseError[];
}
export declare function validatePASClaimInquiryResponse(resource: PASClaimInquiryResponse): Promise<{
    errors: string[];
    warnings: string[];
}>;
