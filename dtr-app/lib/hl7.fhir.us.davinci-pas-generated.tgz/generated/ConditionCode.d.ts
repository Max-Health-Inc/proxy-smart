import { Extension } from "fhir/r4";
export interface ConditionCode extends Extension {
    extension: Extension[];
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-conditionCode";
}
export declare function validateConditionCode(resource: ConditionCode): Promise<{
    errors: string[];
    warnings: string[];
}>;
