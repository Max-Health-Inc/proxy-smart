import { Extension, Identifier } from "fhir/r4";
export interface ItemTraceNumber extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemTraceNumber";
    value?: Identifier;
}
export declare function validateItemTraceNumber(resource: ItemTraceNumber): Promise<{
    errors: string[];
    warnings: string[];
}>;
