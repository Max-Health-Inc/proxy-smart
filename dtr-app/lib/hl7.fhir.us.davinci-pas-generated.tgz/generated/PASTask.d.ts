import { PASTaskCodesCode } from "./valuesets/ValueSet-PASTaskCodes";
import { PALineNumber } from "./PALineNumber";
import { CodeableConcept, Coding, Extension, Identifier, Reference, Task, TaskInput } from "fhir/r4";
export interface ExtensionPaLineNumber extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-paLineNumber';
}
export interface PASTaskReasonCodeCoding extends Coding {
    system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes";
    code: "priorAuthorization";
}
export interface PASTaskInput extends TaskInput {
    type: CodeableConcept;
    extension?: (Extension | PALineNumber | PALineNumber)[];
}
export interface PASTask extends Task {
    /** Must Support */
    identifier: Identifier[];
    /** Must Support */
    statusReason?: CodeableConcept;
    intent: "order";
    /** Must Support | @see {@link ./valuesets/ValueSet-PASTaskCodes.ts} for valid codes (2 codes) */
    code: CodeableConcept & {
        coding: Array<{
            code: PASTaskCodesCode;
            system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes";
        }>;
    };
    /** Must Support */
    for: Reference;
    /** Must Support */
    requester: Reference;
    /** Must Support */
    owner: Reference;
    reasonCode: {
        coding: PASTaskReasonCodeCoding[];
    };
    /** Must Support */
    reasonReference: Reference;
    /** Must Support */
    input: PASTaskInput[];
}
export declare function validatePASTask(resource: PASTask): Promise<{
    errors: string[];
    warnings: string[];
}>;
