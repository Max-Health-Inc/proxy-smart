import { validatePASClaim } from "./PASClaim.js";
// Only import helpers actually referenced below (dynamic based on required fields)
import { randomId, setRandomSeed, enrichResource, randomDate, skeletonCodeableConcept, skeletonReference } from "./RandomSupport.js";
// Helper emitted only when meta.profile enforcement is applicable (resource profiles)
// Internal helper (emitted per class file) to clone without resorting to 'any'.
function safeClone(value) {
    // Use native structuredClone if present; otherwise fallback to JSON round-trip.
    // We intentionally avoid casting through any to satisfy no-explicit-any lint rule.
    const g = globalThis;
    // Narrow globalThis to an object potentially containing structuredClone.
    if (typeof g.structuredClone === 'function') {
        return g.structuredClone(value);
    }
    return JSON.parse(JSON.stringify(value)); // best-effort deep clone
}
export class PASClaimClass {
    constructor(resource) {
        this.resource = resource;
    }
    /** Validate current resource instance. */
    async validate() {
        return validatePASClaim(this.resource);
    }
    getResource() {
        return this.resource;
    }
    setResource(resource) {
        this.resource = resource;
    }
    /**
     * Returns a plain JSON clone of the underlying resource ONLY if the last validation succeeded with zero errors.
     * Call validate() first; otherwise this method throws to prevent accidental use of invalid / unchecked data.
     */
    async toJSON() {
        return safeClone(this.resource);
    }
    /**
     * Create an empty instance for parity testing: for true FHIR resources, includes only resourceType; for datatypes, returns an empty object.
     * Note: meta.profile (when applicable) will be ensured by the constructor when wrapping this resource.
     */
    static empty(overrides = {}) {
        // For Resource profiles, include only resourceType. For Extension profiles, include url so the instance is minimally meaningful.
        const base = {};
        return { ...base, ...overrides };
    }
    /**
     * Create a minimal randomized instance of PASClaim.
     * Populates id, resourceType (if applicable) and primitive required (min>0) top-level fields with placeholders.
     */
    static random(overrides = {}, opts) {
        if (opts?.seed !== undefined) {
            // Direct call (no dynamic require) to ensure deterministic seeding works under ESM.
            setRandomSeed(opts.seed);
        }
        // Start with a Partial to avoid unsafe casting errors; we'll assert at the end.
        const base = { id: randomId(), status: "active", type: skeletonCodeableConcept(), use: "preauthorization", patient: skeletonReference(), created: randomDate(), insurer: skeletonReference(), provider: skeletonReference(), priority: skeletonCodeableConcept(), insurance: [({ sequence: "Example sequence", focal: true, coverage: { reference: 'Resource/' + randomId() } })], item: [({ extension: [{ "url": "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-nursingHomeResidentialStatus" }], sequence: "Example sequence", category: { coding: [{ "code": "unknown", "system": "http://terminology.hl7.org/CodeSystem/data-absent-reason" }] }, productOrService: { coding: [{ "code": "not-applicable", "system": "http://terminology.hl7.org/CodeSystem/data-absent-reason" }] }, detail: [{ "sequence": "Example sequence", "productOrService": { "coding": [{ "code": "unknown", "system": "http://terminology.hl7.org/CodeSystem/data-absent-reason" }] }, "subDetail": [{ "sequence": "Example sequence", "productOrService": { "coding": [{ "code": "unknown", "system": "http://terminology.hl7.org/CodeSystem/data-absent-reason" }] } }] }] })], };
        // Always include meta.profile with this profile's canonical URL if available & only for resource profiles
        // (no profileUrl provided or profile targets a datatype – meta.profile not applicable)
        // Enrich the base resource with common fields using centralized enrichment logic
        enrichResource(base, 'Claim', 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-claim', PASClaimClass._fieldPatterns, PASClaimClass._forbiddenFields, PASClaimClass.valueSetBindings, PASClaimClass._codeResolver);
        // Cast through unknown to acknowledge dynamic enrichment
        return { ...base, ...overrides };
    }
    /** Convenience: returns a class instance wrapping a randomized resource. */
    static randomClass(overrides = {}, opts) {
        return new PASClaimClass(this.random(overrides, opts));
    }
}
/** Pattern constraints for profile fields (used by random() generator) */
PASClaimClass._fieldPatterns = {
    "encounter.url": "http://hl7.org/fhir/5.0/StructureDefinition/extension-Claim.encounter",
    "status": "active",
    "use": "preauthorization",
    "OverallClaimMember.careTeamClaimScope.url": "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-careTeamClaimScope",
    "OverallClaimMember.careTeamClaimScope": true,
    "ItemClaimMember.careTeamClaimScope.url": "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-careTeamClaimScope",
    "supportingInfo.category": "dischargeDates",
    "category": {
        "coding": [
            {
                "system": "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes",
                "code": "patientEvent"
            }
        ]
    },
    "AdmissionDates.category": "admissionDates",
    "DischargeDates.category": "dischargeDates",
    "AdditionalInformation.category": "dischargeDates",
    "MessageText.category": "dischargeDates",
    "diagnosis.type": "patientreasonforvisit",
    "insurance.focal": true,
    "item.nursingHomeResidentialStatus.url": "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-nursingHomeResidentialStatus",
    "item.productOrService": "not-applicable",
    "PatientEvent.category": "patientEvent",
    "_refReq_extension": {
        "url": true,
        "valueReference": true
    },
    "_refReq_payee": {
        "type": true
    },
    "_refReq_careTeam": {
        "extension": {
            "profile": "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-careTeamClaimScope"
        },
        "sequence": true,
        "provider": true,
        "extension.url": true
    },
    "_refReq_supportingInfo": {
        "sequence": true,
        "category": true,
        "timingDate": true,
        "valueReference": true,
        "valueString": true
    },
    "_refReq_diagnosis": {
        "sequence": true,
        "diagnosisCodeableConcept": true
    },
    "_refReq_procedure": {
        "sequence": true,
        "procedureCodeableConcept": true
    },
    "_refReq_insurance": {
        "sequence": true,
        "focal": true,
        "coverage": true
    },
    "_refReq_accident": {
        "date": true
    },
    "_refReq_item": {
        "extension.url": true,
        "sequence": true,
        "category": true,
        "productOrService": true,
        "detail.sequence": true,
        "detail.productOrService": true,
        "detail.subDetail.sequence": true,
        "detail.subDetail.productOrService": true
    }
};
/** Fields that are forbidden (max=0) in this profile - must not be generated */
PASClaimClass._forbiddenFields = [];
/** ValueSet bindings for coded fields - maps field name to ValueSet URL */
PASClaimClass.valueSetBindings = {
    "language": "http://hl7.org/fhir/ValueSet/languages",
    "status": "http://hl7.org/fhir/ValueSet/fm-status|4.0.1",
    "type": "http://hl7.org/fhir/ValueSet/claim-type",
    "subType": "http://hl7.org/fhir/ValueSet/claim-subtype",
    "use": "http://hl7.org/fhir/ValueSet/claim-use|4.0.1",
    "priority": "http://hl7.org/fhir/ValueSet/process-priority",
    "fundsReserve": "http://hl7.org/fhir/ValueSet/fundsreserve",
    "related.relationship": "http://hl7.org/fhir/ValueSet/related-claim-relationship",
    "payee.type": "http://hl7.org/fhir/ValueSet/payeetype",
    "careTeam.role": "http://hl7.org/fhir/ValueSet/claim-careteamrole",
    "careTeam.qualification": "http://hl7.org/fhir/ValueSet/provider-qualification",
    "supportingInfo.category": "http://hl7.org/fhir/us/davinci-pas/ValueSet/PASSupportingInfoType",
    "supportingInfo.code": "http://hl7.org/fhir/ValueSet/claim-exception",
    "supportingInfo.reason": "http://hl7.org/fhir/ValueSet/missing-tooth-reason",
    "diagnosis.diagnosis[x]": "http://hl7.org/fhir/us/davinci-pas/ValueSet/X12278DiagnosisCodes",
    "diagnosis.type": "http://hl7.org/fhir/us/davinci-pas/ValueSet/X12278DiagnosisType",
    "diagnosis.onAdmission": "http://hl7.org/fhir/ValueSet/ex-diagnosis-on-admission",
    "diagnosis.packageCode": "http://hl7.org/fhir/ValueSet/ex-diagnosisrelatedgroup",
    "procedure.type": "http://hl7.org/fhir/ValueSet/ex-procedure-type",
    "procedure.procedure[x]": "http://hl7.org/fhir/ValueSet/icd-10-procedures",
    "accident.type": "https://valueset.x12.org/x217/005010/request/2000E/UM/1/05/01/1362",
    "item.extension.value[x]": "https://valueset.x12.org/x217/005010/request/2000F/SV2/1/09/00/1345",
    "item.revenue": "http://hl7.org/fhir/us/davinci-pas/ValueSet/AHANUBCRevenueCodes",
    "item.category": "https://valueset.x12.org/x217/005010/request/2000F/UM/1/03/00/1365",
    "item.productOrService": "http://hl7.org/fhir/us/davinci-pas/ValueSet/X12278RequestedServiceType",
    "item.modifier": "http://hl7.org/fhir/us/davinci-pas/ValueSet/X12278RequestedServiceModifierType",
    "item.programCode": "http://hl7.org/fhir/ValueSet/ex-program-code",
    "item.location[x]": "http://hl7.org/fhir/us/davinci-pas/ValueSet/X12278LocationType",
    "item.bodySite": "http://hl7.org/fhir/ValueSet/tooth",
    "item.subSite": "http://hl7.org/fhir/ValueSet/surface",
    "item.detail.revenue": "http://hl7.org/fhir/ValueSet/ex-revenue-center",
    "item.detail.category": "http://hl7.org/fhir/ValueSet/ex-benefitcategory",
    "item.detail.productOrService": "http://hl7.org/fhir/ValueSet/service-uscls",
    "item.detail.modifier": "http://hl7.org/fhir/ValueSet/claim-modifiers",
    "item.detail.programCode": "http://hl7.org/fhir/ValueSet/ex-program-code",
    "item.detail.subDetail.revenue": "http://hl7.org/fhir/ValueSet/ex-revenue-center",
    "item.detail.subDetail.category": "http://hl7.org/fhir/ValueSet/ex-benefitcategory",
    "item.detail.subDetail.productOrService": "http://hl7.org/fhir/ValueSet/service-uscls",
    "item.detail.subDetail.modifier": "http://hl7.org/fhir/ValueSet/claim-modifiers",
    "item.detail.subDetail.programCode": "http://hl7.org/fhir/ValueSet/ex-program-code"
};
/** Code resolver for ValueSet bindings - returns a random valid code from a ValueSet by URL */
PASClaimClass._codeResolver = (() => {
    // Try to dynamically import the ValueSetRegistry - it may not exist if no ValueSets were generated
    try {
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        const registry = require('./valuesets/index.js');
        if (registry && typeof registry.getRandomConceptByUrl === 'function') {
            return registry.getRandomConceptByUrl;
        }
    }
    catch { /* ValueSetRegistry not available */ }
    return undefined;
})();
