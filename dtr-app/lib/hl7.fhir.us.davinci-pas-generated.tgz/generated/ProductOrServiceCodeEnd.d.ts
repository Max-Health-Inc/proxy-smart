import { Extension } from "fhir/r4";
export interface ProductOrServiceCodeEnd extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-productOrServiceCodeEnd";
}
export declare function validateProductOrServiceCodeEnd(resource: ProductOrServiceCodeEnd): Promise<{
    errors: string[];
    warnings: string[];
}>;
