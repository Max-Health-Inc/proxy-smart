import { Quantity } from "fhir/r4";
export type SimpleQuantity = Quantity;
export declare function validateSimpleQuantity(resource: SimpleQuantity): Promise<{
    errors: string[];
    warnings: string[];
}>;
