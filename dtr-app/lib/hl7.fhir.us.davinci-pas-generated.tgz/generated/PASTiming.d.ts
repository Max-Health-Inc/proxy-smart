import { CalendarPattern } from "./CalendarPattern";
import { DeliveryPattern } from "./DeliveryPattern";
import { Extension, Timing } from "fhir/r4";
export interface PASTiming extends Timing {
    extension?: (Extension | CalendarPattern | DeliveryPattern)[];
}
export declare function validatePASTiming(resource: PASTiming): Promise<{
    errors: string[];
    warnings: string[];
}>;
