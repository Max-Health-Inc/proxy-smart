import { Extension } from "fhir/r4";
export interface InfoCancelledFlag extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/modifierextension-infoCancelled";
}
export declare function validateInfoCancelledFlag(resource: InfoCancelledFlag): Promise<{
    errors: string[];
    warnings: string[];
}>;
