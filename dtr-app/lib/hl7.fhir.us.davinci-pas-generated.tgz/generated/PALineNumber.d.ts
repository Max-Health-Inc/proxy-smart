import { Extension } from "fhir/r4";
export interface PALineNumber extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-paLineNumber";
}
export declare function validatePALineNumber(resource: PALineNumber): Promise<{
    errors: string[];
    warnings: string[];
}>;
