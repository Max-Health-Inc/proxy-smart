import { validateCRDCoverageInformation } from "./CRDCoverageInformation.js";
// Only import helpers actually referenced below (dynamic based on required fields)
import { randomId, setRandomSeed, enrichResource } from "./RandomSupport.js";
// Helper emitted only when meta.profile enforcement is applicable (resource profiles)
// Internal helper (emitted per class file) to clone without resorting to 'any'.
function safeClone(value) {
    // Use native structuredClone if present; otherwise fallback to JSON round-trip.
    // We intentionally avoid casting through any to satisfy no-explicit-any lint rule.
    const g = globalThis;
    // Narrow globalThis to an object potentially containing structuredClone.
    if (typeof g.structuredClone === 'function') {
        return g.structuredClone(value);
    }
    return JSON.parse(JSON.stringify(value)); // best-effort deep clone
}
export class CRDCoverageInformationClass {
    constructor(resource) {
        this.resource = resource;
    }
    /** Validate current resource instance. */
    async validate() {
        return validateCRDCoverageInformation(this.resource);
    }
    getResource() {
        return this.resource;
    }
    setResource(resource) {
        this.resource = resource;
    }
    /**
     * Returns a plain JSON clone of the underlying resource ONLY if the last validation succeeded with zero errors.
     * Call validate() first; otherwise this method throws to prevent accidental use of invalid / unchecked data.
     */
    async toJSON() {
        return safeClone(this.resource);
    }
    /**
     * Create an empty instance for parity testing: for true FHIR resources, includes only resourceType; for datatypes, returns an empty object.
     * Note: meta.profile (when applicable) will be ensured by the constructor when wrapping this resource.
     */
    static empty(overrides = {}) {
        // For Resource profiles, include only resourceType. For Extension profiles, include url so the instance is minimally meaningful.
        const base = {
            url: 'http://hl7.org/fhir/us/davinci-crd/StructureDefinition/ext-coverage-information',
        };
        return { ...base, ...overrides };
    }
    /**
     * Create a minimal randomized instance of CRDCoverageInformation.
     * Populates id, resourceType (if applicable) and primitive required (min>0) top-level fields with placeholders.
     */
    static random(overrides = {}, opts) {
        if (opts?.seed !== undefined) {
            // Direct call (no dynamic require) to ensure deterministic seeding works under ESM.
            setRandomSeed(opts.seed);
        }
        // Start with a Partial to avoid unsafe casting errors; we'll assert at the end.
        const base = { id: randomId(), extension: [{ url: "coverage" }, { url: "covered" }, { url: "date" }, { url: "coverage-assertion-id" }], url: "http://hl7.org/fhir/us/davinci-crd/StructureDefinition/ext-coverage-information", };
        // Always include meta.profile with this profile's canonical URL if available & only for resource profiles
        // (no profileUrl provided or profile targets a datatype – meta.profile not applicable)
        // Enrich the base resource with common fields using centralized enrichment logic
        enrichResource(base, 'Extension', 'http://hl7.org/fhir/us/davinci-crd/StructureDefinition/ext-coverage-information', CRDCoverageInformationClass._fieldPatterns, CRDCoverageInformationClass._forbiddenFields, CRDCoverageInformationClass.valueSetBindings, CRDCoverageInformationClass._codeResolver);
        // Cast through unknown to acknowledge dynamic enrichment
        return { ...base, ...overrides };
    }
    /** Convenience: returns a class instance wrapping a randomized resource. */
    static randomClass(overrides = {}, opts) {
        return new CRDCoverageInformationClass(this.random(overrides, opts));
    }
}
/** Pattern constraints for profile fields (used by random() generator) */
CRDCoverageInformationClass._fieldPatterns = {
    "coverage.url": "coverage",
    "covered.url": "covered",
    "pa-needed.url": "pa-needed",
    "doc-needed.url": "doc-needed",
    "doc-purpose.url": "doc-purpose",
    "info-needed.url": "info-needed",
    "billingCode.url": "billingCode",
    "reason.url": "reason",
    "detail.code.url": "code",
    "detail.value.url": "value",
    "detail.qualification.url": "qualification",
    "detail.url": "detail",
    "dependency.url": "dependency",
    "questionnaire.url": "questionnaire",
    "date.url": "date",
    "coverage-assertion-id.url": "coverage-assertion-id",
    "satisfied-pa-id.url": "satisfied-pa-id",
    "contact.url": "contact",
    "expiry-date.url": "expiry-date",
    "url": "http://hl7.org/fhir/us/davinci-crd/StructureDefinition/ext-coverage-information",
    "_refReq_extension": {
        "url": true,
        "valueReference": true,
        "valueCode": true,
        "valueCoding": true,
        "valueCodeableConcept": true,
        "extension": true,
        "extension.url": true,
        "valueDate": true
    },
    "_choiceType_value[x]": [
        "base64Binary",
        "boolean",
        "canonical",
        "code",
        "date",
        "dateTime",
        "decimal",
        "id",
        "instant",
        "integer",
        "markdown",
        "oid",
        "positiveInt",
        "string",
        "time",
        "unsignedInt",
        "uri",
        "url",
        "uuid",
        "Address",
        "Age",
        "Annotation",
        "Attachment",
        "CodeableConcept",
        "Coding",
        "ContactPoint",
        "Count",
        "Distance",
        "Duration",
        "HumanName",
        "Identifier",
        "Money",
        "Period",
        "Quantity",
        "Range",
        "Ratio",
        "Reference",
        "SampledData",
        "Signature",
        "Timing",
        "ContactDetail",
        "Contributor",
        "DataRequirement",
        "Expression",
        "ParameterDefinition",
        "RelatedArtifact",
        "TriggerDefinition",
        "UsageContext",
        "Dosage",
        "Meta"
    ]
};
/** Fields that are forbidden (max=0) in this profile - must not be generated */
CRDCoverageInformationClass._forbiddenFields = ["value[x]"];
/** ValueSet bindings for coded fields - maps field name to ValueSet URL */
CRDCoverageInformationClass.valueSetBindings = {
    "extension.value[x]": "http://hl7.org/fhir/us/davinci-crd/ValueSet/coverageAssertionReasons",
    "extension.extension.value[x]": "http://hl7.org/fhir/us/davinci-crd/ValueSet/coverageDetail"
};
/** Code resolver for ValueSet bindings - returns a random valid code from a ValueSet by URL */
CRDCoverageInformationClass._codeResolver = (() => {
    // Try to dynamically import the ValueSetRegistry - it may not exist if no ValueSets were generated
    try {
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        const registry = require('./valuesets/index.js');
        if (registry && typeof registry.getRandomConceptByUrl === 'function') {
            return registry.getRandomConceptByUrl;
        }
    }
    catch { /* ValueSetRegistry not available */ }
    return undefined;
})();
