import { Extension } from "fhir/r4";
export interface CertificationExpirationDate extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemCertificationExpirationDate";
}
export declare function validateCertificationExpirationDate(resource: CertificationExpirationDate): Promise<{
    errors: string[];
    warnings: string[];
}>;
