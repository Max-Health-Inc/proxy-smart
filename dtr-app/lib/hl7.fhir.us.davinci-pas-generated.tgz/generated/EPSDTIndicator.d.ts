import { Extension } from "fhir/r4";
export interface EPSDTIndicator extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-epsdtIndicator";
}
export declare function validateEPSDTIndicator(resource: EPSDTIndicator): Promise<{
    errors: string[];
    warnings: string[];
}>;
