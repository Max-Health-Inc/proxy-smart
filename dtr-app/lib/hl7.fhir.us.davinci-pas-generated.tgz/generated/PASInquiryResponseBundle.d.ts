import { Bundle, BundleEntry, FhirResource } from "fhir/r4";
export interface PASInquiryResponseBundleEntry extends BundleEntry {
    /** Must Support */
    resource: FhirResource;
}
export interface PASInquiryResponseBundle extends Bundle {
    type: "collection";
    /** Must Support */
    entry: PASInquiryResponseBundleEntry[];
}
export declare function validatePASInquiryResponseBundle(resource: PASInquiryResponseBundle): Promise<{
    errors: string[];
    warnings: string[];
}>;
