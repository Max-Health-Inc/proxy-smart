import { validatePASPractitionerRole } from "./PASPractitionerRole.js";
// Only import helpers actually referenced below (dynamic based on required fields)
import { randomId, setRandomSeed, enrichResource, skeletonReference } from "./RandomSupport.js";
function ensureProfile(res, profile) {
    if (!res.meta) {
        res.meta = { profile: [profile] };
        return;
    }
    if (!res.meta.profile) {
        res.meta.profile = [profile];
        return;
    }
    if (!res.meta.profile.includes(profile)) {
        res.meta.profile = [...res.meta.profile, profile];
    }
}
// Internal helper (emitted per class file) to clone without resorting to 'any'.
function safeClone(value) {
    // Use native structuredClone if present; otherwise fallback to JSON round-trip.
    // We intentionally avoid casting through any to satisfy no-explicit-any lint rule.
    const g = globalThis;
    // Narrow globalThis to an object potentially containing structuredClone.
    if (typeof g.structuredClone === 'function') {
        return g.structuredClone(value);
    }
    return JSON.parse(JSON.stringify(value)); // best-effort deep clone
}
export class PASPractitionerRoleClass {
    constructor(resource) {
        this.resource = resource;
        ensureProfile(this.resource, 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-practitionerrole');
    }
    /** Validate current resource instance. */
    async validate() {
        return validatePASPractitionerRole(this.resource);
    }
    getResource() {
        return this.resource;
    }
    setResource(resource) {
        this.resource = resource;
        ensureProfile(this.resource, 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-practitionerrole');
    }
    /**
     * Returns a plain JSON clone of the underlying resource ONLY if the last validation succeeded with zero errors.
     * Call validate() first; otherwise this method throws to prevent accidental use of invalid / unchecked data.
     */
    async toJSON() {
        return safeClone(this.resource);
    }
    /**
     * Create an empty instance for parity testing: for true FHIR resources, includes only resourceType; for datatypes, returns an empty object.
     * Note: meta.profile (when applicable) will be ensured by the constructor when wrapping this resource.
     */
    static empty(overrides = {}) {
        // For Resource profiles, include only resourceType. For Extension profiles, include url so the instance is minimally meaningful.
        const base = {
            resourceType: 'PractitionerRole',
        };
        return { ...base, ...overrides };
    }
    /**
     * Create a minimal randomized instance of PASPractitionerRole.
     * Populates id, resourceType (if applicable) and primitive required (min>0) top-level fields with placeholders.
     */
    static random(overrides = {}, opts) {
        if (opts?.seed !== undefined) {
            // Direct call (no dynamic require) to ensure deterministic seeding works under ESM.
            setRandomSeed(opts.seed);
        }
        // Start with a Partial to avoid unsafe casting errors; we'll assert at the end.
        const base = { resourceType: 'PractitionerRole', id: randomId(), practitioner: skeletonReference(), };
        // Always include meta.profile with this profile's canonical URL if available & only for resource profiles
        ensureProfile(base, 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-practitionerrole');
        // Enrich the base resource with common fields using centralized enrichment logic
        enrichResource(base, 'PractitionerRole', 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-practitionerrole', PASPractitionerRoleClass._fieldPatterns, PASPractitionerRoleClass._forbiddenFields, PASPractitionerRoleClass.valueSetBindings, PASPractitionerRoleClass._codeResolver);
        // Cast through unknown to acknowledge dynamic enrichment
        return { ...base, ...overrides };
    }
    /** Convenience: returns a class instance wrapping a randomized resource. */
    static randomClass(overrides = {}, opts) {
        return new PASPractitionerRoleClass(this.random(overrides, opts));
    }
}
/** Pattern constraints for profile fields (used by random() generator) */
PASPractitionerRoleClass._fieldPatterns = {
    "_refReq_notAvailable": {
        "description": true
    }
};
/** Fields that are forbidden (max=0) in this profile - must not be generated */
PASPractitionerRoleClass._forbiddenFields = [];
/** ValueSet bindings for coded fields - maps field name to ValueSet URL */
PASPractitionerRoleClass.valueSetBindings = {
    "language": "http://hl7.org/fhir/ValueSet/languages",
    "code": "http://hl7.org/fhir/ValueSet/practitioner-role",
    "specialty": "http://hl7.org/fhir/ValueSet/c80-practice-codes",
    "availableTime.daysOfWeek": "http://hl7.org/fhir/ValueSet/days-of-week|4.0.1"
};
/** Code resolver for ValueSet bindings - returns a random valid code from a ValueSet by URL */
PASPractitionerRoleClass._codeResolver = (() => {
    // Try to dynamically import the ValueSetRegistry - it may not exist if no ValueSets were generated
    try {
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        const registry = require('./valuesets/index.js');
        if (registry && typeof registry.getRandomConceptByUrl === 'function') {
            return registry.getRandomConceptByUrl;
        }
    }
    catch { /* ValueSetRegistry not available */ }
    return undefined;
})();
