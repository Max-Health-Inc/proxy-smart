import { CodeableConcept, Organization, OrganizationContact } from "fhir/r4";
export interface PASRequestor extends Organization {
    /** Must Support */
    type?: CodeableConcept[];
    /** Must Support */
    contact?: OrganizationContact[];
}
export declare function validatePASRequestor(resource: PASRequestor): Promise<{
    errors: string[];
    warnings: string[];
}>;
