import { Extension } from "fhir/r4";
export interface RevenueUnitRateLimit extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-revenueUnitRateLimit";
}
export declare function validateRevenueUnitRateLimit(resource: RevenueUnitRateLimit): Promise<{
    errors: string[];
    warnings: string[];
}>;
