import { BackboneElement, CodeableConcept, Extension, Identifier, Period, Reference } from "fhir/r4";
export interface PASMetricDataProviderId extends Identifier {
    extension?: Extension[];
    type?: CodeableConcept;
    system?: "http://hl7.org/fhir/sid/us-npi";
    value: string;
    period?: Period;
    assigner?: Reference;
}
export interface PASMetricDataGroupId extends Identifier {
    extension?: Extension[];
    type?: CodeableConcept;
    system?: "http://hl7.org/fhir/sid/us-npi";
    value: string;
    period?: Period;
    assigner?: Reference;
}
export interface PASMetricDataPayerId extends Identifier {
    extension?: Extension[];
    type?: CodeableConcept;
    system: string;
    value: string;
    period?: Period;
    assigner?: Reference;
}
export interface PASMetricDataExchange extends BackboneElement {
    id?: string;
    extension?: Extension[];
    modifierExtension?: Extension[];
    type: string;
    with?: string;
    method: string;
    requestTime: string;
    responseTime?: string;
    httpResponse: string;
}
export interface PASMetricDataIssue extends BackboneElement {
    id?: string;
    extension?: Extension[];
    modifierExtension?: Extension[];
    code: string;
    details?: CodeableConcept;
}
export interface PASMetricDataAaaCodes extends BackboneElement {
    id?: string;
    extension?: Extension[];
    modifierExtension?: Extension[];
    loopID: string;
    aaaCode: string;
}
export interface PASMetricDataItemDetailAaaCodes extends BackboneElement {
    id?: string;
    extension?: Extension[];
    modifierExtension?: Extension[];
    loopID: string;
    aaaCode: string;
}
export interface PASMetricDataItemDetail extends BackboneElement {
    id?: string;
    extension?: Extension[];
    modifierExtension?: Extension[];
    trn?: number;
    item: CodeableConcept;
    assertionId?: string;
    initialSubmissionTime?: string;
    finalResponseTime?: string;
    responsesRequired?: number;
    aaaCodes?: PASMetricDataItemDetailAaaCodes[];
    locationType?: string;
    result?: string;
    denialReason?: string;
}
export interface PASMetricDataRequestedDoc extends BackboneElement {
    id?: string;
    extension?: Extension[];
    modifierExtension?: Extension[];
    docRequest: CodeableConcept[];
    timeRequested: string;
    timeSubmitted?: string;
    submissionMethod?: string;
}
export interface PASMetricData {
    /** @see {@link ./valuesets/ValueSet-MetricDataSource.ts} for valid codes (3 codes) */
    source: string;
    providerId: PASMetricDataProviderId;
    groupId: PASMetricDataGroupId;
    payerId: PASMetricDataPayerId;
    exchange: PASMetricDataExchange[];
    issue?: PASMetricDataIssue[];
    aaaCodes?: PASMetricDataAaaCodes[];
    itemDetail?: PASMetricDataItemDetail[];
    supportingDoc?: string;
    requestedDoc?: PASMetricDataRequestedDoc[];
    exceptionSubmission?: boolean;
    businessLine?: CodeableConcept;
}
export declare function validatePASMetricData(resource: PASMetricData): Promise<{
    errors: string[];
    warnings: string[];
}>;
