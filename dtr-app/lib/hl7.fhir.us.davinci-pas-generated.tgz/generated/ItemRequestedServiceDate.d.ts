import { Extension } from "fhir/r4";
export interface ItemRequestedServiceDate extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemRequestedServiceDate";
}
export declare function validateItemRequestedServiceDate(resource: ItemRequestedServiceDate): Promise<{
    errors: string[];
    warnings: string[];
}>;
