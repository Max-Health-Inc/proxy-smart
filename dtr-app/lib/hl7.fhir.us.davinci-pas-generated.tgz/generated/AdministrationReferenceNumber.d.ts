import { Extension } from "fhir/r4";
export interface AdministrationReferenceNumber extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-administrationReferenceNumber";
}
export declare function validateAdministrationReferenceNumber(resource: AdministrationReferenceNumber): Promise<{
    errors: string[];
    warnings: string[];
}>;
