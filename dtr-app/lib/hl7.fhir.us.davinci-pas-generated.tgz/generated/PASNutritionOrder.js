import fhirpath from "fhirpath";
import fhirpath_r4_model from "fhirpath/fhir-context/r4/index.js";
export async function validatePASNutritionOrder(resource) {
    const errors = [];
    const warnings = [];
    const result0 = await Promise.resolve(fhirpath.evaluate(resource, "NutritionOrder.all(contained.contained.empty())", { resource }, fhirpath_r4_model));
    if (!result0.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL NOT contain nested Resources");
    }
    const result1 = await Promise.resolve(fhirpath.evaluate(resource, "NutritionOrder.all(contained.meta.versionId.empty() and contained.meta.lastUpdated.empty())", { resource }, fhirpath_r4_model));
    if (!result1.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a meta.versionId or a meta.lastUpdated");
    }
    const result2 = await Promise.resolve(fhirpath.evaluate(resource, "NutritionOrder.all(contained.meta.security.empty())", { resource }, fhirpath_r4_model));
    if (!result2.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a security label");
    }
    const result3 = await Promise.resolve(fhirpath.evaluate(resource, "NutritionOrder.all(text.`div`.exists())", { resource }, fhirpath_r4_model));
    if (!result3.every(Boolean)) {
        warnings.push("Constraint violation: A resource should have narrative for robust management");
    }
    const result4 = await Promise.resolve(fhirpath.evaluate(resource, "NutritionOrder.all(oralDiet.exists() or supplement.exists() or enteralFormula.exists())", { resource }, fhirpath_r4_model));
    if (!result4.every(Boolean)) {
        warnings.push("Constraint violation: Nutrition Order SHALL contain either Oral Diet , Supplement, or Enteral Formula class");
    }
    const result5 = await Promise.resolve(fhirpath.evaluate(resource, "meta.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result5.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result6 = await Promise.resolve(fhirpath.evaluate(resource, "implicitRules.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result6.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result7 = await Promise.resolve(fhirpath.evaluate(resource, "language.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result7.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result8 = await Promise.resolve(fhirpath.evaluate(resource, "text.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result8.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result9 = await Promise.resolve(fhirpath.evaluate(resource, "extension.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result9.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result10 = await Promise.resolve(fhirpath.evaluate(resource, "modifierExtension.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result10.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result11 = await Promise.resolve(fhirpath.evaluate(resource, "identifier.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result11.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result12 = await Promise.resolve(fhirpath.evaluate(resource, "instantiatesCanonical.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result12.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result13 = await Promise.resolve(fhirpath.evaluate(resource, "instantiatesUri.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result13.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result14 = await Promise.resolve(fhirpath.evaluate(resource, "instantiates.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result14.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result15 = await Promise.resolve(fhirpath.evaluate(resource, "status.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result15.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result16 = await Promise.resolve(fhirpath.evaluate(resource, "intent.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result16.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result17 = await Promise.resolve(fhirpath.evaluate(resource, "patient.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result17.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result18 = await Promise.resolve(fhirpath.evaluate(resource, "encounter.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result18.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result19 = await Promise.resolve(fhirpath.evaluate(resource, "dateTime.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result19.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result20 = await Promise.resolve(fhirpath.evaluate(resource, "orderer.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result20.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result21 = await Promise.resolve(fhirpath.evaluate(resource, "allergyIntolerance.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result21.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result22 = await Promise.resolve(fhirpath.evaluate(resource, "foodPreferenceModifier.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result22.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result23 = await Promise.resolve(fhirpath.evaluate(resource, "excludeFoodModifier.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result23.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result24 = await Promise.resolve(fhirpath.evaluate(resource, "oralDiet.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result24.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result25 = await Promise.resolve(fhirpath.evaluate(resource, "supplement.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result25.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result26 = await Promise.resolve(fhirpath.evaluate(resource, "enteralFormula.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result26.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result27 = await Promise.resolve(fhirpath.evaluate(resource, "note.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result27.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result28 = await Promise.resolve(fhirpath.evaluate(resource, "DomainResource.all(contained.contained.empty())", { resource }, fhirpath_r4_model));
    if (!result28.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL NOT contain nested Resources");
    }
    const result29 = await Promise.resolve(fhirpath.evaluate(resource, "DomainResource.all(contained.meta.versionId.empty() and contained.meta.lastUpdated.empty())", { resource }, fhirpath_r4_model));
    if (!result29.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a meta.versionId or a meta.lastUpdated");
    }
    const result30 = await Promise.resolve(fhirpath.evaluate(resource, "DomainResource.all(contained.meta.security.empty())", { resource }, fhirpath_r4_model));
    if (!result30.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a security label");
    }
    const result31 = await Promise.resolve(fhirpath.evaluate(resource, "DomainResource.all(text.`div`.exists())", { resource }, fhirpath_r4_model));
    if (!result31.every(Boolean)) {
        warnings.push("Constraint violation: A resource should have narrative for robust management");
    }
    const result32 = await Promise.resolve(fhirpath.evaluate(resource, "extension.where(url='questionnaire' or url='response').exists() implies (extension.where(url = 'doc-needed').exists() and extension.where(url = 'doc-needed').all(value != 'no-doc'))", { resource }, fhirpath_r4_model));
    if (!result32.every(Boolean)) {
        errors.push("Constraint violation: Questionnaire and QuestionnaireResponse are only allowed when doc-needed exists and not equal to 'no-doc'");
    }
    const result33 = await Promise.resolve(fhirpath.evaluate(resource, "extension.where(url = 'covered' and value != 'not-covered') implies extension.where(url = 'pa-needed').exists()", { resource }, fhirpath_r4_model));
    if (!result33.every(Boolean)) {
        errors.push("Constraint violation: If covered is set to 'not-covered', then 'pa-needed' should not exist.");
    }
    const result34 = await Promise.resolve(fhirpath.evaluate(resource, "extension.where(url = 'info-needed').exists() implies extension.where((url = 'covered' or url = 'pa-needed' or url = 'doc-needed') and value = 'conditional').count() >= 1", { resource }, fhirpath_r4_model));
    if (!result34.every(Boolean)) {
        errors.push("Constraint violation: If 'info-needed' exists, then at least one of 'covered', 'pa-needed', or 'doc-needed' must be 'conditional'.");
    }
    const result35 = await Promise.resolve(fhirpath.evaluate(resource, "extension.where(url = 'pa-needed' and value = 'satisfied') and extension.where(url = 'doc-purpose').exists() implies extension.where(url = 'doc-purpose').all(value != 'PA')", { resource }, fhirpath_r4_model));
    if (!result35.every(Boolean)) {
        errors.push("Constraint violation: If 'pa-needed' is 'satisfied', then 'Doc-purpose' can't be 'PA'.");
    }
    const result36 = await Promise.resolve(fhirpath.evaluate(resource, "extension.where(url = 'pa-needed' and value = 'satisfied').exists() = extension.where(url = 'satisfied-pa-id').exists()", { resource }, fhirpath_r4_model));
    if (!result36.every(Boolean)) {
        errors.push("Constraint violation: 'satisfied-pa-id' must exist if and only if 'pa-needed' is set to 'satisfied'.");
    }
    const result37 = await Promise.resolve(fhirpath.evaluate(resource, "status.exists()", { resource }, fhirpath_r4_model));
    if (!result37.every(Boolean)) {
        errors.push("Constraint violation: status must be present");
    }
    const result38 = await Promise.resolve(fhirpath.evaluate(resource, "intent.exists()", { resource }, fhirpath_r4_model));
    if (!result38.every(Boolean)) {
        errors.push("Constraint violation: intent must be present");
    }
    const result39 = await Promise.resolve(fhirpath.evaluate(resource, "patient.exists()", { resource }, fhirpath_r4_model));
    if (!result39.every(Boolean)) {
        errors.push("Constraint violation: patient must be present");
    }
    const result40 = await Promise.resolve(fhirpath.evaluate(resource, "dateTime.exists()", { resource }, fhirpath_r4_model));
    if (!result40.every(Boolean)) {
        errors.push("Constraint violation: dateTime must be present");
    }
    const result41 = await Promise.resolve(fhirpath.evaluate(resource, "extension.count() <= 1", { resource }, fhirpath_r4_model));
    if (!result41.every(Boolean)) {
        errors.push("Constraint violation: extension must contain at most one element");
    }
    // Fixed value constraint for intent
    if (resource.intent !== undefined && resource.intent !== "order") {
        errors.push("intent must have the fixed value 'order'");
    }
    return { errors, warnings };
}
