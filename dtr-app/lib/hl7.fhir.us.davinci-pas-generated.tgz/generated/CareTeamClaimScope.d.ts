import { Extension } from "fhir/r4";
export interface CareTeamClaimScope extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-careTeamClaimScope";
}
export declare function validateCareTeamClaimScope(resource: CareTeamClaimScope): Promise<{
    errors: string[];
    warnings: string[];
}>;
