import { Extension } from "fhir/r4";
export interface HomeHealthCareInformation extends Extension {
    extension: Extension[];
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-homeHealthCareInformation";
}
export declare function validateHomeHealthCareInformation(resource: HomeHealthCareInformation): Promise<{
    errors: string[];
    warnings: string[];
}>;
