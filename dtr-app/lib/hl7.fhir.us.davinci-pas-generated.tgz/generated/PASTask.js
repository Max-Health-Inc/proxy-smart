import fhirpath from "fhirpath";
import fhirpath_r4_model from "fhirpath/fhir-context/r4/index.js";
export async function validatePASTask(resource) {
    const errors = [];
    const warnings = [];
    const result0 = await Promise.resolve(fhirpath.evaluate(resource, "Task.all(contained.contained.empty())", { resource }, fhirpath_r4_model));
    if (!result0.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL NOT contain nested Resources");
    }
    const result1 = await Promise.resolve(fhirpath.evaluate(resource, "Task.all(contained.meta.versionId.empty() and contained.meta.lastUpdated.empty())", { resource }, fhirpath_r4_model));
    if (!result1.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a meta.versionId or a meta.lastUpdated");
    }
    const result2 = await Promise.resolve(fhirpath.evaluate(resource, "Task.all(contained.meta.security.empty())", { resource }, fhirpath_r4_model));
    if (!result2.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a security label");
    }
    const result3 = await Promise.resolve(fhirpath.evaluate(resource, "Task.all(text.`div`.exists())", { resource }, fhirpath_r4_model));
    if (!result3.every(Boolean)) {
        warnings.push("Constraint violation: A resource should have narrative for robust management");
    }
    const result4 = await Promise.resolve(fhirpath.evaluate(resource, "Task.all(lastModified.exists().not() or authoredOn.exists().not() or lastModified >= authoredOn)", { resource }, fhirpath_r4_model));
    if (!result4.every(Boolean)) {
        errors.push("Constraint violation: Last modified date must be greater than or equal to authored-on date.");
    }
    const result5 = await Promise.resolve(fhirpath.evaluate(resource, "Task.all($this.code.coding.where(code='attachment-request-code').count() > 0 implies $this.input.type.coding.where(code='attachments-needed').count() > 0)", { resource }, fhirpath_r4_model));
    if (!result5.every(Boolean)) {
        errors.push("Constraint violation: If task.code is attachment-request-code, then attachments needed slice is required.");
    }
    const result6 = await Promise.resolve(fhirpath.evaluate(resource, "Task.all($this.code.coding.where(code='attachment-request-questionnaire').count() > 0 implies $this.input.type.coding.where(code='questionnaires-needed').count() > 0)", { resource }, fhirpath_r4_model));
    if (!result6.every(Boolean)) {
        errors.push("Constraint violation: If task.code is attachment-request-questionnaire, then questionnaire needed slice is required.");
    }
    const result7 = await Promise.resolve(fhirpath.evaluate(resource, "meta.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result7.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result8 = await Promise.resolve(fhirpath.evaluate(resource, "implicitRules.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result8.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result9 = await Promise.resolve(fhirpath.evaluate(resource, "language.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result9.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result10 = await Promise.resolve(fhirpath.evaluate(resource, "text.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result10.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result11 = await Promise.resolve(fhirpath.evaluate(resource, "extension.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result11.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result12 = await Promise.resolve(fhirpath.evaluate(resource, "modifierExtension.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result12.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result13 = await Promise.resolve(fhirpath.evaluate(resource, "identifier.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result13.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result14 = await Promise.resolve(fhirpath.evaluate(resource, "instantiatesCanonical.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result14.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result15 = await Promise.resolve(fhirpath.evaluate(resource, "instantiatesUri.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result15.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result16 = await Promise.resolve(fhirpath.evaluate(resource, "basedOn.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result16.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result17 = await Promise.resolve(fhirpath.evaluate(resource, "groupIdentifier.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result17.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result18 = await Promise.resolve(fhirpath.evaluate(resource, "partOf.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result18.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result19 = await Promise.resolve(fhirpath.evaluate(resource, "status.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result19.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result20 = await Promise.resolve(fhirpath.evaluate(resource, "statusReason.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result20.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result21 = await Promise.resolve(fhirpath.evaluate(resource, "businessStatus.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result21.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result22 = await Promise.resolve(fhirpath.evaluate(resource, "intent.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result22.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result23 = await Promise.resolve(fhirpath.evaluate(resource, "priority.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result23.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result24 = await Promise.resolve(fhirpath.evaluate(resource, "code.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result24.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result25 = await Promise.resolve(fhirpath.evaluate(resource, "description.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result25.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result26 = await Promise.resolve(fhirpath.evaluate(resource, "focus.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result26.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result27 = await Promise.resolve(fhirpath.evaluate(resource, "for.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result27.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result28 = await Promise.resolve(fhirpath.evaluate(resource, "encounter.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result28.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result29 = await Promise.resolve(fhirpath.evaluate(resource, "executionPeriod.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result29.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result30 = await Promise.resolve(fhirpath.evaluate(resource, "authoredOn.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result30.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result31 = await Promise.resolve(fhirpath.evaluate(resource, "lastModified.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result31.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result32 = await Promise.resolve(fhirpath.evaluate(resource, "requester.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result32.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result33 = await Promise.resolve(fhirpath.evaluate(resource, "performerType.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result33.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result34 = await Promise.resolve(fhirpath.evaluate(resource, "owner.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result34.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result35 = await Promise.resolve(fhirpath.evaluate(resource, "location.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result35.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result36 = await Promise.resolve(fhirpath.evaluate(resource, "reasonCode.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result36.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result37 = await Promise.resolve(fhirpath.evaluate(resource, "reasonReference.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result37.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result38 = await Promise.resolve(fhirpath.evaluate(resource, "insurance.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result38.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result39 = await Promise.resolve(fhirpath.evaluate(resource, "note.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result39.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result40 = await Promise.resolve(fhirpath.evaluate(resource, "relevantHistory.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result40.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result41 = await Promise.resolve(fhirpath.evaluate(resource, "restriction.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result41.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result42 = await Promise.resolve(fhirpath.evaluate(resource, "input.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result42.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result43 = await Promise.resolve(fhirpath.evaluate(resource, "output.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result43.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result44 = await Promise.resolve(fhirpath.evaluate(resource, "DomainResource.all(contained.contained.empty())", { resource }, fhirpath_r4_model));
    if (!result44.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL NOT contain nested Resources");
    }
    const result45 = await Promise.resolve(fhirpath.evaluate(resource, "DomainResource.all(contained.meta.versionId.empty() and contained.meta.lastUpdated.empty())", { resource }, fhirpath_r4_model));
    if (!result45.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a meta.versionId or a meta.lastUpdated");
    }
    const result46 = await Promise.resolve(fhirpath.evaluate(resource, "DomainResource.all(contained.meta.security.empty())", { resource }, fhirpath_r4_model));
    if (!result46.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a security label");
    }
    const result47 = await Promise.resolve(fhirpath.evaluate(resource, "DomainResource.all(text.`div`.exists())", { resource }, fhirpath_r4_model));
    if (!result47.every(Boolean)) {
        warnings.push("Constraint violation: A resource should have narrative for robust management");
    }
    const result48 = await Promise.resolve(fhirpath.evaluate(resource, "identifier.count() >= 1", { resource }, fhirpath_r4_model));
    if (!result48.every(Boolean)) {
        errors.push("Constraint violation: identifier must contain at least one element");
    }
    const result49 = await Promise.resolve(fhirpath.evaluate(resource, "status.exists()", { resource }, fhirpath_r4_model));
    if (!result49.every(Boolean)) {
        errors.push("Constraint violation: status must be present");
    }
    const result50 = await Promise.resolve(fhirpath.evaluate(resource, "intent.exists()", { resource }, fhirpath_r4_model));
    if (!result50.every(Boolean)) {
        errors.push("Constraint violation: intent must be present");
    }
    const result51 = await Promise.resolve(fhirpath.evaluate(resource, "code.exists()", { resource }, fhirpath_r4_model));
    if (!result51.every(Boolean)) {
        errors.push("Constraint violation: code must be present");
    }
    const result52 = await Promise.resolve(fhirpath.evaluate(resource, "for.exists()", { resource }, fhirpath_r4_model));
    if (!result52.every(Boolean)) {
        errors.push("Constraint violation: for must be present");
    }
    const result53 = await Promise.resolve(fhirpath.evaluate(resource, "requester.exists()", { resource }, fhirpath_r4_model));
    if (!result53.every(Boolean)) {
        errors.push("Constraint violation: requester must be present");
    }
    const result54 = await Promise.resolve(fhirpath.evaluate(resource, "owner.exists()", { resource }, fhirpath_r4_model));
    if (!result54.every(Boolean)) {
        errors.push("Constraint violation: owner must be present");
    }
    const result55 = await Promise.resolve(fhirpath.evaluate(resource, "reasonCode.exists()", { resource }, fhirpath_r4_model));
    if (!result55.every(Boolean)) {
        errors.push("Constraint violation: reasonCode must be present");
    }
    const result56 = await Promise.resolve(fhirpath.evaluate(resource, "reasonReference.exists()", { resource }, fhirpath_r4_model));
    if (!result56.every(Boolean)) {
        errors.push("Constraint violation: reasonReference must be present");
    }
    const result57 = await Promise.resolve(fhirpath.evaluate(resource, "input.count() >= 2", { resource }, fhirpath_r4_model));
    if (!result57.every(Boolean)) {
        errors.push("Constraint violation: input must contain at least 2 elements");
    }
    const result58 = await Promise.resolve(fhirpath.evaluate(resource, "input.count() >= 1", { resource }, fhirpath_r4_model));
    if (!result58.every(Boolean)) {
        errors.push("Constraint violation: input must contain at least one element");
    }
    const result59 = await Promise.resolve(fhirpath.evaluate(resource, "input.count() <= 1", { resource }, fhirpath_r4_model));
    if (!result59.every(Boolean)) {
        errors.push("Constraint violation: input must contain at most one element");
    }
    const result60 = await Promise.resolve(fhirpath.evaluate(resource, "input.extension.count() <= 1", { resource }, fhirpath_r4_model));
    if (!result60.every(Boolean)) {
        errors.push("Constraint violation: input.extension must contain at most one element");
    }
    // Pattern constraint for reasonCode: must include coding with system="http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes" and code="priorAuthorization"
    if (resource.reasonCode) {
        const reasonCode_pattern0Valid = resource.reasonCode.coding?.some(coding => coding?.system === "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes" && coding?.code === "priorAuthorization");
        if (!reasonCode_pattern0Valid) {
            errors.push("reasonCode must include a coding with system 'http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes' and code 'priorAuthorization'");
        }
    }
    // Fixed value constraint for intent
    if (resource.intent !== undefined && resource.intent !== "order") {
        errors.push("intent must have the fixed value 'order'");
    }
    // Required BackboneElement slice validation for input:PayerURL (discriminated by type)
    if (resource.input && Array.isArray(resource.input)) {
        const PayerURLElements = resource.input.filter(item => item.type?.coding?.some((c) => c.system === "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes" && c.code === "payer-url"));
        if (PayerURLElements.length < 1) {
            errors.push("No elements matched required slice: 'input:PayerURL'");
        }
    }
    else {
        errors.push("No elements matched required slice: 'input:PayerURL'");
    }
    // Slice validation for input.extension:paLineNumber skipped: no pattern/value discriminator found
    // Discriminator types 'type', 'profile', 'exists', 'position' are not yet supported
    // Slice validation for input.extension:paLineNumber skipped: no pattern/value discriminator found
    // Discriminator types 'type', 'profile', 'exists', 'position' are not yet supported
    return { errors, warnings };
}
