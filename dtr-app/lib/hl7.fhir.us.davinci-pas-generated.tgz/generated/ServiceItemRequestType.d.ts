import { Extension } from "fhir/r4";
export interface ServiceItemRequestType extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-serviceItemRequestType";
}
export declare function validateServiceItemRequestType(resource: ServiceItemRequestType): Promise<{
    errors: string[];
    warnings: string[];
}>;
