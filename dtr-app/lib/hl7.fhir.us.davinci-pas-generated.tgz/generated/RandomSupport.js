let __seed = Date.now() & 0xffffffff;
export function setRandomSeed(seed) { __seed = seed >>> 0; }
function rng() {
    __seed = (1664525 * __seed + 1013904223) >>> 0;
    return __seed / 0x100000000;
}
export function randomId() { return 'id-' + rng().toString(36).slice(2, 10); }
export function randomString(prefix = 'val') { return prefix + '-' + rng().toString(36).slice(2, 8); }
export function randomInt(min = 0, max = 100) { return Math.floor(rng() * (max - min + 1)) + min; }
export function randomBool() { return rng() < 0.5; }
export function randomDate(start = new Date(Date.now() - 1000 * 60 * 60 * 24 * 30), end = new Date()) { const t = start.getTime() + rng() * (end.getTime() - start.getTime()); return new Date(t).toISOString(); }
export function randomCode(codes) { if (!codes.length)
    return randomString('code'); return codes[Math.floor(rng() * codes.length)]; }
/**
 * Generate a valid UUID v4 (random) for use in urn:uuid: URIs.
 * This generates proper hex-formatted UUIDs that are valid for FHIR fullUrl and identifier values.
 */
export function randomUUID() {
    const hex = () => Math.floor(rng() * 16).toString(16);
    const segment = (len) => Array.from({ length: len }, hex).join('');
    // UUID v4 format: xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx (y is 8, 9, a, or b)
    const variant = ['8', '9', 'a', 'b'][Math.floor(rng() * 4)];
    return segment(8) + '-' + segment(4) + '-4' + segment(3) + '-' + variant + segment(3) + '-' + segment(12);
}
/**
 * Generate a valid US National Provider Identifier (NPI).
 * NPIs are 10-digit numbers that pass the US Core Luhn check.
 * The US Core us-core-17 constraint uses a specific algorithm:
 * - Doubles digits at positions 0, 2, 4, 6, 8 (even positions from left)
 * - If doubled value >= 10, subtracts 9
 * - Adds 24 (constant for '80' prefix)
 * - Sum must be divisible by 10
 */
export function randomNPI() {
    // Generate 9 random digits (the 10th is the check digit)
    const digits = [];
    for (let i = 0; i < 9; i++) {
        digits.push(Math.floor(rng() * 10));
    }
    // Calculate sum using US Core algorithm: double at even positions (0,2,4,6,8) + 24
    let sum = 24; // Constant for '80' prefix
    for (let i = 0; i < 9; i++) {
        let d = digits[i];
        // Double digits at even positions (0, 2, 4, 6, 8)
        if (i % 2 === 0) {
            d = d < 5 ? d * 2 : (d * 2) - 9;
        }
        sum += d;
    }
    // Check digit makes sum divisible by 10
    const checkDigit = (10 - (sum % 10)) % 10;
    return digits.join('') + checkDigit.toString();
}
// Skeleton factories for common FHIR complex types
export function skeletonHumanName() { return { family: randomString('fam'), given: [randomString('giv')] }; }
export function skeletonAddress() { return { line: [randomString('line')], city: randomString('city'), country: 'DE' }; }
export function skeletonCoding(system = 'http://terminology.hl7.org/CodeSystem/v3-NullFlavor', codes = []) { return { system, code: randomCode(codes), display: randomString('disp') }; }
export function skeletonCodeableConcept(system, codes = []) { return { coding: [skeletonCoding(system, codes)], text: randomString('text') }; }
export function skeletonIdentifier(system = 'urn:ietf:rfc:3986') { return { system, value: 'urn:uuid:' + randomUUID() }; }
export function skeletonReference(resourceType = 'Patient') { return { reference: resourceType + '/' + randomId() }; }
export function skeletonPeriod() { const start = randomDate(); return { start, end: start }; }
export function skeletonContactPoint() { return { system: 'phone', value: randomString('tel'), use: 'mobile' }; }
export function skeletonQuantity() { return { value: randomInt(1, 100), unit: randomString('u'), system: 'http://unitsofmeasure.org' }; }
/**
 * This is a centralized enrichment function used by all generated random() methods.
 * @param base - The base resource object to enrich (will be mutated)
 * @param baseResource - The FHIR resource type (e.g., 'Observation', 'Patient')
 * @param profileUrl - The canonical URL of the profile
 * @param fieldPatterns - Map of field names to their pattern constraints
 * @param forbiddenFields - Array of field names that are forbidden (max=0) in this profile
 * @param valueSetBindings - Map of field names to ValueSet URLs for coded bindings
 * @param codeResolver - Optional function to resolve a ValueSet URL to a random valid code
 */
export function enrichResource(base, baseResource, profileUrl, fieldPatterns, forbiddenFields = [], valueSetBindings = {}, codeResolver) {
    try {
        // Helper to check if a field is forbidden
        const isForbidden = (fieldName) => forbiddenFields.includes(fieldName);
        // Helper to resolve a code from ValueSet binding - uses codeResolver if available
        // Returns a CodeableConcept-compatible structure or undefined if not resolvable
        const resolveBindingCode = (fieldName, fallbackSystem, fallbackCode, fallbackDisplay) => {
            const bindingUrl = valueSetBindings[fieldName];
            if (bindingUrl && codeResolver) {
                const resolved = codeResolver(bindingUrl);
                if (resolved) {
                    return {
                        coding: [{ system: resolved.system, code: resolved.code, display: resolved.display }],
                        text: resolved.display || resolved.code
                    };
                }
            }
            // Return fallback if provided
            if (fallbackSystem && fallbackCode) {
                return {
                    coding: [{ system: fallbackSystem, code: fallbackCode, display: fallbackDisplay }],
                    text: fallbackDisplay || fallbackCode
                };
            }
            return undefined;
        };
        // Helper to resolve a code and return just the code string (for primitive 'code' types)
        const resolveBindingCodePrimitive = (fieldName, fallbackCode) => {
            const bindingUrl = valueSetBindings[fieldName];
            if (bindingUrl && codeResolver) {
                const resolved = codeResolver(bindingUrl);
                if (resolved) {
                    return resolved.code;
                }
            }
            return fallbackCode;
        };
        // Helper to get CodeableConcept pattern value (for category, code, etc.)
        const getPatternValue = (fieldName) => {
            if (!fieldPatterns || Object.keys(fieldPatterns).length === 0 || !(fieldName in fieldPatterns))
                return undefined;
            const pattern = fieldPatterns[fieldName];
            if (!pattern || typeof pattern !== 'object')
                return undefined;
            const obj = pattern;
            if ('coding' in obj && Array.isArray(obj.coding) && obj.coding.length > 0) {
                return { coding: obj.coding };
            }
            return undefined;
        };
        // Helper to get the raw pattern for a field (returns patterns with system even without code)
        // Used for merging pattern fields (like 'version') into existing codings
        const getRawCodeableConceptPattern = (fieldName) => {
            if (!fieldPatterns || Object.keys(fieldPatterns).length === 0 || !(fieldName in fieldPatterns))
                return undefined;
            const pattern = fieldPatterns[fieldName];
            if (!pattern || typeof pattern !== 'object')
                return undefined;
            const obj = pattern;
            if ('coding' in obj && Array.isArray(obj.coding) && obj.coding.length > 0) {
                return { coding: obj.coding };
            }
            return undefined;
        };
        // Helper to merge pattern coding fields into existing codings (preserves existing fields, adds pattern fields)
        const mergeCodingPatterns = (existingCodings, patternCodings) => {
            const patternBySystem = new Map();
            for (const patternCoding of patternCodings) {
                patternBySystem.set(patternCoding.system, patternCoding);
            }
            for (const existing of existingCodings) {
                const patternCoding = patternBySystem.get(existing.system);
                if (patternCoding) {
                    // Merge: pattern fields are added to existing (existing takes precedence for conflicts except pattern-specific fields like version)
                    for (const [key, value] of Object.entries(patternCoding)) {
                        if (key !== 'system' && !(key in existing)) {
                            existing[key] = value;
                        }
                    }
                }
            }
        };
        // Helper to get "complete" CodeableConcept pattern value (must have both system AND code)
        // Returns undefined if the pattern only specifies system without code
        const getCompleteCodePatternValue = (fieldName) => {
            if (!fieldPatterns || Object.keys(fieldPatterns).length === 0 || !(fieldName in fieldPatterns))
                return undefined;
            const pattern = fieldPatterns[fieldName];
            if (!pattern || typeof pattern !== 'object')
                return undefined;
            const obj = pattern;
            if ('coding' in obj && Array.isArray(obj.coding) && obj.coding.length > 0) {
                // Check if the first coding has both system and code
                const firstCoding = obj.coding[0];
                if (firstCoding && 'system' in firstCoding && 'code' in firstCoding) {
                    return { coding: obj.coding };
                }
            }
            return undefined;
        };
        // Helper to get primitive pattern value (for patternString, patternCode, patternUri)
        // Keys are nested paths like "valueQuantity.unit", "deviceName.name", etc.
        const getPrimitivePattern = (nestedPath) => {
            if (!fieldPatterns || !(nestedPath in fieldPatterns))
                return undefined;
            const value = fieldPatterns[nestedPath];
            if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
                return value;
            }
            return undefined;
        };
        // Helper to apply nested primitive patterns to a target object
        // e.g., applies "valueQuantity.unit" pattern to base.valueQuantity.unit
        const applyNestedPatterns = (targetField, target) => {
            if (!fieldPatterns)
                return;
            for (const key of Object.keys(fieldPatterns)) {
                if (key.startsWith(targetField + '.')) {
                    const nestedKey = key.slice(targetField.length + 1); // e.g., "unit" from "valueQuantity.unit"
                    const patternValue = fieldPatterns[key];
                    if (typeof patternValue === 'string' || typeof patternValue === 'number' || typeof patternValue === 'boolean') {
                        target[nestedKey] = patternValue;
                    }
                }
            }
        };
        // Helper to get Reference nested requirements (e.g., serviceProvider.identifier, serviceProvider.display)
        // These are stored in fieldPatterns with key "_refReq_<fieldName>"
        const getRefRequirements = (fieldName) => {
            if (!fieldPatterns)
                return undefined;
            const reqKey = '_refReq_' + fieldName;
            const reqs = fieldPatterns[reqKey];
            if (reqs && typeof reqs === 'object' && !Array.isArray(reqs)) {
                return reqs;
            }
            return undefined;
        };
        // Identifier-like profile
        if (/Identifier/i.test(baseResource)) {
            if (!isForbidden('system') && !('system' in base))
                base.system = 'urn:ietf:rfc:3986';
            if (!isForbidden('value') && !('value' in base))
                base.value = 'urn:uuid:' + randomUUID();
            if (!isForbidden('type') && !('type' in base))
                base.type = { text: 'Primary Identifier' };
        }
        // Patient / Practitioner
        if (/Patient|Practitioner/i.test(baseResource)) {
            if (!isForbidden('identifier') && !('identifier' in base))
                base.identifier = [{ system: 'urn:ietf:rfc:3986', value: 'urn:uuid:' + randomUUID() }];
            if (!isForbidden('name') && !('name' in base))
                base.name = [{ family: randomId(), given: [randomId()] }];
            if (!isForbidden('gender') && !('gender' in base))
                base.gender = 'unknown';
            if (!isForbidden('birthDate') && !('birthDate' in base))
                base.birthDate = new Date(Date.now() - 10 * 365 * 24 * 60 * 60 * 1000).toISOString().substring(0, 10);
            if (!isForbidden('address') && !('address' in base))
                base.address = [{ city: 'Example City', postalCode: '12345', country: 'DE' }];
        }
        // Condition
        if (/Condition/i.test(baseResource)) {
            // For code field: ADD missing pattern codings to existing codings
            // Never remove existing codings - classGenerator's random() already includes required slice codings
            // We only add any pattern codings that might be missing (by system+code pair)
            const patternCode = getCompleteCodePatternValue('code');
            if (!isForbidden('code')) {
                if (patternCode && 'code' in base && base.code && typeof base.code === 'object') {
                    const existingCode = base.code;
                    const patternCodeObj = patternCode;
                    if (existingCode.coding && patternCodeObj.coding) {
                        // Build a set of existing coding keys (system|code pairs)
                        const existingCodingKeys = new Set();
                        for (const existing of existingCode.coding) {
                            const key = String(existing.system || '') + '|' + String(existing.code || '');
                            existingCodingKeys.add(key);
                        }
                        // Only ADD pattern codings that aren't already present (by system+code)
                        for (const patternCoding of patternCodeObj.coding) {
                            const key = String(patternCoding.system || '') + '|' + String(patternCoding.code || '');
                            if (!existingCodingKeys.has(key)) {
                                existingCode.coding.push(patternCoding);
                                existingCodingKeys.add(key);
                            }
                        }
                    }
                    else if (!existingCode.coding && patternCodeObj.coding) {
                        existingCode.coding = patternCodeObj.coding;
                    }
                }
                else if (patternCode) {
                    base.code = patternCode;
                }
                else if (!('code' in base)) {
                    // Try to resolve from ValueSet binding first, fall back to hardcoded default
                    const resolved = resolveBindingCode('code', 'http://snomed.info/sct', '64572001', 'Condition');
                    base.code = resolved || { coding: [{ system: 'http://snomed.info/sct', code: '64572001', display: 'Condition' }], text: 'Example condition' };
                }
                // Also merge in pattern fields (like version) that don't require a complete pattern (system+code)
                // This handles cases where the pattern specifies additional fields like version for ICD-10-GM coding profiles
                const rawPattern = getRawCodeableConceptPattern('code');
                if (rawPattern?.coding && 'code' in base && base.code && typeof base.code === 'object') {
                    const existingCode = base.code;
                    if (existingCode.coding) {
                        mergeCodingPatterns(existingCode.coding, rawPattern.coding);
                    }
                }
            }
            if (!isForbidden('clinicalStatus') && !('clinicalStatus' in base)) {
                const resolved = resolveBindingCode('clinicalStatus', 'http://terminology.hl7.org/CodeSystem/condition-clinical', 'active');
                base.clinicalStatus = resolved || { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/condition-clinical', code: 'active' }] };
            }
            if (!isForbidden('verificationStatus') && !('verificationStatus' in base)) {
                const resolved = resolveBindingCode('verificationStatus', 'http://terminology.hl7.org/CodeSystem/condition-ver-status', 'confirmed');
                base.verificationStatus = resolved || { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/condition-ver-status', code: 'confirmed' }] };
            }
            if (!isForbidden('subject') && !('subject' in base))
                base.subject = { reference: 'Patient/' + randomId() };
            // If code is present and encounter is required (via _refReq_encounter), add encounter
            // This is needed for constraints like ISiK's isik-con1 ("wenn code vorhanden, dann encounter")
            if ('code' in base && getRefRequirements('encounter') && !('encounter' in base)) {
                base.encounter = { reference: 'Encounter/' + randomId() };
            }
            // Always use pattern if available for category, even if category already exists
            const patternCategory = getPatternValue('category');
            if (patternCategory) {
                base.category = [patternCategory];
            }
            else if (!('category' in base)) {
                const resolved = resolveBindingCode('category', 'http://terminology.hl7.org/CodeSystem/condition-category', 'encounter-diagnosis');
                base.category = [resolved || { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/condition-category', code: 'encounter-diagnosis' }] }];
            }
        }
        // Observation
        if (/Observation/i.test(baseResource)) {
            if (!('status' in base))
                base.status = 'final';
            // For code field: ADD missing pattern codings to existing codings
            // Never remove existing codings - classGenerator's random() already includes required slice codings
            // We only add any pattern codings that might be missing (by system+code pair)
            const patternCode = getCompleteCodePatternValue('code');
            if (patternCode && 'code' in base && base.code && typeof base.code === 'object') {
                const existingCode = base.code;
                const patternCodeObj = patternCode;
                if (existingCode.coding && patternCodeObj.coding) {
                    // Build a set of existing coding keys (system|code pairs)
                    const existingCodingKeys = new Set();
                    for (const existing of existingCode.coding) {
                        const key = String(existing.system || '') + '|' + String(existing.code || '');
                        existingCodingKeys.add(key);
                    }
                    // Only ADD pattern codings that aren't already present (by system+code)
                    for (const patternCoding of patternCodeObj.coding) {
                        const key = String(patternCoding.system || '') + '|' + String(patternCoding.code || '');
                        if (!existingCodingKeys.has(key)) {
                            existingCode.coding.push(patternCoding);
                            existingCodingKeys.add(key);
                        }
                    }
                }
                else if (!existingCode.coding && patternCodeObj.coding) {
                    existingCode.coding = patternCodeObj.coding;
                }
            }
            else if (patternCode) {
                base.code = patternCode;
            }
            else if (!('code' in base)) {
                // Try to resolve from ValueSet binding first, fall back to hardcoded default
                const resolved = resolveBindingCode('code', 'http://loinc.org', '8867-4', 'Heart rate');
                base.code = resolved || { coding: [{ system: 'http://loinc.org', code: '8867-4', display: 'Heart rate' }], text: 'Heart rate' };
            }
            if (!('subject' in base))
                base.subject = { reference: 'Patient/' + randomId() };
            if (!('effectiveDateTime' in base))
                base.effectiveDateTime = new Date().toISOString();
            // Always use pattern if available for category, even if category already exists
            const patternCategory = getPatternValue('category');
            if (patternCategory) {
                base.category = [patternCategory];
            }
            else if (!('category' in base)) {
                const resolved = resolveBindingCode('category', 'http://terminology.hl7.org/CodeSystem/observation-category', 'vital-signs');
                base.category = [resolved || { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/observation-category', code: 'vital-signs' }] }];
            }
            // Observations MUST have value[x], dataAbsentReason, component, or hasMember
            const hasValue = Object.keys(base).some(k => k.startsWith('value'));
            const hasComponent = 'component' in base;
            const hasHasMember = 'hasMember' in base;
            const hasDataAbsentReason = 'dataAbsentReason' in base;
            if (!hasValue && !hasComponent && !hasHasMember && !hasDataAbsentReason) {
                // Check for patterns from the StructureDefinition for valueQuantity fields
                const codePattern = getPrimitivePattern('valueQuantity.code');
                const unitPattern = getPrimitivePattern('valueQuantity.unit');
                const systemPattern = getPrimitivePattern('valueQuantity.system');
                // Check if there are nested requirements for value[x] (indicates required binding)
                const valueReqs = getRefRequirements('value[x]');
                const codeRequired = valueReqs?.code;
                // Check if value[x] is constrained to specific types (e.g., only CodeableConcept)
                const valueTypeConstraint = fieldPatterns['_choiceType_value[x]'];
                const isCodeableConceptOnly = valueTypeConstraint && valueTypeConstraint.length === 1 && valueTypeConstraint[0] === 'CodeableConcept';
                if (isCodeableConceptOnly) {
                    // Profile constrains value[x] to only CodeableConcept - use valueCodeableConcept
                    // Check for a pattern from the profile, otherwise use data-absent-reason
                    const valuePattern = getPatternValue('valueCodeableConcept');
                    if (valuePattern) {
                        base.valueCodeableConcept = valuePattern;
                    }
                    else {
                        // Use a generic CodeableConcept that indicates no specific value is required
                        base.valueCodeableConcept = { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/data-absent-reason', code: 'unknown', display: 'Unknown' }], text: 'Unknown' };
                    }
                }
                else if (codeRequired && codePattern === undefined) {
                    // If code is required but we don't have a pattern, use dataAbsentReason instead
                    // This avoids required binding violations when we don't know the valid codes
                    base.dataAbsentReason = { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/data-absent-reason', code: 'unknown' }] };
                }
                else {
                    // Use patterns if available, otherwise use generic defaults
                    base.valueQuantity = {
                        value: 72,
                        unit: unitPattern !== undefined ? unitPattern : 'beats/minute',
                        system: systemPattern !== undefined ? systemPattern : 'http://unitsofmeasure.org',
                        code: codePattern !== undefined ? codePattern : '/min'
                    };
                }
            }
            // Apply nested primitive patterns to valueQuantity if present
            // These come from patternString/patternCode/patternUri on valueQuantity.unit, .code, .system
            if ('valueQuantity' in base && typeof base.valueQuantity === 'object' && base.valueQuantity !== null) {
                applyNestedPatterns('valueQuantity', base.valueQuantity);
            }
            // Ensure each component has a value or dataAbsentReason (vs-3 constraint)
            // This handles blood pressure and other vital signs with component slices
            if ('component' in base && Array.isArray(base.component)) {
                for (const comp of base.component) {
                    const hasCompValue = Object.keys(comp).some(k => k.startsWith('value'));
                    const hasCompDataAbsentReason = 'dataAbsentReason' in comp;
                    if (!hasCompValue && !hasCompDataAbsentReason) {
                        // Add a generic valueQuantity - for blood pressure this will be overwritten
                        // by profile-specific logic if needed
                        comp.valueQuantity = { value: 120, unit: 'mmHg', system: 'http://unitsofmeasure.org', code: 'mm[Hg]' };
                    }
                }
            }
        }
        // CarePlan
        if (/CarePlan/i.test(baseResource)) {
            if (!('status' in base))
                base.status = 'active';
            if (!('intent' in base))
                base.intent = 'order';
            if (!('subject' in base))
                base.subject = { reference: 'Patient/' + randomId() };
            // Always use pattern if available for category, even if category already exists
            const patternCategory = getPatternValue('category');
            if (patternCategory) {
                base.category = [patternCategory];
            }
            else if (!('category' in base)) {
                const resolved = resolveBindingCode('category', 'http://hl7.org/fhir/us/core/CodeSystem/careplan-category', 'assess-plan');
                base.category = [resolved || { coding: [{ system: 'http://hl7.org/fhir/us/core/CodeSystem/careplan-category', code: 'assess-plan' }] }];
            }
        }
        // Procedure
        if (/Procedure/i.test(baseResource)) {
            if (!('code' in base)) {
                const resolved = resolveBindingCode('code', 'http://snomed.info/sct', '71388002', 'Procedure');
                base.code = resolved || { coding: [{ system: 'http://snomed.info/sct', code: '71388002', display: 'Procedure' }], text: 'Example procedure' };
            }
            if (!('status' in base))
                base.status = 'completed';
            if (!('subject' in base))
                base.subject = { reference: 'Patient/' + randomId() };
            if (!('performedDateTime' in base))
                base.performedDateTime = new Date().toISOString();
            if (!('category' in base)) {
                const resolved = resolveBindingCode('category', 'http://snomed.info/sct', '387713003');
                base.category = resolved || { coding: [{ system: 'http://snomed.info/sct', code: '387713003' }] };
            }
        }
        // Encounter
        if (/Encounter/i.test(baseResource)) {
            // Force correct status - 'active' is NOT valid for Encounter.status
            base.status = 'finished';
            if (!('class' in base))
                base.class = { system: 'http://terminology.hl7.org/CodeSystem/v3-ActCode', code: 'IMP', display: 'inpatient encounter' };
            if (!('subject' in base))
                base.subject = { reference: 'Patient/' + randomId() };
            if (!('period' in base))
                base.period = { start: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(), end: new Date().toISOString() };
            if (!('type' in base)) {
                const resolved = resolveBindingCode('type', 'http://terminology.hl7.org/CodeSystem/v3-ActCode', 'IMP');
                base.type = [resolved || { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/v3-ActCode', code: 'IMP' }] }];
            }
            if (!('serviceProvider' in base))
                base.serviceProvider = { reference: 'Organization/' + randomId() };
        }
        // QuestionnaireResponse
        if (/QuestionnaireResponse/i.test(baseResource)) {
            // Force correct status - 'active' is NOT valid for QuestionnaireResponse.status
            base.status = 'completed';
            // questionnaire must be an absolute canonical URL, not a relative reference
            if (!('questionnaire' in base))
                base.questionnaire = 'http://example.org/Questionnaire/' + randomId();
            if (!('subject' in base))
                base.subject = { reference: 'Patient/' + randomId() };
            if (!('authored' in base))
                base.authored = new Date().toISOString();
            if (!('author' in base))
                base.author = { reference: 'Practitioner/' + randomId() };
            if (!('item' in base))
                base.item = [{ linkId: '1', text: 'Example question', answer: [{ valueString: 'Example answer' }] }];
        }
        // Account
        if (/Account/i.test(baseResource)) {
            if (!('status' in base))
                base.status = 'active';
            if (!('type' in base)) {
                const resolved = resolveBindingCode('type', 'http://terminology.hl7.org/CodeSystem/v3-ActCode', 'PBILLACCT');
                base.type = resolved || { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/v3-ActCode', code: 'PBILLACCT' }] };
            }
            if (!('identifier' in base))
                base.identifier = [{ system: 'urn:ietf:rfc:3986', value: 'urn:uuid:' + randomUUID() }];
            if (!('subject' in base))
                base.subject = [{ reference: 'Patient/' + randomId() }];
        }
        // Bundle
        if (/Bundle/i.test(baseResource)) {
            // Check for profile-specific type patterns (e.g., SMART user-access-brands-bundle requires 'collection')
            const typePattern = getPrimitivePattern('type');
            if (typePattern !== undefined) {
                base.type = typePattern;
            }
            else if (!('type' in base)) {
                base.type = 'document';
            }
            if (!('timestamp' in base))
                base.timestamp = new Date().toISOString();
            // Use proper UUIDs for identifier values (urn:uuid: requires valid UUID format)
            if (!('identifier' in base))
                base.identifier = { system: 'urn:ietf:rfc:3986', value: 'urn:uuid:' + randomUUID() };
            // Ensure meta.lastUpdated is present (required by SMART and other profiles)
            if (!('meta' in base))
                base.meta = { lastUpdated: new Date().toISOString() };
            else if (typeof base.meta === 'object' && base.meta !== null && !('lastUpdated' in base.meta)) {
                base.meta.lastUpdated = new Date().toISOString();
            }
            // Use proper UUIDs for fullUrl values
            if (!('entry' in base))
                base.entry = [{ fullUrl: 'urn:uuid:' + randomUUID(), resource: { resourceType: 'Composition', id: randomId(), status: 'final', type: { coding: [{ system: 'http://loinc.org', code: '60591-5' }] }, subject: { reference: 'Patient/' + randomId() }, date: new Date().toISOString(), author: [{ reference: 'Practitioner/' + randomId() }], title: 'Example Document', section: [{ title: 'Section', text: { status: 'generated', div: '<div xmlns="http://www.w3.org/1999/xhtml">Section content</div>' } }] } }];
            // Fix existing entry fullUrls to use proper UUIDs
            if (Array.isArray(base.entry)) {
                for (const entry of base.entry) {
                    if (entry.fullUrl && entry.fullUrl.startsWith('urn:uuid:id-')) {
                        entry.fullUrl = 'urn:uuid:' + randomUUID();
                    }
                }
            }
        }
        // Composition
        if (/Composition/i.test(baseResource)) {
            // Force correct status - 'active' is NOT valid for Composition.status
            base.status = 'final';
            // Use profile-specific type pattern if available, otherwise use default
            if (!('type' in base)) {
                const typePattern = getPatternValue('type');
                base.type = typePattern || { coding: [{ system: 'http://loinc.org', code: '60591-5', display: 'Patient summary Document' }] };
            }
            if (!('subject' in base))
                base.subject = { reference: 'Patient/' + randomId() };
            if (!('date' in base))
                base.date = new Date().toISOString();
            if (!('author' in base))
                base.author = [{ reference: 'Practitioner/' + randomId() }];
            if (!('title' in base))
                base.title = 'Patient Summary';
            // Section must have at least one element for many profiles
            // Add code to prevent unintended slice matching (e.g., originalRepresentation which has code 55108-5)
            if (!('section' in base) || (Array.isArray(base.section) && base.section.length === 0)) {
                base.section = [{
                        title: 'Section',
                        code: { coding: [{ system: 'http://loinc.org', code: '48765-2', display: 'Allergies and adverse reactions Document' }] },
                        text: { status: 'generated', div: '<div xmlns="http://www.w3.org/1999/xhtml">Section content</div>' }
                    }];
            }
            // EPR confidentiality handling removed - should be handled by pattern extraction
        }
        // Device
        if (/Device/i.test(baseResource)) {
            if (!('deviceName' in base))
                base.deviceName = [{ name: 'Example Device', type: 'user-friendly-name' }];
            if (!('type' in base)) {
                const resolved = resolveBindingCode('type', 'http://snomed.info/sct', '49062001', 'Device');
                base.type = resolved || { coding: [{ system: 'http://snomed.info/sct', code: '49062001', display: 'Device' }] };
            }
            if (!('status' in base))
                base.status = 'active';
            // Apply nested primitive patterns to manufacturer if present
            const manufacturerPattern = getPrimitivePattern('manufacturer');
            if (manufacturerPattern !== undefined) {
                base.manufacturer = manufacturerPattern;
            }
            // Apply nested primitive patterns to deviceName entries if present
            if ('deviceName' in base && Array.isArray(base.deviceName) && base.deviceName.length > 0) {
                const namePattern = getPrimitivePattern('deviceName.name');
                const typePattern = getPrimitivePattern('deviceName.type');
                for (const deviceNameEntry of base.deviceName) {
                    if (namePattern !== undefined)
                        deviceNameEntry.name = namePattern;
                    if (typePattern !== undefined)
                        deviceNameEntry.type = typePattern;
                }
            }
        }
        // ValueSet - url must be a valid absolute URI (HTTP URL or proper URN)
        if (/ValueSet/i.test(baseResource)) {
            if (!('status' in base))
                base.status = 'active';
            if (!('url' in base))
                base.url = 'http://example.org/fhir/ValueSet/' + randomId();
            // name must be machine-readable identifier (no spaces, starts with letter)
            if (!('name' in base))
                base.name = 'ExampleValueSet' + randomId().replace(/-/g, '');
            else if (typeof base.name === 'string' && /^[0-9a-f-]+$/i.test(base.name)) {
                // If name looks like a UUID/randomId, make it a valid identifier
                base.name = 'ValueSet' + base.name.replace(/-/g, '').substring(0, 10);
            }
            if (!('version' in base))
                base.version = '1.0.0';
            if (!('compose' in base))
                base.compose = { include: [{ system: 'http://loinc.org', concept: [{ code: '1234-5', display: 'Example LOINC' }] }] };
            // Handle useContext when pattern for 'code' is present (ISiK ValueSet)
            // The pattern key 'code' refers to useContext.code
            if (fieldPatterns && 'code' in fieldPatterns && !('useContext' in base)) {
                const codePattern = fieldPatterns['code'];
                base.useContext = [{
                        code: {
                            system: codePattern.system || 'http://terminology.hl7.org/CodeSystem/usage-context-type',
                            code: codePattern.code || 'focus'
                        },
                        valueCodeableConcept: {
                            coding: [{ system: 'http://hl7.org/fhir/resource-types', code: 'ValueSet' }]
                        }
                    }];
            }
        }
        // CodeSystem - url must be a valid absolute URI (HTTP URL or proper URN)
        if (/CodeSystem/i.test(baseResource)) {
            if (!('status' in base))
                base.status = 'active';
            if (!('content' in base))
                base.content = 'complete';
            if (!('url' in base))
                base.url = 'http://example.org/fhir/CodeSystem/' + randomId();
            if (!('name' in base))
                base.name = 'ExampleCodeSystem';
            if (!('version' in base))
                base.version = '1.0.0';
            if (!('concept' in base))
                base.concept = [{ code: 'example', display: 'Example Code' }];
        }
        // RelatedPerson
        if (/RelatedPerson/i.test(baseResource)) {
            if (!('patient' in base))
                base.patient = { reference: 'Patient/' + randomId() };
            if (!('identifier' in base))
                base.identifier = [{ system: 'urn:ietf:rfc:3986', value: 'urn:uuid:' + randomUUID() }];
            if (!('name' in base))
                base.name = [{ family: randomId(), given: [randomId()] }];
            if (!('relationship' in base)) {
                const resolved = resolveBindingCode('relationship', 'http://terminology.hl7.org/CodeSystem/v3-RoleCode', 'FTH', 'father');
                base.relationship = [resolved || { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/v3-RoleCode', code: 'FTH', display: 'father' }] }];
            }
            if (!('address' in base))
                base.address = [{ city: 'Example City', postalCode: '12345', country: 'DE' }];
        }
        // DocumentReference
        if (/DocumentReference/i.test(baseResource)) {
            // Force correct status - 'active' is NOT valid for DocumentReference.status
            base.status = 'current';
            if (!('type' in base)) {
                const resolved = resolveBindingCode('type', 'http://loinc.org', '34133-9');
                base.type = resolved || { coding: [{ system: 'http://loinc.org', code: '34133-9' }] };
            }
            // Always use pattern if available for category, even if category already exists
            const patternCategory = getPatternValue('category');
            if (patternCategory) {
                base.category = [patternCategory];
            }
            else if (!('category' in base)) {
                base.category = [{ coding: [{ system: 'http://hl7.org/fhir/us/core/CodeSystem/us-core-documentreference-category', code: 'clinical-note' }] }];
            }
            if (!('subject' in base))
                base.subject = { reference: 'Patient/' + randomId() };
            if (!('content' in base)) {
                base.content = [{ attachment: { contentType: 'application/pdf', data: 'ZXhhbXBsZQ==', url: 'urn:uuid:' + randomUUID() } }];
            }
            else if (Array.isArray(base.content) && base.content.length > 0) {
                for (const c of base.content) {
                    if (c.attachment) {
                        if (!c.attachment.data)
                            c.attachment.data = 'ZXhhbXBsZQ==';
                        if (!c.attachment.url)
                            c.attachment.url = 'urn:uuid:' + randomUUID();
                        if (!c.attachment.contentType)
                            c.attachment.contentType = 'application/pdf';
                    }
                    else {
                        c.attachment = { contentType: 'application/pdf', data: 'ZXhhbXBsZQ==', url: 'urn:uuid:' + randomUUID() };
                    }
                }
            }
            // EPR format handling removed - should be handled by pattern extraction
        }
        // Specimen
        if (/Specimen/i.test(baseResource)) {
            // IPS Specimen requires type
            if (!isForbidden('type') && !('type' in base)) {
                const resolved = resolveBindingCode('type', 'http://snomed.info/sct', '119297000', 'Blood specimen');
                base.type = resolved || { coding: [{ system: 'http://snomed.info/sct', code: '119297000', display: 'Blood specimen' }] };
            }
            if (!isForbidden('subject') && !('subject' in base)) {
                base.subject = { reference: 'Patient/' + randomId() };
            }
        }
        // Binary
        if (/Binary/i.test(baseResource)) {
            if (!('contentType' in base))
                base.contentType = 'application/pdf';
            if (!('data' in base))
                base.data = 'SGVsbG8gV29ybGQ=';
        }
        // Coverage
        if (/Coverage/i.test(baseResource)) {
            if (!isForbidden('status') && !('status' in base))
                base.status = 'active';
            if (!isForbidden('type') && !('type' in base)) {
                const resolved = resolveBindingCode('type', 'http://terminology.hl7.org/CodeSystem/v3-ActCode', 'EHCPOL', 'extended healthcare');
                base.type = resolved || { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/v3-ActCode', code: 'EHCPOL', display: 'extended healthcare' }] };
            }
            if (!isForbidden('subscriberId') && !('subscriberId' in base))
                base.subscriberId = randomId();
            if (!isForbidden('beneficiary') && !('beneficiary' in base))
                base.beneficiary = { reference: 'Patient/' + randomId() };
            if (!isForbidden('payor') && !('payor' in base))
                base.payor = [{ reference: 'Organization/' + randomId() }];
        }
        // AllergyIntolerance - clinicalStatus required when verificationStatus != entered-in-error
        if (/AllergyIntolerance/i.test(baseResource)) {
            if (!('patient' in base))
                base.patient = { reference: 'Patient/' + randomId() };
            if (!('code' in base)) {
                const resolved = resolveBindingCode('code', 'http://snomed.info/sct', '387517004', 'Paracetamol');
                base.code = resolved || { coding: [{ system: 'http://snomed.info/sct', code: '387517004', display: 'Paracetamol' }] };
            }
            // Always include clinicalStatus to satisfy ait-1 constraint
            if (!('clinicalStatus' in base)) {
                const resolved = resolveBindingCode('clinicalStatus', 'http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical', 'active');
                base.clinicalStatus = resolved || { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical', code: 'active' }] };
            }
            if (!('verificationStatus' in base)) {
                const resolved = resolveBindingCode('verificationStatus', 'http://terminology.hl7.org/CodeSystem/allergyintolerance-verification', 'confirmed');
                base.verificationStatus = resolved || { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/allergyintolerance-verification', code: 'confirmed' }] };
            }
        }
        // MedicationRequest - requester required when intent='order'
        if (/MedicationRequest/i.test(baseResource)) {
            if (!('status' in base))
                base.status = 'active';
            if (!('intent' in base))
                base.intent = 'order';
            if (!('medicationCodeableConcept' in base) && !('medicationReference' in base)) {
                const resolved = resolveBindingCode('medicationCodeableConcept', 'http://www.nlm.nih.gov/research/umls/rxnorm', '1049502', 'Amoxicillin 250mg');
                base.medicationCodeableConcept = resolved || { coding: [{ system: 'http://www.nlm.nih.gov/research/umls/rxnorm', code: '1049502', display: 'Amoxicillin 250mg' }] };
            }
            if (!('subject' in base))
                base.subject = { reference: 'Patient/' + randomId() };
            // requester required when intent='order' (us-core-21 constraint)
            if (!('requester' in base))
                base.requester = { reference: 'Practitioner/' + randomId() };
        }
        // MedicationDispense
        if (/MedicationDispense/i.test(baseResource)) {
            if (!('status' in base))
                base.status = 'completed';
            if (!('medicationCodeableConcept' in base) && !('medicationReference' in base)) {
                const resolved = resolveBindingCode('medicationCodeableConcept', 'http://www.nlm.nih.gov/research/umls/rxnorm', '1049502', 'Amoxicillin 250mg');
                base.medicationCodeableConcept = resolved || { coding: [{ system: 'http://www.nlm.nih.gov/research/umls/rxnorm', code: '1049502', display: 'Amoxicillin 250mg' }] };
            }
            if (!('subject' in base))
                base.subject = { reference: 'Patient/' + randomId() };
            if (!('performer' in base))
                base.performer = [{ actor: { reference: 'Practitioner/' + randomId() } }];
            // us-core-20: whenHandedOver SHALL be present if status is 'completed'
            if (base.status === 'completed' && !('whenHandedOver' in base)) {
                base.whenHandedOver = new Date().toISOString();
            }
        }
        // PractitionerRole - needs practitioner/organization/location/healthcareService AND telecom/endpoint
        if (/PractitionerRole/i.test(baseResource)) {
            // Remove any Patient-like fields that don't belong
            delete base.name;
            delete base.gender;
            delete base.birthDate;
            delete base.address;
            // Required fields for us-core-13: practitioner, organization, location, or healthcareService
            if (!('practitioner' in base))
                base.practitioner = { reference: 'Practitioner/' + randomId() };
            if (!('organization' in base))
                base.organization = { reference: 'Organization/' + randomId() };
            // Required for pd-1: telecom or endpoint
            if (!('telecom' in base) && !('endpoint' in base)) {
                base.telecom = [{ system: 'phone', value: '+1-555-555-5555', use: 'work' }];
            }
            if (!('code' in base)) {
                const resolved = resolveBindingCode('code', 'http://terminology.hl7.org/CodeSystem/practitioner-role', 'doctor');
                base.code = [resolved || { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/practitioner-role', code: 'doctor' }] }];
            }
        }
        // DiagnosticReport - needs effective[x]
        if (/DiagnosticReport/i.test(baseResource)) {
            if (!('status' in base))
                base.status = 'final';
            if (!('code' in base)) {
                const resolved = resolveBindingCode('code', 'http://loinc.org', '58410-2', 'Complete blood count');
                base.code = resolved || { coding: [{ system: 'http://loinc.org', code: '58410-2', display: 'Complete blood count' }] };
            }
            if (!('subject' in base))
                base.subject = { reference: 'Patient/' + randomId() };
            if (!('effectiveDateTime' in base) && !('effectivePeriod' in base)) {
                base.effectiveDateTime = new Date().toISOString();
            }
            if (!('issued' in base))
                base.issued = new Date().toISOString();
            // Category for laboratory reports
            if (profileUrl.includes('laboratory')) {
                if (!('category' in base)) {
                    const resolved = resolveBindingCode('category', 'http://terminology.hl7.org/CodeSystem/v2-0074', 'LAB');
                    base.category = [resolved || { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/v2-0074', code: 'LAB' }] }];
                }
            }
            // presentedForm for note-exchange
            if (profileUrl.includes('note-exchange')) {
                if (!('presentedForm' in base))
                    base.presentedForm = [{ contentType: 'application/pdf', data: 'ZXhhbXBsZQ==' }];
            }
        }
        // Generic narrative for DomainResource derivatives
        // Note: Bundle and Binary do NOT support text/narrative elements
        if (/DomainResource|Patient|Account|Composition|CodeSystem|Condition|Encounter|Practitioner|Procedure|ValueSet|RelatedPerson|DocumentReference|Coverage/.test(baseResource) && !/Bundle|Binary/.test(baseResource)) {
            if (!('text' in base)) {
                // Check if there's a pattern constraint for text.status
                const textStatusPattern = getPrimitivePattern('text.status');
                const status = textStatusPattern !== undefined ? textStatusPattern : 'generated';
                base.text = { status: status, div: '<div xmlns="http://www.w3.org/1999/xhtml">Generated</div>' };
            }
            else if (typeof base.text === 'object' && base.text !== null) {
                // Apply text.status pattern to existing text object
                const textStatusPattern = getPrimitivePattern('text.status');
                if (textStatusPattern !== undefined) {
                    base.text.status = textStatusPattern;
                }
            }
        }
        // Extension value fallback
        if (/Extension/.test(baseResource)) {
            const hasValue = Object.keys(base).some(k => k.startsWith('value'));
            if (!hasValue)
                base['valueString'] = 'value';
            if (!('url' in base))
                base.url = profileUrl || 'urn:uuid:extension';
        }
        // Generic Reference enrichment: apply nested requirements to all Reference fields
        // This handles profile-level constraints that require identifier/display on References
        // like Encounter.serviceProvider.identifier and Encounter.serviceProvider.display
        if (fieldPatterns) {
            for (const key of Object.keys(fieldPatterns)) {
                if (key.startsWith('_refReq_')) {
                    const refFieldName = key.slice('_refReq_'.length);
                    // Check if the field exists in base (could be a Reference or array of References)
                    const fieldValue = base[refFieldName];
                    const reqs = fieldPatterns[key];
                    // Handle primitive element extensions (e.g., confidentiality with _confidentiality.extension)
                    // FHIR uses _<fieldName> prefix for extensions on primitive elements
                    const extReq = reqs['extension'];
                    if (extReq && (typeof fieldValue === 'string' || typeof fieldValue === 'undefined')) {
                        // This is a primitive field that needs an extension on the underscore-prefixed element
                        // First ensure the primitive field has a value
                        if (!fieldValue) {
                            // Generate a default value for common primitive fields
                            if (refFieldName === 'confidentiality') {
                                base[refFieldName] = 'N'; // Normal confidentiality
                            }
                        }
                        // Add the _<fieldName> with extension
                        const underscoreFieldName = '_' + refFieldName;
                        if (!base[underscoreFieldName]) {
                            const extProfile = typeof extReq === 'object' && extReq.profile
                                ? String(extReq.profile)
                                : undefined;
                            // Create extension with the profile URL if available
                            const ext = { url: extProfile || 'http://example.org/extension' };
                            // For known CH Core extension profiles, add a valueCodeableConcept with sample data
                            if (extProfile && extProfile.includes('ch-ext-epr-confidentialitycode')) {
                                ext.valueCodeableConcept = {
                                    coding: [{
                                            system: 'http://snomed.info/sct',
                                            code: '17621005',
                                            display: 'Normal'
                                        }]
                                };
                            }
                            else {
                                // Generic fallback: add a string value
                                ext.valueString = 'Example extension value';
                            }
                            base[underscoreFieldName] = {
                                extension: [ext]
                            };
                        }
                        continue; // Skip the rest of the _refReq processing for this field
                    }
                    if (fieldValue) {
                        // Determine target resource type from the reference
                        let targetType = 'Resource';
                        if (Array.isArray(fieldValue)) {
                            // Array of References or CodeableConcepts
                            for (const ref of fieldValue) {
                                if (ref && typeof ref === 'object') {
                                    const refObj = ref;
                                    if (typeof refObj.reference === 'string') {
                                        const match = refObj.reference.match(/^([A-Za-z]+)\//);
                                        if (match)
                                            targetType = match[1];
                                    }
                                    // Add required nested properties
                                    if ((reqs['identifier'] || reqs['identifier.system'] || reqs['identifier.value']) && !('identifier' in refObj)) {
                                        refObj.identifier = { system: 'urn:ietf:rfc:3986', value: 'urn:uuid:' + randomUUID() };
                                    }
                                    if (reqs['display'] && !('display' in refObj)) {
                                        refObj.display = 'Example ' + targetType;
                                    }
                                    // Handle CodeableConcept.text requirement
                                    if (reqs['text'] && !('text' in refObj)) {
                                        if ('coding' in refObj && Array.isArray(refObj.coding)) {
                                            const firstCoding = refObj.coding[0];
                                            const displayText = (firstCoding && firstCoding.display) || (firstCoding && firstCoding.code) || 'Example text';
                                            refObj.text = String(displayText);
                                        }
                                    }
                                }
                            }
                        }
                        else if (typeof fieldValue === 'object') {
                            // Single Reference
                            const refObj = fieldValue;
                            if (typeof refObj.reference === 'string') {
                                const match = refObj.reference.match(/^([A-Za-z]+)\//);
                                if (match)
                                    targetType = match[1];
                            }
                            // Add required nested properties
                            if ((reqs['identifier'] || reqs['identifier.system'] || reqs['identifier.value']) && !('identifier' in refObj)) {
                                refObj.identifier = { system: 'urn:ietf:rfc:3986', value: 'urn:uuid:' + randomUUID() };
                            }
                            if (reqs['display'] && !('display' in refObj)) {
                                refObj.display = 'Example ' + targetType;
                            }
                            // Handle CodeableConcept nested requirements (e.g., type.text for ISiKBerichtSubSysteme)
                            // CodeableConcept has: coding (array), text (string)
                            if (reqs['text'] && !('text' in refObj)) {
                                // Check if this looks like a CodeableConcept (has coding array)
                                if ('coding' in refObj && Array.isArray(refObj.coding)) {
                                    // Get display from first coding if available
                                    const firstCoding = refObj.coding[0];
                                    const displayText = firstCoding?.display || firstCoding?.code || 'Example text';
                                    refObj.text = String(displayText);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    catch { /* enrichment is best-effort */ }
}
