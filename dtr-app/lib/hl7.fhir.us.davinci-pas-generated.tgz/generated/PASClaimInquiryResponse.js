import fhirpath from "fhirpath";
import fhirpath_r4_model from "fhirpath/fhir-context/r4/index.js";
export async function validatePASClaimInquiryResponse(resource) {
    const errors = [];
    const warnings = [];
    const result0 = await Promise.resolve(fhirpath.evaluate(resource, "ClaimResponse.all(contained.contained.empty())", { resource }, fhirpath_r4_model));
    if (!result0.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL NOT contain nested Resources");
    }
    const result1 = await Promise.resolve(fhirpath.evaluate(resource, "ClaimResponse.all(contained.meta.versionId.empty() and contained.meta.lastUpdated.empty())", { resource }, fhirpath_r4_model));
    if (!result1.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a meta.versionId or a meta.lastUpdated");
    }
    const result2 = await Promise.resolve(fhirpath.evaluate(resource, "ClaimResponse.all(contained.meta.security.empty())", { resource }, fhirpath_r4_model));
    if (!result2.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a security label");
    }
    const result3 = await Promise.resolve(fhirpath.evaluate(resource, "ClaimResponse.all(text.`div`.exists())", { resource }, fhirpath_r4_model));
    if (!result3.every(Boolean)) {
        warnings.push("Constraint violation: A resource should have narrative for robust management");
    }
    const result4 = await Promise.resolve(fhirpath.evaluate(resource, "meta.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result4.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result5 = await Promise.resolve(fhirpath.evaluate(resource, "implicitRules.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result5.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result6 = await Promise.resolve(fhirpath.evaluate(resource, "language.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result6.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result7 = await Promise.resolve(fhirpath.evaluate(resource, "text.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result7.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result8 = await Promise.resolve(fhirpath.evaluate(resource, "extension.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result8.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result9 = await Promise.resolve(fhirpath.evaluate(resource, "modifierExtension.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result9.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result10 = await Promise.resolve(fhirpath.evaluate(resource, "identifier.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result10.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result11 = await Promise.resolve(fhirpath.evaluate(resource, "status.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result11.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result12 = await Promise.resolve(fhirpath.evaluate(resource, "type.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result12.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result13 = await Promise.resolve(fhirpath.evaluate(resource, "subType.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result13.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result14 = await Promise.resolve(fhirpath.evaluate(resource, "use.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result14.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result15 = await Promise.resolve(fhirpath.evaluate(resource, "patient.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result15.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result16 = await Promise.resolve(fhirpath.evaluate(resource, "created.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result16.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result17 = await Promise.resolve(fhirpath.evaluate(resource, "insurer.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result17.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result18 = await Promise.resolve(fhirpath.evaluate(resource, "requestor.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result18.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result19 = await Promise.resolve(fhirpath.evaluate(resource, "request.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result19.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result20 = await Promise.resolve(fhirpath.evaluate(resource, "outcome.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result20.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result21 = await Promise.resolve(fhirpath.evaluate(resource, "disposition.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result21.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result22 = await Promise.resolve(fhirpath.evaluate(resource, "preAuthRef.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result22.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result23 = await Promise.resolve(fhirpath.evaluate(resource, "preAuthPeriod.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result23.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result24 = await Promise.resolve(fhirpath.evaluate(resource, "payeeType.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result24.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result25 = await Promise.resolve(fhirpath.evaluate(resource, "item.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result25.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result26 = await Promise.resolve(fhirpath.evaluate(resource, "addItem.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result26.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result27 = await Promise.resolve(fhirpath.evaluate(resource, "adjudication.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result27.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result28 = await Promise.resolve(fhirpath.evaluate(resource, "total.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result28.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result29 = await Promise.resolve(fhirpath.evaluate(resource, "payment.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result29.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result30 = await Promise.resolve(fhirpath.evaluate(resource, "fundsReserve.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result30.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result31 = await Promise.resolve(fhirpath.evaluate(resource, "formCode.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result31.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result32 = await Promise.resolve(fhirpath.evaluate(resource, "form.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result32.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result33 = await Promise.resolve(fhirpath.evaluate(resource, "processNote.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result33.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result34 = await Promise.resolve(fhirpath.evaluate(resource, "communicationRequest.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result34.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result35 = await Promise.resolve(fhirpath.evaluate(resource, "insurance.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result35.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result36 = await Promise.resolve(fhirpath.evaluate(resource, "error.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result36.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result37 = await Promise.resolve(fhirpath.evaluate(resource, "DomainResource.all(contained.contained.empty())", { resource }, fhirpath_r4_model));
    if (!result37.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL NOT contain nested Resources");
    }
    const result38 = await Promise.resolve(fhirpath.evaluate(resource, "DomainResource.all(contained.meta.versionId.empty() and contained.meta.lastUpdated.empty())", { resource }, fhirpath_r4_model));
    if (!result38.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a meta.versionId or a meta.lastUpdated");
    }
    const result39 = await Promise.resolve(fhirpath.evaluate(resource, "DomainResource.all(contained.meta.security.empty())", { resource }, fhirpath_r4_model));
    if (!result39.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a security label");
    }
    const result40 = await Promise.resolve(fhirpath.evaluate(resource, "DomainResource.all(text.`div`.exists())", { resource }, fhirpath_r4_model));
    if (!result40.every(Boolean)) {
        warnings.push("Constraint violation: A resource should have narrative for robust management");
    }
    const result41 = await Promise.resolve(fhirpath.evaluate(resource, "status.exists()", { resource }, fhirpath_r4_model));
    if (!result41.every(Boolean)) {
        errors.push("Constraint violation: status must be present");
    }
    const result42 = await Promise.resolve(fhirpath.evaluate(resource, "type.exists()", { resource }, fhirpath_r4_model));
    if (!result42.every(Boolean)) {
        errors.push("Constraint violation: type must be present");
    }
    const result43 = await Promise.resolve(fhirpath.evaluate(resource, "use.exists()", { resource }, fhirpath_r4_model));
    if (!result43.every(Boolean)) {
        errors.push("Constraint violation: use must be present");
    }
    const result44 = await Promise.resolve(fhirpath.evaluate(resource, "patient.exists()", { resource }, fhirpath_r4_model));
    if (!result44.every(Boolean)) {
        errors.push("Constraint violation: patient must be present");
    }
    const result45 = await Promise.resolve(fhirpath.evaluate(resource, "created.exists()", { resource }, fhirpath_r4_model));
    if (!result45.every(Boolean)) {
        errors.push("Constraint violation: created must be present");
    }
    const result46 = await Promise.resolve(fhirpath.evaluate(resource, "insurer.exists()", { resource }, fhirpath_r4_model));
    if (!result46.every(Boolean)) {
        errors.push("Constraint violation: insurer must be present");
    }
    const result47 = await Promise.resolve(fhirpath.evaluate(resource, "outcome.exists()", { resource }, fhirpath_r4_model));
    if (!result47.every(Boolean)) {
        errors.push("Constraint violation: outcome must be present");
    }
    const result48 = await Promise.resolve(fhirpath.evaluate(resource, "item.extension.count() <= 1", { resource }, fhirpath_r4_model));
    if (!result48.every(Boolean)) {
        errors.push("Constraint violation: item.extension must contain at most one element");
    }
    const result49 = await Promise.resolve(fhirpath.evaluate(resource, "item.adjudication.extension.count() <= 1", { resource }, fhirpath_r4_model));
    if (!result49.every(Boolean)) {
        errors.push("Constraint violation: item.adjudication.extension must contain at most one element");
    }
    const result50 = await Promise.resolve(fhirpath.evaluate(resource, "error.extension.count() <= 1", { resource }, fhirpath_r4_model));
    if (!result50.every(Boolean)) {
        errors.push("Constraint violation: error.extension must contain at most one element");
    }
    // Fixed value constraint for status
    if (resource.status !== undefined && resource.status !== "active") {
        errors.push("status must have the fixed value 'active'");
    }
    // Fixed value constraint for use
    if (resource.use !== undefined && resource.use !== "preauthorization") {
        errors.push("use must have the fixed value 'preauthorization'");
    }
    return { errors, warnings };
}
