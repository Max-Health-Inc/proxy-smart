import { validatePASMedicationRequest } from "./PASMedicationRequest.js";
// Only import helpers actually referenced below (dynamic based on required fields)
import { randomId, setRandomSeed, enrichResource, randomDate, skeletonReference } from "./RandomSupport.js";
function ensureProfile(res, profile) {
    if (!res.meta) {
        res.meta = { profile: [profile] };
        return;
    }
    if (!res.meta.profile) {
        res.meta.profile = [profile];
        return;
    }
    if (!res.meta.profile.includes(profile)) {
        res.meta.profile = [...res.meta.profile, profile];
    }
}
// Internal helper (emitted per class file) to clone without resorting to 'any'.
function safeClone(value) {
    // Use native structuredClone if present; otherwise fallback to JSON round-trip.
    // We intentionally avoid casting through any to satisfy no-explicit-any lint rule.
    const g = globalThis;
    // Narrow globalThis to an object potentially containing structuredClone.
    if (typeof g.structuredClone === 'function') {
        return g.structuredClone(value);
    }
    return JSON.parse(JSON.stringify(value)); // best-effort deep clone
}
export class PASMedicationRequestClass {
    constructor(resource) {
        this.resource = resource;
        ensureProfile(this.resource, 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-medicationrequest');
    }
    /** Validate current resource instance. */
    async validate() {
        return validatePASMedicationRequest(this.resource);
    }
    getResource() {
        return this.resource;
    }
    setResource(resource) {
        this.resource = resource;
        ensureProfile(this.resource, 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-medicationrequest');
    }
    /**
     * Returns a plain JSON clone of the underlying resource ONLY if the last validation succeeded with zero errors.
     * Call validate() first; otherwise this method throws to prevent accidental use of invalid / unchecked data.
     */
    async toJSON() {
        return safeClone(this.resource);
    }
    /**
     * Create an empty instance for parity testing: for true FHIR resources, includes only resourceType; for datatypes, returns an empty object.
     * Note: meta.profile (when applicable) will be ensured by the constructor when wrapping this resource.
     */
    static empty(overrides = {}) {
        // For Resource profiles, include only resourceType. For Extension profiles, include url so the instance is minimally meaningful.
        const base = {
            resourceType: 'MedicationRequest',
        };
        return { ...base, ...overrides };
    }
    /**
     * Create a minimal randomized instance of PASMedicationRequest.
     * Populates id, resourceType (if applicable) and primitive required (min>0) top-level fields with placeholders.
     */
    static random(overrides = {}, opts) {
        if (opts?.seed !== undefined) {
            // Direct call (no dynamic require) to ensure deterministic seeding works under ESM.
            setRandomSeed(opts.seed);
        }
        // Start with a Partial to avoid unsafe casting errors; we'll assert at the end.
        const base = { resourceType: 'MedicationRequest', id: randomId(), status: 'active', intent: "order", medicationCodeableConcept: { coding: [{ system: "http://www.nlm.nih.gov/research/umls/rxnorm", code: "313782" }] }, subject: skeletonReference(), authoredOn: randomDate(), requester: skeletonReference(), };
        // Always include meta.profile with this profile's canonical URL if available & only for resource profiles
        ensureProfile(base, 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-medicationrequest');
        // Enrich the base resource with common fields using centralized enrichment logic
        enrichResource(base, 'MedicationRequest', 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-medicationrequest', PASMedicationRequestClass._fieldPatterns, PASMedicationRequestClass._forbiddenFields, PASMedicationRequestClass.valueSetBindings, PASMedicationRequestClass._codeResolver);
        // Cast through unknown to acknowledge dynamic enrichment
        return { ...base, ...overrides };
    }
    /** Convenience: returns a class instance wrapping a randomized resource. */
    static randomClass(overrides = {}, opts) {
        return new PASMedicationRequestClass(this.random(overrides, opts));
    }
}
/** Pattern constraints for profile fields (used by random() generator) */
PASMedicationRequestClass._fieldPatterns = {
    "intent": "order",
    "_refReq_substitution": {
        "allowedBoolean": true
    },
    "_choiceType_reported[x]": [
        "boolean",
        "Reference"
    ],
    "_choiceType_medication[x]": [
        "CodeableConcept",
        "Reference"
    ]
};
/** Fields that are forbidden (max=0) in this profile - must not be generated */
PASMedicationRequestClass._forbiddenFields = [];
/** ValueSet bindings for coded fields - maps field name to ValueSet URL */
PASMedicationRequestClass.valueSetBindings = {
    "language": "http://hl7.org/fhir/ValueSet/languages",
    "status": "http://hl7.org/fhir/ValueSet/medicationrequest-status",
    "statusReason": "http://hl7.org/fhir/ValueSet/medicationrequest-status-reason",
    "intent": "http://hl7.org/fhir/ValueSet/medicationrequest-intent",
    "category": "http://hl7.org/fhir/ValueSet/medicationrequest-category",
    "priority": "http://hl7.org/fhir/ValueSet/request-priority|4.0.1",
    "medication[x]": "http://hl7.org/fhir/us/core/ValueSet/us-core-medication-codes",
    "performerType": "http://hl7.org/fhir/ValueSet/performer-role",
    "reasonCode": "http://hl7.org/fhir/ValueSet/condition-code",
    "courseOfTherapyType": "http://hl7.org/fhir/ValueSet/medicationrequest-course-of-therapy",
    "dosageInstruction.additionalInstruction": "http://hl7.org/fhir/ValueSet/additional-instruction-codes",
    "dosageInstruction.asNeeded[x]": "http://hl7.org/fhir/ValueSet/medication-as-needed-reason",
    "dosageInstruction.site": "http://hl7.org/fhir/ValueSet/approach-site-codes",
    "dosageInstruction.route": "http://hl7.org/fhir/ValueSet/route-codes",
    "dosageInstruction.method": "http://hl7.org/fhir/ValueSet/administration-method-codes",
    "dosageInstruction.doseAndRate.type": "http://hl7.org/fhir/ValueSet/dose-rate-type",
    "substitution.allowed[x]": "http://terminology.hl7.org/ValueSet/v3-ActSubstanceAdminSubstitutionCode",
    "substitution.reason": "http://terminology.hl7.org/ValueSet/v3-SubstanceAdminSubstitutionReason"
};
/** Code resolver for ValueSet bindings - returns a random valid code from a ValueSet by URL */
PASMedicationRequestClass._codeResolver = (() => {
    // Try to dynamically import the ValueSetRegistry - it may not exist if no ValueSets were generated
    try {
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        const registry = require('./valuesets/index.js');
        if (registry && typeof registry.getRandomConceptByUrl === 'function') {
            return registry.getRandomConceptByUrl;
        }
    }
    catch { /* ValueSetRegistry not available */ }
    return undefined;
})();
