import { Extension } from "fhir/r4";
export interface InfoChanged extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-infoChanged";
}
export declare function validateInfoChanged(resource: InfoChanged): Promise<{
    errors: string[];
    warnings: string[];
}>;
