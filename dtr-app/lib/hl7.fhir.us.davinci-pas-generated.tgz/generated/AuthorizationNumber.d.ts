import { Extension } from "fhir/r4";
export interface AuthorizationNumber extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-authorizationNumber";
}
export declare function validateAuthorizationNumber(resource: AuthorizationNumber): Promise<{
    errors: string[];
    warnings: string[];
}>;
