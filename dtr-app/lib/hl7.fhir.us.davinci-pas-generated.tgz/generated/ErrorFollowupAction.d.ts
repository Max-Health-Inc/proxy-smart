import { Extension } from "fhir/r4";
export interface ErrorFollowupAction extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-errorFollowupAction";
}
export declare function validateErrorFollowupAction(resource: ErrorFollowupAction): Promise<{
    errors: string[];
    warnings: string[];
}>;
