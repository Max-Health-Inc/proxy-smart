import { Extension } from "fhir/r4";
export interface CertificationType extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-certificationType";
}
export declare function validateCertificationType(resource: CertificationType): Promise<{
    errors: string[];
    warnings: string[];
}>;
