import { Extension } from "fhir/r4";
export interface NursingHomeLevelOfCare extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-nursingHomeLevelOfCare";
}
export declare function validateNursingHomeLevelOfCare(resource: NursingHomeLevelOfCare): Promise<{
    errors: string[];
    warnings: string[];
}>;
