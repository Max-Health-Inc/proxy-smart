import { validatePASClaimInquiryResponse } from "./PASClaimInquiryResponse.js";
// Only import helpers actually referenced below (dynamic based on required fields)
import { randomId, setRandomSeed, enrichResource, randomDate, skeletonCodeableConcept, skeletonReference } from "./RandomSupport.js";
// Helper emitted only when meta.profile enforcement is applicable (resource profiles)
// Internal helper (emitted per class file) to clone without resorting to 'any'.
function safeClone(value) {
    // Use native structuredClone if present; otherwise fallback to JSON round-trip.
    // We intentionally avoid casting through any to satisfy no-explicit-any lint rule.
    const g = globalThis;
    // Narrow globalThis to an object potentially containing structuredClone.
    if (typeof g.structuredClone === 'function') {
        return g.structuredClone(value);
    }
    return JSON.parse(JSON.stringify(value)); // best-effort deep clone
}
export class PASClaimInquiryResponseClass {
    constructor(resource) {
        this.resource = resource;
    }
    /** Validate current resource instance. */
    async validate() {
        return validatePASClaimInquiryResponse(this.resource);
    }
    getResource() {
        return this.resource;
    }
    setResource(resource) {
        this.resource = resource;
    }
    /**
     * Returns a plain JSON clone of the underlying resource ONLY if the last validation succeeded with zero errors.
     * Call validate() first; otherwise this method throws to prevent accidental use of invalid / unchecked data.
     */
    async toJSON() {
        return safeClone(this.resource);
    }
    /**
     * Create an empty instance for parity testing: for true FHIR resources, includes only resourceType; for datatypes, returns an empty object.
     * Note: meta.profile (when applicable) will be ensured by the constructor when wrapping this resource.
     */
    static empty(overrides = {}) {
        // For Resource profiles, include only resourceType. For Extension profiles, include url so the instance is minimally meaningful.
        const base = {};
        return { ...base, ...overrides };
    }
    /**
     * Create a minimal randomized instance of PASClaimInquiryResponse.
     * Populates id, resourceType (if applicable) and primitive required (min>0) top-level fields with placeholders.
     */
    static random(overrides = {}, opts) {
        if (opts?.seed !== undefined) {
            // Direct call (no dynamic require) to ensure deterministic seeding works under ESM.
            setRandomSeed(opts.seed);
        }
        // Start with a Partial to avoid unsafe casting errors; we'll assert at the end.
        const base = { id: randomId(), status: "active", type: skeletonCodeableConcept(), use: "preauthorization", patient: skeletonReference(), created: randomDate(), insurer: skeletonReference(), outcome: 'unknown', };
        // Always include meta.profile with this profile's canonical URL if available & only for resource profiles
        // (no profileUrl provided or profile targets a datatype – meta.profile not applicable)
        // Enrich the base resource with common fields using centralized enrichment logic
        enrichResource(base, 'ClaimResponse', 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-claiminquiryresponse', PASClaimInquiryResponseClass._fieldPatterns, PASClaimInquiryResponseClass._forbiddenFields, PASClaimInquiryResponseClass.valueSetBindings, PASClaimInquiryResponseClass._codeResolver);
        // Cast through unknown to acknowledge dynamic enrichment
        return { ...base, ...overrides };
    }
    /** Convenience: returns a class instance wrapping a randomized resource. */
    static randomClass(overrides = {}, opts) {
        return new PASClaimInquiryResponseClass(this.random(overrides, opts));
    }
}
/** Pattern constraints for profile fields (used by random() generator) */
PASClaimInquiryResponseClass._fieldPatterns = {
    "status": "active",
    "use": "preauthorization",
    "category": {
        "coding": [
            {
                "system": "http://terminology.hl7.org/CodeSystem/adjudication",
                "code": "submitted"
            }
        ]
    },
    "item.adjudication.category": "submitted",
    "_refReq_item": {
        "itemSequence": true,
        "adjudication": true,
        "adjudication.category": true,
        "detail.detailSequence": true,
        "detail.adjudication": true,
        "detail.subDetail.subDetailSequence": true
    },
    "_refReq_addItem": {
        "productOrService": true,
        "adjudication": true,
        "detail.productOrService": true,
        "detail.adjudication": true,
        "detail.subDetail.productOrService": true,
        "detail.subDetail.adjudication": true
    },
    "_refReq_total": {
        "category": true,
        "amount": true
    },
    "_refReq_payment": {
        "type": true,
        "amount": true
    },
    "_refReq_processNote": {
        "text": true
    },
    "_refReq_insurance": {
        "sequence": true,
        "focal": true,
        "coverage": true
    },
    "_refReq_error": {
        "code": true
    }
};
/** Fields that are forbidden (max=0) in this profile - must not be generated */
PASClaimInquiryResponseClass._forbiddenFields = [];
/** ValueSet bindings for coded fields - maps field name to ValueSet URL */
PASClaimInquiryResponseClass.valueSetBindings = {
    "language": "http://hl7.org/fhir/ValueSet/languages",
    "status": "http://hl7.org/fhir/ValueSet/fm-status|4.0.1",
    "type": "http://hl7.org/fhir/ValueSet/claim-type",
    "subType": "http://hl7.org/fhir/ValueSet/claim-subtype",
    "use": "http://hl7.org/fhir/ValueSet/claim-use|4.0.1",
    "outcome": "http://hl7.org/fhir/ValueSet/remittance-outcome|4.0.1",
    "payeeType": "http://hl7.org/fhir/ValueSet/payeetype",
    "item.adjudication.category": "http://hl7.org/fhir/ValueSet/adjudication",
    "item.adjudication.reason": "http://hl7.org/fhir/ValueSet/adjudication-reason",
    "addItem.productOrService": "http://hl7.org/fhir/ValueSet/service-uscls",
    "addItem.modifier": "http://hl7.org/fhir/ValueSet/claim-modifiers",
    "addItem.programCode": "http://hl7.org/fhir/ValueSet/ex-program-code",
    "addItem.location[x]": "http://hl7.org/fhir/ValueSet/service-place",
    "addItem.bodySite": "http://hl7.org/fhir/ValueSet/tooth",
    "addItem.subSite": "http://hl7.org/fhir/ValueSet/surface",
    "addItem.detail.productOrService": "http://hl7.org/fhir/ValueSet/service-uscls",
    "addItem.detail.modifier": "http://hl7.org/fhir/ValueSet/claim-modifiers",
    "addItem.detail.subDetail.productOrService": "http://hl7.org/fhir/ValueSet/service-uscls",
    "addItem.detail.subDetail.modifier": "http://hl7.org/fhir/ValueSet/claim-modifiers",
    "total.category": "http://hl7.org/fhir/ValueSet/adjudication",
    "payment.type": "http://hl7.org/fhir/ValueSet/ex-paymenttype",
    "payment.adjustmentReason": "http://hl7.org/fhir/ValueSet/payment-adjustment-reason",
    "fundsReserve": "http://hl7.org/fhir/ValueSet/fundsreserve",
    "formCode": "http://hl7.org/fhir/ValueSet/forms",
    "processNote.type": "http://hl7.org/fhir/ValueSet/note-type|4.0.1",
    "processNote.language": "http://hl7.org/fhir/ValueSet/languages",
    "error.code": "http://hl7.org/fhir/us/davinci-pas/ValueSet/X12278RejectReasonCodes"
};
/** Code resolver for ValueSet bindings - returns a random valid code from a ValueSet by URL */
PASClaimInquiryResponseClass._codeResolver = (() => {
    // Try to dynamically import the ValueSetRegistry - it may not exist if no ValueSets were generated
    try {
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        const registry = require('./valuesets/index.js');
        if (registry && typeof registry.getRandomConceptByUrl === 'function') {
            return registry.getRandomConceptByUrl;
        }
    }
    catch { /* ValueSetRegistry not available */ }
    return undefined;
})();
