import fhirpath from "fhirpath";
import fhirpath_r4_model from "fhirpath/fhir-context/r4/index.js";
export async function validatePASInsurer(resource) {
    const errors = [];
    const warnings = [];
    const result0 = await Promise.resolve(fhirpath.evaluate(resource, "Organization.all(contained.contained.empty())", { resource }, fhirpath_r4_model));
    if (!result0.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL NOT contain nested Resources");
    }
    const result1 = await Promise.resolve(fhirpath.evaluate(resource, "Organization.all(contained.meta.versionId.empty() and contained.meta.lastUpdated.empty())", { resource }, fhirpath_r4_model));
    if (!result1.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a meta.versionId or a meta.lastUpdated");
    }
    const result2 = await Promise.resolve(fhirpath.evaluate(resource, "Organization.all(contained.meta.security.empty())", { resource }, fhirpath_r4_model));
    if (!result2.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a security label");
    }
    const result3 = await Promise.resolve(fhirpath.evaluate(resource, "Organization.all(text.`div`.exists())", { resource }, fhirpath_r4_model));
    if (!result3.every(Boolean)) {
        warnings.push("Constraint violation: A resource should have narrative for robust management");
    }
    const result4 = await Promise.resolve(fhirpath.evaluate(resource, "Organization.all((identifier.count() + name.count()) > 0)", { resource }, fhirpath_r4_model));
    if (!result4.every(Boolean)) {
        errors.push("Constraint violation: The organization SHALL at least have a name or an identifier, and possibly more than one");
    }
    const result5 = await Promise.resolve(fhirpath.evaluate(resource, "meta.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result5.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result6 = await Promise.resolve(fhirpath.evaluate(resource, "implicitRules.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result6.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result7 = await Promise.resolve(fhirpath.evaluate(resource, "language.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result7.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result8 = await Promise.resolve(fhirpath.evaluate(resource, "text.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result8.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result9 = await Promise.resolve(fhirpath.evaluate(resource, "extension.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result9.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result10 = await Promise.resolve(fhirpath.evaluate(resource, "modifierExtension.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result10.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result11 = await Promise.resolve(fhirpath.evaluate(resource, "identifier.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result11.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result12 = await Promise.resolve(fhirpath.evaluate(resource, "active.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result12.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result13 = await Promise.resolve(fhirpath.evaluate(resource, "type.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result13.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result14 = await Promise.resolve(fhirpath.evaluate(resource, "name.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result14.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result15 = await Promise.resolve(fhirpath.evaluate(resource, "alias.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result15.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result16 = await Promise.resolve(fhirpath.evaluate(resource, "telecom.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result16.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result17 = await Promise.resolve(fhirpath.evaluate(resource, "telecom.all(where(use = 'home').empty())", { resource }, fhirpath_r4_model));
    if (!result17.every(Boolean)) {
        errors.push("Constraint violation: The telecom of an organization can never be of use 'home'");
    }
    const result18 = await Promise.resolve(fhirpath.evaluate(resource, "address.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result18.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result19 = await Promise.resolve(fhirpath.evaluate(resource, "address.all(where(use = 'home').empty())", { resource }, fhirpath_r4_model));
    if (!result19.every(Boolean)) {
        errors.push("Constraint violation: An address of an organization can never be of use 'home'");
    }
    const result20 = await Promise.resolve(fhirpath.evaluate(resource, "partOf.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result20.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result21 = await Promise.resolve(fhirpath.evaluate(resource, "contact.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result21.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result22 = await Promise.resolve(fhirpath.evaluate(resource, "endpoint.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result22.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result23 = await Promise.resolve(fhirpath.evaluate(resource, "active.exists()", { resource }, fhirpath_r4_model));
    if (!result23.every(Boolean)) {
        errors.push("Constraint violation: active must be present");
    }
    const result24 = await Promise.resolve(fhirpath.evaluate(resource, "name.exists()", { resource }, fhirpath_r4_model));
    if (!result24.every(Boolean)) {
        errors.push("Constraint violation: name must be present");
    }
    const result25 = await Promise.resolve(fhirpath.evaluate(resource, "address.line.count() <= 4", { resource }, fhirpath_r4_model));
    if (!result25.every(Boolean)) {
        errors.push("Constraint violation: address.line must contain at most 4 elements");
    }
    return { errors, warnings };
}
