import { CodeableConcept, Organization } from "fhir/r4";
export interface PASInsurer extends Organization {
    /** Must Support */
    type?: CodeableConcept[];
}
export declare function validatePASInsurer(resource: PASInsurer): Promise<{
    errors: string[];
    warnings: string[];
}>;
