import { PASIdentifier } from "./PASIdentifier";
import { CodeableConcept, Identifier, Organization } from "fhir/r4";
export interface PASInsurer extends Organization {
    /** Must Support */
    identifier?: (Identifier | PASIdentifier | PASIdentifier)[];
    /** Must Support */
    type?: CodeableConcept[];
}
export declare function validatePASInsurer(resource: PASInsurer): Promise<{
    errors: string[];
    warnings: string[];
}>;
