import { Extension } from "fhir/r4";
export interface LevelOfServiceCode extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-levelOfServiceCode";
}
export declare function validateLevelOfServiceCode(resource: LevelOfServiceCode): Promise<{
    errors: string[];
    warnings: string[];
}>;
