import { HumanName, Practitioner } from "fhir/r4";
export interface PASPractitioner extends Practitioner {
    /** Must Support */
    name: HumanName[];
}
export declare function validatePASPractitioner(resource: PASPractitioner): Promise<{
    errors: string[];
    warnings: string[];
}>;
