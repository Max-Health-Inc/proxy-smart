import { PractitionerRole, Reference } from "fhir/r4";
export interface PASPractitionerRole extends PractitionerRole {
    /** Must Support */
    practitioner: Reference;
    /** Must Support */
    organization?: Reference;
}
export declare function validatePASPractitionerRole(resource: PASPractitionerRole): Promise<{
    errors: string[];
    warnings: string[];
}>;
