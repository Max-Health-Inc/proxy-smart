import { Extension } from "fhir/r4";
export interface NursingHomeResidentialStatus extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-nursingHomeResidentialStatus";
}
export declare function validateNursingHomeResidentialStatus(resource: NursingHomeResidentialStatus): Promise<{
    errors: string[];
    warnings: string[];
}>;
