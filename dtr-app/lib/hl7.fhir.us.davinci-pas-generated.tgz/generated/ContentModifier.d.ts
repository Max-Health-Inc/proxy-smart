import { Extension } from "fhir/r4";
export interface ContentModifier extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-contentModifier";
}
export declare function validateContentModifier(resource: ContentModifier): Promise<{
    errors: string[];
    warnings: string[];
}>;
