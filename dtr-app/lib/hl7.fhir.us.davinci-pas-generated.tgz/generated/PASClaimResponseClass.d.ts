import { PASClaimResponse } from "./PASClaimResponse.js";
export declare class PASClaimResponseClass {
    private resource;
    /** Pattern constraints for profile fields (used by random() generator) */
    protected static readonly _fieldPatterns: {
        status: string;
        use: string;
        category: {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "item.adjudication.category": string;
        _refReq_item: {
            itemSequence: boolean;
            adjudication: boolean;
            "adjudication.category": boolean;
            "detail.detailSequence": boolean;
            "detail.adjudication": boolean;
            "detail.subDetail.subDetailSequence": boolean;
        };
        _refReq_addItem: {
            productOrService: boolean;
            adjudication: boolean;
            "detail.productOrService": boolean;
            "detail.adjudication": boolean;
            "detail.subDetail.productOrService": boolean;
            "detail.subDetail.adjudication": boolean;
        };
        _refReq_total: {
            category: boolean;
            amount: boolean;
        };
        _refReq_payment: {
            type: boolean;
            amount: boolean;
        };
        _refReq_processNote: {
            text: boolean;
        };
        _refReq_insurance: {
            sequence: boolean;
            focal: boolean;
            coverage: boolean;
        };
        _refReq_error: {
            code: boolean;
        };
    };
    /** Fields that are forbidden (max=0) in this profile - must not be generated */
    protected static readonly _forbiddenFields: string[];
    /** ValueSet bindings for coded fields - maps field name to ValueSet URL */
    static readonly valueSetBindings: Record<string, string>;
    /** Code resolver for ValueSet bindings - returns a random valid code from a ValueSet by URL */
    protected static readonly _codeResolver: ((url: string) => {
        code: string;
        system: string;
        display?: string;
    } | undefined) | undefined;
    constructor(resource: PASClaimResponse);
    /** Validate current resource instance. */
    validate(): Promise<{
        errors: string[];
        warnings: string[];
    }>;
    getResource(): PASClaimResponse;
    setResource(resource: PASClaimResponse): void;
    /**
     * Returns a plain JSON clone of the underlying resource ONLY if the last validation succeeded with zero errors.
     * Call validate() first; otherwise this method throws to prevent accidental use of invalid / unchecked data.
     */
    toJSON(): Promise<PASClaimResponse>;
    /**
     * Create an empty instance for parity testing: for true FHIR resources, includes only resourceType; for datatypes, returns an empty object.
     * Note: meta.profile (when applicable) will be ensured by the constructor when wrapping this resource.
     */
    static empty(overrides?: Partial<PASClaimResponse>): PASClaimResponse;
    /**
     * Create a minimal randomized instance of PASClaimResponse.
     * Populates id, resourceType (if applicable) and primitive required (min>0) top-level fields with placeholders.
     */
    static random(overrides?: Partial<PASClaimResponse>, opts?: {
        seed?: number;
    }): PASClaimResponse;
    /** Convenience: returns a class instance wrapping a randomized resource. */
    static randomClass(overrides?: Partial<PASClaimResponse>, opts?: {
        seed?: number;
    }): PASClaimResponseClass;
}
