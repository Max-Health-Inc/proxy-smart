import { validatePASNutritionOrder } from "./PASNutritionOrder.js";
// Only import helpers actually referenced below (dynamic based on required fields)
import { randomId, setRandomSeed, enrichResource, randomDate, skeletonReference } from "./RandomSupport.js";
// Helper emitted only when meta.profile enforcement is applicable (resource profiles)
// Internal helper (emitted per class file) to clone without resorting to 'any'.
function safeClone(value) {
    // Use native structuredClone if present; otherwise fallback to JSON round-trip.
    // We intentionally avoid casting through any to satisfy no-explicit-any lint rule.
    const g = globalThis;
    // Narrow globalThis to an object potentially containing structuredClone.
    if (typeof g.structuredClone === 'function') {
        return g.structuredClone(value);
    }
    return JSON.parse(JSON.stringify(value)); // best-effort deep clone
}
export class PASNutritionOrderClass {
    constructor(resource) {
        this.resource = resource;
    }
    /** Validate current resource instance. */
    async validate() {
        return validatePASNutritionOrder(this.resource);
    }
    getResource() {
        return this.resource;
    }
    setResource(resource) {
        this.resource = resource;
    }
    /**
     * Returns a plain JSON clone of the underlying resource ONLY if the last validation succeeded with zero errors.
     * Call validate() first; otherwise this method throws to prevent accidental use of invalid / unchecked data.
     */
    async toJSON() {
        return safeClone(this.resource);
    }
    /**
     * Create an empty instance for parity testing: for true FHIR resources, includes only resourceType; for datatypes, returns an empty object.
     * Note: meta.profile (when applicable) will be ensured by the constructor when wrapping this resource.
     */
    static empty(overrides = {}) {
        // For Resource profiles, include only resourceType. For Extension profiles, include url so the instance is minimally meaningful.
        const base = {};
        return { ...base, ...overrides };
    }
    /**
     * Create a minimal randomized instance of PASNutritionOrder.
     * Populates id, resourceType (if applicable) and primitive required (min>0) top-level fields with placeholders.
     */
    static random(overrides = {}, opts) {
        if (opts?.seed !== undefined) {
            // Direct call (no dynamic require) to ensure deterministic seeding works under ESM.
            setRandomSeed(opts.seed);
        }
        // Start with a Partial to avoid unsafe casting errors; we'll assert at the end.
        const base = { id: randomId(), status: 'active', intent: "order", patient: skeletonReference(), dateTime: randomDate(), };
        // Always include meta.profile with this profile's canonical URL if available & only for resource profiles
        // (no profileUrl provided or profile targets a datatype – meta.profile not applicable)
        // Enrich the base resource with common fields using centralized enrichment logic
        enrichResource(base, 'NutritionOrder', 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-nutritionorder', PASNutritionOrderClass._fieldPatterns, PASNutritionOrderClass._forbiddenFields, PASNutritionOrderClass.valueSetBindings, PASNutritionOrderClass._codeResolver);
        // Cast through unknown to acknowledge dynamic enrichment
        return { ...base, ...overrides };
    }
    /** Convenience: returns a class instance wrapping a randomized resource. */
    static randomClass(overrides = {}, opts) {
        return new PASNutritionOrderClass(this.random(overrides, opts));
    }
}
/** Pattern constraints for profile fields (used by random() generator) */
PASNutritionOrderClass._fieldPatterns = {
    "intent": "order"
};
/** Fields that are forbidden (max=0) in this profile - must not be generated */
PASNutritionOrderClass._forbiddenFields = [];
/** ValueSet bindings for coded fields - maps field name to ValueSet URL */
PASNutritionOrderClass.valueSetBindings = {
    "language": "http://hl7.org/fhir/ValueSet/languages",
    "status": "http://hl7.org/fhir/ValueSet/request-status|4.0.1",
    "intent": "http://hl7.org/fhir/ValueSet/request-intent|4.0.1",
    "foodPreferenceModifier": "http://hl7.org/fhir/ValueSet/encounter-diet",
    "excludeFoodModifier": "http://hl7.org/fhir/ValueSet/food-type",
    "oralDiet.type": "http://hl7.org/fhir/us/davinci-pas/ValueSet/X12278NutritionOralDietType",
    "oralDiet.nutrient.modifier": "http://hl7.org/fhir/ValueSet/nutrient-code",
    "oralDiet.texture.modifier": "http://hl7.org/fhir/ValueSet/texture-code",
    "oralDiet.texture.foodType": "http://hl7.org/fhir/ValueSet/modified-foodtype",
    "oralDiet.fluidConsistencyType": "http://hl7.org/fhir/ValueSet/consistency-type",
    "supplement.type": "http://hl7.org/fhir/ValueSet/supplement-type",
    "enteralFormula.baseFormulaType": "http://hl7.org/fhir/us/davinci-pas/ValueSet/X12278NutritionEnteralFormulaType",
    "enteralFormula.additiveType": "http://hl7.org/fhir/ValueSet/entformula-additive",
    "enteralFormula.routeofAdministration": "http://hl7.org/fhir/ValueSet/enteral-route"
};
/** Code resolver for ValueSet bindings - returns a random valid code from a ValueSet by URL */
PASNutritionOrderClass._codeResolver = (() => {
    // Try to dynamically import the ValueSetRegistry - it may not exist if no ValueSets were generated
    try {
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        const registry = require('./valuesets/index.js');
        if (registry && typeof registry.getRandomConceptByUrl === 'function') {
            return registry.getRandomConceptByUrl;
        }
    }
    catch { /* ValueSetRegistry not available */ }
    return undefined;
})();
