import { validatePASInquiryRequestBundle } from "./PASInquiryRequestBundle.js";
// Only import helpers actually referenced below (dynamic based on required fields)
import { randomId, setRandomSeed, enrichResource, randomDate, skeletonIdentifier } from "./RandomSupport.js";
function ensureProfile(res, profile) {
    if (!res.meta) {
        res.meta = { profile: [profile] };
        return;
    }
    if (!res.meta.profile) {
        res.meta.profile = [profile];
        return;
    }
    if (!res.meta.profile.includes(profile)) {
        res.meta.profile = [...res.meta.profile, profile];
    }
}
// Internal helper (emitted per class file) to clone without resorting to 'any'.
function safeClone(value) {
    // Use native structuredClone if present; otherwise fallback to JSON round-trip.
    // We intentionally avoid casting through any to satisfy no-explicit-any lint rule.
    const g = globalThis;
    // Narrow globalThis to an object potentially containing structuredClone.
    if (typeof g.structuredClone === 'function') {
        return g.structuredClone(value);
    }
    return JSON.parse(JSON.stringify(value)); // best-effort deep clone
}
export class PASInquiryRequestBundleClass {
    constructor(resource) {
        this.resource = resource;
        ensureProfile(this.resource, 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-pas-inquiry-request-bundle');
    }
    /** Validate current resource instance. */
    async validate() {
        return validatePASInquiryRequestBundle(this.resource);
    }
    getResource() {
        return this.resource;
    }
    setResource(resource) {
        this.resource = resource;
        ensureProfile(this.resource, 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-pas-inquiry-request-bundle');
    }
    /**
     * Returns a plain JSON clone of the underlying resource ONLY if the last validation succeeded with zero errors.
     * Call validate() first; otherwise this method throws to prevent accidental use of invalid / unchecked data.
     */
    async toJSON() {
        return safeClone(this.resource);
    }
    /**
     * Create an empty instance for parity testing: for true FHIR resources, includes only resourceType; for datatypes, returns an empty object.
     * Note: meta.profile (when applicable) will be ensured by the constructor when wrapping this resource.
     */
    static empty(overrides = {}) {
        // For Resource profiles, include only resourceType. For Extension profiles, include url so the instance is minimally meaningful.
        const base = {
            resourceType: 'Bundle',
        };
        return { ...base, ...overrides };
    }
    /**
     * Create a minimal randomized instance of PASInquiryRequestBundle.
     * Populates id, resourceType (if applicable) and primitive required (min>0) top-level fields with placeholders.
     */
    static random(overrides = {}, opts) {
        if (opts?.seed !== undefined) {
            // Direct call (no dynamic require) to ensure deterministic seeding works under ESM.
            setRandomSeed(opts.seed);
        }
        // Start with a Partial to avoid unsafe casting errors; we'll assert at the end.
        const base = { resourceType: 'Bundle', id: randomId(), identifier: skeletonIdentifier(), type: "collection", timestamp: randomDate(), entry: [{ fullUrl: 'urn:uuid:' + crypto.randomUUID(), resource: { resourceType: 'Profile', id: 'comp-' + randomId(), meta: { profile: ['http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-claim-inquiry'] }, status: 'final', type: { coding: [{ system: 'http://loinc.org', code: '60591-5' }], text: '60591-5' }, subject: { reference: 'Patient/' + randomId(), display: 'Example Patient' }, date: new Date().toISOString(), author: [{ reference: 'Practitioner/' + randomId(), display: 'Example Practitioner' }], title: 'Document Title', text: { status: 'generated', div: '<div xmlns="http://www.w3.org/1999/xhtml">Generated</div>' }, section: [{ title: 'Section', text: { status: 'generated', div: '<div xmlns="http://www.w3.org/1999/xhtml">Content</div>' } }] } }], };
        // Always include meta.profile with this profile's canonical URL if available & only for resource profiles
        ensureProfile(base, 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-pas-inquiry-request-bundle');
        // Enrich the base resource with common fields using centralized enrichment logic
        enrichResource(base, 'Bundle', 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-pas-inquiry-request-bundle', PASInquiryRequestBundleClass._fieldPatterns, PASInquiryRequestBundleClass._forbiddenFields, PASInquiryRequestBundleClass.valueSetBindings, PASInquiryRequestBundleClass._codeResolver);
        // Cast through unknown to acknowledge dynamic enrichment
        return { ...base, ...overrides };
    }
    /** Convenience: returns a class instance wrapping a randomized resource. */
    static randomClass(overrides = {}, opts) {
        return new PASInquiryRequestBundleClass(this.random(overrides, opts));
    }
}
/** Pattern constraints for profile fields (used by random() generator) */
PASInquiryRequestBundleClass._fieldPatterns = {
    "type": "collection",
    "_refReq_link": {
        "relation": true,
        "url": true
    },
    "_refReq_entry": {
        "fullUrl": true,
        "resource": true,
        "request.method": true,
        "request.url": true,
        "response.status": true
    }
};
/** Fields that are forbidden (max=0) in this profile - must not be generated */
PASInquiryRequestBundleClass._forbiddenFields = [];
/** ValueSet bindings for coded fields - maps field name to ValueSet URL */
PASInquiryRequestBundleClass.valueSetBindings = {
    "language": "http://hl7.org/fhir/ValueSet/languages",
    "type": "http://hl7.org/fhir/ValueSet/bundle-type|4.0.1",
    "entry.search.mode": "http://hl7.org/fhir/ValueSet/search-entry-mode|4.0.1",
    "entry.request.method": "http://hl7.org/fhir/ValueSet/http-verb|4.0.1"
};
/** Code resolver for ValueSet bindings - returns a random valid code from a ValueSet by URL */
PASInquiryRequestBundleClass._codeResolver = (() => {
    // Try to dynamically import the ValueSetRegistry - it may not exist if no ValueSets were generated
    try {
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        const registry = require('./valuesets/index.js');
        if (registry && typeof registry.getRandomConceptByUrl === 'function') {
            return registry.getRandomConceptByUrl;
        }
    }
    catch { /* ValueSetRegistry not available */ }
    return undefined;
})();
