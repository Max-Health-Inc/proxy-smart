import { Extension } from "fhir/r4";
export interface CalendarPattern extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-timingcalendarpattern";
}
export declare function validateCalendarPattern(resource: CalendarPattern): Promise<{
    errors: string[];
    warnings: string[];
}>;
