import { IdentifierJurisdiction } from "./IdentifierJurisdiction";
import { IdentifierSubDepartment } from "./IdentifierSubDepartment";
import { Extension, Identifier } from "fhir/r4";
export interface PASIdentifier extends Identifier {
    extension?: (Extension | IdentifierSubDepartment | IdentifierJurisdiction)[];
}
export declare function validatePASIdentifier(resource: PASIdentifier): Promise<{
    errors: string[];
    warnings: string[];
}>;
