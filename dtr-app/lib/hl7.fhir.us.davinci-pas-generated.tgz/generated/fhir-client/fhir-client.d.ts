import { FhirReadClient as BaseFhirReadClient, FhirWriteClient as BaseFhirWriteClient, type FetchFn } from "@babelfhir-ts/client-r4";
import type * as GeneratedTypes from "../index.js";
/**
 * Profile-specific FHIR Read Client.
 * Extends the base R4 read client with typed profile accessors.
 * Inherits all base R4 resource methods from @babelfhir-ts/client-r4.
 */
export declare class FhirReadClient extends BaseFhirReadClient {
    pASBeneficiary(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASBeneficiary>;
    pASCommunicationRequest(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASCommunicationRequest>;
    pASCoverage(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASCoverage>;
    pASDeviceRequest(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASDeviceRequest>;
    pASEncounter(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASEncounter>;
    pASInsurer(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASInsurer>;
    pASLocation(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASLocation>;
    pASOrganization(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASOrganization>;
    pASPractitioner(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASPractitioner>;
    pASPractitionerRole(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASPractitionerRole>;
    pASRequestor(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASRequestor>;
    pASServiceRequest(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASServiceRequest>;
    pASSubscriber(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASSubscriber>;
}
/**
 * Profile-specific FHIR Write Client.
 * Extends the base R4 write client with typed profile accessors.
 * Inherits all base R4 resource methods from @babelfhir-ts/client-r4.
 */
export declare class FhirWriteClient extends BaseFhirWriteClient {
    pASBeneficiary(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASBeneficiary>;
    pASCommunicationRequest(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASCommunicationRequest>;
    pASCoverage(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASCoverage>;
    pASDeviceRequest(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASDeviceRequest>;
    pASEncounter(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASEncounter>;
    pASInsurer(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASInsurer>;
    pASLocation(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASLocation>;
    pASOrganization(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASOrganization>;
    pASPractitioner(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASPractitioner>;
    pASPractitionerRole(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASPractitionerRole>;
    pASRequestor(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASRequestor>;
    pASServiceRequest(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASServiceRequest>;
    pASSubscriber(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASSubscriber>;
}
/**
 * Main FHIR Client — works with plain fetch or an authenticated fetch wrapper.
 * Provides both base R4 accessors (inherited) and profile-specific accessors.
 *
 * @example
 * // Unauthenticated
 * const client = new FhirClient("https://fhir.example.com");
 *
 * // With custom fetch (e.g. from SmartFhirClient)
 * const client = new FhirClient("https://fhir.example.com", authenticatedFetch);
 *
 * // Base R4 methods (inherited from @babelfhir-ts/client-r4)
 * const pt = await client.read().patient().read("123");
 *
 * // Profile-specific methods (generated)
 * const claim = await client.read().pASClaim().search({ status: "active" });
 */
export declare class FhirClient {
    readonly baseUrl: string;
    private readonly readClient;
    private readonly writeClient;
    constructor(baseUrl: string, fetchFn?: FetchFn);
    /**
     * Get a read client for querying resources
     */
    read(): FhirReadClient;
    /**
     * Get a write client for creating/updating resources
     */
    write(): FhirWriteClient;
}
