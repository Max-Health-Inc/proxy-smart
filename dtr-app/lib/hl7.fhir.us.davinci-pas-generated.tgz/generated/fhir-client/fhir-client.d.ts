import { type PASBeneficiaryReader, type PASCommunicationRequestReader, type PASCoverageReader, type PASDeviceRequestReader, type PASEncounterReader, type PASInsurerReader, type PASLocationReader, type PASOrganizationReader, type PASPractitionerReader, type PASPractitionerRoleReader, type PASRequestorReader, type PASServiceRequestReader, type PASSubscriberReader, type AccountReader, type ActivityDefinitionReader, type AdverseEventReader, type AllergyIntoleranceReader, type AppointmentReader, type AppointmentResponseReader, type AuditEventReader, type BasicReader, type BinaryReader, type BiologicallyDerivedProductReader, type BodyStructureReader, type CapabilityStatementReader, type CarePlanReader, type CareTeamReader, type ChargeItemReader, type ChargeItemDefinitionReader, type ClaimReader, type ClaimResponseReader, type ClinicalImpressionReader, type CodeSystemReader, type CommunicationReader, type CompartmentDefinitionReader, type CompositionReader, type ConceptMapReader, type ConditionReader, type ConsentReader, type ContractReader, type CoverageEligibilityRequestReader, type CoverageEligibilityResponseReader, type DetectedIssueReader, type DeviceReader, type DeviceDefinitionReader, type DeviceMetricReader, type DeviceUseStatementReader, type DiagnosticReportReader, type DocumentManifestReader, type DocumentReferenceReader, type EndpointReader, type EnrollmentRequestReader, type EnrollmentResponseReader, type EpisodeOfCareReader, type EventDefinitionReader, type EvidenceReader, type EvidenceVariableReader, type ExampleScenarioReader, type ExplanationOfBenefitReader, type FamilyMemberHistoryReader, type FlagReader, type GoalReader, type GraphDefinitionReader, type GroupReader, type GuidanceResponseReader, type HealthcareServiceReader, type ImagingStudyReader, type ImmunizationReader, type ImmunizationEvaluationReader, type ImmunizationRecommendationReader, type ImplementationGuideReader, type InsurancePlanReader, type InvoiceReader, type LibraryReader, type LinkageReader, type ListReader, type MeasureReader, type MeasureReportReader, type MediaReader, type MedicationReader, type MedicationAdministrationReader, type MedicationDispenseReader, type MedicationKnowledgeReader, type MedicationRequestReader, type MedicationStatementReader, type MedicinalProductReader, type MessageDefinitionReader, type MessageHeaderReader, type MolecularSequenceReader, type NamingSystemReader, type NutritionOrderReader, type ObservationReader, type ObservationDefinitionReader, type OperationDefinitionReader, type OperationOutcomeReader, type OrganizationAffiliationReader, type ParametersReader, type PaymentNoticeReader, type PaymentReconciliationReader, type PersonReader, type PlanDefinitionReader, type ProcedureReader, type ProvenanceReader, type QuestionnaireReader, type QuestionnaireResponseReader, type RelatedPersonReader, type RequestGroupReader, type ResearchDefinitionReader, type ResearchElementDefinitionReader, type ResearchStudyReader, type ResearchSubjectReader, type RiskAssessmentReader, type RiskEvidenceSynthesisReader, type ScheduleReader, type SearchParameterReader, type SlotReader, type SpecimenReader, type SpecimenDefinitionReader, type StructureDefinitionReader, type StructureMapReader, type SubscriptionReader, type SubstanceReader, type SubstanceSpecificationReader, type SupplyDeliveryReader, type SupplyRequestReader, type TaskReader, type TerminologyCapabilitiesReader, type TestReportReader, type TestScriptReader, type ValueSetReader, type VerificationResultReader, type VisionPrescriptionReader, type FhirResourceSearcher, type FetchFn } from "./resource-reader.js";
import { type PASBeneficiaryWriter, type PASCommunicationRequestWriter, type PASCoverageWriter, type PASDeviceRequestWriter, type PASEncounterWriter, type PASInsurerWriter, type PASLocationWriter, type PASOrganizationWriter, type PASPractitionerWriter, type PASPractitionerRoleWriter, type PASRequestorWriter, type PASServiceRequestWriter, type PASSubscriberWriter, type AccountWriter, type ActivityDefinitionWriter, type AdverseEventWriter, type AllergyIntoleranceWriter, type AppointmentWriter, type AppointmentResponseWriter, type AuditEventWriter, type BasicWriter, type BinaryWriter, type BiologicallyDerivedProductWriter, type BodyStructureWriter, type CapabilityStatementWriter, type CarePlanWriter, type CareTeamWriter, type ChargeItemWriter, type ChargeItemDefinitionWriter, type ClaimWriter, type ClaimResponseWriter, type ClinicalImpressionWriter, type CodeSystemWriter, type CommunicationWriter, type CompartmentDefinitionWriter, type CompositionWriter, type ConceptMapWriter, type ConditionWriter, type ConsentWriter, type ContractWriter, type CoverageEligibilityRequestWriter, type CoverageEligibilityResponseWriter, type DetectedIssueWriter, type DeviceWriter, type DeviceDefinitionWriter, type DeviceMetricWriter, type DeviceUseStatementWriter, type DiagnosticReportWriter, type DocumentManifestWriter, type DocumentReferenceWriter, type EndpointWriter, type EnrollmentRequestWriter, type EnrollmentResponseWriter, type EpisodeOfCareWriter, type EventDefinitionWriter, type EvidenceWriter, type EvidenceVariableWriter, type ExampleScenarioWriter, type ExplanationOfBenefitWriter, type FamilyMemberHistoryWriter, type FlagWriter, type GoalWriter, type GraphDefinitionWriter, type GroupWriter, type GuidanceResponseWriter, type HealthcareServiceWriter, type ImagingStudyWriter, type ImmunizationWriter, type ImmunizationEvaluationWriter, type ImmunizationRecommendationWriter, type ImplementationGuideWriter, type InsurancePlanWriter, type InvoiceWriter, type LibraryWriter, type LinkageWriter, type ListWriter, type MeasureWriter, type MeasureReportWriter, type MediaWriter, type MedicationWriter, type MedicationAdministrationWriter, type MedicationDispenseWriter, type MedicationKnowledgeWriter, type MedicationRequestWriter, type MedicationStatementWriter, type MedicinalProductWriter, type MessageDefinitionWriter, type MessageHeaderWriter, type MolecularSequenceWriter, type NamingSystemWriter, type NutritionOrderWriter, type ObservationWriter, type ObservationDefinitionWriter, type OperationDefinitionWriter, type OperationOutcomeWriter, type OrganizationAffiliationWriter, type ParametersWriter, type PaymentNoticeWriter, type PaymentReconciliationWriter, type PersonWriter, type PlanDefinitionWriter, type ProcedureWriter, type ProvenanceWriter, type QuestionnaireWriter, type QuestionnaireResponseWriter, type RelatedPersonWriter, type RequestGroupWriter, type ResearchDefinitionWriter, type ResearchElementDefinitionWriter, type ResearchStudyWriter, type ResearchSubjectWriter, type RiskAssessmentWriter, type RiskEvidenceSynthesisWriter, type ScheduleWriter, type SearchParameterWriter, type SlotWriter, type SpecimenWriter, type SpecimenDefinitionWriter, type StructureDefinitionWriter, type StructureMapWriter, type SubscriptionWriter, type SubstanceWriter, type SubstanceSpecificationWriter, type SupplyDeliveryWriter, type SupplyRequestWriter, type TaskWriter, type TerminologyCapabilitiesWriter, type TestReportWriter, type TestScriptWriter, type ValueSetWriter, type VerificationResultWriter, type VisionPrescriptionWriter, type FhirResourceWriter } from "./resource-writer.js";
/**
 * FHIR Client for reading resources
 */
export declare class FhirReadClient {
    private readonly baseUrl;
    private readonly fetchFn?;
    constructor(baseUrl: string, fetchFn?: FetchFn);
    /**
     * Generic reader for any FHIR resource type.
     * Use this for resource types not covered by the named methods.
     *
     * @example
     * const reader = client.read().resource<MyCustomType>("CustomResource");
     * const item = await reader.read("123");
     */
    resource<T>(resourceType: string): FhirResourceSearcher<T>;
    pASBeneficiary(): PASBeneficiaryReader;
    pASCommunicationRequest(): PASCommunicationRequestReader;
    pASCoverage(): PASCoverageReader;
    pASDeviceRequest(): PASDeviceRequestReader;
    pASEncounter(): PASEncounterReader;
    pASInsurer(): PASInsurerReader;
    pASLocation(): PASLocationReader;
    pASOrganization(): PASOrganizationReader;
    pASPractitioner(): PASPractitionerReader;
    pASPractitionerRole(): PASPractitionerRoleReader;
    pASRequestor(): PASRequestorReader;
    pASServiceRequest(): PASServiceRequestReader;
    pASSubscriber(): PASSubscriberReader;
    account(): AccountReader;
    activityDefinition(): ActivityDefinitionReader;
    adverseEvent(): AdverseEventReader;
    allergyIntolerance(): AllergyIntoleranceReader;
    appointment(): AppointmentReader;
    appointmentResponse(): AppointmentResponseReader;
    auditEvent(): AuditEventReader;
    basic(): BasicReader;
    binary(): BinaryReader;
    biologicallyDerivedProduct(): BiologicallyDerivedProductReader;
    bodyStructure(): BodyStructureReader;
    capabilityStatement(): CapabilityStatementReader;
    carePlan(): CarePlanReader;
    careTeam(): CareTeamReader;
    chargeItem(): ChargeItemReader;
    chargeItemDefinition(): ChargeItemDefinitionReader;
    claim(): ClaimReader;
    claimResponse(): ClaimResponseReader;
    clinicalImpression(): ClinicalImpressionReader;
    codeSystem(): CodeSystemReader;
    communication(): CommunicationReader;
    compartmentDefinition(): CompartmentDefinitionReader;
    composition(): CompositionReader;
    conceptMap(): ConceptMapReader;
    condition(): ConditionReader;
    consent(): ConsentReader;
    contract(): ContractReader;
    coverageEligibilityRequest(): CoverageEligibilityRequestReader;
    coverageEligibilityResponse(): CoverageEligibilityResponseReader;
    detectedIssue(): DetectedIssueReader;
    device(): DeviceReader;
    deviceDefinition(): DeviceDefinitionReader;
    deviceMetric(): DeviceMetricReader;
    deviceUseStatement(): DeviceUseStatementReader;
    diagnosticReport(): DiagnosticReportReader;
    documentManifest(): DocumentManifestReader;
    documentReference(): DocumentReferenceReader;
    endpoint(): EndpointReader;
    enrollmentRequest(): EnrollmentRequestReader;
    enrollmentResponse(): EnrollmentResponseReader;
    episodeOfCare(): EpisodeOfCareReader;
    eventDefinition(): EventDefinitionReader;
    evidence(): EvidenceReader;
    evidenceVariable(): EvidenceVariableReader;
    exampleScenario(): ExampleScenarioReader;
    explanationOfBenefit(): ExplanationOfBenefitReader;
    familyMemberHistory(): FamilyMemberHistoryReader;
    flag(): FlagReader;
    goal(): GoalReader;
    graphDefinition(): GraphDefinitionReader;
    group(): GroupReader;
    guidanceResponse(): GuidanceResponseReader;
    healthcareService(): HealthcareServiceReader;
    imagingStudy(): ImagingStudyReader;
    immunization(): ImmunizationReader;
    immunizationEvaluation(): ImmunizationEvaluationReader;
    immunizationRecommendation(): ImmunizationRecommendationReader;
    implementationGuide(): ImplementationGuideReader;
    insurancePlan(): InsurancePlanReader;
    invoice(): InvoiceReader;
    library(): LibraryReader;
    linkage(): LinkageReader;
    list(): ListReader;
    measure(): MeasureReader;
    measureReport(): MeasureReportReader;
    media(): MediaReader;
    medication(): MedicationReader;
    medicationAdministration(): MedicationAdministrationReader;
    medicationDispense(): MedicationDispenseReader;
    medicationKnowledge(): MedicationKnowledgeReader;
    medicationRequest(): MedicationRequestReader;
    medicationStatement(): MedicationStatementReader;
    medicinalProduct(): MedicinalProductReader;
    messageDefinition(): MessageDefinitionReader;
    messageHeader(): MessageHeaderReader;
    molecularSequence(): MolecularSequenceReader;
    namingSystem(): NamingSystemReader;
    nutritionOrder(): NutritionOrderReader;
    observation(): ObservationReader;
    observationDefinition(): ObservationDefinitionReader;
    operationDefinition(): OperationDefinitionReader;
    operationOutcome(): OperationOutcomeReader;
    organizationAffiliation(): OrganizationAffiliationReader;
    parameters(): ParametersReader;
    paymentNotice(): PaymentNoticeReader;
    paymentReconciliation(): PaymentReconciliationReader;
    person(): PersonReader;
    planDefinition(): PlanDefinitionReader;
    procedure(): ProcedureReader;
    provenance(): ProvenanceReader;
    questionnaire(): QuestionnaireReader;
    questionnaireResponse(): QuestionnaireResponseReader;
    relatedPerson(): RelatedPersonReader;
    requestGroup(): RequestGroupReader;
    researchDefinition(): ResearchDefinitionReader;
    researchElementDefinition(): ResearchElementDefinitionReader;
    researchStudy(): ResearchStudyReader;
    researchSubject(): ResearchSubjectReader;
    riskAssessment(): RiskAssessmentReader;
    riskEvidenceSynthesis(): RiskEvidenceSynthesisReader;
    schedule(): ScheduleReader;
    searchParameter(): SearchParameterReader;
    slot(): SlotReader;
    specimen(): SpecimenReader;
    specimenDefinition(): SpecimenDefinitionReader;
    structureDefinition(): StructureDefinitionReader;
    structureMap(): StructureMapReader;
    subscription(): SubscriptionReader;
    substance(): SubstanceReader;
    substanceSpecification(): SubstanceSpecificationReader;
    supplyDelivery(): SupplyDeliveryReader;
    supplyRequest(): SupplyRequestReader;
    task(): TaskReader;
    terminologyCapabilities(): TerminologyCapabilitiesReader;
    testReport(): TestReportReader;
    testScript(): TestScriptReader;
    valueSet(): ValueSetReader;
    verificationResult(): VerificationResultReader;
    visionPrescription(): VisionPrescriptionReader;
}
/**
 * FHIR Client for writing resources
 */
export declare class FhirWriteClient {
    private readonly baseUrl;
    private readonly fetchFn?;
    constructor(baseUrl: string, fetchFn?: FetchFn);
    /**
     * Generic writer for any FHIR resource type.
     * Use this for resource types not covered by the named methods.
     *
     * @example
     * const writer = client.write().resource<MyCustomType>("CustomResource");
     * await writer.create(myResource);
     */
    resource<T>(resourceType: string): FhirResourceWriter<T>;
    pASBeneficiary(): PASBeneficiaryWriter;
    pASCommunicationRequest(): PASCommunicationRequestWriter;
    pASCoverage(): PASCoverageWriter;
    pASDeviceRequest(): PASDeviceRequestWriter;
    pASEncounter(): PASEncounterWriter;
    pASInsurer(): PASInsurerWriter;
    pASLocation(): PASLocationWriter;
    pASOrganization(): PASOrganizationWriter;
    pASPractitioner(): PASPractitionerWriter;
    pASPractitionerRole(): PASPractitionerRoleWriter;
    pASRequestor(): PASRequestorWriter;
    pASServiceRequest(): PASServiceRequestWriter;
    pASSubscriber(): PASSubscriberWriter;
    account(): AccountWriter;
    activityDefinition(): ActivityDefinitionWriter;
    adverseEvent(): AdverseEventWriter;
    allergyIntolerance(): AllergyIntoleranceWriter;
    appointment(): AppointmentWriter;
    appointmentResponse(): AppointmentResponseWriter;
    auditEvent(): AuditEventWriter;
    basic(): BasicWriter;
    binary(): BinaryWriter;
    biologicallyDerivedProduct(): BiologicallyDerivedProductWriter;
    bodyStructure(): BodyStructureWriter;
    capabilityStatement(): CapabilityStatementWriter;
    carePlan(): CarePlanWriter;
    careTeam(): CareTeamWriter;
    chargeItem(): ChargeItemWriter;
    chargeItemDefinition(): ChargeItemDefinitionWriter;
    claim(): ClaimWriter;
    claimResponse(): ClaimResponseWriter;
    clinicalImpression(): ClinicalImpressionWriter;
    codeSystem(): CodeSystemWriter;
    communication(): CommunicationWriter;
    compartmentDefinition(): CompartmentDefinitionWriter;
    composition(): CompositionWriter;
    conceptMap(): ConceptMapWriter;
    condition(): ConditionWriter;
    consent(): ConsentWriter;
    contract(): ContractWriter;
    coverageEligibilityRequest(): CoverageEligibilityRequestWriter;
    coverageEligibilityResponse(): CoverageEligibilityResponseWriter;
    detectedIssue(): DetectedIssueWriter;
    device(): DeviceWriter;
    deviceDefinition(): DeviceDefinitionWriter;
    deviceMetric(): DeviceMetricWriter;
    deviceUseStatement(): DeviceUseStatementWriter;
    diagnosticReport(): DiagnosticReportWriter;
    documentManifest(): DocumentManifestWriter;
    documentReference(): DocumentReferenceWriter;
    endpoint(): EndpointWriter;
    enrollmentRequest(): EnrollmentRequestWriter;
    enrollmentResponse(): EnrollmentResponseWriter;
    episodeOfCare(): EpisodeOfCareWriter;
    eventDefinition(): EventDefinitionWriter;
    evidence(): EvidenceWriter;
    evidenceVariable(): EvidenceVariableWriter;
    exampleScenario(): ExampleScenarioWriter;
    explanationOfBenefit(): ExplanationOfBenefitWriter;
    familyMemberHistory(): FamilyMemberHistoryWriter;
    flag(): FlagWriter;
    goal(): GoalWriter;
    graphDefinition(): GraphDefinitionWriter;
    group(): GroupWriter;
    guidanceResponse(): GuidanceResponseWriter;
    healthcareService(): HealthcareServiceWriter;
    imagingStudy(): ImagingStudyWriter;
    immunization(): ImmunizationWriter;
    immunizationEvaluation(): ImmunizationEvaluationWriter;
    immunizationRecommendation(): ImmunizationRecommendationWriter;
    implementationGuide(): ImplementationGuideWriter;
    insurancePlan(): InsurancePlanWriter;
    invoice(): InvoiceWriter;
    library(): LibraryWriter;
    linkage(): LinkageWriter;
    list(): ListWriter;
    measure(): MeasureWriter;
    measureReport(): MeasureReportWriter;
    media(): MediaWriter;
    medication(): MedicationWriter;
    medicationAdministration(): MedicationAdministrationWriter;
    medicationDispense(): MedicationDispenseWriter;
    medicationKnowledge(): MedicationKnowledgeWriter;
    medicationRequest(): MedicationRequestWriter;
    medicationStatement(): MedicationStatementWriter;
    medicinalProduct(): MedicinalProductWriter;
    messageDefinition(): MessageDefinitionWriter;
    messageHeader(): MessageHeaderWriter;
    molecularSequence(): MolecularSequenceWriter;
    namingSystem(): NamingSystemWriter;
    nutritionOrder(): NutritionOrderWriter;
    observation(): ObservationWriter;
    observationDefinition(): ObservationDefinitionWriter;
    operationDefinition(): OperationDefinitionWriter;
    operationOutcome(): OperationOutcomeWriter;
    organizationAffiliation(): OrganizationAffiliationWriter;
    parameters(): ParametersWriter;
    paymentNotice(): PaymentNoticeWriter;
    paymentReconciliation(): PaymentReconciliationWriter;
    person(): PersonWriter;
    planDefinition(): PlanDefinitionWriter;
    procedure(): ProcedureWriter;
    provenance(): ProvenanceWriter;
    questionnaire(): QuestionnaireWriter;
    questionnaireResponse(): QuestionnaireResponseWriter;
    relatedPerson(): RelatedPersonWriter;
    requestGroup(): RequestGroupWriter;
    researchDefinition(): ResearchDefinitionWriter;
    researchElementDefinition(): ResearchElementDefinitionWriter;
    researchStudy(): ResearchStudyWriter;
    researchSubject(): ResearchSubjectWriter;
    riskAssessment(): RiskAssessmentWriter;
    riskEvidenceSynthesis(): RiskEvidenceSynthesisWriter;
    schedule(): ScheduleWriter;
    searchParameter(): SearchParameterWriter;
    slot(): SlotWriter;
    specimen(): SpecimenWriter;
    specimenDefinition(): SpecimenDefinitionWriter;
    structureDefinition(): StructureDefinitionWriter;
    structureMap(): StructureMapWriter;
    subscription(): SubscriptionWriter;
    substance(): SubstanceWriter;
    substanceSpecification(): SubstanceSpecificationWriter;
    supplyDelivery(): SupplyDeliveryWriter;
    supplyRequest(): SupplyRequestWriter;
    task(): TaskWriter;
    terminologyCapabilities(): TerminologyCapabilitiesWriter;
    testReport(): TestReportWriter;
    testScript(): TestScriptWriter;
    valueSet(): ValueSetWriter;
    verificationResult(): VerificationResultWriter;
    visionPrescription(): VisionPrescriptionWriter;
}
/**
 * Main FHIR Client — works with plain fetch or an authenticated fetch wrapper.
 *
 * @example
 * // Unauthenticated
 * const client = new FhirClient("https://fhir.example.com");
 *
 * // With custom fetch (e.g. from SmartFhirClient)
 * const client = new FhirClient("https://fhir.example.com", authenticatedFetch);
 *
 * // Read base R4 resources
 * const patient = await client.read().patient().read("123");
 *
 * // Read profiled resources
 * const coverage = await client.read().pASCoverage().searchAll({});
 *
 * // Generic access for any resource type
 * const custom = await client.read().resource<MyType>("CustomResource").read("456");
 */
export declare class FhirClient {
    readonly baseUrl: string;
    private readonly readClient;
    private readonly writeClient;
    constructor(baseUrl: string, fetchFn?: FetchFn);
    /**
     * Get a read client for querying resources
     */
    read(): FhirReadClient;
    /**
     * Get a write client for creating/updating resources
     */
    write(): FhirWriteClient;
}
