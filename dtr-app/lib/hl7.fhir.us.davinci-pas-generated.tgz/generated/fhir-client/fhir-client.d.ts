import { type PASBeneficiaryReader, type PASCommunicationRequestReader, type PASCoverageReader, type PASDeviceRequestReader, type PASEncounterReader, type PASInsurerReader, type PASLocationReader, type PASOrganizationReader, type PASPractitionerReader, type PASPractitionerRoleReader, type PASRequestorReader, type PASServiceRequestReader, type PASSubscriberReader, type FetchFn } from "./resource-reader.js";
import { type PASBeneficiaryWriter, type PASCommunicationRequestWriter, type PASCoverageWriter, type PASDeviceRequestWriter, type PASEncounterWriter, type PASInsurerWriter, type PASLocationWriter, type PASOrganizationWriter, type PASPractitionerWriter, type PASPractitionerRoleWriter, type PASRequestorWriter, type PASServiceRequestWriter, type PASSubscriberWriter } from "./resource-writer.js";
/**
 * FHIR Client for reading resources
 */
export declare class FhirReadClient {
    private readonly baseUrl;
    private readonly fetchFn?;
    constructor(baseUrl: string, fetchFn?: FetchFn);
    pASBeneficiary(): PASBeneficiaryReader;
    pASCommunicationRequest(): PASCommunicationRequestReader;
    pASCoverage(): PASCoverageReader;
    pASDeviceRequest(): PASDeviceRequestReader;
    pASEncounter(): PASEncounterReader;
    pASInsurer(): PASInsurerReader;
    pASLocation(): PASLocationReader;
    pASOrganization(): PASOrganizationReader;
    pASPractitioner(): PASPractitionerReader;
    pASPractitionerRole(): PASPractitionerRoleReader;
    pASRequestor(): PASRequestorReader;
    pASServiceRequest(): PASServiceRequestReader;
    pASSubscriber(): PASSubscriberReader;
}
/**
 * FHIR Client for writing resources
 */
export declare class FhirWriteClient {
    private readonly baseUrl;
    private readonly fetchFn?;
    constructor(baseUrl: string, fetchFn?: FetchFn);
    pASBeneficiary(): PASBeneficiaryWriter;
    pASCommunicationRequest(): PASCommunicationRequestWriter;
    pASCoverage(): PASCoverageWriter;
    pASDeviceRequest(): PASDeviceRequestWriter;
    pASEncounter(): PASEncounterWriter;
    pASInsurer(): PASInsurerWriter;
    pASLocation(): PASLocationWriter;
    pASOrganization(): PASOrganizationWriter;
    pASPractitioner(): PASPractitionerWriter;
    pASPractitionerRole(): PASPractitionerRoleWriter;
    pASRequestor(): PASRequestorWriter;
    pASServiceRequest(): PASServiceRequestWriter;
    pASSubscriber(): PASSubscriberWriter;
}
/**
 * Main FHIR Client — works with plain fetch or an authenticated fetch wrapper.
 *
 * @example
 * // Unauthenticated
 * const client = new FhirClient("https://fhir.example.com");
 *
 * // With custom fetch (e.g. from SmartFhirClient)
 * const client = new FhirClient("https://fhir.example.com", authenticatedFetch);
 */
export declare class FhirClient {
    readonly baseUrl: string;
    private readonly readClient;
    private readonly writeClient;
    constructor(baseUrl: string, fetchFn?: FetchFn);
    /**
     * Get a read client for querying resources
     */
    read(): FhirReadClient;
    /**
     * Get a write client for creating/updating resources
     */
    write(): FhirWriteClient;
}
