/**
 * FHIR Bundle Parser - provides type-safe parsing and filtering of FHIR Bundles
 */
export class BundleParser {
    constructor(bundle) {
        this.bundle = bundle;
    }
    /**
     * Get all resources from the bundle
     */
    getAllResources() {
        return this.bundle.entry?.map(e => e.resource).filter((r) => r !== undefined) || [];
    }
    /**
     * Get resources of a specific type
     */
    getResourcesByType(resourceType) {
        const entries = this.getAllEntries();
        switch (resourceType) {
            case 'Patient':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Patient')
                    .map(e => e.resource);
            case 'CommunicationRequest':
                return entries
                    .filter((e) => e.resource?.resourceType === 'CommunicationRequest')
                    .map(e => e.resource);
            case 'Coverage':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Coverage')
                    .map(e => e.resource);
            case 'DeviceRequest':
                return entries
                    .filter((e) => e.resource?.resourceType === 'DeviceRequest')
                    .map(e => e.resource);
            case 'Encounter':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Encounter')
                    .map(e => e.resource);
            case 'Organization':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Organization')
                    .map(e => e.resource);
            case 'Location':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Location')
                    .map(e => e.resource);
            case 'Practitioner':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Practitioner')
                    .map(e => e.resource);
            case 'PractitionerRole':
                return entries
                    .filter((e) => e.resource?.resourceType === 'PractitionerRole')
                    .map(e => e.resource);
            case 'ServiceRequest':
                return entries
                    .filter((e) => e.resource?.resourceType === 'ServiceRequest')
                    .map(e => e.resource);
            case 'Account':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Account')
                    .map(e => e.resource);
            case 'ActivityDefinition':
                return entries
                    .filter((e) => e.resource?.resourceType === 'ActivityDefinition')
                    .map(e => e.resource);
            case 'AdverseEvent':
                return entries
                    .filter((e) => e.resource?.resourceType === 'AdverseEvent')
                    .map(e => e.resource);
            case 'AllergyIntolerance':
                return entries
                    .filter((e) => e.resource?.resourceType === 'AllergyIntolerance')
                    .map(e => e.resource);
            case 'Appointment':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Appointment')
                    .map(e => e.resource);
            case 'AppointmentResponse':
                return entries
                    .filter((e) => e.resource?.resourceType === 'AppointmentResponse')
                    .map(e => e.resource);
            case 'AuditEvent':
                return entries
                    .filter((e) => e.resource?.resourceType === 'AuditEvent')
                    .map(e => e.resource);
            case 'Basic':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Basic')
                    .map(e => e.resource);
            case 'Binary':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Binary')
                    .map(e => e.resource);
            case 'BiologicallyDerivedProduct':
                return entries
                    .filter((e) => e.resource?.resourceType === 'BiologicallyDerivedProduct')
                    .map(e => e.resource);
            case 'BodyStructure':
                return entries
                    .filter((e) => e.resource?.resourceType === 'BodyStructure')
                    .map(e => e.resource);
            case 'CapabilityStatement':
                return entries
                    .filter((e) => e.resource?.resourceType === 'CapabilityStatement')
                    .map(e => e.resource);
            case 'CarePlan':
                return entries
                    .filter((e) => e.resource?.resourceType === 'CarePlan')
                    .map(e => e.resource);
            case 'CareTeam':
                return entries
                    .filter((e) => e.resource?.resourceType === 'CareTeam')
                    .map(e => e.resource);
            case 'ChargeItem':
                return entries
                    .filter((e) => e.resource?.resourceType === 'ChargeItem')
                    .map(e => e.resource);
            case 'ChargeItemDefinition':
                return entries
                    .filter((e) => e.resource?.resourceType === 'ChargeItemDefinition')
                    .map(e => e.resource);
            case 'Claim':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Claim')
                    .map(e => e.resource);
            case 'ClaimResponse':
                return entries
                    .filter((e) => e.resource?.resourceType === 'ClaimResponse')
                    .map(e => e.resource);
            case 'ClinicalImpression':
                return entries
                    .filter((e) => e.resource?.resourceType === 'ClinicalImpression')
                    .map(e => e.resource);
            case 'CodeSystem':
                return entries
                    .filter((e) => e.resource?.resourceType === 'CodeSystem')
                    .map(e => e.resource);
            case 'Communication':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Communication')
                    .map(e => e.resource);
            case 'CompartmentDefinition':
                return entries
                    .filter((e) => e.resource?.resourceType === 'CompartmentDefinition')
                    .map(e => e.resource);
            case 'Composition':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Composition')
                    .map(e => e.resource);
            case 'ConceptMap':
                return entries
                    .filter((e) => e.resource?.resourceType === 'ConceptMap')
                    .map(e => e.resource);
            case 'Condition':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Condition')
                    .map(e => e.resource);
            case 'Consent':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Consent')
                    .map(e => e.resource);
            case 'Contract':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Contract')
                    .map(e => e.resource);
            case 'CoverageEligibilityRequest':
                return entries
                    .filter((e) => e.resource?.resourceType === 'CoverageEligibilityRequest')
                    .map(e => e.resource);
            case 'CoverageEligibilityResponse':
                return entries
                    .filter((e) => e.resource?.resourceType === 'CoverageEligibilityResponse')
                    .map(e => e.resource);
            case 'DetectedIssue':
                return entries
                    .filter((e) => e.resource?.resourceType === 'DetectedIssue')
                    .map(e => e.resource);
            case 'Device':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Device')
                    .map(e => e.resource);
            case 'DeviceDefinition':
                return entries
                    .filter((e) => e.resource?.resourceType === 'DeviceDefinition')
                    .map(e => e.resource);
            case 'DeviceMetric':
                return entries
                    .filter((e) => e.resource?.resourceType === 'DeviceMetric')
                    .map(e => e.resource);
            case 'DeviceUseStatement':
                return entries
                    .filter((e) => e.resource?.resourceType === 'DeviceUseStatement')
                    .map(e => e.resource);
            case 'DiagnosticReport':
                return entries
                    .filter((e) => e.resource?.resourceType === 'DiagnosticReport')
                    .map(e => e.resource);
            case 'DocumentManifest':
                return entries
                    .filter((e) => e.resource?.resourceType === 'DocumentManifest')
                    .map(e => e.resource);
            case 'DocumentReference':
                return entries
                    .filter((e) => e.resource?.resourceType === 'DocumentReference')
                    .map(e => e.resource);
            case 'Endpoint':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Endpoint')
                    .map(e => e.resource);
            case 'EnrollmentRequest':
                return entries
                    .filter((e) => e.resource?.resourceType === 'EnrollmentRequest')
                    .map(e => e.resource);
            case 'EnrollmentResponse':
                return entries
                    .filter((e) => e.resource?.resourceType === 'EnrollmentResponse')
                    .map(e => e.resource);
            case 'EpisodeOfCare':
                return entries
                    .filter((e) => e.resource?.resourceType === 'EpisodeOfCare')
                    .map(e => e.resource);
            case 'EventDefinition':
                return entries
                    .filter((e) => e.resource?.resourceType === 'EventDefinition')
                    .map(e => e.resource);
            case 'Evidence':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Evidence')
                    .map(e => e.resource);
            case 'EvidenceVariable':
                return entries
                    .filter((e) => e.resource?.resourceType === 'EvidenceVariable')
                    .map(e => e.resource);
            case 'ExampleScenario':
                return entries
                    .filter((e) => e.resource?.resourceType === 'ExampleScenario')
                    .map(e => e.resource);
            case 'ExplanationOfBenefit':
                return entries
                    .filter((e) => e.resource?.resourceType === 'ExplanationOfBenefit')
                    .map(e => e.resource);
            case 'FamilyMemberHistory':
                return entries
                    .filter((e) => e.resource?.resourceType === 'FamilyMemberHistory')
                    .map(e => e.resource);
            case 'Flag':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Flag')
                    .map(e => e.resource);
            case 'Goal':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Goal')
                    .map(e => e.resource);
            case 'GraphDefinition':
                return entries
                    .filter((e) => e.resource?.resourceType === 'GraphDefinition')
                    .map(e => e.resource);
            case 'Group':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Group')
                    .map(e => e.resource);
            case 'GuidanceResponse':
                return entries
                    .filter((e) => e.resource?.resourceType === 'GuidanceResponse')
                    .map(e => e.resource);
            case 'HealthcareService':
                return entries
                    .filter((e) => e.resource?.resourceType === 'HealthcareService')
                    .map(e => e.resource);
            case 'ImagingStudy':
                return entries
                    .filter((e) => e.resource?.resourceType === 'ImagingStudy')
                    .map(e => e.resource);
            case 'Immunization':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Immunization')
                    .map(e => e.resource);
            case 'ImmunizationEvaluation':
                return entries
                    .filter((e) => e.resource?.resourceType === 'ImmunizationEvaluation')
                    .map(e => e.resource);
            case 'ImmunizationRecommendation':
                return entries
                    .filter((e) => e.resource?.resourceType === 'ImmunizationRecommendation')
                    .map(e => e.resource);
            case 'ImplementationGuide':
                return entries
                    .filter((e) => e.resource?.resourceType === 'ImplementationGuide')
                    .map(e => e.resource);
            case 'InsurancePlan':
                return entries
                    .filter((e) => e.resource?.resourceType === 'InsurancePlan')
                    .map(e => e.resource);
            case 'Invoice':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Invoice')
                    .map(e => e.resource);
            case 'Library':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Library')
                    .map(e => e.resource);
            case 'Linkage':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Linkage')
                    .map(e => e.resource);
            case 'List':
                return entries
                    .filter((e) => e.resource?.resourceType === 'List')
                    .map(e => e.resource);
            case 'Measure':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Measure')
                    .map(e => e.resource);
            case 'MeasureReport':
                return entries
                    .filter((e) => e.resource?.resourceType === 'MeasureReport')
                    .map(e => e.resource);
            case 'Media':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Media')
                    .map(e => e.resource);
            case 'Medication':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Medication')
                    .map(e => e.resource);
            case 'MedicationAdministration':
                return entries
                    .filter((e) => e.resource?.resourceType === 'MedicationAdministration')
                    .map(e => e.resource);
            case 'MedicationDispense':
                return entries
                    .filter((e) => e.resource?.resourceType === 'MedicationDispense')
                    .map(e => e.resource);
            case 'MedicationKnowledge':
                return entries
                    .filter((e) => e.resource?.resourceType === 'MedicationKnowledge')
                    .map(e => e.resource);
            case 'MedicationRequest':
                return entries
                    .filter((e) => e.resource?.resourceType === 'MedicationRequest')
                    .map(e => e.resource);
            case 'MedicationStatement':
                return entries
                    .filter((e) => e.resource?.resourceType === 'MedicationStatement')
                    .map(e => e.resource);
            case 'MedicinalProduct':
                return entries
                    .filter((e) => e.resource?.resourceType === 'MedicinalProduct')
                    .map(e => e.resource);
            case 'MessageDefinition':
                return entries
                    .filter((e) => e.resource?.resourceType === 'MessageDefinition')
                    .map(e => e.resource);
            case 'MessageHeader':
                return entries
                    .filter((e) => e.resource?.resourceType === 'MessageHeader')
                    .map(e => e.resource);
            case 'MolecularSequence':
                return entries
                    .filter((e) => e.resource?.resourceType === 'MolecularSequence')
                    .map(e => e.resource);
            case 'NamingSystem':
                return entries
                    .filter((e) => e.resource?.resourceType === 'NamingSystem')
                    .map(e => e.resource);
            case 'NutritionOrder':
                return entries
                    .filter((e) => e.resource?.resourceType === 'NutritionOrder')
                    .map(e => e.resource);
            case 'Observation':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Observation')
                    .map(e => e.resource);
            case 'ObservationDefinition':
                return entries
                    .filter((e) => e.resource?.resourceType === 'ObservationDefinition')
                    .map(e => e.resource);
            case 'OperationDefinition':
                return entries
                    .filter((e) => e.resource?.resourceType === 'OperationDefinition')
                    .map(e => e.resource);
            case 'OperationOutcome':
                return entries
                    .filter((e) => e.resource?.resourceType === 'OperationOutcome')
                    .map(e => e.resource);
            case 'OrganizationAffiliation':
                return entries
                    .filter((e) => e.resource?.resourceType === 'OrganizationAffiliation')
                    .map(e => e.resource);
            case 'Parameters':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Parameters')
                    .map(e => e.resource);
            case 'PaymentNotice':
                return entries
                    .filter((e) => e.resource?.resourceType === 'PaymentNotice')
                    .map(e => e.resource);
            case 'PaymentReconciliation':
                return entries
                    .filter((e) => e.resource?.resourceType === 'PaymentReconciliation')
                    .map(e => e.resource);
            case 'Person':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Person')
                    .map(e => e.resource);
            case 'PlanDefinition':
                return entries
                    .filter((e) => e.resource?.resourceType === 'PlanDefinition')
                    .map(e => e.resource);
            case 'Procedure':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Procedure')
                    .map(e => e.resource);
            case 'Provenance':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Provenance')
                    .map(e => e.resource);
            case 'Questionnaire':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Questionnaire')
                    .map(e => e.resource);
            case 'QuestionnaireResponse':
                return entries
                    .filter((e) => e.resource?.resourceType === 'QuestionnaireResponse')
                    .map(e => e.resource);
            case 'RelatedPerson':
                return entries
                    .filter((e) => e.resource?.resourceType === 'RelatedPerson')
                    .map(e => e.resource);
            case 'RequestGroup':
                return entries
                    .filter((e) => e.resource?.resourceType === 'RequestGroup')
                    .map(e => e.resource);
            case 'ResearchDefinition':
                return entries
                    .filter((e) => e.resource?.resourceType === 'ResearchDefinition')
                    .map(e => e.resource);
            case 'ResearchElementDefinition':
                return entries
                    .filter((e) => e.resource?.resourceType === 'ResearchElementDefinition')
                    .map(e => e.resource);
            case 'ResearchStudy':
                return entries
                    .filter((e) => e.resource?.resourceType === 'ResearchStudy')
                    .map(e => e.resource);
            case 'ResearchSubject':
                return entries
                    .filter((e) => e.resource?.resourceType === 'ResearchSubject')
                    .map(e => e.resource);
            case 'RiskAssessment':
                return entries
                    .filter((e) => e.resource?.resourceType === 'RiskAssessment')
                    .map(e => e.resource);
            case 'RiskEvidenceSynthesis':
                return entries
                    .filter((e) => e.resource?.resourceType === 'RiskEvidenceSynthesis')
                    .map(e => e.resource);
            case 'Schedule':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Schedule')
                    .map(e => e.resource);
            case 'SearchParameter':
                return entries
                    .filter((e) => e.resource?.resourceType === 'SearchParameter')
                    .map(e => e.resource);
            case 'Slot':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Slot')
                    .map(e => e.resource);
            case 'Specimen':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Specimen')
                    .map(e => e.resource);
            case 'SpecimenDefinition':
                return entries
                    .filter((e) => e.resource?.resourceType === 'SpecimenDefinition')
                    .map(e => e.resource);
            case 'StructureDefinition':
                return entries
                    .filter((e) => e.resource?.resourceType === 'StructureDefinition')
                    .map(e => e.resource);
            case 'StructureMap':
                return entries
                    .filter((e) => e.resource?.resourceType === 'StructureMap')
                    .map(e => e.resource);
            case 'Subscription':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Subscription')
                    .map(e => e.resource);
            case 'Substance':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Substance')
                    .map(e => e.resource);
            case 'SubstanceSpecification':
                return entries
                    .filter((e) => e.resource?.resourceType === 'SubstanceSpecification')
                    .map(e => e.resource);
            case 'SupplyDelivery':
                return entries
                    .filter((e) => e.resource?.resourceType === 'SupplyDelivery')
                    .map(e => e.resource);
            case 'SupplyRequest':
                return entries
                    .filter((e) => e.resource?.resourceType === 'SupplyRequest')
                    .map(e => e.resource);
            case 'Task':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Task')
                    .map(e => e.resource);
            case 'TerminologyCapabilities':
                return entries
                    .filter((e) => e.resource?.resourceType === 'TerminologyCapabilities')
                    .map(e => e.resource);
            case 'TestReport':
                return entries
                    .filter((e) => e.resource?.resourceType === 'TestReport')
                    .map(e => e.resource);
            case 'TestScript':
                return entries
                    .filter((e) => e.resource?.resourceType === 'TestScript')
                    .map(e => e.resource);
            case 'ValueSet':
                return entries
                    .filter((e) => e.resource?.resourceType === 'ValueSet')
                    .map(e => e.resource);
            case 'VerificationResult':
                return entries
                    .filter((e) => e.resource?.resourceType === 'VerificationResult')
                    .map(e => e.resource);
            case 'VisionPrescription':
                return entries
                    .filter((e) => e.resource?.resourceType === 'VisionPrescription')
                    .map(e => e.resource);
            default:
                return [];
        }
    }
    /**
     * Get the first resource of a specific type
     */
    getFirstResourceByType(resourceType) {
        return this.getResourcesByType(resourceType)[0];
    }
    filterResources(predicate) {
        return this.getAllResources().filter(predicate);
    }
    /**
     * Get all entries (including metadata like fullUrl, search scores, etc.)
     */
    getAllEntries() {
        return (this.bundle.entry || []);
    }
    /**
     * Get entries of a specific resource type
     */
    getEntriesByType(resourceType) {
        return this.getAllEntries().filter((e) => e.resource?.resourceType === resourceType);
    }
    /**
     * Get total count from bundle (if available)
     */
    getTotal() {
        return this.bundle.total;
    }
    /**
     * Get next page URL from bundle links
     */
    getNextUrl() {
        return this.bundle.link?.find(l => l.relation === 'next')?.url;
    }
    /**
     * Get previous page URL from bundle links
     */
    getPreviousUrl() {
        return this.bundle.link?.find(l => l.relation === 'previous')?.url;
    }
    /**
     * Check if bundle has more pages
     */
    hasNextPage() {
        return this.getNextUrl() !== undefined;
    }
    /**
     * Group resources by type
     */
    groupByResourceType() {
        const grouped = new Map();
        for (const resource of this.getAllResources()) {
            const type = resource.resourceType;
            if (!grouped.has(type)) {
                grouped.set(type, []);
            }
            grouped.get(type).push(resource);
        }
        return grouped;
    }
    /**
     * Get bundle type
     */
    getBundleType() {
        return this.bundle.type;
    }
}
/**
 * Parse a FHIR Bundle into a BundleParser instance
 */
export function parseBundle(bundle) {
    return new BundleParser(bundle);
}
