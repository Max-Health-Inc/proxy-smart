import { FhirResourceReader, } from "./resource-reader.js";
import { FhirResourceWriterImpl, } from "./resource-writer.js";
/**
 * FHIR Client for reading resources
 */
export class FhirReadClient {
    constructor(baseUrl, fetchFn) {
        this.baseUrl = baseUrl;
        this.fetchFn = fetchFn;
    }
    pASBeneficiary() {
        return new FhirResourceReader(this.baseUrl, "Patient", this.fetchFn);
    }
    pASCommunicationRequest() {
        return new FhirResourceReader(this.baseUrl, "CommunicationRequest", this.fetchFn);
    }
    pASCoverage() {
        return new FhirResourceReader(this.baseUrl, "Coverage", this.fetchFn);
    }
    pASDeviceRequest() {
        return new FhirResourceReader(this.baseUrl, "DeviceRequest", this.fetchFn);
    }
    pASEncounter() {
        return new FhirResourceReader(this.baseUrl, "Encounter", this.fetchFn);
    }
    pASInsurer() {
        return new FhirResourceReader(this.baseUrl, "Organization", this.fetchFn);
    }
    pASLocation() {
        return new FhirResourceReader(this.baseUrl, "Location", this.fetchFn);
    }
    pASOrganization() {
        return new FhirResourceReader(this.baseUrl, "Organization", this.fetchFn);
    }
    pASPractitioner() {
        return new FhirResourceReader(this.baseUrl, "Practitioner", this.fetchFn);
    }
    pASPractitionerRole() {
        return new FhirResourceReader(this.baseUrl, "PractitionerRole", this.fetchFn);
    }
    pASRequestor() {
        return new FhirResourceReader(this.baseUrl, "Organization", this.fetchFn);
    }
    pASServiceRequest() {
        return new FhirResourceReader(this.baseUrl, "ServiceRequest", this.fetchFn);
    }
    pASSubscriber() {
        return new FhirResourceReader(this.baseUrl, "Patient", this.fetchFn);
    }
}
/**
 * FHIR Client for writing resources
 */
export class FhirWriteClient {
    constructor(baseUrl, fetchFn) {
        this.baseUrl = baseUrl;
        this.fetchFn = fetchFn;
    }
    pASBeneficiary() {
        return new FhirResourceWriterImpl(this.baseUrl, "Patient", this.fetchFn);
    }
    pASCommunicationRequest() {
        return new FhirResourceWriterImpl(this.baseUrl, "CommunicationRequest", this.fetchFn);
    }
    pASCoverage() {
        return new FhirResourceWriterImpl(this.baseUrl, "Coverage", this.fetchFn);
    }
    pASDeviceRequest() {
        return new FhirResourceWriterImpl(this.baseUrl, "DeviceRequest", this.fetchFn);
    }
    pASEncounter() {
        return new FhirResourceWriterImpl(this.baseUrl, "Encounter", this.fetchFn);
    }
    pASInsurer() {
        return new FhirResourceWriterImpl(this.baseUrl, "Organization", this.fetchFn);
    }
    pASLocation() {
        return new FhirResourceWriterImpl(this.baseUrl, "Location", this.fetchFn);
    }
    pASOrganization() {
        return new FhirResourceWriterImpl(this.baseUrl, "Organization", this.fetchFn);
    }
    pASPractitioner() {
        return new FhirResourceWriterImpl(this.baseUrl, "Practitioner", this.fetchFn);
    }
    pASPractitionerRole() {
        return new FhirResourceWriterImpl(this.baseUrl, "PractitionerRole", this.fetchFn);
    }
    pASRequestor() {
        return new FhirResourceWriterImpl(this.baseUrl, "Organization", this.fetchFn);
    }
    pASServiceRequest() {
        return new FhirResourceWriterImpl(this.baseUrl, "ServiceRequest", this.fetchFn);
    }
    pASSubscriber() {
        return new FhirResourceWriterImpl(this.baseUrl, "Patient", this.fetchFn);
    }
}
/**
 * Main FHIR Client — works with plain fetch or an authenticated fetch wrapper.
 *
 * @example
 * // Unauthenticated
 * const client = new FhirClient("https://fhir.example.com");
 *
 * // With custom fetch (e.g. from SmartFhirClient)
 * const client = new FhirClient("https://fhir.example.com", authenticatedFetch);
 */
export class FhirClient {
    constructor(baseUrl, fetchFn) {
        this.baseUrl = baseUrl;
        this.readClient = new FhirReadClient(baseUrl, fetchFn);
        this.writeClient = new FhirWriteClient(baseUrl, fetchFn);
    }
    /**
     * Get a read client for querying resources
     */
    read() {
        return this.readClient;
    }
    /**
     * Get a write client for creating/updating resources
     */
    write() {
        return this.writeClient;
    }
}
