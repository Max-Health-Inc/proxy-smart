import { FhirResourceReader, } from "./resource-reader.js";
import { FhirResourceWriterImpl, } from "./resource-writer.js";
/**
 * FHIR Client for reading resources
 */
export class FhirReadClient {
    constructor(baseUrl, fetchFn) {
        this.baseUrl = baseUrl;
        this.fetchFn = fetchFn;
    }
    /**
     * Generic reader for any FHIR resource type.
     * Use this for resource types not covered by the named methods.
     *
     * @example
     * const reader = client.read().resource<MyCustomType>("CustomResource");
     * const item = await reader.read("123");
     */
    resource(resourceType) {
        return new FhirResourceReader(this.baseUrl, resourceType, this.fetchFn);
    }
    // ── Profiled resource types ──────────────────────────────────────────
    pASBeneficiary() {
        return new FhirResourceReader(this.baseUrl, "Patient", this.fetchFn);
    }
    pASCommunicationRequest() {
        return new FhirResourceReader(this.baseUrl, "CommunicationRequest", this.fetchFn);
    }
    pASCoverage() {
        return new FhirResourceReader(this.baseUrl, "Coverage", this.fetchFn);
    }
    pASDeviceRequest() {
        return new FhirResourceReader(this.baseUrl, "DeviceRequest", this.fetchFn);
    }
    pASEncounter() {
        return new FhirResourceReader(this.baseUrl, "Encounter", this.fetchFn);
    }
    pASInsurer() {
        return new FhirResourceReader(this.baseUrl, "Organization", this.fetchFn);
    }
    pASLocation() {
        return new FhirResourceReader(this.baseUrl, "Location", this.fetchFn);
    }
    pASOrganization() {
        return new FhirResourceReader(this.baseUrl, "Organization", this.fetchFn);
    }
    pASPractitioner() {
        return new FhirResourceReader(this.baseUrl, "Practitioner", this.fetchFn);
    }
    pASPractitionerRole() {
        return new FhirResourceReader(this.baseUrl, "PractitionerRole", this.fetchFn);
    }
    pASRequestor() {
        return new FhirResourceReader(this.baseUrl, "Organization", this.fetchFn);
    }
    pASServiceRequest() {
        return new FhirResourceReader(this.baseUrl, "ServiceRequest", this.fetchFn);
    }
    pASSubscriber() {
        return new FhirResourceReader(this.baseUrl, "Patient", this.fetchFn);
    }
    // ── Base FHIR R4 resource types ──────────────────────────────────────
    account() {
        return new FhirResourceReader(this.baseUrl, "Account", this.fetchFn);
    }
    activityDefinition() {
        return new FhirResourceReader(this.baseUrl, "ActivityDefinition", this.fetchFn);
    }
    adverseEvent() {
        return new FhirResourceReader(this.baseUrl, "AdverseEvent", this.fetchFn);
    }
    allergyIntolerance() {
        return new FhirResourceReader(this.baseUrl, "AllergyIntolerance", this.fetchFn);
    }
    appointment() {
        return new FhirResourceReader(this.baseUrl, "Appointment", this.fetchFn);
    }
    appointmentResponse() {
        return new FhirResourceReader(this.baseUrl, "AppointmentResponse", this.fetchFn);
    }
    auditEvent() {
        return new FhirResourceReader(this.baseUrl, "AuditEvent", this.fetchFn);
    }
    basic() {
        return new FhirResourceReader(this.baseUrl, "Basic", this.fetchFn);
    }
    binary() {
        return new FhirResourceReader(this.baseUrl, "Binary", this.fetchFn);
    }
    biologicallyDerivedProduct() {
        return new FhirResourceReader(this.baseUrl, "BiologicallyDerivedProduct", this.fetchFn);
    }
    bodyStructure() {
        return new FhirResourceReader(this.baseUrl, "BodyStructure", this.fetchFn);
    }
    capabilityStatement() {
        return new FhirResourceReader(this.baseUrl, "CapabilityStatement", this.fetchFn);
    }
    carePlan() {
        return new FhirResourceReader(this.baseUrl, "CarePlan", this.fetchFn);
    }
    careTeam() {
        return new FhirResourceReader(this.baseUrl, "CareTeam", this.fetchFn);
    }
    chargeItem() {
        return new FhirResourceReader(this.baseUrl, "ChargeItem", this.fetchFn);
    }
    chargeItemDefinition() {
        return new FhirResourceReader(this.baseUrl, "ChargeItemDefinition", this.fetchFn);
    }
    claim() {
        return new FhirResourceReader(this.baseUrl, "Claim", this.fetchFn);
    }
    claimResponse() {
        return new FhirResourceReader(this.baseUrl, "ClaimResponse", this.fetchFn);
    }
    clinicalImpression() {
        return new FhirResourceReader(this.baseUrl, "ClinicalImpression", this.fetchFn);
    }
    codeSystem() {
        return new FhirResourceReader(this.baseUrl, "CodeSystem", this.fetchFn);
    }
    communication() {
        return new FhirResourceReader(this.baseUrl, "Communication", this.fetchFn);
    }
    compartmentDefinition() {
        return new FhirResourceReader(this.baseUrl, "CompartmentDefinition", this.fetchFn);
    }
    composition() {
        return new FhirResourceReader(this.baseUrl, "Composition", this.fetchFn);
    }
    conceptMap() {
        return new FhirResourceReader(this.baseUrl, "ConceptMap", this.fetchFn);
    }
    condition() {
        return new FhirResourceReader(this.baseUrl, "Condition", this.fetchFn);
    }
    consent() {
        return new FhirResourceReader(this.baseUrl, "Consent", this.fetchFn);
    }
    contract() {
        return new FhirResourceReader(this.baseUrl, "Contract", this.fetchFn);
    }
    coverageEligibilityRequest() {
        return new FhirResourceReader(this.baseUrl, "CoverageEligibilityRequest", this.fetchFn);
    }
    coverageEligibilityResponse() {
        return new FhirResourceReader(this.baseUrl, "CoverageEligibilityResponse", this.fetchFn);
    }
    detectedIssue() {
        return new FhirResourceReader(this.baseUrl, "DetectedIssue", this.fetchFn);
    }
    device() {
        return new FhirResourceReader(this.baseUrl, "Device", this.fetchFn);
    }
    deviceDefinition() {
        return new FhirResourceReader(this.baseUrl, "DeviceDefinition", this.fetchFn);
    }
    deviceMetric() {
        return new FhirResourceReader(this.baseUrl, "DeviceMetric", this.fetchFn);
    }
    deviceUseStatement() {
        return new FhirResourceReader(this.baseUrl, "DeviceUseStatement", this.fetchFn);
    }
    diagnosticReport() {
        return new FhirResourceReader(this.baseUrl, "DiagnosticReport", this.fetchFn);
    }
    documentManifest() {
        return new FhirResourceReader(this.baseUrl, "DocumentManifest", this.fetchFn);
    }
    documentReference() {
        return new FhirResourceReader(this.baseUrl, "DocumentReference", this.fetchFn);
    }
    endpoint() {
        return new FhirResourceReader(this.baseUrl, "Endpoint", this.fetchFn);
    }
    enrollmentRequest() {
        return new FhirResourceReader(this.baseUrl, "EnrollmentRequest", this.fetchFn);
    }
    enrollmentResponse() {
        return new FhirResourceReader(this.baseUrl, "EnrollmentResponse", this.fetchFn);
    }
    episodeOfCare() {
        return new FhirResourceReader(this.baseUrl, "EpisodeOfCare", this.fetchFn);
    }
    eventDefinition() {
        return new FhirResourceReader(this.baseUrl, "EventDefinition", this.fetchFn);
    }
    evidence() {
        return new FhirResourceReader(this.baseUrl, "Evidence", this.fetchFn);
    }
    evidenceVariable() {
        return new FhirResourceReader(this.baseUrl, "EvidenceVariable", this.fetchFn);
    }
    exampleScenario() {
        return new FhirResourceReader(this.baseUrl, "ExampleScenario", this.fetchFn);
    }
    explanationOfBenefit() {
        return new FhirResourceReader(this.baseUrl, "ExplanationOfBenefit", this.fetchFn);
    }
    familyMemberHistory() {
        return new FhirResourceReader(this.baseUrl, "FamilyMemberHistory", this.fetchFn);
    }
    flag() {
        return new FhirResourceReader(this.baseUrl, "Flag", this.fetchFn);
    }
    goal() {
        return new FhirResourceReader(this.baseUrl, "Goal", this.fetchFn);
    }
    graphDefinition() {
        return new FhirResourceReader(this.baseUrl, "GraphDefinition", this.fetchFn);
    }
    group() {
        return new FhirResourceReader(this.baseUrl, "Group", this.fetchFn);
    }
    guidanceResponse() {
        return new FhirResourceReader(this.baseUrl, "GuidanceResponse", this.fetchFn);
    }
    healthcareService() {
        return new FhirResourceReader(this.baseUrl, "HealthcareService", this.fetchFn);
    }
    imagingStudy() {
        return new FhirResourceReader(this.baseUrl, "ImagingStudy", this.fetchFn);
    }
    immunization() {
        return new FhirResourceReader(this.baseUrl, "Immunization", this.fetchFn);
    }
    immunizationEvaluation() {
        return new FhirResourceReader(this.baseUrl, "ImmunizationEvaluation", this.fetchFn);
    }
    immunizationRecommendation() {
        return new FhirResourceReader(this.baseUrl, "ImmunizationRecommendation", this.fetchFn);
    }
    implementationGuide() {
        return new FhirResourceReader(this.baseUrl, "ImplementationGuide", this.fetchFn);
    }
    insurancePlan() {
        return new FhirResourceReader(this.baseUrl, "InsurancePlan", this.fetchFn);
    }
    invoice() {
        return new FhirResourceReader(this.baseUrl, "Invoice", this.fetchFn);
    }
    library() {
        return new FhirResourceReader(this.baseUrl, "Library", this.fetchFn);
    }
    linkage() {
        return new FhirResourceReader(this.baseUrl, "Linkage", this.fetchFn);
    }
    list() {
        return new FhirResourceReader(this.baseUrl, "List", this.fetchFn);
    }
    measure() {
        return new FhirResourceReader(this.baseUrl, "Measure", this.fetchFn);
    }
    measureReport() {
        return new FhirResourceReader(this.baseUrl, "MeasureReport", this.fetchFn);
    }
    media() {
        return new FhirResourceReader(this.baseUrl, "Media", this.fetchFn);
    }
    medication() {
        return new FhirResourceReader(this.baseUrl, "Medication", this.fetchFn);
    }
    medicationAdministration() {
        return new FhirResourceReader(this.baseUrl, "MedicationAdministration", this.fetchFn);
    }
    medicationDispense() {
        return new FhirResourceReader(this.baseUrl, "MedicationDispense", this.fetchFn);
    }
    medicationKnowledge() {
        return new FhirResourceReader(this.baseUrl, "MedicationKnowledge", this.fetchFn);
    }
    medicationRequest() {
        return new FhirResourceReader(this.baseUrl, "MedicationRequest", this.fetchFn);
    }
    medicationStatement() {
        return new FhirResourceReader(this.baseUrl, "MedicationStatement", this.fetchFn);
    }
    medicinalProduct() {
        return new FhirResourceReader(this.baseUrl, "MedicinalProduct", this.fetchFn);
    }
    messageDefinition() {
        return new FhirResourceReader(this.baseUrl, "MessageDefinition", this.fetchFn);
    }
    messageHeader() {
        return new FhirResourceReader(this.baseUrl, "MessageHeader", this.fetchFn);
    }
    molecularSequence() {
        return new FhirResourceReader(this.baseUrl, "MolecularSequence", this.fetchFn);
    }
    namingSystem() {
        return new FhirResourceReader(this.baseUrl, "NamingSystem", this.fetchFn);
    }
    nutritionOrder() {
        return new FhirResourceReader(this.baseUrl, "NutritionOrder", this.fetchFn);
    }
    observation() {
        return new FhirResourceReader(this.baseUrl, "Observation", this.fetchFn);
    }
    observationDefinition() {
        return new FhirResourceReader(this.baseUrl, "ObservationDefinition", this.fetchFn);
    }
    operationDefinition() {
        return new FhirResourceReader(this.baseUrl, "OperationDefinition", this.fetchFn);
    }
    operationOutcome() {
        return new FhirResourceReader(this.baseUrl, "OperationOutcome", this.fetchFn);
    }
    organizationAffiliation() {
        return new FhirResourceReader(this.baseUrl, "OrganizationAffiliation", this.fetchFn);
    }
    parameters() {
        return new FhirResourceReader(this.baseUrl, "Parameters", this.fetchFn);
    }
    paymentNotice() {
        return new FhirResourceReader(this.baseUrl, "PaymentNotice", this.fetchFn);
    }
    paymentReconciliation() {
        return new FhirResourceReader(this.baseUrl, "PaymentReconciliation", this.fetchFn);
    }
    person() {
        return new FhirResourceReader(this.baseUrl, "Person", this.fetchFn);
    }
    planDefinition() {
        return new FhirResourceReader(this.baseUrl, "PlanDefinition", this.fetchFn);
    }
    procedure() {
        return new FhirResourceReader(this.baseUrl, "Procedure", this.fetchFn);
    }
    provenance() {
        return new FhirResourceReader(this.baseUrl, "Provenance", this.fetchFn);
    }
    questionnaire() {
        return new FhirResourceReader(this.baseUrl, "Questionnaire", this.fetchFn);
    }
    questionnaireResponse() {
        return new FhirResourceReader(this.baseUrl, "QuestionnaireResponse", this.fetchFn);
    }
    relatedPerson() {
        return new FhirResourceReader(this.baseUrl, "RelatedPerson", this.fetchFn);
    }
    requestGroup() {
        return new FhirResourceReader(this.baseUrl, "RequestGroup", this.fetchFn);
    }
    researchDefinition() {
        return new FhirResourceReader(this.baseUrl, "ResearchDefinition", this.fetchFn);
    }
    researchElementDefinition() {
        return new FhirResourceReader(this.baseUrl, "ResearchElementDefinition", this.fetchFn);
    }
    researchStudy() {
        return new FhirResourceReader(this.baseUrl, "ResearchStudy", this.fetchFn);
    }
    researchSubject() {
        return new FhirResourceReader(this.baseUrl, "ResearchSubject", this.fetchFn);
    }
    riskAssessment() {
        return new FhirResourceReader(this.baseUrl, "RiskAssessment", this.fetchFn);
    }
    riskEvidenceSynthesis() {
        return new FhirResourceReader(this.baseUrl, "RiskEvidenceSynthesis", this.fetchFn);
    }
    schedule() {
        return new FhirResourceReader(this.baseUrl, "Schedule", this.fetchFn);
    }
    searchParameter() {
        return new FhirResourceReader(this.baseUrl, "SearchParameter", this.fetchFn);
    }
    slot() {
        return new FhirResourceReader(this.baseUrl, "Slot", this.fetchFn);
    }
    specimen() {
        return new FhirResourceReader(this.baseUrl, "Specimen", this.fetchFn);
    }
    specimenDefinition() {
        return new FhirResourceReader(this.baseUrl, "SpecimenDefinition", this.fetchFn);
    }
    structureDefinition() {
        return new FhirResourceReader(this.baseUrl, "StructureDefinition", this.fetchFn);
    }
    structureMap() {
        return new FhirResourceReader(this.baseUrl, "StructureMap", this.fetchFn);
    }
    subscription() {
        return new FhirResourceReader(this.baseUrl, "Subscription", this.fetchFn);
    }
    substance() {
        return new FhirResourceReader(this.baseUrl, "Substance", this.fetchFn);
    }
    substanceSpecification() {
        return new FhirResourceReader(this.baseUrl, "SubstanceSpecification", this.fetchFn);
    }
    supplyDelivery() {
        return new FhirResourceReader(this.baseUrl, "SupplyDelivery", this.fetchFn);
    }
    supplyRequest() {
        return new FhirResourceReader(this.baseUrl, "SupplyRequest", this.fetchFn);
    }
    task() {
        return new FhirResourceReader(this.baseUrl, "Task", this.fetchFn);
    }
    terminologyCapabilities() {
        return new FhirResourceReader(this.baseUrl, "TerminologyCapabilities", this.fetchFn);
    }
    testReport() {
        return new FhirResourceReader(this.baseUrl, "TestReport", this.fetchFn);
    }
    testScript() {
        return new FhirResourceReader(this.baseUrl, "TestScript", this.fetchFn);
    }
    valueSet() {
        return new FhirResourceReader(this.baseUrl, "ValueSet", this.fetchFn);
    }
    verificationResult() {
        return new FhirResourceReader(this.baseUrl, "VerificationResult", this.fetchFn);
    }
    visionPrescription() {
        return new FhirResourceReader(this.baseUrl, "VisionPrescription", this.fetchFn);
    }
}
/**
 * FHIR Client for writing resources
 */
export class FhirWriteClient {
    constructor(baseUrl, fetchFn) {
        this.baseUrl = baseUrl;
        this.fetchFn = fetchFn;
    }
    /**
     * Generic writer for any FHIR resource type.
     * Use this for resource types not covered by the named methods.
     *
     * @example
     * const writer = client.write().resource<MyCustomType>("CustomResource");
     * await writer.create(myResource);
     */
    resource(resourceType) {
        return new FhirResourceWriterImpl(this.baseUrl, resourceType, this.fetchFn);
    }
    // ── Profiled resource types ──────────────────────────────────────────
    pASBeneficiary() {
        return new FhirResourceWriterImpl(this.baseUrl, "Patient", this.fetchFn);
    }
    pASCommunicationRequest() {
        return new FhirResourceWriterImpl(this.baseUrl, "CommunicationRequest", this.fetchFn);
    }
    pASCoverage() {
        return new FhirResourceWriterImpl(this.baseUrl, "Coverage", this.fetchFn);
    }
    pASDeviceRequest() {
        return new FhirResourceWriterImpl(this.baseUrl, "DeviceRequest", this.fetchFn);
    }
    pASEncounter() {
        return new FhirResourceWriterImpl(this.baseUrl, "Encounter", this.fetchFn);
    }
    pASInsurer() {
        return new FhirResourceWriterImpl(this.baseUrl, "Organization", this.fetchFn);
    }
    pASLocation() {
        return new FhirResourceWriterImpl(this.baseUrl, "Location", this.fetchFn);
    }
    pASOrganization() {
        return new FhirResourceWriterImpl(this.baseUrl, "Organization", this.fetchFn);
    }
    pASPractitioner() {
        return new FhirResourceWriterImpl(this.baseUrl, "Practitioner", this.fetchFn);
    }
    pASPractitionerRole() {
        return new FhirResourceWriterImpl(this.baseUrl, "PractitionerRole", this.fetchFn);
    }
    pASRequestor() {
        return new FhirResourceWriterImpl(this.baseUrl, "Organization", this.fetchFn);
    }
    pASServiceRequest() {
        return new FhirResourceWriterImpl(this.baseUrl, "ServiceRequest", this.fetchFn);
    }
    pASSubscriber() {
        return new FhirResourceWriterImpl(this.baseUrl, "Patient", this.fetchFn);
    }
    // ── Base FHIR R4 resource types ──────────────────────────────────────
    account() {
        return new FhirResourceWriterImpl(this.baseUrl, "Account", this.fetchFn);
    }
    activityDefinition() {
        return new FhirResourceWriterImpl(this.baseUrl, "ActivityDefinition", this.fetchFn);
    }
    adverseEvent() {
        return new FhirResourceWriterImpl(this.baseUrl, "AdverseEvent", this.fetchFn);
    }
    allergyIntolerance() {
        return new FhirResourceWriterImpl(this.baseUrl, "AllergyIntolerance", this.fetchFn);
    }
    appointment() {
        return new FhirResourceWriterImpl(this.baseUrl, "Appointment", this.fetchFn);
    }
    appointmentResponse() {
        return new FhirResourceWriterImpl(this.baseUrl, "AppointmentResponse", this.fetchFn);
    }
    auditEvent() {
        return new FhirResourceWriterImpl(this.baseUrl, "AuditEvent", this.fetchFn);
    }
    basic() {
        return new FhirResourceWriterImpl(this.baseUrl, "Basic", this.fetchFn);
    }
    binary() {
        return new FhirResourceWriterImpl(this.baseUrl, "Binary", this.fetchFn);
    }
    biologicallyDerivedProduct() {
        return new FhirResourceWriterImpl(this.baseUrl, "BiologicallyDerivedProduct", this.fetchFn);
    }
    bodyStructure() {
        return new FhirResourceWriterImpl(this.baseUrl, "BodyStructure", this.fetchFn);
    }
    capabilityStatement() {
        return new FhirResourceWriterImpl(this.baseUrl, "CapabilityStatement", this.fetchFn);
    }
    carePlan() {
        return new FhirResourceWriterImpl(this.baseUrl, "CarePlan", this.fetchFn);
    }
    careTeam() {
        return new FhirResourceWriterImpl(this.baseUrl, "CareTeam", this.fetchFn);
    }
    chargeItem() {
        return new FhirResourceWriterImpl(this.baseUrl, "ChargeItem", this.fetchFn);
    }
    chargeItemDefinition() {
        return new FhirResourceWriterImpl(this.baseUrl, "ChargeItemDefinition", this.fetchFn);
    }
    claim() {
        return new FhirResourceWriterImpl(this.baseUrl, "Claim", this.fetchFn);
    }
    claimResponse() {
        return new FhirResourceWriterImpl(this.baseUrl, "ClaimResponse", this.fetchFn);
    }
    clinicalImpression() {
        return new FhirResourceWriterImpl(this.baseUrl, "ClinicalImpression", this.fetchFn);
    }
    codeSystem() {
        return new FhirResourceWriterImpl(this.baseUrl, "CodeSystem", this.fetchFn);
    }
    communication() {
        return new FhirResourceWriterImpl(this.baseUrl, "Communication", this.fetchFn);
    }
    compartmentDefinition() {
        return new FhirResourceWriterImpl(this.baseUrl, "CompartmentDefinition", this.fetchFn);
    }
    composition() {
        return new FhirResourceWriterImpl(this.baseUrl, "Composition", this.fetchFn);
    }
    conceptMap() {
        return new FhirResourceWriterImpl(this.baseUrl, "ConceptMap", this.fetchFn);
    }
    condition() {
        return new FhirResourceWriterImpl(this.baseUrl, "Condition", this.fetchFn);
    }
    consent() {
        return new FhirResourceWriterImpl(this.baseUrl, "Consent", this.fetchFn);
    }
    contract() {
        return new FhirResourceWriterImpl(this.baseUrl, "Contract", this.fetchFn);
    }
    coverageEligibilityRequest() {
        return new FhirResourceWriterImpl(this.baseUrl, "CoverageEligibilityRequest", this.fetchFn);
    }
    coverageEligibilityResponse() {
        return new FhirResourceWriterImpl(this.baseUrl, "CoverageEligibilityResponse", this.fetchFn);
    }
    detectedIssue() {
        return new FhirResourceWriterImpl(this.baseUrl, "DetectedIssue", this.fetchFn);
    }
    device() {
        return new FhirResourceWriterImpl(this.baseUrl, "Device", this.fetchFn);
    }
    deviceDefinition() {
        return new FhirResourceWriterImpl(this.baseUrl, "DeviceDefinition", this.fetchFn);
    }
    deviceMetric() {
        return new FhirResourceWriterImpl(this.baseUrl, "DeviceMetric", this.fetchFn);
    }
    deviceUseStatement() {
        return new FhirResourceWriterImpl(this.baseUrl, "DeviceUseStatement", this.fetchFn);
    }
    diagnosticReport() {
        return new FhirResourceWriterImpl(this.baseUrl, "DiagnosticReport", this.fetchFn);
    }
    documentManifest() {
        return new FhirResourceWriterImpl(this.baseUrl, "DocumentManifest", this.fetchFn);
    }
    documentReference() {
        return new FhirResourceWriterImpl(this.baseUrl, "DocumentReference", this.fetchFn);
    }
    endpoint() {
        return new FhirResourceWriterImpl(this.baseUrl, "Endpoint", this.fetchFn);
    }
    enrollmentRequest() {
        return new FhirResourceWriterImpl(this.baseUrl, "EnrollmentRequest", this.fetchFn);
    }
    enrollmentResponse() {
        return new FhirResourceWriterImpl(this.baseUrl, "EnrollmentResponse", this.fetchFn);
    }
    episodeOfCare() {
        return new FhirResourceWriterImpl(this.baseUrl, "EpisodeOfCare", this.fetchFn);
    }
    eventDefinition() {
        return new FhirResourceWriterImpl(this.baseUrl, "EventDefinition", this.fetchFn);
    }
    evidence() {
        return new FhirResourceWriterImpl(this.baseUrl, "Evidence", this.fetchFn);
    }
    evidenceVariable() {
        return new FhirResourceWriterImpl(this.baseUrl, "EvidenceVariable", this.fetchFn);
    }
    exampleScenario() {
        return new FhirResourceWriterImpl(this.baseUrl, "ExampleScenario", this.fetchFn);
    }
    explanationOfBenefit() {
        return new FhirResourceWriterImpl(this.baseUrl, "ExplanationOfBenefit", this.fetchFn);
    }
    familyMemberHistory() {
        return new FhirResourceWriterImpl(this.baseUrl, "FamilyMemberHistory", this.fetchFn);
    }
    flag() {
        return new FhirResourceWriterImpl(this.baseUrl, "Flag", this.fetchFn);
    }
    goal() {
        return new FhirResourceWriterImpl(this.baseUrl, "Goal", this.fetchFn);
    }
    graphDefinition() {
        return new FhirResourceWriterImpl(this.baseUrl, "GraphDefinition", this.fetchFn);
    }
    group() {
        return new FhirResourceWriterImpl(this.baseUrl, "Group", this.fetchFn);
    }
    guidanceResponse() {
        return new FhirResourceWriterImpl(this.baseUrl, "GuidanceResponse", this.fetchFn);
    }
    healthcareService() {
        return new FhirResourceWriterImpl(this.baseUrl, "HealthcareService", this.fetchFn);
    }
    imagingStudy() {
        return new FhirResourceWriterImpl(this.baseUrl, "ImagingStudy", this.fetchFn);
    }
    immunization() {
        return new FhirResourceWriterImpl(this.baseUrl, "Immunization", this.fetchFn);
    }
    immunizationEvaluation() {
        return new FhirResourceWriterImpl(this.baseUrl, "ImmunizationEvaluation", this.fetchFn);
    }
    immunizationRecommendation() {
        return new FhirResourceWriterImpl(this.baseUrl, "ImmunizationRecommendation", this.fetchFn);
    }
    implementationGuide() {
        return new FhirResourceWriterImpl(this.baseUrl, "ImplementationGuide", this.fetchFn);
    }
    insurancePlan() {
        return new FhirResourceWriterImpl(this.baseUrl, "InsurancePlan", this.fetchFn);
    }
    invoice() {
        return new FhirResourceWriterImpl(this.baseUrl, "Invoice", this.fetchFn);
    }
    library() {
        return new FhirResourceWriterImpl(this.baseUrl, "Library", this.fetchFn);
    }
    linkage() {
        return new FhirResourceWriterImpl(this.baseUrl, "Linkage", this.fetchFn);
    }
    list() {
        return new FhirResourceWriterImpl(this.baseUrl, "List", this.fetchFn);
    }
    measure() {
        return new FhirResourceWriterImpl(this.baseUrl, "Measure", this.fetchFn);
    }
    measureReport() {
        return new FhirResourceWriterImpl(this.baseUrl, "MeasureReport", this.fetchFn);
    }
    media() {
        return new FhirResourceWriterImpl(this.baseUrl, "Media", this.fetchFn);
    }
    medication() {
        return new FhirResourceWriterImpl(this.baseUrl, "Medication", this.fetchFn);
    }
    medicationAdministration() {
        return new FhirResourceWriterImpl(this.baseUrl, "MedicationAdministration", this.fetchFn);
    }
    medicationDispense() {
        return new FhirResourceWriterImpl(this.baseUrl, "MedicationDispense", this.fetchFn);
    }
    medicationKnowledge() {
        return new FhirResourceWriterImpl(this.baseUrl, "MedicationKnowledge", this.fetchFn);
    }
    medicationRequest() {
        return new FhirResourceWriterImpl(this.baseUrl, "MedicationRequest", this.fetchFn);
    }
    medicationStatement() {
        return new FhirResourceWriterImpl(this.baseUrl, "MedicationStatement", this.fetchFn);
    }
    medicinalProduct() {
        return new FhirResourceWriterImpl(this.baseUrl, "MedicinalProduct", this.fetchFn);
    }
    messageDefinition() {
        return new FhirResourceWriterImpl(this.baseUrl, "MessageDefinition", this.fetchFn);
    }
    messageHeader() {
        return new FhirResourceWriterImpl(this.baseUrl, "MessageHeader", this.fetchFn);
    }
    molecularSequence() {
        return new FhirResourceWriterImpl(this.baseUrl, "MolecularSequence", this.fetchFn);
    }
    namingSystem() {
        return new FhirResourceWriterImpl(this.baseUrl, "NamingSystem", this.fetchFn);
    }
    nutritionOrder() {
        return new FhirResourceWriterImpl(this.baseUrl, "NutritionOrder", this.fetchFn);
    }
    observation() {
        return new FhirResourceWriterImpl(this.baseUrl, "Observation", this.fetchFn);
    }
    observationDefinition() {
        return new FhirResourceWriterImpl(this.baseUrl, "ObservationDefinition", this.fetchFn);
    }
    operationDefinition() {
        return new FhirResourceWriterImpl(this.baseUrl, "OperationDefinition", this.fetchFn);
    }
    operationOutcome() {
        return new FhirResourceWriterImpl(this.baseUrl, "OperationOutcome", this.fetchFn);
    }
    organizationAffiliation() {
        return new FhirResourceWriterImpl(this.baseUrl, "OrganizationAffiliation", this.fetchFn);
    }
    parameters() {
        return new FhirResourceWriterImpl(this.baseUrl, "Parameters", this.fetchFn);
    }
    paymentNotice() {
        return new FhirResourceWriterImpl(this.baseUrl, "PaymentNotice", this.fetchFn);
    }
    paymentReconciliation() {
        return new FhirResourceWriterImpl(this.baseUrl, "PaymentReconciliation", this.fetchFn);
    }
    person() {
        return new FhirResourceWriterImpl(this.baseUrl, "Person", this.fetchFn);
    }
    planDefinition() {
        return new FhirResourceWriterImpl(this.baseUrl, "PlanDefinition", this.fetchFn);
    }
    procedure() {
        return new FhirResourceWriterImpl(this.baseUrl, "Procedure", this.fetchFn);
    }
    provenance() {
        return new FhirResourceWriterImpl(this.baseUrl, "Provenance", this.fetchFn);
    }
    questionnaire() {
        return new FhirResourceWriterImpl(this.baseUrl, "Questionnaire", this.fetchFn);
    }
    questionnaireResponse() {
        return new FhirResourceWriterImpl(this.baseUrl, "QuestionnaireResponse", this.fetchFn);
    }
    relatedPerson() {
        return new FhirResourceWriterImpl(this.baseUrl, "RelatedPerson", this.fetchFn);
    }
    requestGroup() {
        return new FhirResourceWriterImpl(this.baseUrl, "RequestGroup", this.fetchFn);
    }
    researchDefinition() {
        return new FhirResourceWriterImpl(this.baseUrl, "ResearchDefinition", this.fetchFn);
    }
    researchElementDefinition() {
        return new FhirResourceWriterImpl(this.baseUrl, "ResearchElementDefinition", this.fetchFn);
    }
    researchStudy() {
        return new FhirResourceWriterImpl(this.baseUrl, "ResearchStudy", this.fetchFn);
    }
    researchSubject() {
        return new FhirResourceWriterImpl(this.baseUrl, "ResearchSubject", this.fetchFn);
    }
    riskAssessment() {
        return new FhirResourceWriterImpl(this.baseUrl, "RiskAssessment", this.fetchFn);
    }
    riskEvidenceSynthesis() {
        return new FhirResourceWriterImpl(this.baseUrl, "RiskEvidenceSynthesis", this.fetchFn);
    }
    schedule() {
        return new FhirResourceWriterImpl(this.baseUrl, "Schedule", this.fetchFn);
    }
    searchParameter() {
        return new FhirResourceWriterImpl(this.baseUrl, "SearchParameter", this.fetchFn);
    }
    slot() {
        return new FhirResourceWriterImpl(this.baseUrl, "Slot", this.fetchFn);
    }
    specimen() {
        return new FhirResourceWriterImpl(this.baseUrl, "Specimen", this.fetchFn);
    }
    specimenDefinition() {
        return new FhirResourceWriterImpl(this.baseUrl, "SpecimenDefinition", this.fetchFn);
    }
    structureDefinition() {
        return new FhirResourceWriterImpl(this.baseUrl, "StructureDefinition", this.fetchFn);
    }
    structureMap() {
        return new FhirResourceWriterImpl(this.baseUrl, "StructureMap", this.fetchFn);
    }
    subscription() {
        return new FhirResourceWriterImpl(this.baseUrl, "Subscription", this.fetchFn);
    }
    substance() {
        return new FhirResourceWriterImpl(this.baseUrl, "Substance", this.fetchFn);
    }
    substanceSpecification() {
        return new FhirResourceWriterImpl(this.baseUrl, "SubstanceSpecification", this.fetchFn);
    }
    supplyDelivery() {
        return new FhirResourceWriterImpl(this.baseUrl, "SupplyDelivery", this.fetchFn);
    }
    supplyRequest() {
        return new FhirResourceWriterImpl(this.baseUrl, "SupplyRequest", this.fetchFn);
    }
    task() {
        return new FhirResourceWriterImpl(this.baseUrl, "Task", this.fetchFn);
    }
    terminologyCapabilities() {
        return new FhirResourceWriterImpl(this.baseUrl, "TerminologyCapabilities", this.fetchFn);
    }
    testReport() {
        return new FhirResourceWriterImpl(this.baseUrl, "TestReport", this.fetchFn);
    }
    testScript() {
        return new FhirResourceWriterImpl(this.baseUrl, "TestScript", this.fetchFn);
    }
    valueSet() {
        return new FhirResourceWriterImpl(this.baseUrl, "ValueSet", this.fetchFn);
    }
    verificationResult() {
        return new FhirResourceWriterImpl(this.baseUrl, "VerificationResult", this.fetchFn);
    }
    visionPrescription() {
        return new FhirResourceWriterImpl(this.baseUrl, "VisionPrescription", this.fetchFn);
    }
}
/**
 * Main FHIR Client — works with plain fetch or an authenticated fetch wrapper.
 *
 * @example
 * // Unauthenticated
 * const client = new FhirClient("https://fhir.example.com");
 *
 * // With custom fetch (e.g. from SmartFhirClient)
 * const client = new FhirClient("https://fhir.example.com", authenticatedFetch);
 *
 * // Read base R4 resources
 * const patient = await client.read().patient().read("123");
 *
 * // Read profiled resources
 * const coverage = await client.read().pASCoverage().searchAll({});
 *
 * // Generic access for any resource type
 * const custom = await client.read().resource<MyType>("CustomResource").read("456");
 */
export class FhirClient {
    constructor(baseUrl, fetchFn) {
        this.baseUrl = baseUrl;
        this.readClient = new FhirReadClient(baseUrl, fetchFn);
        this.writeClient = new FhirWriteClient(baseUrl, fetchFn);
    }
    /**
     * Get a read client for querying resources
     */
    read() {
        return this.readClient;
    }
    /**
     * Get a write client for creating/updating resources
     */
    write() {
        return this.writeClient;
    }
}
