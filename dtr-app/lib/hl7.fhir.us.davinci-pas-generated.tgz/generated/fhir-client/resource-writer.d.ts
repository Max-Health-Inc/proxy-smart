import type * as GeneratedTypes from "../index.js";
import type * as BaseTypes from "./types.js";
import type { WithId } from "./types.js";
/**
 * Generic FHIR resource writer
 */
export interface FhirResourceWriter<T> {
    readonly baseUrl: string;
    readonly resourceType: string;
    /**
     * Create a new resource
     */
    create(resource: T): Promise<WithId<T>>;
    /**
     * Update an existing resource
     */
    update(resource: WithId<T>): Promise<WithId<T>>;
    /**
     * Delete a resource
     */
    delete(id: string): Promise<void>;
    /**
     * Create or update (upsert)
     */
    createOrUpdate(resource: T | WithId<T>): Promise<WithId<T>>;
}
/**
 * Specific writer types for type safety
 */
export type PASBeneficiaryWriter = FhirResourceWriter<GeneratedTypes.PASBeneficiary>;
export type PASCommunicationRequestWriter = FhirResourceWriter<GeneratedTypes.PASCommunicationRequest>;
export type PASCoverageWriter = FhirResourceWriter<GeneratedTypes.PASCoverage>;
export type PASDeviceRequestWriter = FhirResourceWriter<GeneratedTypes.PASDeviceRequest>;
export type PASEncounterWriter = FhirResourceWriter<GeneratedTypes.PASEncounter>;
export type PASInsurerWriter = FhirResourceWriter<GeneratedTypes.PASInsurer>;
export type PASLocationWriter = FhirResourceWriter<GeneratedTypes.PASLocation>;
export type PASOrganizationWriter = FhirResourceWriter<GeneratedTypes.PASOrganization>;
export type PASPractitionerWriter = FhirResourceWriter<GeneratedTypes.PASPractitioner>;
export type PASPractitionerRoleWriter = FhirResourceWriter<GeneratedTypes.PASPractitionerRole>;
export type PASRequestorWriter = FhirResourceWriter<GeneratedTypes.PASRequestor>;
export type PASServiceRequestWriter = FhirResourceWriter<GeneratedTypes.PASServiceRequest>;
export type PASSubscriberWriter = FhirResourceWriter<GeneratedTypes.PASSubscriber>;
/**
 * Base FHIR R4 writer types
 */
export type AccountWriter = FhirResourceWriter<BaseTypes.Account>;
export type ActivityDefinitionWriter = FhirResourceWriter<BaseTypes.ActivityDefinition>;
export type AdverseEventWriter = FhirResourceWriter<BaseTypes.AdverseEvent>;
export type AllergyIntoleranceWriter = FhirResourceWriter<BaseTypes.AllergyIntolerance>;
export type AppointmentWriter = FhirResourceWriter<BaseTypes.Appointment>;
export type AppointmentResponseWriter = FhirResourceWriter<BaseTypes.AppointmentResponse>;
export type AuditEventWriter = FhirResourceWriter<BaseTypes.AuditEvent>;
export type BasicWriter = FhirResourceWriter<BaseTypes.Basic>;
export type BinaryWriter = FhirResourceWriter<BaseTypes.Binary>;
export type BiologicallyDerivedProductWriter = FhirResourceWriter<BaseTypes.BiologicallyDerivedProduct>;
export type BodyStructureWriter = FhirResourceWriter<BaseTypes.BodyStructure>;
export type CapabilityStatementWriter = FhirResourceWriter<BaseTypes.CapabilityStatement>;
export type CarePlanWriter = FhirResourceWriter<BaseTypes.CarePlan>;
export type CareTeamWriter = FhirResourceWriter<BaseTypes.CareTeam>;
export type ChargeItemWriter = FhirResourceWriter<BaseTypes.ChargeItem>;
export type ChargeItemDefinitionWriter = FhirResourceWriter<BaseTypes.ChargeItemDefinition>;
export type ClaimWriter = FhirResourceWriter<BaseTypes.Claim>;
export type ClaimResponseWriter = FhirResourceWriter<BaseTypes.ClaimResponse>;
export type ClinicalImpressionWriter = FhirResourceWriter<BaseTypes.ClinicalImpression>;
export type CodeSystemWriter = FhirResourceWriter<BaseTypes.CodeSystem>;
export type CommunicationWriter = FhirResourceWriter<BaseTypes.Communication>;
export type CompartmentDefinitionWriter = FhirResourceWriter<BaseTypes.CompartmentDefinition>;
export type CompositionWriter = FhirResourceWriter<BaseTypes.Composition>;
export type ConceptMapWriter = FhirResourceWriter<BaseTypes.ConceptMap>;
export type ConditionWriter = FhirResourceWriter<BaseTypes.Condition>;
export type ConsentWriter = FhirResourceWriter<BaseTypes.Consent>;
export type ContractWriter = FhirResourceWriter<BaseTypes.Contract>;
export type CoverageEligibilityRequestWriter = FhirResourceWriter<BaseTypes.CoverageEligibilityRequest>;
export type CoverageEligibilityResponseWriter = FhirResourceWriter<BaseTypes.CoverageEligibilityResponse>;
export type DetectedIssueWriter = FhirResourceWriter<BaseTypes.DetectedIssue>;
export type DeviceWriter = FhirResourceWriter<BaseTypes.Device>;
export type DeviceDefinitionWriter = FhirResourceWriter<BaseTypes.DeviceDefinition>;
export type DeviceMetricWriter = FhirResourceWriter<BaseTypes.DeviceMetric>;
export type DeviceUseStatementWriter = FhirResourceWriter<BaseTypes.DeviceUseStatement>;
export type DiagnosticReportWriter = FhirResourceWriter<BaseTypes.DiagnosticReport>;
export type DocumentManifestWriter = FhirResourceWriter<BaseTypes.DocumentManifest>;
export type DocumentReferenceWriter = FhirResourceWriter<BaseTypes.DocumentReference>;
export type EndpointWriter = FhirResourceWriter<BaseTypes.Endpoint>;
export type EnrollmentRequestWriter = FhirResourceWriter<BaseTypes.EnrollmentRequest>;
export type EnrollmentResponseWriter = FhirResourceWriter<BaseTypes.EnrollmentResponse>;
export type EpisodeOfCareWriter = FhirResourceWriter<BaseTypes.EpisodeOfCare>;
export type EventDefinitionWriter = FhirResourceWriter<BaseTypes.EventDefinition>;
export type EvidenceWriter = FhirResourceWriter<BaseTypes.Evidence>;
export type EvidenceVariableWriter = FhirResourceWriter<BaseTypes.EvidenceVariable>;
export type ExampleScenarioWriter = FhirResourceWriter<BaseTypes.ExampleScenario>;
export type ExplanationOfBenefitWriter = FhirResourceWriter<BaseTypes.ExplanationOfBenefit>;
export type FamilyMemberHistoryWriter = FhirResourceWriter<BaseTypes.FamilyMemberHistory>;
export type FlagWriter = FhirResourceWriter<BaseTypes.Flag>;
export type GoalWriter = FhirResourceWriter<BaseTypes.Goal>;
export type GraphDefinitionWriter = FhirResourceWriter<BaseTypes.GraphDefinition>;
export type GroupWriter = FhirResourceWriter<BaseTypes.Group>;
export type GuidanceResponseWriter = FhirResourceWriter<BaseTypes.GuidanceResponse>;
export type HealthcareServiceWriter = FhirResourceWriter<BaseTypes.HealthcareService>;
export type ImagingStudyWriter = FhirResourceWriter<BaseTypes.ImagingStudy>;
export type ImmunizationWriter = FhirResourceWriter<BaseTypes.Immunization>;
export type ImmunizationEvaluationWriter = FhirResourceWriter<BaseTypes.ImmunizationEvaluation>;
export type ImmunizationRecommendationWriter = FhirResourceWriter<BaseTypes.ImmunizationRecommendation>;
export type ImplementationGuideWriter = FhirResourceWriter<BaseTypes.ImplementationGuide>;
export type InsurancePlanWriter = FhirResourceWriter<BaseTypes.InsurancePlan>;
export type InvoiceWriter = FhirResourceWriter<BaseTypes.Invoice>;
export type LibraryWriter = FhirResourceWriter<BaseTypes.Library>;
export type LinkageWriter = FhirResourceWriter<BaseTypes.Linkage>;
export type ListWriter = FhirResourceWriter<BaseTypes.List>;
export type MeasureWriter = FhirResourceWriter<BaseTypes.Measure>;
export type MeasureReportWriter = FhirResourceWriter<BaseTypes.MeasureReport>;
export type MediaWriter = FhirResourceWriter<BaseTypes.Media>;
export type MedicationWriter = FhirResourceWriter<BaseTypes.Medication>;
export type MedicationAdministrationWriter = FhirResourceWriter<BaseTypes.MedicationAdministration>;
export type MedicationDispenseWriter = FhirResourceWriter<BaseTypes.MedicationDispense>;
export type MedicationKnowledgeWriter = FhirResourceWriter<BaseTypes.MedicationKnowledge>;
export type MedicationRequestWriter = FhirResourceWriter<BaseTypes.MedicationRequest>;
export type MedicationStatementWriter = FhirResourceWriter<BaseTypes.MedicationStatement>;
export type MedicinalProductWriter = FhirResourceWriter<BaseTypes.MedicinalProduct>;
export type MessageDefinitionWriter = FhirResourceWriter<BaseTypes.MessageDefinition>;
export type MessageHeaderWriter = FhirResourceWriter<BaseTypes.MessageHeader>;
export type MolecularSequenceWriter = FhirResourceWriter<BaseTypes.MolecularSequence>;
export type NamingSystemWriter = FhirResourceWriter<BaseTypes.NamingSystem>;
export type NutritionOrderWriter = FhirResourceWriter<BaseTypes.NutritionOrder>;
export type ObservationWriter = FhirResourceWriter<BaseTypes.Observation>;
export type ObservationDefinitionWriter = FhirResourceWriter<BaseTypes.ObservationDefinition>;
export type OperationDefinitionWriter = FhirResourceWriter<BaseTypes.OperationDefinition>;
export type OperationOutcomeWriter = FhirResourceWriter<BaseTypes.OperationOutcome>;
export type OrganizationAffiliationWriter = FhirResourceWriter<BaseTypes.OrganizationAffiliation>;
export type ParametersWriter = FhirResourceWriter<BaseTypes.Parameters>;
export type PaymentNoticeWriter = FhirResourceWriter<BaseTypes.PaymentNotice>;
export type PaymentReconciliationWriter = FhirResourceWriter<BaseTypes.PaymentReconciliation>;
export type PersonWriter = FhirResourceWriter<BaseTypes.Person>;
export type PlanDefinitionWriter = FhirResourceWriter<BaseTypes.PlanDefinition>;
export type ProcedureWriter = FhirResourceWriter<BaseTypes.Procedure>;
export type ProvenanceWriter = FhirResourceWriter<BaseTypes.Provenance>;
export type QuestionnaireWriter = FhirResourceWriter<BaseTypes.Questionnaire>;
export type QuestionnaireResponseWriter = FhirResourceWriter<BaseTypes.QuestionnaireResponse>;
export type RelatedPersonWriter = FhirResourceWriter<BaseTypes.RelatedPerson>;
export type RequestGroupWriter = FhirResourceWriter<BaseTypes.RequestGroup>;
export type ResearchDefinitionWriter = FhirResourceWriter<BaseTypes.ResearchDefinition>;
export type ResearchElementDefinitionWriter = FhirResourceWriter<BaseTypes.ResearchElementDefinition>;
export type ResearchStudyWriter = FhirResourceWriter<BaseTypes.ResearchStudy>;
export type ResearchSubjectWriter = FhirResourceWriter<BaseTypes.ResearchSubject>;
export type RiskAssessmentWriter = FhirResourceWriter<BaseTypes.RiskAssessment>;
export type RiskEvidenceSynthesisWriter = FhirResourceWriter<BaseTypes.RiskEvidenceSynthesis>;
export type ScheduleWriter = FhirResourceWriter<BaseTypes.Schedule>;
export type SearchParameterWriter = FhirResourceWriter<BaseTypes.SearchParameter>;
export type SlotWriter = FhirResourceWriter<BaseTypes.Slot>;
export type SpecimenWriter = FhirResourceWriter<BaseTypes.Specimen>;
export type SpecimenDefinitionWriter = FhirResourceWriter<BaseTypes.SpecimenDefinition>;
export type StructureDefinitionWriter = FhirResourceWriter<BaseTypes.StructureDefinition>;
export type StructureMapWriter = FhirResourceWriter<BaseTypes.StructureMap>;
export type SubscriptionWriter = FhirResourceWriter<BaseTypes.Subscription>;
export type SubstanceWriter = FhirResourceWriter<BaseTypes.Substance>;
export type SubstanceSpecificationWriter = FhirResourceWriter<BaseTypes.SubstanceSpecification>;
export type SupplyDeliveryWriter = FhirResourceWriter<BaseTypes.SupplyDelivery>;
export type SupplyRequestWriter = FhirResourceWriter<BaseTypes.SupplyRequest>;
export type TaskWriter = FhirResourceWriter<BaseTypes.Task>;
export type TerminologyCapabilitiesWriter = FhirResourceWriter<BaseTypes.TerminologyCapabilities>;
export type TestReportWriter = FhirResourceWriter<BaseTypes.TestReport>;
export type TestScriptWriter = FhirResourceWriter<BaseTypes.TestScript>;
export type ValueSetWriter = FhirResourceWriter<BaseTypes.ValueSet>;
export type VerificationResultWriter = FhirResourceWriter<BaseTypes.VerificationResult>;
export type VisionPrescriptionWriter = FhirResourceWriter<BaseTypes.VisionPrescription>;
import type { FetchFn } from "./resource-reader.js";
/**
 * Implementation of FHIR resource writer
 */
export declare class FhirResourceWriterImpl<T> implements FhirResourceWriter<T> {
    readonly baseUrl: string;
    readonly resourceType: string;
    private readonly fetchFn;
    constructor(baseUrl: string, resourceType: string, fetchFn?: FetchFn);
    create(resource: T): Promise<WithId<T>>;
    update(resource: WithId<T>): Promise<WithId<T>>;
    delete(id: string): Promise<void>;
    createOrUpdate(resource: T | WithId<T>): Promise<WithId<T>>;
}
