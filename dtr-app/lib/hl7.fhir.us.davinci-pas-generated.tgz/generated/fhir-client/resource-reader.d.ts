import type * as GeneratedTypes from "../index.js";
import type * as BaseTypes from "./types.js";
import type { Bundle, SearchParams, WithId } from "./types.js";
/**
 * Generic FHIR resource searcher/reader
 */
export interface FhirResourceSearcher<T> {
    readonly baseUrl: string;
    readonly resourceType: string;
    /**
     * Read a resource by ID
     */
    read(id: string): Promise<WithId<T>>;
    /**
     * Search for resources
     */
    search(params?: SearchParams): Promise<Bundle<WithId<T>>>;
    /**
     * Search and return first result or undefined
     */
    searchOne(params?: SearchParams): Promise<undefined | WithId<T>>;
    /**
     * Search and return all results (handles pagination)
     */
    searchAll(params?: SearchParams): Promise<WithId<T>[]>;
}
/**
 * Specific reader types for type safety
 */
export type PASBeneficiaryReader = FhirResourceSearcher<GeneratedTypes.PASBeneficiary>;
export type PASCommunicationRequestReader = FhirResourceSearcher<GeneratedTypes.PASCommunicationRequest>;
export type PASCoverageReader = FhirResourceSearcher<GeneratedTypes.PASCoverage>;
export type PASDeviceRequestReader = FhirResourceSearcher<GeneratedTypes.PASDeviceRequest>;
export type PASEncounterReader = FhirResourceSearcher<GeneratedTypes.PASEncounter>;
export type PASInsurerReader = FhirResourceSearcher<GeneratedTypes.PASInsurer>;
export type PASLocationReader = FhirResourceSearcher<GeneratedTypes.PASLocation>;
export type PASOrganizationReader = FhirResourceSearcher<GeneratedTypes.PASOrganization>;
export type PASPractitionerReader = FhirResourceSearcher<GeneratedTypes.PASPractitioner>;
export type PASPractitionerRoleReader = FhirResourceSearcher<GeneratedTypes.PASPractitionerRole>;
export type PASRequestorReader = FhirResourceSearcher<GeneratedTypes.PASRequestor>;
export type PASServiceRequestReader = FhirResourceSearcher<GeneratedTypes.PASServiceRequest>;
export type PASSubscriberReader = FhirResourceSearcher<GeneratedTypes.PASSubscriber>;
/**
 * Base FHIR R4 reader types
 */
export type AccountReader = FhirResourceSearcher<BaseTypes.Account>;
export type ActivityDefinitionReader = FhirResourceSearcher<BaseTypes.ActivityDefinition>;
export type AdverseEventReader = FhirResourceSearcher<BaseTypes.AdverseEvent>;
export type AllergyIntoleranceReader = FhirResourceSearcher<BaseTypes.AllergyIntolerance>;
export type AppointmentReader = FhirResourceSearcher<BaseTypes.Appointment>;
export type AppointmentResponseReader = FhirResourceSearcher<BaseTypes.AppointmentResponse>;
export type AuditEventReader = FhirResourceSearcher<BaseTypes.AuditEvent>;
export type BasicReader = FhirResourceSearcher<BaseTypes.Basic>;
export type BinaryReader = FhirResourceSearcher<BaseTypes.Binary>;
export type BiologicallyDerivedProductReader = FhirResourceSearcher<BaseTypes.BiologicallyDerivedProduct>;
export type BodyStructureReader = FhirResourceSearcher<BaseTypes.BodyStructure>;
export type CapabilityStatementReader = FhirResourceSearcher<BaseTypes.CapabilityStatement>;
export type CarePlanReader = FhirResourceSearcher<BaseTypes.CarePlan>;
export type CareTeamReader = FhirResourceSearcher<BaseTypes.CareTeam>;
export type ChargeItemReader = FhirResourceSearcher<BaseTypes.ChargeItem>;
export type ChargeItemDefinitionReader = FhirResourceSearcher<BaseTypes.ChargeItemDefinition>;
export type ClaimReader = FhirResourceSearcher<BaseTypes.Claim>;
export type ClaimResponseReader = FhirResourceSearcher<BaseTypes.ClaimResponse>;
export type ClinicalImpressionReader = FhirResourceSearcher<BaseTypes.ClinicalImpression>;
export type CodeSystemReader = FhirResourceSearcher<BaseTypes.CodeSystem>;
export type CommunicationReader = FhirResourceSearcher<BaseTypes.Communication>;
export type CompartmentDefinitionReader = FhirResourceSearcher<BaseTypes.CompartmentDefinition>;
export type CompositionReader = FhirResourceSearcher<BaseTypes.Composition>;
export type ConceptMapReader = FhirResourceSearcher<BaseTypes.ConceptMap>;
export type ConditionReader = FhirResourceSearcher<BaseTypes.Condition>;
export type ConsentReader = FhirResourceSearcher<BaseTypes.Consent>;
export type ContractReader = FhirResourceSearcher<BaseTypes.Contract>;
export type CoverageEligibilityRequestReader = FhirResourceSearcher<BaseTypes.CoverageEligibilityRequest>;
export type CoverageEligibilityResponseReader = FhirResourceSearcher<BaseTypes.CoverageEligibilityResponse>;
export type DetectedIssueReader = FhirResourceSearcher<BaseTypes.DetectedIssue>;
export type DeviceReader = FhirResourceSearcher<BaseTypes.Device>;
export type DeviceDefinitionReader = FhirResourceSearcher<BaseTypes.DeviceDefinition>;
export type DeviceMetricReader = FhirResourceSearcher<BaseTypes.DeviceMetric>;
export type DeviceUseStatementReader = FhirResourceSearcher<BaseTypes.DeviceUseStatement>;
export type DiagnosticReportReader = FhirResourceSearcher<BaseTypes.DiagnosticReport>;
export type DocumentManifestReader = FhirResourceSearcher<BaseTypes.DocumentManifest>;
export type DocumentReferenceReader = FhirResourceSearcher<BaseTypes.DocumentReference>;
export type EndpointReader = FhirResourceSearcher<BaseTypes.Endpoint>;
export type EnrollmentRequestReader = FhirResourceSearcher<BaseTypes.EnrollmentRequest>;
export type EnrollmentResponseReader = FhirResourceSearcher<BaseTypes.EnrollmentResponse>;
export type EpisodeOfCareReader = FhirResourceSearcher<BaseTypes.EpisodeOfCare>;
export type EventDefinitionReader = FhirResourceSearcher<BaseTypes.EventDefinition>;
export type EvidenceReader = FhirResourceSearcher<BaseTypes.Evidence>;
export type EvidenceVariableReader = FhirResourceSearcher<BaseTypes.EvidenceVariable>;
export type ExampleScenarioReader = FhirResourceSearcher<BaseTypes.ExampleScenario>;
export type ExplanationOfBenefitReader = FhirResourceSearcher<BaseTypes.ExplanationOfBenefit>;
export type FamilyMemberHistoryReader = FhirResourceSearcher<BaseTypes.FamilyMemberHistory>;
export type FlagReader = FhirResourceSearcher<BaseTypes.Flag>;
export type GoalReader = FhirResourceSearcher<BaseTypes.Goal>;
export type GraphDefinitionReader = FhirResourceSearcher<BaseTypes.GraphDefinition>;
export type GroupReader = FhirResourceSearcher<BaseTypes.Group>;
export type GuidanceResponseReader = FhirResourceSearcher<BaseTypes.GuidanceResponse>;
export type HealthcareServiceReader = FhirResourceSearcher<BaseTypes.HealthcareService>;
export type ImagingStudyReader = FhirResourceSearcher<BaseTypes.ImagingStudy>;
export type ImmunizationReader = FhirResourceSearcher<BaseTypes.Immunization>;
export type ImmunizationEvaluationReader = FhirResourceSearcher<BaseTypes.ImmunizationEvaluation>;
export type ImmunizationRecommendationReader = FhirResourceSearcher<BaseTypes.ImmunizationRecommendation>;
export type ImplementationGuideReader = FhirResourceSearcher<BaseTypes.ImplementationGuide>;
export type InsurancePlanReader = FhirResourceSearcher<BaseTypes.InsurancePlan>;
export type InvoiceReader = FhirResourceSearcher<BaseTypes.Invoice>;
export type LibraryReader = FhirResourceSearcher<BaseTypes.Library>;
export type LinkageReader = FhirResourceSearcher<BaseTypes.Linkage>;
export type ListReader = FhirResourceSearcher<BaseTypes.List>;
export type MeasureReader = FhirResourceSearcher<BaseTypes.Measure>;
export type MeasureReportReader = FhirResourceSearcher<BaseTypes.MeasureReport>;
export type MediaReader = FhirResourceSearcher<BaseTypes.Media>;
export type MedicationReader = FhirResourceSearcher<BaseTypes.Medication>;
export type MedicationAdministrationReader = FhirResourceSearcher<BaseTypes.MedicationAdministration>;
export type MedicationDispenseReader = FhirResourceSearcher<BaseTypes.MedicationDispense>;
export type MedicationKnowledgeReader = FhirResourceSearcher<BaseTypes.MedicationKnowledge>;
export type MedicationRequestReader = FhirResourceSearcher<BaseTypes.MedicationRequest>;
export type MedicationStatementReader = FhirResourceSearcher<BaseTypes.MedicationStatement>;
export type MedicinalProductReader = FhirResourceSearcher<BaseTypes.MedicinalProduct>;
export type MessageDefinitionReader = FhirResourceSearcher<BaseTypes.MessageDefinition>;
export type MessageHeaderReader = FhirResourceSearcher<BaseTypes.MessageHeader>;
export type MolecularSequenceReader = FhirResourceSearcher<BaseTypes.MolecularSequence>;
export type NamingSystemReader = FhirResourceSearcher<BaseTypes.NamingSystem>;
export type NutritionOrderReader = FhirResourceSearcher<BaseTypes.NutritionOrder>;
export type ObservationReader = FhirResourceSearcher<BaseTypes.Observation>;
export type ObservationDefinitionReader = FhirResourceSearcher<BaseTypes.ObservationDefinition>;
export type OperationDefinitionReader = FhirResourceSearcher<BaseTypes.OperationDefinition>;
export type OperationOutcomeReader = FhirResourceSearcher<BaseTypes.OperationOutcome>;
export type OrganizationAffiliationReader = FhirResourceSearcher<BaseTypes.OrganizationAffiliation>;
export type ParametersReader = FhirResourceSearcher<BaseTypes.Parameters>;
export type PaymentNoticeReader = FhirResourceSearcher<BaseTypes.PaymentNotice>;
export type PaymentReconciliationReader = FhirResourceSearcher<BaseTypes.PaymentReconciliation>;
export type PersonReader = FhirResourceSearcher<BaseTypes.Person>;
export type PlanDefinitionReader = FhirResourceSearcher<BaseTypes.PlanDefinition>;
export type ProcedureReader = FhirResourceSearcher<BaseTypes.Procedure>;
export type ProvenanceReader = FhirResourceSearcher<BaseTypes.Provenance>;
export type QuestionnaireReader = FhirResourceSearcher<BaseTypes.Questionnaire>;
export type QuestionnaireResponseReader = FhirResourceSearcher<BaseTypes.QuestionnaireResponse>;
export type RelatedPersonReader = FhirResourceSearcher<BaseTypes.RelatedPerson>;
export type RequestGroupReader = FhirResourceSearcher<BaseTypes.RequestGroup>;
export type ResearchDefinitionReader = FhirResourceSearcher<BaseTypes.ResearchDefinition>;
export type ResearchElementDefinitionReader = FhirResourceSearcher<BaseTypes.ResearchElementDefinition>;
export type ResearchStudyReader = FhirResourceSearcher<BaseTypes.ResearchStudy>;
export type ResearchSubjectReader = FhirResourceSearcher<BaseTypes.ResearchSubject>;
export type RiskAssessmentReader = FhirResourceSearcher<BaseTypes.RiskAssessment>;
export type RiskEvidenceSynthesisReader = FhirResourceSearcher<BaseTypes.RiskEvidenceSynthesis>;
export type ScheduleReader = FhirResourceSearcher<BaseTypes.Schedule>;
export type SearchParameterReader = FhirResourceSearcher<BaseTypes.SearchParameter>;
export type SlotReader = FhirResourceSearcher<BaseTypes.Slot>;
export type SpecimenReader = FhirResourceSearcher<BaseTypes.Specimen>;
export type SpecimenDefinitionReader = FhirResourceSearcher<BaseTypes.SpecimenDefinition>;
export type StructureDefinitionReader = FhirResourceSearcher<BaseTypes.StructureDefinition>;
export type StructureMapReader = FhirResourceSearcher<BaseTypes.StructureMap>;
export type SubscriptionReader = FhirResourceSearcher<BaseTypes.Subscription>;
export type SubstanceReader = FhirResourceSearcher<BaseTypes.Substance>;
export type SubstanceSpecificationReader = FhirResourceSearcher<BaseTypes.SubstanceSpecification>;
export type SupplyDeliveryReader = FhirResourceSearcher<BaseTypes.SupplyDelivery>;
export type SupplyRequestReader = FhirResourceSearcher<BaseTypes.SupplyRequest>;
export type TaskReader = FhirResourceSearcher<BaseTypes.Task>;
export type TerminologyCapabilitiesReader = FhirResourceSearcher<BaseTypes.TerminologyCapabilities>;
export type TestReportReader = FhirResourceSearcher<BaseTypes.TestReport>;
export type TestScriptReader = FhirResourceSearcher<BaseTypes.TestScript>;
export type ValueSetReader = FhirResourceSearcher<BaseTypes.ValueSet>;
export type VerificationResultReader = FhirResourceSearcher<BaseTypes.VerificationResult>;
export type VisionPrescriptionReader = FhirResourceSearcher<BaseTypes.VisionPrescription>;
/**
 * Custom fetch function type for injecting auth headers
 */
export type FetchFn = typeof globalThis.fetch;
/**
 * Implementation of FHIR resource reader
 */
export declare class FhirResourceReader<T> implements FhirResourceSearcher<T> {
    readonly baseUrl: string;
    readonly resourceType: string;
    private readonly fetchFn;
    constructor(baseUrl: string, resourceType: string, fetchFn?: FetchFn);
    read(id: string): Promise<WithId<T>>;
    search(params?: SearchParams): Promise<Bundle<WithId<T>>>;
    searchOne(params?: SearchParams): Promise<undefined | WithId<T>>;
    searchAll(params?: SearchParams): Promise<WithId<T>[]>;
}
