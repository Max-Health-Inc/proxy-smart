import type * as GeneratedTypes from "../index.js";
/**
 * A FHIR resource with an ID
 */
export type WithId<T> = {
    id: string;
} & T;
/**
 * Search parameters for FHIR resources
 */
export type SearchParams = Record<string, boolean | number | string | string[] | undefined>;
/**
 * Bundle of FHIR resources
 */
export interface Bundle<T> {
    resourceType: "Bundle";
    type: "collection" | "searchset" | "transaction-response" | "transaction";
    total?: number;
    link?: {
        relation: string;
        url: string;
    }[];
    entry?: {
        resource: T;
        fullUrl?: string;
    }[];
}
/**
 * Base FHIR R4 resource interfaces (not profiled in this package)
 */
export interface Account {
    resourceType: "Account";
    id?: string;
    [key: string]: unknown;
}
export interface ActivityDefinition {
    resourceType: "ActivityDefinition";
    id?: string;
    [key: string]: unknown;
}
export interface AdverseEvent {
    resourceType: "AdverseEvent";
    id?: string;
    [key: string]: unknown;
}
export interface AllergyIntolerance {
    resourceType: "AllergyIntolerance";
    id?: string;
    [key: string]: unknown;
}
export interface Appointment {
    resourceType: "Appointment";
    id?: string;
    [key: string]: unknown;
}
export interface AppointmentResponse {
    resourceType: "AppointmentResponse";
    id?: string;
    [key: string]: unknown;
}
export interface AuditEvent {
    resourceType: "AuditEvent";
    id?: string;
    [key: string]: unknown;
}
export interface Basic {
    resourceType: "Basic";
    id?: string;
    [key: string]: unknown;
}
export interface Binary {
    resourceType: "Binary";
    id?: string;
    [key: string]: unknown;
}
export interface BiologicallyDerivedProduct {
    resourceType: "BiologicallyDerivedProduct";
    id?: string;
    [key: string]: unknown;
}
export interface BodyStructure {
    resourceType: "BodyStructure";
    id?: string;
    [key: string]: unknown;
}
export interface CapabilityStatement {
    resourceType: "CapabilityStatement";
    id?: string;
    [key: string]: unknown;
}
export interface CarePlan {
    resourceType: "CarePlan";
    id?: string;
    [key: string]: unknown;
}
export interface CareTeam {
    resourceType: "CareTeam";
    id?: string;
    [key: string]: unknown;
}
export interface ChargeItem {
    resourceType: "ChargeItem";
    id?: string;
    [key: string]: unknown;
}
export interface ChargeItemDefinition {
    resourceType: "ChargeItemDefinition";
    id?: string;
    [key: string]: unknown;
}
export interface Claim {
    resourceType: "Claim";
    id?: string;
    [key: string]: unknown;
}
export interface ClaimResponse {
    resourceType: "ClaimResponse";
    id?: string;
    [key: string]: unknown;
}
export interface ClinicalImpression {
    resourceType: "ClinicalImpression";
    id?: string;
    [key: string]: unknown;
}
export interface CodeSystem {
    resourceType: "CodeSystem";
    id?: string;
    [key: string]: unknown;
}
export interface Communication {
    resourceType: "Communication";
    id?: string;
    [key: string]: unknown;
}
export interface CompartmentDefinition {
    resourceType: "CompartmentDefinition";
    id?: string;
    [key: string]: unknown;
}
export interface Composition {
    resourceType: "Composition";
    id?: string;
    [key: string]: unknown;
}
export interface ConceptMap {
    resourceType: "ConceptMap";
    id?: string;
    [key: string]: unknown;
}
export interface Condition {
    resourceType: "Condition";
    id?: string;
    [key: string]: unknown;
}
export interface Consent {
    resourceType: "Consent";
    id?: string;
    [key: string]: unknown;
}
export interface Contract {
    resourceType: "Contract";
    id?: string;
    [key: string]: unknown;
}
export interface CoverageEligibilityRequest {
    resourceType: "CoverageEligibilityRequest";
    id?: string;
    [key: string]: unknown;
}
export interface CoverageEligibilityResponse {
    resourceType: "CoverageEligibilityResponse";
    id?: string;
    [key: string]: unknown;
}
export interface DetectedIssue {
    resourceType: "DetectedIssue";
    id?: string;
    [key: string]: unknown;
}
export interface Device {
    resourceType: "Device";
    id?: string;
    [key: string]: unknown;
}
export interface DeviceDefinition {
    resourceType: "DeviceDefinition";
    id?: string;
    [key: string]: unknown;
}
export interface DeviceMetric {
    resourceType: "DeviceMetric";
    id?: string;
    [key: string]: unknown;
}
export interface DeviceUseStatement {
    resourceType: "DeviceUseStatement";
    id?: string;
    [key: string]: unknown;
}
export interface DiagnosticReport {
    resourceType: "DiagnosticReport";
    id?: string;
    [key: string]: unknown;
}
export interface DocumentManifest {
    resourceType: "DocumentManifest";
    id?: string;
    [key: string]: unknown;
}
export interface DocumentReference {
    resourceType: "DocumentReference";
    id?: string;
    [key: string]: unknown;
}
export interface Endpoint {
    resourceType: "Endpoint";
    id?: string;
    [key: string]: unknown;
}
export interface EnrollmentRequest {
    resourceType: "EnrollmentRequest";
    id?: string;
    [key: string]: unknown;
}
export interface EnrollmentResponse {
    resourceType: "EnrollmentResponse";
    id?: string;
    [key: string]: unknown;
}
export interface EpisodeOfCare {
    resourceType: "EpisodeOfCare";
    id?: string;
    [key: string]: unknown;
}
export interface EventDefinition {
    resourceType: "EventDefinition";
    id?: string;
    [key: string]: unknown;
}
export interface Evidence {
    resourceType: "Evidence";
    id?: string;
    [key: string]: unknown;
}
export interface EvidenceVariable {
    resourceType: "EvidenceVariable";
    id?: string;
    [key: string]: unknown;
}
export interface ExampleScenario {
    resourceType: "ExampleScenario";
    id?: string;
    [key: string]: unknown;
}
export interface ExplanationOfBenefit {
    resourceType: "ExplanationOfBenefit";
    id?: string;
    [key: string]: unknown;
}
export interface FamilyMemberHistory {
    resourceType: "FamilyMemberHistory";
    id?: string;
    [key: string]: unknown;
}
export interface Flag {
    resourceType: "Flag";
    id?: string;
    [key: string]: unknown;
}
export interface Goal {
    resourceType: "Goal";
    id?: string;
    [key: string]: unknown;
}
export interface GraphDefinition {
    resourceType: "GraphDefinition";
    id?: string;
    [key: string]: unknown;
}
export interface Group {
    resourceType: "Group";
    id?: string;
    [key: string]: unknown;
}
export interface GuidanceResponse {
    resourceType: "GuidanceResponse";
    id?: string;
    [key: string]: unknown;
}
export interface HealthcareService {
    resourceType: "HealthcareService";
    id?: string;
    [key: string]: unknown;
}
export interface ImagingStudy {
    resourceType: "ImagingStudy";
    id?: string;
    [key: string]: unknown;
}
export interface Immunization {
    resourceType: "Immunization";
    id?: string;
    [key: string]: unknown;
}
export interface ImmunizationEvaluation {
    resourceType: "ImmunizationEvaluation";
    id?: string;
    [key: string]: unknown;
}
export interface ImmunizationRecommendation {
    resourceType: "ImmunizationRecommendation";
    id?: string;
    [key: string]: unknown;
}
export interface ImplementationGuide {
    resourceType: "ImplementationGuide";
    id?: string;
    [key: string]: unknown;
}
export interface InsurancePlan {
    resourceType: "InsurancePlan";
    id?: string;
    [key: string]: unknown;
}
export interface Invoice {
    resourceType: "Invoice";
    id?: string;
    [key: string]: unknown;
}
export interface Library {
    resourceType: "Library";
    id?: string;
    [key: string]: unknown;
}
export interface Linkage {
    resourceType: "Linkage";
    id?: string;
    [key: string]: unknown;
}
export interface List {
    resourceType: "List";
    id?: string;
    [key: string]: unknown;
}
export interface Measure {
    resourceType: "Measure";
    id?: string;
    [key: string]: unknown;
}
export interface MeasureReport {
    resourceType: "MeasureReport";
    id?: string;
    [key: string]: unknown;
}
export interface Media {
    resourceType: "Media";
    id?: string;
    [key: string]: unknown;
}
export interface Medication {
    resourceType: "Medication";
    id?: string;
    [key: string]: unknown;
}
export interface MedicationAdministration {
    resourceType: "MedicationAdministration";
    id?: string;
    [key: string]: unknown;
}
export interface MedicationDispense {
    resourceType: "MedicationDispense";
    id?: string;
    [key: string]: unknown;
}
export interface MedicationKnowledge {
    resourceType: "MedicationKnowledge";
    id?: string;
    [key: string]: unknown;
}
export interface MedicationRequest {
    resourceType: "MedicationRequest";
    id?: string;
    [key: string]: unknown;
}
export interface MedicationStatement {
    resourceType: "MedicationStatement";
    id?: string;
    [key: string]: unknown;
}
export interface MedicinalProduct {
    resourceType: "MedicinalProduct";
    id?: string;
    [key: string]: unknown;
}
export interface MessageDefinition {
    resourceType: "MessageDefinition";
    id?: string;
    [key: string]: unknown;
}
export interface MessageHeader {
    resourceType: "MessageHeader";
    id?: string;
    [key: string]: unknown;
}
export interface MolecularSequence {
    resourceType: "MolecularSequence";
    id?: string;
    [key: string]: unknown;
}
export interface NamingSystem {
    resourceType: "NamingSystem";
    id?: string;
    [key: string]: unknown;
}
export interface NutritionOrder {
    resourceType: "NutritionOrder";
    id?: string;
    [key: string]: unknown;
}
export interface Observation {
    resourceType: "Observation";
    id?: string;
    [key: string]: unknown;
}
export interface ObservationDefinition {
    resourceType: "ObservationDefinition";
    id?: string;
    [key: string]: unknown;
}
export interface OperationDefinition {
    resourceType: "OperationDefinition";
    id?: string;
    [key: string]: unknown;
}
export interface OperationOutcome {
    resourceType: "OperationOutcome";
    id?: string;
    [key: string]: unknown;
}
export interface OrganizationAffiliation {
    resourceType: "OrganizationAffiliation";
    id?: string;
    [key: string]: unknown;
}
export interface Parameters {
    resourceType: "Parameters";
    id?: string;
    [key: string]: unknown;
}
export interface PaymentNotice {
    resourceType: "PaymentNotice";
    id?: string;
    [key: string]: unknown;
}
export interface PaymentReconciliation {
    resourceType: "PaymentReconciliation";
    id?: string;
    [key: string]: unknown;
}
export interface Person {
    resourceType: "Person";
    id?: string;
    [key: string]: unknown;
}
export interface PlanDefinition {
    resourceType: "PlanDefinition";
    id?: string;
    [key: string]: unknown;
}
export interface Procedure {
    resourceType: "Procedure";
    id?: string;
    [key: string]: unknown;
}
export interface Provenance {
    resourceType: "Provenance";
    id?: string;
    [key: string]: unknown;
}
export interface Questionnaire {
    resourceType: "Questionnaire";
    id?: string;
    [key: string]: unknown;
}
export interface QuestionnaireResponse {
    resourceType: "QuestionnaireResponse";
    id?: string;
    [key: string]: unknown;
}
export interface RelatedPerson {
    resourceType: "RelatedPerson";
    id?: string;
    [key: string]: unknown;
}
export interface RequestGroup {
    resourceType: "RequestGroup";
    id?: string;
    [key: string]: unknown;
}
export interface ResearchDefinition {
    resourceType: "ResearchDefinition";
    id?: string;
    [key: string]: unknown;
}
export interface ResearchElementDefinition {
    resourceType: "ResearchElementDefinition";
    id?: string;
    [key: string]: unknown;
}
export interface ResearchStudy {
    resourceType: "ResearchStudy";
    id?: string;
    [key: string]: unknown;
}
export interface ResearchSubject {
    resourceType: "ResearchSubject";
    id?: string;
    [key: string]: unknown;
}
export interface RiskAssessment {
    resourceType: "RiskAssessment";
    id?: string;
    [key: string]: unknown;
}
export interface RiskEvidenceSynthesis {
    resourceType: "RiskEvidenceSynthesis";
    id?: string;
    [key: string]: unknown;
}
export interface Schedule {
    resourceType: "Schedule";
    id?: string;
    [key: string]: unknown;
}
export interface SearchParameter {
    resourceType: "SearchParameter";
    id?: string;
    [key: string]: unknown;
}
export interface Slot {
    resourceType: "Slot";
    id?: string;
    [key: string]: unknown;
}
export interface Specimen {
    resourceType: "Specimen";
    id?: string;
    [key: string]: unknown;
}
export interface SpecimenDefinition {
    resourceType: "SpecimenDefinition";
    id?: string;
    [key: string]: unknown;
}
export interface StructureDefinition {
    resourceType: "StructureDefinition";
    id?: string;
    [key: string]: unknown;
}
export interface StructureMap {
    resourceType: "StructureMap";
    id?: string;
    [key: string]: unknown;
}
export interface Subscription {
    resourceType: "Subscription";
    id?: string;
    [key: string]: unknown;
}
export interface Substance {
    resourceType: "Substance";
    id?: string;
    [key: string]: unknown;
}
export interface SubstanceSpecification {
    resourceType: "SubstanceSpecification";
    id?: string;
    [key: string]: unknown;
}
export interface SupplyDelivery {
    resourceType: "SupplyDelivery";
    id?: string;
    [key: string]: unknown;
}
export interface SupplyRequest {
    resourceType: "SupplyRequest";
    id?: string;
    [key: string]: unknown;
}
export interface Task {
    resourceType: "Task";
    id?: string;
    [key: string]: unknown;
}
export interface TerminologyCapabilities {
    resourceType: "TerminologyCapabilities";
    id?: string;
    [key: string]: unknown;
}
export interface TestReport {
    resourceType: "TestReport";
    id?: string;
    [key: string]: unknown;
}
export interface TestScript {
    resourceType: "TestScript";
    id?: string;
    [key: string]: unknown;
}
export interface ValueSet {
    resourceType: "ValueSet";
    id?: string;
    [key: string]: unknown;
}
export interface VerificationResult {
    resourceType: "VerificationResult";
    id?: string;
    [key: string]: unknown;
}
export interface VisionPrescription {
    resourceType: "VisionPrescription";
    id?: string;
    [key: string]: unknown;
}
/**
 * All FHIR resource types — profiled types from this package + base R4 types
 */
export type FhirResource = GeneratedTypes.PASBeneficiary | GeneratedTypes.PASCommunicationRequest | GeneratedTypes.PASCoverage | GeneratedTypes.PASDeviceRequest | GeneratedTypes.PASEncounter | GeneratedTypes.PASInsurer | GeneratedTypes.PASLocation | GeneratedTypes.PASOrganization | GeneratedTypes.PASPractitioner | GeneratedTypes.PASPractitionerRole | GeneratedTypes.PASRequestor | GeneratedTypes.PASServiceRequest | GeneratedTypes.PASSubscriber | Account | ActivityDefinition | AdverseEvent | AllergyIntolerance | Appointment | AppointmentResponse | AuditEvent | Basic | Binary | BiologicallyDerivedProduct | BodyStructure | CapabilityStatement | CarePlan | CareTeam | ChargeItem | ChargeItemDefinition | Claim | ClaimResponse | ClinicalImpression | CodeSystem | Communication | CompartmentDefinition | Composition | ConceptMap | Condition | Consent | Contract | CoverageEligibilityRequest | CoverageEligibilityResponse | DetectedIssue | Device | DeviceDefinition | DeviceMetric | DeviceUseStatement | DiagnosticReport | DocumentManifest | DocumentReference | Endpoint | EnrollmentRequest | EnrollmentResponse | EpisodeOfCare | EventDefinition | Evidence | EvidenceVariable | ExampleScenario | ExplanationOfBenefit | FamilyMemberHistory | Flag | Goal | GraphDefinition | Group | GuidanceResponse | HealthcareService | ImagingStudy | Immunization | ImmunizationEvaluation | ImmunizationRecommendation | ImplementationGuide | InsurancePlan | Invoice | Library | Linkage | List | Measure | MeasureReport | Media | Medication | MedicationAdministration | MedicationDispense | MedicationKnowledge | MedicationRequest | MedicationStatement | MedicinalProduct | MessageDefinition | MessageHeader | MolecularSequence | NamingSystem | NutritionOrder | Observation | ObservationDefinition | OperationDefinition | OperationOutcome | OrganizationAffiliation | Parameters | PaymentNotice | PaymentReconciliation | Person | PlanDefinition | Procedure | Provenance | Questionnaire | QuestionnaireResponse | RelatedPerson | RequestGroup | ResearchDefinition | ResearchElementDefinition | ResearchStudy | ResearchSubject | RiskAssessment | RiskEvidenceSynthesis | Schedule | SearchParameter | Slot | Specimen | SpecimenDefinition | StructureDefinition | StructureMap | Subscription | Substance | SubstanceSpecification | SupplyDelivery | SupplyRequest | Task | TerminologyCapabilities | TestReport | TestScript | ValueSet | VerificationResult | VisionPrescription;
