import { Organization } from "fhir/r4";
export interface PASOrganization extends Organization {
    /** Must Support */
    active: boolean;
    /** Must Support */
    name: string;
}
export declare function validatePASOrganization(resource: PASOrganization): Promise<{
    errors: string[];
    warnings: string[];
}>;
