import { Extension } from "fhir/r4";
export interface DeliveryPattern extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-timingdeliverypattern";
}
export declare function validateDeliveryPattern(resource: DeliveryPattern): Promise<{
    errors: string[];
    warnings: string[];
}>;
