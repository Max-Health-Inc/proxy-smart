import { PASClaimUpdate } from "./PASClaimUpdate.js";
export declare class PASClaimUpdateClass {
    private resource;
    /** Pattern constraints for profile fields (used by random() generator) */
    protected static readonly _fieldPatterns: {
        "encounter.url": string;
        status: string;
        use: string;
        "OverallClaimMember.careTeamClaimScope.url": string;
        "OverallClaimMember.careTeamClaimScope": boolean;
        "ItemClaimMember.careTeamClaimScope.url": string;
        "supportingInfo.category": string;
        category: {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "AdmissionDates.category": string;
        "DischargeDates.category": string;
        "AdditionalInformation.category": string;
        "MessageText.category": string;
        "diagnosis.type": string;
        "insurance.focal": boolean;
        "item.nursingHomeResidentialStatus.url": string;
        "item.productOrService": string;
        "PatientEvent.category": string;
        _refReq_extension: {
            url: boolean;
            valueReference: boolean;
        };
        _refReq_payee: {
            type: boolean;
        };
        _refReq_careTeam: {
            extension: {
                profile: string;
            };
            sequence: boolean;
            provider: boolean;
            "extension.url": boolean;
        };
        _refReq_supportingInfo: {
            sequence: boolean;
            category: boolean;
            timingDate: boolean;
            valueReference: boolean;
            valueString: boolean;
        };
        _refReq_diagnosis: {
            sequence: boolean;
            diagnosisCodeableConcept: boolean;
        };
        _refReq_procedure: {
            sequence: boolean;
            procedureCodeableConcept: boolean;
        };
        _refReq_insurance: {
            sequence: boolean;
            focal: boolean;
            coverage: boolean;
        };
        _refReq_accident: {
            date: boolean;
        };
        _refReq_item: {
            "extension.url": boolean;
            sequence: boolean;
            category: boolean;
            productOrService: boolean;
            "detail.sequence": boolean;
            "detail.productOrService": boolean;
            "detail.subDetail.sequence": boolean;
            "detail.subDetail.productOrService": boolean;
        };
    };
    /** Fields that are forbidden (max=0) in this profile - must not be generated */
    protected static readonly _forbiddenFields: string[];
    /** FHIR element ordering for this profile's base resource (used by enrichResource for correct JSON field order) */
    protected static readonly _fieldOrder: string[];
    /** ValueSet bindings for coded fields - maps field name to ValueSet URL */
    static readonly valueSetBindings: Record<string, string>;
    /** Code resolver for ValueSet bindings - returns a random valid code from a ValueSet by URL */
    protected static readonly _codeResolver: ((url: string) => {
        code: string;
        system: string;
        display?: string;
    } | undefined) | undefined;
    constructor(resource: PASClaimUpdate);
    /** Validate current resource instance. */
    validate(): Promise<{
        errors: string[];
        warnings: string[];
    }>;
    getResource(): PASClaimUpdate;
    setResource(resource: PASClaimUpdate): void;
    /**
     * Returns a plain JSON clone of the underlying resource ONLY if the last validation succeeded with zero errors.
     * Call validate() first; otherwise this method throws to prevent accidental use of invalid / unchecked data.
     */
    toJSON(): Promise<PASClaimUpdate>;
    /**
     * Create an empty instance for parity testing: for true FHIR resources, includes only resourceType; for datatypes, returns an empty object.
     * Note: meta.profile (when applicable) will be ensured by the constructor when wrapping this resource.
     */
    static empty(overrides?: Partial<PASClaimUpdate>): PASClaimUpdate;
    /**
     * Create a minimal randomized instance of PASClaimUpdate.
     * Populates id, resourceType (if applicable) and primitive required (min>0) top-level fields with placeholders.
     */
    static random(overrides?: Partial<PASClaimUpdate>, opts?: {
        seed?: number;
    }): PASClaimUpdate;
    /** Convenience: returns a class instance wrapping a randomized resource. */
    static randomClass(overrides?: Partial<PASClaimUpdate>, opts?: {
        seed?: number;
    }): PASClaimUpdateClass;
}
