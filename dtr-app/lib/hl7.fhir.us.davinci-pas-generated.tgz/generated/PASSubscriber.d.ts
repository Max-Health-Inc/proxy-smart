import { MilitaryStatus } from "./MilitaryStatus";
import { UsCoreBirthsex } from "./UsCoreBirthsex";
import { UsCoreEthnicity } from "./UsCoreEthnicity";
import { UsCoreRace } from "./UsCoreRace";
import { Extension, HumanName, Patient } from "fhir/r4";
export interface PASSubscriber extends Patient {
    /** Must Support */
    name: HumanName[];
    extension?: (Extension | UsCoreRace | UsCoreEthnicity | UsCoreBirthsex | MilitaryStatus)[];
}
export declare function validatePASSubscriber(resource: PASSubscriber): Promise<{
    errors: string[];
    warnings: string[];
}>;
