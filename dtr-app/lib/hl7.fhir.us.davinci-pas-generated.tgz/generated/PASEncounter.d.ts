import { NursingHomeResidentialStatus } from "./NursingHomeResidentialStatus";
import { PatientStatus } from "./PatientStatus";
import { CodeableConcept, Encounter, Extension, Reference } from "fhir/r4";
export interface PASEncounter extends Encounter {
    status: "planned";
    /** Must Support */
    type: CodeableConcept[];
    /** Must Support */
    subject: Reference;
    extension?: (Extension | PatientStatus | NursingHomeResidentialStatus)[];
}
export declare function validatePASEncounter(resource: PASEncounter): Promise<{
    errors: string[];
    warnings: string[];
}>;
