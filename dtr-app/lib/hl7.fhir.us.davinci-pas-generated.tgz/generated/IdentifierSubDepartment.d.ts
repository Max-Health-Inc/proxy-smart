import { Extension } from "fhir/r4";
export interface IdentifierSubDepartment extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-identifierSubDepartment";
}
export declare function validateIdentifierSubDepartment(resource: IdentifierSubDepartment): Promise<{
    errors: string[];
    warnings: string[];
}>;
