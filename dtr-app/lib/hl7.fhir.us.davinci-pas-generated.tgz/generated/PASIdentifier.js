import fhirpath from "fhirpath";
import fhirpath_r4_model from "fhirpath/fhir-context/r4/index.js";
export async function validatePASIdentifier(resource) {
    const errors = [];
    const warnings = [];
    const result0 = await Promise.resolve(fhirpath.evaluate(resource, "Identifier.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result0.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result1 = await Promise.resolve(fhirpath.evaluate(resource, "extension.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result1.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result2 = await Promise.resolve(fhirpath.evaluate(resource, "use.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result2.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result3 = await Promise.resolve(fhirpath.evaluate(resource, "type.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result3.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result4 = await Promise.resolve(fhirpath.evaluate(resource, "system.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result4.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result5 = await Promise.resolve(fhirpath.evaluate(resource, "value.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result5.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result6 = await Promise.resolve(fhirpath.evaluate(resource, "period.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result6.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result7 = await Promise.resolve(fhirpath.evaluate(resource, "assigner.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result7.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result8 = await Promise.resolve(fhirpath.evaluate(resource, "Element.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result8.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result9 = await Promise.resolve(fhirpath.evaluate(resource, "extension.count() <= 1", { resource }, fhirpath_r4_model));
    if (!result9.every(Boolean)) {
        errors.push("Constraint violation: extension must contain at most one element");
    }
    return { errors, warnings };
}
