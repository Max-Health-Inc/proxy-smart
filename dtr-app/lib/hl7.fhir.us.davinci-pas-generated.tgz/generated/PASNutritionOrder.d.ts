import { CRDCoverageInformation } from "./CRDCoverageInformation";
import { SimpleQuantity } from "./SimpleQuantity";
import { CodeableConcept, Extension, NutritionOrder, NutritionOrderEnteralFormula, NutritionOrderOralDiet, Reference } from "fhir/r4";
export interface PASNutritionOrderOralDiet extends NutritionOrderOralDiet {
    /** Must Support */
    type?: CodeableConcept[];
}
export interface PASNutritionOrderEnteralFormula extends NutritionOrderEnteralFormula {
    /** Must Support */
    baseFormulaType?: CodeableConcept;
    caloricDensity?: SimpleQuantity;
    maxVolumeToDeliver?: SimpleQuantity;
}
export interface PASNutritionOrder extends NutritionOrder {
    intent: "order";
    /** Must Support */
    patient: Reference;
    /** Must Support */
    oralDiet?: PASNutritionOrderOralDiet;
    /** Must Support */
    enteralFormula?: PASNutritionOrderEnteralFormula;
    extension?: (Extension | CRDCoverageInformation)[];
}
export declare function validatePASNutritionOrder(resource: PASNutritionOrder): Promise<{
    errors: string[];
    warnings: string[];
}>;
