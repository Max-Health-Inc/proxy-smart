import fhirpath from "fhirpath";
import fhirpath_r4_model from "fhirpath/fhir-context/r4/index.js";
export async function validatePASTiming(resource) {
    const errors = [];
    const warnings = [];
    const result0 = await Promise.resolve(fhirpath.evaluate(resource, "Timing.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result0.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result1 = await Promise.resolve(fhirpath.evaluate(resource, "extension.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result1.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result2 = await Promise.resolve(fhirpath.evaluate(resource, "modifierExtension.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result2.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result3 = await Promise.resolve(fhirpath.evaluate(resource, "event.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result3.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result4 = await Promise.resolve(fhirpath.evaluate(resource, "repeat.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result4.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result5 = await Promise.resolve(fhirpath.evaluate(resource, "repeat.all(duration.empty() or durationUnit.exists())", { resource }, fhirpath_r4_model));
    if (!result5.every(Boolean)) {
        errors.push("Constraint violation: if there's a duration, there needs to be duration units");
    }
    const result6 = await Promise.resolve(fhirpath.evaluate(resource, "repeat.all(period.empty() or periodUnit.exists())", { resource }, fhirpath_r4_model));
    if (!result6.every(Boolean)) {
        errors.push("Constraint violation: if there's a period, there needs to be period units");
    }
    const result7 = await Promise.resolve(fhirpath.evaluate(resource, "repeat.all(duration.exists() implies duration >= 0)", { resource }, fhirpath_r4_model));
    if (!result7.every(Boolean)) {
        errors.push("Constraint violation: duration SHALL be a non-negative value");
    }
    const result8 = await Promise.resolve(fhirpath.evaluate(resource, "repeat.all(period.exists() implies period >= 0)", { resource }, fhirpath_r4_model));
    if (!result8.every(Boolean)) {
        errors.push("Constraint violation: period SHALL be a non-negative value");
    }
    const result9 = await Promise.resolve(fhirpath.evaluate(resource, "repeat.all(periodMax.empty() or period.exists())", { resource }, fhirpath_r4_model));
    if (!result9.every(Boolean)) {
        errors.push("Constraint violation: If there's a periodMax, there must be a period");
    }
    const result10 = await Promise.resolve(fhirpath.evaluate(resource, "repeat.all(durationMax.empty() or duration.exists())", { resource }, fhirpath_r4_model));
    if (!result10.every(Boolean)) {
        errors.push("Constraint violation: If there's a durationMax, there must be a duration");
    }
    const result11 = await Promise.resolve(fhirpath.evaluate(resource, "repeat.all(countMax.empty() or count.exists())", { resource }, fhirpath_r4_model));
    if (!result11.every(Boolean)) {
        errors.push("Constraint violation: If there's a countMax, there must be a count");
    }
    const result12 = await Promise.resolve(fhirpath.evaluate(resource, "repeat.all(offset.empty() or (when.exists() and ((when in ('C' | 'CM' | 'CD' | 'CV')).not())))", { resource }, fhirpath_r4_model));
    if (!result12.every(Boolean)) {
        errors.push("Constraint violation: If there's an offset, there must be a when (and not C, CM, CD, CV)");
    }
    const result13 = await Promise.resolve(fhirpath.evaluate(resource, "repeat.all(timeOfDay.empty() or when.empty())", { resource }, fhirpath_r4_model));
    if (!result13.every(Boolean)) {
        errors.push("Constraint violation: If there's a timeOfDay, there cannot be a when, or vice versa");
    }
    const result14 = await Promise.resolve(fhirpath.evaluate(resource, "code.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result14.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result15 = await Promise.resolve(fhirpath.evaluate(resource, "BackboneElement.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result15.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result16 = await Promise.resolve(fhirpath.evaluate(resource, "Element.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model));
    if (!result16.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result17 = await Promise.resolve(fhirpath.evaluate(resource, "extension.count() <= 1", { resource }, fhirpath_r4_model));
    if (!result17.every(Boolean)) {
        errors.push("Constraint violation: extension must contain at most one element");
    }
    return { errors, warnings };
}
