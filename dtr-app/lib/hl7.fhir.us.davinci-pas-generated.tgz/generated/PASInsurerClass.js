import { validatePASInsurer } from "./PASInsurer.js";
// Only import helpers actually referenced below (dynamic based on required fields)
import { randomId, setRandomSeed, enrichResource } from "./RandomSupport.js";
function ensureProfile(res, profile) {
    if (!res.meta) {
        res.meta = { profile: [profile] };
        return;
    }
    if (!res.meta.profile) {
        res.meta.profile = [profile];
        return;
    }
    if (!res.meta.profile.includes(profile)) {
        res.meta.profile = [...res.meta.profile, profile];
    }
}
// Internal helper (emitted per class file) to clone without resorting to 'any'.
function safeClone(value) {
    // Use native structuredClone if present; otherwise fallback to JSON round-trip.
    // We intentionally avoid casting through any to satisfy no-explicit-any lint rule.
    const g = globalThis;
    // Narrow globalThis to an object potentially containing structuredClone.
    if (typeof g.structuredClone === 'function') {
        return g.structuredClone(value);
    }
    return JSON.parse(JSON.stringify(value)); // best-effort deep clone
}
export class PASInsurerClass {
    constructor(resource) {
        this.resource = resource;
        ensureProfile(this.resource, 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-insurer');
    }
    /** Validate current resource instance. */
    async validate() {
        return validatePASInsurer(this.resource);
    }
    getResource() {
        return this.resource;
    }
    setResource(resource) {
        this.resource = resource;
        ensureProfile(this.resource, 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-insurer');
    }
    /**
     * Returns a plain JSON clone of the underlying resource ONLY if the last validation succeeded with zero errors.
     * Call validate() first; otherwise this method throws to prevent accidental use of invalid / unchecked data.
     */
    async toJSON() {
        return safeClone(this.resource);
    }
    /**
     * Create an empty instance for parity testing: for true FHIR resources, includes only resourceType; for datatypes, returns an empty object.
     * Note: meta.profile (when applicable) will be ensured by the constructor when wrapping this resource.
     */
    static empty(overrides = {}) {
        // For Resource profiles, include only resourceType. For Extension profiles, include url so the instance is minimally meaningful.
        const base = {
            resourceType: 'Organization',
        };
        return { ...base, ...overrides };
    }
    /**
     * Create a minimal randomized instance of PASInsurer.
     * Populates id, resourceType (if applicable) and primitive required (min>0) top-level fields with placeholders.
     */
    static random(overrides = {}, opts) {
        if (opts?.seed !== undefined) {
            // Direct call (no dynamic require) to ensure deterministic seeding works under ESM.
            setRandomSeed(opts.seed);
        }
        // Start with a Partial to avoid unsafe casting errors; we'll assert at the end.
        const base = { resourceType: 'Organization', id: randomId(), active: false, name: 'Example Organization', };
        // Always include meta.profile with this profile's canonical URL if available & only for resource profiles
        ensureProfile(base, 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-insurer');
        // Enrich the base resource with common fields using centralized enrichment logic
        enrichResource(base, 'Organization', 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-insurer', PASInsurerClass._fieldPatterns, PASInsurerClass._forbiddenFields, PASInsurerClass.valueSetBindings, PASInsurerClass._codeResolver);
        // Cast through unknown to acknowledge dynamic enrichment
        return { ...base, ...overrides };
    }
    /** Convenience: returns a class instance wrapping a randomized resource. */
    static randomClass(overrides = {}, opts) {
        return new PASInsurerClass(this.random(overrides, opts));
    }
}
/** Pattern constraints for profile fields (used by random() generator) */
PASInsurerClass._fieldPatterns = {
    "identifier": {
        "system": "http://hl7.org/fhir/sid/us-npi"
    },
    "_refReq_identifier": {
        "system": true
    }
};
/** Fields that are forbidden (max=0) in this profile - must not be generated */
PASInsurerClass._forbiddenFields = [];
/** ValueSet bindings for coded fields - maps field name to ValueSet URL */
PASInsurerClass.valueSetBindings = {
    "language": "http://hl7.org/fhir/ValueSet/languages",
    "identifier.use": "http://hl7.org/fhir/ValueSet/identifier-use|4.0.1",
    "identifier.type": "http://hl7.org/fhir/ValueSet/identifier-type",
    "type": "https://valueset.x12.org/x217/005010/request/2010A/NM1/1/01/00/98",
    "address.use": "http://hl7.org/fhir/ValueSet/address-use|4.0.1",
    "address.type": "http://hl7.org/fhir/ValueSet/address-type|4.0.1",
    "address.state": "http://hl7.org/fhir/us/core/ValueSet/us-core-usps-state",
    "contact.purpose": "http://hl7.org/fhir/ValueSet/contactentity-type"
};
/** Code resolver for ValueSet bindings - returns a random valid code from a ValueSet by URL */
PASInsurerClass._codeResolver = (() => {
    // Try to dynamically import the ValueSetRegistry - it may not exist if no ValueSets were generated
    try {
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        const registry = require('./valuesets/index.js');
        if (registry && typeof registry.getRandomConceptByUrl === 'function') {
            return registry.getRandomConceptByUrl;
        }
    }
    catch { /* ValueSetRegistry not available */ }
    return undefined;
})();
