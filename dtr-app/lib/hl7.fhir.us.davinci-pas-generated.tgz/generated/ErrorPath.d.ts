import { Extension } from "fhir/r4";
export interface ErrorPath extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-errorPath";
}
export declare function validateErrorPath(resource: ErrorPath): Promise<{
    errors: string[];
    warnings: string[];
}>;
