import { Extension } from "fhir/r4";
export interface ServiceLineNumber extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-serviceLineNumber";
}
export declare function validateServiceLineNumber(resource: ServiceLineNumber): Promise<{
    errors: string[];
    warnings: string[];
}>;
