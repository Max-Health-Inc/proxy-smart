import { Extension } from "fhir/r4";
export interface PatientStatus extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-patientStatus";
}
export declare function validatePatientStatus(resource: PatientStatus): Promise<{
    errors: string[];
    warnings: string[];
}>;
