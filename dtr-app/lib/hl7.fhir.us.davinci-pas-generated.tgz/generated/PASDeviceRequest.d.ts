import { CRDCoverageInformation } from "./CRDCoverageInformation";
import { DeviceRequest, Extension, Reference } from "fhir/r4";
export interface PASDeviceRequest extends DeviceRequest {
    intent: "order";
    /** Must Support */
    subject: Reference;
    extension?: (Extension | CRDCoverageInformation)[];
}
export declare function validatePASDeviceRequest(resource: PASDeviceRequest): Promise<{
    errors: string[];
    warnings: string[];
}>;
