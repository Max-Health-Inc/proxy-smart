import { Extension } from "fhir/r4";
export interface CertificationEffectiveDate extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemCertificationEffectiveDate";
}
export declare function validateCertificationEffectiveDate(resource: CertificationEffectiveDate): Promise<{
    errors: string[];
    warnings: string[];
}>;
