import type { HumanName, Address, Coding, CodeableConcept, Identifier, Reference, Period, ContactPoint, Quantity } from 'fhir/r4';
export declare function setRandomSeed(seed: number): void;
export declare function randomId(): string;
export declare function randomString(prefix?: string): string;
export declare function randomInt(min?: number, max?: number): number;
export declare function randomBool(): boolean;
export declare function randomDate(start?: Date, end?: Date): string;
export declare function randomCode(codes: string[]): string;
/**
 * Generate a valid UUID v4 (random) for use in urn:uuid: URIs.
 * This generates proper hex-formatted UUIDs that are valid for FHIR fullUrl and identifier values.
 */
export declare function randomUUID(): string;
/**
 * Generate a valid US National Provider Identifier (NPI).
 * NPIs are 10-digit numbers that pass the US Core Luhn check.
 * The US Core us-core-17 constraint uses a specific algorithm:
 * - Doubles digits at positions 0, 2, 4, 6, 8 (even positions from left)
 * - If doubled value >= 10, subtracts 9
 * - Adds 24 (constant for '80' prefix)
 * - Sum must be divisible by 10
 */
export declare function randomNPI(): string;
export declare function skeletonHumanName(): HumanName;
export declare function skeletonAddress(): Address;
export declare function skeletonCoding(system?: string, codes?: string[]): Coding;
export declare function skeletonCodeableConcept(system?: string, codes?: string[]): CodeableConcept;
export declare function skeletonIdentifier(system?: string): Identifier;
export declare function skeletonReference(resourceType?: string): Reference;
export declare function skeletonPeriod(): Period;
export declare function skeletonContactPoint(): ContactPoint;
export declare function skeletonQuantity(): Quantity;
/**
 * Enrich a base resource with common fields based on resourceType and profile patterns.
/** Resolved code from a ValueSet binding */
export type ResolvedCode = {
    code: string;
    system: string;
    display?: string;
};
/** Code resolver function type - looks up a random code by ValueSet URL */
export type CodeResolver = (valueSetUrl: string) => ResolvedCode | undefined;
/**
 * This is a centralized enrichment function used by all generated random() methods.
 * @param base - The base resource object to enrich (will be mutated)
 * @param baseResource - The FHIR resource type (e.g., 'Observation', 'Patient')
 * @param profileUrl - The canonical URL of the profile
 * @param fieldPatterns - Map of field names to their pattern constraints
 * @param forbiddenFields - Array of field names that are forbidden (max=0) in this profile
 * @param valueSetBindings - Map of field names to ValueSet URLs for coded bindings
 * @param codeResolver - Optional function to resolve a ValueSet URL to a random valid code
 */
export declare function enrichResource(base: Record<string, unknown>, baseResource: string, profileUrl: string, fieldPatterns: Record<string, unknown>, forbiddenFields?: string[], valueSetBindings?: Record<string, string>, codeResolver?: CodeResolver): void;
