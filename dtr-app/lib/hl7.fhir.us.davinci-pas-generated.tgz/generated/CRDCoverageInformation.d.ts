import { Extension } from "fhir/r4";
export interface CRDCoverageInformation extends Extension {
    extension: Extension[];
    url: "http://hl7.org/fhir/us/davinci-crd/StructureDefinition/ext-coverage-information";
}
export declare function validateCRDCoverageInformation(resource: CRDCoverageInformation): Promise<{
    errors: string[];
    warnings: string[];
}>;
