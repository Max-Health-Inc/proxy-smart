import { PASInquiryResponseBundle } from "./PASInquiryResponseBundle.js";
export declare class PASInquiryResponseBundleClass {
    private resource;
    /** Pattern constraints for profile fields (used by random() generator) */
    protected static readonly _fieldPatterns: {
        type: string;
        _refReq_link: {
            relation: boolean;
            url: boolean;
        };
        _refReq_entry: {
            fullUrl: boolean;
            resource: boolean;
            "request.method": boolean;
            "request.url": boolean;
            "response.status": boolean;
        };
    };
    /** Fields that are forbidden (max=0) in this profile - must not be generated */
    protected static readonly _forbiddenFields: string[];
    /** ValueSet bindings for coded fields - maps field name to ValueSet URL */
    static readonly valueSetBindings: Record<string, string>;
    /** Code resolver for ValueSet bindings - returns a random valid code from a ValueSet by URL */
    protected static readonly _codeResolver: ((url: string) => {
        code: string;
        system: string;
        display?: string;
    } | undefined) | undefined;
    constructor(resource: PASInquiryResponseBundle);
    /** Validate current resource instance. */
    validate(): Promise<{
        errors: string[];
        warnings: string[];
    }>;
    getResource(): PASInquiryResponseBundle;
    setResource(resource: PASInquiryResponseBundle): void;
    /**
     * Returns a plain JSON clone of the underlying resource ONLY if the last validation succeeded with zero errors.
     * Call validate() first; otherwise this method throws to prevent accidental use of invalid / unchecked data.
     */
    toJSON(): Promise<PASInquiryResponseBundle>;
    /**
     * Create an empty instance for parity testing: for true FHIR resources, includes only resourceType; for datatypes, returns an empty object.
     * Note: meta.profile (when applicable) will be ensured by the constructor when wrapping this resource.
     */
    static empty(overrides?: Partial<PASInquiryResponseBundle>): PASInquiryResponseBundle;
    /**
     * Create a minimal randomized instance of PASInquiryResponseBundle.
     * Populates id, resourceType (if applicable) and primitive required (min>0) top-level fields with placeholders.
     */
    static random(overrides?: Partial<PASInquiryResponseBundle>, opts?: {
        seed?: number;
    }): PASInquiryResponseBundle;
    /** Convenience: returns a class instance wrapping a randomized resource. */
    static randomClass(overrides?: Partial<PASInquiryResponseBundle>, opts?: {
        seed?: number;
    }): PASInquiryResponseBundleClass;
}
