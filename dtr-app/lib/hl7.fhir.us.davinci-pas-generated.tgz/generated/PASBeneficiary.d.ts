import { UsCoreBirthsex } from "./UsCoreBirthsex";
import { UsCoreEthnicity } from "./UsCoreEthnicity";
import { UsCoreRace } from "./UsCoreRace";
import { Extension, HumanName, Patient } from "fhir/r4";
export interface PASBeneficiary extends Patient {
    /** Must Support */
    name: HumanName[];
    extension?: (Extension | UsCoreRace | UsCoreEthnicity | UsCoreBirthsex)[];
}
export declare function validatePASBeneficiary(resource: PASBeneficiary): Promise<{
    errors: string[];
    warnings: string[];
}>;
