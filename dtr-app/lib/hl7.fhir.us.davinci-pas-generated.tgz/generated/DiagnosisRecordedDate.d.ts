import { Extension } from "fhir/r4";
export interface DiagnosisRecordedDate extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-diagnosisRecordedDate";
}
export declare function validateDiagnosisRecordedDate(resource: DiagnosisRecordedDate): Promise<{
    errors: string[];
    warnings: string[];
}>;
