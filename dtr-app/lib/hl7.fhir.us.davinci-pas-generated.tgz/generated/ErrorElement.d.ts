import { Extension } from "fhir/r4";
export interface ErrorElement extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-errorElement";
}
export declare function validateErrorElement(resource: ErrorElement): Promise<{
    errors: string[];
    warnings: string[];
}>;
