/**
 * ValueSet: imagingstudy-status
 * URL: http://hl7.org/fhir/ValueSet/imagingstudy-status
 * Size: 5 concepts
 */
export declare const ImagingstudyStatusConcepts: readonly [{
    readonly code: "registered";
    readonly system: "http://hl7.org/fhir/imagingstudy-status";
}, {
    readonly code: "available";
    readonly system: "http://hl7.org/fhir/imagingstudy-status";
}, {
    readonly code: "cancelled";
    readonly system: "http://hl7.org/fhir/imagingstudy-status";
}, {
    readonly code: "entered-in-error";
    readonly system: "http://hl7.org/fhir/imagingstudy-status";
}, {
    readonly code: "unknown";
    readonly system: "http://hl7.org/fhir/imagingstudy-status";
}];
/** Union type of all valid codes in this ValueSet */
export type ImagingstudyStatusCode = "registered" | "available" | "cancelled" | "entered-in-error" | "unknown";
/** Type representing a concept from this ValueSet */
export type ImagingstudyStatusConcept = typeof ImagingstudyStatusConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidImagingstudyStatusCode(code: string): code is ImagingstudyStatusCode;
/**
 * Get concept details by code
 */
export declare function getImagingstudyStatusConcept(code: string): ImagingstudyStatusConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ImagingstudyStatusCodes: ("unknown" | "entered-in-error" | "registered" | "cancelled" | "available")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomImagingstudyStatusCode(): ImagingstudyStatusCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomImagingstudyStatusConcept(): ImagingstudyStatusConcept;
