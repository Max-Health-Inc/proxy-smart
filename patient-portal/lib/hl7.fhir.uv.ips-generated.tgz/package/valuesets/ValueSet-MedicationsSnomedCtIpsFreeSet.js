/**
 * ValueSet: MedicationsSnomedCtIpsFreeSet
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/medications-snomed-ct-ips-free-set
 * Size: 10 concepts
 */
export const MedicationsSnomedCtIpsFreeSetConcepts = [
    { code: "774702006", system: "http://snomed.info/sct" },
    { code: "418268006", system: "http://snomed.info/sct" },
    { code: "346469000", system: "http://snomed.info/sct" },
    { code: "346468008", system: "http://snomed.info/sct" },
    { code: "346467003", system: "http://snomed.info/sct" },
    { code: "346405008", system: "http://snomed.info/sct" },
    { code: "346364006", system: "http://snomed.info/sct" },
    { code: "346313005", system: "http://snomed.info/sct" },
    { code: "320835005", system: "http://snomed.info/sct" },
    { code: "63338004", system: "http://snomed.info/sct" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidMedicationsSnomedCtIpsFreeSetCode(code) {
    return MedicationsSnomedCtIpsFreeSetConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getMedicationsSnomedCtIpsFreeSetConcept(code) {
    return MedicationsSnomedCtIpsFreeSetConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const MedicationsSnomedCtIpsFreeSetCodes = MedicationsSnomedCtIpsFreeSetConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomMedicationsSnomedCtIpsFreeSetCode() {
    return MedicationsSnomedCtIpsFreeSetCodes[Math.floor(Math.random() * MedicationsSnomedCtIpsFreeSetCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomMedicationsSnomedCtIpsFreeSetConcept() {
    return MedicationsSnomedCtIpsFreeSetConcepts[Math.floor(Math.random() * MedicationsSnomedCtIpsFreeSetConcepts.length)];
}
