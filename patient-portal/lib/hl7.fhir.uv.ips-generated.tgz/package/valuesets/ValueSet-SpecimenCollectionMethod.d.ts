/**
 * ValueSet: specimen-collection-method
 * URL: http://hl7.org/fhir/ValueSet/specimen-collection-method
 * Size: 10 concepts
 */
export declare const SpecimenCollectionMethodConcepts: readonly [{
    readonly code: "129316008";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "129314006";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "129300006";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "129304002";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "129323009";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "73416001";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "225113003";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "70777001";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "386089008";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "278450005";
    readonly system: "http://snomed.info/sct";
}];
/** Union type of all valid codes in this ValueSet */
export type SpecimenCollectionMethodCode = "129316008" | "129314006" | "129300006" | "129304002" | "129323009" | "73416001" | "225113003" | "70777001" | "386089008" | "278450005";
/** Type representing a concept from this ValueSet */
export type SpecimenCollectionMethodConcept = typeof SpecimenCollectionMethodConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidSpecimenCollectionMethodCode(code: string): code is SpecimenCollectionMethodCode;
/**
 * Get concept details by code
 */
export declare function getSpecimenCollectionMethodConcept(code: string): SpecimenCollectionMethodConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const SpecimenCollectionMethodCodes: ("129314006" | "386089008" | "278450005" | "225113003" | "73416001" | "70777001" | "129316008" | "129300006" | "129304002" | "129323009")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomSpecimenCollectionMethodCode(): SpecimenCollectionMethodCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomSpecimenCollectionMethodConcept(): SpecimenCollectionMethodConcept;
