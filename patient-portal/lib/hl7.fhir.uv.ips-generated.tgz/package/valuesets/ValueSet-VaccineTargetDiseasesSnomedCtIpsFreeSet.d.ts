/**
 * ValueSet: VaccineTargetDiseasesSnomedCtIpsFreeSet
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/target-diseases-snomed-ct-ips-free-set
 * Size: 22 concepts
 */
export declare const VaccineTargetDiseasesSnomedCtIpsFreeSetConcepts: readonly [{
    readonly code: "4834000";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "6142004";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "14189004";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "23502006";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "24662006";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "25225006";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "27836007";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "32398004";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "36989005";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "38907003";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "40468003";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "50711007";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "56717001";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "66071002";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "70036007";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "76902006";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "186150001";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "240532009";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "372244006";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "398102009";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "442438000";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "840539006";
    readonly system: "http://snomed.info/sct";
}];
/** String type (ValueSet too large for union type) */
export type VaccineTargetDiseasesSnomedCtIpsFreeSetCode = string;
/** Type representing a concept from this ValueSet */
export type VaccineTargetDiseasesSnomedCtIpsFreeSetConcept = typeof VaccineTargetDiseasesSnomedCtIpsFreeSetConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidVaccineTargetDiseasesSnomedCtIpsFreeSetCode(code: string): code is VaccineTargetDiseasesSnomedCtIpsFreeSetCode;
/**
 * Get concept details by code
 */
export declare function getVaccineTargetDiseasesSnomedCtIpsFreeSetConcept(code: string): VaccineTargetDiseasesSnomedCtIpsFreeSetConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const VaccineTargetDiseasesSnomedCtIpsFreeSetCodes: ("840539006" | "442438000" | "398102009" | "372244006" | "240532009" | "186150001" | "76902006" | "70036007" | "66071002" | "56717001" | "50711007" | "40468003" | "38907003" | "36989005" | "32398004" | "27836007" | "25225006" | "24662006" | "23502006" | "14189004" | "6142004" | "4834000")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomVaccineTargetDiseasesSnomedCtIpsFreeSetCode(): VaccineTargetDiseasesSnomedCtIpsFreeSetCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomVaccineTargetDiseasesSnomedCtIpsFreeSetConcept(): VaccineTargetDiseasesSnomedCtIpsFreeSetConcept;
