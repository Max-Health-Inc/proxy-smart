/**
 * ValueSet: ResultsSpecimenTypeSnomedCtIpsFreeSet
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/results-specimen-type-snomed-ct-ips-free-set
 * Size: 127 concepts
 */
export const ResultsSpecimenTypeSnomedCtIpsFreeSetConcepts = [
    { code: "708048008", system: "http://snomed.info/sct" },
    { code: "702701006", system: "http://snomed.info/sct" },
    { code: "698276005", system: "http://snomed.info/sct" },
    { code: "472896000", system: "http://snomed.info/sct" },
    { code: "472881004", system: "http://snomed.info/sct" },
    { code: "472867001", system: "http://snomed.info/sct" },
    { code: "446861007", system: "http://snomed.info/sct" },
    { code: "446846006", system: "http://snomed.info/sct" },
    { code: "446562005", system: "http://snomed.info/sct" },
    { code: "446302006", system: "http://snomed.info/sct" },
    { code: "446272009", system: "http://snomed.info/sct" },
    { code: "440500007", system: "http://snomed.info/sct" },
    { code: "440493002", system: "http://snomed.info/sct" },
    { code: "440473005", system: "http://snomed.info/sct" },
    { code: "440137008", system: "http://snomed.info/sct" },
    { code: "439961009", system: "http://snomed.info/sct" },
    { code: "438660002", system: "http://snomed.info/sct" },
    { code: "432825001", system: "http://snomed.info/sct" },
    { code: "430268003", system: "http://snomed.info/sct" },
    { code: "408654003", system: "http://snomed.info/sct" },
    { code: "399713008", system: "http://snomed.info/sct" },
    { code: "309502007", system: "http://snomed.info/sct" },
    { code: "309213006", system: "http://snomed.info/sct" },
    { code: "309211008", system: "http://snomed.info/sct" },
    { code: "309210009", system: "http://snomed.info/sct" },
    { code: "309176002", system: "http://snomed.info/sct" },
    { code: "309166000", system: "http://snomed.info/sct" },
    { code: "309075001", system: "http://snomed.info/sct" },
    { code: "309068002", system: "http://snomed.info/sct" },
    { code: "309067007", system: "http://snomed.info/sct" },
    { code: "309066003", system: "http://snomed.info/sct" },
    { code: "309051001", system: "http://snomed.info/sct" },
    { code: "309049000", system: "http://snomed.info/sct" },
    { code: "302795002", system: "http://snomed.info/sct" },
    { code: "302794003", system: "http://snomed.info/sct" },
    { code: "278020009", system: "http://snomed.info/sct" },
    { code: "258649003", system: "http://snomed.info/sct" },
    { code: "258609006", system: "http://snomed.info/sct" },
    { code: "258607008", system: "http://snomed.info/sct" },
    { code: "258603007", system: "http://snomed.info/sct" },
    { code: "258591005", system: "http://snomed.info/sct" },
    { code: "258580003", system: "http://snomed.info/sct" },
    { code: "258574006", system: "http://snomed.info/sct" },
    { code: "258531008", system: "http://snomed.info/sct" },
    { code: "258530009", system: "http://snomed.info/sct" },
    { code: "258528007", system: "http://snomed.info/sct" },
    { code: "258523003", system: "http://snomed.info/sct" },
    { code: "258520000", system: "http://snomed.info/sct" },
    { code: "258505006", system: "http://snomed.info/sct" },
    { code: "258503004", system: "http://snomed.info/sct" },
    { code: "258502009", system: "http://snomed.info/sct" },
    { code: "258500001", system: "http://snomed.info/sct" },
    { code: "258498002", system: "http://snomed.info/sct" },
    { code: "258482009", system: "http://snomed.info/sct" },
    { code: "258474009", system: "http://snomed.info/sct" },
    { code: "258463000", system: "http://snomed.info/sct" },
    { code: "258459007", system: "http://snomed.info/sct" },
    { code: "258455001", system: "http://snomed.info/sct" },
    { code: "258453008", system: "http://snomed.info/sct" },
    { code: "258450006", system: "http://snomed.info/sct" },
    { code: "258442002", system: "http://snomed.info/sct" },
    { code: "258441009", system: "http://snomed.info/sct" },
    { code: "258440005", system: "http://snomed.info/sct" },
    { code: "258438000", system: "http://snomed.info/sct" },
    { code: "258435002", system: "http://snomed.info/sct" },
    { code: "258415003", system: "http://snomed.info/sct" },
    { code: "257261003", system: "http://snomed.info/sct" },
    { code: "168141000", system: "http://snomed.info/sct" },
    { code: "168139001", system: "http://snomed.info/sct" },
    { code: "168138009", system: "http://snomed.info/sct" },
    { code: "168137004", system: "http://snomed.info/sct" },
    { code: "122880004", system: "http://snomed.info/sct" },
    { code: "122877000", system: "http://snomed.info/sct" },
    { code: "122609004", system: "http://snomed.info/sct" },
    { code: "122593002", system: "http://snomed.info/sct" },
    { code: "122580007", system: "http://snomed.info/sct" },
    { code: "122575003", system: "http://snomed.info/sct" },
    { code: "122572000", system: "http://snomed.info/sct" },
    { code: "122568004", system: "http://snomed.info/sct" },
    { code: "122566000", system: "http://snomed.info/sct" },
    { code: "122565001", system: "http://snomed.info/sct" },
    { code: "122560006", system: "http://snomed.info/sct" },
    { code: "122556008", system: "http://snomed.info/sct" },
    { code: "122555007", system: "http://snomed.info/sct" },
    { code: "122554006", system: "http://snomed.info/sct" },
    { code: "122552005", system: "http://snomed.info/sct" },
    { code: "119401005", system: "http://snomed.info/sct" },
    { code: "119395005", system: "http://snomed.info/sct" },
    { code: "119394009", system: "http://snomed.info/sct" },
    { code: "119376003", system: "http://snomed.info/sct" },
    { code: "119371008", system: "http://snomed.info/sct" },
    { code: "119370009", system: "http://snomed.info/sct" },
    { code: "119367005", system: "http://snomed.info/sct" },
    { code: "119366001", system: "http://snomed.info/sct" },
    { code: "119365002", system: "http://snomed.info/sct" },
    { code: "119364003", system: "http://snomed.info/sct" },
    { code: "119363009", system: "http://snomed.info/sct" },
    { code: "119362004", system: "http://snomed.info/sct" },
    { code: "119361006", system: "http://snomed.info/sct" },
    { code: "119360007", system: "http://snomed.info/sct" },
    { code: "119351004", system: "http://snomed.info/sct" },
    { code: "119350003", system: "http://snomed.info/sct" },
    { code: "119349003", system: "http://snomed.info/sct" },
    { code: "119345009", system: "http://snomed.info/sct" },
    { code: "119344008", system: "http://snomed.info/sct" },
    { code: "119342007", system: "http://snomed.info/sct" },
    { code: "119341000", system: "http://snomed.info/sct" },
    { code: "119339001", system: "http://snomed.info/sct" },
    { code: "119337004", system: "http://snomed.info/sct" },
    { code: "119336008", system: "http://snomed.info/sct" },
    { code: "119335007", system: "http://snomed.info/sct" },
    { code: "119334006", system: "http://snomed.info/sct" },
    { code: "119332005", system: "http://snomed.info/sct" },
    { code: "119329007", system: "http://snomed.info/sct" },
    { code: "119327009", system: "http://snomed.info/sct" },
    { code: "119325001", system: "http://snomed.info/sct" },
    { code: "119323008", system: "http://snomed.info/sct" },
    { code: "119320006", system: "http://snomed.info/sct" },
    { code: "119318008", system: "http://snomed.info/sct" },
    { code: "119312009", system: "http://snomed.info/sct" },
    { code: "119311002", system: "http://snomed.info/sct" },
    { code: "119305000", system: "http://snomed.info/sct" },
    { code: "119304001", system: "http://snomed.info/sct" },
    { code: "119300005", system: "http://snomed.info/sct" },
    { code: "119297000", system: "http://snomed.info/sct" },
    { code: "119295008", system: "http://snomed.info/sct" },
    { code: "119294007", system: "http://snomed.info/sct" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidResultsSpecimenTypeSnomedCtIpsFreeSetCode(code) {
    return ResultsSpecimenTypeSnomedCtIpsFreeSetConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getResultsSpecimenTypeSnomedCtIpsFreeSetConcept(code) {
    return ResultsSpecimenTypeSnomedCtIpsFreeSetConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ResultsSpecimenTypeSnomedCtIpsFreeSetCodes = ResultsSpecimenTypeSnomedCtIpsFreeSetConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomResultsSpecimenTypeSnomedCtIpsFreeSetCode() {
    return ResultsSpecimenTypeSnomedCtIpsFreeSetCodes[Math.floor(Math.random() * ResultsSpecimenTypeSnomedCtIpsFreeSetCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomResultsSpecimenTypeSnomedCtIpsFreeSetConcept() {
    return ResultsSpecimenTypeSnomedCtIpsFreeSetConcepts[Math.floor(Math.random() * ResultsSpecimenTypeSnomedCtIpsFreeSetConcepts.length)];
}
