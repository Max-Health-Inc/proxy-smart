/**
 * ValueSet: VaccineTargetDiseasesSnomedCtIpsFreeSet
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/target-diseases-snomed-ct-ips-free-set
 * Size: 22 concepts
 */
export const VaccineTargetDiseasesSnomedCtIpsFreeSetConcepts = [
    { code: "4834000", system: "http://snomed.info/sct" },
    { code: "6142004", system: "http://snomed.info/sct" },
    { code: "14189004", system: "http://snomed.info/sct" },
    { code: "23502006", system: "http://snomed.info/sct" },
    { code: "24662006", system: "http://snomed.info/sct" },
    { code: "25225006", system: "http://snomed.info/sct" },
    { code: "27836007", system: "http://snomed.info/sct" },
    { code: "32398004", system: "http://snomed.info/sct" },
    { code: "36989005", system: "http://snomed.info/sct" },
    { code: "38907003", system: "http://snomed.info/sct" },
    { code: "40468003", system: "http://snomed.info/sct" },
    { code: "50711007", system: "http://snomed.info/sct" },
    { code: "56717001", system: "http://snomed.info/sct" },
    { code: "66071002", system: "http://snomed.info/sct" },
    { code: "70036007", system: "http://snomed.info/sct" },
    { code: "76902006", system: "http://snomed.info/sct" },
    { code: "186150001", system: "http://snomed.info/sct" },
    { code: "240532009", system: "http://snomed.info/sct" },
    { code: "372244006", system: "http://snomed.info/sct" },
    { code: "398102009", system: "http://snomed.info/sct" },
    { code: "442438000", system: "http://snomed.info/sct" },
    { code: "840539006", system: "http://snomed.info/sct" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidVaccineTargetDiseasesSnomedCtIpsFreeSetCode(code) {
    return VaccineTargetDiseasesSnomedCtIpsFreeSetConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getVaccineTargetDiseasesSnomedCtIpsFreeSetConcept(code) {
    return VaccineTargetDiseasesSnomedCtIpsFreeSetConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const VaccineTargetDiseasesSnomedCtIpsFreeSetCodes = VaccineTargetDiseasesSnomedCtIpsFreeSetConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomVaccineTargetDiseasesSnomedCtIpsFreeSetCode() {
    return VaccineTargetDiseasesSnomedCtIpsFreeSetCodes[Math.floor(Math.random() * VaccineTargetDiseasesSnomedCtIpsFreeSetCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomVaccineTargetDiseasesSnomedCtIpsFreeSetConcept() {
    return VaccineTargetDiseasesSnomedCtIpsFreeSetConcepts[Math.floor(Math.random() * VaccineTargetDiseasesSnomedCtIpsFreeSetConcepts.length)];
}
