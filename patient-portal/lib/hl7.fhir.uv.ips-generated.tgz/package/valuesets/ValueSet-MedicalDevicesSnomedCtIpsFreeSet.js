/**
 * ValueSet: MedicalDevicesSnomedCtIpsFreeSet
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/medical-devices-snomed-ct-ips-free-set
 * Size: 72 concepts
 */
export const MedicalDevicesSnomedCtIpsFreeSetConcepts = [
    { code: "705991002", system: "http://snomed.info/sct" },
    { code: "705865004", system: "http://snomed.info/sct" },
    { code: "469997005", system: "http://snomed.info/sct" },
    { code: "429798007", system: "http://snomed.info/sct" },
    { code: "424921004", system: "http://snomed.info/sct" },
    { code: "423449009", system: "http://snomed.info/sct" },
    { code: "421168009", system: "http://snomed.info/sct" },
    { code: "414580007", system: "http://snomed.info/sct" },
    { code: "413766009", system: "http://snomed.info/sct" },
    { code: "408099007", system: "http://snomed.info/sct" },
    { code: "360329004", system: "http://snomed.info/sct" },
    { code: "360145006", system: "http://snomed.info/sct" },
    { code: "360123005", system: "http://snomed.info/sct" },
    { code: "360100007", system: "http://snomed.info/sct" },
    { code: "360070009", system: "http://snomed.info/sct" },
    { code: "360058005", system: "http://snomed.info/sct" },
    { code: "360046005", system: "http://snomed.info/sct" },
    { code: "360041000", system: "http://snomed.info/sct" },
    { code: "314523008", system: "http://snomed.info/sct" },
    { code: "304186003", system: "http://snomed.info/sct" },
    { code: "304185004", system: "http://snomed.info/sct" },
    { code: "304124003", system: "http://snomed.info/sct" },
    { code: "304121006", system: "http://snomed.info/sct" },
    { code: "304120007", system: "http://snomed.info/sct" },
    { code: "304070008", system: "http://snomed.info/sct" },
    { code: "303947005", system: "http://snomed.info/sct" },
    { code: "303726000", system: "http://snomed.info/sct" },
    { code: "303619008", system: "http://snomed.info/sct" },
    { code: "303618000", system: "http://snomed.info/sct" },
    { code: "303617005", system: "http://snomed.info/sct" },
    { code: "303608005", system: "http://snomed.info/sct" },
    { code: "303533002", system: "http://snomed.info/sct" },
    { code: "303515008", system: "http://snomed.info/sct" },
    { code: "303503009", system: "http://snomed.info/sct" },
    { code: "303500007", system: "http://snomed.info/sct" },
    { code: "303499003", system: "http://snomed.info/sct" },
    { code: "303497001", system: "http://snomed.info/sct" },
    { code: "303490004", system: "http://snomed.info/sct" },
    { code: "303277008", system: "http://snomed.info/sct" },
    { code: "286576009", system: "http://snomed.info/sct" },
    { code: "286558002", system: "http://snomed.info/sct" },
    { code: "268460000", system: "http://snomed.info/sct" },
    { code: "264824009", system: "http://snomed.info/sct" },
    { code: "258593008", system: "http://snomed.info/sct" },
    { code: "257366006", system: "http://snomed.info/sct" },
    { code: "257343005", system: "http://snomed.info/sct" },
    { code: "257283004", system: "http://snomed.info/sct" },
    { code: "257282009", system: "http://snomed.info/sct" },
    { code: "257275005", system: "http://snomed.info/sct" },
    { code: "118425005", system: "http://snomed.info/sct" },
    { code: "118374007", system: "http://snomed.info/sct" },
    { code: "102314001", system: "http://snomed.info/sct" },
    { code: "102303004", system: "http://snomed.info/sct" },
    { code: "90134004", system: "http://snomed.info/sct" },
    { code: "84683006", system: "http://snomed.info/sct" },
    { code: "77777004", system: "http://snomed.info/sct" },
    { code: "77444004", system: "http://snomed.info/sct" },
    { code: "74444006", system: "http://snomed.info/sct" },
    { code: "72506001", system: "http://snomed.info/sct" },
    { code: "68183006", system: "http://snomed.info/sct" },
    { code: "67270000", system: "http://snomed.info/sct" },
    { code: "63289001", system: "http://snomed.info/sct" },
    { code: "63112008", system: "http://snomed.info/sct" },
    { code: "53671008", system: "http://snomed.info/sct" },
    { code: "45633005", system: "http://snomed.info/sct" },
    { code: "43252007", system: "http://snomed.info/sct" },
    { code: "31031000", system: "http://snomed.info/sct" },
    { code: "25937001", system: "http://snomed.info/sct" },
    { code: "17107009", system: "http://snomed.info/sct" },
    { code: "14423008", system: "http://snomed.info/sct" },
    { code: "2282003", system: "http://snomed.info/sct" },
    { code: "271003", system: "http://snomed.info/sct" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidMedicalDevicesSnomedCtIpsFreeSetCode(code) {
    return MedicalDevicesSnomedCtIpsFreeSetConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getMedicalDevicesSnomedCtIpsFreeSetConcept(code) {
    return MedicalDevicesSnomedCtIpsFreeSetConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const MedicalDevicesSnomedCtIpsFreeSetCodes = MedicalDevicesSnomedCtIpsFreeSetConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomMedicalDevicesSnomedCtIpsFreeSetCode() {
    return MedicalDevicesSnomedCtIpsFreeSetCodes[Math.floor(Math.random() * MedicalDevicesSnomedCtIpsFreeSetCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomMedicalDevicesSnomedCtIpsFreeSetConcept() {
    return MedicalDevicesSnomedCtIpsFreeSetConcepts[Math.floor(Math.random() * MedicalDevicesSnomedCtIpsFreeSetConcepts.length)];
}
