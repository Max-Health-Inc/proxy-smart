/**
 * ValueSet: referencerange-appliesto
 * URL: http://hl7.org/fhir/ValueSet/referencerange-appliesto
 * Size: 924 concepts
 */
interface ReferencerangeAppliestoConceptDef {
    readonly code: string;
    readonly system: string;
    readonly display?: string;
}
export declare const ReferencerangeAppliestoConcepts: readonly ReferencerangeAppliestoConceptDef[];
/** String type (ValueSet too large for union type) */
export type ReferencerangeAppliestoCode = string;
/** Type representing a concept from this ValueSet */
export type ReferencerangeAppliestoConcept = ReferencerangeAppliestoConceptDef;
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidReferencerangeAppliestoCode(code: string): code is ReferencerangeAppliestoCode;
/**
 * Get concept details by code
 */
export declare function getReferencerangeAppliestoConcept(code: string): ReferencerangeAppliestoConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ReferencerangeAppliestoCodes: string[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomReferencerangeAppliestoCode(): ReferencerangeAppliestoCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomReferencerangeAppliestoConcept(): ReferencerangeAppliestoConcept;
export {};
