/**
 * ValueSet: ResultsBloodGroupSnomedCtIpsFreeSet
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/results-blood-group-snomed-ct-ips-free-set
 * Size: 13 concepts
 */
export const ResultsBloodGroupSnomedCtIpsFreeSetConcepts = [
    { code: "278154007", system: "http://snomed.info/sct" },
    { code: "278153001", system: "http://snomed.info/sct" },
    { code: "278152006", system: "http://snomed.info/sct" },
    { code: "278151004", system: "http://snomed.info/sct" },
    { code: "278150003", system: "http://snomed.info/sct" },
    { code: "278149003", system: "http://snomed.info/sct" },
    { code: "278148006", system: "http://snomed.info/sct" },
    { code: "278147001", system: "http://snomed.info/sct" },
    { code: "165746003", system: "http://snomed.info/sct" },
    { code: "165743006", system: "http://snomed.info/sct" },
    { code: "112149005", system: "http://snomed.info/sct" },
    { code: "112144000", system: "http://snomed.info/sct" },
    { code: "58460004", system: "http://snomed.info/sct" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidResultsBloodGroupSnomedCtIpsFreeSetCode(code) {
    return ResultsBloodGroupSnomedCtIpsFreeSetConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getResultsBloodGroupSnomedCtIpsFreeSetConcept(code) {
    return ResultsBloodGroupSnomedCtIpsFreeSetConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ResultsBloodGroupSnomedCtIpsFreeSetCodes = ResultsBloodGroupSnomedCtIpsFreeSetConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomResultsBloodGroupSnomedCtIpsFreeSetCode() {
    return ResultsBloodGroupSnomedCtIpsFreeSetCodes[Math.floor(Math.random() * ResultsBloodGroupSnomedCtIpsFreeSetCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomResultsBloodGroupSnomedCtIpsFreeSetConcept() {
    return ResultsBloodGroupSnomedCtIpsFreeSetConcepts[Math.floor(Math.random() * ResultsBloodGroupSnomedCtIpsFreeSetConcepts.length)];
}
