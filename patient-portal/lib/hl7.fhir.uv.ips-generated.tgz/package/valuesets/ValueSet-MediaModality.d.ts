/**
 * ValueSet: media-modality
 * URL: http://hl7.org/fhir/ValueSet/media-modality
 * Size: 8 concepts
 */
export declare const MediaModalityConcepts: readonly [{
    readonly code: "diagram";
    readonly system: "http://terminology.hl7.org/CodeSystem/media-modality";
}, {
    readonly code: "fax";
    readonly system: "http://terminology.hl7.org/CodeSystem/media-modality";
}, {
    readonly code: "scan";
    readonly system: "http://terminology.hl7.org/CodeSystem/media-modality";
}, {
    readonly code: "retina";
    readonly system: "http://terminology.hl7.org/CodeSystem/media-modality";
}, {
    readonly code: "fingerprint";
    readonly system: "http://terminology.hl7.org/CodeSystem/media-modality";
}, {
    readonly code: "iris";
    readonly system: "http://terminology.hl7.org/CodeSystem/media-modality";
}, {
    readonly code: "palm";
    readonly system: "http://terminology.hl7.org/CodeSystem/media-modality";
}, {
    readonly code: "face";
    readonly system: "http://terminology.hl7.org/CodeSystem/media-modality";
}];
/** Union type of all valid codes in this ValueSet */
export type MediaModalityCode = "diagram" | "fax" | "scan" | "retina" | "fingerprint" | "iris" | "palm" | "face";
/** Type representing a concept from this ValueSet */
export type MediaModalityConcept = typeof MediaModalityConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidMediaModalityCode(code: string): code is MediaModalityCode;
/**
 * Get concept details by code
 */
export declare function getMediaModalityConcept(code: string): MediaModalityConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const MediaModalityCodes: ("fax" | "diagram" | "scan" | "retina" | "fingerprint" | "iris" | "palm" | "face")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomMediaModalityCode(): MediaModalityCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomMediaModalityConcept(): MediaModalityConcept;
