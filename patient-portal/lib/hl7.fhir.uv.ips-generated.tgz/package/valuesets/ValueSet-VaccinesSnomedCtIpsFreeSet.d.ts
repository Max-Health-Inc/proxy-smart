/**
 * ValueSet: VaccinesSnomedCtIpsFreeSet
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/vaccines-snomed-ct-ips-free-set
 * Size: 78 concepts
 */
export declare const VaccinesSnomedCtIpsFreeSetConcepts: readonly [{
    readonly code: "2221000221107";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "2171000221104";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "1981000221108";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "1801000221105";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "1181000221105";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "1131000221109";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "1121000221106";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "1101000221104";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "1081000221109";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "1051000221104";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "1031000221108";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "1011000221100";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "1001000221103";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "971000221109";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "601000221108";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "1119254000";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "1052328007";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "871921009";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "871918007";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "871908002";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "871895005";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "871889009";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "871887006";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "871878002";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "871876003";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "871875004";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "871873006";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "871871008";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "871866001";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "871839001";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "871837004";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "871831003";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "871826000";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "871806004";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "871804001";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "871803007";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "871772009";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "871768005";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "871765008";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "871759008";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "871740006";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "871738001";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "871737006";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "863911006";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "840599008";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "840549009";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "836500008";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "836498007";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "836495005";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "836403007";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "836402002";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "836401009";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "836398006";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "836397001";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "836393002";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "836390004";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "836389008";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "836388000";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "836387005";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "836385002";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "836384003";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "836383009";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "836382004";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "836381006";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "836380007";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "836379009";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "836378001";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "836377006";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "836375003";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "836374004";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "836369007";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "836368004";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "777725002";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "775641005";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "774618008";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "428601009";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "409568008";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "37146000";
    readonly system: "http://snomed.info/sct";
}];
/** String type (ValueSet too large for union type) */
export type VaccinesSnomedCtIpsFreeSetCode = string;
/** Type representing a concept from this ValueSet */
export type VaccinesSnomedCtIpsFreeSetConcept = typeof VaccinesSnomedCtIpsFreeSetConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidVaccinesSnomedCtIpsFreeSetCode(code: string): code is VaccinesSnomedCtIpsFreeSetCode;
/**
 * Get concept details by code
 */
export declare function getVaccinesSnomedCtIpsFreeSetConcept(code: string): VaccinesSnomedCtIpsFreeSetConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const VaccinesSnomedCtIpsFreeSetCodes: ("37146000" | "409568008" | "428601009" | "774618008" | "775641005" | "777725002" | "836368004" | "836369007" | "836374004" | "836375003" | "836377006" | "836378001" | "836379009" | "836380007" | "836381006" | "836382004" | "836383009" | "836384003" | "836385002" | "836387005" | "836388000" | "836389008" | "836390004" | "836393002" | "836397001" | "836398006" | "836401009" | "836402002" | "836403007" | "836495005" | "836498007" | "836500008" | "840549009" | "840599008" | "863911006" | "871737006" | "871738001" | "871740006" | "871759008" | "871765008" | "871768005" | "871772009" | "871803007" | "871804001" | "871806004" | "871826000" | "871831003" | "871837004" | "871839001" | "871866001" | "871871008" | "871873006" | "871875004" | "871876003" | "871878002" | "871887006" | "871889009" | "871895005" | "871908002" | "871918007" | "871921009" | "1052328007" | "1119254000" | "601000221108" | "971000221109" | "1001000221103" | "1011000221100" | "1031000221108" | "1051000221104" | "1081000221109" | "1101000221104" | "1121000221106" | "1131000221109" | "1181000221105" | "1801000221105" | "1981000221108" | "2171000221104" | "2221000221107")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomVaccinesSnomedCtIpsFreeSetCode(): VaccinesSnomedCtIpsFreeSetCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomVaccinesSnomedCtIpsFreeSetConcept(): VaccinesSnomedCtIpsFreeSetConcept;
