/**
 * ValueSet: v3-ActCode
 * URL: http://terminology.hl7.org/ValueSet/v3-ActCode
 * Size: 1116 concepts
 */
interface V3ActCodeConceptDef {
    readonly code: string;
    readonly system: string;
    readonly display?: string;
}
export declare const V3ActCodeConcepts: readonly V3ActCodeConceptDef[];
/** String type (ValueSet too large for union type) */
export type V3ActCodeCode = string;
/** Type representing a concept from this ValueSet */
export type V3ActCodeConcept = V3ActCodeConceptDef;
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidV3ActCodeCode(code: string): code is V3ActCodeCode;
/**
 * Get concept details by code
 */
export declare function getV3ActCodeConcept(code: string): V3ActCodeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const V3ActCodeCodes: string[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomV3ActCodeCode(): V3ActCodeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomV3ActCodeConcept(): V3ActCodeConcept;
export {};
