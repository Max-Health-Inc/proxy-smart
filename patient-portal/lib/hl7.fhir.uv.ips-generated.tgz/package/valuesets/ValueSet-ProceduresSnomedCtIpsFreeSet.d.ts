/**
 * ValueSet: ProceduresSnomedCtIpsFreeSet
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/procedures-snomed-ct-ips-free-set
 * Size: 690 concepts
 */
interface ProceduresSnomedCtIpsFreeSetConceptDef {
    readonly code: string;
    readonly system: string;
    readonly display?: string;
}
export declare const ProceduresSnomedCtIpsFreeSetConcepts: readonly ProceduresSnomedCtIpsFreeSetConceptDef[];
/** String type (ValueSet too large for union type) */
export type ProceduresSnomedCtIpsFreeSetCode = string;
/** Type representing a concept from this ValueSet */
export type ProceduresSnomedCtIpsFreeSetConcept = ProceduresSnomedCtIpsFreeSetConceptDef;
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidProceduresSnomedCtIpsFreeSetCode(code: string): code is ProceduresSnomedCtIpsFreeSetCode;
/**
 * Get concept details by code
 */
export declare function getProceduresSnomedCtIpsFreeSetConcept(code: string): ProceduresSnomedCtIpsFreeSetConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ProceduresSnomedCtIpsFreeSetCodes: string[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomProceduresSnomedCtIpsFreeSetCode(): ProceduresSnomedCtIpsFreeSetCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomProceduresSnomedCtIpsFreeSetConcept(): ProceduresSnomedCtIpsFreeSetConcept;
export {};
