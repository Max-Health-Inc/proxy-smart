/**
 * ValueSet: MedicalDevicesSnomedCtIpsFreeSet
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/medical-devices-snomed-ct-ips-free-set
 * Size: 72 concepts
 */
export declare const MedicalDevicesSnomedCtIpsFreeSetConcepts: readonly [{
    readonly code: "705991002";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "705865004";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "469997005";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "429798007";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "424921004";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "423449009";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "421168009";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "414580007";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "413766009";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "408099007";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "360329004";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "360145006";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "360123005";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "360100007";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "360070009";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "360058005";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "360046005";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "360041000";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "314523008";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "304186003";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "304185004";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "304124003";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "304121006";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "304120007";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "304070008";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "303947005";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "303726000";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "303619008";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "303618000";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "303617005";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "303608005";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "303533002";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "303515008";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "303503009";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "303500007";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "303499003";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "303497001";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "303490004";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "303277008";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "286576009";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "286558002";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "268460000";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "264824009";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "258593008";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "257366006";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "257343005";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "257283004";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "257282009";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "257275005";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "118425005";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "118374007";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "102314001";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "102303004";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "90134004";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "84683006";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "77777004";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "77444004";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "74444006";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "72506001";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "68183006";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "67270000";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "63289001";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "63112008";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "53671008";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "45633005";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "43252007";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "31031000";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "25937001";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "17107009";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "14423008";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "2282003";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "271003";
    readonly system: "http://snomed.info/sct";
}];
/** String type (ValueSet too large for union type) */
export type MedicalDevicesSnomedCtIpsFreeSetCode = string;
/** Type representing a concept from this ValueSet */
export type MedicalDevicesSnomedCtIpsFreeSetConcept = typeof MedicalDevicesSnomedCtIpsFreeSetConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidMedicalDevicesSnomedCtIpsFreeSetCode(code: string): code is MedicalDevicesSnomedCtIpsFreeSetCode;
/**
 * Get concept details by code
 */
export declare function getMedicalDevicesSnomedCtIpsFreeSetConcept(code: string): MedicalDevicesSnomedCtIpsFreeSetConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const MedicalDevicesSnomedCtIpsFreeSetCodes: ("705991002" | "705865004" | "469997005" | "429798007" | "424921004" | "423449009" | "421168009" | "414580007" | "413766009" | "408099007" | "360329004" | "360145006" | "360123005" | "360100007" | "360070009" | "360058005" | "360046005" | "360041000" | "314523008" | "304186003" | "304185004" | "304124003" | "304121006" | "304120007" | "304070008" | "303947005" | "303726000" | "303619008" | "303618000" | "303617005" | "303608005" | "303533002" | "303515008" | "303503009" | "303500007" | "303499003" | "303497001" | "303490004" | "303277008" | "286576009" | "286558002" | "268460000" | "264824009" | "258593008" | "257366006" | "257343005" | "257283004" | "257282009" | "257275005" | "118425005" | "118374007" | "102314001" | "102303004" | "90134004" | "84683006" | "77777004" | "77444004" | "74444006" | "72506001" | "68183006" | "67270000" | "63289001" | "63112008" | "53671008" | "45633005" | "43252007" | "31031000" | "25937001" | "17107009" | "14423008" | "2282003" | "271003")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomMedicalDevicesSnomedCtIpsFreeSetCode(): MedicalDevicesSnomedCtIpsFreeSetCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomMedicalDevicesSnomedCtIpsFreeSetConcept(): MedicalDevicesSnomedCtIpsFreeSetConcept;
