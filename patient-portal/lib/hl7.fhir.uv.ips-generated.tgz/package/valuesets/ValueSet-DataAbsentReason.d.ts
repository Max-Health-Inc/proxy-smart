/**
 * ValueSet: data-absent-reason
 * URL: http://hl7.org/fhir/ValueSet/data-absent-reason
 * Size: 15 concepts
 */
export declare const DataAbsentReasonConcepts: readonly [{
    readonly code: "unknown";
    readonly system: "http://terminology.hl7.org/CodeSystem/data-absent-reason";
}, {
    readonly code: "asked-unknown";
    readonly system: "http://terminology.hl7.org/CodeSystem/data-absent-reason";
}, {
    readonly code: "temp-unknown";
    readonly system: "http://terminology.hl7.org/CodeSystem/data-absent-reason";
}, {
    readonly code: "not-asked";
    readonly system: "http://terminology.hl7.org/CodeSystem/data-absent-reason";
}, {
    readonly code: "asked-declined";
    readonly system: "http://terminology.hl7.org/CodeSystem/data-absent-reason";
}, {
    readonly code: "masked";
    readonly system: "http://terminology.hl7.org/CodeSystem/data-absent-reason";
}, {
    readonly code: "not-applicable";
    readonly system: "http://terminology.hl7.org/CodeSystem/data-absent-reason";
}, {
    readonly code: "unsupported";
    readonly system: "http://terminology.hl7.org/CodeSystem/data-absent-reason";
}, {
    readonly code: "as-text";
    readonly system: "http://terminology.hl7.org/CodeSystem/data-absent-reason";
}, {
    readonly code: "error";
    readonly system: "http://terminology.hl7.org/CodeSystem/data-absent-reason";
}, {
    readonly code: "not-a-number";
    readonly system: "http://terminology.hl7.org/CodeSystem/data-absent-reason";
}, {
    readonly code: "negative-infinity";
    readonly system: "http://terminology.hl7.org/CodeSystem/data-absent-reason";
}, {
    readonly code: "positive-infinity";
    readonly system: "http://terminology.hl7.org/CodeSystem/data-absent-reason";
}, {
    readonly code: "not-performed";
    readonly system: "http://terminology.hl7.org/CodeSystem/data-absent-reason";
}, {
    readonly code: "not-permitted";
    readonly system: "http://terminology.hl7.org/CodeSystem/data-absent-reason";
}];
/** Union type of all valid codes in this ValueSet */
export type DataAbsentReasonCode = "unknown" | "asked-unknown" | "temp-unknown" | "not-asked" | "asked-declined" | "masked" | "not-applicable" | "unsupported" | "as-text" | "error" | "not-a-number" | "negative-infinity" | "positive-infinity" | "not-performed" | "not-permitted";
/** Type representing a concept from this ValueSet */
export type DataAbsentReasonConcept = typeof DataAbsentReasonConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidDataAbsentReasonCode(code: string): code is DataAbsentReasonCode;
/**
 * Get concept details by code
 */
export declare function getDataAbsentReasonConcept(code: string): DataAbsentReasonConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const DataAbsentReasonCodes: ("unknown" | "asked-unknown" | "temp-unknown" | "not-asked" | "asked-declined" | "masked" | "not-applicable" | "unsupported" | "as-text" | "error" | "not-a-number" | "negative-infinity" | "positive-infinity" | "not-performed" | "not-permitted")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomDataAbsentReasonCode(): DataAbsentReasonCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomDataAbsentReasonConcept(): DataAbsentReasonConcept;
