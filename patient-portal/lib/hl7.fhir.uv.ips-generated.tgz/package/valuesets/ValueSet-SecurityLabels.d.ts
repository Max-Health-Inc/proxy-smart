/**
 * ValueSet: security-labels
 * URL: http://hl7.org/fhir/ValueSet/security-labels
 * Size: 263 concepts
 */
interface SecurityLabelsConceptDef {
    readonly code: string;
    readonly system: string;
    readonly display?: string;
}
export declare const SecurityLabelsConcepts: readonly SecurityLabelsConceptDef[];
/** String type (ValueSet too large for union type) */
export type SecurityLabelsCode = string;
/** Type representing a concept from this ValueSet */
export type SecurityLabelsConcept = SecurityLabelsConceptDef;
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidSecurityLabelsCode(code: string): code is SecurityLabelsCode;
/**
 * Get concept details by code
 */
export declare function getSecurityLabelsConcept(code: string): SecurityLabelsConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const SecurityLabelsCodes: string[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomSecurityLabelsCode(): SecurityLabelsCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomSecurityLabelsConcept(): SecurityLabelsConcept;
export {};
