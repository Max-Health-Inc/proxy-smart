/**
 * ValueSet: VaccinesSnomedCtIpsFreeSet
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/vaccines-snomed-ct-ips-free-set
 * Size: 78 concepts
 */
export const VaccinesSnomedCtIpsFreeSetConcepts = [
    { code: "2221000221107", system: "http://snomed.info/sct" },
    { code: "2171000221104", system: "http://snomed.info/sct" },
    { code: "1981000221108", system: "http://snomed.info/sct" },
    { code: "1801000221105", system: "http://snomed.info/sct" },
    { code: "1181000221105", system: "http://snomed.info/sct" },
    { code: "1131000221109", system: "http://snomed.info/sct" },
    { code: "1121000221106", system: "http://snomed.info/sct" },
    { code: "1101000221104", system: "http://snomed.info/sct" },
    { code: "1081000221109", system: "http://snomed.info/sct" },
    { code: "1051000221104", system: "http://snomed.info/sct" },
    { code: "1031000221108", system: "http://snomed.info/sct" },
    { code: "1011000221100", system: "http://snomed.info/sct" },
    { code: "1001000221103", system: "http://snomed.info/sct" },
    { code: "971000221109", system: "http://snomed.info/sct" },
    { code: "601000221108", system: "http://snomed.info/sct" },
    { code: "1119254000", system: "http://snomed.info/sct" },
    { code: "1052328007", system: "http://snomed.info/sct" },
    { code: "871921009", system: "http://snomed.info/sct" },
    { code: "871918007", system: "http://snomed.info/sct" },
    { code: "871908002", system: "http://snomed.info/sct" },
    { code: "871895005", system: "http://snomed.info/sct" },
    { code: "871889009", system: "http://snomed.info/sct" },
    { code: "871887006", system: "http://snomed.info/sct" },
    { code: "871878002", system: "http://snomed.info/sct" },
    { code: "871876003", system: "http://snomed.info/sct" },
    { code: "871875004", system: "http://snomed.info/sct" },
    { code: "871873006", system: "http://snomed.info/sct" },
    { code: "871871008", system: "http://snomed.info/sct" },
    { code: "871866001", system: "http://snomed.info/sct" },
    { code: "871839001", system: "http://snomed.info/sct" },
    { code: "871837004", system: "http://snomed.info/sct" },
    { code: "871831003", system: "http://snomed.info/sct" },
    { code: "871826000", system: "http://snomed.info/sct" },
    { code: "871806004", system: "http://snomed.info/sct" },
    { code: "871804001", system: "http://snomed.info/sct" },
    { code: "871803007", system: "http://snomed.info/sct" },
    { code: "871772009", system: "http://snomed.info/sct" },
    { code: "871768005", system: "http://snomed.info/sct" },
    { code: "871765008", system: "http://snomed.info/sct" },
    { code: "871759008", system: "http://snomed.info/sct" },
    { code: "871740006", system: "http://snomed.info/sct" },
    { code: "871738001", system: "http://snomed.info/sct" },
    { code: "871737006", system: "http://snomed.info/sct" },
    { code: "863911006", system: "http://snomed.info/sct" },
    { code: "840599008", system: "http://snomed.info/sct" },
    { code: "840549009", system: "http://snomed.info/sct" },
    { code: "836500008", system: "http://snomed.info/sct" },
    { code: "836498007", system: "http://snomed.info/sct" },
    { code: "836495005", system: "http://snomed.info/sct" },
    { code: "836403007", system: "http://snomed.info/sct" },
    { code: "836402002", system: "http://snomed.info/sct" },
    { code: "836401009", system: "http://snomed.info/sct" },
    { code: "836398006", system: "http://snomed.info/sct" },
    { code: "836397001", system: "http://snomed.info/sct" },
    { code: "836393002", system: "http://snomed.info/sct" },
    { code: "836390004", system: "http://snomed.info/sct" },
    { code: "836389008", system: "http://snomed.info/sct" },
    { code: "836388000", system: "http://snomed.info/sct" },
    { code: "836387005", system: "http://snomed.info/sct" },
    { code: "836385002", system: "http://snomed.info/sct" },
    { code: "836384003", system: "http://snomed.info/sct" },
    { code: "836383009", system: "http://snomed.info/sct" },
    { code: "836382004", system: "http://snomed.info/sct" },
    { code: "836381006", system: "http://snomed.info/sct" },
    { code: "836380007", system: "http://snomed.info/sct" },
    { code: "836379009", system: "http://snomed.info/sct" },
    { code: "836378001", system: "http://snomed.info/sct" },
    { code: "836377006", system: "http://snomed.info/sct" },
    { code: "836375003", system: "http://snomed.info/sct" },
    { code: "836374004", system: "http://snomed.info/sct" },
    { code: "836369007", system: "http://snomed.info/sct" },
    { code: "836368004", system: "http://snomed.info/sct" },
    { code: "777725002", system: "http://snomed.info/sct" },
    { code: "775641005", system: "http://snomed.info/sct" },
    { code: "774618008", system: "http://snomed.info/sct" },
    { code: "428601009", system: "http://snomed.info/sct" },
    { code: "409568008", system: "http://snomed.info/sct" },
    { code: "37146000", system: "http://snomed.info/sct" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidVaccinesSnomedCtIpsFreeSetCode(code) {
    return VaccinesSnomedCtIpsFreeSetConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getVaccinesSnomedCtIpsFreeSetConcept(code) {
    return VaccinesSnomedCtIpsFreeSetConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const VaccinesSnomedCtIpsFreeSetCodes = VaccinesSnomedCtIpsFreeSetConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomVaccinesSnomedCtIpsFreeSetCode() {
    return VaccinesSnomedCtIpsFreeSetCodes[Math.floor(Math.random() * VaccinesSnomedCtIpsFreeSetCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomVaccinesSnomedCtIpsFreeSetConcept() {
    return VaccinesSnomedCtIpsFreeSetConcepts[Math.floor(Math.random() * VaccinesSnomedCtIpsFreeSetConcepts.length)];
}
