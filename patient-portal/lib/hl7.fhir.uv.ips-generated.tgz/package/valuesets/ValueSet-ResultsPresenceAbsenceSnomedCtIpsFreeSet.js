/**
 * ValueSet: ResultsPresenceAbsenceSnomedCtIpsFreeSet
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/results-presence-absence-snomed-ct-ips-free-set
 * Size: 9 concepts
 */
export const ResultsPresenceAbsenceSnomedCtIpsFreeSetConcepts = [
    { code: "441614007", system: "http://snomed.info/sct" },
    { code: "441521003", system: "http://snomed.info/sct" },
    { code: "441517005", system: "http://snomed.info/sct" },
    { code: "260350009", system: "http://snomed.info/sct" },
    { code: "260349009", system: "http://snomed.info/sct" },
    { code: "260348001", system: "http://snomed.info/sct" },
    { code: "260347006", system: "http://snomed.info/sct" },
    { code: "52101004", system: "http://snomed.info/sct" },
    { code: "2667000", system: "http://snomed.info/sct" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidResultsPresenceAbsenceSnomedCtIpsFreeSetCode(code) {
    return ResultsPresenceAbsenceSnomedCtIpsFreeSetConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getResultsPresenceAbsenceSnomedCtIpsFreeSetConcept(code) {
    return ResultsPresenceAbsenceSnomedCtIpsFreeSetConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ResultsPresenceAbsenceSnomedCtIpsFreeSetCodes = ResultsPresenceAbsenceSnomedCtIpsFreeSetConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomResultsPresenceAbsenceSnomedCtIpsFreeSetCode() {
    return ResultsPresenceAbsenceSnomedCtIpsFreeSetCodes[Math.floor(Math.random() * ResultsPresenceAbsenceSnomedCtIpsFreeSetCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomResultsPresenceAbsenceSnomedCtIpsFreeSetConcept() {
    return ResultsPresenceAbsenceSnomedCtIpsFreeSetConcepts[Math.floor(Math.random() * ResultsPresenceAbsenceSnomedCtIpsFreeSetConcepts.length)];
}
