/**
 * ValueSet: media-modality
 * URL: http://hl7.org/fhir/ValueSet/media-modality
 * Size: 8 concepts
 */
export const MediaModalityConcepts = [
    { code: "diagram", system: "http://terminology.hl7.org/CodeSystem/media-modality" },
    { code: "fax", system: "http://terminology.hl7.org/CodeSystem/media-modality" },
    { code: "scan", system: "http://terminology.hl7.org/CodeSystem/media-modality" },
    { code: "retina", system: "http://terminology.hl7.org/CodeSystem/media-modality" },
    { code: "fingerprint", system: "http://terminology.hl7.org/CodeSystem/media-modality" },
    { code: "iris", system: "http://terminology.hl7.org/CodeSystem/media-modality" },
    { code: "palm", system: "http://terminology.hl7.org/CodeSystem/media-modality" },
    { code: "face", system: "http://terminology.hl7.org/CodeSystem/media-modality" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidMediaModalityCode(code) {
    return MediaModalityConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getMediaModalityConcept(code) {
    return MediaModalityConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const MediaModalityCodes = MediaModalityConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomMediaModalityCode() {
    return MediaModalityCodes[Math.floor(Math.random() * MediaModalityCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomMediaModalityConcept() {
    return MediaModalityConcepts[Math.floor(Math.random() * MediaModalityConcepts.length)];
}
