/**
 * ValueSet: specimen-collection-method
 * URL: http://hl7.org/fhir/ValueSet/specimen-collection-method
 * Size: 10 concepts
 */
export const SpecimenCollectionMethodConcepts = [
    { code: "129316008", system: "http://snomed.info/sct" },
    { code: "129314006", system: "http://snomed.info/sct" },
    { code: "129300006", system: "http://snomed.info/sct" },
    { code: "129304002", system: "http://snomed.info/sct" },
    { code: "129323009", system: "http://snomed.info/sct" },
    { code: "73416001", system: "http://snomed.info/sct" },
    { code: "225113003", system: "http://snomed.info/sct" },
    { code: "70777001", system: "http://snomed.info/sct" },
    { code: "386089008", system: "http://snomed.info/sct" },
    { code: "278450005", system: "http://snomed.info/sct" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidSpecimenCollectionMethodCode(code) {
    return SpecimenCollectionMethodConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getSpecimenCollectionMethodConcept(code) {
    return SpecimenCollectionMethodConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const SpecimenCollectionMethodCodes = SpecimenCollectionMethodConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomSpecimenCollectionMethodCode() {
    return SpecimenCollectionMethodCodes[Math.floor(Math.random() * SpecimenCollectionMethodCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomSpecimenCollectionMethodConcept() {
    return SpecimenCollectionMethodConcepts[Math.floor(Math.random() * SpecimenCollectionMethodConcepts.length)];
}
