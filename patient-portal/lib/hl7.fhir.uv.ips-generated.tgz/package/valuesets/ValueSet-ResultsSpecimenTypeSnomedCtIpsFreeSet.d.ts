/**
 * ValueSet: ResultsSpecimenTypeSnomedCtIpsFreeSet
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/results-specimen-type-snomed-ct-ips-free-set
 * Size: 127 concepts
 */
interface ResultsSpecimenTypeSnomedCtIpsFreeSetConceptDef {
    readonly code: string;
    readonly system: string;
    readonly display?: string;
}
export declare const ResultsSpecimenTypeSnomedCtIpsFreeSetConcepts: readonly ResultsSpecimenTypeSnomedCtIpsFreeSetConceptDef[];
/** String type (ValueSet too large for union type) */
export type ResultsSpecimenTypeSnomedCtIpsFreeSetCode = string;
/** Type representing a concept from this ValueSet */
export type ResultsSpecimenTypeSnomedCtIpsFreeSetConcept = ResultsSpecimenTypeSnomedCtIpsFreeSetConceptDef;
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidResultsSpecimenTypeSnomedCtIpsFreeSetCode(code: string): code is ResultsSpecimenTypeSnomedCtIpsFreeSetCode;
/**
 * Get concept details by code
 */
export declare function getResultsSpecimenTypeSnomedCtIpsFreeSetConcept(code: string): ResultsSpecimenTypeSnomedCtIpsFreeSetConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ResultsSpecimenTypeSnomedCtIpsFreeSetCodes: string[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomResultsSpecimenTypeSnomedCtIpsFreeSetCode(): ResultsSpecimenTypeSnomedCtIpsFreeSetCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomResultsSpecimenTypeSnomedCtIpsFreeSetConcept(): ResultsSpecimenTypeSnomedCtIpsFreeSetConcept;
export {};
