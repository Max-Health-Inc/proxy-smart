/**
 * ValueSet: imagingstudy-status
 * URL: http://hl7.org/fhir/ValueSet/imagingstudy-status
 * Size: 5 concepts
 */
export const ImagingstudyStatusConcepts = [
    { code: "registered", system: "http://hl7.org/fhir/imagingstudy-status" },
    { code: "available", system: "http://hl7.org/fhir/imagingstudy-status" },
    { code: "cancelled", system: "http://hl7.org/fhir/imagingstudy-status" },
    { code: "entered-in-error", system: "http://hl7.org/fhir/imagingstudy-status" },
    { code: "unknown", system: "http://hl7.org/fhir/imagingstudy-status" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidImagingstudyStatusCode(code) {
    return ImagingstudyStatusConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getImagingstudyStatusConcept(code) {
    return ImagingstudyStatusConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ImagingstudyStatusCodes = ImagingstudyStatusConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomImagingstudyStatusCode() {
    return ImagingstudyStatusCodes[Math.floor(Math.random() * ImagingstudyStatusCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomImagingstudyStatusConcept() {
    return ImagingstudyStatusConcepts[Math.floor(Math.random() * ImagingstudyStatusConcepts.length)];
}
