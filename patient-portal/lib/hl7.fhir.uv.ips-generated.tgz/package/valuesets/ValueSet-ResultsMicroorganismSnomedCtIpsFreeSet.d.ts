/**
 * ValueSet: ResultsMicroorganismSnomedCtIpsFreeSet
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/results-microorganism-snomed-ct-ips-free-set
 * Size: 1343 concepts
 */
interface ResultsMicroorganismSnomedCtIpsFreeSetConceptDef {
    readonly code: string;
    readonly system: string;
    readonly display?: string;
}
export declare const ResultsMicroorganismSnomedCtIpsFreeSetConcepts: readonly ResultsMicroorganismSnomedCtIpsFreeSetConceptDef[];
/** String type (ValueSet too large for union type) */
export type ResultsMicroorganismSnomedCtIpsFreeSetCode = string;
/** Type representing a concept from this ValueSet */
export type ResultsMicroorganismSnomedCtIpsFreeSetConcept = ResultsMicroorganismSnomedCtIpsFreeSetConceptDef;
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidResultsMicroorganismSnomedCtIpsFreeSetCode(code: string): code is ResultsMicroorganismSnomedCtIpsFreeSetCode;
/**
 * Get concept details by code
 */
export declare function getResultsMicroorganismSnomedCtIpsFreeSetConcept(code: string): ResultsMicroorganismSnomedCtIpsFreeSetConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ResultsMicroorganismSnomedCtIpsFreeSetCodes: string[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomResultsMicroorganismSnomedCtIpsFreeSetCode(): ResultsMicroorganismSnomedCtIpsFreeSetCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomResultsMicroorganismSnomedCtIpsFreeSetConcept(): ResultsMicroorganismSnomedCtIpsFreeSetConcept;
export {};
