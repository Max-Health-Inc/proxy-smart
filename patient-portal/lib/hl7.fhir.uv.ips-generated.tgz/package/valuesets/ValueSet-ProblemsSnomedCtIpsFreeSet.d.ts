/**
 * ValueSet: ProblemsSnomedCtIpsFreeSet
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/problems-snomed-ct-ips-free-set
 * Size: 5622 concepts
 */
interface ProblemsSnomedCtIpsFreeSetConceptDef {
    readonly code: string;
    readonly system: string;
    readonly display?: string;
}
export declare const ProblemsSnomedCtIpsFreeSetConcepts: readonly ProblemsSnomedCtIpsFreeSetConceptDef[];
/** String type (ValueSet too large for union type) */
export type ProblemsSnomedCtIpsFreeSetCode = string;
/** Type representing a concept from this ValueSet */
export type ProblemsSnomedCtIpsFreeSetConcept = ProblemsSnomedCtIpsFreeSetConceptDef;
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidProblemsSnomedCtIpsFreeSetCode(code: string): code is ProblemsSnomedCtIpsFreeSetCode;
/**
 * Get concept details by code
 */
export declare function getProblemsSnomedCtIpsFreeSetConcept(code: string): ProblemsSnomedCtIpsFreeSetConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ProblemsSnomedCtIpsFreeSetCodes: string[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomProblemsSnomedCtIpsFreeSetCode(): ProblemsSnomedCtIpsFreeSetCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomProblemsSnomedCtIpsFreeSetConcept(): ProblemsSnomedCtIpsFreeSetConcept;
export {};
