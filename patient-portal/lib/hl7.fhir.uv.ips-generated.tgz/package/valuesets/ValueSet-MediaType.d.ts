/**
 * ValueSet: media-type
 * URL: http://hl7.org/fhir/ValueSet/media-type
 * Size: 3 concepts
 */
export declare const MediaTypeConcepts: readonly [{
    readonly code: "image";
    readonly system: "http://terminology.hl7.org/CodeSystem/media-type";
}, {
    readonly code: "video";
    readonly system: "http://terminology.hl7.org/CodeSystem/media-type";
}, {
    readonly code: "audio";
    readonly system: "http://terminology.hl7.org/CodeSystem/media-type";
}];
/** Union type of all valid codes in this ValueSet */
export type MediaTypeCode = "image" | "video" | "audio";
/** Type representing a concept from this ValueSet */
export type MediaTypeConcept = typeof MediaTypeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidMediaTypeCode(code: string): code is MediaTypeCode;
/**
 * Get concept details by code
 */
export declare function getMediaTypeConcept(code: string): MediaTypeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const MediaTypeCodes: ("image" | "video" | "audio")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomMediaTypeCode(): MediaTypeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomMediaTypeConcept(): MediaTypeConcept;
