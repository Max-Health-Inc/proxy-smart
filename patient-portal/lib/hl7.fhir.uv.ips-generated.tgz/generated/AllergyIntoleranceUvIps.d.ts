import { AllergyintoleranceAbatementExtension } from "./AllergyintoleranceAbatementExtension";
import { CodeableConceptIPS } from "./CodeableConceptIPS";
import { AllergyIntolerance, AllergyIntoleranceReaction, Extension, Reference } from "fhir/r4";
export interface AllergyIntoleranceUvIpsReaction extends AllergyIntoleranceReaction {
    /** Must Support */
    manifestation: CodeableConceptIPS[];
}
export interface AllergyIntoleranceUvIps extends AllergyIntolerance {
    /** Must Support */
    clinicalStatus?: CodeableConceptIPS;
    /** Must Support */
    code: CodeableConceptIPS;
    /** Must Support */
    patient: Reference;
    /** Must Support */
    reaction?: AllergyIntoleranceUvIpsReaction[];
    extension?: (Extension | AllergyintoleranceAbatementExtension)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateAllergyIntoleranceUvIps(resource: AllergyIntoleranceUvIps, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
