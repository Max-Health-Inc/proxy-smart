import { CodeableConceptIPS } from "./CodeableConceptIPS";
import { Device } from "fhir/r4";
export interface DeviceUvIps extends Device {
    /** Must Support */
    type?: CodeableConceptIPS;
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateDeviceUvIps(resource: DeviceUvIps, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
