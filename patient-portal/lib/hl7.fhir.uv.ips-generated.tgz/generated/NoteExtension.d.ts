import type { Extension } from "fhir/r4";
export type NoteExtension = Extension;
