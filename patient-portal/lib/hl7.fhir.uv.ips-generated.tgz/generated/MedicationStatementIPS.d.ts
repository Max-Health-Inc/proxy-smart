import { SimpleQuantity } from "./SimpleQuantity";
import { Dosage, MedicationStatement, Reference, Timing } from "fhir/r4";
export interface MedicationStatementIPSDosage extends Dosage {
    /** Must Support */
    timing?: Timing;
    maxDosePerAdministration?: SimpleQuantity;
    maxDosePerLifetime?: SimpleQuantity;
}
export interface MedicationStatementIPS extends MedicationStatement {
    /** Must Support */
    subject: Reference;
    /** Must Support */
    dosage?: MedicationStatementIPSDosage[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateMedicationStatementIPS(resource: MedicationStatementIPS, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
