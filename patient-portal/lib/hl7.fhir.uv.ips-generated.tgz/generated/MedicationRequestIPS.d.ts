import { SimpleQuantity } from "./SimpleQuantity";
import { Dosage, MedicationRequest, Reference, Timing } from "fhir/r4";
export interface MedicationRequestIPSDosageInstruction extends Dosage {
    /** Must Support */
    timing?: Timing;
    maxDosePerAdministration?: SimpleQuantity;
    maxDosePerLifetime?: SimpleQuantity;
}
export interface MedicationRequestIPS extends MedicationRequest {
    /** Must Support */
    subject: Reference;
    /** Must Support */
    dosageInstruction?: MedicationRequestIPSDosageInstruction[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateMedicationRequestIPS(resource: MedicationRequestIPS, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
