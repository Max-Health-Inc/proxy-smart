import { CodeableConceptIPS } from "./CodeableConceptIPS";
import { SimpleQuantity } from "./SimpleQuantity";
import { Observation, ObservationReferenceRange, Reference } from "fhir/r4";
export interface ObservationPregnancyEddUvIpsReferenceRange extends ObservationReferenceRange {
    low?: SimpleQuantity;
    high?: SimpleQuantity;
}
export interface ObservationPregnancyEddUvIps extends Observation {
    /** Must Support | @see {@link ./valuesets/ValueSet-PregnancyExpectedDeliveryDateMethodUvIps.ts} for valid codes (3 codes) */
    code: CodeableConceptIPS;
    /** Must Support */
    subject: Reference;
    referenceRange?: ObservationPregnancyEddUvIpsReferenceRange[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateObservationPregnancyEddUvIps(resource: ObservationPregnancyEddUvIps, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
