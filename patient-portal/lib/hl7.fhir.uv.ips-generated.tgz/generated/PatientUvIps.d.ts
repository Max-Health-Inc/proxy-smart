import { IndividualGenderIdentityExtension } from "./IndividualGenderIdentityExtension";
import { Address, ContactPoint, Extension, HumanName, Identifier, Patient, Reference } from "fhir/r4";
import { IndividualPronounsExtension } from "./IndividualPronounsExtension";
export interface PatientUvIps extends Patient {
    /** Must Support */
    identifier?: Identifier[];
    /** Must Support */
    name: HumanName[];
    /** Must Support */
    telecom?: ContactPoint[];
    /** Must Support */
    address?: Address[];
    /** Must Support */
    generalPractitioner?: Reference[];
    extension?: (Extension | IndividualGenderIdentityExtension | IndividualPronounsExtension)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePatientUvIps(resource: PatientUvIps, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
