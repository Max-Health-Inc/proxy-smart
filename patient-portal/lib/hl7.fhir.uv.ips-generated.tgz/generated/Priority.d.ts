import { CodeableConcept, Extension } from "fhir/r4";
export interface Priority extends Extension {
    url: "http://hl7.org/fhir/StructureDefinition/flag-priority";
    value: CodeableConcept;
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePriority(resource: Priority, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
