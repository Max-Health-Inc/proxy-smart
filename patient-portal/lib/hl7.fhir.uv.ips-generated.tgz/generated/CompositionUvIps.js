import fhirpath from "fhirpath";
import fhirpath_r4_model from "fhirpath/fhir-context/r4/index.js";
export async function validateCompositionUvIps(resource, options) {
    const errors = [];
    const warnings = [];
    const fhirpathOptions = {
        preciseMath: true,
        ...(options?.traceFn ? { traceFn: options.traceFn } : {}),
        ...(options?.signal ? { signal: options.signal } : {}),
        ...(options?.httpHeaders ? { httpHeaders: options.httpHeaders } : {}),
    };
    const result0 = await fhirpath.evaluate(resource, "Composition.all(contained.contained.empty())", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result0.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL NOT contain nested Resources");
    }
    const result1 = await fhirpath.evaluate(resource, "Composition.all(contained.where((('#'+id in (%resource.descendants().reference | %resource.descendants().as(canonical) | %resource.descendants().as(uri) | %resource.descendants().as(url))) or descendants().where(reference = '#').exists() or descendants().where(as(canonical) = '#').exists() or descendants().where(as(canonical) = '#').exists()).not()).trace('unmatched', id).empty())", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result1.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL be referred to from elsewhere in the resource or SHALL refer to the containing resource");
    }
    const result2 = await fhirpath.evaluate(resource, "Composition.all(contained.meta.versionId.empty() and contained.meta.lastUpdated.empty())", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result2.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a meta.versionId or a meta.lastUpdated");
    }
    const result3 = await fhirpath.evaluate(resource, "Composition.all(contained.meta.security.empty())", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result3.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a security label");
    }
    const result4 = await fhirpath.evaluate(resource, "Composition.all(text.`div`.exists())", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result4.every(Boolean)) {
        warnings.push("Constraint violation: A resource should have narrative for robust management");
    }
    const result5 = await fhirpath.evaluate(resource, "meta.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result5.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result6 = await fhirpath.evaluate(resource, "implicitRules.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result6.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result7 = await fhirpath.evaluate(resource, "language.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result7.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result8 = await fhirpath.evaluate(resource, "text.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result8.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result9 = await fhirpath.evaluate(resource, "extension.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result9.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result10 = await fhirpath.evaluate(resource, "modifierExtension.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result10.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result11 = await fhirpath.evaluate(resource, "identifier.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result11.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result12 = await fhirpath.evaluate(resource, "status.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result12.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result13 = await fhirpath.evaluate(resource, "type.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result13.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result14 = await fhirpath.evaluate(resource, "category.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result14.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result15 = await fhirpath.evaluate(resource, "subject.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result15.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result16 = await fhirpath.evaluate(resource, "encounter.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result16.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result17 = await fhirpath.evaluate(resource, "date.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result17.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result18 = await fhirpath.evaluate(resource, "author.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result18.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result19 = await fhirpath.evaluate(resource, "title.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result19.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result20 = await fhirpath.evaluate(resource, "confidentiality.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result20.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result21 = await fhirpath.evaluate(resource, "attester.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result21.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result22 = await fhirpath.evaluate(resource, "custodian.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result22.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result23 = await fhirpath.evaluate(resource, "relatesTo.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result23.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result24 = await fhirpath.evaluate(resource, "event.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result24.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result25 = await fhirpath.evaluate(resource, "text.exists() or entry.exists() or section.exists()", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result25.every(Boolean)) {
        errors.push("Constraint violation: A section must contain at least one of text, entries, or sub-sections");
    }
    const result26 = await fhirpath.evaluate(resource, "section.all(emptyReason.empty() or entry.empty())", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result26.every(Boolean)) {
        errors.push("Constraint violation: A section can only have an emptyReason if it is empty");
    }
    const result27 = await fhirpath.evaluate(resource, "section.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result27.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result28 = await fhirpath.evaluate(resource, "DomainResource.all(contained.contained.empty())", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result28.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL NOT contain nested Resources");
    }
    const result29 = await fhirpath.evaluate(resource, "DomainResource.all(contained.where((('#'+id in (%resource.descendants().reference | %resource.descendants().as(canonical) | %resource.descendants().as(uri) | %resource.descendants().as(url))) or descendants().where(reference = '#').exists() or descendants().where(as(canonical) = '#').exists() or descendants().where(as(canonical) = '#').exists()).not()).trace('unmatched', id).empty())", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result29.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL be referred to from elsewhere in the resource or SHALL refer to the containing resource");
    }
    const result30 = await fhirpath.evaluate(resource, "DomainResource.all(contained.meta.versionId.empty() and contained.meta.lastUpdated.empty())", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result30.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a meta.versionId or a meta.lastUpdated");
    }
    const result31 = await fhirpath.evaluate(resource, "DomainResource.all(contained.meta.security.empty())", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result31.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a security label");
    }
    const result32 = await fhirpath.evaluate(resource, "DomainResource.all(text.`div`.exists())", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result32.every(Boolean)) {
        warnings.push("Constraint violation: A resource should have narrative for robust management");
    }
    const result33 = await fhirpath.evaluate(resource, "section.all((entry.reference.exists() or emptyReason.exists()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result33.every(Boolean)) {
        errors.push("Constraint violation: Either section.entry or emptyReason are present");
    }
    const result34 = await fhirpath.evaluate(resource, "status.exists()", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result34.every(Boolean)) {
        errors.push("Constraint violation: status must be present");
    }
    const result35 = await fhirpath.evaluate(resource, "type.exists()", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result35.every(Boolean)) {
        errors.push("Constraint violation: type must be present");
    }
    const result36 = await fhirpath.evaluate(resource, "subject.exists()", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result36.every(Boolean)) {
        errors.push("Constraint violation: subject must be present");
    }
    const result37 = await fhirpath.evaluate(resource, "date.exists()", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result37.every(Boolean)) {
        errors.push("Constraint violation: date must be present");
    }
    const result38 = await fhirpath.evaluate(resource, "author.count() >= 1", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result38.every(Boolean)) {
        errors.push("Constraint violation: author must contain at least one element");
    }
    const result39 = await fhirpath.evaluate(resource, "title.exists()", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result39.every(Boolean)) {
        errors.push("Constraint violation: title must be present");
    }
    const result40 = await fhirpath.evaluate(resource, "section.count() >= 3", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result40.every(Boolean)) {
        errors.push("Constraint violation: section must contain at least 3 elements");
    }
    const result41 = await fhirpath.evaluate(resource, "section.count() >= 1", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result41.every(Boolean)) {
        errors.push("Constraint violation: section must contain at least one element");
    }
    const result42 = await fhirpath.evaluate(resource, "section.section.count() <= 0", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result42.every(Boolean)) {
        errors.push("Constraint violation: section.section must contain at most 0 elements");
    }
    const result43 = await fhirpath.evaluate(resource, "event.count() <= 1", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result43.every(Boolean)) {
        errors.push("Constraint violation: event must contain at most one element");
    }
    const result44 = await fhirpath.evaluate(resource, "event.code.count() <= 1", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result44.every(Boolean)) {
        errors.push("Constraint violation: event.code must contain at most one element");
    }
    const result45 = await fhirpath.evaluate(resource, "section.count() <= 1", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result45.every(Boolean)) {
        errors.push("Constraint violation: section must contain at most one element");
    }
    const result46 = await fhirpath.evaluate(resource, "section.entry.count() <= 1", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result46.every(Boolean)) {
        errors.push("Constraint violation: section.entry must contain at most one element");
    }
    // Pattern constraint for type: must include coding with system="http://loinc.org" and code="60591-5"
    if (resource.type) {
        const type_pattern0Valid = resource.type.coding?.some(coding => coding?.system === "http://loinc.org" && coding?.code === "60591-5");
        if (!type_pattern0Valid) {
            errors.push("type must include a coding with system 'http://loinc.org' and code '60591-5'");
        }
    }
    // Required BackboneElement slice validation for section:sectionProblems (discriminated by code)
    if (resource.section && Array.isArray(resource.section)) {
        const sectionProblemsElements = resource.section.filter(item => item.code?.coding?.some((c) => c.system === "http://loinc.org" && c.code === "11450-4"));
        if (sectionProblemsElements.length < 1) {
            errors.push("No elements matched required slice: 'section:sectionProblems'");
        }
    }
    else {
        errors.push("No elements matched required slice: 'section:sectionProblems'");
    }
    // Required BackboneElement slice validation for section:sectionAllergies (discriminated by code)
    if (resource.section && Array.isArray(resource.section)) {
        const sectionAllergiesElements = resource.section.filter(item => item.code?.coding?.some((c) => c.system === "http://loinc.org" && c.code === "48765-2"));
        if (sectionAllergiesElements.length < 1) {
            errors.push("No elements matched required slice: 'section:sectionAllergies'");
        }
    }
    else {
        errors.push("No elements matched required slice: 'section:sectionAllergies'");
    }
    // Required BackboneElement slice validation for section:sectionMedications (discriminated by code)
    if (resource.section && Array.isArray(resource.section)) {
        const sectionMedicationsElements = resource.section.filter(item => item.code?.coding?.some((c) => c.system === "http://loinc.org" && c.code === "10160-0"));
        if (sectionMedicationsElements.length < 1) {
            errors.push("No elements matched required slice: 'section:sectionMedications'");
        }
    }
    else {
        errors.push("No elements matched required slice: 'section:sectionMedications'");
    }
    return { errors, warnings };
}
