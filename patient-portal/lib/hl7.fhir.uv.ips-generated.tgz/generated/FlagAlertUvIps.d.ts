import { CodeableConceptIPS } from "./CodeableConceptIPS";
import { Extension, Flag, Reference } from "fhir/r4";
import { Priority } from "./Priority";
export interface FlagAlertUvIps extends Flag {
    status: "active";
    /** Must Support */
    category?: CodeableConceptIPS[];
    /** Must Support */
    code: CodeableConceptIPS;
    /** Must Support */
    subject: Reference;
    extension?: (Extension | Priority)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateFlagAlertUvIps(resource: FlagAlertUvIps, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
