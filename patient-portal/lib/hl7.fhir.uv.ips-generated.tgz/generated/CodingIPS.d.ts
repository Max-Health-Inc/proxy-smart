import { Translation } from "./Translation";
import { Coding, Element, Extension } from "fhir/r4";
export interface CodingIPSDisplayElement extends Element {
    extension?: (Extension | Translation)[];
}
export interface CodingIPS extends Coding {
    _display?: CodingIPSDisplayElement;
    display?: string;
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateCodingIPS(resource: CodingIPS, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
