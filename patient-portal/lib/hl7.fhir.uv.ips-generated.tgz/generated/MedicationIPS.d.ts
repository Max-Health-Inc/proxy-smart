import { CodeableConceptIPS } from "./CodeableConceptIPS";
import { Medication, MedicationIngredient, Ratio } from "fhir/r4";
export interface MedicationIPSIngredient extends MedicationIngredient {
    /** Must Support */
    strength?: Ratio;
}
export interface MedicationIPS extends Medication {
    /** Must Support */
    code: CodeableConceptIPS;
    /** Must Support */
    form?: CodeableConceptIPS;
    /** Must Support */
    ingredient?: MedicationIPSIngredient[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateMedicationIPS(resource: MedicationIPS, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
