import { Device, Identifier } from "fhir/r4";
export interface DeviceObserverUvIps extends Device {
    /** Must Support */
    identifier?: Identifier[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateDeviceObserverUvIps(resource: DeviceObserverUvIps, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
