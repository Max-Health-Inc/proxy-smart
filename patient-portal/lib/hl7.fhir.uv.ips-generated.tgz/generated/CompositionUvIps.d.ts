import { NoteExtension } from "./NoteExtension";
import { CodeableConcept, Coding, Composition, CompositionAttester, CompositionSection, Extension, Identifier, Narrative, Reference } from "fhir/r4";
export interface CompositionUvIpsTypeCoding extends Coding {
    system: "http://loinc.org";
    code: "60591-5";
}
export interface CompositionUvIpsSection extends CompositionSection {
    /** Must Support */
    code: CodeableConcept;
    /** Must Support */
    text: Narrative;
    extension?: (Extension | NoteExtension | NoteExtension | NoteExtension | NoteExtension | NoteExtension | NoteExtension | NoteExtension | NoteExtension | NoteExtension | NoteExtension | NoteExtension | NoteExtension | NoteExtension | NoteExtension | NoteExtension | NoteExtension | NoteExtension)[];
}
export interface CompositionUvIps extends Composition {
    /** Must Support */
    text?: Narrative;
    /** Must Support */
    identifier?: Identifier;
    type: {
        coding: CompositionUvIpsTypeCoding[];
    };
    /** Must Support */
    subject: Reference;
    /** Must Support */
    author: Reference[];
    /** Must Support */
    attester?: CompositionAttester[];
    /** Must Support */
    custodian?: Reference;
    /** Must Support */
    section: CompositionUvIpsSection[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateCompositionUvIps(resource: CompositionUvIps, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
