import { SimpleQuantity } from "./SimpleQuantity";
import { Coding, Observation, ObservationReferenceRange, Reference } from "fhir/r4";
export interface ObservationPregnancyStatusUvIpsCodeCoding extends Coding {
    system: "http://loinc.org";
    code: "82810-3";
}
export interface ObservationPregnancyStatusUvIpsReferenceRange extends ObservationReferenceRange {
    low?: SimpleQuantity;
    high?: SimpleQuantity;
}
export interface ObservationPregnancyStatusUvIps extends Observation {
    code: {
        coding: ObservationPregnancyStatusUvIpsCodeCoding[];
    };
    /** Must Support */
    subject: Reference;
    referenceRange?: ObservationPregnancyStatusUvIpsReferenceRange[];
    /** Must Support */
    hasMember?: Reference[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateObservationPregnancyStatusUvIps(resource: ObservationPregnancyStatusUvIps, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
