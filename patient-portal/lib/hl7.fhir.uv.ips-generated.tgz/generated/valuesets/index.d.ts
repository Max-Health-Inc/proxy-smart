/**
 * ValueSet Registry
 * Central registry of all loaded ValueSets with explicit codes
 */
import * as CurrentSmokingStatusUvIps from './ValueSet-CurrentSmokingStatusUvIps.js';
import * as MedicationsExampleUvIps from './ValueSet-MedicationsExampleUvIps.js';
import * as PersonalRelationshipUvIps from './ValueSet-PersonalRelationshipUvIps.js';
import * as PregnanciesSummaryUvIps from './ValueSet-PregnanciesSummaryUvIps.js';
import * as PregnancyExpectedDeliveryDateMethodUvIps from './ValueSet-PregnancyExpectedDeliveryDateMethodUvIps.js';
import * as PregnancyStatusUvIps from './ValueSet-PregnancyStatusUvIps.js';
import * as ProblemTypeLoinc from './ValueSet-ProblemTypeLoinc.js';
import * as ProblemTypeUvIps from './ValueSet-ProblemTypeUvIps.js';
import * as ResultsRadiologyComponentUvIps from './ValueSet-ResultsRadiologyComponentUvIps.js';
import * as VaccineTargetDiseasesUvIps from './ValueSet-VaccineTargetDiseasesUvIps.js';
export declare const ValueSetRegistry: {
    readonly CurrentSmokingStatusUvIps: typeof CurrentSmokingStatusUvIps;
    readonly MedicationsExampleUvIps: typeof MedicationsExampleUvIps;
    readonly PersonalRelationshipUvIps: typeof PersonalRelationshipUvIps;
    readonly PregnanciesSummaryUvIps: typeof PregnanciesSummaryUvIps;
    readonly PregnancyExpectedDeliveryDateMethodUvIps: typeof PregnancyExpectedDeliveryDateMethodUvIps;
    readonly PregnancyStatusUvIps: typeof PregnancyStatusUvIps;
    readonly ProblemTypeLoinc: typeof ProblemTypeLoinc;
    readonly ProblemTypeUvIps: typeof ProblemTypeUvIps;
    readonly ResultsRadiologyComponentUvIps: typeof ResultsRadiologyComponentUvIps;
    readonly VaccineTargetDiseasesUvIps: typeof VaccineTargetDiseasesUvIps;
};
export type ValueSetName = keyof typeof ValueSetRegistry;
export declare function getValueSet(name: ValueSetName): typeof CurrentSmokingStatusUvIps | typeof MedicationsExampleUvIps | typeof PersonalRelationshipUvIps | typeof PregnanciesSummaryUvIps | typeof PregnancyExpectedDeliveryDateMethodUvIps | typeof PregnancyStatusUvIps | typeof ProblemTypeLoinc | typeof ProblemTypeUvIps | typeof ResultsRadiologyComponentUvIps | typeof VaccineTargetDiseasesUvIps;
/** Map from ValueSet URL to registry name */
export declare const ValueSetUrlMap: Record<string, ValueSetName>;
/**
 * Get a random code from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A random code string, or undefined if ValueSet not found
 */
export declare function getRandomCodeByUrl(url: string): string | undefined;
/**
 * Get a random concept (code, system, display) from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A concept object with code, system, and optional display, or undefined if ValueSet not found
 */
export declare function getRandomConceptByUrl(url: string): {
    code: string;
    system: string;
    display?: string;
} | undefined;
