/**
 * ValueSet Registry
 * Central registry of all loaded ValueSets with explicit codes
 */
import * as CurrentSmokingStatusUvIps from './ValueSet-CurrentSmokingStatusUvIps.js';
import * as MedicationsExampleUvIps from './ValueSet-MedicationsExampleUvIps.js';
import * as PersonalRelationshipUvIps from './ValueSet-PersonalRelationshipUvIps.js';
import * as PregnanciesSummaryUvIps from './ValueSet-PregnanciesSummaryUvIps.js';
import * as PregnancyExpectedDeliveryDateMethodUvIps from './ValueSet-PregnancyExpectedDeliveryDateMethodUvIps.js';
import * as PregnancyStatusUvIps from './ValueSet-PregnancyStatusUvIps.js';
import * as ProblemTypeLoinc from './ValueSet-ProblemTypeLoinc.js';
import * as ProblemTypeUvIps from './ValueSet-ProblemTypeUvIps.js';
import * as ResultsRadiologyComponentUvIps from './ValueSet-ResultsRadiologyComponentUvIps.js';
import * as VaccineTargetDiseasesUvIps from './ValueSet-VaccineTargetDiseasesUvIps.js';
export const ValueSetRegistry = {
    CurrentSmokingStatusUvIps,
    MedicationsExampleUvIps,
    PersonalRelationshipUvIps,
    PregnanciesSummaryUvIps,
    PregnancyExpectedDeliveryDateMethodUvIps,
    PregnancyStatusUvIps,
    ProblemTypeLoinc,
    ProblemTypeUvIps,
    ResultsRadiologyComponentUvIps,
    VaccineTargetDiseasesUvIps,
};
export function getValueSet(name) {
    return ValueSetRegistry[name];
}
/** Map from ValueSet URL to registry name */
export const ValueSetUrlMap = {
    'http://hl7.org/fhir/uv/ips/ValueSet/current-smoking-status-uv-ips': 'CurrentSmokingStatusUvIps',
    'http://hl7.org/fhir/uv/ips/ValueSet/medication-example-uv-ips': 'MedicationsExampleUvIps',
    'http://hl7.org/fhir/uv/ips/ValueSet/personal-relationship-uv-ips': 'PersonalRelationshipUvIps',
    'http://hl7.org/fhir/uv/ips/ValueSet/pregnancies-summary-uv-ips': 'PregnanciesSummaryUvIps',
    'http://hl7.org/fhir/uv/ips/ValueSet/edd-method-uv-ips': 'PregnancyExpectedDeliveryDateMethodUvIps',
    'http://hl7.org/fhir/uv/ips/ValueSet/pregnancy-status-uv-ips': 'PregnancyStatusUvIps',
    'http://hl7.org/fhir/uv/ips/ValueSet/problem-type-loinc': 'ProblemTypeLoinc',
    'http://hl7.org/fhir/uv/ips/ValueSet/problem-type-uv-ips': 'ProblemTypeUvIps',
    'http://hl7.org/fhir/uv/ips/ValueSet/results-radiology-component-uv-ips': 'ResultsRadiologyComponentUvIps',
    'http://hl7.org/fhir/uv/ips/ValueSet/target-diseases-uv-ips': 'VaccineTargetDiseasesUvIps',
};
function stripVersionFromUrl(url) {
    const pipeIndex = url.indexOf('|');
    return pipeIndex >= 0 ? url.substring(0, pipeIndex) : url;
}
/**
 * Get a random code from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A random code string, or undefined if ValueSet not found
 */
export function getRandomCodeByUrl(url) {
    const cleanUrl = stripVersionFromUrl(url);
    const name = ValueSetUrlMap[cleanUrl];
    if (!name)
        return undefined;
    const vs = ValueSetRegistry[name];
    // Each ValueSet exports random<Name>Code() function
    const randomFn = vs['random' + name + 'Code'];
    return randomFn?.();
}
/**
 * Get a random concept (code, system, display) from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A concept object with code, system, and optional display, or undefined if ValueSet not found
 */
export function getRandomConceptByUrl(url) {
    const cleanUrl = stripVersionFromUrl(url);
    const name = ValueSetUrlMap[cleanUrl];
    if (!name)
        return undefined;
    const vs = ValueSetRegistry[name];
    // Each ValueSet exports random<Name>Concept() function
    const randomFn = vs['random' + name + 'Concept'];
    return randomFn?.();
}
