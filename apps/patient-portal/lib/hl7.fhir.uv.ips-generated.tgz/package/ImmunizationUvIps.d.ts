import { CodeableConceptIPS } from "./CodeableConceptIPS";
import { Immunization, Reference } from "fhir/r4";
export interface ImmunizationUvIps extends Omit<Immunization, 'vaccineCode' | 'patient' | 'site' | 'route'> {
    /** Must Support | @see {@link ./valuesets/ValueSet-VaccinesUvIps.ts} for valid codes (2 codes) */
    vaccineCode: CodeableConceptIPS;
    /** Must Support */
    patient: Reference;
    /** @see {@link ./valuesets/ValueSet-BodySite.ts} for valid codes (15 codes) */
    site?: CodeableConceptIPS;
    route?: CodeableConceptIPS;
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateImmunizationUvIps(resource: ImmunizationUvIps, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
