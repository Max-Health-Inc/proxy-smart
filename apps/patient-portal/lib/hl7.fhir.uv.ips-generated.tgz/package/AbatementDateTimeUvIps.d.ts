import { Extension } from "fhir/r4";
export interface AbatementDateTimeUvIps extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/ips/StructureDefinition/abatement-dateTime-uv-ips";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateAbatementDateTimeUvIps(resource: AbatementDateTimeUvIps, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
