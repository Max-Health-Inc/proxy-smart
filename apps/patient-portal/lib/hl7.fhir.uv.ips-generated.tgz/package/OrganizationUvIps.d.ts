import { Organization } from "fhir/r4";
export type OrganizationUvIps = Organization;
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateOrganizationUvIps(resource: OrganizationUvIps, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
