import { CodeableConceptIPS } from "./CodeableConceptIPS";
import { Specimen } from "fhir/r4";
export interface SpecimenUvIps extends Omit<Specimen, 'type'> {
    type: CodeableConceptIPS;
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateSpecimenUvIps(resource: SpecimenUvIps, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
