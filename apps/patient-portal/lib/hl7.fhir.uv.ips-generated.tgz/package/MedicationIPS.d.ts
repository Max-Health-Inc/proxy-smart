import { CodeableConceptIPS } from "./CodeableConceptIPS";
import { RatioIPS } from "./RatioIPS";
import { Medication, MedicationIngredient } from "fhir/r4";
export interface MedicationIPSIngredient extends Omit<MedicationIngredient, 'strength'> {
    /** Must Support */
    strength?: RatioIPS;
}
export interface MedicationIPS extends Omit<Medication, 'code' | 'form' | 'ingredient'> {
    /** Must Support | @see {@link ./valuesets/ValueSet-MedicationSnomedCodesAbsentUnknown.ts} for valid codes (2 codes) */
    code: CodeableConceptIPS;
    /** Must Support */
    form?: CodeableConceptIPS;
    /** Must Support */
    ingredient?: MedicationIPSIngredient[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateMedicationIPS(resource: MedicationIPS, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
