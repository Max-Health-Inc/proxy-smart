import { AbatementDateTimeUvIps } from "./AbatementDateTimeUvIps";
import { CodeableConceptIPS } from "./CodeableConceptIPS";
import { AllergyIntolerance, AllergyIntoleranceReaction, Extension, Reference } from "fhir/r4";
export interface AllergyIntoleranceUvIpsReaction extends Omit<AllergyIntoleranceReaction, 'manifestation'> {
    /** Must Support | @see {@link ./valuesets/ValueSet-AllergyReactionSnomedCtIpsFreeSet.ts} for valid codes (31 codes) */
    manifestation: CodeableConceptIPS[];
}
export interface AllergyIntoleranceUvIps extends Omit<AllergyIntolerance, 'code' | 'patient' | 'reaction' | 'extension'> {
    /** Must Support | @see {@link ./valuesets/ValueSet-AllergyIntoleranceUvIps.ts} for valid codes (5 codes) */
    code?: CodeableConceptIPS;
    /** Must Support */
    patient: Reference;
    /** Must Support */
    reaction?: AllergyIntoleranceUvIpsReaction[];
    extension?: (Extension | AbatementDateTimeUvIps)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateAllergyIntoleranceUvIps(resource: AllergyIntoleranceUvIps, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
