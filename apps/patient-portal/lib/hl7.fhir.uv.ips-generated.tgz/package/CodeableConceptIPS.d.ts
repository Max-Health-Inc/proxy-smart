import { CodingIPS } from "./CodingIPS";
import { CodeableConcept } from "fhir/r4";
export interface CodeableConceptIPS extends Omit<CodeableConcept, 'coding'> {
    /** Must Support */
    coding?: CodingIPS[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateCodeableConceptIPS(resource: CodeableConceptIPS, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
