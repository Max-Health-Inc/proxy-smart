import { Address, ContactPoint, HumanName, Identifier, Patient, Reference } from "fhir/r4";
export interface PatientUvIps extends Omit<Patient, 'identifier' | 'name' | 'telecom' | 'address' | 'generalPractitioner'> {
    /** Must Support */
    identifier?: Identifier[];
    /** Must Support */
    name: HumanName[];
    /** Must Support */
    telecom?: ContactPoint[];
    /** Must Support */
    address?: Address[];
    /** Must Support */
    generalPractitioner?: Reference[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePatientUvIps(resource: PatientUvIps, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
