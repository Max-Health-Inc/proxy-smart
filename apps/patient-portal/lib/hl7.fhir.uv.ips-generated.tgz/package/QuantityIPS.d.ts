import { Quantity } from "fhir/r4";
export interface QuantityIPS extends Omit<Quantity, 'system'> {
    system: "http://unitsofmeasure.org";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateQuantityIPS(resource: QuantityIPS, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
