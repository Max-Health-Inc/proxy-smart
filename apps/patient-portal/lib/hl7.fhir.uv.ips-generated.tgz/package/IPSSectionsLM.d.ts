import { Document } from "./Document";
import { DocumentSection } from "./DocumentSection";
export interface IPSSectionsLM extends Document {
    sectionProblems: DocumentSection;
    sectionAllergies: DocumentSection;
    sectionMedications: DocumentSection;
    sectionImmunizations?: DocumentSection;
    sectionResults?: DocumentSection;
    sectionProceduresHx?: DocumentSection;
    sectionMedicalDevices?: DocumentSection;
    sectionAdvanceDirectives?: DocumentSection;
    sectionAlerts?: DocumentSection;
    sectionFunctionalStatus?: DocumentSection;
    sectionPastProblems?: DocumentSection;
    sectionPregnancyHx?: DocumentSection;
    sectionPatientStory?: DocumentSection;
    sectionPlanOfCare?: DocumentSection;
    sectionSocialHistory?: DocumentSection;
    sectionVitalSigns?: DocumentSection;
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateIPSSectionsLM(resource: IPSSectionsLM, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
