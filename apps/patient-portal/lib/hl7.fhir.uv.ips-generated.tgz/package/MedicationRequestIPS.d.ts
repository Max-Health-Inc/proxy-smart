import { CodeableConceptIPS } from "./CodeableConceptIPS";
import { DataAbsentReason } from "./DataAbsentReason";
import { Dosage, Extension, MedicationRequest, MedicationRequestDispenseRequest, Period, Reference, SimpleQuantity, Timing } from "fhir/r4";
export interface MedicationRequestIPSDosageInstruction extends Omit<Dosage, 'text' | 'timing' | 'route' | 'maxDosePerAdministration' | 'maxDosePerLifetime'> {
    /** Must Support */
    text?: string;
    /** Must Support */
    timing?: Timing;
    route?: CodeableConceptIPS;
    maxDosePerAdministration?: SimpleQuantity;
    maxDosePerLifetime?: SimpleQuantity;
}
export interface MedicationRequestIPS extends Omit<MedicationRequest, 'subject' | 'dosageInstruction' | 'dispenseRequest'> {
    /** Must Support */
    subject: Reference;
    /** Must Support */
    dosageInstruction?: MedicationRequestIPSDosageInstruction[];
    dispenseRequest: MedicationRequestIPSDispenseRequest;
}
export interface MedicationRequestIPSDispenseRequest extends Omit<MedicationRequestDispenseRequest, 'validityPeriod'> {
    validityPeriod: MedicationRequestIPSDispenseRequestValidityPeriod;
}
export interface MedicationRequestIPSDispenseRequestValidityPeriod extends Omit<Period, 'extension'> {
    extension?: (Extension | DataAbsentReason)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateMedicationRequestIPS(resource: MedicationRequestIPS, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
