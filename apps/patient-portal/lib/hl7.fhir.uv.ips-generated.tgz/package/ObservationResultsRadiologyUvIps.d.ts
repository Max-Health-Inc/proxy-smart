import { ObservationCodesCode } from "./valuesets/ValueSet-ObservationCodes";
import { CodeableConceptIPS } from "./CodeableConceptIPS";
import { CodeableConcept, Observation, ObservationComponent, Reference } from "fhir/r4";
export interface ObservationResultsRadiologyUvIpsComponent extends Omit<ObservationComponent, 'code'> {
    /** @see {@link ./valuesets/ValueSet-ObservationCodes.ts} for valid codes (31 codes) */
    code: CodeableConcept & {
        coding: Array<{
            code: ObservationCodesCode;
            system: "http://loinc.org";
        }>;
    };
}
export interface ObservationResultsRadiologyUvIps extends Omit<Observation, 'status' | 'performer' | 'bodySite' | 'component'> {
    status: "final";
    /** Must Support */
    performer: Reference[];
    /** @see {@link ./valuesets/ValueSet-BodySite.ts} for valid codes (15 codes) */
    bodySite?: CodeableConceptIPS;
    /** Must Support */
    component?: ObservationResultsRadiologyUvIpsComponent[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateObservationResultsRadiologyUvIps(resource: ObservationResultsRadiologyUvIps, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
