import { SimpleQuantityIPS } from "./SimpleQuantityIPS";
import { Range } from "fhir/r4";
export interface RangeIPS extends Omit<Range, 'low' | 'high'> {
    /** Must Support */
    low?: SimpleQuantityIPS;
    /** Must Support */
    high?: SimpleQuantityIPS;
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateRangeIPS(resource: RangeIPS, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
