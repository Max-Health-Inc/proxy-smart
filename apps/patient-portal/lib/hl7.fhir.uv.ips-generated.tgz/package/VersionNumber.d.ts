import { Extension } from "fhir/r4";
export interface VersionNumber extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/StructureDefinition/composition-clinicaldocument-versionNumber";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateVersionNumber(resource: VersionNumber, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
