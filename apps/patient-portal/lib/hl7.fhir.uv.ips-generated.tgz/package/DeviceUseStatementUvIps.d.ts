import { CodeableConceptIPS } from "./CodeableConceptIPS";
import { DeviceUseStatement, Reference } from "fhir/r4";
export interface DeviceUseStatementUvIps extends Omit<DeviceUseStatement, 'subject' | 'device' | 'bodySite'> {
    /** Must Support */
    subject: Reference;
    /** Must Support */
    device: Reference;
    /** @see {@link ./valuesets/ValueSet-BodySite.ts} for valid codes (15 codes) */
    bodySite?: CodeableConceptIPS;
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateDeviceUseStatementUvIps(resource: DeviceUseStatementUvIps, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
