/**
 * ValueSet: MedicalDevicesSnomedCtIpsFreeSet
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/medical-devices-snomed-ct-ips-free-set
 * Size: Infinity concepts
 */
export const MedicalDevicesSnomedCtIpsFreeSetConcepts = [
    { code: "705991002", system: "http://snomed.info/sct", display: "Mechanical cardiac valve prosthesis" },
    { code: "705865004", system: "http://snomed.info/sct", display: "Implantable ankle prosthesis" },
    { code: "469997005", system: "http://snomed.info/sct", display: "Maxillofacial prosthesis" },
    { code: "429798007", system: "http://snomed.info/sct", display: "Artificial vertebral disc" },
    { code: "424921004", system: "http://snomed.info/sct", display: "Permanent cardiac pacemaker, device" },
    { code: "423449009", system: "http://snomed.info/sct", display: "Pulmonary valve prosthesis" },
    { code: "421168009", system: "http://snomed.info/sct", display: "Eye sphere implant" },
    { code: "414580007", system: "http://snomed.info/sct", display: "Laryngeal keel" },
    { code: "413766009", system: "http://snomed.info/sct", display: "Carotid artery stent" },
    { code: "408099007", system: "http://snomed.info/sct", display: "Suture" },
    { code: "360329004", system: "http://snomed.info/sct", display: "Dacron graft" },
    { code: "360145006", system: "http://snomed.info/sct", display: "Bone prosthesis" },
    { code: "360123005", system: "http://snomed.info/sct", display: "Biliary stent" },
    { code: "360100007", system: "http://snomed.info/sct", display: "Tracheal stent" },
    { code: "360070009", system: "http://snomed.info/sct", display: "Laryngeal implant" },
    { code: "360058005", system: "http://snomed.info/sct", display: "Intraventricular pump" },
    { code: "360046005", system: "http://snomed.info/sct", display: "Arterial stent" },
    { code: "360041000", system: "http://snomed.info/sct", display: "Implanted drug delivery system" },
    { code: "314523008", system: "http://snomed.info/sct", display: "Joint implant" },
    { code: "304186003", system: "http://snomed.info/sct", display: "Hand joint implant" },
    { code: "304185004", system: "http://snomed.info/sct", display: "Foot joint implant" },
    { code: "304124003", system: "http://snomed.info/sct", display: "Shoulder joint implant" },
    { code: "304121006", system: "http://snomed.info/sct", display: "Femoral head prosthesis" },
    { code: "304120007", system: "http://snomed.info/sct", display: "Total hip replacement prosthesis" },
    { code: "304070008", system: "http://snomed.info/sct", display: "Body wall implant" },
    { code: "303947005", system: "http://snomed.info/sct", display: "Rod fixation system" },
    { code: "303726000", system: "http://snomed.info/sct", display: "Shoulder joint prosthesis" },
    { code: "303619008", system: "http://snomed.info/sct", display: "Cardiac implant" },
    { code: "303618000", system: "http://snomed.info/sct", display: "Nervous system implant" },
    { code: "303617005", system: "http://snomed.info/sct", display: "Vascular implant" },
    { code: "303608005", system: "http://snomed.info/sct", display: "Ophthalmological implant" },
    { code: "303533002", system: "http://snomed.info/sct", display: "Hip joint implant" },
    { code: "303515008", system: "http://snomed.info/sct", display: "Orbital implant" },
    { code: "303503009", system: "http://snomed.info/sct", display: "Musculoskeletal implant" },
    { code: "303500007", system: "http://snomed.info/sct", display: "Auditory implant" },
    { code: "303499003", system: "http://snomed.info/sct", display: "Gastrointestinal implant" },
    { code: "303497001", system: "http://snomed.info/sct", display: "Urogenital implant" },
    { code: "303490004", system: "http://snomed.info/sct", display: "Cardiovascular implant" },
    { code: "303277008", system: "http://snomed.info/sct", display: "Fallopian tube prosthesis" },
    { code: "286576009", system: "http://snomed.info/sct", display: "Urethral stent" },
    { code: "286558002", system: "http://snomed.info/sct", display: "Ureteric stent" },
    { code: "268460000", system: "http://snomed.info/sct", display: "Intrauterine contraceptive device" },
    { code: "264824009", system: "http://snomed.info/sct", display: "Cardiac conduit" },
    { code: "258593008", system: "http://snomed.info/sct", display: "Ventricular shunt" },
    { code: "257366006", system: "http://snomed.info/sct", display: "JJ stent" },
    { code: "257343005", system: "http://snomed.info/sct", display: "Xenograft cardiac valve" },
    { code: "257283004", system: "http://snomed.info/sct", display: "Valved cardiac conduit" },
    { code: "257282009", system: "http://snomed.info/sct", display: "Non-valved conduit" },
    { code: "257275005", system: "http://snomed.info/sct", display: "Spinal cage" },
    { code: "118425005", system: "http://snomed.info/sct", display: "Ventricular reservoir" },
    { code: "118374007", system: "http://snomed.info/sct", display: "Silicone implant" },
    { code: "102314001", system: "http://snomed.info/sct", display: "Embolization coil" },
    { code: "102303004", system: "http://snomed.info/sct", display: "Vascular prosthesis" },
    { code: "90134004", system: "http://snomed.info/sct", display: "Metal periosteal implant" },
    { code: "84683006", system: "http://snomed.info/sct", display: "Aortic valve prosthesis" },
    { code: "77777004", system: "http://snomed.info/sct", display: "Bone staple" },
    { code: "77444004", system: "http://snomed.info/sct", display: "Bone pin" },
    { code: "74444006", system: "http://snomed.info/sct", display: "Limb prosthesis" },
    { code: "72506001", system: "http://snomed.info/sct", display: "Implantable defibrillator" },
    { code: "68183006", system: "http://snomed.info/sct", display: "Bone screw" },
    { code: "67270000", system: "http://snomed.info/sct", display: "Hip prosthesis" },
    { code: "63289001", system: "http://snomed.info/sct", display: "Surgical metal nail, device" },
    { code: "63112008", system: "http://snomed.info/sct", display: "Bone wire" },
    { code: "53671008", system: "http://snomed.info/sct", display: "Gastric balloon" },
    { code: "45633005", system: "http://snomed.info/sct", display: "Peritoneal dialyzer" },
    { code: "43252007", system: "http://snomed.info/sct", display: "Cochlear prosthesis" },
    { code: "31031000", system: "http://snomed.info/sct", display: "Orthopedic internal fixation system" },
    { code: "25937001", system: "http://snomed.info/sct", display: "Neurostimulator" },
    { code: "17107009", system: "http://snomed.info/sct", display: "Mitral valve prosthesis" },
    { code: "14423008", system: "http://snomed.info/sct", display: "Adhesive bandage" },
    { code: "2282003", system: "http://snomed.info/sct", display: "Breast implant" },
    { code: "271003", system: "http://snomed.info/sct", display: "Bone plate" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidMedicalDevicesSnomedCtIpsFreeSetCode(code) {
    return MedicalDevicesSnomedCtIpsFreeSetConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getMedicalDevicesSnomedCtIpsFreeSetConcept(code) {
    return MedicalDevicesSnomedCtIpsFreeSetConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const MedicalDevicesSnomedCtIpsFreeSetCodes = MedicalDevicesSnomedCtIpsFreeSetConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomMedicalDevicesSnomedCtIpsFreeSetCode() {
    return MedicalDevicesSnomedCtIpsFreeSetCodes[Math.floor(Math.random() * MedicalDevicesSnomedCtIpsFreeSetCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomMedicalDevicesSnomedCtIpsFreeSetConcept() {
    return MedicalDevicesSnomedCtIpsFreeSetConcepts[Math.floor(Math.random() * MedicalDevicesSnomedCtIpsFreeSetConcepts.length)];
}
