/**
 * ValueSet: ProcedureOutcomeCodes(SNOMEDCT)
 * URL: http://hl7.org/fhir/ValueSet/procedure-outcome
 * Size: 3 concepts
 */
export const ProcedureOutcomeCodesSNOMEDCTConcepts = [
    { code: "385669000", system: "http://snomed.info/sct" },
    { code: "385671000", system: "http://snomed.info/sct" },
    { code: "385670004", system: "http://snomed.info/sct" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidProcedureOutcomeCodesSNOMEDCTCode(code) {
    return ProcedureOutcomeCodesSNOMEDCTConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getProcedureOutcomeCodesSNOMEDCTConcept(code) {
    return ProcedureOutcomeCodesSNOMEDCTConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ProcedureOutcomeCodesSNOMEDCTCodes = ProcedureOutcomeCodesSNOMEDCTConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomProcedureOutcomeCodesSNOMEDCTCode() {
    return ProcedureOutcomeCodesSNOMEDCTCodes[Math.floor(Math.random() * ProcedureOutcomeCodesSNOMEDCTCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomProcedureOutcomeCodesSNOMEDCTConcept() {
    return ProcedureOutcomeCodesSNOMEDCTConcepts[Math.floor(Math.random() * ProcedureOutcomeCodesSNOMEDCTConcepts.length)];
}
