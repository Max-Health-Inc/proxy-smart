/**
 * ValueSet: AllergyReactionSnomedCtIpsFreeSet
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/allergy-reaction-snomed-ct-ips-free-set
 * Size: 31 concepts
 */
export declare const AllergyReactionSnomedCtIpsFreeSetConcepts: readonly [{
    readonly code: "4386001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Bronchospasm (finding)";
}, {
    readonly code: "9826008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Conjunctivitis (disorder)";
}, {
    readonly code: "23924001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Tight chest (finding)";
}, {
    readonly code: "24079001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Atopic dermatitis (disorder)";
}, {
    readonly code: "31996006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Vasculitis (disorder)";
}, {
    readonly code: "39579001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Anaphylaxis (disorder)";
}, {
    readonly code: "41291007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Angioedema (disorder)";
}, {
    readonly code: "43116000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Eczema (disorder)";
}, {
    readonly code: "49727002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Cough (finding)";
}, {
    readonly code: "51599000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Edema of larynx (disorder)";
}, {
    readonly code: "62315008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Diarrhea (finding)";
}, {
    readonly code: "70076002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Rhinitis (disorder)";
}, {
    readonly code: "73442001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Stevens-Johnson syndrome (disorder)";
}, {
    readonly code: "76067001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Sneezing (finding)";
}, {
    readonly code: "91175000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Seizure (finding)";
}, {
    readonly code: "126485001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Urticaria (disorder)";
}, {
    readonly code: "162290004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Dry eyes (finding)";
}, {
    readonly code: "195967001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Asthma (disorder)";
}, {
    readonly code: "247472004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Weal (disorder)";
}, {
    readonly code: "267036007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Dyspnea (finding)";
}, {
    readonly code: "271757001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Papular eruption (disorder)";
}, {
    readonly code: "271759003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Bullous eruption (disorder)";
}, {
    readonly code: "271807003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Eruption of skin (disorder)";
}, {
    readonly code: "410430005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Cardiorespiratory arrest (disorder)";
}, {
    readonly code: "418363000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Itching of skin (finding)";
}, {
    readonly code: "422400008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Vomiting (disorder)";
}, {
    readonly code: "422587007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Nausea (finding)";
}, {
    readonly code: "698247007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Cardiac arrhythmia (disorder)";
}, {
    readonly code: "702809001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Drug reaction with eosinophilia and systemic symptoms (disorder)";
}, {
    readonly code: "768962006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Lyell syndrome (disorder)";
}, {
    readonly code: "781682005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hyperemia of eye (finding)";
}];
/** String type (ValueSet too large for union type) */
export type AllergyReactionSnomedCtIpsFreeSetCode = string;
/** Type representing a concept from this ValueSet */
export type AllergyReactionSnomedCtIpsFreeSetConcept = typeof AllergyReactionSnomedCtIpsFreeSetConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidAllergyReactionSnomedCtIpsFreeSetCode(code: string): code is AllergyReactionSnomedCtIpsFreeSetCode;
/**
 * Get concept details by code
 */
export declare function getAllergyReactionSnomedCtIpsFreeSetConcept(code: string): AllergyReactionSnomedCtIpsFreeSetConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const AllergyReactionSnomedCtIpsFreeSetCodes: ("271757001" | "4386001" | "9826008" | "23924001" | "24079001" | "31996006" | "39579001" | "41291007" | "43116000" | "49727002" | "51599000" | "62315008" | "70076002" | "73442001" | "76067001" | "91175000" | "126485001" | "162290004" | "195967001" | "247472004" | "267036007" | "271759003" | "271807003" | "410430005" | "418363000" | "422400008" | "422587007" | "698247007" | "702809001" | "768962006" | "781682005")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomAllergyReactionSnomedCtIpsFreeSetCode(): AllergyReactionSnomedCtIpsFreeSetCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomAllergyReactionSnomedCtIpsFreeSetConcept(): AllergyReactionSnomedCtIpsFreeSetConcept;
