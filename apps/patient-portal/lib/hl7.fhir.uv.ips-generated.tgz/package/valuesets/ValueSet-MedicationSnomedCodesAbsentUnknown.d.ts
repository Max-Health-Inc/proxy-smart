/**
 * ValueSet: MedicationSnomedCodesAbsentUnknown
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/medication-snomed-absent-unknown-uv-ips
 * Size: 2 concepts
 */
export declare const MedicationSnomedCodesAbsentUnknownConcepts: readonly [{
    readonly code: "no-medication-info";
    readonly system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips";
}, {
    readonly code: "no-known-medications";
    readonly system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips";
}];
/** Union type of all valid codes in this ValueSet */
export type MedicationSnomedCodesAbsentUnknownCode = "no-medication-info" | "no-known-medications";
/** Type representing a concept from this ValueSet */
export type MedicationSnomedCodesAbsentUnknownConcept = typeof MedicationSnomedCodesAbsentUnknownConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidMedicationSnomedCodesAbsentUnknownCode(code: string): code is MedicationSnomedCodesAbsentUnknownCode;
/**
 * Get concept details by code
 */
export declare function getMedicationSnomedCodesAbsentUnknownConcept(code: string): MedicationSnomedCodesAbsentUnknownConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const MedicationSnomedCodesAbsentUnknownCodes: ("no-medication-info" | "no-known-medications")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomMedicationSnomedCodesAbsentUnknownCode(): MedicationSnomedCodesAbsentUnknownCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomMedicationSnomedCodesAbsentUnknownConcept(): MedicationSnomedCodesAbsentUnknownConcept;
