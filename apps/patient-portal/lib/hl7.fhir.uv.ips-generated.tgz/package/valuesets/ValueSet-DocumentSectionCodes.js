/**
 * ValueSet: DocumentSectionCodes
 * URL: http://hl7.org/fhir/ValueSet/doc-section-codes
 * Size: 57 concepts
 */
export const DocumentSectionCodesConcepts = [
    { code: "10154-3", system: "http://loinc.org" },
    { code: "10157-6", system: "http://loinc.org" },
    { code: "10160-0", system: "http://loinc.org" },
    { code: "10164-2", system: "http://loinc.org" },
    { code: "10183-2", system: "http://loinc.org" },
    { code: "10184-0", system: "http://loinc.org" },
    { code: "10187-3", system: "http://loinc.org" },
    { code: "10210-3", system: "http://loinc.org" },
    { code: "10216-0", system: "http://loinc.org" },
    { code: "10218-6", system: "http://loinc.org" },
    { code: "10218-6", system: "http://loinc.org" },
    { code: "10223-6", system: "http://loinc.org" },
    { code: "10222-8", system: "http://loinc.org" },
    { code: "11329-0", system: "http://loinc.org" },
    { code: "11348-0", system: "http://loinc.org" },
    { code: "11369-6", system: "http://loinc.org" },
    { code: "57852-6", system: "http://loinc.org" },
    { code: "11493-4", system: "http://loinc.org" },
    { code: "11535-2", system: "http://loinc.org" },
    { code: "11537-8", system: "http://loinc.org" },
    { code: "18776-5", system: "http://loinc.org" },
    { code: "18841-7", system: "http://loinc.org" },
    { code: "29299-5", system: "http://loinc.org" },
    { code: "29545-1", system: "http://loinc.org" },
    { code: "29549-3", system: "http://loinc.org" },
    { code: "29554-3", system: "http://loinc.org" },
    { code: "29762-2", system: "http://loinc.org" },
    { code: "30954-2", system: "http://loinc.org" },
    { code: "42344-2", system: "http://loinc.org" },
    { code: "42346-7", system: "http://loinc.org" },
    { code: "42348-3", system: "http://loinc.org" },
    { code: "42349-1", system: "http://loinc.org" },
    { code: "46240-8", system: "http://loinc.org" },
    { code: "46241-6", system: "http://loinc.org" },
    { code: "46264-8", system: "http://loinc.org" },
    { code: "47420-5", system: "http://loinc.org" },
    { code: "47519-4", system: "http://loinc.org" },
    { code: "48765-2", system: "http://loinc.org" },
    { code: "48768-6", system: "http://loinc.org" },
    { code: "51848-0", system: "http://loinc.org" },
    { code: "55109-3", system: "http://loinc.org" },
    { code: "55122-6", system: "http://loinc.org" },
    { code: "59768-2", system: "http://loinc.org" },
    { code: "59769-0", system: "http://loinc.org" },
    { code: "59770-8", system: "http://loinc.org" },
    { code: "59771-6", system: "http://loinc.org" },
    { code: "59772-4", system: "http://loinc.org" },
    { code: "59773-2", system: "http://loinc.org" },
    { code: "59775-7", system: "http://loinc.org" },
    { code: "59776-5", system: "http://loinc.org" },
    { code: "61149-1", system: "http://loinc.org" },
    { code: "61150-9", system: "http://loinc.org" },
    { code: "61150-9", system: "http://loinc.org" },
    { code: "69730-0", system: "http://loinc.org" },
    { code: "8648-8", system: "http://loinc.org" },
    { code: "8653-8", system: "http://loinc.org" },
    { code: "8716-3", system: "http://loinc.org" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidDocumentSectionCodesCode(code) {
    return DocumentSectionCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getDocumentSectionCodesConcept(code) {
    return DocumentSectionCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const DocumentSectionCodesCodes = DocumentSectionCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomDocumentSectionCodesCode() {
    return DocumentSectionCodesCodes[Math.floor(Math.random() * DocumentSectionCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomDocumentSectionCodesConcept() {
    return DocumentSectionCodesConcepts[Math.floor(Math.random() * DocumentSectionCodesConcepts.length)];
}
