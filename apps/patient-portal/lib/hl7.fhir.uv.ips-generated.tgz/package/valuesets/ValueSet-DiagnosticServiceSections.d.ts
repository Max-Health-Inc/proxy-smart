/**
 * ValueSet: diagnostic-service-sections
 * URL: http://hl7.org/fhir/ValueSet/diagnostic-service-sections
 * Size: 45 concepts
 */
export declare const DiagnosticServiceSectionsConcepts: readonly [{
    readonly code: "AU";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "BG";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "BLB";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "CG";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "CH";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "CP";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "CT";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "CTH";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "CUS";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "EC";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "EN";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "GE";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "HM";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "ICU";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "IMG";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "IMM";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "LAB";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "MB";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "MCB";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "MYC";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "NMR";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "NMS";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "NRS";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "OSL";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "OT";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "OTH";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "OUS";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "PAR";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "PAT";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "PF";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "PHR";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "PHY";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "PT";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "RAD";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "RC";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "RT";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "RUS";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "RX";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "SP";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "SR";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "TX";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "URN";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "VR";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "VUS";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}, {
    readonly code: "XRC";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0074";
}];
/** String type (ValueSet too large for union type) */
export type DiagnosticServiceSectionsCode = string;
/** Type representing a concept from this ValueSet */
export type DiagnosticServiceSectionsConcept = typeof DiagnosticServiceSectionsConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidDiagnosticServiceSectionsCode(code: string): code is DiagnosticServiceSectionsCode;
/**
 * Get concept details by code
 */
export declare function getDiagnosticServiceSectionsConcept(code: string): DiagnosticServiceSectionsConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const DiagnosticServiceSectionsCodes: ("OTH" | "LAB" | "PHY" | "AU" | "BG" | "BLB" | "CG" | "CH" | "CP" | "CT" | "CTH" | "CUS" | "EC" | "EN" | "GE" | "HM" | "ICU" | "IMG" | "IMM" | "MB" | "MCB" | "MYC" | "NMR" | "NMS" | "NRS" | "OSL" | "OT" | "OUS" | "PAR" | "PAT" | "PF" | "PHR" | "PT" | "RAD" | "RC" | "RT" | "RUS" | "RX" | "SP" | "SR" | "TX" | "URN" | "VR" | "VUS" | "XRC")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomDiagnosticServiceSectionsCode(): DiagnosticServiceSectionsCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomDiagnosticServiceSectionsConcept(): DiagnosticServiceSectionsConcept;
