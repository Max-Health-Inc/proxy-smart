/**
 * ValueSet: ImagingStudyStatus
 * URL: http://hl7.org/fhir/ValueSet/imagingstudy-status
 * Size: 5 concepts
 */
export const ImagingStudyStatusConcepts = [
    { code: "registered", system: "http://hl7.org/fhir/imagingstudy-status", display: "Registered" },
    { code: "available", system: "http://hl7.org/fhir/imagingstudy-status", display: "Available" },
    { code: "cancelled", system: "http://hl7.org/fhir/imagingstudy-status", display: "Cancelled" },
    { code: "entered-in-error", system: "http://hl7.org/fhir/imagingstudy-status", display: "Entered in Error" },
    { code: "unknown", system: "http://hl7.org/fhir/imagingstudy-status", display: "Unknown" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidImagingStudyStatusCode(code) {
    return ImagingStudyStatusConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getImagingStudyStatusConcept(code) {
    return ImagingStudyStatusConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ImagingStudyStatusCodes = ImagingStudyStatusConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomImagingStudyStatusCode() {
    return ImagingStudyStatusCodes[Math.floor(Math.random() * ImagingStudyStatusCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomImagingStudyStatusConcept() {
    return ImagingStudyStatusConcepts[Math.floor(Math.random() * ImagingStudyStatusConcepts.length)];
}
