/**
 * ValueSet: ProcedureFollowUpCodes(SNOMEDCT)
 * URL: http://hl7.org/fhir/ValueSet/procedure-followup
 * Size: 10 concepts
 */
export const ProcedureFollowUpCodesSNOMEDCTConcepts = [
    { code: "18949003", system: "http://snomed.info/sct" },
    { code: "30549001", system: "http://snomed.info/sct" },
    { code: "241031001", system: "http://snomed.info/sct" },
    { code: "35963001", system: "http://snomed.info/sct" },
    { code: "225164002", system: "http://snomed.info/sct" },
    { code: "447346005", system: "http://snomed.info/sct" },
    { code: "229506003", system: "http://snomed.info/sct" },
    { code: "274441001", system: "http://snomed.info/sct" },
    { code: "394725008", system: "http://snomed.info/sct" },
    { code: "359825008", system: "http://snomed.info/sct" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidProcedureFollowUpCodesSNOMEDCTCode(code) {
    return ProcedureFollowUpCodesSNOMEDCTConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getProcedureFollowUpCodesSNOMEDCTConcept(code) {
    return ProcedureFollowUpCodesSNOMEDCTConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ProcedureFollowUpCodesSNOMEDCTCodes = ProcedureFollowUpCodesSNOMEDCTConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomProcedureFollowUpCodesSNOMEDCTCode() {
    return ProcedureFollowUpCodesSNOMEDCTCodes[Math.floor(Math.random() * ProcedureFollowUpCodesSNOMEDCTCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomProcedureFollowUpCodesSNOMEDCTConcept() {
    return ProcedureFollowUpCodesSNOMEDCTConcepts[Math.floor(Math.random() * ProcedureFollowUpCodesSNOMEDCTConcepts.length)];
}
