/**
 * ValueSet: DoseAndRateType
 * URL: http://hl7.org/fhir/ValueSet/dose-rate-type
 * Size: 2 concepts
 */
export declare const DoseAndRateTypeConcepts: readonly [{
    readonly code: "calculated";
    readonly system: "http://terminology.hl7.org/CodeSystem/dose-rate-type";
    readonly display: "Calculated";
}, {
    readonly code: "ordered";
    readonly system: "http://terminology.hl7.org/CodeSystem/dose-rate-type";
    readonly display: "Ordered";
}];
/** Union type of all valid codes in this ValueSet */
export type DoseAndRateTypeCode = "calculated" | "ordered";
/** Type representing a concept from this ValueSet */
export type DoseAndRateTypeConcept = typeof DoseAndRateTypeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidDoseAndRateTypeCode(code: string): code is DoseAndRateTypeCode;
/**
 * Get concept details by code
 */
export declare function getDoseAndRateTypeConcept(code: string): DoseAndRateTypeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const DoseAndRateTypeCodes: ("calculated" | "ordered")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomDoseAndRateTypeCode(): DoseAndRateTypeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomDoseAndRateTypeConcept(): DoseAndRateTypeConcept;
