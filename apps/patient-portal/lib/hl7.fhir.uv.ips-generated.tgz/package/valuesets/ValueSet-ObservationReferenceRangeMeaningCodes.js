/**
 * ValueSet: ObservationReferenceRangeMeaningCodes
 * URL: http://hl7.org/fhir/ValueSet/referencerange-meaning
 * Size: 2 concepts
 */
export const ObservationReferenceRangeMeaningCodesConcepts = [
    { code: "type", system: "http://terminology.hl7.org/CodeSystem/referencerange-meaning", display: "Type" },
    { code: "endocrine", system: "http://terminology.hl7.org/CodeSystem/referencerange-meaning", display: "Endocrine" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidObservationReferenceRangeMeaningCodesCode(code) {
    return ObservationReferenceRangeMeaningCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getObservationReferenceRangeMeaningCodesConcept(code) {
    return ObservationReferenceRangeMeaningCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ObservationReferenceRangeMeaningCodesCodes = ObservationReferenceRangeMeaningCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomObservationReferenceRangeMeaningCodesCode() {
    return ObservationReferenceRangeMeaningCodesCodes[Math.floor(Math.random() * ObservationReferenceRangeMeaningCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomObservationReferenceRangeMeaningCodesConcept() {
    return ObservationReferenceRangeMeaningCodesConcepts[Math.floor(Math.random() * ObservationReferenceRangeMeaningCodesConcepts.length)];
}
