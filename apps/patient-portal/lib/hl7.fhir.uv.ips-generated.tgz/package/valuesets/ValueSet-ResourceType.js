/**
 * ValueSet: ResourceType
 * URL: http://hl7.org/fhir/ValueSet/resource-types
 * Size: 100 concepts
 */
export const ResourceTypeConcepts = [
    { code: "Account", system: "http://hl7.org/fhir/resource-types", display: "Account" },
    { code: "ActivityDefinition", system: "http://hl7.org/fhir/resource-types", display: "ActivityDefinition" },
    { code: "AdverseEvent", system: "http://hl7.org/fhir/resource-types", display: "AdverseEvent" },
    { code: "AllergyIntolerance", system: "http://hl7.org/fhir/resource-types", display: "AllergyIntolerance" },
    { code: "Appointment", system: "http://hl7.org/fhir/resource-types", display: "Appointment" },
    { code: "AppointmentResponse", system: "http://hl7.org/fhir/resource-types", display: "AppointmentResponse" },
    { code: "AuditEvent", system: "http://hl7.org/fhir/resource-types", display: "AuditEvent" },
    { code: "Basic", system: "http://hl7.org/fhir/resource-types", display: "Basic" },
    { code: "Binary", system: "http://hl7.org/fhir/resource-types", display: "Binary" },
    { code: "BiologicallyDerivedProduct", system: "http://hl7.org/fhir/resource-types", display: "BiologicallyDerivedProduct" },
    { code: "BodyStructure", system: "http://hl7.org/fhir/resource-types", display: "BodyStructure" },
    { code: "Bundle", system: "http://hl7.org/fhir/resource-types", display: "Bundle" },
    { code: "CapabilityStatement", system: "http://hl7.org/fhir/resource-types", display: "CapabilityStatement" },
    { code: "CarePlan", system: "http://hl7.org/fhir/resource-types", display: "CarePlan" },
    { code: "CareTeam", system: "http://hl7.org/fhir/resource-types", display: "CareTeam" },
    { code: "CatalogEntry", system: "http://hl7.org/fhir/resource-types", display: "CatalogEntry" },
    { code: "ChargeItem", system: "http://hl7.org/fhir/resource-types", display: "ChargeItem" },
    { code: "ChargeItemDefinition", system: "http://hl7.org/fhir/resource-types", display: "ChargeItemDefinition" },
    { code: "Claim", system: "http://hl7.org/fhir/resource-types", display: "Claim" },
    { code: "ClaimResponse", system: "http://hl7.org/fhir/resource-types", display: "ClaimResponse" },
    { code: "ClinicalImpression", system: "http://hl7.org/fhir/resource-types", display: "ClinicalImpression" },
    { code: "CodeSystem", system: "http://hl7.org/fhir/resource-types", display: "CodeSystem" },
    { code: "Communication", system: "http://hl7.org/fhir/resource-types", display: "Communication" },
    { code: "CommunicationRequest", system: "http://hl7.org/fhir/resource-types", display: "CommunicationRequest" },
    { code: "CompartmentDefinition", system: "http://hl7.org/fhir/resource-types", display: "CompartmentDefinition" },
    { code: "Composition", system: "http://hl7.org/fhir/resource-types", display: "Composition" },
    { code: "ConceptMap", system: "http://hl7.org/fhir/resource-types", display: "ConceptMap" },
    { code: "Condition", system: "http://hl7.org/fhir/resource-types", display: "Condition" },
    { code: "Consent", system: "http://hl7.org/fhir/resource-types", display: "Consent" },
    { code: "Contract", system: "http://hl7.org/fhir/resource-types", display: "Contract" },
    { code: "Coverage", system: "http://hl7.org/fhir/resource-types", display: "Coverage" },
    { code: "CoverageEligibilityRequest", system: "http://hl7.org/fhir/resource-types", display: "CoverageEligibilityRequest" },
    { code: "CoverageEligibilityResponse", system: "http://hl7.org/fhir/resource-types", display: "CoverageEligibilityResponse" },
    { code: "DetectedIssue", system: "http://hl7.org/fhir/resource-types", display: "DetectedIssue" },
    { code: "Device", system: "http://hl7.org/fhir/resource-types", display: "Device" },
    { code: "DeviceDefinition", system: "http://hl7.org/fhir/resource-types", display: "DeviceDefinition" },
    { code: "DeviceMetric", system: "http://hl7.org/fhir/resource-types", display: "DeviceMetric" },
    { code: "DeviceRequest", system: "http://hl7.org/fhir/resource-types", display: "DeviceRequest" },
    { code: "DeviceUseStatement", system: "http://hl7.org/fhir/resource-types", display: "DeviceUseStatement" },
    { code: "DiagnosticReport", system: "http://hl7.org/fhir/resource-types", display: "DiagnosticReport" },
    { code: "DocumentManifest", system: "http://hl7.org/fhir/resource-types", display: "DocumentManifest" },
    { code: "DocumentReference", system: "http://hl7.org/fhir/resource-types", display: "DocumentReference" },
    { code: "DomainResource", system: "http://hl7.org/fhir/resource-types", display: "DomainResource" },
    { code: "EffectEvidenceSynthesis", system: "http://hl7.org/fhir/resource-types", display: "EffectEvidenceSynthesis" },
    { code: "Encounter", system: "http://hl7.org/fhir/resource-types", display: "Encounter" },
    { code: "Endpoint", system: "http://hl7.org/fhir/resource-types", display: "Endpoint" },
    { code: "EnrollmentRequest", system: "http://hl7.org/fhir/resource-types", display: "EnrollmentRequest" },
    { code: "EnrollmentResponse", system: "http://hl7.org/fhir/resource-types", display: "EnrollmentResponse" },
    { code: "EpisodeOfCare", system: "http://hl7.org/fhir/resource-types", display: "EpisodeOfCare" },
    { code: "EventDefinition", system: "http://hl7.org/fhir/resource-types", display: "EventDefinition" },
    { code: "Evidence", system: "http://hl7.org/fhir/resource-types", display: "Evidence" },
    { code: "EvidenceVariable", system: "http://hl7.org/fhir/resource-types", display: "EvidenceVariable" },
    { code: "ExampleScenario", system: "http://hl7.org/fhir/resource-types", display: "ExampleScenario" },
    { code: "ExplanationOfBenefit", system: "http://hl7.org/fhir/resource-types", display: "ExplanationOfBenefit" },
    { code: "FamilyMemberHistory", system: "http://hl7.org/fhir/resource-types", display: "FamilyMemberHistory" },
    { code: "Flag", system: "http://hl7.org/fhir/resource-types", display: "Flag" },
    { code: "Goal", system: "http://hl7.org/fhir/resource-types", display: "Goal" },
    { code: "GraphDefinition", system: "http://hl7.org/fhir/resource-types", display: "GraphDefinition" },
    { code: "Group", system: "http://hl7.org/fhir/resource-types", display: "Group" },
    { code: "GuidanceResponse", system: "http://hl7.org/fhir/resource-types", display: "GuidanceResponse" },
    { code: "HealthcareService", system: "http://hl7.org/fhir/resource-types", display: "HealthcareService" },
    { code: "ImagingStudy", system: "http://hl7.org/fhir/resource-types", display: "ImagingStudy" },
    { code: "Immunization", system: "http://hl7.org/fhir/resource-types", display: "Immunization" },
    { code: "ImmunizationEvaluation", system: "http://hl7.org/fhir/resource-types", display: "ImmunizationEvaluation" },
    { code: "ImmunizationRecommendation", system: "http://hl7.org/fhir/resource-types", display: "ImmunizationRecommendation" },
    { code: "ImplementationGuide", system: "http://hl7.org/fhir/resource-types", display: "ImplementationGuide" },
    { code: "InsurancePlan", system: "http://hl7.org/fhir/resource-types", display: "InsurancePlan" },
    { code: "Invoice", system: "http://hl7.org/fhir/resource-types", display: "Invoice" },
    { code: "Library", system: "http://hl7.org/fhir/resource-types", display: "Library" },
    { code: "Linkage", system: "http://hl7.org/fhir/resource-types", display: "Linkage" },
    { code: "List", system: "http://hl7.org/fhir/resource-types", display: "List" },
    { code: "Location", system: "http://hl7.org/fhir/resource-types", display: "Location" },
    { code: "Measure", system: "http://hl7.org/fhir/resource-types", display: "Measure" },
    { code: "MeasureReport", system: "http://hl7.org/fhir/resource-types", display: "MeasureReport" },
    { code: "Media", system: "http://hl7.org/fhir/resource-types", display: "Media" },
    { code: "Medication", system: "http://hl7.org/fhir/resource-types", display: "Medication" },
    { code: "MedicationAdministration", system: "http://hl7.org/fhir/resource-types", display: "MedicationAdministration" },
    { code: "MedicationDispense", system: "http://hl7.org/fhir/resource-types", display: "MedicationDispense" },
    { code: "MedicationKnowledge", system: "http://hl7.org/fhir/resource-types", display: "MedicationKnowledge" },
    { code: "MedicationRequest", system: "http://hl7.org/fhir/resource-types", display: "MedicationRequest" },
    { code: "MedicationStatement", system: "http://hl7.org/fhir/resource-types", display: "MedicationStatement" },
    { code: "MedicinalProduct", system: "http://hl7.org/fhir/resource-types", display: "MedicinalProduct" },
    { code: "MedicinalProductAuthorization", system: "http://hl7.org/fhir/resource-types", display: "MedicinalProductAuthorization" },
    { code: "MedicinalProductContraindication", system: "http://hl7.org/fhir/resource-types", display: "MedicinalProductContraindication" },
    { code: "MedicinalProductIndication", system: "http://hl7.org/fhir/resource-types", display: "MedicinalProductIndication" },
    { code: "MedicinalProductIngredient", system: "http://hl7.org/fhir/resource-types", display: "MedicinalProductIngredient" },
    { code: "MedicinalProductInteraction", system: "http://hl7.org/fhir/resource-types", display: "MedicinalProductInteraction" },
    { code: "MedicinalProductManufactured", system: "http://hl7.org/fhir/resource-types", display: "MedicinalProductManufactured" },
    { code: "MedicinalProductPackaged", system: "http://hl7.org/fhir/resource-types", display: "MedicinalProductPackaged" },
    { code: "MedicinalProductPharmaceutical", system: "http://hl7.org/fhir/resource-types", display: "MedicinalProductPharmaceutical" },
    { code: "MedicinalProductUndesirableEffect", system: "http://hl7.org/fhir/resource-types", display: "MedicinalProductUndesirableEffect" },
    { code: "MessageDefinition", system: "http://hl7.org/fhir/resource-types", display: "MessageDefinition" },
    { code: "MessageHeader", system: "http://hl7.org/fhir/resource-types", display: "MessageHeader" },
    { code: "MolecularSequence", system: "http://hl7.org/fhir/resource-types", display: "MolecularSequence" },
    { code: "NamingSystem", system: "http://hl7.org/fhir/resource-types", display: "NamingSystem" },
    { code: "NutritionOrder", system: "http://hl7.org/fhir/resource-types", display: "NutritionOrder" },
    { code: "Observation", system: "http://hl7.org/fhir/resource-types", display: "Observation" },
    { code: "ObservationDefinition", system: "http://hl7.org/fhir/resource-types", display: "ObservationDefinition" },
    { code: "OperationDefinition", system: "http://hl7.org/fhir/resource-types", display: "OperationDefinition" },
    { code: "OperationOutcome", system: "http://hl7.org/fhir/resource-types", display: "OperationOutcome" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidResourceTypeCode(code) {
    return ResourceTypeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getResourceTypeConcept(code) {
    return ResourceTypeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ResourceTypeCodes = ResourceTypeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomResourceTypeCode() {
    return ResourceTypeCodes[Math.floor(Math.random() * ResourceTypeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomResourceTypeConcept() {
    return ResourceTypeConcepts[Math.floor(Math.random() * ResourceTypeConcepts.length)];
}
