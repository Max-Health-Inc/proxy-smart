/**
 * ValueSet: ProblemSeverityUvIps
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/condition-severity-uv-ips
 * Size: 3 concepts
 */
export declare const ProblemSeverityUvIpsConcepts: readonly [{
    readonly code: "LA6752-5";
    readonly system: "http://loinc.org";
    readonly display: "Mild";
}, {
    readonly code: "LA6751-7";
    readonly system: "http://loinc.org";
    readonly display: "Moderate";
}, {
    readonly code: "LA6750-9";
    readonly system: "http://loinc.org";
    readonly display: "Severe";
}];
/** Union type of all valid codes in this ValueSet */
export type ProblemSeverityUvIpsCode = "LA6752-5" | "LA6751-7" | "LA6750-9";
/** Type representing a concept from this ValueSet */
export type ProblemSeverityUvIpsConcept = typeof ProblemSeverityUvIpsConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidProblemSeverityUvIpsCode(code: string): code is ProblemSeverityUvIpsCode;
/**
 * Get concept details by code
 */
export declare function getProblemSeverityUvIpsConcept(code: string): ProblemSeverityUvIpsConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ProblemSeverityUvIpsCodes: ("LA6752-5" | "LA6751-7" | "LA6750-9")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomProblemSeverityUvIpsCode(): ProblemSeverityUvIpsCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomProblemSeverityUvIpsConcept(): ProblemSeverityUvIpsConcept;
