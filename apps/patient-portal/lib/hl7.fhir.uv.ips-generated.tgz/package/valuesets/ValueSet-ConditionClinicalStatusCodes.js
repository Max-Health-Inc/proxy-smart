/**
 * ValueSet: ConditionClinicalStatusCodes
 * URL: http://hl7.org/fhir/ValueSet/condition-clinical
 * Size: 2 concepts
 */
export const ConditionClinicalStatusCodesConcepts = [
    { code: "active", system: "http://terminology.hl7.org/CodeSystem/condition-clinical", display: "Active" },
    { code: "inactive", system: "http://terminology.hl7.org/CodeSystem/condition-clinical", display: "Inactive" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidConditionClinicalStatusCodesCode(code) {
    return ConditionClinicalStatusCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getConditionClinicalStatusCodesConcept(code) {
    return ConditionClinicalStatusCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ConditionClinicalStatusCodesCodes = ConditionClinicalStatusCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomConditionClinicalStatusCodesCode() {
    return ConditionClinicalStatusCodesCodes[Math.floor(Math.random() * ConditionClinicalStatusCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomConditionClinicalStatusCodesConcept() {
    return ConditionClinicalStatusCodesConcepts[Math.floor(Math.random() * ConditionClinicalStatusCodesConcepts.length)];
}
