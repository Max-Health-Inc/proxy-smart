/**
 * ValueSet: ResultsSpecimenCollectionMethodUvIps
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/results-specimen-collection-method-uv-ips
 * Size: 10 concepts
 */
export const ResultsSpecimenCollectionMethodUvIpsConcepts = [
    { code: "129316008", system: "http://snomed.info/sct", display: "Aspiration - action" },
    { code: "129314006", system: "http://snomed.info/sct", display: "Biopsy - action" },
    { code: "129300006", system: "http://snomed.info/sct", display: "Puncture - action" },
    { code: "129304002", system: "http://snomed.info/sct", display: "Excision - action" },
    { code: "129323009", system: "http://snomed.info/sct", display: "Scraping - action" },
    { code: "73416001", system: "http://snomed.info/sct", display: "Urine specimen collection, clean catch" },
    { code: "225113003", system: "http://snomed.info/sct", display: "Timed urine collection" },
    { code: "70777001", system: "http://snomed.info/sct", display: "Urine specimen collection, catheterized" },
    { code: "386089008", system: "http://snomed.info/sct", display: "Collection of coughed sputum" },
    { code: "278450005", system: "http://snomed.info/sct", display: "Finger-prick sampling" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidResultsSpecimenCollectionMethodUvIpsCode(code) {
    return ResultsSpecimenCollectionMethodUvIpsConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getResultsSpecimenCollectionMethodUvIpsConcept(code) {
    return ResultsSpecimenCollectionMethodUvIpsConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ResultsSpecimenCollectionMethodUvIpsCodes = ResultsSpecimenCollectionMethodUvIpsConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomResultsSpecimenCollectionMethodUvIpsCode() {
    return ResultsSpecimenCollectionMethodUvIpsCodes[Math.floor(Math.random() * ResultsSpecimenCollectionMethodUvIpsCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomResultsSpecimenCollectionMethodUvIpsConcept() {
    return ResultsSpecimenCollectionMethodUvIpsConcepts[Math.floor(Math.random() * ResultsSpecimenCollectionMethodUvIpsConcepts.length)];
}
