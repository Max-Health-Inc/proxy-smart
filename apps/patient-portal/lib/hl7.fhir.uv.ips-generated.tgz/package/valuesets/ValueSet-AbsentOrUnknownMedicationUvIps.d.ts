/**
 * ValueSet: AbsentOrUnknownMedicationUvIps
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/absent-or-unknown-medications-uv-ips
 * Size: 2 concepts
 */
export declare const AbsentOrUnknownMedicationUvIpsConcepts: readonly [{
    readonly code: "no-medication-info";
    readonly system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips";
    readonly display: "No information about medications";
}, {
    readonly code: "no-known-medications";
    readonly system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips";
    readonly display: "No known medications";
}];
/** Union type of all valid codes in this ValueSet */
export type AbsentOrUnknownMedicationUvIpsCode = "no-medication-info" | "no-known-medications";
/** Type representing a concept from this ValueSet */
export type AbsentOrUnknownMedicationUvIpsConcept = typeof AbsentOrUnknownMedicationUvIpsConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidAbsentOrUnknownMedicationUvIpsCode(code: string): code is AbsentOrUnknownMedicationUvIpsCode;
/**
 * Get concept details by code
 */
export declare function getAbsentOrUnknownMedicationUvIpsConcept(code: string): AbsentOrUnknownMedicationUvIpsConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const AbsentOrUnknownMedicationUvIpsCodes: ("no-medication-info" | "no-known-medications")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomAbsentOrUnknownMedicationUvIpsCode(): AbsentOrUnknownMedicationUvIpsCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomAbsentOrUnknownMedicationUvIpsConcept(): AbsentOrUnknownMedicationUvIpsConcept;
