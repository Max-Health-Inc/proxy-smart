/**
 * ValueSet: ResultsRadiologyTextualObservationsSnomedDicomLoincUvIps
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/results-radiology-txtobs-snomed-dicom-loinc-uv-ips
 * Size: 11 concepts
 */
export declare const ResultsRadiologyTextualObservationsSnomedDicomLoincUvIpsConcepts: readonly [{
    readonly code: "121065";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
    readonly display: "Procedure Description";
}, {
    readonly code: "121069";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
    readonly display: "Previous Finding";
}, {
    readonly code: "121071";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
    readonly display: "Finding";
}, {
    readonly code: "121073";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
    readonly display: "Impression";
}, {
    readonly code: "121075";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
    readonly display: "Recommendation";
}, {
    readonly code: "121077";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
    readonly display: "Conclusion";
}, {
    readonly code: "121110";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
    readonly display: "Patient Presentation";
}, {
    readonly code: "121111";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
    readonly display: "Summary";
}, {
    readonly code: "11329-0";
    readonly system: "http://loinc.org";
    readonly display: "History";
}, {
    readonly code: "55115-0";
    readonly system: "http://loinc.org";
    readonly display: "Request";
}, {
    readonly code: "116224001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Complication of Procedure";
}];
/** Union type of all valid codes in this ValueSet */
export type ResultsRadiologyTextualObservationsSnomedDicomLoincUvIpsCode = "121065" | "121069" | "121071" | "121073" | "121075" | "121077" | "121110" | "121111" | "11329-0" | "55115-0" | "116224001";
/** Type representing a concept from this ValueSet */
export type ResultsRadiologyTextualObservationsSnomedDicomLoincUvIpsConcept = typeof ResultsRadiologyTextualObservationsSnomedDicomLoincUvIpsConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidResultsRadiologyTextualObservationsSnomedDicomLoincUvIpsCode(code: string): code is ResultsRadiologyTextualObservationsSnomedDicomLoincUvIpsCode;
/**
 * Get concept details by code
 */
export declare function getResultsRadiologyTextualObservationsSnomedDicomLoincUvIpsConcept(code: string): ResultsRadiologyTextualObservationsSnomedDicomLoincUvIpsConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ResultsRadiologyTextualObservationsSnomedDicomLoincUvIpsCodes: ("116224001" | "11329-0" | "121065" | "121069" | "121071" | "121073" | "121075" | "121077" | "121110" | "121111" | "55115-0")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomResultsRadiologyTextualObservationsSnomedDicomLoincUvIpsCode(): ResultsRadiologyTextualObservationsSnomedDicomLoincUvIpsCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomResultsRadiologyTextualObservationsSnomedDicomLoincUvIpsConcept(): ResultsRadiologyTextualObservationsSnomedDicomLoincUvIpsConcept;
