/**
 * ValueSet: ResultsPresenceAbsenceSnomedCtIpsFreeSet
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/results-presence-absence-snomed-ct-ips-free-set
 * Size: Infinity concepts
 */
export declare const ResultsPresenceAbsenceSnomedCtIpsFreeSetConcepts: readonly [{
    readonly code: "441614007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Present one plus out of three plus";
}, {
    readonly code: "441521003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Present three plus out of three plus";
}, {
    readonly code: "441517005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Present two plus out of three plus";
}, {
    readonly code: "260350009";
    readonly system: "http://snomed.info/sct";
    readonly display: "++++";
}, {
    readonly code: "260349009";
    readonly system: "http://snomed.info/sct";
    readonly display: "+++";
}, {
    readonly code: "260348001";
    readonly system: "http://snomed.info/sct";
    readonly display: "++";
}, {
    readonly code: "260347006";
    readonly system: "http://snomed.info/sct";
    readonly display: "+";
}, {
    readonly code: "52101004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Present";
}, {
    readonly code: "2667000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Absent";
}];
/** String type (ValueSet too large for union type) */
export type ResultsPresenceAbsenceSnomedCtIpsFreeSetCode = string;
/** Type representing a concept from this ValueSet */
export type ResultsPresenceAbsenceSnomedCtIpsFreeSetConcept = typeof ResultsPresenceAbsenceSnomedCtIpsFreeSetConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidResultsPresenceAbsenceSnomedCtIpsFreeSetCode(code: string): code is ResultsPresenceAbsenceSnomedCtIpsFreeSetCode;
/**
 * Get concept details by code
 */
export declare function getResultsPresenceAbsenceSnomedCtIpsFreeSetConcept(code: string): ResultsPresenceAbsenceSnomedCtIpsFreeSetConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ResultsPresenceAbsenceSnomedCtIpsFreeSetCodes: ("441614007" | "441521003" | "441517005" | "260350009" | "260349009" | "260348001" | "260347006" | "52101004" | "2667000")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomResultsPresenceAbsenceSnomedCtIpsFreeSetCode(): ResultsPresenceAbsenceSnomedCtIpsFreeSetCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomResultsPresenceAbsenceSnomedCtIpsFreeSetConcept(): ResultsPresenceAbsenceSnomedCtIpsFreeSetConcept;
