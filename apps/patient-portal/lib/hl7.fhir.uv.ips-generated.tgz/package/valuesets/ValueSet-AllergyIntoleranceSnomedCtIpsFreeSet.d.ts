/**
 * ValueSet: AllergyIntoleranceSnomedCtIpsFreeSet
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/allergy-intolerance-snomed-ct-ips-free-set
 * Size: Infinity concepts
 */
interface AllergyIntoleranceSnomedCtIpsFreeSetConceptDef {
    readonly code: string;
    readonly system: string;
    readonly display?: string;
}
export declare const AllergyIntoleranceSnomedCtIpsFreeSetConcepts: readonly AllergyIntoleranceSnomedCtIpsFreeSetConceptDef[];
/** String type (ValueSet too large for union type) */
export type AllergyIntoleranceSnomedCtIpsFreeSetCode = string;
/** Type representing a concept from this ValueSet */
export type AllergyIntoleranceSnomedCtIpsFreeSetConcept = AllergyIntoleranceSnomedCtIpsFreeSetConceptDef;
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidAllergyIntoleranceSnomedCtIpsFreeSetCode(code: string): code is AllergyIntoleranceSnomedCtIpsFreeSetCode;
/**
 * Get concept details by code
 */
export declare function getAllergyIntoleranceSnomedCtIpsFreeSetConcept(code: string): AllergyIntoleranceSnomedCtIpsFreeSetConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const AllergyIntoleranceSnomedCtIpsFreeSetCodes: string[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomAllergyIntoleranceSnomedCtIpsFreeSetCode(): AllergyIntoleranceSnomedCtIpsFreeSetCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomAllergyIntoleranceSnomedCtIpsFreeSetConcept(): AllergyIntoleranceSnomedCtIpsFreeSetConcept;
export {};
