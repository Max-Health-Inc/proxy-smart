/**
 * ValueSet: Medication usage category codes
 * URL: http://hl7.org/fhir/ValueSet/medication-statement-category
 * Size: 4 concepts
 */
export declare const MedicationUsageCategoryCodesConcepts: readonly [{
    readonly code: "inpatient";
    readonly system: "http://terminology.hl7.org/CodeSystem/medication-statement-category";
    readonly display: "Inpatient";
}, {
    readonly code: "outpatient";
    readonly system: "http://terminology.hl7.org/CodeSystem/medication-statement-category";
    readonly display: "Outpatient";
}, {
    readonly code: "community";
    readonly system: "http://terminology.hl7.org/CodeSystem/medication-statement-category";
    readonly display: "Community";
}, {
    readonly code: "patientspecified";
    readonly system: "http://terminology.hl7.org/CodeSystem/medication-statement-category";
    readonly display: "Patient Specified";
}];
/** Union type of all valid codes in this ValueSet */
export type MedicationUsageCategoryCodesCode = "inpatient" | "outpatient" | "community" | "patientspecified";
/** Type representing a concept from this ValueSet */
export type MedicationUsageCategoryCodesConcept = typeof MedicationUsageCategoryCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidMedicationUsageCategoryCodesCode(code: string): code is MedicationUsageCategoryCodesCode;
/**
 * Get concept details by code
 */
export declare function getMedicationUsageCategoryCodesConcept(code: string): MedicationUsageCategoryCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const MedicationUsageCategoryCodesCodes: ("inpatient" | "outpatient" | "community" | "patientspecified")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomMedicationUsageCategoryCodesCode(): MedicationUsageCategoryCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomMedicationUsageCategoryCodesConcept(): MedicationUsageCategoryCodesConcept;
