/**
 * ValueSet: DocumentClassValueSet
 * URL: http://hl7.org/fhir/ValueSet/document-classcodes
 * Size: 45 concepts
 */
export const DocumentClassValueSetConcepts = [
    { code: "11369-6", system: "http://loinc.org", display: "History of Immunization" },
    { code: "11485-0", system: "http://loinc.org", display: "Anesthesia records" },
    { code: "11486-8", system: "http://loinc.org", display: "Chemotherapy records" },
    { code: "11488-4", system: "http://loinc.org", display: "Consult Note" },
    { code: "11506-3", system: "http://loinc.org", display: "Provider-unspecified progress note" },
    { code: "11543-6", system: "http://loinc.org", display: "Nursery records" },
    { code: "15508-5", system: "http://loinc.org", display: "Labor and delivery records" },
    { code: "18726-0", system: "http://loinc.org", display: "Radiology studies (set)" },
    { code: "18761-7", system: "http://loinc.org", display: "Provider-unspecified transfer summary" },
    { code: "18842-5", system: "http://loinc.org", display: "Discharge summary" },
    { code: "26436-6", system: "http://loinc.org", display: "Laboratory Studies (set)" },
    { code: "26441-6", system: "http://loinc.org", display: "Cardiology studies (set)" },
    { code: "26442-4", system: "http://loinc.org", display: "Obstetrical studies (set)" },
    { code: "27895-2", system: "http://loinc.org", display: "Gastroenterology endoscopy studies (set)" },
    { code: "27896-0", system: "http://loinc.org", display: "Pulmonary studies (set)" },
    { code: "27897-8", system: "http://loinc.org", display: "Neuromuscular electrophysiology studies (set)" },
    { code: "27898-6", system: "http://loinc.org", display: "Pathology studies (set)" },
    { code: "28570-0", system: "http://loinc.org", display: "Provider-unspecified procedure note" },
    { code: "28619-5", system: "http://loinc.org", display: "Ophthalmology/optometry studies (set)" },
    { code: "28634-4", system: "http://loinc.org", display: "Miscellaneous studies (set)" },
    { code: "29749-9", system: "http://loinc.org", display: "Dialysis records" },
    { code: "29750-7", system: "http://loinc.org", display: "Neonatal intensive care records" },
    { code: "29751-5", system: "http://loinc.org", display: "Critical care records" },
    { code: "29752-3", system: "http://loinc.org", display: "Perioperative records" },
    { code: "34109-9", system: "http://loinc.org", display: "Evaluation and management note" },
    { code: "34117-2", system: "http://loinc.org", display: "Provider-unspecified, History and physical note" },
    { code: "34121-4", system: "http://loinc.org", display: "Interventional procedure note" },
    { code: "34122-2", system: "http://loinc.org", display: "Pathology procedure note" },
    { code: "34133-9", system: "http://loinc.org", display: "Summarization of episode note" },
    { code: "34140-4", system: "http://loinc.org", display: "Transfer of care referral note" },
    { code: "34748-4", system: "http://loinc.org", display: "Telephone encounter note" },
    { code: "34775-7", system: "http://loinc.org", display: "General surgery Pre-operative evaluation and management note" },
    { code: "47039-3", system: "http://loinc.org", display: "Inpatient Admission history and physical note" },
    { code: "47042-7", system: "http://loinc.org", display: "Counseling note" },
    { code: "47045-0", system: "http://loinc.org", display: "Study report Document" },
    { code: "47046-8", system: "http://loinc.org", display: "Summary of death" },
    { code: "47049-2", system: "http://loinc.org", display: "Non-patient Communication" },
    { code: "57017-6", system: "http://loinc.org", display: "Privacy Policy Organization Document" },
    { code: "57016-8", system: "http://loinc.org", display: "Privacy Policy Acknowledgment Document" },
    { code: "56445-0", system: "http://loinc.org", display: "Medication Summary Document" },
    { code: "53576-5", system: "http://loinc.org", display: "Personal health monitoring report Document" },
    { code: "56447-6", system: "http://loinc.org", display: "Plan of care note" },
    { code: "18748-4", system: "http://loinc.org", display: "Diagnostic imaging study" },
    { code: "11504-8", system: "http://loinc.org", display: "Surgical operation note " },
    { code: "57133-1", system: "http://loinc.org", display: "Referral note" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidDocumentClassValueSetCode(code) {
    return DocumentClassValueSetConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getDocumentClassValueSetConcept(code) {
    return DocumentClassValueSetConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const DocumentClassValueSetCodes = DocumentClassValueSetConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomDocumentClassValueSetCode() {
    return DocumentClassValueSetCodes[Math.floor(Math.random() * DocumentClassValueSetCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomDocumentClassValueSetConcept() {
    return DocumentClassValueSetConcepts[Math.floor(Math.random() * DocumentClassValueSetConcepts.length)];
}
