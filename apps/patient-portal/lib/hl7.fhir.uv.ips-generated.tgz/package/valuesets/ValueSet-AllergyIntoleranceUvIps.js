/**
 * ValueSet: AllergyIntoleranceUvIps
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/allergy-intolerance-uv-ips
 * Size: 5 concepts
 */
export const AllergyIntoleranceUvIpsConcepts = [
    { code: "no-allergy-info", system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips" },
    { code: "no-known-allergies", system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips" },
    { code: "no-known-medication-allergies", system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips" },
    { code: "no-known-environmental-allergies", system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips" },
    { code: "no-known-food-allergies", system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidAllergyIntoleranceUvIpsCode(code) {
    return AllergyIntoleranceUvIpsConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getAllergyIntoleranceUvIpsConcept(code) {
    return AllergyIntoleranceUvIpsConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const AllergyIntoleranceUvIpsCodes = AllergyIntoleranceUvIpsConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomAllergyIntoleranceUvIpsCode() {
    return AllergyIntoleranceUvIpsCodes[Math.floor(Math.random() * AllergyIntoleranceUvIpsCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomAllergyIntoleranceUvIpsConcept() {
    return AllergyIntoleranceUvIpsConcepts[Math.floor(Math.random() * AllergyIntoleranceUvIpsConcepts.length)];
}
