/**
 * ValueSet: CommonLanguages
 * URL: http://hl7.org/fhir/ValueSet/languages
 * Size: 56 concepts
 */
export const CommonLanguagesConcepts = [
    { code: "ar", system: "urn:ietf:bcp:47", display: "Arabic" },
    { code: "bn", system: "urn:ietf:bcp:47", display: "Bengali" },
    { code: "cs", system: "urn:ietf:bcp:47", display: "Czech" },
    { code: "da", system: "urn:ietf:bcp:47", display: "Danish" },
    { code: "de", system: "urn:ietf:bcp:47", display: "German" },
    { code: "de-AT", system: "urn:ietf:bcp:47", display: "German (Austria)" },
    { code: "de-CH", system: "urn:ietf:bcp:47", display: "German (Switzerland)" },
    { code: "de-DE", system: "urn:ietf:bcp:47", display: "German (Germany)" },
    { code: "el", system: "urn:ietf:bcp:47", display: "Greek" },
    { code: "en", system: "urn:ietf:bcp:47", display: "English" },
    { code: "en-AU", system: "urn:ietf:bcp:47", display: "English (Australia)" },
    { code: "en-CA", system: "urn:ietf:bcp:47", display: "English (Canada)" },
    { code: "en-GB", system: "urn:ietf:bcp:47", display: "English (Great Britain)" },
    { code: "en-IN", system: "urn:ietf:bcp:47", display: "English (India)" },
    { code: "en-NZ", system: "urn:ietf:bcp:47", display: "English (New Zeland)" },
    { code: "en-SG", system: "urn:ietf:bcp:47", display: "English (Singapore)" },
    { code: "en-US", system: "urn:ietf:bcp:47", display: "English (United States)" },
    { code: "es", system: "urn:ietf:bcp:47", display: "Spanish" },
    { code: "es-AR", system: "urn:ietf:bcp:47", display: "Spanish (Argentina)" },
    { code: "es-ES", system: "urn:ietf:bcp:47", display: "Spanish (Spain)" },
    { code: "es-UY", system: "urn:ietf:bcp:47", display: "Spanish (Uruguay)" },
    { code: "fi", system: "urn:ietf:bcp:47", display: "Finnish" },
    { code: "fr", system: "urn:ietf:bcp:47", display: "French" },
    { code: "fr-BE", system: "urn:ietf:bcp:47", display: "French (Belgium)" },
    { code: "fr-CH", system: "urn:ietf:bcp:47", display: "French (Switzerland)" },
    { code: "fr-FR", system: "urn:ietf:bcp:47", display: "French (France)" },
    { code: "fy", system: "urn:ietf:bcp:47", display: "Frysian" },
    { code: "fy-NL", system: "urn:ietf:bcp:47", display: "Frysian (Netherlands)" },
    { code: "hi", system: "urn:ietf:bcp:47", display: "Hindi" },
    { code: "hr", system: "urn:ietf:bcp:47", display: "Croatian" },
    { code: "it", system: "urn:ietf:bcp:47", display: "Italian" },
    { code: "it-CH", system: "urn:ietf:bcp:47", display: "Italian (Switzerland)" },
    { code: "it-IT", system: "urn:ietf:bcp:47", display: "Italian (Italy)" },
    { code: "ja", system: "urn:ietf:bcp:47", display: "Japanese" },
    { code: "ko", system: "urn:ietf:bcp:47", display: "Korean" },
    { code: "nl", system: "urn:ietf:bcp:47", display: "Dutch" },
    { code: "nl-BE", system: "urn:ietf:bcp:47", display: "Dutch (Belgium)" },
    { code: "nl-NL", system: "urn:ietf:bcp:47", display: "Dutch (Netherlands)" },
    { code: "no", system: "urn:ietf:bcp:47", display: "Norwegian" },
    { code: "no-NO", system: "urn:ietf:bcp:47", display: "Norwegian (Norway)" },
    { code: "pa", system: "urn:ietf:bcp:47", display: "Punjabi" },
    { code: "pl", system: "urn:ietf:bcp:47", display: "Polish" },
    { code: "pt", system: "urn:ietf:bcp:47", display: "Portuguese" },
    { code: "pt-BR", system: "urn:ietf:bcp:47", display: "Portuguese (Brazil)" },
    { code: "ru", system: "urn:ietf:bcp:47", display: "Russian" },
    { code: "ru-RU", system: "urn:ietf:bcp:47", display: "Russian (Russia)" },
    { code: "sr", system: "urn:ietf:bcp:47", display: "Serbian" },
    { code: "sr-RS", system: "urn:ietf:bcp:47", display: "Serbian (Serbia)" },
    { code: "sv", system: "urn:ietf:bcp:47", display: "Swedish" },
    { code: "sv-SE", system: "urn:ietf:bcp:47", display: "Swedish (Sweden)" },
    { code: "te", system: "urn:ietf:bcp:47", display: "Telegu" },
    { code: "zh", system: "urn:ietf:bcp:47", display: "Chinese" },
    { code: "zh-CN", system: "urn:ietf:bcp:47", display: "Chinese (China)" },
    { code: "zh-HK", system: "urn:ietf:bcp:47", display: "Chinese (Hong Kong)" },
    { code: "zh-SG", system: "urn:ietf:bcp:47", display: "Chinese (Singapore)" },
    { code: "zh-TW", system: "urn:ietf:bcp:47", display: "Chinese (Taiwan)" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidCommonLanguagesCode(code) {
    return CommonLanguagesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getCommonLanguagesConcept(code) {
    return CommonLanguagesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const CommonLanguagesCodes = CommonLanguagesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomCommonLanguagesCode() {
    return CommonLanguagesCodes[Math.floor(Math.random() * CommonLanguagesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomCommonLanguagesConcept() {
    return CommonLanguagesConcepts[Math.floor(Math.random() * CommonLanguagesConcepts.length)];
}
