/**
 * ValueSet: Condition/DiagnosisSeverity
 * URL: http://hl7.org/fhir/ValueSet/condition-severity
 * Size: 3 concepts
 */
export declare const ConditionDiagnosisSeverityConcepts: readonly [{
    readonly code: "24484000";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "6736007";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "255604002";
    readonly system: "http://snomed.info/sct";
}];
/** Union type of all valid codes in this ValueSet */
export type ConditionDiagnosisSeverityCode = "24484000" | "6736007" | "255604002";
/** Type representing a concept from this ValueSet */
export type ConditionDiagnosisSeverityConcept = typeof ConditionDiagnosisSeverityConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidConditionDiagnosisSeverityCode(code: string): code is ConditionDiagnosisSeverityCode;
/**
 * Get concept details by code
 */
export declare function getConditionDiagnosisSeverityConcept(code: string): ConditionDiagnosisSeverityConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ConditionDiagnosisSeverityCodes: ("24484000" | "6736007" | "255604002")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomConditionDiagnosisSeverityCode(): ConditionDiagnosisSeverityCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomConditionDiagnosisSeverityConcept(): ConditionDiagnosisSeverityConcept;
