/**
 * ValueSet: ProcedureOutcomeCodes(SNOMEDCT)
 * URL: http://hl7.org/fhir/ValueSet/procedure-outcome
 * Size: 3 concepts
 */
export declare const ProcedureOutcomeCodesSNOMEDCTConcepts: readonly [{
    readonly code: "385669000";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "385671000";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "385670004";
    readonly system: "http://snomed.info/sct";
}];
/** Union type of all valid codes in this ValueSet */
export type ProcedureOutcomeCodesSNOMEDCTCode = "385669000" | "385671000" | "385670004";
/** Type representing a concept from this ValueSet */
export type ProcedureOutcomeCodesSNOMEDCTConcept = typeof ProcedureOutcomeCodesSNOMEDCTConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidProcedureOutcomeCodesSNOMEDCTCode(code: string): code is ProcedureOutcomeCodesSNOMEDCTCode;
/**
 * Get concept details by code
 */
export declare function getProcedureOutcomeCodesSNOMEDCTConcept(code: string): ProcedureOutcomeCodesSNOMEDCTConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ProcedureOutcomeCodesSNOMEDCTCodes: ("385669000" | "385671000" | "385670004")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomProcedureOutcomeCodesSNOMEDCTCode(): ProcedureOutcomeCodesSNOMEDCTCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomProcedureOutcomeCodesSNOMEDCTConcept(): ProcedureOutcomeCodesSNOMEDCTConcept;
