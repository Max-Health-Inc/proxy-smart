/**
 * ValueSet: CurrentSmokingStatusUvIps
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/current-smoking-status-uv-ips
 * Size: 8 concepts
 */
export declare const CurrentSmokingStatusUvIpsConcepts: readonly [{
    readonly code: "LA18976-3";
    readonly system: "http://loinc.org";
    readonly display: "Current every day smoker";
}, {
    readonly code: "LA18977-1";
    readonly system: "http://loinc.org";
    readonly display: "Current some day smoker";
}, {
    readonly code: "LA15920-4";
    readonly system: "http://loinc.org";
    readonly display: "Former smoker";
}, {
    readonly code: "LA18978-9";
    readonly system: "http://loinc.org";
    readonly display: "Never smoker";
}, {
    readonly code: "LA18979-7";
    readonly system: "http://loinc.org";
    readonly display: "Smoker, current status unknown";
}, {
    readonly code: "LA18980-5";
    readonly system: "http://loinc.org";
    readonly display: "Unknown if ever smoked";
}, {
    readonly code: "LA18981-3";
    readonly system: "http://loinc.org";
    readonly display: "Heavy tobacco smoker";
}, {
    readonly code: "LA18982-1";
    readonly system: "http://loinc.org";
    readonly display: "Light tobacco smoker";
}];
/** Union type of all valid codes in this ValueSet */
export type CurrentSmokingStatusUvIpsCode = "LA18976-3" | "LA18977-1" | "LA15920-4" | "LA18978-9" | "LA18979-7" | "LA18980-5" | "LA18981-3" | "LA18982-1";
/** Type representing a concept from this ValueSet */
export type CurrentSmokingStatusUvIpsConcept = typeof CurrentSmokingStatusUvIpsConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidCurrentSmokingStatusUvIpsCode(code: string): code is CurrentSmokingStatusUvIpsCode;
/**
 * Get concept details by code
 */
export declare function getCurrentSmokingStatusUvIpsConcept(code: string): CurrentSmokingStatusUvIpsConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const CurrentSmokingStatusUvIpsCodes: ("LA18976-3" | "LA18977-1" | "LA15920-4" | "LA18978-9" | "LA18979-7" | "LA18980-5" | "LA18981-3" | "LA18982-1")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomCurrentSmokingStatusUvIpsCode(): CurrentSmokingStatusUvIpsCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomCurrentSmokingStatusUvIpsConcept(): CurrentSmokingStatusUvIpsConcept;
