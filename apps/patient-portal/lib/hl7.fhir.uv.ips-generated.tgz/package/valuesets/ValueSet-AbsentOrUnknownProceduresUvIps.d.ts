/**
 * ValueSet: AbsentOrUnknownProceduresUvIps
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/absent-or-unknown-procedures-uv-ips
 * Size: 2 concepts
 */
export declare const AbsentOrUnknownProceduresUvIpsConcepts: readonly [{
    readonly code: "no-procedure-info";
    readonly system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips";
    readonly display: "No information about past history of procedures";
}, {
    readonly code: "no-known-procedures";
    readonly system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips";
    readonly display: "No known procedures";
}];
/** Union type of all valid codes in this ValueSet */
export type AbsentOrUnknownProceduresUvIpsCode = "no-procedure-info" | "no-known-procedures";
/** Type representing a concept from this ValueSet */
export type AbsentOrUnknownProceduresUvIpsConcept = typeof AbsentOrUnknownProceduresUvIpsConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidAbsentOrUnknownProceduresUvIpsCode(code: string): code is AbsentOrUnknownProceduresUvIpsCode;
/**
 * Get concept details by code
 */
export declare function getAbsentOrUnknownProceduresUvIpsConcept(code: string): AbsentOrUnknownProceduresUvIpsConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const AbsentOrUnknownProceduresUvIpsCodes: ("no-procedure-info" | "no-known-procedures")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomAbsentOrUnknownProceduresUvIpsCode(): AbsentOrUnknownProceduresUvIpsCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomAbsentOrUnknownProceduresUvIpsConcept(): AbsentOrUnknownProceduresUvIpsConcept;
