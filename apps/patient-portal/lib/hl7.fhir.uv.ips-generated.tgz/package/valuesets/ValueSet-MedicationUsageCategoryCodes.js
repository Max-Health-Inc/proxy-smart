/**
 * ValueSet: Medication usage category codes
 * URL: http://hl7.org/fhir/ValueSet/medication-statement-category
 * Size: 4 concepts
 */
export const MedicationUsageCategoryCodesConcepts = [
    { code: "inpatient", system: "http://terminology.hl7.org/CodeSystem/medication-statement-category", display: "Inpatient" },
    { code: "outpatient", system: "http://terminology.hl7.org/CodeSystem/medication-statement-category", display: "Outpatient" },
    { code: "community", system: "http://terminology.hl7.org/CodeSystem/medication-statement-category", display: "Community" },
    { code: "patientspecified", system: "http://terminology.hl7.org/CodeSystem/medication-statement-category", display: "Patient Specified" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidMedicationUsageCategoryCodesCode(code) {
    return MedicationUsageCategoryCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getMedicationUsageCategoryCodesConcept(code) {
    return MedicationUsageCategoryCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const MedicationUsageCategoryCodesCodes = MedicationUsageCategoryCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomMedicationUsageCategoryCodesCode() {
    return MedicationUsageCategoryCodesCodes[Math.floor(Math.random() * MedicationUsageCategoryCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomMedicationUsageCategoryCodesConcept() {
    return MedicationUsageCategoryCodesConcepts[Math.floor(Math.random() * MedicationUsageCategoryCodesConcepts.length)];
}
