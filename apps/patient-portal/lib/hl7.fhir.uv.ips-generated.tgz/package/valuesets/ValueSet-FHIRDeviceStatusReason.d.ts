/**
 * ValueSet: FHIRDeviceStatusReason
 * URL: http://hl7.org/fhir/ValueSet/device-status-reason
 * Size: 8 concepts
 */
export declare const FHIRDeviceStatusReasonConcepts: readonly [{
    readonly code: "online";
    readonly system: "http://terminology.hl7.org/CodeSystem/device-status-reason";
    readonly display: "Online";
}, {
    readonly code: "paused";
    readonly system: "http://terminology.hl7.org/CodeSystem/device-status-reason";
    readonly display: "Paused";
}, {
    readonly code: "standby";
    readonly system: "http://terminology.hl7.org/CodeSystem/device-status-reason";
    readonly display: "Standby";
}, {
    readonly code: "offline";
    readonly system: "http://terminology.hl7.org/CodeSystem/device-status-reason";
    readonly display: "Offline";
}, {
    readonly code: "not-ready";
    readonly system: "http://terminology.hl7.org/CodeSystem/device-status-reason";
    readonly display: "Not Ready";
}, {
    readonly code: "transduc-discon";
    readonly system: "http://terminology.hl7.org/CodeSystem/device-status-reason";
    readonly display: "Transducer Disconnected";
}, {
    readonly code: "hw-discon";
    readonly system: "http://terminology.hl7.org/CodeSystem/device-status-reason";
    readonly display: "Hardware Disconnected";
}, {
    readonly code: "off";
    readonly system: "http://terminology.hl7.org/CodeSystem/device-status-reason";
    readonly display: "Off";
}];
/** Union type of all valid codes in this ValueSet */
export type FHIRDeviceStatusReasonCode = "online" | "paused" | "standby" | "offline" | "not-ready" | "transduc-discon" | "hw-discon" | "off";
/** Type representing a concept from this ValueSet */
export type FHIRDeviceStatusReasonConcept = typeof FHIRDeviceStatusReasonConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidFHIRDeviceStatusReasonCode(code: string): code is FHIRDeviceStatusReasonCode;
/**
 * Get concept details by code
 */
export declare function getFHIRDeviceStatusReasonConcept(code: string): FHIRDeviceStatusReasonConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const FHIRDeviceStatusReasonCodes: ("online" | "paused" | "standby" | "offline" | "not-ready" | "transduc-discon" | "hw-discon" | "off")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomFHIRDeviceStatusReasonCode(): FHIRDeviceStatusReasonCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomFHIRDeviceStatusReasonConcept(): FHIRDeviceStatusReasonConcept;
