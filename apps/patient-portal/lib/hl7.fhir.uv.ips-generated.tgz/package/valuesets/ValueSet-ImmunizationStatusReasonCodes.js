/**
 * ValueSet: ImmunizationStatusReasonCodes
 * URL: http://hl7.org/fhir/ValueSet/immunization-status-reason
 * Size: Infinity concepts
 */
export const ImmunizationStatusReasonCodesConcepts = [
    { code: "IMMUNE", system: "http://terminology.hl7.org/CodeSystem/v3-ActReason" },
    { code: "MEDPREC", system: "http://terminology.hl7.org/CodeSystem/v3-ActReason" },
    { code: "OSTOCK", system: "http://terminology.hl7.org/CodeSystem/v3-ActReason" },
    { code: "PATOBJ", system: "http://terminology.hl7.org/CodeSystem/v3-ActReason" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidImmunizationStatusReasonCodesCode(code) {
    return ImmunizationStatusReasonCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getImmunizationStatusReasonCodesConcept(code) {
    return ImmunizationStatusReasonCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ImmunizationStatusReasonCodesCodes = ImmunizationStatusReasonCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomImmunizationStatusReasonCodesCode() {
    return ImmunizationStatusReasonCodesCodes[Math.floor(Math.random() * ImmunizationStatusReasonCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomImmunizationStatusReasonCodesConcept() {
    return ImmunizationStatusReasonCodesConcepts[Math.floor(Math.random() * ImmunizationStatusReasonCodesConcepts.length)];
}
