/**
 * ValueSet: FHIRDeviceStatus
 * URL: http://hl7.org/fhir/ValueSet/device-status
 * Size: 4 concepts
 */
export const FHIRDeviceStatusConcepts = [
    { code: "active", system: "http://hl7.org/fhir/device-status", display: "Active" },
    { code: "inactive", system: "http://hl7.org/fhir/device-status", display: "Inactive" },
    { code: "entered-in-error", system: "http://hl7.org/fhir/device-status", display: "Entered in Error" },
    { code: "unknown", system: "http://hl7.org/fhir/device-status", display: "Unknown" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidFHIRDeviceStatusCode(code) {
    return FHIRDeviceStatusConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getFHIRDeviceStatusConcept(code) {
    return FHIRDeviceStatusConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const FHIRDeviceStatusCodes = FHIRDeviceStatusConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomFHIRDeviceStatusCode() {
    return FHIRDeviceStatusCodes[Math.floor(Math.random() * FHIRDeviceStatusCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomFHIRDeviceStatusConcept() {
    return FHIRDeviceStatusConcepts[Math.floor(Math.random() * FHIRDeviceStatusConcepts.length)];
}
