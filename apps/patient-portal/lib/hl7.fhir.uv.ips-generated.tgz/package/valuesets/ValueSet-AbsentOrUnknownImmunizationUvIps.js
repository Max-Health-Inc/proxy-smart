/**
 * ValueSet: AbsentOrUnknownImmunizationUvIps
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/absent-or-unknown-immunizations-uv-ips
 * Size: 2 concepts
 */
export const AbsentOrUnknownImmunizationUvIpsConcepts = [
    { code: "no-immunization-info", system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips", display: "No information about immunizations" },
    { code: "no-known-immunizations", system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips", display: "No known immunizations" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidAbsentOrUnknownImmunizationUvIpsCode(code) {
    return AbsentOrUnknownImmunizationUvIpsConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getAbsentOrUnknownImmunizationUvIpsConcept(code) {
    return AbsentOrUnknownImmunizationUvIpsConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const AbsentOrUnknownImmunizationUvIpsCodes = AbsentOrUnknownImmunizationUvIpsConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomAbsentOrUnknownImmunizationUvIpsCode() {
    return AbsentOrUnknownImmunizationUvIpsCodes[Math.floor(Math.random() * AbsentOrUnknownImmunizationUvIpsCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomAbsentOrUnknownImmunizationUvIpsConcept() {
    return AbsentOrUnknownImmunizationUvIpsConcepts[Math.floor(Math.random() * AbsentOrUnknownImmunizationUvIpsConcepts.length)];
}
