/**
 * ValueSet: AllergyIntoleranceUvIps
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/allergy-intolerance-uv-ips
 * Size: 5 concepts
 */
export declare const AllergyIntoleranceUvIpsConcepts: readonly [{
    readonly code: "no-allergy-info";
    readonly system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips";
}, {
    readonly code: "no-known-allergies";
    readonly system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips";
}, {
    readonly code: "no-known-medication-allergies";
    readonly system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips";
}, {
    readonly code: "no-known-environmental-allergies";
    readonly system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips";
}, {
    readonly code: "no-known-food-allergies";
    readonly system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips";
}];
/** Union type of all valid codes in this ValueSet */
export type AllergyIntoleranceUvIpsCode = "no-allergy-info" | "no-known-allergies" | "no-known-medication-allergies" | "no-known-environmental-allergies" | "no-known-food-allergies";
/** Type representing a concept from this ValueSet */
export type AllergyIntoleranceUvIpsConcept = typeof AllergyIntoleranceUvIpsConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidAllergyIntoleranceUvIpsCode(code: string): code is AllergyIntoleranceUvIpsCode;
/**
 * Get concept details by code
 */
export declare function getAllergyIntoleranceUvIpsConcept(code: string): AllergyIntoleranceUvIpsConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const AllergyIntoleranceUvIpsCodes: ("no-allergy-info" | "no-known-allergies" | "no-known-medication-allergies" | "no-known-environmental-allergies" | "no-known-food-allergies")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomAllergyIntoleranceUvIpsCode(): AllergyIntoleranceUvIpsCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomAllergyIntoleranceUvIpsConcept(): AllergyIntoleranceUvIpsConcept;
