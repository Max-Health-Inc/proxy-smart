/**
 * ValueSet: medicationRequest Intent
 * URL: http://hl7.org/fhir/ValueSet/medicationrequest-intent
 * Size: 8 concepts
 */
export const MedicationRequestIntentConcepts = [
    { code: "proposal", system: "http://hl7.org/fhir/CodeSystem/medicationrequest-intent", display: "Proposal" },
    { code: "plan", system: "http://hl7.org/fhir/CodeSystem/medicationrequest-intent", display: "Plan" },
    { code: "order", system: "http://hl7.org/fhir/CodeSystem/medicationrequest-intent", display: "Order" },
    { code: "original-order", system: "http://hl7.org/fhir/CodeSystem/medicationrequest-intent", display: "Original Order" },
    { code: "reflex-order", system: "http://hl7.org/fhir/CodeSystem/medicationrequest-intent", display: "Reflex Order" },
    { code: "filler-order", system: "http://hl7.org/fhir/CodeSystem/medicationrequest-intent", display: "Filler Order" },
    { code: "instance-order", system: "http://hl7.org/fhir/CodeSystem/medicationrequest-intent", display: "Instance Order" },
    { code: "option", system: "http://hl7.org/fhir/CodeSystem/medicationrequest-intent", display: "Option" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidMedicationRequestIntentCode(code) {
    return MedicationRequestIntentConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getMedicationRequestIntentConcept(code) {
    return MedicationRequestIntentConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const MedicationRequestIntentCodes = MedicationRequestIntentConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomMedicationRequestIntentCode() {
    return MedicationRequestIntentCodes[Math.floor(Math.random() * MedicationRequestIntentCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomMedicationRequestIntentConcept() {
    return MedicationRequestIntentConcepts[Math.floor(Math.random() * MedicationRequestIntentConcepts.length)];
}
