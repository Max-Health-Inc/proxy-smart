/**
 * ValueSet: c80-practice-codes
 * URL: http://hl7.org/fhir/ValueSet/c80-practice-codes
 * Size: 117 concepts
 */
export const C80PracticeCodesConcepts = [
    { code: "408467006", system: "http://snomed.info/sct" },
    { code: "394577000", system: "http://snomed.info/sct" },
    { code: "394578005", system: "http://snomed.info/sct" },
    { code: "421661004", system: "http://snomed.info/sct" },
    { code: "408462000", system: "http://snomed.info/sct" },
    { code: "394579002", system: "http://snomed.info/sct" },
    { code: "394804000", system: "http://snomed.info/sct" },
    { code: "394580004", system: "http://snomed.info/sct" },
    { code: "394803006", system: "http://snomed.info/sct" },
    { code: "408480009", system: "http://snomed.info/sct" },
    { code: "408454008", system: "http://snomed.info/sct" },
    { code: "394809005", system: "http://snomed.info/sct" },
    { code: "394592004", system: "http://snomed.info/sct" },
    { code: "394600006", system: "http://snomed.info/sct" },
    { code: "394601005", system: "http://snomed.info/sct" },
    { code: "394581000", system: "http://snomed.info/sct" },
    { code: "408478003", system: "http://snomed.info/sct" },
    { code: "394812008", system: "http://snomed.info/sct" },
    { code: "408444009", system: "http://snomed.info/sct" },
    { code: "394582007", system: "http://snomed.info/sct" },
    { code: "408475000", system: "http://snomed.info/sct" },
    { code: "410005002", system: "http://snomed.info/sct" },
    { code: "394583002", system: "http://snomed.info/sct" },
    { code: "419772000", system: "http://snomed.info/sct" },
    { code: "394584008", system: "http://snomed.info/sct" },
    { code: "408443003", system: "http://snomed.info/sct" },
    { code: "394802001", system: "http://snomed.info/sct" },
    { code: "394915009", system: "http://snomed.info/sct" },
    { code: "394814009", system: "http://snomed.info/sct" },
    { code: "394808002", system: "http://snomed.info/sct" },
    { code: "394811001", system: "http://snomed.info/sct" },
    { code: "408446006", system: "http://snomed.info/sct" },
    { code: "394586005", system: "http://snomed.info/sct" },
    { code: "394916005", system: "http://snomed.info/sct" },
    { code: "408472002", system: "http://snomed.info/sct" },
    { code: "394597005", system: "http://snomed.info/sct" },
    { code: "394598000", system: "http://snomed.info/sct" },
    { code: "394807007", system: "http://snomed.info/sct" },
    { code: "419192003", system: "http://snomed.info/sct" },
    { code: "408468001", system: "http://snomed.info/sct" },
    { code: "394593009", system: "http://snomed.info/sct" },
    { code: "394813003", system: "http://snomed.info/sct" },
    { code: "410001006", system: "http://snomed.info/sct" },
    { code: "394589003", system: "http://snomed.info/sct" },
    { code: "394591006", system: "http://snomed.info/sct" },
    { code: "394599008", system: "http://snomed.info/sct" },
    { code: "394649004", system: "http://snomed.info/sct" },
    { code: "408470005", system: "http://snomed.info/sct" },
    { code: "394585009", system: "http://snomed.info/sct" },
    { code: "394821009", system: "http://snomed.info/sct" },
    { code: "422191005", system: "http://snomed.info/sct" },
    { code: "394594003", system: "http://snomed.info/sct" },
    { code: "416304004", system: "http://snomed.info/sct" },
    { code: "418960008", system: "http://snomed.info/sct" },
    { code: "394882004", system: "http://snomed.info/sct" },
    { code: "394806003", system: "http://snomed.info/sct" },
    { code: "394588006", system: "http://snomed.info/sct" },
    { code: "408459003", system: "http://snomed.info/sct" },
    { code: "394607009", system: "http://snomed.info/sct" },
    { code: "419610006", system: "http://snomed.info/sct" },
    { code: "418058008", system: "http://snomed.info/sct" },
    { code: "420208008", system: "http://snomed.info/sct" },
    { code: "418652005", system: "http://snomed.info/sct" },
    { code: "418535003", system: "http://snomed.info/sct" },
    { code: "418862001", system: "http://snomed.info/sct" },
    { code: "419365004", system: "http://snomed.info/sct" },
    { code: "418002000", system: "http://snomed.info/sct" },
    { code: "419983000", system: "http://snomed.info/sct" },
    { code: "419170002", system: "http://snomed.info/sct" },
    { code: "419472004", system: "http://snomed.info/sct" },
    { code: "394539006", system: "http://snomed.info/sct" },
    { code: "420112009", system: "http://snomed.info/sct" },
    { code: "409968004", system: "http://snomed.info/sct" },
    { code: "394587001", system: "http://snomed.info/sct" },
    { code: "394913002", system: "http://snomed.info/sct" },
    { code: "408440000", system: "http://snomed.info/sct" },
    { code: "418112009", system: "http://snomed.info/sct" },
    { code: "419815003", system: "http://snomed.info/sct" },
    { code: "394914008", system: "http://snomed.info/sct" },
    { code: "408455009", system: "http://snomed.info/sct" },
    { code: "394602003", system: "http://snomed.info/sct" },
    { code: "408447002", system: "http://snomed.info/sct" },
    { code: "394810000", system: "http://snomed.info/sct" },
    { code: "408450004", system: "http://snomed.info/sct" },
    { code: "408476004", system: "http://snomed.info/sct" },
    { code: "408469009", system: "http://snomed.info/sct" },
    { code: "408466002", system: "http://snomed.info/sct" },
    { code: "408471009", system: "http://snomed.info/sct" },
    { code: "408464004", system: "http://snomed.info/sct" },
    { code: "408441001", system: "http://snomed.info/sct" },
    { code: "408465003", system: "http://snomed.info/sct" },
    { code: "394605001", system: "http://snomed.info/sct" },
    { code: "394608004", system: "http://snomed.info/sct" },
    { code: "408461007", system: "http://snomed.info/sct" },
    { code: "408460008", system: "http://snomed.info/sct" },
    { code: "408460008", system: "http://snomed.info/sct" },
    { code: "394606000", system: "http://snomed.info/sct" },
    { code: "408449004", system: "http://snomed.info/sct" },
    { code: "394608004", system: "http://snomed.info/sct" },
    { code: "418018006", system: "http://snomed.info/sct" },
    { code: "394604002", system: "http://snomed.info/sct" },
    { code: "394609007", system: "http://snomed.info/sct" },
    { code: "408474001", system: "http://snomed.info/sct" },
    { code: "394610002", system: "http://snomed.info/sct" },
    { code: "394611003", system: "http://snomed.info/sct" },
    { code: "408477008", system: "http://snomed.info/sct" },
    { code: "394801008", system: "http://snomed.info/sct" },
    { code: "408463005", system: "http://snomed.info/sct" },
    { code: "419321007", system: "http://snomed.info/sct" },
    { code: "394576009", system: "http://snomed.info/sct" },
    { code: "394590007", system: "http://snomed.info/sct" },
    { code: "409967009", system: "http://snomed.info/sct" },
    { code: "408448007", system: "http://snomed.info/sct" },
    { code: "419043006", system: "http://snomed.info/sct" },
    { code: "394612005", system: "http://snomed.info/sct" },
    { code: "394733009", system: "http://snomed.info/sct" },
    { code: "394732004", system: "http://snomed.info/sct" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidC80PracticeCodesCode(code) {
    return C80PracticeCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getC80PracticeCodesConcept(code) {
    return C80PracticeCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const C80PracticeCodesCodes = C80PracticeCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomC80PracticeCodesCode() {
    return C80PracticeCodesCodes[Math.floor(Math.random() * C80PracticeCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomC80PracticeCodesConcept() {
    return C80PracticeCodesConcepts[Math.floor(Math.random() * C80PracticeCodesConcepts.length)];
}
