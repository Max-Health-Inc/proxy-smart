/**
 * ValueSet: FHIRSpecimenCollectionMethod
 * URL: http://hl7.org/fhir/ValueSet/specimen-collection-method
 * Size: 10 concepts
 */
export const FHIRSpecimenCollectionMethodConcepts = [
    { code: "129316008", system: "http://snomed.info/sct", display: "Aspiration - action" },
    { code: "129314006", system: "http://snomed.info/sct", display: "Biopsy - action" },
    { code: "129300006", system: "http://snomed.info/sct", display: "Puncture - action" },
    { code: "129304002", system: "http://snomed.info/sct", display: "Excision - action" },
    { code: "129323009", system: "http://snomed.info/sct", display: "Scraping - action" },
    { code: "73416001", system: "http://snomed.info/sct", display: "Urine specimen collection, clean catch" },
    { code: "225113003", system: "http://snomed.info/sct", display: "Timed urine collection" },
    { code: "70777001", system: "http://snomed.info/sct", display: "Urine specimen collection, catheterized" },
    { code: "386089008", system: "http://snomed.info/sct", display: "Collection of coughed sputum" },
    { code: "278450005", system: "http://snomed.info/sct", display: "Finger-prick sampling" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidFHIRSpecimenCollectionMethodCode(code) {
    return FHIRSpecimenCollectionMethodConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getFHIRSpecimenCollectionMethodConcept(code) {
    return FHIRSpecimenCollectionMethodConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const FHIRSpecimenCollectionMethodCodes = FHIRSpecimenCollectionMethodConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomFHIRSpecimenCollectionMethodCode() {
    return FHIRSpecimenCollectionMethodCodes[Math.floor(Math.random() * FHIRSpecimenCollectionMethodCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomFHIRSpecimenCollectionMethodConcept() {
    return FHIRSpecimenCollectionMethodConcepts[Math.floor(Math.random() * FHIRSpecimenCollectionMethodConcepts.length)];
}
