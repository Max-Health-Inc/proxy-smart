/**
 * ValueSet: ImmunizationReasonCodes
 * URL: http://hl7.org/fhir/ValueSet/immunization-reason
 * Size: 2 concepts
 */
export const ImmunizationReasonCodesConcepts = [
    { code: "429060002", system: "http://snomed.info/sct" },
    { code: "281657000", system: "http://snomed.info/sct" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidImmunizationReasonCodesCode(code) {
    return ImmunizationReasonCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getImmunizationReasonCodesConcept(code) {
    return ImmunizationReasonCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ImmunizationReasonCodesCodes = ImmunizationReasonCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomImmunizationReasonCodesCode() {
    return ImmunizationReasonCodesCodes[Math.floor(Math.random() * ImmunizationReasonCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomImmunizationReasonCodesConcept() {
    return ImmunizationReasonCodesConcepts[Math.floor(Math.random() * ImmunizationReasonCodesConcepts.length)];
}
