/**
 * ValueSet: sect_CID_29.html
 * URL: http://dicom.nema.org/medical/dicom/current/output/chtml/part16/sect_CID_29.html
 * Size: 49 concepts
 */
export const SectCID29HtmlConcepts = [
    { code: "BMD", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "EOG", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "SM", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "OP", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "ECG", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "GM", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "XA", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "XC", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "DMS", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "IVUS", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "CR", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "CT", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "OSS", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "TG", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "LEN", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "OPTENF", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "HD", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "OCT", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "BDUS", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "DG", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "PT", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "EPS", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "LS", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "PX", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "OPM", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "OPTBSV", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "OPV", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "DX", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "OPT", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "MG", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "US", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "EMG", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "IVOCT", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "MR", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "IO", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "EEG", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "RTIMAGE", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "VA", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "RESP", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "ES", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "AR", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "POS", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "RG", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "RF", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "KER", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "OAM", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "NM", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "BI", system: "http://dicom.nema.org/resources/ontology/DCM" },
    { code: "SRF", system: "http://dicom.nema.org/resources/ontology/DCM" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidSectCID29HtmlCode(code) {
    return SectCID29HtmlConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getSectCID29HtmlConcept(code) {
    return SectCID29HtmlConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const SectCID29HtmlCodes = SectCID29HtmlConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomSectCID29HtmlCode() {
    return SectCID29HtmlCodes[Math.floor(Math.random() * SectCID29HtmlCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomSectCID29HtmlConcept() {
    return SectCID29HtmlConcepts[Math.floor(Math.random() * SectCID29HtmlConcepts.length)];
}
