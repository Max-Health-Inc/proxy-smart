/**
 * ValueSet: Laterality
 * URL: http://hl7.org/fhir/ValueSet/bodysite-laterality
 * Size: 3 concepts
 */
export declare const LateralityConcepts: readonly [{
    readonly code: "419161000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Unilateral left";
}, {
    readonly code: "419465000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Unilateral right";
}, {
    readonly code: "51440002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Bilateral";
}];
/** Union type of all valid codes in this ValueSet */
export type LateralityCode = "419161000" | "419465000" | "51440002";
/** Type representing a concept from this ValueSet */
export type LateralityConcept = typeof LateralityConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidLateralityCode(code: string): code is LateralityCode;
/**
 * Get concept details by code
 */
export declare function getLateralityConcept(code: string): LateralityConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const LateralityCodes: ("419161000" | "419465000" | "51440002")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomLateralityCode(): LateralityCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomLateralityConcept(): LateralityConcept;
