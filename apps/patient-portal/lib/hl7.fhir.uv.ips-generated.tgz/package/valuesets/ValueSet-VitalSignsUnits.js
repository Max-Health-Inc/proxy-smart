/**
 * ValueSet: VitalSignsUnits
 * URL: http://hl7.org/fhir/ValueSet/ucum-vitals-common
 * Size: 12 concepts
 */
export const VitalSignsUnitsConcepts = [
    { code: "%", system: "http://unitsofmeasure.org", display: "percent" },
    { code: "cm", system: "http://unitsofmeasure.org", display: "centimeter" },
    { code: "[in_i]", system: "http://unitsofmeasure.org", display: "inch (international)" },
    { code: "kg", system: "http://unitsofmeasure.org", display: "kilogram" },
    { code: "g", system: "http://unitsofmeasure.org", display: "gram" },
    { code: "[lb_av]", system: "http://unitsofmeasure.org", display: "pound (US and British)" },
    { code: "Cel", system: "http://unitsofmeasure.org", display: "degree Celsius" },
    { code: "[degF]", system: "http://unitsofmeasure.org", display: "degree Fahrenheit" },
    { code: "mm[Hg]", system: "http://unitsofmeasure.org", display: "millimeter of mercury" },
    { code: "/min", system: "http://unitsofmeasure.org", display: "per minute" },
    { code: "kg/m2", system: "http://unitsofmeasure.org", display: "kilogram / (meter ^ 2)" },
    { code: "m2", system: "http://unitsofmeasure.org", display: "square meter" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidVitalSignsUnitsCode(code) {
    return VitalSignsUnitsConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getVitalSignsUnitsConcept(code) {
    return VitalSignsUnitsConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const VitalSignsUnitsCodes = VitalSignsUnitsConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomVitalSignsUnitsCode() {
    return VitalSignsUnitsCodes[Math.floor(Math.random() * VitalSignsUnitsCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomVitalSignsUnitsConcept() {
    return VitalSignsUnitsConcepts[Math.floor(Math.random() * VitalSignsUnitsConcepts.length)];
}
