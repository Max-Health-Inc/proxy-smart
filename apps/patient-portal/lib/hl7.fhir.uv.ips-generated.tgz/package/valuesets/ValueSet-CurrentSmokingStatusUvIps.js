/**
 * ValueSet: CurrentSmokingStatusUvIps
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/current-smoking-status-uv-ips
 * Size: 8 concepts
 */
export const CurrentSmokingStatusUvIpsConcepts = [
    { code: "LA18976-3", system: "http://loinc.org", display: "Current every day smoker" },
    { code: "LA18977-1", system: "http://loinc.org", display: "Current some day smoker" },
    { code: "LA15920-4", system: "http://loinc.org", display: "Former smoker" },
    { code: "LA18978-9", system: "http://loinc.org", display: "Never smoker" },
    { code: "LA18979-7", system: "http://loinc.org", display: "Smoker, current status unknown" },
    { code: "LA18980-5", system: "http://loinc.org", display: "Unknown if ever smoked" },
    { code: "LA18981-3", system: "http://loinc.org", display: "Heavy tobacco smoker" },
    { code: "LA18982-1", system: "http://loinc.org", display: "Light tobacco smoker" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidCurrentSmokingStatusUvIpsCode(code) {
    return CurrentSmokingStatusUvIpsConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getCurrentSmokingStatusUvIpsConcept(code) {
    return CurrentSmokingStatusUvIpsConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const CurrentSmokingStatusUvIpsCodes = CurrentSmokingStatusUvIpsConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomCurrentSmokingStatusUvIpsCode() {
    return CurrentSmokingStatusUvIpsCodes[Math.floor(Math.random() * CurrentSmokingStatusUvIpsCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomCurrentSmokingStatusUvIpsConcept() {
    return CurrentSmokingStatusUvIpsConcepts[Math.floor(Math.random() * CurrentSmokingStatusUvIpsConcepts.length)];
}
