/**
 * ValueSet: AbsentOrUnknownProceduresUvIps
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/absent-or-unknown-procedures-uv-ips
 * Size: 2 concepts
 */
export const AbsentOrUnknownProceduresUvIpsConcepts = [
    { code: "no-procedure-info", system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips", display: "No information about past history of procedures" },
    { code: "no-known-procedures", system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips", display: "No known procedures" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidAbsentOrUnknownProceduresUvIpsCode(code) {
    return AbsentOrUnknownProceduresUvIpsConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getAbsentOrUnknownProceduresUvIpsConcept(code) {
    return AbsentOrUnknownProceduresUvIpsConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const AbsentOrUnknownProceduresUvIpsCodes = AbsentOrUnknownProceduresUvIpsConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomAbsentOrUnknownProceduresUvIpsCode() {
    return AbsentOrUnknownProceduresUvIpsCodes[Math.floor(Math.random() * AbsentOrUnknownProceduresUvIpsCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomAbsentOrUnknownProceduresUvIpsConcept() {
    return AbsentOrUnknownProceduresUvIpsConcepts[Math.floor(Math.random() * AbsentOrUnknownProceduresUvIpsConcepts.length)];
}
