/**
 * ValueSet: DeviceUseStatementStatus
 * URL: http://hl7.org/fhir/ValueSet/device-statement-status
 * Size: 6 concepts
 */
export const DeviceUseStatementStatusConcepts = [
    { code: "active", system: "http://hl7.org/fhir/device-statement-status", display: "Active" },
    { code: "completed", system: "http://hl7.org/fhir/device-statement-status", display: "Completed" },
    { code: "entered-in-error", system: "http://hl7.org/fhir/device-statement-status", display: "Entered in Error" },
    { code: "intended", system: "http://hl7.org/fhir/device-statement-status", display: "Intended" },
    { code: "stopped", system: "http://hl7.org/fhir/device-statement-status", display: "Stopped" },
    { code: "on-hold", system: "http://hl7.org/fhir/device-statement-status", display: "On Hold" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidDeviceUseStatementStatusCode(code) {
    return DeviceUseStatementStatusConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getDeviceUseStatementStatusConcept(code) {
    return DeviceUseStatementStatusConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const DeviceUseStatementStatusCodes = DeviceUseStatementStatusConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomDeviceUseStatementStatusCode() {
    return DeviceUseStatementStatusCodes[Math.floor(Math.random() * DeviceUseStatementStatusCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomDeviceUseStatementStatusConcept() {
    return DeviceUseStatementStatusConcepts[Math.floor(Math.random() * DeviceUseStatementStatusConcepts.length)];
}
