/**
 * ValueSet: MedicalDevicesSnomedAbsentUnknownUvIps
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/medical-devices-snomed-absent-unknown-uv-ips
 * Size: 2 concepts
 */
export declare const MedicalDevicesSnomedAbsentUnknownUvIpsConcepts: readonly [{
    readonly code: "no-device-info";
    readonly system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips";
}, {
    readonly code: "no-known-devices";
    readonly system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips";
}];
/** Union type of all valid codes in this ValueSet */
export type MedicalDevicesSnomedAbsentUnknownUvIpsCode = "no-device-info" | "no-known-devices";
/** Type representing a concept from this ValueSet */
export type MedicalDevicesSnomedAbsentUnknownUvIpsConcept = typeof MedicalDevicesSnomedAbsentUnknownUvIpsConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidMedicalDevicesSnomedAbsentUnknownUvIpsCode(code: string): code is MedicalDevicesSnomedAbsentUnknownUvIpsCode;
/**
 * Get concept details by code
 */
export declare function getMedicalDevicesSnomedAbsentUnknownUvIpsConcept(code: string): MedicalDevicesSnomedAbsentUnknownUvIpsConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const MedicalDevicesSnomedAbsentUnknownUvIpsCodes: ("no-device-info" | "no-known-devices")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomMedicalDevicesSnomedAbsentUnknownUvIpsCode(): MedicalDevicesSnomedAbsentUnknownUvIpsCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomMedicalDevicesSnomedAbsentUnknownUvIpsConcept(): MedicalDevicesSnomedAbsentUnknownUvIpsConcept;
