/**
 * ValueSet: UDIEntryType
 * URL: http://hl7.org/fhir/ValueSet/udi-entry-type
 * Size: 6 concepts
 */
export const UDIEntryTypeConcepts = [
    { code: "barcode", system: "http://hl7.org/fhir/udi-entry-type", display: "Barcode" },
    { code: "rfid", system: "http://hl7.org/fhir/udi-entry-type", display: "RFID" },
    { code: "manual", system: "http://hl7.org/fhir/udi-entry-type", display: "Manual" },
    { code: "card", system: "http://hl7.org/fhir/udi-entry-type", display: "Card" },
    { code: "self-reported", system: "http://hl7.org/fhir/udi-entry-type", display: "Self Reported" },
    { code: "unknown", system: "http://hl7.org/fhir/udi-entry-type", display: "Unknown" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidUDIEntryTypeCode(code) {
    return UDIEntryTypeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getUDIEntryTypeConcept(code) {
    return UDIEntryTypeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const UDIEntryTypeCodes = UDIEntryTypeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomUDIEntryTypeCode() {
    return UDIEntryTypeCodes[Math.floor(Math.random() * UDIEntryTypeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomUDIEntryTypeConcept() {
    return UDIEntryTypeConcepts[Math.floor(Math.random() * UDIEntryTypeConcepts.length)];
}
