/**
 * ValueSet: ImmunizationFunctionCodes
 * URL: http://hl7.org/fhir/ValueSet/immunization-function
 * Size: 2 concepts
 */
export declare const ImmunizationFunctionCodesConcepts: readonly [{
    readonly code: "OP";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0443";
}, {
    readonly code: "AP";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0443";
}];
/** Union type of all valid codes in this ValueSet */
export type ImmunizationFunctionCodesCode = "OP" | "AP";
/** Type representing a concept from this ValueSet */
export type ImmunizationFunctionCodesConcept = typeof ImmunizationFunctionCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidImmunizationFunctionCodesCode(code: string): code is ImmunizationFunctionCodesCode;
/**
 * Get concept details by code
 */
export declare function getImmunizationFunctionCodesConcept(code: string): ImmunizationFunctionCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ImmunizationFunctionCodesCodes: ("AP" | "OP")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomImmunizationFunctionCodesCode(): ImmunizationFunctionCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomImmunizationFunctionCodesConcept(): ImmunizationFunctionCodesConcept;
