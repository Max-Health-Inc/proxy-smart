/**
 * ValueSet: AbsentOrUnknownProblemsUvIps
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/absent-or-unknown-problems-uv-ips
 * Size: 2 concepts
 */
export declare const AbsentOrUnknownProblemsUvIpsConcepts: readonly [{
    readonly code: "no-problem-info";
    readonly system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips";
    readonly display: "No information about current problems";
}, {
    readonly code: "no-known-problems";
    readonly system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips";
    readonly display: "No known problems";
}];
/** Union type of all valid codes in this ValueSet */
export type AbsentOrUnknownProblemsUvIpsCode = "no-problem-info" | "no-known-problems";
/** Type representing a concept from this ValueSet */
export type AbsentOrUnknownProblemsUvIpsConcept = typeof AbsentOrUnknownProblemsUvIpsConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidAbsentOrUnknownProblemsUvIpsCode(code: string): code is AbsentOrUnknownProblemsUvIpsCode;
/**
 * Get concept details by code
 */
export declare function getAbsentOrUnknownProblemsUvIpsConcept(code: string): AbsentOrUnknownProblemsUvIpsConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const AbsentOrUnknownProblemsUvIpsCodes: ("no-problem-info" | "no-known-problems")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomAbsentOrUnknownProblemsUvIpsCode(): AbsentOrUnknownProblemsUvIpsCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomAbsentOrUnknownProblemsUvIpsConcept(): AbsentOrUnknownProblemsUvIpsConcept;
