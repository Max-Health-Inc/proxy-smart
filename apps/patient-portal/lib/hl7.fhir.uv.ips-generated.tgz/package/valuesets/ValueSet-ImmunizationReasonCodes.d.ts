/**
 * ValueSet: ImmunizationReasonCodes
 * URL: http://hl7.org/fhir/ValueSet/immunization-reason
 * Size: 2 concepts
 */
export declare const ImmunizationReasonCodesConcepts: readonly [{
    readonly code: "429060002";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "281657000";
    readonly system: "http://snomed.info/sct";
}];
/** Union type of all valid codes in this ValueSet */
export type ImmunizationReasonCodesCode = "429060002" | "281657000";
/** Type representing a concept from this ValueSet */
export type ImmunizationReasonCodesConcept = typeof ImmunizationReasonCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidImmunizationReasonCodesCode(code: string): code is ImmunizationReasonCodesCode;
/**
 * Get concept details by code
 */
export declare function getImmunizationReasonCodesConcept(code: string): ImmunizationReasonCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ImmunizationReasonCodesCodes: ("429060002" | "281657000")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomImmunizationReasonCodesCode(): ImmunizationReasonCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomImmunizationReasonCodesConcept(): ImmunizationReasonCodesConcept;
