/**
 * ValueSet: PracticeSettingCodeValueSet
 * URL: http://hl7.org/fhir/ValueSet/c80-practice-codes
 * Size: 117 concepts
 */
export const PracticeSettingCodeValueSetConcepts = [
    { code: "408467006", system: "http://snomed.info/sct", display: "Adult mental illness" },
    { code: "394577000", system: "http://snomed.info/sct", display: "Anesthetics" },
    { code: "394578005", system: "http://snomed.info/sct", display: "Audiological medicine" },
    { code: "421661004", system: "http://snomed.info/sct", display: "Blood banking and transfusion medicine" },
    { code: "408462000", system: "http://snomed.info/sct", display: "Burns care" },
    { code: "394579002", system: "http://snomed.info/sct", display: "Cardiology" },
    { code: "394804000", system: "http://snomed.info/sct", display: "Clinical cytogenetics and molecular genetics" },
    { code: "394580004", system: "http://snomed.info/sct", display: "Clinical genetics" },
    { code: "394803006", system: "http://snomed.info/sct", display: "Clinical hematology" },
    { code: "408480009", system: "http://snomed.info/sct", display: "Clinical immunology" },
    { code: "408454008", system: "http://snomed.info/sct", display: "Clinical microbiology" },
    { code: "394809005", system: "http://snomed.info/sct", display: "Clinical neuro-physiology" },
    { code: "394592004", system: "http://snomed.info/sct", display: "Clinical oncology" },
    { code: "394600006", system: "http://snomed.info/sct", display: "Clinical pharmacology" },
    { code: "394601005", system: "http://snomed.info/sct", display: "Clinical physiology" },
    { code: "394581000", system: "http://snomed.info/sct", display: "Community medicine" },
    { code: "408478003", system: "http://snomed.info/sct", display: "Critical care medicine" },
    { code: "394812008", system: "http://snomed.info/sct", display: "Dental medicine specialties" },
    { code: "408444009", system: "http://snomed.info/sct", display: "Dental-General dental practice" },
    { code: "394582007", system: "http://snomed.info/sct", display: "Dermatology" },
    { code: "408475000", system: "http://snomed.info/sct", display: "Diabetic medicine" },
    { code: "410005002", system: "http://snomed.info/sct", display: "Dive medicine" },
    { code: "394583002", system: "http://snomed.info/sct", display: "Endocrinology" },
    { code: "419772000", system: "http://snomed.info/sct", display: "Family practice" },
    { code: "394584008", system: "http://snomed.info/sct", display: "Gastroenterology" },
    { code: "408443003", system: "http://snomed.info/sct", display: "General medical practice" },
    { code: "394802001", system: "http://snomed.info/sct", display: "General medicine" },
    { code: "394915009", system: "http://snomed.info/sct", display: "General pathology" },
    { code: "394814009", system: "http://snomed.info/sct", display: "General practice" },
    { code: "394808002", system: "http://snomed.info/sct", display: "Genito-urinary medicine" },
    { code: "394811001", system: "http://snomed.info/sct", display: "Geriatric medicine" },
    { code: "408446006", system: "http://snomed.info/sct", display: "Gynecological oncology" },
    { code: "394586005", system: "http://snomed.info/sct", display: "Gynecology" },
    { code: "394916005", system: "http://snomed.info/sct", display: "Hematopathology" },
    { code: "408472002", system: "http://snomed.info/sct", display: "Hepatology" },
    { code: "394597005", system: "http://snomed.info/sct", display: "Histopathology" },
    { code: "394598000", system: "http://snomed.info/sct", display: "Immunopathology" },
    { code: "394807007", system: "http://snomed.info/sct", display: "Infectious diseases" },
    { code: "419192003", system: "http://snomed.info/sct", display: "Internal medicine" },
    { code: "408468001", system: "http://snomed.info/sct", display: "Learning disability" },
    { code: "394593009", system: "http://snomed.info/sct", display: "Medical oncology" },
    { code: "394813003", system: "http://snomed.info/sct", display: "Medical ophthalmology" },
    { code: "410001006", system: "http://snomed.info/sct", display: "Military medicine" },
    { code: "394589003", system: "http://snomed.info/sct", display: "Nephrology" },
    { code: "394591006", system: "http://snomed.info/sct", display: "Neurology" },
    { code: "394599008", system: "http://snomed.info/sct", display: "Neuropathology" },
    { code: "394649004", system: "http://snomed.info/sct", display: "Nuclear medicine" },
    { code: "408470005", system: "http://snomed.info/sct", display: "Obstetrics" },
    { code: "394585009", system: "http://snomed.info/sct", display: "Obstetrics and gynecology" },
    { code: "394821009", system: "http://snomed.info/sct", display: "Occupational medicine" },
    { code: "422191005", system: "http://snomed.info/sct", display: "Ophthalmic surgery" },
    { code: "394594003", system: "http://snomed.info/sct", display: "Ophthalmology" },
    { code: "416304004", system: "http://snomed.info/sct", display: "Osteopathic manipulative medicine" },
    { code: "418960008", system: "http://snomed.info/sct", display: "Otolaryngology" },
    { code: "394882004", system: "http://snomed.info/sct", display: "Pain management" },
    { code: "394806003", system: "http://snomed.info/sct", display: "Palliative medicine" },
    { code: "394588006", system: "http://snomed.info/sct", display: "Pediatric (Child and adolescent) psychiatry" },
    { code: "408459003", system: "http://snomed.info/sct", display: "Pediatric cardiology" },
    { code: "394607009", system: "http://snomed.info/sct", display: "Pediatric dentistry" },
    { code: "419610006", system: "http://snomed.info/sct", display: "Pediatric endocrinology" },
    { code: "418058008", system: "http://snomed.info/sct", display: "Pediatric gastroenterology" },
    { code: "420208008", system: "http://snomed.info/sct", display: "Pediatric genetics" },
    { code: "418652005", system: "http://snomed.info/sct", display: "Pediatric hematology" },
    { code: "418535003", system: "http://snomed.info/sct", display: "Pediatric immunology" },
    { code: "418862001", system: "http://snomed.info/sct", display: "Pediatric infectious diseases" },
    { code: "419365004", system: "http://snomed.info/sct", display: "Pediatric nephrology" },
    { code: "418002000", system: "http://snomed.info/sct", display: "Pediatric oncology" },
    { code: "419983000", system: "http://snomed.info/sct", display: "Pediatric ophthalmology" },
    { code: "419170002", system: "http://snomed.info/sct", display: "Pediatric pulmonology" },
    { code: "419472004", system: "http://snomed.info/sct", display: "Pediatric rheumatology" },
    { code: "394539006", system: "http://snomed.info/sct", display: "Pediatric surgery" },
    { code: "420112009", system: "http://snomed.info/sct", display: "Pediatric surgery-bone marrow transplantation" },
    { code: "409968004", system: "http://snomed.info/sct", display: "Preventive medicine" },
    { code: "394587001", system: "http://snomed.info/sct", display: "Psychiatry" },
    { code: "394913002", system: "http://snomed.info/sct", display: "Psychotherapy" },
    { code: "408440000", system: "http://snomed.info/sct", display: "Public health medicine" },
    { code: "418112009", system: "http://snomed.info/sct", display: "Pulmonary medicine" },
    { code: "419815003", system: "http://snomed.info/sct", display: "Radiation oncology" },
    { code: "394914008", system: "http://snomed.info/sct", display: "Radiology" },
    { code: "408455009", system: "http://snomed.info/sct", display: "Radiology-Interventional radiology" },
    { code: "394602003", system: "http://snomed.info/sct", display: "Rehabilitation" },
    { code: "408447002", system: "http://snomed.info/sct", display: "Respite care" },
    { code: "394810000", system: "http://snomed.info/sct", display: "Rheumatology" },
    { code: "408450004", system: "http://snomed.info/sct", display: "Sleep studies" },
    { code: "408476004", system: "http://snomed.info/sct", display: "Surgery-Bone and marrow transplantation" },
    { code: "408469009", system: "http://snomed.info/sct", display: "Surgery-Breast surgery" },
    { code: "408466002", system: "http://snomed.info/sct", display: "Surgery-Cardiac surgery" },
    { code: "408471009", system: "http://snomed.info/sct", display: "Surgery-Cardiothoracic transplantation" },
    { code: "408464004", system: "http://snomed.info/sct", display: "Surgery-Colorectal surgery" },
    { code: "408441001", system: "http://snomed.info/sct", display: "Surgery-Dental-Endodontics" },
    { code: "408465003", system: "http://snomed.info/sct", display: "Surgery-Dental-Oral and maxillofacial surgery" },
    { code: "394605001", system: "http://snomed.info/sct", display: "Surgery-Dental-Oral surgery" },
    { code: "394608004", system: "http://snomed.info/sct", display: "Surgery-Dental-Orthodontics" },
    { code: "408461007", system: "http://snomed.info/sct", display: "Surgery-Dental-Periodontal surgery" },
    { code: "408460008", system: "http://snomed.info/sct", display: "Surgery-Dental-Prosthetic dentistry (Prosthodontics)" },
    { code: "408460008", system: "http://snomed.info/sct", display: "Surgery-Dental-surgical-Prosthodontics" },
    { code: "394606000", system: "http://snomed.info/sct", display: "Surgery-Dentistry-Restorative dentistry" },
    { code: "408449004", system: "http://snomed.info/sct", display: "Surgery-Dentistry--surgical" },
    { code: "394608004", system: "http://snomed.info/sct", display: "Surgery-Dentistry-surgical-Orthodontics" },
    { code: "418018006", system: "http://snomed.info/sct", display: "Surgery-Dermatologic surgery" },
    { code: "394604002", system: "http://snomed.info/sct", display: "Surgery-Ear, nose and throat surgery" },
    { code: "394609007", system: "http://snomed.info/sct", display: "Surgery-general" },
    { code: "408474001", system: "http://snomed.info/sct", display: "Surgery-Hepatobiliary and pancreatic surgery" },
    { code: "394610002", system: "http://snomed.info/sct", display: "Surgery-Neurosurgery" },
    { code: "394611003", system: "http://snomed.info/sct", display: "Surgery-Plastic surgery" },
    { code: "408477008", system: "http://snomed.info/sct", display: "Surgery-Transplantation surgery" },
    { code: "394801008", system: "http://snomed.info/sct", display: "Surgery-Trauma and orthopedics" },
    { code: "408463005", system: "http://snomed.info/sct", display: "Surgery-Vascular" },
    { code: "419321007", system: "http://snomed.info/sct", display: "Surgical oncology" },
    { code: "394576009", system: "http://snomed.info/sct", display: "Surgical-Accident & emergency" },
    { code: "394590007", system: "http://snomed.info/sct", display: "Thoracic medicine" },
    { code: "409967009", system: "http://snomed.info/sct", display: "Toxicology" },
    { code: "408448007", system: "http://snomed.info/sct", display: "Tropical medicine" },
    { code: "419043006", system: "http://snomed.info/sct", display: "Urological oncology" },
    { code: "394612005", system: "http://snomed.info/sct", display: "Urology" },
    { code: "394733009", system: "http://snomed.info/sct", display: "Medical specialty--OTHER--NOT LISTED" },
    { code: "394732004", system: "http://snomed.info/sct", display: "Surgical specialty--OTHER-NOT LISTED" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidPracticeSettingCodeValueSetCode(code) {
    return PracticeSettingCodeValueSetConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getPracticeSettingCodeValueSetConcept(code) {
    return PracticeSettingCodeValueSetConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const PracticeSettingCodeValueSetCodes = PracticeSettingCodeValueSetConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomPracticeSettingCodeValueSetCode() {
    return PracticeSettingCodeValueSetCodes[Math.floor(Math.random() * PracticeSettingCodeValueSetCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomPracticeSettingCodeValueSetConcept() {
    return PracticeSettingCodeValueSetConcepts[Math.floor(Math.random() * PracticeSettingCodeValueSetConcepts.length)];
}
