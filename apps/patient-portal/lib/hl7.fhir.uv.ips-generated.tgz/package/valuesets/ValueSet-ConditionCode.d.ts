/**
 * ValueSet: condition-code
 * URL: http://hl7.org/fhir/ValueSet/condition-code
 * Size: 1 concepts
 */
export declare const ConditionCodeConcepts: readonly [{
    readonly code: "160245001";
    readonly system: "http://snomed.info/sct";
}];
/** Union type of all valid codes in this ValueSet */
export type ConditionCodeCode = "160245001";
/** Type representing a concept from this ValueSet */
export type ConditionCodeConcept = typeof ConditionCodeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidConditionCodeCode(code: string): code is ConditionCodeCode;
/**
 * Get concept details by code
 */
export declare function getConditionCodeConcept(code: string): ConditionCodeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ConditionCodeCodes: "160245001"[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomConditionCodeCode(): ConditionCodeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomConditionCodeConcept(): ConditionCodeConcept;
