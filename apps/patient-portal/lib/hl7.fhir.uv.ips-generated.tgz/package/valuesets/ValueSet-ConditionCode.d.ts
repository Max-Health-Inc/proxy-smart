/**
 * ValueSet: condition-code
 * URL: http://hl7.org/fhir/ValueSet/condition-code
 * Size: 15 concepts
 */
export declare const ConditionCodeConcepts: readonly [{
    readonly code: "27113001";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "50373000";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "75367002";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "364075005";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "86290005";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "386725007";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "431314004";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "60621009";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "271649006";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "271650006";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "404684003";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "118228005";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "250171008";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "363787002";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "386661006";
    readonly system: "http://snomed.info/sct";
}];
/** Union type of all valid codes in this ValueSet */
export type ConditionCodeCode = "27113001" | "50373000" | "75367002" | "364075005" | "86290005" | "386725007" | "431314004" | "60621009" | "271649006" | "271650006" | "404684003" | "118228005" | "250171008" | "363787002" | "386661006";
/** Type representing a concept from this ValueSet */
export type ConditionCodeConcept = typeof ConditionCodeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidConditionCodeCode(code: string): code is ConditionCodeCode;
/**
 * Get concept details by code
 */
export declare function getConditionCodeConcept(code: string): ConditionCodeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ConditionCodeCodes: ("404684003" | "364075005" | "27113001" | "50373000" | "75367002" | "86290005" | "386725007" | "431314004" | "60621009" | "271649006" | "271650006" | "118228005" | "250171008" | "363787002" | "386661006")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomConditionCodeCode(): ConditionCodeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomConditionCodeConcept(): ConditionCodeConcept;
