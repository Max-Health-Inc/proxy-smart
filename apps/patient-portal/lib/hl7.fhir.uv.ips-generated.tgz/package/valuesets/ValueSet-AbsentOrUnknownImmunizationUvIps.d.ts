/**
 * ValueSet: AbsentOrUnknownImmunizationUvIps
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/absent-or-unknown-immunizations-uv-ips
 * Size: 2 concepts
 */
export declare const AbsentOrUnknownImmunizationUvIpsConcepts: readonly [{
    readonly code: "no-immunization-info";
    readonly system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips";
    readonly display: "No information about immunizations";
}, {
    readonly code: "no-known-immunizations";
    readonly system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips";
    readonly display: "No known immunizations";
}];
/** Union type of all valid codes in this ValueSet */
export type AbsentOrUnknownImmunizationUvIpsCode = "no-immunization-info" | "no-known-immunizations";
/** Type representing a concept from this ValueSet */
export type AbsentOrUnknownImmunizationUvIpsConcept = typeof AbsentOrUnknownImmunizationUvIpsConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidAbsentOrUnknownImmunizationUvIpsCode(code: string): code is AbsentOrUnknownImmunizationUvIpsCode;
/**
 * Get concept details by code
 */
export declare function getAbsentOrUnknownImmunizationUvIpsConcept(code: string): AbsentOrUnknownImmunizationUvIpsConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const AbsentOrUnknownImmunizationUvIpsCodes: ("no-immunization-info" | "no-known-immunizations")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomAbsentOrUnknownImmunizationUvIpsCode(): AbsentOrUnknownImmunizationUvIpsCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomAbsentOrUnknownImmunizationUvIpsConcept(): AbsentOrUnknownImmunizationUvIpsConcept;
