/**
 * ValueSet: ResultsSpecimenTypeSnomedCtIpsFreeSet
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/results-specimen-type-snomed-ct-ips-free-set
 * Size: Infinity concepts
 */
export const ResultsSpecimenTypeSnomedCtIpsFreeSetConcepts = [
    { code: "708048008", system: "http://snomed.info/sct", display: "Plasma specimen with citrate" },
    { code: "702701006", system: "http://snomed.info/sct", display: "Specimen from cervix or vagina" },
    { code: "698276005", system: "http://snomed.info/sct", display: "First stream urine specimen" },
    { code: "472896000", system: "http://snomed.info/sct", display: "Swab from blister" },
    { code: "472881004", system: "http://snomed.info/sct", display: "Swab from pharynx" },
    { code: "472867001", system: "http://snomed.info/sct", display: "Swab from tonsil" },
    { code: "446861007", system: "http://snomed.info/sct", display: "Cerebrospinal fluid specimen obtained via ventriculoperitoneal shunt" },
    { code: "446846006", system: "http://snomed.info/sct", display: "Urine specimen obtained via indwelling urinary catheter" },
    { code: "446562005", system: "http://snomed.info/sct", display: "Body fluid specimen obtained via sump drain" },
    { code: "446302006", system: "http://snomed.info/sct", display: "Air specimen" },
    { code: "446272009", system: "http://snomed.info/sct", display: "Blood specimen submitted in heparinized collection tube" },
    { code: "440500007", system: "http://snomed.info/sct", display: "Dried blood spot specimen" },
    { code: "440493002", system: "http://snomed.info/sct", display: "Graft specimen from patient" },
    { code: "440473005", system: "http://snomed.info/sct", display: "Contact lens submitted as specimen" },
    { code: "440137008", system: "http://snomed.info/sct", display: "Specimen obtained by peritoneal lavage" },
    { code: "439961009", system: "http://snomed.info/sct", display: "Implant submitted as specimen" },
    { code: "438660002", system: "http://snomed.info/sct", display: "Specimen from prosthetic device" },
    { code: "432825001", system: "http://snomed.info/sct", display: "Body secretion specimen" },
    { code: "430268003", system: "http://snomed.info/sct", display: "Specimen from bone" },
    { code: "408654003", system: "http://snomed.info/sct", display: "Specimen obtained by amputation" },
    { code: "399713008", system: "http://snomed.info/sct", display: "Specimen from uterine cervix obtained by cone biopsy" },
    { code: "309502007", system: "http://snomed.info/sct", display: "Fetus specimen" },
    { code: "309213006", system: "http://snomed.info/sct", display: "Gastric brushings specimen" },
    { code: "309211008", system: "http://snomed.info/sct", display: "Gastric biopsy specimen" },
    { code: "309210009", system: "http://snomed.info/sct", display: "Esophageal brushings specimen" },
    { code: "309176002", system: "http://snomed.info/sct", display: "Bronchial brushings specimen" },
    { code: "309166000", system: "http://snomed.info/sct", display: "Ear swab specimen" },
    { code: "309075001", system: "http://snomed.info/sct", display: "Skin cyst specimen" },
    { code: "309068002", system: "http://snomed.info/sct", display: "Skin lesion specimen" },
    { code: "309067007", system: "http://snomed.info/sct", display: "Specimen from skin obtained by curettage" },
    { code: "309066003", system: "http://snomed.info/sct", display: "Skin biopsy specimen" },
    { code: "309051001", system: "http://snomed.info/sct", display: "Body fluid specimen" },
    { code: "309049000", system: "http://snomed.info/sct", display: "Lesion specimen" },
    { code: "302795002", system: "http://snomed.info/sct", display: "Lymph node aspirate" },
    { code: "302794003", system: "http://snomed.info/sct", display: "Nasogastric aspirate" },
    { code: "278020009", system: "http://snomed.info/sct", display: "Spot urine specimen" },
    { code: "258649003", system: "http://snomed.info/sct", display: "Intravenous infusion fluid specimen" },
    { code: "258609006", system: "http://snomed.info/sct", display: "Sputum specimen obtained by aspiration from trachea" },
    { code: "258607008", system: "http://snomed.info/sct", display: "Bronchoalveolar lavage fluid specimen" },
    { code: "258603007", system: "http://snomed.info/sct", display: "Respiratory specimen" },
    { code: "258591005", system: "http://snomed.info/sct", display: "White blood cell specimen" },
    { code: "258580003", system: "http://snomed.info/sct", display: "Whole blood specimen" },
    { code: "258574006", system: "http://snomed.info/sct", display: "Mid-stream urine specimen" },
    { code: "258531008", system: "http://snomed.info/sct", display: "Wound swab" },
    { code: "258530009", system: "http://snomed.info/sct", display: "Urethral swab" },
    { code: "258528007", system: "http://snomed.info/sct", display: "Rectal swab" },
    { code: "258523003", system: "http://snomed.info/sct", display: "Vulval swab" },
    { code: "258520000", system: "http://snomed.info/sct", display: "Vaginal swab" },
    { code: "258505006", system: "http://snomed.info/sct", display: "Skin ulcer swab" },
    { code: "258503004", system: "http://snomed.info/sct", display: "Skin swab" },
    { code: "258502009", system: "http://snomed.info/sct", display: "Pus swab" },
    { code: "258500001", system: "http://snomed.info/sct", display: "Nasopharyngeal swab" },
    { code: "258498002", system: "http://snomed.info/sct", display: "Conjunctival swab" },
    { code: "258482009", system: "http://snomed.info/sct", display: "Vesicle fluid specimen" },
    { code: "258474009", system: "http://snomed.info/sct", display: "Sinus fluid specimen" },
    { code: "258463000", system: "http://snomed.info/sct", display: "Jejunal fluid specimen" },
    { code: "258459007", system: "http://snomed.info/sct", display: "Gastric fluid specimen" },
    { code: "258455001", system: "http://snomed.info/sct", display: "Drainage fluid specimen" },
    { code: "258453008", system: "http://snomed.info/sct", display: "Cyst fluid specimen" },
    { code: "258450006", system: "http://snomed.info/sct", display: "Cerebrospinal fluid specimen" },
    { code: "258442002", system: "http://snomed.info/sct", display: "Fluid specimen" },
    { code: "258441009", system: "http://snomed.info/sct", display: "Exudate specimen" },
    { code: "258440005", system: "http://snomed.info/sct", display: "Effusion specimen" },
    { code: "258438000", system: "http://snomed.info/sct", display: "Vitreous humor specimen" },
    { code: "258435002", system: "http://snomed.info/sct", display: "Tumor tissue specimen" },
    { code: "258415003", system: "http://snomed.info/sct", display: "Biopsy specimen" },
    { code: "257261003", system: "http://snomed.info/sct", display: "Swab" },
    { code: "168141000", system: "http://snomed.info/sct", display: "Nasal fluid specimen" },
    { code: "168139001", system: "http://snomed.info/sct", display: "Peritoneal fluid specimen" },
    { code: "168138009", system: "http://snomed.info/sct", display: "Gastric lavage aspirate specimen" },
    { code: "168137004", system: "http://snomed.info/sct", display: "Gastric aspirate specimen" },
    { code: "122880004", system: "http://snomed.info/sct", display: "Urine specimen obtained by clean catch procedure" },
    { code: "122877000", system: "http://snomed.info/sct", display: "Upper respiratory fluid specimen obtained by tracheal aspiration" },
    { code: "122609004", system: "http://snomed.info/sct", display: "Specimen from lung obtained by bronchial washing procedure" },
    { code: "122593002", system: "http://snomed.info/sct", display: "Tissue specimen obtained from ulcer" },
    { code: "122580007", system: "http://snomed.info/sct", display: "Cerumen specimen" },
    { code: "122575003", system: "http://snomed.info/sct", display: "Urine specimen" },
    { code: "122572000", system: "http://snomed.info/sct", display: "Vomitus specimen" },
    { code: "122568004", system: "http://snomed.info/sct", display: "Exudate specimen from wound" },
    { code: "122566000", system: "http://snomed.info/sct", display: "Fluid specimen from wound" },
    { code: "122565001", system: "http://snomed.info/sct", display: "Urinary catheter specimen" },
    { code: "122560006", system: "http://snomed.info/sct", display: "Blood specimen from blood donor" },
    { code: "122556008", system: "http://snomed.info/sct", display: "Cord blood specimen" },
    { code: "122555007", system: "http://snomed.info/sct", display: "Venous blood specimen" },
    { code: "122554006", system: "http://snomed.info/sct", display: "Capillary blood specimen" },
    { code: "122552005", system: "http://snomed.info/sct", display: "Arterial blood specimen" },
    { code: "119401005", system: "http://snomed.info/sct", display: "Specimen from conjunctiva" },
    { code: "119395005", system: "http://snomed.info/sct", display: "Specimen from uterine cervix" },
    { code: "119394009", system: "http://snomed.info/sct", display: "Specimen from vagina" },
    { code: "119376003", system: "http://snomed.info/sct", display: "Tissue specimen" },
    { code: "119371008", system: "http://snomed.info/sct", display: "Specimen from abscess" },
    { code: "119370009", system: "http://snomed.info/sct", display: "Specimen from fistula" },
    { code: "119367005", system: "http://snomed.info/sct", display: "Specimen from burn injury" },
    { code: "119366001", system: "http://snomed.info/sct", display: "Specimen from wound abscess" },
    { code: "119365002", system: "http://snomed.info/sct", display: "Specimen from wound" },
    { code: "119364003", system: "http://snomed.info/sct", display: "Serum specimen" },
    { code: "119363009", system: "http://snomed.info/sct", display: "Platelet rich plasma specimen" },
    { code: "119362004", system: "http://snomed.info/sct", display: "Platelet poor plasma specimen" },
    { code: "119361006", system: "http://snomed.info/sct", display: "Plasma specimen" },
    { code: "119360007", system: "http://snomed.info/sct", display: "Dialysis fluid specimen" },
    { code: "119351004", system: "http://snomed.info/sct", display: "Erythrocyte specimen" },
    { code: "119350003", system: "http://snomed.info/sct", display: "Calculus specimen" },
    { code: "119349003", system: "http://snomed.info/sct", display: "Spermatozoa specimen" },
    { code: "119345009", system: "http://snomed.info/sct", display: "Menstrual blood specimen" },
    { code: "119344008", system: "http://snomed.info/sct", display: "Specimen from genital system" },
    { code: "119342007", system: "http://snomed.info/sct", display: "Saliva specimen" },
    { code: "119341000", system: "http://snomed.info/sct", display: "Bile specimen" },
    { code: "119339001", system: "http://snomed.info/sct", display: "Stool specimen" },
    { code: "119337004", system: "http://snomed.info/sct", display: "Inhaled gas specimen" },
    { code: "119336008", system: "http://snomed.info/sct", display: "Exhaled air specimen" },
    { code: "119335007", system: "http://snomed.info/sct", display: "Coughed sputum specimen" },
    { code: "119334006", system: "http://snomed.info/sct", display: "Sputum specimen" },
    { code: "119332005", system: "http://snomed.info/sct", display: "Synovial fluid specimen" },
    { code: "119329007", system: "http://snomed.info/sct", display: "Colostrum specimen" },
    { code: "119327009", system: "http://snomed.info/sct", display: "Nail specimen" },
    { code: "119325001", system: "http://snomed.info/sct", display: "Tissue specimen from skin" },
    { code: "119323008", system: "http://snomed.info/sct", display: "Pus specimen" },
    { code: "119320006", system: "http://snomed.info/sct", display: "Food specimen" },
    { code: "119318008", system: "http://snomed.info/sct", display: "Water specimen" },
    { code: "119312009", system: "http://snomed.info/sct", display: "Catheter tip submitted as specimen" },
    { code: "119311002", system: "http://snomed.info/sct", display: "Catheter submitted as specimen" },
    { code: "119305000", system: "http://snomed.info/sct", display: "Specimen from plasma bag" },
    { code: "119304001", system: "http://snomed.info/sct", display: "Specimen from blood bag" },
    { code: "119300005", system: "http://snomed.info/sct", display: "Specimen from blood product" },
    { code: "119297000", system: "http://snomed.info/sct", display: "Blood specimen" },
    { code: "119295008", system: "http://snomed.info/sct", display: "Specimen obtained by aspiration" },
    { code: "119294007", system: "http://snomed.info/sct", display: "Dried blood specimen" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidResultsSpecimenTypeSnomedCtIpsFreeSetCode(code) {
    return ResultsSpecimenTypeSnomedCtIpsFreeSetConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getResultsSpecimenTypeSnomedCtIpsFreeSetConcept(code) {
    return ResultsSpecimenTypeSnomedCtIpsFreeSetConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ResultsSpecimenTypeSnomedCtIpsFreeSetCodes = ResultsSpecimenTypeSnomedCtIpsFreeSetConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomResultsSpecimenTypeSnomedCtIpsFreeSetCode() {
    return ResultsSpecimenTypeSnomedCtIpsFreeSetCodes[Math.floor(Math.random() * ResultsSpecimenTypeSnomedCtIpsFreeSetCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomResultsSpecimenTypeSnomedCtIpsFreeSetConcept() {
    return ResultsSpecimenTypeSnomedCtIpsFreeSetConcepts[Math.floor(Math.random() * ResultsSpecimenTypeSnomedCtIpsFreeSetConcepts.length)];
}
