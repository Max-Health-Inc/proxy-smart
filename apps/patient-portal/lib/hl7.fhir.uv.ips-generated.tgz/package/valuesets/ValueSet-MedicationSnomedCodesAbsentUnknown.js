/**
 * ValueSet: MedicationSnomedCodesAbsentUnknown
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/medication-snomed-absent-unknown-uv-ips
 * Size: 2 concepts
 */
export const MedicationSnomedCodesAbsentUnknownConcepts = [
    { code: "no-medication-info", system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips" },
    { code: "no-known-medications", system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidMedicationSnomedCodesAbsentUnknownCode(code) {
    return MedicationSnomedCodesAbsentUnknownConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getMedicationSnomedCodesAbsentUnknownConcept(code) {
    return MedicationSnomedCodesAbsentUnknownConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const MedicationSnomedCodesAbsentUnknownCodes = MedicationSnomedCodesAbsentUnknownConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomMedicationSnomedCodesAbsentUnknownCode() {
    return MedicationSnomedCodesAbsentUnknownCodes[Math.floor(Math.random() * MedicationSnomedCodesAbsentUnknownCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomMedicationSnomedCodesAbsentUnknownConcept() {
    return MedicationSnomedCodesAbsentUnknownConcepts[Math.floor(Math.random() * MedicationSnomedCodesAbsentUnknownConcepts.length)];
}
