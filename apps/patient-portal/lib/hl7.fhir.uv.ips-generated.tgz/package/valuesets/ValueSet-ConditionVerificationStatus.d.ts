/**
 * ValueSet: ConditionVerificationStatus
 * URL: http://hl7.org/fhir/ValueSet/condition-ver-status
 * Size: 4 concepts
 */
export declare const ConditionVerificationStatusConcepts: readonly [{
    readonly code: "unconfirmed";
    readonly system: "http://terminology.hl7.org/CodeSystem/condition-ver-status";
    readonly display: "Unconfirmed";
}, {
    readonly code: "confirmed";
    readonly system: "http://terminology.hl7.org/CodeSystem/condition-ver-status";
    readonly display: "Confirmed";
}, {
    readonly code: "refuted";
    readonly system: "http://terminology.hl7.org/CodeSystem/condition-ver-status";
    readonly display: "Refuted";
}, {
    readonly code: "entered-in-error";
    readonly system: "http://terminology.hl7.org/CodeSystem/condition-ver-status";
    readonly display: "Entered in Error";
}];
/** Union type of all valid codes in this ValueSet */
export type ConditionVerificationStatusCode = "unconfirmed" | "confirmed" | "refuted" | "entered-in-error";
/** Type representing a concept from this ValueSet */
export type ConditionVerificationStatusConcept = typeof ConditionVerificationStatusConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidConditionVerificationStatusCode(code: string): code is ConditionVerificationStatusCode;
/**
 * Get concept details by code
 */
export declare function getConditionVerificationStatusConcept(code: string): ConditionVerificationStatusConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ConditionVerificationStatusCodes: ("confirmed" | "entered-in-error" | "unconfirmed" | "refuted")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomConditionVerificationStatusCode(): ConditionVerificationStatusCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomConditionVerificationStatusConcept(): ConditionVerificationStatusConcept;
