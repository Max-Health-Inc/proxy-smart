/**
 * ValueSet: AllergyIntoleranceSeverity
 * URL: http://hl7.org/fhir/ValueSet/reaction-event-severity
 * Size: 3 concepts
 */
export declare const AllergyIntoleranceSeverityConcepts: readonly [{
    readonly code: "mild";
    readonly system: "http://hl7.org/fhir/reaction-event-severity";
    readonly display: "Mild";
}, {
    readonly code: "moderate";
    readonly system: "http://hl7.org/fhir/reaction-event-severity";
    readonly display: "Moderate";
}, {
    readonly code: "severe";
    readonly system: "http://hl7.org/fhir/reaction-event-severity";
    readonly display: "Severe";
}];
/** Union type of all valid codes in this ValueSet */
export type AllergyIntoleranceSeverityCode = "mild" | "moderate" | "severe";
/** Type representing a concept from this ValueSet */
export type AllergyIntoleranceSeverityConcept = typeof AllergyIntoleranceSeverityConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidAllergyIntoleranceSeverityCode(code: string): code is AllergyIntoleranceSeverityCode;
/**
 * Get concept details by code
 */
export declare function getAllergyIntoleranceSeverityConcept(code: string): AllergyIntoleranceSeverityConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const AllergyIntoleranceSeverityCodes: ("mild" | "moderate" | "severe")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomAllergyIntoleranceSeverityCode(): AllergyIntoleranceSeverityCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomAllergyIntoleranceSeverityConcept(): AllergyIntoleranceSeverityConcept;
