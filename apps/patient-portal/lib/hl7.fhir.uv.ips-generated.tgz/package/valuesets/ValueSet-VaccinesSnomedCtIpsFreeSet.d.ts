/**
 * ValueSet: VaccinesSnomedCtIpsFreeSet
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/vaccines-snomed-ct-ips-free-set
 * Size: Infinity concepts
 */
export declare const VaccinesSnomedCtIpsFreeSetConcepts: readonly [{
    readonly code: "2221000221107";
    readonly system: "http://snomed.info/sct";
    readonly display: "Live attenuated Human alphaherpesvirus 3 only vaccine product";
}, {
    readonly code: "2171000221104";
    readonly system: "http://snomed.info/sct";
    readonly display: "Salmonella enterica subspecies enterica serovar Typhi capsular polysaccharide unconjugated antigen only vaccine product in parenteral dose form";
}, {
    readonly code: "1981000221108";
    readonly system: "http://snomed.info/sct";
    readonly display: "Neisseria meningitidis serogroup B antigen only vaccine product";
}, {
    readonly code: "1801000221105";
    readonly system: "http://snomed.info/sct";
    readonly display: "Streptococcus pneumoniae capsular polysaccharide antigen conjugated only vaccine product";
}, {
    readonly code: "1181000221105";
    readonly system: "http://snomed.info/sct";
    readonly display: "Influenza virus antigen only vaccine product";
}, {
    readonly code: "1131000221109";
    readonly system: "http://snomed.info/sct";
    readonly display: "Vaccine product containing only inactivated whole Rabies lyssavirus antigen";
}, {
    readonly code: "1121000221106";
    readonly system: "http://snomed.info/sct";
    readonly display: "Live attenuated Yellow fever virus antigen only vaccine product";
}, {
    readonly code: "1101000221104";
    readonly system: "http://snomed.info/sct";
    readonly display: "Clostridium tetani toxoid antigen-containing vaccine product";
}, {
    readonly code: "1081000221109";
    readonly system: "http://snomed.info/sct";
    readonly display: "Live attenuated Rotavirus antigen only vaccine product";
}, {
    readonly code: "1051000221104";
    readonly system: "http://snomed.info/sct";
    readonly display: "Live attenuated Human poliovirus serotypes 1 and 3 antigens only vaccine product in oral dose form";
}, {
    readonly code: "1031000221108";
    readonly system: "http://snomed.info/sct";
    readonly display: "Human poliovirus antigen-containing vaccine product";
}, {
    readonly code: "1011000221100";
    readonly system: "http://snomed.info/sct";
    readonly display: "Live attenuated Vibrio cholerae antigen only vaccine product in oral dose form";
}, {
    readonly code: "1001000221103";
    readonly system: "http://snomed.info/sct";
    readonly display: "Inactivated whole Vibrio cholerae antigen only vaccine product in oral dose form";
}, {
    readonly code: "971000221109";
    readonly system: "http://snomed.info/sct";
    readonly display: "Live attenuated Salmonella enterica subspecies enterica serovar Typhi antigen only vaccine product in oral dose form";
}, {
    readonly code: "601000221108";
    readonly system: "http://snomed.info/sct";
    readonly display: "Bordetella pertussis antigen-containing vaccine product";
}, {
    readonly code: "1119254000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Streptococcus pneumoniae Danish serotype 1, 3, 4, 5, 6A, 6B, 7F, 9V, 14, 18C, 19A, 19F, and 23F capsular polysaccharide antigens only vaccine product";
}, {
    readonly code: "1052328007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Streptococcus pneumoniae Danish serotype 4, 6B, 9V, 14, 18C, 19F, and 23F capsular polysaccharide antigens conjugated only vaccine product";
}, {
    readonly code: "871921009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Staphylococcus toxoid vaccine";
}, {
    readonly code: "871918007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Rickettsia antigen-containing vaccine product";
}, {
    readonly code: "871908002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Human alphaherpesvirus 3 and Measles morbillivirus and Mumps orthorubulavirus and Rubella virus antigens only vaccine product";
}, {
    readonly code: "871895005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Bordetella pertussis and Clostridium tetani and Corynebacterium diphtheriae and Haemophilus influenzae type b and Hepatitis B virus and Human poliovirus antigens only vaccine product";
}, {
    readonly code: "871889009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Acellular Bordetella pertussis and Corynebacterium diphtheriae and Hepatitis B virus and inactivated whole Human poliovirus antigens only vaccine product";
}, {
    readonly code: "871887006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Bordetella pertussis and Clostridium tetani and Corynebacterium diphtheriae and Haemophilus influenzae type b and Human poliovirus antigens only vaccine product";
}, {
    readonly code: "871878002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Bordetella pertussis and Clostridium tetani and Corynebacterium diphtheriae and Human poliovirus antigens only vaccine product";
}, {
    readonly code: "871876003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Acellular Bordetella pertussis and Clostridium tetani and Corynebacterium diphtheriae antigens only vaccine product";
}, {
    readonly code: "871875004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Bordetella pertussis and Clostridium tetani and Corynebacterium diphtheriae antigens only vaccine product";
}, {
    readonly code: "871873006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Neisseria meningitidis serogroup A, C, W135 and Y only vaccine product";
}, {
    readonly code: "871871008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Neisseria meningitidis serogroup A and C only vaccine product";
}, {
    readonly code: "871866001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Neisseria meningitidis serogroup C only vaccine product";
}, {
    readonly code: "871839001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Bordetella pertussis and Clostridium tetani and Corynebacterium diphtheriae and Haemophilus influenzae type b antigens only vaccine product";
}, {
    readonly code: "871837004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Clostridium tetani and Corynebacterium diphtheriae and Human poliovirus antigens only vaccine product";
}, {
    readonly code: "871831003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Measles morbillivirus and Mumps orthorubulavirus and Rubella virus antigens only vaccine product";
}, {
    readonly code: "871826000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Clostridium tetani and Corynebacterium diphtheriae antigens only vaccine product";
}, {
    readonly code: "871806004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Haemophilus influenzae type b and Hepatitis B virus antigens only vaccine product";
}, {
    readonly code: "871804001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hepatitis A virus and Salmonella enterica subspecies enterica serovar Typhi antigens only vaccine product";
}, {
    readonly code: "871803007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hepatitis A and Hepatitis B virus antigens only vaccine product";
}, {
    readonly code: "871772009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Influenza A virus subtype H1N1 antigen only vaccine product";
}, {
    readonly code: "871768005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Influenza virus antigen only vaccine product in nasal dose form";
}, {
    readonly code: "871765008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Measles morbillivirus antigen only vaccine product";
}, {
    readonly code: "871759008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Acellular Bordetella pertussis only vaccine product";
}, {
    readonly code: "871740006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Inactivated whole Human poliovirus antigen only vaccine product";
}, {
    readonly code: "871738001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Live attenuated Mumps orthorubulavirus antigen only vaccine product";
}, {
    readonly code: "871737006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Mumps orthorubulavirus antigen only vaccine product";
}, {
    readonly code: "863911006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Clostridium tetani antigen-containing vaccine product";
}, {
    readonly code: "840599008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Borrelia burgdorferi antigen-containing vaccine product";
}, {
    readonly code: "840549009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Yersinia pestis antigen-containing vaccine product";
}, {
    readonly code: "836500008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Haemophilus influenzae type b and Neisseria meningitidis serogroup C antigens only vaccine product";
}, {
    readonly code: "836498007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Mumps orthorubulavirus antigen-containing vaccine product";
}, {
    readonly code: "836495005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Human alphaherpesvirus 3 antigen-containing vaccine product";
}, {
    readonly code: "836403007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Tick-borne encephalitis virus antigen-containing vaccine product";
}, {
    readonly code: "836402002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Bacillus Calmette-Guerin antigen-containing vaccine product";
}, {
    readonly code: "836401009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Neisseria meningitidis antigen-containing vaccine product";
}, {
    readonly code: "836398006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Streptococcus pneumoniae antigen-containing vaccine product";
}, {
    readonly code: "836397001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Coxiella burnetii antigen-containing vaccine product";
}, {
    readonly code: "836393002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Rabies lyssavirus antigen-containing vaccine product";
}, {
    readonly code: "836390004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Salmonella enterica subspecies enterica serovar Typhi antigen-containing vaccine product";
}, {
    readonly code: "836389008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Vaccinia virus antigen-containing vaccine product";
}, {
    readonly code: "836388000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Rubella virus antigen-containing vaccine product";
}, {
    readonly code: "836387005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Rotavirus antigen-containing vaccine product";
}, {
    readonly code: "836385002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Yellow fever virus antigen-containing vaccine product";
}, {
    readonly code: "836384003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Bacillus anthracis antigen-containing vaccine product";
}, {
    readonly code: "836383009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Vibrio cholerae antigen-containing vaccine product";
}, {
    readonly code: "836382004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Measles morbillivirus antigen-containing vaccine product";
}, {
    readonly code: "836381006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Corynebacterium diphtheriae antigen-containing vaccine product";
}, {
    readonly code: "836380007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Haemophilus influenzae type b antigen-containing vaccine product";
}, {
    readonly code: "836379009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Human papillomavirus antigen-containing vaccine product";
}, {
    readonly code: "836378001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Japanese encephalitis virus antigen-containing vaccine product";
}, {
    readonly code: "836377006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Influenza virus antigen-containing vaccine product";
}, {
    readonly code: "836375003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hepatitis A virus antigen-containing vaccine product";
}, {
    readonly code: "836374004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hepatitis B virus antigen-containing vaccine product";
}, {
    readonly code: "836369007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Virus antigen-containing vaccine product";
}, {
    readonly code: "836368004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Bacteria antigen-containing vaccine product";
}, {
    readonly code: "777725002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Clostridium tetani toxoid antigen adsorbed only vaccine product";
}, {
    readonly code: "775641005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Clostridium tetani toxoid adsorbed and Corynebacterium diphtheriae toxoid antigens only vaccine product";
}, {
    readonly code: "774618008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Whole cell Bordetella pertussis and Clostridium tetani toxoid adsorbed and Corynebacterium diphtheriae toxoid antigens only vaccine product";
}, {
    readonly code: "428601009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Paratyphoid vaccine";
}, {
    readonly code: "409568008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Pentavalent botulinum toxoid vaccine";
}, {
    readonly code: "37146000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Typhus vaccine";
}];
/** String type (ValueSet too large for union type) */
export type VaccinesSnomedCtIpsFreeSetCode = string;
/** Type representing a concept from this ValueSet */
export type VaccinesSnomedCtIpsFreeSetConcept = typeof VaccinesSnomedCtIpsFreeSetConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidVaccinesSnomedCtIpsFreeSetCode(code: string): code is VaccinesSnomedCtIpsFreeSetCode;
/**
 * Get concept details by code
 */
export declare function getVaccinesSnomedCtIpsFreeSetConcept(code: string): VaccinesSnomedCtIpsFreeSetConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const VaccinesSnomedCtIpsFreeSetCodes: ("37146000" | "409568008" | "428601009" | "774618008" | "775641005" | "777725002" | "836368004" | "836369007" | "836374004" | "836375003" | "836377006" | "836378001" | "836379009" | "836380007" | "836381006" | "836382004" | "836383009" | "836384003" | "836385002" | "836387005" | "836388000" | "836389008" | "836390004" | "836393002" | "836397001" | "836398006" | "836401009" | "836402002" | "836403007" | "836495005" | "836498007" | "836500008" | "840549009" | "840599008" | "863911006" | "871737006" | "871738001" | "871740006" | "871759008" | "871765008" | "871768005" | "871772009" | "871803007" | "871804001" | "871806004" | "871826000" | "871831003" | "871837004" | "871839001" | "871866001" | "871871008" | "871873006" | "871875004" | "871876003" | "871878002" | "871887006" | "871889009" | "871895005" | "871908002" | "871918007" | "871921009" | "1052328007" | "1119254000" | "601000221108" | "971000221109" | "1001000221103" | "1011000221100" | "1031000221108" | "1051000221104" | "1081000221109" | "1101000221104" | "1121000221106" | "1131000221109" | "1181000221105" | "1801000221105" | "1981000221108" | "2171000221104" | "2221000221107")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomVaccinesSnomedCtIpsFreeSetCode(): VaccinesSnomedCtIpsFreeSetCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomVaccinesSnomedCtIpsFreeSetConcept(): VaccinesSnomedCtIpsFreeSetConcept;
