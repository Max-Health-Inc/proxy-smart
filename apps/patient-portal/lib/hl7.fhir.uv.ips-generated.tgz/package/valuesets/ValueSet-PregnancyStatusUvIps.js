/**
 * ValueSet: PregnancyStatusUvIps
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/pregnancy-status-uv-ips
 * Size: 3 concepts
 */
export const PregnancyStatusUvIpsConcepts = [
    { code: "LA15173-0", system: "http://loinc.org", display: "Pregnant" },
    { code: "LA26683-5", system: "http://loinc.org", display: "Not pregnant" },
    { code: "LA4489-6", system: "http://loinc.org", display: "Unknown" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidPregnancyStatusUvIpsCode(code) {
    return PregnancyStatusUvIpsConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getPregnancyStatusUvIpsConcept(code) {
    return PregnancyStatusUvIpsConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const PregnancyStatusUvIpsCodes = PregnancyStatusUvIpsConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomPregnancyStatusUvIpsCode() {
    return PregnancyStatusUvIpsCodes[Math.floor(Math.random() * PregnancyStatusUvIpsCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomPregnancyStatusUvIpsConcept() {
    return PregnancyStatusUvIpsConcepts[Math.floor(Math.random() * PregnancyStatusUvIpsConcepts.length)];
}
