/**
 * ValueSet: ConditionClinicalStatusCodes
 * URL: http://hl7.org/fhir/ValueSet/condition-clinical
 * Size: 2 concepts
 */
export declare const ConditionClinicalStatusCodesConcepts: readonly [{
    readonly code: "active";
    readonly system: "http://terminology.hl7.org/CodeSystem/condition-clinical";
    readonly display: "Active";
}, {
    readonly code: "inactive";
    readonly system: "http://terminology.hl7.org/CodeSystem/condition-clinical";
    readonly display: "Inactive";
}];
/** Union type of all valid codes in this ValueSet */
export type ConditionClinicalStatusCodesCode = "active" | "inactive";
/** Type representing a concept from this ValueSet */
export type ConditionClinicalStatusCodesConcept = typeof ConditionClinicalStatusCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidConditionClinicalStatusCodesCode(code: string): code is ConditionClinicalStatusCodesCode;
/**
 * Get concept details by code
 */
export declare function getConditionClinicalStatusCodesConcept(code: string): ConditionClinicalStatusCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ConditionClinicalStatusCodesCodes: ("active" | "inactive")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomConditionClinicalStatusCodesCode(): ConditionClinicalStatusCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomConditionClinicalStatusCodesConcept(): ConditionClinicalStatusCodesConcept;
