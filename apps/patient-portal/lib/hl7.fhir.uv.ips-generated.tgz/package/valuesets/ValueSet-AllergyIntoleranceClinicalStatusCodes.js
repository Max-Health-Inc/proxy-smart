/**
 * ValueSet: AllergyIntoleranceClinicalStatusCodes
 * URL: http://hl7.org/fhir/ValueSet/allergyintolerance-clinical
 * Size: 2 concepts
 */
export const AllergyIntoleranceClinicalStatusCodesConcepts = [
    { code: "active", system: "http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical", display: "Active" },
    { code: "inactive", system: "http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical", display: "Inactive" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidAllergyIntoleranceClinicalStatusCodesCode(code) {
    return AllergyIntoleranceClinicalStatusCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getAllergyIntoleranceClinicalStatusCodesConcept(code) {
    return AllergyIntoleranceClinicalStatusCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const AllergyIntoleranceClinicalStatusCodesCodes = AllergyIntoleranceClinicalStatusCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomAllergyIntoleranceClinicalStatusCodesCode() {
    return AllergyIntoleranceClinicalStatusCodesCodes[Math.floor(Math.random() * AllergyIntoleranceClinicalStatusCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomAllergyIntoleranceClinicalStatusCodesConcept() {
    return AllergyIntoleranceClinicalStatusCodesConcepts[Math.floor(Math.random() * AllergyIntoleranceClinicalStatusCodesConcepts.length)];
}
