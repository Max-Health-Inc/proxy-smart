/**
 * ValueSet: ProceduresSnomedAbsentUnknownUvIps
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/procedures-snomed-absent-unknown-uv-ips
 * Size: 2 concepts
 */
export const ProceduresSnomedAbsentUnknownUvIpsConcepts = [
    { code: "no-procedure-info", system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips" },
    { code: "no-known-procedures", system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidProceduresSnomedAbsentUnknownUvIpsCode(code) {
    return ProceduresSnomedAbsentUnknownUvIpsConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getProceduresSnomedAbsentUnknownUvIpsConcept(code) {
    return ProceduresSnomedAbsentUnknownUvIpsConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ProceduresSnomedAbsentUnknownUvIpsCodes = ProceduresSnomedAbsentUnknownUvIpsConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomProceduresSnomedAbsentUnknownUvIpsCode() {
    return ProceduresSnomedAbsentUnknownUvIpsCodes[Math.floor(Math.random() * ProceduresSnomedAbsentUnknownUvIpsCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomProceduresSnomedAbsentUnknownUvIpsConcept() {
    return ProceduresSnomedAbsentUnknownUvIpsConcepts[Math.floor(Math.random() * ProceduresSnomedAbsentUnknownUvIpsConcepts.length)];
}
