/**
 * ValueSet: MedicalDevicesSnomedAbsentUnknownUvIps
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/medical-devices-snomed-absent-unknown-uv-ips
 * Size: 2 concepts
 */
export const MedicalDevicesSnomedAbsentUnknownUvIpsConcepts = [
    { code: "no-device-info", system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips" },
    { code: "no-known-devices", system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidMedicalDevicesSnomedAbsentUnknownUvIpsCode(code) {
    return MedicalDevicesSnomedAbsentUnknownUvIpsConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getMedicalDevicesSnomedAbsentUnknownUvIpsConcept(code) {
    return MedicalDevicesSnomedAbsentUnknownUvIpsConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const MedicalDevicesSnomedAbsentUnknownUvIpsCodes = MedicalDevicesSnomedAbsentUnknownUvIpsConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomMedicalDevicesSnomedAbsentUnknownUvIpsCode() {
    return MedicalDevicesSnomedAbsentUnknownUvIpsCodes[Math.floor(Math.random() * MedicalDevicesSnomedAbsentUnknownUvIpsCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomMedicalDevicesSnomedAbsentUnknownUvIpsConcept() {
    return MedicalDevicesSnomedAbsentUnknownUvIpsConcepts[Math.floor(Math.random() * MedicalDevicesSnomedAbsentUnknownUvIpsConcepts.length)];
}
