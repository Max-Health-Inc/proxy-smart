/**
 * ValueSet: MediaCollectionView/Projection
 * URL: http://hl7.org/fhir/ValueSet/media-view
 * Size: 100 concepts
 */
export declare const MediaCollectionViewProjectionConcepts: readonly [{
    readonly code: "260419006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Projection";
}, {
    readonly code: "260421001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Left lateral oblique";
}, {
    readonly code: "260422008";
    readonly system: "http://snomed.info/sct";
    readonly display: "C1-C2 left oblique";
}, {
    readonly code: "260424009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Right lateral oblique";
}, {
    readonly code: "260425005";
    readonly system: "http://snomed.info/sct";
    readonly display: "C1-C2 right oblique";
}, {
    readonly code: "260426006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Medial oblique";
}, {
    readonly code: "260427002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Oblique lateral";
}, {
    readonly code: "260428007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Mandible X-ray - lateral oblique";
}, {
    readonly code: "260430009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Anteroposterior left lateral decubitus";
}, {
    readonly code: "260431008";
    readonly system: "http://snomed.info/sct";
    readonly display: "C1-C2 left lateral";
}, {
    readonly code: "260432001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Left true lateral";
}, {
    readonly code: "260434000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Anteroposterior right lateral decubitus";
}, {
    readonly code: "260435004";
    readonly system: "http://snomed.info/sct";
    readonly display: "C1-C2 right lateral";
}, {
    readonly code: "260436003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Right true lateral";
}, {
    readonly code: "260437007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Lateral vertical beam";
}, {
    readonly code: "260438002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Lateral horizontal beam";
}, {
    readonly code: "260439005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Lateral inverted";
}, {
    readonly code: "260440007";
    readonly system: "http://snomed.info/sct";
    readonly display: "True lateral of mandible";
}, {
    readonly code: "260441006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Frog lateral";
}, {
    readonly code: "260442004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Erect lateral";
}, {
    readonly code: "260443009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Anteroposterior inverted";
}, {
    readonly code: "260444003";
    readonly system: "http://snomed.info/sct";
    readonly display: "PA - Rotated posteroanterior";
}, {
    readonly code: "260445002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Posteroanterior 20 degree";
}, {
    readonly code: "260446001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Posteroanterior in ulnar deviation";
}, {
    readonly code: "260447005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Penetrated posteroanterior";
}, {
    readonly code: "260450008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Lordotic projection";
}, {
    readonly code: "260451007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Supine decubitus";
}, {
    readonly code: "260452000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Decubitus";
}, {
    readonly code: "260453005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Internal/external rotation";
}, {
    readonly code: "260454004";
    readonly system: "http://snomed.info/sct";
    readonly display: "45 degree projection";
}, {
    readonly code: "260455003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Head and neck projection";
}, {
    readonly code: "260458001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Slit anteroposterior";
}, {
    readonly code: "260459009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Reverse Towne's";
}, {
    readonly code: "260460004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Slit 35 degree fronto-occipital";
}, {
    readonly code: "260461000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Vertex projection";
}, {
    readonly code: "260463002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Left Stenver's";
}, {
    readonly code: "260464008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Right Stenver's";
}, {
    readonly code: "260465009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Occipitofrontal projection";
}, {
    readonly code: "260466005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Occipitomental projection";
}, {
    readonly code: "260467001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Occipitomental - erect";
}, {
    readonly code: "260468006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Occipitomental - tilted";
}, {
    readonly code: "260469003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Occipitomental - prone";
}, {
    readonly code: "260470002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Occipitomental - 15 degree";
}, {
    readonly code: "260471003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Occipitomental - 30 degree";
}, {
    readonly code: "260472005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Occipitomental - 45 degree";
}, {
    readonly code: "260473000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Waters - 35 degree tilt to radiographic baseline";
}, {
    readonly code: "260475007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Submentovertical reduced exposure for zygomatic arches";
}, {
    readonly code: "260476008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Slit SMV";
}, {
    readonly code: "260477004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Dental/oral projection";
}, {
    readonly code: "260478009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Body - molar";
}, {
    readonly code: "260479001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Body - premolar";
}, {
    readonly code: "260481004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Ramus projection";
}, {
    readonly code: "260482006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Bimolar projection";
}, {
    readonly code: "260483001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Toller projection";
}, {
    readonly code: "260484007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Transmaxillary projection";
}, {
    readonly code: "260485008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Temporomandibular joint setting";
}, {
    readonly code: "260486009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Maxillary sinus setting";
}, {
    readonly code: "260487000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Dental panoramic";
}, {
    readonly code: "260489002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Implant setting projection";
}, {
    readonly code: "260490006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Segmental setting";
}, {
    readonly code: "260491005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Axial view for sesamoid bones";
}, {
    readonly code: "260492003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Brewerton's projection";
}, {
    readonly code: "260493008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Harris Beath axial projection";
}, {
    readonly code: "260494002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Tunnel projection";
}, {
    readonly code: "260496000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Judet projection";
}, {
    readonly code: "260497009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Mortice projection";
}, {
    readonly code: "260499007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Occlusal projection";
}, {
    readonly code: "260500003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Projected oblique occlusal";
}, {
    readonly code: "260501004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Lower true occlusal";
}, {
    readonly code: "260502006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Power grip series";
}, {
    readonly code: "260503001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Radial head projection";
}, {
    readonly code: "260504007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Skyline projection";
}, {
    readonly code: "260506009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Van Rosen projection";
}, {
    readonly code: "272455005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Inferosuperior projection";
}, {
    readonly code: "272456006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Apical projection";
}, {
    readonly code: "272457002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Vertical projection";
}, {
    readonly code: "272458007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Prone projection";
}, {
    readonly code: "272459004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Supine projection";
}, {
    readonly code: "272460009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Anterior projection";
}, {
    readonly code: "272461008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Right posterior projection";
}, {
    readonly code: "272462001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Left posterior projection";
}, {
    readonly code: "272464000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Perorbital projection";
}, {
    readonly code: "272465004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Temporomandibular joint projection";
}, {
    readonly code: "272466003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Optic foramen projection";
}, {
    readonly code: "272467007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Lateral facial skeleton projection";
}, {
    readonly code: "272468002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Ear projection";
}, {
    readonly code: "272469005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Mid face projection";
}, {
    readonly code: "272470006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Cervical spine projection";
}, {
    readonly code: "272472003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Macro projection";
}, {
    readonly code: "272473008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Outlet projection";
}, {
    readonly code: "272474002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Swimmer's projection";
}, {
    readonly code: "272475001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Tibial tuberosity projection";
}, {
    readonly code: "272476000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Transthoracic projection";
}, {
    readonly code: "272478004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Transcranial projection";
}, {
    readonly code: "272479007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Posteroanterior projection";
}, {
    readonly code: "272480005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Horizontal projection";
}, {
    readonly code: "272481009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Erect projection";
}, {
    readonly code: "272482002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Adduction projection";
}, {
    readonly code: "272483007";
    readonly system: "http://snomed.info/sct";
    readonly display: "True projection";
}, {
    readonly code: "272484001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Contralateral projection";
}];
/** String type (ValueSet too large for union type) */
export type MediaCollectionViewProjectionCode = string;
/** Type representing a concept from this ValueSet */
export type MediaCollectionViewProjectionConcept = typeof MediaCollectionViewProjectionConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidMediaCollectionViewProjectionCode(code: string): code is MediaCollectionViewProjectionCode;
/**
 * Get concept details by code
 */
export declare function getMediaCollectionViewProjectionConcept(code: string): MediaCollectionViewProjectionConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const MediaCollectionViewProjectionCodes: ("260419006" | "260421001" | "260422008" | "260424009" | "260425005" | "260426006" | "260427002" | "260428007" | "260430009" | "260431008" | "260432001" | "260434000" | "260435004" | "260436003" | "260437007" | "260438002" | "260439005" | "260440007" | "260441006" | "260442004" | "260443009" | "260444003" | "260445002" | "260446001" | "260447005" | "260450008" | "260451007" | "260452000" | "260453005" | "260454004" | "260455003" | "260458001" | "260459009" | "260460004" | "260461000" | "260463002" | "260464008" | "260465009" | "260466005" | "260467001" | "260468006" | "260469003" | "260470002" | "260471003" | "260472005" | "260473000" | "260475007" | "260476008" | "260477004" | "260478009" | "260479001" | "260481004" | "260482006" | "260483001" | "260484007" | "260485008" | "260486009" | "260487000" | "260489002" | "260490006" | "260491005" | "260492003" | "260493008" | "260494002" | "260496000" | "260497009" | "260499007" | "260500003" | "260501004" | "260502006" | "260503001" | "260504007" | "260506009" | "272455005" | "272456006" | "272457002" | "272458007" | "272459004" | "272460009" | "272461008" | "272462001" | "272464000" | "272465004" | "272466003" | "272467007" | "272468002" | "272469005" | "272470006" | "272472003" | "272473008" | "272474002" | "272475001" | "272476000" | "272478004" | "272479007" | "272480005" | "272481009" | "272482002" | "272483007" | "272484001")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomMediaCollectionViewProjectionCode(): MediaCollectionViewProjectionCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomMediaCollectionViewProjectionConcept(): MediaCollectionViewProjectionConcept;
