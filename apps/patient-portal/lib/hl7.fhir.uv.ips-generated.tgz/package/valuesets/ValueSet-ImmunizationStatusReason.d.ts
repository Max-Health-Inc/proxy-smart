/**
 * ValueSet: immunization-status-reason
 * URL: http://hl7.org/fhir/ValueSet/immunization-status-reason
 * Size: 4 concepts
 */
export declare const ImmunizationStatusReasonConcepts: readonly [{
    readonly code: "IMMUNE";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActReason";
}, {
    readonly code: "MEDPREC";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActReason";
}, {
    readonly code: "OSTOCK";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActReason";
}, {
    readonly code: "PATOBJ";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActReason";
}];
/** Union type of all valid codes in this ValueSet */
export type ImmunizationStatusReasonCode = "IMMUNE" | "MEDPREC" | "OSTOCK" | "PATOBJ";
/** Type representing a concept from this ValueSet */
export type ImmunizationStatusReasonConcept = typeof ImmunizationStatusReasonConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidImmunizationStatusReasonCode(code: string): code is ImmunizationStatusReasonCode;
/**
 * Get concept details by code
 */
export declare function getImmunizationStatusReasonConcept(code: string): ImmunizationStatusReasonConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ImmunizationStatusReasonCodes: ("IMMUNE" | "MEDPREC" | "OSTOCK" | "PATOBJ")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomImmunizationStatusReasonCode(): ImmunizationStatusReasonCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomImmunizationStatusReasonConcept(): ImmunizationStatusReasonConcept;
