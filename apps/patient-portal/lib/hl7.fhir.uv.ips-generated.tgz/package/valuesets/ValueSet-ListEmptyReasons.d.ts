/**
 * ValueSet: ListEmptyReasons
 * URL: http://hl7.org/fhir/ValueSet/list-empty-reason
 * Size: 6 concepts
 */
export declare const ListEmptyReasonsConcepts: readonly [{
    readonly code: "nilknown";
    readonly system: "http://terminology.hl7.org/CodeSystem/list-empty-reason";
    readonly display: "Nil Known";
}, {
    readonly code: "notasked";
    readonly system: "http://terminology.hl7.org/CodeSystem/list-empty-reason";
    readonly display: "Not Asked";
}, {
    readonly code: "withheld";
    readonly system: "http://terminology.hl7.org/CodeSystem/list-empty-reason";
    readonly display: "Information Withheld";
}, {
    readonly code: "unavailable";
    readonly system: "http://terminology.hl7.org/CodeSystem/list-empty-reason";
    readonly display: "Unavailable";
}, {
    readonly code: "notstarted";
    readonly system: "http://terminology.hl7.org/CodeSystem/list-empty-reason";
    readonly display: "Not Started";
}, {
    readonly code: "closed";
    readonly system: "http://terminology.hl7.org/CodeSystem/list-empty-reason";
    readonly display: "Closed";
}];
/** Union type of all valid codes in this ValueSet */
export type ListEmptyReasonsCode = "nilknown" | "notasked" | "withheld" | "unavailable" | "notstarted" | "closed";
/** Type representing a concept from this ValueSet */
export type ListEmptyReasonsConcept = typeof ListEmptyReasonsConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidListEmptyReasonsCode(code: string): code is ListEmptyReasonsCode;
/**
 * Get concept details by code
 */
export declare function getListEmptyReasonsConcept(code: string): ListEmptyReasonsConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ListEmptyReasonsCodes: ("unavailable" | "nilknown" | "notasked" | "withheld" | "notstarted" | "closed")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomListEmptyReasonsCode(): ListEmptyReasonsCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomListEmptyReasonsConcept(): ListEmptyReasonsConcept;
