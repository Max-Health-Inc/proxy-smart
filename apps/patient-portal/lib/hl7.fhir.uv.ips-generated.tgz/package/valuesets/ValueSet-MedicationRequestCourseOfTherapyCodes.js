/**
 * ValueSet: medicationRequest Course of Therapy Codes
 * URL: http://hl7.org/fhir/ValueSet/medicationrequest-course-of-therapy
 * Size: 3 concepts
 */
export const MedicationRequestCourseOfTherapyCodesConcepts = [
    { code: "continuous", system: "http://terminology.hl7.org/CodeSystem/medicationrequest-course-of-therapy", display: "Continuous long term therapy" },
    { code: "acute", system: "http://terminology.hl7.org/CodeSystem/medicationrequest-course-of-therapy", display: "Short course (acute) therapy" },
    { code: "seasonal", system: "http://terminology.hl7.org/CodeSystem/medicationrequest-course-of-therapy", display: "Seasonal" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidMedicationRequestCourseOfTherapyCodesCode(code) {
    return MedicationRequestCourseOfTherapyCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getMedicationRequestCourseOfTherapyCodesConcept(code) {
    return MedicationRequestCourseOfTherapyCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const MedicationRequestCourseOfTherapyCodesCodes = MedicationRequestCourseOfTherapyCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomMedicationRequestCourseOfTherapyCodesCode() {
    return MedicationRequestCourseOfTherapyCodesCodes[Math.floor(Math.random() * MedicationRequestCourseOfTherapyCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomMedicationRequestCourseOfTherapyCodesConcept() {
    return MedicationRequestCourseOfTherapyCodesConcepts[Math.floor(Math.random() * MedicationRequestCourseOfTherapyCodesConcepts.length)];
}
