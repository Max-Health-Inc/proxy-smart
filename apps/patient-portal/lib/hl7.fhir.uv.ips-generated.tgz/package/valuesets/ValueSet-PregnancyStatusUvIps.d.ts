/**
 * ValueSet: PregnancyStatusUvIps
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/pregnancy-status-uv-ips
 * Size: 3 concepts
 */
export declare const PregnancyStatusUvIpsConcepts: readonly [{
    readonly code: "LA15173-0";
    readonly system: "http://loinc.org";
    readonly display: "Pregnant";
}, {
    readonly code: "LA26683-5";
    readonly system: "http://loinc.org";
    readonly display: "Not pregnant";
}, {
    readonly code: "LA4489-6";
    readonly system: "http://loinc.org";
    readonly display: "Unknown";
}];
/** Union type of all valid codes in this ValueSet */
export type PregnancyStatusUvIpsCode = "LA15173-0" | "LA26683-5" | "LA4489-6";
/** Type representing a concept from this ValueSet */
export type PregnancyStatusUvIpsConcept = typeof PregnancyStatusUvIpsConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidPregnancyStatusUvIpsCode(code: string): code is PregnancyStatusUvIpsCode;
/**
 * Get concept details by code
 */
export declare function getPregnancyStatusUvIpsConcept(code: string): PregnancyStatusUvIpsConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const PregnancyStatusUvIpsCodes: ("LA15173-0" | "LA26683-5" | "LA4489-6")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomPregnancyStatusUvIpsCode(): PregnancyStatusUvIpsCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomPregnancyStatusUvIpsConcept(): PregnancyStatusUvIpsConcept;
