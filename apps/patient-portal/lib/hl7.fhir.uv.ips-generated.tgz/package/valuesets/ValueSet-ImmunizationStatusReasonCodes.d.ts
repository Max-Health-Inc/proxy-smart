/**
 * ValueSet: ImmunizationStatusReasonCodes
 * URL: http://hl7.org/fhir/ValueSet/immunization-status-reason
 * Size: Infinity concepts
 */
export declare const ImmunizationStatusReasonCodesConcepts: readonly [{
    readonly code: "IMMUNE";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActReason";
}, {
    readonly code: "MEDPREC";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActReason";
}, {
    readonly code: "OSTOCK";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActReason";
}, {
    readonly code: "PATOBJ";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActReason";
}];
/** String type (ValueSet too large for union type) */
export type ImmunizationStatusReasonCodesCode = string;
/** Type representing a concept from this ValueSet */
export type ImmunizationStatusReasonCodesConcept = typeof ImmunizationStatusReasonCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidImmunizationStatusReasonCodesCode(code: string): code is ImmunizationStatusReasonCodesCode;
/**
 * Get concept details by code
 */
export declare function getImmunizationStatusReasonCodesConcept(code: string): ImmunizationStatusReasonCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ImmunizationStatusReasonCodesCodes: ("IMMUNE" | "MEDPREC" | "OSTOCK" | "PATOBJ")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomImmunizationStatusReasonCodesCode(): ImmunizationStatusReasonCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomImmunizationStatusReasonCodesConcept(): ImmunizationStatusReasonCodesConcept;
