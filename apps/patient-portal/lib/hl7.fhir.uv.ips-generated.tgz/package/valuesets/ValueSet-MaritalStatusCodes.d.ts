/**
 * ValueSet: Marital Status Codes
 * URL: http://hl7.org/fhir/ValueSet/marital-status
 * Size: 1 concepts
 */
export declare const MaritalStatusCodesConcepts: readonly [{
    readonly code: "UNK";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-NullFlavor";
}];
/** Union type of all valid codes in this ValueSet */
export type MaritalStatusCodesCode = "UNK";
/** Type representing a concept from this ValueSet */
export type MaritalStatusCodesConcept = typeof MaritalStatusCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidMaritalStatusCodesCode(code: string): code is MaritalStatusCodesCode;
/**
 * Get concept details by code
 */
export declare function getMaritalStatusCodesConcept(code: string): MaritalStatusCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const MaritalStatusCodesCodes: "UNK"[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomMaritalStatusCodesCode(): MaritalStatusCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomMaritalStatusCodesConcept(): MaritalStatusCodesConcept;
