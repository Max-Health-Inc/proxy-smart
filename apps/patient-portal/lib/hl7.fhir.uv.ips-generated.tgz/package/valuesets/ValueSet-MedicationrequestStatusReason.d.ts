/**
 * ValueSet: medicationrequest-status-reason
 * URL: http://hl7.org/fhir/ValueSet/medicationrequest-status-reason
 * Size: 13 concepts
 */
export declare const MedicationrequestStatusReasonConcepts: readonly [{
    readonly code: "altchoice";
    readonly system: "http://terminology.hl7.org/CodeSystem/medicationrequest-status-reason";
}, {
    readonly code: "clarif";
    readonly system: "http://terminology.hl7.org/CodeSystem/medicationrequest-status-reason";
}, {
    readonly code: "drughigh";
    readonly system: "http://terminology.hl7.org/CodeSystem/medicationrequest-status-reason";
}, {
    readonly code: "hospadm";
    readonly system: "http://terminology.hl7.org/CodeSystem/medicationrequest-status-reason";
}, {
    readonly code: "labint";
    readonly system: "http://terminology.hl7.org/CodeSystem/medicationrequest-status-reason";
}, {
    readonly code: "non-avail";
    readonly system: "http://terminology.hl7.org/CodeSystem/medicationrequest-status-reason";
}, {
    readonly code: "preg";
    readonly system: "http://terminology.hl7.org/CodeSystem/medicationrequest-status-reason";
}, {
    readonly code: "salg";
    readonly system: "http://terminology.hl7.org/CodeSystem/medicationrequest-status-reason";
}, {
    readonly code: "sddi";
    readonly system: "http://terminology.hl7.org/CodeSystem/medicationrequest-status-reason";
}, {
    readonly code: "sdupther";
    readonly system: "http://terminology.hl7.org/CodeSystem/medicationrequest-status-reason";
}, {
    readonly code: "sintol";
    readonly system: "http://terminology.hl7.org/CodeSystem/medicationrequest-status-reason";
}, {
    readonly code: "surg";
    readonly system: "http://terminology.hl7.org/CodeSystem/medicationrequest-status-reason";
}, {
    readonly code: "washout";
    readonly system: "http://terminology.hl7.org/CodeSystem/medicationrequest-status-reason";
}];
/** Union type of all valid codes in this ValueSet */
export type MedicationrequestStatusReasonCode = "altchoice" | "clarif" | "drughigh" | "hospadm" | "labint" | "non-avail" | "preg" | "salg" | "sddi" | "sdupther" | "sintol" | "surg" | "washout";
/** Type representing a concept from this ValueSet */
export type MedicationrequestStatusReasonConcept = typeof MedicationrequestStatusReasonConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidMedicationrequestStatusReasonCode(code: string): code is MedicationrequestStatusReasonCode;
/**
 * Get concept details by code
 */
export declare function getMedicationrequestStatusReasonConcept(code: string): MedicationrequestStatusReasonConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const MedicationrequestStatusReasonCodes: ("altchoice" | "clarif" | "drughigh" | "hospadm" | "labint" | "non-avail" | "preg" | "salg" | "sddi" | "sdupther" | "sintol" | "surg" | "washout")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomMedicationrequestStatusReasonCode(): MedicationrequestStatusReasonCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomMedicationrequestStatusReasonConcept(): MedicationrequestStatusReasonConcept;
