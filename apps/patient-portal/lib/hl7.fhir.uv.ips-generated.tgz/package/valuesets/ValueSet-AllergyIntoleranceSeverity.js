/**
 * ValueSet: AllergyIntoleranceSeverity
 * URL: http://hl7.org/fhir/ValueSet/reaction-event-severity
 * Size: 3 concepts
 */
export const AllergyIntoleranceSeverityConcepts = [
    { code: "mild", system: "http://hl7.org/fhir/reaction-event-severity", display: "Mild" },
    { code: "moderate", system: "http://hl7.org/fhir/reaction-event-severity", display: "Moderate" },
    { code: "severe", system: "http://hl7.org/fhir/reaction-event-severity", display: "Severe" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidAllergyIntoleranceSeverityCode(code) {
    return AllergyIntoleranceSeverityConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getAllergyIntoleranceSeverityConcept(code) {
    return AllergyIntoleranceSeverityConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const AllergyIntoleranceSeverityCodes = AllergyIntoleranceSeverityConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomAllergyIntoleranceSeverityCode() {
    return AllergyIntoleranceSeverityCodes[Math.floor(Math.random() * AllergyIntoleranceSeverityCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomAllergyIntoleranceSeverityConcept() {
    return AllergyIntoleranceSeverityConcepts[Math.floor(Math.random() * AllergyIntoleranceSeverityConcepts.length)];
}
