/**
 * ValueSet: AbsentOrUnknownDevicesUvIps
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/absent-or-unknown-devices-uv-ips
 * Size: 2 concepts
 */
export const AbsentOrUnknownDevicesUvIpsConcepts = [
    { code: "no-device-info", system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips", display: "No information about device" },
    { code: "no-known-devices", system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips", display: "No known devices in use" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidAbsentOrUnknownDevicesUvIpsCode(code) {
    return AbsentOrUnknownDevicesUvIpsConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getAbsentOrUnknownDevicesUvIpsConcept(code) {
    return AbsentOrUnknownDevicesUvIpsConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const AbsentOrUnknownDevicesUvIpsCodes = AbsentOrUnknownDevicesUvIpsConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomAbsentOrUnknownDevicesUvIpsCode() {
    return AbsentOrUnknownDevicesUvIpsCodes[Math.floor(Math.random() * AbsentOrUnknownDevicesUvIpsCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomAbsentOrUnknownDevicesUvIpsConcept() {
    return AbsentOrUnknownDevicesUvIpsConcepts[Math.floor(Math.random() * AbsentOrUnknownDevicesUvIpsConcepts.length)];
}
