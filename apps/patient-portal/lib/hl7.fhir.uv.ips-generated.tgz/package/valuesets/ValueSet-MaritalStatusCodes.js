/**
 * ValueSet: Marital Status Codes
 * URL: http://hl7.org/fhir/ValueSet/marital-status
 * Size: 1 concepts
 */
export const MaritalStatusCodesConcepts = [
    { code: "UNK", system: "http://terminology.hl7.org/CodeSystem/v3-NullFlavor" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidMaritalStatusCodesCode(code) {
    return MaritalStatusCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getMaritalStatusCodesConcept(code) {
    return MaritalStatusCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const MaritalStatusCodesCodes = MaritalStatusCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomMaritalStatusCodesCode() {
    return MaritalStatusCodesCodes[Math.floor(Math.random() * MaritalStatusCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomMaritalStatusCodesConcept() {
    return MaritalStatusCodesConcepts[Math.floor(Math.random() * MaritalStatusCodesConcepts.length)];
}
