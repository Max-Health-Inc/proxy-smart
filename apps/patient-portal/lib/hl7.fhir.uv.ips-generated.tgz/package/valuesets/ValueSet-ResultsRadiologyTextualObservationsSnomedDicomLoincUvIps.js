/**
 * ValueSet: ResultsRadiologyTextualObservationsSnomedDicomLoincUvIps
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/results-radiology-txtobs-snomed-dicom-loinc-uv-ips
 * Size: 11 concepts
 */
export const ResultsRadiologyTextualObservationsSnomedDicomLoincUvIpsConcepts = [
    { code: "121065", system: "http://dicom.nema.org/resources/ontology/DCM", display: "Procedure Description" },
    { code: "121069", system: "http://dicom.nema.org/resources/ontology/DCM", display: "Previous Finding" },
    { code: "121071", system: "http://dicom.nema.org/resources/ontology/DCM", display: "Finding" },
    { code: "121073", system: "http://dicom.nema.org/resources/ontology/DCM", display: "Impression" },
    { code: "121075", system: "http://dicom.nema.org/resources/ontology/DCM", display: "Recommendation" },
    { code: "121077", system: "http://dicom.nema.org/resources/ontology/DCM", display: "Conclusion" },
    { code: "121110", system: "http://dicom.nema.org/resources/ontology/DCM", display: "Patient Presentation" },
    { code: "121111", system: "http://dicom.nema.org/resources/ontology/DCM", display: "Summary" },
    { code: "11329-0", system: "http://loinc.org", display: "History" },
    { code: "55115-0", system: "http://loinc.org", display: "Request" },
    { code: "116224001", system: "http://snomed.info/sct", display: "Complication of Procedure" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidResultsRadiologyTextualObservationsSnomedDicomLoincUvIpsCode(code) {
    return ResultsRadiologyTextualObservationsSnomedDicomLoincUvIpsConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getResultsRadiologyTextualObservationsSnomedDicomLoincUvIpsConcept(code) {
    return ResultsRadiologyTextualObservationsSnomedDicomLoincUvIpsConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ResultsRadiologyTextualObservationsSnomedDicomLoincUvIpsCodes = ResultsRadiologyTextualObservationsSnomedDicomLoincUvIpsConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomResultsRadiologyTextualObservationsSnomedDicomLoincUvIpsCode() {
    return ResultsRadiologyTextualObservationsSnomedDicomLoincUvIpsCodes[Math.floor(Math.random() * ResultsRadiologyTextualObservationsSnomedDicomLoincUvIpsCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomResultsRadiologyTextualObservationsSnomedDicomLoincUvIpsConcept() {
    return ResultsRadiologyTextualObservationsSnomedDicomLoincUvIpsConcepts[Math.floor(Math.random() * ResultsRadiologyTextualObservationsSnomedDicomLoincUvIpsConcepts.length)];
}
