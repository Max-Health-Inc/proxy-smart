/**
 * ValueSet: AbsentOrUnknownMedicationUvIps
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/absent-or-unknown-medications-uv-ips
 * Size: 2 concepts
 */
export const AbsentOrUnknownMedicationUvIpsConcepts = [
    { code: "no-medication-info", system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips", display: "No information about medications" },
    { code: "no-known-medications", system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips", display: "No known medications" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidAbsentOrUnknownMedicationUvIpsCode(code) {
    return AbsentOrUnknownMedicationUvIpsConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getAbsentOrUnknownMedicationUvIpsConcept(code) {
    return AbsentOrUnknownMedicationUvIpsConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const AbsentOrUnknownMedicationUvIpsCodes = AbsentOrUnknownMedicationUvIpsConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomAbsentOrUnknownMedicationUvIpsCode() {
    return AbsentOrUnknownMedicationUvIpsCodes[Math.floor(Math.random() * AbsentOrUnknownMedicationUvIpsCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomAbsentOrUnknownMedicationUvIpsConcept() {
    return AbsentOrUnknownMedicationUvIpsConcepts[Math.floor(Math.random() * AbsentOrUnknownMedicationUvIpsConcepts.length)];
}
