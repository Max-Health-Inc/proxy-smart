/**
 * ValueSet: AbsentOrUnknownAllergiesUvIps
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/absent-or-unknown-allergies-uv-ips
 * Size: 5 concepts
 */
export const AbsentOrUnknownAllergiesUvIpsConcepts = [
    { code: "no-allergy-info", system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips", display: "No information about allergies" },
    { code: "no-known-allergies", system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips", display: "No known allergies" },
    { code: "no-known-medication-allergies", system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips", display: "No known medication allergies" },
    { code: "no-known-environmental-allergies", system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips", display: "No known environmental allergies" },
    { code: "no-known-food-allergies", system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips", display: "No known food allergies" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidAbsentOrUnknownAllergiesUvIpsCode(code) {
    return AbsentOrUnknownAllergiesUvIpsConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getAbsentOrUnknownAllergiesUvIpsConcept(code) {
    return AbsentOrUnknownAllergiesUvIpsConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const AbsentOrUnknownAllergiesUvIpsCodes = AbsentOrUnknownAllergiesUvIpsConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomAbsentOrUnknownAllergiesUvIpsCode() {
    return AbsentOrUnknownAllergiesUvIpsCodes[Math.floor(Math.random() * AbsentOrUnknownAllergiesUvIpsCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomAbsentOrUnknownAllergiesUvIpsConcept() {
    return AbsentOrUnknownAllergiesUvIpsConcepts[Math.floor(Math.random() * AbsentOrUnknownAllergiesUvIpsConcepts.length)];
}
