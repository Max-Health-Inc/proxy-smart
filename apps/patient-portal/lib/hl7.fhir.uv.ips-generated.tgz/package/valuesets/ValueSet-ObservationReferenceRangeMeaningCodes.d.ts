/**
 * ValueSet: ObservationReferenceRangeMeaningCodes
 * URL: http://hl7.org/fhir/ValueSet/referencerange-meaning
 * Size: 2 concepts
 */
export declare const ObservationReferenceRangeMeaningCodesConcepts: readonly [{
    readonly code: "type";
    readonly system: "http://terminology.hl7.org/CodeSystem/referencerange-meaning";
    readonly display: "Type";
}, {
    readonly code: "endocrine";
    readonly system: "http://terminology.hl7.org/CodeSystem/referencerange-meaning";
    readonly display: "Endocrine";
}];
/** Union type of all valid codes in this ValueSet */
export type ObservationReferenceRangeMeaningCodesCode = "type" | "endocrine";
/** Type representing a concept from this ValueSet */
export type ObservationReferenceRangeMeaningCodesConcept = typeof ObservationReferenceRangeMeaningCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidObservationReferenceRangeMeaningCodesCode(code: string): code is ObservationReferenceRangeMeaningCodesCode;
/**
 * Get concept details by code
 */
export declare function getObservationReferenceRangeMeaningCodesConcept(code: string): ObservationReferenceRangeMeaningCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ObservationReferenceRangeMeaningCodesCodes: ("type" | "endocrine")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomObservationReferenceRangeMeaningCodesCode(): ObservationReferenceRangeMeaningCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomObservationReferenceRangeMeaningCodesConcept(): ObservationReferenceRangeMeaningCodesConcept;
