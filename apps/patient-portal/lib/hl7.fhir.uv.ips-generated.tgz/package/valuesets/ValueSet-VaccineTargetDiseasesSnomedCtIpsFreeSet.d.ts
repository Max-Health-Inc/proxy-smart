/**
 * ValueSet: VaccineTargetDiseasesSnomedCtIpsFreeSet
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/target-diseases-snomed-ct-ips-free-set
 * Size: Infinity concepts
 */
export declare const VaccineTargetDiseasesSnomedCtIpsFreeSetConcepts: readonly [{
    readonly code: "4834000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Typhoid fever";
}, {
    readonly code: "6142004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Influenza";
}, {
    readonly code: "14189004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Measles";
}, {
    readonly code: "23502006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Lyme disease";
}, {
    readonly code: "24662006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Influenza due to Influenza B virus";
}, {
    readonly code: "25225006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Disease due to Adenovirus";
}, {
    readonly code: "27836007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Pertussis";
}, {
    readonly code: "32398004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Bronchitis";
}, {
    readonly code: "36989005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Mumps";
}, {
    readonly code: "38907003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Varicella";
}, {
    readonly code: "40468003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Viral hepatitis, type A";
}, {
    readonly code: "50711007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Viral hepatitis C";
}, {
    readonly code: "56717001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Tuberculosis";
}, {
    readonly code: "66071002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Type B viral hepatitis";
}, {
    readonly code: "70036007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Haemophilus influenzae pneumonia";
}, {
    readonly code: "76902006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Tetanus";
}, {
    readonly code: "186150001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Enteritis due to rotavirus";
}, {
    readonly code: "240532009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Human papilloma virus infection";
}, {
    readonly code: "372244006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Malignant melanoma";
}, {
    readonly code: "398102009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Acute poliomyelitis";
}, {
    readonly code: "442438000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Influenza due to Influenza A virus";
}, {
    readonly code: "840539006";
    readonly system: "http://snomed.info/sct";
    readonly display: "COVID-19";
}];
/** String type (ValueSet too large for union type) */
export type VaccineTargetDiseasesSnomedCtIpsFreeSetCode = string;
/** Type representing a concept from this ValueSet */
export type VaccineTargetDiseasesSnomedCtIpsFreeSetConcept = typeof VaccineTargetDiseasesSnomedCtIpsFreeSetConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidVaccineTargetDiseasesSnomedCtIpsFreeSetCode(code: string): code is VaccineTargetDiseasesSnomedCtIpsFreeSetCode;
/**
 * Get concept details by code
 */
export declare function getVaccineTargetDiseasesSnomedCtIpsFreeSetConcept(code: string): VaccineTargetDiseasesSnomedCtIpsFreeSetConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const VaccineTargetDiseasesSnomedCtIpsFreeSetCodes: ("840539006" | "442438000" | "398102009" | "372244006" | "240532009" | "186150001" | "76902006" | "70036007" | "66071002" | "56717001" | "50711007" | "40468003" | "38907003" | "36989005" | "32398004" | "27836007" | "25225006" | "24662006" | "23502006" | "14189004" | "6142004" | "4834000")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomVaccineTargetDiseasesSnomedCtIpsFreeSetCode(): VaccineTargetDiseasesSnomedCtIpsFreeSetCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomVaccineTargetDiseasesSnomedCtIpsFreeSetConcept(): VaccineTargetDiseasesSnomedCtIpsFreeSetConcept;
