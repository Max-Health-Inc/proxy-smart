/**
 * ValueSet: ImagingStudySeriesPerformerFunction
 * URL: http://hl7.org/fhir/ValueSet/series-performer-function
 * Size: 5 concepts
 */
export const ImagingStudySeriesPerformerFunctionConcepts = [
    { code: "CON", system: "http://terminology.hl7.org/CodeSystem/v3-ParticipationType", display: "consultant" },
    { code: "VRF", system: "http://terminology.hl7.org/CodeSystem/v3-ParticipationType", display: "verifier" },
    { code: "PRF", system: "http://terminology.hl7.org/CodeSystem/v3-ParticipationType", display: "performer" },
    { code: "SPRF", system: "http://terminology.hl7.org/CodeSystem/v3-ParticipationType", display: "secondary performer" },
    { code: "REF", system: "http://terminology.hl7.org/CodeSystem/v3-ParticipationType", display: "referrer" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidImagingStudySeriesPerformerFunctionCode(code) {
    return ImagingStudySeriesPerformerFunctionConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getImagingStudySeriesPerformerFunctionConcept(code) {
    return ImagingStudySeriesPerformerFunctionConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ImagingStudySeriesPerformerFunctionCodes = ImagingStudySeriesPerformerFunctionConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomImagingStudySeriesPerformerFunctionCode() {
    return ImagingStudySeriesPerformerFunctionCodes[Math.floor(Math.random() * ImagingStudySeriesPerformerFunctionCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomImagingStudySeriesPerformerFunctionConcept() {
    return ImagingStudySeriesPerformerFunctionConcepts[Math.floor(Math.random() * ImagingStudySeriesPerformerFunctionConcepts.length)];
}
