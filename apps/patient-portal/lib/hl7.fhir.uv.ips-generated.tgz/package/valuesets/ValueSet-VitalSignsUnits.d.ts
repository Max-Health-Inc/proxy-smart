/**
 * ValueSet: VitalSignsUnits
 * URL: http://hl7.org/fhir/ValueSet/ucum-vitals-common
 * Size: 12 concepts
 */
export declare const VitalSignsUnitsConcepts: readonly [{
    readonly code: "%";
    readonly system: "http://unitsofmeasure.org";
    readonly display: "percent";
}, {
    readonly code: "cm";
    readonly system: "http://unitsofmeasure.org";
    readonly display: "centimeter";
}, {
    readonly code: "[in_i]";
    readonly system: "http://unitsofmeasure.org";
    readonly display: "inch (international)";
}, {
    readonly code: "kg";
    readonly system: "http://unitsofmeasure.org";
    readonly display: "kilogram";
}, {
    readonly code: "g";
    readonly system: "http://unitsofmeasure.org";
    readonly display: "gram";
}, {
    readonly code: "[lb_av]";
    readonly system: "http://unitsofmeasure.org";
    readonly display: "pound (US and British)";
}, {
    readonly code: "Cel";
    readonly system: "http://unitsofmeasure.org";
    readonly display: "degree Celsius";
}, {
    readonly code: "[degF]";
    readonly system: "http://unitsofmeasure.org";
    readonly display: "degree Fahrenheit";
}, {
    readonly code: "mm[Hg]";
    readonly system: "http://unitsofmeasure.org";
    readonly display: "millimeter of mercury";
}, {
    readonly code: "/min";
    readonly system: "http://unitsofmeasure.org";
    readonly display: "per minute";
}, {
    readonly code: "kg/m2";
    readonly system: "http://unitsofmeasure.org";
    readonly display: "kilogram / (meter ^ 2)";
}, {
    readonly code: "m2";
    readonly system: "http://unitsofmeasure.org";
    readonly display: "square meter";
}];
/** Union type of all valid codes in this ValueSet */
export type VitalSignsUnitsCode = "%" | "cm" | "[in_i]" | "kg" | "g" | "[lb_av]" | "Cel" | "[degF]" | "mm[Hg]" | "/min" | "kg/m2" | "m2";
/** Type representing a concept from this ValueSet */
export type VitalSignsUnitsConcept = typeof VitalSignsUnitsConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidVitalSignsUnitsCode(code: string): code is VitalSignsUnitsCode;
/**
 * Get concept details by code
 */
export declare function getVitalSignsUnitsConcept(code: string): VitalSignsUnitsConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const VitalSignsUnitsCodes: ("/min" | "Cel" | "kg" | "cm" | "kg/m2" | "%" | "mm[Hg]" | "[in_i]" | "g" | "[lb_av]" | "[degF]" | "m2")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomVitalSignsUnitsCode(): VitalSignsUnitsCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomVitalSignsUnitsConcept(): VitalSignsUnitsConcept;
