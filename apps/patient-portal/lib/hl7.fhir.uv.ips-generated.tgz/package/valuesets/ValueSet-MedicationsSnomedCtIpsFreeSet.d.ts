/**
 * ValueSet: MedicationsSnomedCtIpsFreeSet
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/medications-snomed-ct-ips-free-set
 * Size: Infinity concepts
 */
export declare const MedicationsSnomedCtIpsFreeSetConcepts: readonly [{
    readonly code: "774702006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Bacillus Calmette-Guerin antigen only product";
}, {
    readonly code: "418268006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Bacillus Calmette-Guerin antigen-containing product";
}, {
    readonly code: "346469000";
    readonly system: "http://snomed.info/sct";
    readonly display: "House mite allergy vaccine";
}, {
    readonly code: "346468008";
    readonly system: "http://snomed.info/sct";
    readonly display: "House dust allergy vaccine";
}, {
    readonly code: "346467003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Horse allergy vaccine";
}, {
    readonly code: "346405008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Dog allergy vaccine";
}, {
    readonly code: "346364006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Cat allergy vaccine";
}, {
    readonly code: "346313005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Allergen extract vaccine";
}, {
    readonly code: "320835005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Pollen allergy preparations";
}, {
    readonly code: "63338004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Drug flavoring";
}];
/** String type (ValueSet too large for union type) */
export type MedicationsSnomedCtIpsFreeSetCode = string;
/** Type representing a concept from this ValueSet */
export type MedicationsSnomedCtIpsFreeSetConcept = typeof MedicationsSnomedCtIpsFreeSetConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidMedicationsSnomedCtIpsFreeSetCode(code: string): code is MedicationsSnomedCtIpsFreeSetCode;
/**
 * Get concept details by code
 */
export declare function getMedicationsSnomedCtIpsFreeSetConcept(code: string): MedicationsSnomedCtIpsFreeSetConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const MedicationsSnomedCtIpsFreeSetCodes: ("63338004" | "320835005" | "346313005" | "346364006" | "346405008" | "346467003" | "346468008" | "346469000" | "418268006" | "774702006")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomMedicationsSnomedCtIpsFreeSetCode(): MedicationsSnomedCtIpsFreeSetCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomMedicationsSnomedCtIpsFreeSetConcept(): MedicationsSnomedCtIpsFreeSetConcept;
