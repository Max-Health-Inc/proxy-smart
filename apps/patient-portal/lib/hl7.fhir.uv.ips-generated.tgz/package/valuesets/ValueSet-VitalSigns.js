/**
 * ValueSet: VitalSigns
 * URL: http://hl7.org/fhir/ValueSet/observation-vitalsignresult
 * Size: 13 concepts
 */
export const VitalSignsConcepts = [
    { code: "85353-1", system: "http://loinc.org" },
    { code: "9279-1", system: "http://loinc.org" },
    { code: "8867-4", system: "http://loinc.org" },
    { code: "2708-6", system: "http://loinc.org" },
    { code: "8310-5", system: "http://loinc.org" },
    { code: "8302-2", system: "http://loinc.org" },
    { code: "9843-4", system: "http://loinc.org" },
    { code: "29463-7", system: "http://loinc.org" },
    { code: "39156-5", system: "http://loinc.org" },
    { code: "85354-9", system: "http://loinc.org" },
    { code: "8480-6", system: "http://loinc.org" },
    { code: "8462-4", system: "http://loinc.org" },
    { code: "8478-0", system: "http://loinc.org" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidVitalSignsCode(code) {
    return VitalSignsConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getVitalSignsConcept(code) {
    return VitalSignsConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const VitalSignsCodes = VitalSignsConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomVitalSignsCode() {
    return VitalSignsCodes[Math.floor(Math.random() * VitalSignsCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomVitalSignsConcept() {
    return VitalSignsConcepts[Math.floor(Math.random() * VitalSignsConcepts.length)];
}
