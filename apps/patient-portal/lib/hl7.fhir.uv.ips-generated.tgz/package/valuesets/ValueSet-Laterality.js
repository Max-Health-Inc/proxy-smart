/**
 * ValueSet: Laterality
 * URL: http://hl7.org/fhir/ValueSet/bodysite-laterality
 * Size: 3 concepts
 */
export const LateralityConcepts = [
    { code: "419161000", system: "http://snomed.info/sct", display: "Unilateral left" },
    { code: "419465000", system: "http://snomed.info/sct", display: "Unilateral right" },
    { code: "51440002", system: "http://snomed.info/sct", display: "Bilateral" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidLateralityCode(code) {
    return LateralityConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getLateralityConcept(code) {
    return LateralityConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const LateralityCodes = LateralityConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomLateralityCode() {
    return LateralityCodes[Math.floor(Math.random() * LateralityCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomLateralityConcept() {
    return LateralityConcepts[Math.floor(Math.random() * LateralityConcepts.length)];
}
