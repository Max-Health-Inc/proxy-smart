/**
 * ValueSet: ProblemSeverityUvIps
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/condition-severity-uv-ips
 * Size: 3 concepts
 */
export const ProblemSeverityUvIpsConcepts = [
    { code: "LA6752-5", system: "http://loinc.org", display: "Mild" },
    { code: "LA6751-7", system: "http://loinc.org", display: "Moderate" },
    { code: "LA6750-9", system: "http://loinc.org", display: "Severe" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidProblemSeverityUvIpsCode(code) {
    return ProblemSeverityUvIpsConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getProblemSeverityUvIpsConcept(code) {
    return ProblemSeverityUvIpsConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ProblemSeverityUvIpsCodes = ProblemSeverityUvIpsConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomProblemSeverityUvIpsCode() {
    return ProblemSeverityUvIpsCodes[Math.floor(Math.random() * ProblemSeverityUvIpsCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomProblemSeverityUvIpsConcept() {
    return ProblemSeverityUvIpsConcepts[Math.floor(Math.random() * ProblemSeverityUvIpsConcepts.length)];
}
