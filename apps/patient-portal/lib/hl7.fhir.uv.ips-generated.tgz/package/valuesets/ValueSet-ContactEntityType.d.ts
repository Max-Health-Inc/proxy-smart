/**
 * ValueSet: ContactEntityType
 * URL: http://hl7.org/fhir/ValueSet/contactentity-type
 * Size: 6 concepts
 */
export declare const ContactEntityTypeConcepts: readonly [{
    readonly code: "BILL";
    readonly system: "http://terminology.hl7.org/CodeSystem/contactentity-type";
    readonly display: "Billing";
}, {
    readonly code: "ADMIN";
    readonly system: "http://terminology.hl7.org/CodeSystem/contactentity-type";
    readonly display: "Administrative";
}, {
    readonly code: "HR";
    readonly system: "http://terminology.hl7.org/CodeSystem/contactentity-type";
    readonly display: "Human Resource";
}, {
    readonly code: "PAYOR";
    readonly system: "http://terminology.hl7.org/CodeSystem/contactentity-type";
    readonly display: "Payor";
}, {
    readonly code: "PATINF";
    readonly system: "http://terminology.hl7.org/CodeSystem/contactentity-type";
    readonly display: "Patient";
}, {
    readonly code: "PRESS";
    readonly system: "http://terminology.hl7.org/CodeSystem/contactentity-type";
    readonly display: "Press";
}];
/** Union type of all valid codes in this ValueSet */
export type ContactEntityTypeCode = "BILL" | "ADMIN" | "HR" | "PAYOR" | "PATINF" | "PRESS";
/** Type representing a concept from this ValueSet */
export type ContactEntityTypeConcept = typeof ContactEntityTypeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidContactEntityTypeCode(code: string): code is ContactEntityTypeCode;
/**
 * Get concept details by code
 */
export declare function getContactEntityTypeConcept(code: string): ContactEntityTypeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ContactEntityTypeCodes: ("PAYOR" | "BILL" | "ADMIN" | "HR" | "PATINF" | "PRESS")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomContactEntityTypeCode(): ContactEntityTypeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomContactEntityTypeConcept(): ContactEntityTypeConcept;
