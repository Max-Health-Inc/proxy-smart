/**
 * ValueSet: medicationRequest Category Codes
 * URL: http://hl7.org/fhir/ValueSet/medicationrequest-category
 * Size: 4 concepts
 */
export const MedicationRequestCategoryCodesConcepts = [
    { code: "inpatient", system: "http://terminology.hl7.org/CodeSystem/medicationrequest-category", display: "Inpatient" },
    { code: "outpatient", system: "http://terminology.hl7.org/CodeSystem/medicationrequest-category", display: "Outpatient" },
    { code: "community", system: "http://terminology.hl7.org/CodeSystem/medicationrequest-category", display: "Community" },
    { code: "discharge", system: "http://terminology.hl7.org/CodeSystem/medicationrequest-category", display: "Discharge" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidMedicationRequestCategoryCodesCode(code) {
    return MedicationRequestCategoryCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getMedicationRequestCategoryCodesConcept(code) {
    return MedicationRequestCategoryCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const MedicationRequestCategoryCodesCodes = MedicationRequestCategoryCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomMedicationRequestCategoryCodesCode() {
    return MedicationRequestCategoryCodesCodes[Math.floor(Math.random() * MedicationRequestCategoryCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomMedicationRequestCategoryCodesConcept() {
    return MedicationRequestCategoryCodesConcepts[Math.floor(Math.random() * MedicationRequestCategoryCodesConcepts.length)];
}
