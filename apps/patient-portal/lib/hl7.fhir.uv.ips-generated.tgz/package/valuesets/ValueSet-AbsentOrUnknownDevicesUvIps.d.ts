/**
 * ValueSet: AbsentOrUnknownDevicesUvIps
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/absent-or-unknown-devices-uv-ips
 * Size: 2 concepts
 */
export declare const AbsentOrUnknownDevicesUvIpsConcepts: readonly [{
    readonly code: "no-device-info";
    readonly system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips";
    readonly display: "No information about device";
}, {
    readonly code: "no-known-devices";
    readonly system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips";
    readonly display: "No known devices in use";
}];
/** Union type of all valid codes in this ValueSet */
export type AbsentOrUnknownDevicesUvIpsCode = "no-device-info" | "no-known-devices";
/** Type representing a concept from this ValueSet */
export type AbsentOrUnknownDevicesUvIpsConcept = typeof AbsentOrUnknownDevicesUvIpsConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidAbsentOrUnknownDevicesUvIpsCode(code: string): code is AbsentOrUnknownDevicesUvIpsCode;
/**
 * Get concept details by code
 */
export declare function getAbsentOrUnknownDevicesUvIpsConcept(code: string): AbsentOrUnknownDevicesUvIpsConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const AbsentOrUnknownDevicesUvIpsCodes: ("no-device-info" | "no-known-devices")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomAbsentOrUnknownDevicesUvIpsCode(): AbsentOrUnknownDevicesUvIpsCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomAbsentOrUnknownDevicesUvIpsConcept(): AbsentOrUnknownDevicesUvIpsConcept;
