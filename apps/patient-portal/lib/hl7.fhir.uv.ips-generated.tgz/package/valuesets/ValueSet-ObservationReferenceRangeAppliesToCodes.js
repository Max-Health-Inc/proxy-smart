/**
 * ValueSet: ObservationReferenceRangeAppliesToCodes
 * URL: http://hl7.org/fhir/ValueSet/referencerange-appliesto
 * Size: 3 concepts
 */
export const ObservationReferenceRangeAppliesToCodesConcepts = [
    { code: "248153007", system: "http://snomed.info/sct" },
    { code: "248152002", system: "http://snomed.info/sct" },
    { code: "77386006", system: "http://snomed.info/sct" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidObservationReferenceRangeAppliesToCodesCode(code) {
    return ObservationReferenceRangeAppliesToCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getObservationReferenceRangeAppliesToCodesConcept(code) {
    return ObservationReferenceRangeAppliesToCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ObservationReferenceRangeAppliesToCodesCodes = ObservationReferenceRangeAppliesToCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomObservationReferenceRangeAppliesToCodesCode() {
    return ObservationReferenceRangeAppliesToCodesCodes[Math.floor(Math.random() * ObservationReferenceRangeAppliesToCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomObservationReferenceRangeAppliesToCodesConcept() {
    return ObservationReferenceRangeAppliesToCodesConcepts[Math.floor(Math.random() * ObservationReferenceRangeAppliesToCodesConcepts.length)];
}
