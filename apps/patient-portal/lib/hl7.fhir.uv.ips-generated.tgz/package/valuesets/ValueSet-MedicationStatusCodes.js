/**
 * ValueSet: Medication Status Codes
 * URL: http://hl7.org/fhir/ValueSet/medication-statement-status
 * Size: 8 concepts
 */
export const MedicationStatusCodesConcepts = [
    { code: "active", system: "http://hl7.org/fhir/CodeSystem/medication-statement-status", display: "Active" },
    { code: "completed", system: "http://hl7.org/fhir/CodeSystem/medication-statement-status", display: "Completed" },
    { code: "entered-in-error", system: "http://hl7.org/fhir/CodeSystem/medication-statement-status", display: "Entered in Error" },
    { code: "intended", system: "http://hl7.org/fhir/CodeSystem/medication-statement-status", display: "Intended" },
    { code: "stopped", system: "http://hl7.org/fhir/CodeSystem/medication-statement-status", display: "Stopped" },
    { code: "on-hold", system: "http://hl7.org/fhir/CodeSystem/medication-statement-status", display: "On Hold" },
    { code: "unknown", system: "http://hl7.org/fhir/CodeSystem/medication-statement-status", display: "Unknown" },
    { code: "not-taken", system: "http://hl7.org/fhir/CodeSystem/medication-statement-status", display: "Not Taken" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidMedicationStatusCodesCode(code) {
    return MedicationStatusCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getMedicationStatusCodesConcept(code) {
    return MedicationStatusCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const MedicationStatusCodesCodes = MedicationStatusCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomMedicationStatusCodesCode() {
    return MedicationStatusCodesCodes[Math.floor(Math.random() * MedicationStatusCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomMedicationStatusCodesConcept() {
    return MedicationStatusCodesConcepts[Math.floor(Math.random() * MedicationStatusCodesConcepts.length)];
}
