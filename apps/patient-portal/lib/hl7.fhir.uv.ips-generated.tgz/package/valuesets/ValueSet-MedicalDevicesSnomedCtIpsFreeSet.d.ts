/**
 * ValueSet: MedicalDevicesSnomedCtIpsFreeSet
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/medical-devices-snomed-ct-ips-free-set
 * Size: Infinity concepts
 */
export declare const MedicalDevicesSnomedCtIpsFreeSetConcepts: readonly [{
    readonly code: "705991002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Mechanical cardiac valve prosthesis";
}, {
    readonly code: "705865004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Implantable ankle prosthesis";
}, {
    readonly code: "469997005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Maxillofacial prosthesis";
}, {
    readonly code: "429798007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Artificial vertebral disc";
}, {
    readonly code: "424921004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Permanent cardiac pacemaker, device";
}, {
    readonly code: "423449009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Pulmonary valve prosthesis";
}, {
    readonly code: "421168009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Eye sphere implant";
}, {
    readonly code: "414580007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Laryngeal keel";
}, {
    readonly code: "413766009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Carotid artery stent";
}, {
    readonly code: "408099007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Suture";
}, {
    readonly code: "360329004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Dacron graft";
}, {
    readonly code: "360145006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Bone prosthesis";
}, {
    readonly code: "360123005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Biliary stent";
}, {
    readonly code: "360100007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Tracheal stent";
}, {
    readonly code: "360070009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Laryngeal implant";
}, {
    readonly code: "360058005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Intraventricular pump";
}, {
    readonly code: "360046005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Arterial stent";
}, {
    readonly code: "360041000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Implanted drug delivery system";
}, {
    readonly code: "314523008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Joint implant";
}, {
    readonly code: "304186003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hand joint implant";
}, {
    readonly code: "304185004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Foot joint implant";
}, {
    readonly code: "304124003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Shoulder joint implant";
}, {
    readonly code: "304121006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Femoral head prosthesis";
}, {
    readonly code: "304120007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Total hip replacement prosthesis";
}, {
    readonly code: "304070008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Body wall implant";
}, {
    readonly code: "303947005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Rod fixation system";
}, {
    readonly code: "303726000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Shoulder joint prosthesis";
}, {
    readonly code: "303619008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Cardiac implant";
}, {
    readonly code: "303618000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Nervous system implant";
}, {
    readonly code: "303617005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Vascular implant";
}, {
    readonly code: "303608005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Ophthalmological implant";
}, {
    readonly code: "303533002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hip joint implant";
}, {
    readonly code: "303515008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Orbital implant";
}, {
    readonly code: "303503009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Musculoskeletal implant";
}, {
    readonly code: "303500007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Auditory implant";
}, {
    readonly code: "303499003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Gastrointestinal implant";
}, {
    readonly code: "303497001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Urogenital implant";
}, {
    readonly code: "303490004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Cardiovascular implant";
}, {
    readonly code: "303277008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Fallopian tube prosthesis";
}, {
    readonly code: "286576009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Urethral stent";
}, {
    readonly code: "286558002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Ureteric stent";
}, {
    readonly code: "268460000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Intrauterine contraceptive device";
}, {
    readonly code: "264824009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Cardiac conduit";
}, {
    readonly code: "258593008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Ventricular shunt";
}, {
    readonly code: "257366006";
    readonly system: "http://snomed.info/sct";
    readonly display: "JJ stent";
}, {
    readonly code: "257343005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Xenograft cardiac valve";
}, {
    readonly code: "257283004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Valved cardiac conduit";
}, {
    readonly code: "257282009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Non-valved conduit";
}, {
    readonly code: "257275005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Spinal cage";
}, {
    readonly code: "118425005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Ventricular reservoir";
}, {
    readonly code: "118374007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Silicone implant";
}, {
    readonly code: "102314001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Embolization coil";
}, {
    readonly code: "102303004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Vascular prosthesis";
}, {
    readonly code: "90134004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Metal periosteal implant";
}, {
    readonly code: "84683006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Aortic valve prosthesis";
}, {
    readonly code: "77777004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Bone staple";
}, {
    readonly code: "77444004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Bone pin";
}, {
    readonly code: "74444006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Limb prosthesis";
}, {
    readonly code: "72506001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Implantable defibrillator";
}, {
    readonly code: "68183006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Bone screw";
}, {
    readonly code: "67270000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hip prosthesis";
}, {
    readonly code: "63289001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Surgical metal nail, device";
}, {
    readonly code: "63112008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Bone wire";
}, {
    readonly code: "53671008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Gastric balloon";
}, {
    readonly code: "45633005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Peritoneal dialyzer";
}, {
    readonly code: "43252007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Cochlear prosthesis";
}, {
    readonly code: "31031000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Orthopedic internal fixation system";
}, {
    readonly code: "25937001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Neurostimulator";
}, {
    readonly code: "17107009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Mitral valve prosthesis";
}, {
    readonly code: "14423008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Adhesive bandage";
}, {
    readonly code: "2282003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Breast implant";
}, {
    readonly code: "271003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Bone plate";
}];
/** String type (ValueSet too large for union type) */
export type MedicalDevicesSnomedCtIpsFreeSetCode = string;
/** Type representing a concept from this ValueSet */
export type MedicalDevicesSnomedCtIpsFreeSetConcept = typeof MedicalDevicesSnomedCtIpsFreeSetConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidMedicalDevicesSnomedCtIpsFreeSetCode(code: string): code is MedicalDevicesSnomedCtIpsFreeSetCode;
/**
 * Get concept details by code
 */
export declare function getMedicalDevicesSnomedCtIpsFreeSetConcept(code: string): MedicalDevicesSnomedCtIpsFreeSetConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const MedicalDevicesSnomedCtIpsFreeSetCodes: ("271003" | "2282003" | "705991002" | "705865004" | "469997005" | "429798007" | "424921004" | "423449009" | "421168009" | "414580007" | "413766009" | "408099007" | "360329004" | "360145006" | "360123005" | "360100007" | "360070009" | "360058005" | "360046005" | "360041000" | "314523008" | "304186003" | "304185004" | "304124003" | "304121006" | "304120007" | "304070008" | "303947005" | "303726000" | "303619008" | "303618000" | "303617005" | "303608005" | "303533002" | "303515008" | "303503009" | "303500007" | "303499003" | "303497001" | "303490004" | "303277008" | "286576009" | "286558002" | "268460000" | "264824009" | "258593008" | "257366006" | "257343005" | "257283004" | "257282009" | "257275005" | "118425005" | "118374007" | "102314001" | "102303004" | "90134004" | "84683006" | "77777004" | "77444004" | "74444006" | "72506001" | "68183006" | "67270000" | "63289001" | "63112008" | "53671008" | "45633005" | "43252007" | "31031000" | "25937001" | "17107009" | "14423008")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomMedicalDevicesSnomedCtIpsFreeSetCode(): MedicalDevicesSnomedCtIpsFreeSetCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomMedicalDevicesSnomedCtIpsFreeSetConcept(): MedicalDevicesSnomedCtIpsFreeSetConcept;
