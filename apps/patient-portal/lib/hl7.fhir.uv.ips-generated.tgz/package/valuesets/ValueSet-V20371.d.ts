/**
 * ValueSet: v2-0371
 * URL: http://terminology.hl7.org/ValueSet/v2-0371
 * Size: 57 concepts
 */
export declare const V20371Concepts: readonly [{
    readonly code: "ACDA";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "ACDB";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "ACET";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "AMIES";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "BACTM";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "BF10";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "BOR";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "BOUIN";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "BSKM";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "C32";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "C38";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "CARS";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "CARY";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "CHLTM";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "CTAD";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "EDTK";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "EDTK15";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "EDTK75";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "EDTN";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "ENT";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "ENT+";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "F10";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "FDP";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "FL10";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "FL100";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "HCL6";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "HEPA";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "HEPL";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "HEPN";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "HNO3";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "JKM";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "KARN";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "KOX";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "LIA";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "M4";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "M4RT";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "M5";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "MICHTM";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "MMDTM";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "NAF";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "NAPS";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "NONE";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "PAGE";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "PHENOL";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "PVA";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "RLM";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "SILICA";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "SPS";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "SST";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "STUTM";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "THROM";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "THYMOL";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "THYO";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "TOLU";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "URETM";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "VIRTM";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}, {
    readonly code: "WEST";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0371";
}];
/** String type (ValueSet too large for union type) */
export type V20371Code = string;
/** Type representing a concept from this ValueSet */
export type V20371Concept = typeof V20371Concepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidV20371Code(code: string): code is V20371Code;
/**
 * Get concept details by code
 */
export declare function getV20371Concept(code: string): V20371Concept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const V20371Codes: ("SPS" | "ACDA" | "ACDB" | "ACET" | "AMIES" | "BACTM" | "BF10" | "BOR" | "BOUIN" | "BSKM" | "C32" | "C38" | "CARS" | "CARY" | "CHLTM" | "CTAD" | "EDTK" | "EDTK15" | "EDTK75" | "EDTN" | "ENT" | "ENT+" | "F10" | "FDP" | "FL10" | "FL100" | "HCL6" | "HEPA" | "HEPL" | "HEPN" | "HNO3" | "JKM" | "KARN" | "KOX" | "LIA" | "M4" | "M4RT" | "M5" | "MICHTM" | "MMDTM" | "NAF" | "NAPS" | "NONE" | "PAGE" | "PHENOL" | "PVA" | "RLM" | "SILICA" | "SST" | "STUTM" | "THROM" | "THYMOL" | "THYO" | "TOLU" | "URETM" | "VIRTM" | "WEST")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomV20371Code(): V20371Code;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomV20371Concept(): V20371Concept;
