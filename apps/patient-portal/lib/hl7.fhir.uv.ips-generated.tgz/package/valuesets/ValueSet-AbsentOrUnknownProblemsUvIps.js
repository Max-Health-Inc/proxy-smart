/**
 * ValueSet: AbsentOrUnknownProblemsUvIps
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/absent-or-unknown-problems-uv-ips
 * Size: 2 concepts
 */
export const AbsentOrUnknownProblemsUvIpsConcepts = [
    { code: "no-problem-info", system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips", display: "No information about current problems" },
    { code: "no-known-problems", system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips", display: "No known problems" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidAbsentOrUnknownProblemsUvIpsCode(code) {
    return AbsentOrUnknownProblemsUvIpsConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getAbsentOrUnknownProblemsUvIpsConcept(code) {
    return AbsentOrUnknownProblemsUvIpsConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const AbsentOrUnknownProblemsUvIpsCodes = AbsentOrUnknownProblemsUvIpsConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomAbsentOrUnknownProblemsUvIpsCode() {
    return AbsentOrUnknownProblemsUvIpsCodes[Math.floor(Math.random() * AbsentOrUnknownProblemsUvIpsCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomAbsentOrUnknownProblemsUvIpsConcept() {
    return AbsentOrUnknownProblemsUvIpsConcepts[Math.floor(Math.random() * AbsentOrUnknownProblemsUvIpsConcepts.length)];
}
