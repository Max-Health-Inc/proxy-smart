/**
 * ValueSet: ResultsBloodGroupSnomedCtIpsFreeSet
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/results-blood-group-snomed-ct-ips-free-set
 * Size: Infinity concepts
 */
export declare const ResultsBloodGroupSnomedCtIpsFreeSetConcepts: readonly [{
    readonly code: "278154007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Blood group AB Rh(D) negative";
}, {
    readonly code: "278153001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Blood group B Rh(D) negative";
}, {
    readonly code: "278152006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Blood group A Rh(D) negative";
}, {
    readonly code: "278151004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Blood group AB Rh(D) positive";
}, {
    readonly code: "278150003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Blood group B Rh(D) positive";
}, {
    readonly code: "278149003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Blood group A Rh(D) positive";
}, {
    readonly code: "278148006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Blood group O Rh(D) negative";
}, {
    readonly code: "278147001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Blood group O Rh(D) positive";
}, {
    readonly code: "165746003";
    readonly system: "http://snomed.info/sct";
    readonly display: "RhD negative";
}, {
    readonly code: "165743006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Blood group AB";
}, {
    readonly code: "112149005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Blood group B";
}, {
    readonly code: "112144000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Blood group A";
}, {
    readonly code: "58460004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Blood group O";
}];
/** String type (ValueSet too large for union type) */
export type ResultsBloodGroupSnomedCtIpsFreeSetCode = string;
/** Type representing a concept from this ValueSet */
export type ResultsBloodGroupSnomedCtIpsFreeSetConcept = typeof ResultsBloodGroupSnomedCtIpsFreeSetConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidResultsBloodGroupSnomedCtIpsFreeSetCode(code: string): code is ResultsBloodGroupSnomedCtIpsFreeSetCode;
/**
 * Get concept details by code
 */
export declare function getResultsBloodGroupSnomedCtIpsFreeSetConcept(code: string): ResultsBloodGroupSnomedCtIpsFreeSetConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ResultsBloodGroupSnomedCtIpsFreeSetCodes: ("278154007" | "278153001" | "278152006" | "278151004" | "278150003" | "278149003" | "278148006" | "278147001" | "165746003" | "165743006" | "112149005" | "112144000" | "58460004")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomResultsBloodGroupSnomedCtIpsFreeSetCode(): ResultsBloodGroupSnomedCtIpsFreeSetCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomResultsBloodGroupSnomedCtIpsFreeSetConcept(): ResultsBloodGroupSnomedCtIpsFreeSetConcept;
