/**
 * ValueSet: ImmunizationFunctionCodes
 * URL: http://hl7.org/fhir/ValueSet/immunization-function
 * Size: 2 concepts
 */
export const ImmunizationFunctionCodesConcepts = [
    { code: "OP", system: "http://terminology.hl7.org/CodeSystem/v2-0443" },
    { code: "AP", system: "http://terminology.hl7.org/CodeSystem/v2-0443" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidImmunizationFunctionCodesCode(code) {
    return ImmunizationFunctionCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getImmunizationFunctionCodesConcept(code) {
    return ImmunizationFunctionCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ImmunizationFunctionCodesCodes = ImmunizationFunctionCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomImmunizationFunctionCodesCode() {
    return ImmunizationFunctionCodesCodes[Math.floor(Math.random() * ImmunizationFunctionCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomImmunizationFunctionCodesConcept() {
    return ImmunizationFunctionCodesConcepts[Math.floor(Math.random() * ImmunizationFunctionCodesConcepts.length)];
}
