/**
 * ValueSet: ResultsSpecimenCollectionMethodUvIps
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/results-specimen-collection-method-uv-ips
 * Size: 10 concepts
 */
export declare const ResultsSpecimenCollectionMethodUvIpsConcepts: readonly [{
    readonly code: "129316008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Aspiration - action";
}, {
    readonly code: "129314006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Biopsy - action";
}, {
    readonly code: "129300006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Puncture - action";
}, {
    readonly code: "129304002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Excision - action";
}, {
    readonly code: "129323009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Scraping - action";
}, {
    readonly code: "73416001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Urine specimen collection, clean catch";
}, {
    readonly code: "225113003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Timed urine collection";
}, {
    readonly code: "70777001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Urine specimen collection, catheterized";
}, {
    readonly code: "386089008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Collection of coughed sputum";
}, {
    readonly code: "278450005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Finger-prick sampling";
}];
/** Union type of all valid codes in this ValueSet */
export type ResultsSpecimenCollectionMethodUvIpsCode = "129316008" | "129314006" | "129300006" | "129304002" | "129323009" | "73416001" | "225113003" | "70777001" | "386089008" | "278450005";
/** Type representing a concept from this ValueSet */
export type ResultsSpecimenCollectionMethodUvIpsConcept = typeof ResultsSpecimenCollectionMethodUvIpsConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidResultsSpecimenCollectionMethodUvIpsCode(code: string): code is ResultsSpecimenCollectionMethodUvIpsCode;
/**
 * Get concept details by code
 */
export declare function getResultsSpecimenCollectionMethodUvIpsConcept(code: string): ResultsSpecimenCollectionMethodUvIpsConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ResultsSpecimenCollectionMethodUvIpsCodes: ("129314006" | "129316008" | "129300006" | "129304002" | "129323009" | "73416001" | "225113003" | "70777001" | "386089008" | "278450005")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomResultsSpecimenCollectionMethodUvIpsCode(): ResultsSpecimenCollectionMethodUvIpsCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomResultsSpecimenCollectionMethodUvIpsConcept(): ResultsSpecimenCollectionMethodUvIpsConcept;
