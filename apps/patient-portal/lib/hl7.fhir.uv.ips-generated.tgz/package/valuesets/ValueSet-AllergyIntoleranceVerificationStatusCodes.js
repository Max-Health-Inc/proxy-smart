/**
 * ValueSet: AllergyIntoleranceVerificationStatusCodes
 * URL: http://hl7.org/fhir/ValueSet/allergyintolerance-verification
 * Size: 4 concepts
 */
export const AllergyIntoleranceVerificationStatusCodesConcepts = [
    { code: "unconfirmed", system: "http://terminology.hl7.org/CodeSystem/allergyintolerance-verification", display: "Unconfirmed" },
    { code: "confirmed", system: "http://terminology.hl7.org/CodeSystem/allergyintolerance-verification", display: "Confirmed" },
    { code: "refuted", system: "http://terminology.hl7.org/CodeSystem/allergyintolerance-verification", display: "Refuted" },
    { code: "entered-in-error", system: "http://terminology.hl7.org/CodeSystem/allergyintolerance-verification", display: "Entered in Error" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidAllergyIntoleranceVerificationStatusCodesCode(code) {
    return AllergyIntoleranceVerificationStatusCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getAllergyIntoleranceVerificationStatusCodesConcept(code) {
    return AllergyIntoleranceVerificationStatusCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const AllergyIntoleranceVerificationStatusCodesCodes = AllergyIntoleranceVerificationStatusCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomAllergyIntoleranceVerificationStatusCodesCode() {
    return AllergyIntoleranceVerificationStatusCodesCodes[Math.floor(Math.random() * AllergyIntoleranceVerificationStatusCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomAllergyIntoleranceVerificationStatusCodesConcept() {
    return AllergyIntoleranceVerificationStatusCodesConcepts[Math.floor(Math.random() * AllergyIntoleranceVerificationStatusCodesConcepts.length)];
}
