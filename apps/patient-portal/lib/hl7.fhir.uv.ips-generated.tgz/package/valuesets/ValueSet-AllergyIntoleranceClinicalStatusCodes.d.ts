/**
 * ValueSet: AllergyIntoleranceClinicalStatusCodes
 * URL: http://hl7.org/fhir/ValueSet/allergyintolerance-clinical
 * Size: 2 concepts
 */
export declare const AllergyIntoleranceClinicalStatusCodesConcepts: readonly [{
    readonly code: "active";
    readonly system: "http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical";
    readonly display: "Active";
}, {
    readonly code: "inactive";
    readonly system: "http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical";
    readonly display: "Inactive";
}];
/** Union type of all valid codes in this ValueSet */
export type AllergyIntoleranceClinicalStatusCodesCode = "active" | "inactive";
/** Type representing a concept from this ValueSet */
export type AllergyIntoleranceClinicalStatusCodesConcept = typeof AllergyIntoleranceClinicalStatusCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidAllergyIntoleranceClinicalStatusCodesCode(code: string): code is AllergyIntoleranceClinicalStatusCodesCode;
/**
 * Get concept details by code
 */
export declare function getAllergyIntoleranceClinicalStatusCodesConcept(code: string): AllergyIntoleranceClinicalStatusCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const AllergyIntoleranceClinicalStatusCodesCodes: ("active" | "inactive")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomAllergyIntoleranceClinicalStatusCodesCode(): AllergyIntoleranceClinicalStatusCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomAllergyIntoleranceClinicalStatusCodesConcept(): AllergyIntoleranceClinicalStatusCodesConcept;
