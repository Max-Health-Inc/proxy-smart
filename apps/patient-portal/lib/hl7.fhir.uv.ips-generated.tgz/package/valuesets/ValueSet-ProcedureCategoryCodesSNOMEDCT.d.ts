/**
 * ValueSet: ProcedureCategoryCodes(SNOMEDCT)
 * URL: http://hl7.org/fhir/ValueSet/procedure-category
 * Size: 7 concepts
 */
export declare const ProcedureCategoryCodesSNOMEDCTConcepts: readonly [{
    readonly code: "24642003";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "409063005";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "409073007";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "387713003";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "103693007";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "46947000";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "410606002";
    readonly system: "http://snomed.info/sct";
}];
/** Union type of all valid codes in this ValueSet */
export type ProcedureCategoryCodesSNOMEDCTCode = "24642003" | "409063005" | "409073007" | "387713003" | "103693007" | "46947000" | "410606002";
/** Type representing a concept from this ValueSet */
export type ProcedureCategoryCodesSNOMEDCTConcept = typeof ProcedureCategoryCodesSNOMEDCTConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidProcedureCategoryCodesSNOMEDCTCode(code: string): code is ProcedureCategoryCodesSNOMEDCTCode;
/**
 * Get concept details by code
 */
export declare function getProcedureCategoryCodesSNOMEDCTConcept(code: string): ProcedureCategoryCodesSNOMEDCTConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ProcedureCategoryCodesSNOMEDCTCodes: ("387713003" | "24642003" | "409063005" | "409073007" | "103693007" | "46947000" | "410606002")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomProcedureCategoryCodesSNOMEDCTCode(): ProcedureCategoryCodesSNOMEDCTCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomProcedureCategoryCodesSNOMEDCTConcept(): ProcedureCategoryCodesSNOMEDCTConcept;
