/**
 * ValueSet: Condition/DiagnosisSeverity
 * URL: http://hl7.org/fhir/ValueSet/condition-severity
 * Size: 3 concepts
 */
export const ConditionDiagnosisSeverityConcepts = [
    { code: "24484000", system: "http://snomed.info/sct" },
    { code: "6736007", system: "http://snomed.info/sct" },
    { code: "255604002", system: "http://snomed.info/sct" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidConditionDiagnosisSeverityCode(code) {
    return ConditionDiagnosisSeverityConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getConditionDiagnosisSeverityConcept(code) {
    return ConditionDiagnosisSeverityConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ConditionDiagnosisSeverityCodes = ConditionDiagnosisSeverityConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomConditionDiagnosisSeverityCode() {
    return ConditionDiagnosisSeverityCodes[Math.floor(Math.random() * ConditionDiagnosisSeverityCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomConditionDiagnosisSeverityConcept() {
    return ConditionDiagnosisSeverityConcepts[Math.floor(Math.random() * ConditionDiagnosisSeverityConcepts.length)];
}
