/**
 * ValueSet: MedicationsSnomedCtIpsFreeSet
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/medications-snomed-ct-ips-free-set
 * Size: Infinity concepts
 */
export const MedicationsSnomedCtIpsFreeSetConcepts = [
    { code: "774702006", system: "http://snomed.info/sct", display: "Bacillus Calmette-Guerin antigen only product" },
    { code: "418268006", system: "http://snomed.info/sct", display: "Bacillus Calmette-Guerin antigen-containing product" },
    { code: "346469000", system: "http://snomed.info/sct", display: "House mite allergy vaccine" },
    { code: "346468008", system: "http://snomed.info/sct", display: "House dust allergy vaccine" },
    { code: "346467003", system: "http://snomed.info/sct", display: "Horse allergy vaccine" },
    { code: "346405008", system: "http://snomed.info/sct", display: "Dog allergy vaccine" },
    { code: "346364006", system: "http://snomed.info/sct", display: "Cat allergy vaccine" },
    { code: "346313005", system: "http://snomed.info/sct", display: "Allergen extract vaccine" },
    { code: "320835005", system: "http://snomed.info/sct", display: "Pollen allergy preparations" },
    { code: "63338004", system: "http://snomed.info/sct", display: "Drug flavoring" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidMedicationsSnomedCtIpsFreeSetCode(code) {
    return MedicationsSnomedCtIpsFreeSetConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getMedicationsSnomedCtIpsFreeSetConcept(code) {
    return MedicationsSnomedCtIpsFreeSetConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const MedicationsSnomedCtIpsFreeSetCodes = MedicationsSnomedCtIpsFreeSetConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomMedicationsSnomedCtIpsFreeSetCode() {
    return MedicationsSnomedCtIpsFreeSetCodes[Math.floor(Math.random() * MedicationsSnomedCtIpsFreeSetCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomMedicationsSnomedCtIpsFreeSetConcept() {
    return MedicationsSnomedCtIpsFreeSetConcepts[Math.floor(Math.random() * MedicationsSnomedCtIpsFreeSetConcepts.length)];
}
