/**
 * ValueSet: VaccinesUvIps
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/vaccines-uv-ips
 * Size: 2 concepts
 */
export const VaccinesUvIpsConcepts = [
    { code: "no-immunization-info", system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips" },
    { code: "no-known-immunizations", system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidVaccinesUvIpsCode(code) {
    return VaccinesUvIpsConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getVaccinesUvIpsConcept(code) {
    return VaccinesUvIpsConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const VaccinesUvIpsCodes = VaccinesUvIpsConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomVaccinesUvIpsCode() {
    return VaccinesUvIpsCodes[Math.floor(Math.random() * VaccinesUvIpsCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomVaccinesUvIpsConcept() {
    return VaccinesUvIpsConcepts[Math.floor(Math.random() * VaccinesUvIpsConcepts.length)];
}
