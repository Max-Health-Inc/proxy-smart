/**
 * ValueSet: ListOrderCodes
 * URL: http://hl7.org/fhir/ValueSet/list-order
 * Size: 8 concepts
 */
export const ListOrderCodesConcepts = [
    { code: "user", system: "http://terminology.hl7.org/CodeSystem/list-order", display: "Sorted by User" },
    { code: "system", system: "http://terminology.hl7.org/CodeSystem/list-order", display: "Sorted by System" },
    { code: "event-date", system: "http://terminology.hl7.org/CodeSystem/list-order", display: "Sorted by Event Date" },
    { code: "entry-date", system: "http://terminology.hl7.org/CodeSystem/list-order", display: "Sorted by Item Date" },
    { code: "priority", system: "http://terminology.hl7.org/CodeSystem/list-order", display: "Sorted by Priority" },
    { code: "alphabetic", system: "http://terminology.hl7.org/CodeSystem/list-order", display: "Sorted Alphabetically" },
    { code: "category", system: "http://terminology.hl7.org/CodeSystem/list-order", display: "Sorted by Category" },
    { code: "patient", system: "http://terminology.hl7.org/CodeSystem/list-order", display: "Sorted by Patient" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidListOrderCodesCode(code) {
    return ListOrderCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getListOrderCodesConcept(code) {
    return ListOrderCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ListOrderCodesCodes = ListOrderCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomListOrderCodesCode() {
    return ListOrderCodesCodes[Math.floor(Math.random() * ListOrderCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomListOrderCodesConcept() {
    return ListOrderCodesConcepts[Math.floor(Math.random() * ListOrderCodesConcepts.length)];
}
