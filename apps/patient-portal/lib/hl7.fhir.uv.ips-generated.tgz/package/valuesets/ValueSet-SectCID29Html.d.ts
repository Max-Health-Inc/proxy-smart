/**
 * ValueSet: sect_CID_29.html
 * URL: http://dicom.nema.org/medical/dicom/current/output/chtml/part16/sect_CID_29.html
 * Size: 49 concepts
 */
export declare const SectCID29HtmlConcepts: readonly [{
    readonly code: "BMD";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "EOG";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "SM";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "OP";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "ECG";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "GM";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "XA";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "XC";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "DMS";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "IVUS";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "CR";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "CT";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "OSS";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "TG";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "LEN";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "OPTENF";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "HD";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "OCT";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "BDUS";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "DG";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "PT";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "EPS";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "LS";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "PX";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "OPM";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "OPTBSV";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "OPV";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "DX";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "OPT";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "MG";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "US";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "EMG";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "IVOCT";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "MR";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "IO";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "EEG";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "RTIMAGE";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "VA";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "RESP";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "ES";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "AR";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "POS";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "RG";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "RF";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "KER";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "OAM";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "NM";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "BI";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}, {
    readonly code: "SRF";
    readonly system: "http://dicom.nema.org/resources/ontology/DCM";
}];
/** String type (ValueSet too large for union type) */
export type SectCID29HtmlCode = string;
/** Type representing a concept from this ValueSet */
export type SectCID29HtmlConcept = typeof SectCID29HtmlConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidSectCID29HtmlCode(code: string): code is SectCID29HtmlCode;
/**
 * Get concept details by code
 */
export declare function getSectCID29HtmlConcept(code: string): SectCID29HtmlConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const SectCID29HtmlCodes: ("AR" | "CT" | "PT" | "OP" | "POS" | "BMD" | "EOG" | "SM" | "ECG" | "GM" | "XA" | "XC" | "DMS" | "IVUS" | "CR" | "OSS" | "TG" | "LEN" | "OPTENF" | "HD" | "OCT" | "BDUS" | "DG" | "EPS" | "LS" | "PX" | "OPM" | "OPTBSV" | "OPV" | "DX" | "OPT" | "MG" | "US" | "EMG" | "IVOCT" | "MR" | "IO" | "EEG" | "RTIMAGE" | "VA" | "RESP" | "ES" | "RG" | "RF" | "KER" | "OAM" | "NM" | "BI" | "SRF")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomSectCID29HtmlCode(): SectCID29HtmlCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomSectCID29HtmlConcept(): SectCID29HtmlConcept;
