/**
 * ValueSet: MediaCollectionView/Projection
 * URL: http://hl7.org/fhir/ValueSet/media-view
 * Size: 100 concepts
 */
export const MediaCollectionViewProjectionConcepts = [
    { code: "260419006", system: "http://snomed.info/sct", display: "Projection" },
    { code: "260421001", system: "http://snomed.info/sct", display: "Left lateral oblique" },
    { code: "260422008", system: "http://snomed.info/sct", display: "C1-C2 left oblique" },
    { code: "260424009", system: "http://snomed.info/sct", display: "Right lateral oblique" },
    { code: "260425005", system: "http://snomed.info/sct", display: "C1-C2 right oblique" },
    { code: "260426006", system: "http://snomed.info/sct", display: "Medial oblique" },
    { code: "260427002", system: "http://snomed.info/sct", display: "Oblique lateral" },
    { code: "260428007", system: "http://snomed.info/sct", display: "Mandible X-ray - lateral oblique" },
    { code: "260430009", system: "http://snomed.info/sct", display: "Anteroposterior left lateral decubitus" },
    { code: "260431008", system: "http://snomed.info/sct", display: "C1-C2 left lateral" },
    { code: "260432001", system: "http://snomed.info/sct", display: "Left true lateral" },
    { code: "260434000", system: "http://snomed.info/sct", display: "Anteroposterior right lateral decubitus" },
    { code: "260435004", system: "http://snomed.info/sct", display: "C1-C2 right lateral" },
    { code: "260436003", system: "http://snomed.info/sct", display: "Right true lateral" },
    { code: "260437007", system: "http://snomed.info/sct", display: "Lateral vertical beam" },
    { code: "260438002", system: "http://snomed.info/sct", display: "Lateral horizontal beam" },
    { code: "260439005", system: "http://snomed.info/sct", display: "Lateral inverted" },
    { code: "260440007", system: "http://snomed.info/sct", display: "True lateral of mandible" },
    { code: "260441006", system: "http://snomed.info/sct", display: "Frog lateral" },
    { code: "260442004", system: "http://snomed.info/sct", display: "Erect lateral" },
    { code: "260443009", system: "http://snomed.info/sct", display: "Anteroposterior inverted" },
    { code: "260444003", system: "http://snomed.info/sct", display: "PA - Rotated posteroanterior" },
    { code: "260445002", system: "http://snomed.info/sct", display: "Posteroanterior 20 degree" },
    { code: "260446001", system: "http://snomed.info/sct", display: "Posteroanterior in ulnar deviation" },
    { code: "260447005", system: "http://snomed.info/sct", display: "Penetrated posteroanterior" },
    { code: "260450008", system: "http://snomed.info/sct", display: "Lordotic projection" },
    { code: "260451007", system: "http://snomed.info/sct", display: "Supine decubitus" },
    { code: "260452000", system: "http://snomed.info/sct", display: "Decubitus" },
    { code: "260453005", system: "http://snomed.info/sct", display: "Internal/external rotation" },
    { code: "260454004", system: "http://snomed.info/sct", display: "45 degree projection" },
    { code: "260455003", system: "http://snomed.info/sct", display: "Head and neck projection" },
    { code: "260458001", system: "http://snomed.info/sct", display: "Slit anteroposterior" },
    { code: "260459009", system: "http://snomed.info/sct", display: "Reverse Towne's" },
    { code: "260460004", system: "http://snomed.info/sct", display: "Slit 35 degree fronto-occipital" },
    { code: "260461000", system: "http://snomed.info/sct", display: "Vertex projection" },
    { code: "260463002", system: "http://snomed.info/sct", display: "Left Stenver's" },
    { code: "260464008", system: "http://snomed.info/sct", display: "Right Stenver's" },
    { code: "260465009", system: "http://snomed.info/sct", display: "Occipitofrontal projection" },
    { code: "260466005", system: "http://snomed.info/sct", display: "Occipitomental projection" },
    { code: "260467001", system: "http://snomed.info/sct", display: "Occipitomental - erect" },
    { code: "260468006", system: "http://snomed.info/sct", display: "Occipitomental - tilted" },
    { code: "260469003", system: "http://snomed.info/sct", display: "Occipitomental - prone" },
    { code: "260470002", system: "http://snomed.info/sct", display: "Occipitomental - 15 degree" },
    { code: "260471003", system: "http://snomed.info/sct", display: "Occipitomental - 30 degree" },
    { code: "260472005", system: "http://snomed.info/sct", display: "Occipitomental - 45 degree" },
    { code: "260473000", system: "http://snomed.info/sct", display: "Waters - 35 degree tilt to radiographic baseline" },
    { code: "260475007", system: "http://snomed.info/sct", display: "Submentovertical reduced exposure for zygomatic arches" },
    { code: "260476008", system: "http://snomed.info/sct", display: "Slit SMV" },
    { code: "260477004", system: "http://snomed.info/sct", display: "Dental/oral projection" },
    { code: "260478009", system: "http://snomed.info/sct", display: "Body - molar" },
    { code: "260479001", system: "http://snomed.info/sct", display: "Body - premolar" },
    { code: "260481004", system: "http://snomed.info/sct", display: "Ramus projection" },
    { code: "260482006", system: "http://snomed.info/sct", display: "Bimolar projection" },
    { code: "260483001", system: "http://snomed.info/sct", display: "Toller projection" },
    { code: "260484007", system: "http://snomed.info/sct", display: "Transmaxillary projection" },
    { code: "260485008", system: "http://snomed.info/sct", display: "Temporomandibular joint setting" },
    { code: "260486009", system: "http://snomed.info/sct", display: "Maxillary sinus setting" },
    { code: "260487000", system: "http://snomed.info/sct", display: "Dental panoramic" },
    { code: "260489002", system: "http://snomed.info/sct", display: "Implant setting projection" },
    { code: "260490006", system: "http://snomed.info/sct", display: "Segmental setting" },
    { code: "260491005", system: "http://snomed.info/sct", display: "Axial view for sesamoid bones" },
    { code: "260492003", system: "http://snomed.info/sct", display: "Brewerton's projection" },
    { code: "260493008", system: "http://snomed.info/sct", display: "Harris Beath axial projection" },
    { code: "260494002", system: "http://snomed.info/sct", display: "Tunnel projection" },
    { code: "260496000", system: "http://snomed.info/sct", display: "Judet projection" },
    { code: "260497009", system: "http://snomed.info/sct", display: "Mortice projection" },
    { code: "260499007", system: "http://snomed.info/sct", display: "Occlusal projection" },
    { code: "260500003", system: "http://snomed.info/sct", display: "Projected oblique occlusal" },
    { code: "260501004", system: "http://snomed.info/sct", display: "Lower true occlusal" },
    { code: "260502006", system: "http://snomed.info/sct", display: "Power grip series" },
    { code: "260503001", system: "http://snomed.info/sct", display: "Radial head projection" },
    { code: "260504007", system: "http://snomed.info/sct", display: "Skyline projection" },
    { code: "260506009", system: "http://snomed.info/sct", display: "Van Rosen projection" },
    { code: "272455005", system: "http://snomed.info/sct", display: "Inferosuperior projection" },
    { code: "272456006", system: "http://snomed.info/sct", display: "Apical projection" },
    { code: "272457002", system: "http://snomed.info/sct", display: "Vertical projection" },
    { code: "272458007", system: "http://snomed.info/sct", display: "Prone projection" },
    { code: "272459004", system: "http://snomed.info/sct", display: "Supine projection" },
    { code: "272460009", system: "http://snomed.info/sct", display: "Anterior projection" },
    { code: "272461008", system: "http://snomed.info/sct", display: "Right posterior projection" },
    { code: "272462001", system: "http://snomed.info/sct", display: "Left posterior projection" },
    { code: "272464000", system: "http://snomed.info/sct", display: "Perorbital projection" },
    { code: "272465004", system: "http://snomed.info/sct", display: "Temporomandibular joint projection" },
    { code: "272466003", system: "http://snomed.info/sct", display: "Optic foramen projection" },
    { code: "272467007", system: "http://snomed.info/sct", display: "Lateral facial skeleton projection" },
    { code: "272468002", system: "http://snomed.info/sct", display: "Ear projection" },
    { code: "272469005", system: "http://snomed.info/sct", display: "Mid face projection" },
    { code: "272470006", system: "http://snomed.info/sct", display: "Cervical spine projection" },
    { code: "272472003", system: "http://snomed.info/sct", display: "Macro projection" },
    { code: "272473008", system: "http://snomed.info/sct", display: "Outlet projection" },
    { code: "272474002", system: "http://snomed.info/sct", display: "Swimmer's projection" },
    { code: "272475001", system: "http://snomed.info/sct", display: "Tibial tuberosity projection" },
    { code: "272476000", system: "http://snomed.info/sct", display: "Transthoracic projection" },
    { code: "272478004", system: "http://snomed.info/sct", display: "Transcranial projection" },
    { code: "272479007", system: "http://snomed.info/sct", display: "Posteroanterior projection" },
    { code: "272480005", system: "http://snomed.info/sct", display: "Horizontal projection" },
    { code: "272481009", system: "http://snomed.info/sct", display: "Erect projection" },
    { code: "272482002", system: "http://snomed.info/sct", display: "Adduction projection" },
    { code: "272483007", system: "http://snomed.info/sct", display: "True projection" },
    { code: "272484001", system: "http://snomed.info/sct", display: "Contralateral projection" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidMediaCollectionViewProjectionCode(code) {
    return MediaCollectionViewProjectionConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getMediaCollectionViewProjectionConcept(code) {
    return MediaCollectionViewProjectionConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const MediaCollectionViewProjectionCodes = MediaCollectionViewProjectionConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomMediaCollectionViewProjectionCode() {
    return MediaCollectionViewProjectionCodes[Math.floor(Math.random() * MediaCollectionViewProjectionCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomMediaCollectionViewProjectionConcept() {
    return MediaCollectionViewProjectionConcepts[Math.floor(Math.random() * MediaCollectionViewProjectionConcepts.length)];
}
