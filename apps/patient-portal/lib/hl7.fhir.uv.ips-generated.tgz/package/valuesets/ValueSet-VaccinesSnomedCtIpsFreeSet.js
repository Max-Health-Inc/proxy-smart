/**
 * ValueSet: VaccinesSnomedCtIpsFreeSet
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/vaccines-snomed-ct-ips-free-set
 * Size: Infinity concepts
 */
export const VaccinesSnomedCtIpsFreeSetConcepts = [
    { code: "2221000221107", system: "http://snomed.info/sct", display: "Live attenuated Human alphaherpesvirus 3 only vaccine product" },
    { code: "2171000221104", system: "http://snomed.info/sct", display: "Salmonella enterica subspecies enterica serovar Typhi capsular polysaccharide unconjugated antigen only vaccine product in parenteral dose form" },
    { code: "1981000221108", system: "http://snomed.info/sct", display: "Neisseria meningitidis serogroup B antigen only vaccine product" },
    { code: "1801000221105", system: "http://snomed.info/sct", display: "Streptococcus pneumoniae capsular polysaccharide antigen conjugated only vaccine product" },
    { code: "1181000221105", system: "http://snomed.info/sct", display: "Influenza virus antigen only vaccine product" },
    { code: "1131000221109", system: "http://snomed.info/sct", display: "Vaccine product containing only inactivated whole Rabies lyssavirus antigen" },
    { code: "1121000221106", system: "http://snomed.info/sct", display: "Live attenuated Yellow fever virus antigen only vaccine product" },
    { code: "1101000221104", system: "http://snomed.info/sct", display: "Clostridium tetani toxoid antigen-containing vaccine product" },
    { code: "1081000221109", system: "http://snomed.info/sct", display: "Live attenuated Rotavirus antigen only vaccine product" },
    { code: "1051000221104", system: "http://snomed.info/sct", display: "Live attenuated Human poliovirus serotypes 1 and 3 antigens only vaccine product in oral dose form" },
    { code: "1031000221108", system: "http://snomed.info/sct", display: "Human poliovirus antigen-containing vaccine product" },
    { code: "1011000221100", system: "http://snomed.info/sct", display: "Live attenuated Vibrio cholerae antigen only vaccine product in oral dose form" },
    { code: "1001000221103", system: "http://snomed.info/sct", display: "Inactivated whole Vibrio cholerae antigen only vaccine product in oral dose form" },
    { code: "971000221109", system: "http://snomed.info/sct", display: "Live attenuated Salmonella enterica subspecies enterica serovar Typhi antigen only vaccine product in oral dose form" },
    { code: "601000221108", system: "http://snomed.info/sct", display: "Bordetella pertussis antigen-containing vaccine product" },
    { code: "1119254000", system: "http://snomed.info/sct", display: "Streptococcus pneumoniae Danish serotype 1, 3, 4, 5, 6A, 6B, 7F, 9V, 14, 18C, 19A, 19F, and 23F capsular polysaccharide antigens only vaccine product" },
    { code: "1052328007", system: "http://snomed.info/sct", display: "Streptococcus pneumoniae Danish serotype 4, 6B, 9V, 14, 18C, 19F, and 23F capsular polysaccharide antigens conjugated only vaccine product" },
    { code: "871921009", system: "http://snomed.info/sct", display: "Staphylococcus toxoid vaccine" },
    { code: "871918007", system: "http://snomed.info/sct", display: "Rickettsia antigen-containing vaccine product" },
    { code: "871908002", system: "http://snomed.info/sct", display: "Human alphaherpesvirus 3 and Measles morbillivirus and Mumps orthorubulavirus and Rubella virus antigens only vaccine product" },
    { code: "871895005", system: "http://snomed.info/sct", display: "Bordetella pertussis and Clostridium tetani and Corynebacterium diphtheriae and Haemophilus influenzae type b and Hepatitis B virus and Human poliovirus antigens only vaccine product" },
    { code: "871889009", system: "http://snomed.info/sct", display: "Acellular Bordetella pertussis and Corynebacterium diphtheriae and Hepatitis B virus and inactivated whole Human poliovirus antigens only vaccine product" },
    { code: "871887006", system: "http://snomed.info/sct", display: "Bordetella pertussis and Clostridium tetani and Corynebacterium diphtheriae and Haemophilus influenzae type b and Human poliovirus antigens only vaccine product" },
    { code: "871878002", system: "http://snomed.info/sct", display: "Bordetella pertussis and Clostridium tetani and Corynebacterium diphtheriae and Human poliovirus antigens only vaccine product" },
    { code: "871876003", system: "http://snomed.info/sct", display: "Acellular Bordetella pertussis and Clostridium tetani and Corynebacterium diphtheriae antigens only vaccine product" },
    { code: "871875004", system: "http://snomed.info/sct", display: "Bordetella pertussis and Clostridium tetani and Corynebacterium diphtheriae antigens only vaccine product" },
    { code: "871873006", system: "http://snomed.info/sct", display: "Neisseria meningitidis serogroup A, C, W135 and Y only vaccine product" },
    { code: "871871008", system: "http://snomed.info/sct", display: "Neisseria meningitidis serogroup A and C only vaccine product" },
    { code: "871866001", system: "http://snomed.info/sct", display: "Neisseria meningitidis serogroup C only vaccine product" },
    { code: "871839001", system: "http://snomed.info/sct", display: "Bordetella pertussis and Clostridium tetani and Corynebacterium diphtheriae and Haemophilus influenzae type b antigens only vaccine product" },
    { code: "871837004", system: "http://snomed.info/sct", display: "Clostridium tetani and Corynebacterium diphtheriae and Human poliovirus antigens only vaccine product" },
    { code: "871831003", system: "http://snomed.info/sct", display: "Measles morbillivirus and Mumps orthorubulavirus and Rubella virus antigens only vaccine product" },
    { code: "871826000", system: "http://snomed.info/sct", display: "Clostridium tetani and Corynebacterium diphtheriae antigens only vaccine product" },
    { code: "871806004", system: "http://snomed.info/sct", display: "Haemophilus influenzae type b and Hepatitis B virus antigens only vaccine product" },
    { code: "871804001", system: "http://snomed.info/sct", display: "Hepatitis A virus and Salmonella enterica subspecies enterica serovar Typhi antigens only vaccine product" },
    { code: "871803007", system: "http://snomed.info/sct", display: "Hepatitis A and Hepatitis B virus antigens only vaccine product" },
    { code: "871772009", system: "http://snomed.info/sct", display: "Influenza A virus subtype H1N1 antigen only vaccine product" },
    { code: "871768005", system: "http://snomed.info/sct", display: "Influenza virus antigen only vaccine product in nasal dose form" },
    { code: "871765008", system: "http://snomed.info/sct", display: "Measles morbillivirus antigen only vaccine product" },
    { code: "871759008", system: "http://snomed.info/sct", display: "Acellular Bordetella pertussis only vaccine product" },
    { code: "871740006", system: "http://snomed.info/sct", display: "Inactivated whole Human poliovirus antigen only vaccine product" },
    { code: "871738001", system: "http://snomed.info/sct", display: "Live attenuated Mumps orthorubulavirus antigen only vaccine product" },
    { code: "871737006", system: "http://snomed.info/sct", display: "Mumps orthorubulavirus antigen only vaccine product" },
    { code: "863911006", system: "http://snomed.info/sct", display: "Clostridium tetani antigen-containing vaccine product" },
    { code: "840599008", system: "http://snomed.info/sct", display: "Borrelia burgdorferi antigen-containing vaccine product" },
    { code: "840549009", system: "http://snomed.info/sct", display: "Yersinia pestis antigen-containing vaccine product" },
    { code: "836500008", system: "http://snomed.info/sct", display: "Haemophilus influenzae type b and Neisseria meningitidis serogroup C antigens only vaccine product" },
    { code: "836498007", system: "http://snomed.info/sct", display: "Mumps orthorubulavirus antigen-containing vaccine product" },
    { code: "836495005", system: "http://snomed.info/sct", display: "Human alphaherpesvirus 3 antigen-containing vaccine product" },
    { code: "836403007", system: "http://snomed.info/sct", display: "Tick-borne encephalitis virus antigen-containing vaccine product" },
    { code: "836402002", system: "http://snomed.info/sct", display: "Bacillus Calmette-Guerin antigen-containing vaccine product" },
    { code: "836401009", system: "http://snomed.info/sct", display: "Neisseria meningitidis antigen-containing vaccine product" },
    { code: "836398006", system: "http://snomed.info/sct", display: "Streptococcus pneumoniae antigen-containing vaccine product" },
    { code: "836397001", system: "http://snomed.info/sct", display: "Coxiella burnetii antigen-containing vaccine product" },
    { code: "836393002", system: "http://snomed.info/sct", display: "Rabies lyssavirus antigen-containing vaccine product" },
    { code: "836390004", system: "http://snomed.info/sct", display: "Salmonella enterica subspecies enterica serovar Typhi antigen-containing vaccine product" },
    { code: "836389008", system: "http://snomed.info/sct", display: "Vaccinia virus antigen-containing vaccine product" },
    { code: "836388000", system: "http://snomed.info/sct", display: "Rubella virus antigen-containing vaccine product" },
    { code: "836387005", system: "http://snomed.info/sct", display: "Rotavirus antigen-containing vaccine product" },
    { code: "836385002", system: "http://snomed.info/sct", display: "Yellow fever virus antigen-containing vaccine product" },
    { code: "836384003", system: "http://snomed.info/sct", display: "Bacillus anthracis antigen-containing vaccine product" },
    { code: "836383009", system: "http://snomed.info/sct", display: "Vibrio cholerae antigen-containing vaccine product" },
    { code: "836382004", system: "http://snomed.info/sct", display: "Measles morbillivirus antigen-containing vaccine product" },
    { code: "836381006", system: "http://snomed.info/sct", display: "Corynebacterium diphtheriae antigen-containing vaccine product" },
    { code: "836380007", system: "http://snomed.info/sct", display: "Haemophilus influenzae type b antigen-containing vaccine product" },
    { code: "836379009", system: "http://snomed.info/sct", display: "Human papillomavirus antigen-containing vaccine product" },
    { code: "836378001", system: "http://snomed.info/sct", display: "Japanese encephalitis virus antigen-containing vaccine product" },
    { code: "836377006", system: "http://snomed.info/sct", display: "Influenza virus antigen-containing vaccine product" },
    { code: "836375003", system: "http://snomed.info/sct", display: "Hepatitis A virus antigen-containing vaccine product" },
    { code: "836374004", system: "http://snomed.info/sct", display: "Hepatitis B virus antigen-containing vaccine product" },
    { code: "836369007", system: "http://snomed.info/sct", display: "Virus antigen-containing vaccine product" },
    { code: "836368004", system: "http://snomed.info/sct", display: "Bacteria antigen-containing vaccine product" },
    { code: "777725002", system: "http://snomed.info/sct", display: "Clostridium tetani toxoid antigen adsorbed only vaccine product" },
    { code: "775641005", system: "http://snomed.info/sct", display: "Clostridium tetani toxoid adsorbed and Corynebacterium diphtheriae toxoid antigens only vaccine product" },
    { code: "774618008", system: "http://snomed.info/sct", display: "Whole cell Bordetella pertussis and Clostridium tetani toxoid adsorbed and Corynebacterium diphtheriae toxoid antigens only vaccine product" },
    { code: "428601009", system: "http://snomed.info/sct", display: "Paratyphoid vaccine" },
    { code: "409568008", system: "http://snomed.info/sct", display: "Pentavalent botulinum toxoid vaccine" },
    { code: "37146000", system: "http://snomed.info/sct", display: "Typhus vaccine" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidVaccinesSnomedCtIpsFreeSetCode(code) {
    return VaccinesSnomedCtIpsFreeSetConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getVaccinesSnomedCtIpsFreeSetConcept(code) {
    return VaccinesSnomedCtIpsFreeSetConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const VaccinesSnomedCtIpsFreeSetCodes = VaccinesSnomedCtIpsFreeSetConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomVaccinesSnomedCtIpsFreeSetCode() {
    return VaccinesSnomedCtIpsFreeSetCodes[Math.floor(Math.random() * VaccinesSnomedCtIpsFreeSetCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomVaccinesSnomedCtIpsFreeSetConcept() {
    return VaccinesSnomedCtIpsFreeSetConcepts[Math.floor(Math.random() * VaccinesSnomedCtIpsFreeSetConcepts.length)];
}
