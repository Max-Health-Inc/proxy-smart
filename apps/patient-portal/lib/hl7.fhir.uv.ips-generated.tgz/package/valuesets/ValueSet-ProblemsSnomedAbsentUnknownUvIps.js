/**
 * ValueSet: ProblemsSnomedAbsentUnknownUvIps
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/problems-snomed-absent-unknown-uv-ips
 * Size: 2 concepts
 */
export const ProblemsSnomedAbsentUnknownUvIpsConcepts = [
    { code: "no-problem-info", system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips" },
    { code: "no-known-problems", system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidProblemsSnomedAbsentUnknownUvIpsCode(code) {
    return ProblemsSnomedAbsentUnknownUvIpsConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getProblemsSnomedAbsentUnknownUvIpsConcept(code) {
    return ProblemsSnomedAbsentUnknownUvIpsConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ProblemsSnomedAbsentUnknownUvIpsCodes = ProblemsSnomedAbsentUnknownUvIpsConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomProblemsSnomedAbsentUnknownUvIpsCode() {
    return ProblemsSnomedAbsentUnknownUvIpsCodes[Math.floor(Math.random() * ProblemsSnomedAbsentUnknownUvIpsCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomProblemsSnomedAbsentUnknownUvIpsConcept() {
    return ProblemsSnomedAbsentUnknownUvIpsConcepts[Math.floor(Math.random() * ProblemsSnomedAbsentUnknownUvIpsConcepts.length)];
}
