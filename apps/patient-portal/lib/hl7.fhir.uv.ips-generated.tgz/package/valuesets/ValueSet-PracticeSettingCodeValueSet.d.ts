/**
 * ValueSet: PracticeSettingCodeValueSet
 * URL: http://hl7.org/fhir/ValueSet/c80-practice-codes
 * Size: 117 concepts
 */
interface PracticeSettingCodeValueSetConceptDef {
    readonly code: string;
    readonly system: string;
    readonly display?: string;
}
export declare const PracticeSettingCodeValueSetConcepts: readonly PracticeSettingCodeValueSetConceptDef[];
/** String type (ValueSet too large for union type) */
export type PracticeSettingCodeValueSetCode = string;
/** Type representing a concept from this ValueSet */
export type PracticeSettingCodeValueSetConcept = PracticeSettingCodeValueSetConceptDef;
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidPracticeSettingCodeValueSetCode(code: string): code is PracticeSettingCodeValueSetCode;
/**
 * Get concept details by code
 */
export declare function getPracticeSettingCodeValueSetConcept(code: string): PracticeSettingCodeValueSetConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const PracticeSettingCodeValueSetCodes: string[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomPracticeSettingCodeValueSetCode(): PracticeSettingCodeValueSetCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomPracticeSettingCodeValueSetConcept(): PracticeSettingCodeValueSetConcept;
export {};
