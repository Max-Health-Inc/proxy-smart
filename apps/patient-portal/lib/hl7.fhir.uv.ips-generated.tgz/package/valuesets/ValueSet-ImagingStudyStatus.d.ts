/**
 * ValueSet: ImagingStudyStatus
 * URL: http://hl7.org/fhir/ValueSet/imagingstudy-status
 * Size: 5 concepts
 */
export declare const ImagingStudyStatusConcepts: readonly [{
    readonly code: "registered";
    readonly system: "http://hl7.org/fhir/imagingstudy-status";
    readonly display: "Registered";
}, {
    readonly code: "available";
    readonly system: "http://hl7.org/fhir/imagingstudy-status";
    readonly display: "Available";
}, {
    readonly code: "cancelled";
    readonly system: "http://hl7.org/fhir/imagingstudy-status";
    readonly display: "Cancelled";
}, {
    readonly code: "entered-in-error";
    readonly system: "http://hl7.org/fhir/imagingstudy-status";
    readonly display: "Entered in Error";
}, {
    readonly code: "unknown";
    readonly system: "http://hl7.org/fhir/imagingstudy-status";
    readonly display: "Unknown";
}];
/** Union type of all valid codes in this ValueSet */
export type ImagingStudyStatusCode = "registered" | "available" | "cancelled" | "entered-in-error" | "unknown";
/** Type representing a concept from this ValueSet */
export type ImagingStudyStatusConcept = typeof ImagingStudyStatusConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidImagingStudyStatusCode(code: string): code is ImagingStudyStatusCode;
/**
 * Get concept details by code
 */
export declare function getImagingStudyStatusConcept(code: string): ImagingStudyStatusConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ImagingStudyStatusCodes: ("unknown" | "entered-in-error" | "registered" | "cancelled" | "available")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomImagingStudyStatusCode(): ImagingStudyStatusCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomImagingStudyStatusConcept(): ImagingStudyStatusConcept;
