/**
 * ValueSet: AbsentOrUnknownAllergiesUvIps
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/absent-or-unknown-allergies-uv-ips
 * Size: 5 concepts
 */
export declare const AbsentOrUnknownAllergiesUvIpsConcepts: readonly [{
    readonly code: "no-allergy-info";
    readonly system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips";
    readonly display: "No information about allergies";
}, {
    readonly code: "no-known-allergies";
    readonly system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips";
    readonly display: "No known allergies";
}, {
    readonly code: "no-known-medication-allergies";
    readonly system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips";
    readonly display: "No known medication allergies";
}, {
    readonly code: "no-known-environmental-allergies";
    readonly system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips";
    readonly display: "No known environmental allergies";
}, {
    readonly code: "no-known-food-allergies";
    readonly system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips";
    readonly display: "No known food allergies";
}];
/** Union type of all valid codes in this ValueSet */
export type AbsentOrUnknownAllergiesUvIpsCode = "no-allergy-info" | "no-known-allergies" | "no-known-medication-allergies" | "no-known-environmental-allergies" | "no-known-food-allergies";
/** Type representing a concept from this ValueSet */
export type AbsentOrUnknownAllergiesUvIpsConcept = typeof AbsentOrUnknownAllergiesUvIpsConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidAbsentOrUnknownAllergiesUvIpsCode(code: string): code is AbsentOrUnknownAllergiesUvIpsCode;
/**
 * Get concept details by code
 */
export declare function getAbsentOrUnknownAllergiesUvIpsConcept(code: string): AbsentOrUnknownAllergiesUvIpsConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const AbsentOrUnknownAllergiesUvIpsCodes: ("no-allergy-info" | "no-known-allergies" | "no-known-medication-allergies" | "no-known-environmental-allergies" | "no-known-food-allergies")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomAbsentOrUnknownAllergiesUvIpsCode(): AbsentOrUnknownAllergiesUvIpsCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomAbsentOrUnknownAllergiesUvIpsConcept(): AbsentOrUnknownAllergiesUvIpsConcept;
