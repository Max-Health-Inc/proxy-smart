/**
 * ValueSet: ProceduresSnomedAbsentUnknownUvIps
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/procedures-snomed-absent-unknown-uv-ips
 * Size: 2 concepts
 */
export declare const ProceduresSnomedAbsentUnknownUvIpsConcepts: readonly [{
    readonly code: "no-procedure-info";
    readonly system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips";
}, {
    readonly code: "no-known-procedures";
    readonly system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips";
}];
/** Union type of all valid codes in this ValueSet */
export type ProceduresSnomedAbsentUnknownUvIpsCode = "no-procedure-info" | "no-known-procedures";
/** Type representing a concept from this ValueSet */
export type ProceduresSnomedAbsentUnknownUvIpsConcept = typeof ProceduresSnomedAbsentUnknownUvIpsConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidProceduresSnomedAbsentUnknownUvIpsCode(code: string): code is ProceduresSnomedAbsentUnknownUvIpsCode;
/**
 * Get concept details by code
 */
export declare function getProceduresSnomedAbsentUnknownUvIpsConcept(code: string): ProceduresSnomedAbsentUnknownUvIpsConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ProceduresSnomedAbsentUnknownUvIpsCodes: ("no-procedure-info" | "no-known-procedures")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomProceduresSnomedAbsentUnknownUvIpsCode(): ProceduresSnomedAbsentUnknownUvIpsCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomProceduresSnomedAbsentUnknownUvIpsConcept(): ProceduresSnomedAbsentUnknownUvIpsConcept;
