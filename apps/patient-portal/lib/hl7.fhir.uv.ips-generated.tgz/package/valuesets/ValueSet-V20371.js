/**
 * ValueSet: v2-0371
 * URL: http://terminology.hl7.org/ValueSet/v2-0371
 * Size: 57 concepts
 */
export const V20371Concepts = [
    { code: "ACDA", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "ACDB", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "ACET", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "AMIES", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "BACTM", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "BF10", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "BOR", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "BOUIN", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "BSKM", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "C32", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "C38", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "CARS", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "CARY", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "CHLTM", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "CTAD", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "EDTK", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "EDTK15", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "EDTK75", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "EDTN", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "ENT", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "ENT+", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "F10", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "FDP", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "FL10", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "FL100", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "HCL6", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "HEPA", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "HEPL", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "HEPN", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "HNO3", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "JKM", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "KARN", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "KOX", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "LIA", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "M4", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "M4RT", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "M5", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "MICHTM", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "MMDTM", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "NAF", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "NAPS", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "NONE", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "PAGE", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "PHENOL", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "PVA", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "RLM", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "SILICA", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "SPS", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "SST", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "STUTM", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "THROM", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "THYMOL", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "THYO", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "TOLU", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "URETM", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "VIRTM", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
    { code: "WEST", system: "http://terminology.hl7.org/CodeSystem/v2-0371" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidV20371Code(code) {
    return V20371Concepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getV20371Concept(code) {
    return V20371Concepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const V20371Codes = V20371Concepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomV20371Code() {
    return V20371Codes[Math.floor(Math.random() * V20371Codes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomV20371Concept() {
    return V20371Concepts[Math.floor(Math.random() * V20371Concepts.length)];
}
