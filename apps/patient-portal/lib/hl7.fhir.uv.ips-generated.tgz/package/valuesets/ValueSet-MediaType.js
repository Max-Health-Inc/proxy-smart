/**
 * ValueSet: MediaType
 * URL: http://hl7.org/fhir/ValueSet/media-type
 * Size: 3 concepts
 */
export const MediaTypeConcepts = [
    { code: "image", system: "http://terminology.hl7.org/CodeSystem/media-type", display: "Image" },
    { code: "video", system: "http://terminology.hl7.org/CodeSystem/media-type", display: "Video" },
    { code: "audio", system: "http://terminology.hl7.org/CodeSystem/media-type", display: "Audio" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidMediaTypeCode(code) {
    return MediaTypeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getMediaTypeConcept(code) {
    return MediaTypeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const MediaTypeCodes = MediaTypeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomMediaTypeCode() {
    return MediaTypeCodes[Math.floor(Math.random() * MediaTypeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomMediaTypeConcept() {
    return MediaTypeConcepts[Math.floor(Math.random() * MediaTypeConcepts.length)];
}
