/**
 * ValueSet: AllergyReactionSnomedCtIpsFreeSet
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/allergy-reaction-snomed-ct-ips-free-set
 * Size: 31 concepts
 */
export const AllergyReactionSnomedCtIpsFreeSetConcepts = [
    { code: "4386001", system: "http://snomed.info/sct", display: "Bronchospasm (finding)" },
    { code: "9826008", system: "http://snomed.info/sct", display: "Conjunctivitis (disorder)" },
    { code: "23924001", system: "http://snomed.info/sct", display: "Tight chest (finding)" },
    { code: "24079001", system: "http://snomed.info/sct", display: "Atopic dermatitis (disorder)" },
    { code: "31996006", system: "http://snomed.info/sct", display: "Vasculitis (disorder)" },
    { code: "39579001", system: "http://snomed.info/sct", display: "Anaphylaxis (disorder)" },
    { code: "41291007", system: "http://snomed.info/sct", display: "Angioedema (disorder)" },
    { code: "43116000", system: "http://snomed.info/sct", display: "Eczema (disorder)" },
    { code: "49727002", system: "http://snomed.info/sct", display: "Cough (finding)" },
    { code: "51599000", system: "http://snomed.info/sct", display: "Edema of larynx (disorder)" },
    { code: "62315008", system: "http://snomed.info/sct", display: "Diarrhea (finding)" },
    { code: "70076002", system: "http://snomed.info/sct", display: "Rhinitis (disorder)" },
    { code: "73442001", system: "http://snomed.info/sct", display: "Stevens-Johnson syndrome (disorder)" },
    { code: "76067001", system: "http://snomed.info/sct", display: "Sneezing (finding)" },
    { code: "91175000", system: "http://snomed.info/sct", display: "Seizure (finding)" },
    { code: "126485001", system: "http://snomed.info/sct", display: "Urticaria (disorder)" },
    { code: "162290004", system: "http://snomed.info/sct", display: "Dry eyes (finding)" },
    { code: "195967001", system: "http://snomed.info/sct", display: "Asthma (disorder)" },
    { code: "247472004", system: "http://snomed.info/sct", display: "Weal (disorder)" },
    { code: "267036007", system: "http://snomed.info/sct", display: "Dyspnea (finding)" },
    { code: "271757001", system: "http://snomed.info/sct", display: "Papular eruption (disorder)" },
    { code: "271759003", system: "http://snomed.info/sct", display: "Bullous eruption (disorder)" },
    { code: "271807003", system: "http://snomed.info/sct", display: "Eruption of skin (disorder)" },
    { code: "410430005", system: "http://snomed.info/sct", display: "Cardiorespiratory arrest (disorder)" },
    { code: "418363000", system: "http://snomed.info/sct", display: "Itching of skin (finding)" },
    { code: "422400008", system: "http://snomed.info/sct", display: "Vomiting (disorder)" },
    { code: "422587007", system: "http://snomed.info/sct", display: "Nausea (finding)" },
    { code: "698247007", system: "http://snomed.info/sct", display: "Cardiac arrhythmia (disorder)" },
    { code: "702809001", system: "http://snomed.info/sct", display: "Drug reaction with eosinophilia and systemic symptoms (disorder)" },
    { code: "768962006", system: "http://snomed.info/sct", display: "Lyell syndrome (disorder)" },
    { code: "781682005", system: "http://snomed.info/sct", display: "Hyperemia of eye (finding)" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidAllergyReactionSnomedCtIpsFreeSetCode(code) {
    return AllergyReactionSnomedCtIpsFreeSetConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getAllergyReactionSnomedCtIpsFreeSetConcept(code) {
    return AllergyReactionSnomedCtIpsFreeSetConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const AllergyReactionSnomedCtIpsFreeSetCodes = AllergyReactionSnomedCtIpsFreeSetConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomAllergyReactionSnomedCtIpsFreeSetCode() {
    return AllergyReactionSnomedCtIpsFreeSetCodes[Math.floor(Math.random() * AllergyReactionSnomedCtIpsFreeSetCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomAllergyReactionSnomedCtIpsFreeSetConcept() {
    return AllergyReactionSnomedCtIpsFreeSetConcepts[Math.floor(Math.random() * AllergyReactionSnomedCtIpsFreeSetConcepts.length)];
}
