/**
 * ValueSet: VaccineTargetDiseasesSnomedCtIpsFreeSet
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/target-diseases-snomed-ct-ips-free-set
 * Size: Infinity concepts
 */
export const VaccineTargetDiseasesSnomedCtIpsFreeSetConcepts = [
    { code: "4834000", system: "http://snomed.info/sct", display: "Typhoid fever" },
    { code: "6142004", system: "http://snomed.info/sct", display: "Influenza" },
    { code: "14189004", system: "http://snomed.info/sct", display: "Measles" },
    { code: "23502006", system: "http://snomed.info/sct", display: "Lyme disease" },
    { code: "24662006", system: "http://snomed.info/sct", display: "Influenza due to Influenza B virus" },
    { code: "25225006", system: "http://snomed.info/sct", display: "Disease due to Adenovirus" },
    { code: "27836007", system: "http://snomed.info/sct", display: "Pertussis" },
    { code: "32398004", system: "http://snomed.info/sct", display: "Bronchitis" },
    { code: "36989005", system: "http://snomed.info/sct", display: "Mumps" },
    { code: "38907003", system: "http://snomed.info/sct", display: "Varicella" },
    { code: "40468003", system: "http://snomed.info/sct", display: "Viral hepatitis, type A" },
    { code: "50711007", system: "http://snomed.info/sct", display: "Viral hepatitis C" },
    { code: "56717001", system: "http://snomed.info/sct", display: "Tuberculosis" },
    { code: "66071002", system: "http://snomed.info/sct", display: "Type B viral hepatitis" },
    { code: "70036007", system: "http://snomed.info/sct", display: "Haemophilus influenzae pneumonia" },
    { code: "76902006", system: "http://snomed.info/sct", display: "Tetanus" },
    { code: "186150001", system: "http://snomed.info/sct", display: "Enteritis due to rotavirus" },
    { code: "240532009", system: "http://snomed.info/sct", display: "Human papilloma virus infection" },
    { code: "372244006", system: "http://snomed.info/sct", display: "Malignant melanoma" },
    { code: "398102009", system: "http://snomed.info/sct", display: "Acute poliomyelitis" },
    { code: "442438000", system: "http://snomed.info/sct", display: "Influenza due to Influenza A virus" },
    { code: "840539006", system: "http://snomed.info/sct", display: "COVID-19" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidVaccineTargetDiseasesSnomedCtIpsFreeSetCode(code) {
    return VaccineTargetDiseasesSnomedCtIpsFreeSetConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getVaccineTargetDiseasesSnomedCtIpsFreeSetConcept(code) {
    return VaccineTargetDiseasesSnomedCtIpsFreeSetConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const VaccineTargetDiseasesSnomedCtIpsFreeSetCodes = VaccineTargetDiseasesSnomedCtIpsFreeSetConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomVaccineTargetDiseasesSnomedCtIpsFreeSetCode() {
    return VaccineTargetDiseasesSnomedCtIpsFreeSetCodes[Math.floor(Math.random() * VaccineTargetDiseasesSnomedCtIpsFreeSetCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomVaccineTargetDiseasesSnomedCtIpsFreeSetConcept() {
    return VaccineTargetDiseasesSnomedCtIpsFreeSetConcepts[Math.floor(Math.random() * VaccineTargetDiseasesSnomedCtIpsFreeSetConcepts.length)];
}
