/**
 * ValueSet: DoseAndRateType
 * URL: http://hl7.org/fhir/ValueSet/dose-rate-type
 * Size: 2 concepts
 */
export const DoseAndRateTypeConcepts = [
    { code: "calculated", system: "http://terminology.hl7.org/CodeSystem/dose-rate-type", display: "Calculated" },
    { code: "ordered", system: "http://terminology.hl7.org/CodeSystem/dose-rate-type", display: "Ordered" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidDoseAndRateTypeCode(code) {
    return DoseAndRateTypeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getDoseAndRateTypeConcept(code) {
    return DoseAndRateTypeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const DoseAndRateTypeCodes = DoseAndRateTypeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomDoseAndRateTypeCode() {
    return DoseAndRateTypeCodes[Math.floor(Math.random() * DoseAndRateTypeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomDoseAndRateTypeConcept() {
    return DoseAndRateTypeConcepts[Math.floor(Math.random() * DoseAndRateTypeConcepts.length)];
}
