/**
 * ValueSet: ResultsBloodGroupSnomedCtIpsFreeSet
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/results-blood-group-snomed-ct-ips-free-set
 * Size: Infinity concepts
 */
export const ResultsBloodGroupSnomedCtIpsFreeSetConcepts = [
    { code: "278154007", system: "http://snomed.info/sct", display: "Blood group AB Rh(D) negative" },
    { code: "278153001", system: "http://snomed.info/sct", display: "Blood group B Rh(D) negative" },
    { code: "278152006", system: "http://snomed.info/sct", display: "Blood group A Rh(D) negative" },
    { code: "278151004", system: "http://snomed.info/sct", display: "Blood group AB Rh(D) positive" },
    { code: "278150003", system: "http://snomed.info/sct", display: "Blood group B Rh(D) positive" },
    { code: "278149003", system: "http://snomed.info/sct", display: "Blood group A Rh(D) positive" },
    { code: "278148006", system: "http://snomed.info/sct", display: "Blood group O Rh(D) negative" },
    { code: "278147001", system: "http://snomed.info/sct", display: "Blood group O Rh(D) positive" },
    { code: "165746003", system: "http://snomed.info/sct", display: "RhD negative" },
    { code: "165743006", system: "http://snomed.info/sct", display: "Blood group AB" },
    { code: "112149005", system: "http://snomed.info/sct", display: "Blood group B" },
    { code: "112144000", system: "http://snomed.info/sct", display: "Blood group A" },
    { code: "58460004", system: "http://snomed.info/sct", display: "Blood group O" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidResultsBloodGroupSnomedCtIpsFreeSetCode(code) {
    return ResultsBloodGroupSnomedCtIpsFreeSetConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getResultsBloodGroupSnomedCtIpsFreeSetConcept(code) {
    return ResultsBloodGroupSnomedCtIpsFreeSetConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ResultsBloodGroupSnomedCtIpsFreeSetCodes = ResultsBloodGroupSnomedCtIpsFreeSetConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomResultsBloodGroupSnomedCtIpsFreeSetCode() {
    return ResultsBloodGroupSnomedCtIpsFreeSetCodes[Math.floor(Math.random() * ResultsBloodGroupSnomedCtIpsFreeSetCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomResultsBloodGroupSnomedCtIpsFreeSetConcept() {
    return ResultsBloodGroupSnomedCtIpsFreeSetConcepts[Math.floor(Math.random() * ResultsBloodGroupSnomedCtIpsFreeSetConcepts.length)];
}
