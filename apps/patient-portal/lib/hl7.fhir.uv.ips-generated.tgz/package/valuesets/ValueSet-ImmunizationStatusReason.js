/**
 * ValueSet: immunization-status-reason
 * URL: http://hl7.org/fhir/ValueSet/immunization-status-reason
 * Size: 4 concepts
 */
export const ImmunizationStatusReasonConcepts = [
    { code: "IMMUNE", system: "http://terminology.hl7.org/CodeSystem/v3-ActReason" },
    { code: "MEDPREC", system: "http://terminology.hl7.org/CodeSystem/v3-ActReason" },
    { code: "OSTOCK", system: "http://terminology.hl7.org/CodeSystem/v3-ActReason" },
    { code: "PATOBJ", system: "http://terminology.hl7.org/CodeSystem/v3-ActReason" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidImmunizationStatusReasonCode(code) {
    return ImmunizationStatusReasonConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getImmunizationStatusReasonConcept(code) {
    return ImmunizationStatusReasonConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ImmunizationStatusReasonCodes = ImmunizationStatusReasonConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomImmunizationStatusReasonCode() {
    return ImmunizationStatusReasonCodes[Math.floor(Math.random() * ImmunizationStatusReasonCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomImmunizationStatusReasonConcept() {
    return ImmunizationStatusReasonConcepts[Math.floor(Math.random() * ImmunizationStatusReasonConcepts.length)];
}
