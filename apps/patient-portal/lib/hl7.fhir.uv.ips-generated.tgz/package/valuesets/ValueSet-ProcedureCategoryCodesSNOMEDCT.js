/**
 * ValueSet: ProcedureCategoryCodes(SNOMEDCT)
 * URL: http://hl7.org/fhir/ValueSet/procedure-category
 * Size: 7 concepts
 */
export const ProcedureCategoryCodesSNOMEDCTConcepts = [
    { code: "24642003", system: "http://snomed.info/sct" },
    { code: "409063005", system: "http://snomed.info/sct" },
    { code: "409073007", system: "http://snomed.info/sct" },
    { code: "387713003", system: "http://snomed.info/sct" },
    { code: "103693007", system: "http://snomed.info/sct" },
    { code: "46947000", system: "http://snomed.info/sct" },
    { code: "410606002", system: "http://snomed.info/sct" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidProcedureCategoryCodesSNOMEDCTCode(code) {
    return ProcedureCategoryCodesSNOMEDCTConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getProcedureCategoryCodesSNOMEDCTConcept(code) {
    return ProcedureCategoryCodesSNOMEDCTConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ProcedureCategoryCodesSNOMEDCTCodes = ProcedureCategoryCodesSNOMEDCTConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomProcedureCategoryCodesSNOMEDCTCode() {
    return ProcedureCategoryCodesSNOMEDCTCodes[Math.floor(Math.random() * ProcedureCategoryCodesSNOMEDCTCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomProcedureCategoryCodesSNOMEDCTConcept() {
    return ProcedureCategoryCodesSNOMEDCTConcepts[Math.floor(Math.random() * ProcedureCategoryCodesSNOMEDCTConcepts.length)];
}
