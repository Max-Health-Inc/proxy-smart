/**
 * ValueSet: VaccinesUvIps
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/vaccines-uv-ips
 * Size: 2 concepts
 */
export declare const VaccinesUvIpsConcepts: readonly [{
    readonly code: "no-immunization-info";
    readonly system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips";
}, {
    readonly code: "no-known-immunizations";
    readonly system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips";
}];
/** Union type of all valid codes in this ValueSet */
export type VaccinesUvIpsCode = "no-immunization-info" | "no-known-immunizations";
/** Type representing a concept from this ValueSet */
export type VaccinesUvIpsConcept = typeof VaccinesUvIpsConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidVaccinesUvIpsCode(code: string): code is VaccinesUvIpsCode;
/**
 * Get concept details by code
 */
export declare function getVaccinesUvIpsConcept(code: string): VaccinesUvIpsConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const VaccinesUvIpsCodes: ("no-immunization-info" | "no-known-immunizations")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomVaccinesUvIpsCode(): VaccinesUvIpsCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomVaccinesUvIpsConcept(): VaccinesUvIpsConcept;
