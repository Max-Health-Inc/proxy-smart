/**
 * ValueSet: ConditionVerificationStatus
 * URL: http://hl7.org/fhir/ValueSet/condition-ver-status
 * Size: 4 concepts
 */
export const ConditionVerificationStatusConcepts = [
    { code: "unconfirmed", system: "http://terminology.hl7.org/CodeSystem/condition-ver-status", display: "Unconfirmed" },
    { code: "confirmed", system: "http://terminology.hl7.org/CodeSystem/condition-ver-status", display: "Confirmed" },
    { code: "refuted", system: "http://terminology.hl7.org/CodeSystem/condition-ver-status", display: "Refuted" },
    { code: "entered-in-error", system: "http://terminology.hl7.org/CodeSystem/condition-ver-status", display: "Entered in Error" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidConditionVerificationStatusCode(code) {
    return ConditionVerificationStatusConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getConditionVerificationStatusConcept(code) {
    return ConditionVerificationStatusConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ConditionVerificationStatusCodes = ConditionVerificationStatusConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomConditionVerificationStatusCode() {
    return ConditionVerificationStatusCodes[Math.floor(Math.random() * ConditionVerificationStatusCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomConditionVerificationStatusConcept() {
    return ConditionVerificationStatusConcepts[Math.floor(Math.random() * ConditionVerificationStatusConcepts.length)];
}
