/**
 * ValueSet: ProblemsSnomedAbsentUnknownUvIps
 * URL: http://hl7.org/fhir/uv/ips/ValueSet/problems-snomed-absent-unknown-uv-ips
 * Size: 2 concepts
 */
export declare const ProblemsSnomedAbsentUnknownUvIpsConcepts: readonly [{
    readonly code: "no-problem-info";
    readonly system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips";
}, {
    readonly code: "no-known-problems";
    readonly system: "http://hl7.org/fhir/uv/ips/CodeSystem/absent-unknown-uv-ips";
}];
/** Union type of all valid codes in this ValueSet */
export type ProblemsSnomedAbsentUnknownUvIpsCode = "no-problem-info" | "no-known-problems";
/** Type representing a concept from this ValueSet */
export type ProblemsSnomedAbsentUnknownUvIpsConcept = typeof ProblemsSnomedAbsentUnknownUvIpsConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidProblemsSnomedAbsentUnknownUvIpsCode(code: string): code is ProblemsSnomedAbsentUnknownUvIpsCode;
/**
 * Get concept details by code
 */
export declare function getProblemsSnomedAbsentUnknownUvIpsConcept(code: string): ProblemsSnomedAbsentUnknownUvIpsConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ProblemsSnomedAbsentUnknownUvIpsCodes: ("no-problem-info" | "no-known-problems")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomProblemsSnomedAbsentUnknownUvIpsCode(): ProblemsSnomedAbsentUnknownUvIpsCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomProblemsSnomedAbsentUnknownUvIpsConcept(): ProblemsSnomedAbsentUnknownUvIpsConcept;
