import { CodeableConceptIPS } from "./CodeableConceptIPS";
import { VersionNumber } from "./VersionNumber";
import { Coding, Composition, CompositionAttester, CompositionSection, Extension, Identifier, Narrative, Reference } from "fhir/r4";
export interface CompositionUvIpsTypeCoding extends Omit<Coding, 'system' | 'code'> {
    system: "http://loinc.org";
    code: "60591-5";
}
export interface CompositionUvIpsSection extends Omit<CompositionSection, 'code' | 'text'> {
    /** Must Support | @see {@link ./valuesets/ValueSet-DocumentSectionCodes.ts} for valid codes (57 codes) */
    code: CodeableConceptIPS;
    /** Must Support */
    text: Narrative;
}
export interface CompositionUvIps extends Omit<Composition, 'text' | 'identifier' | 'type' | 'subject' | 'author' | 'attester' | 'custodian' | 'section' | 'extension'> {
    /** Must Support */
    text?: Narrative;
    /** Must Support */
    identifier?: Identifier;
    type: {
        coding: CompositionUvIpsTypeCoding[];
    };
    /** Must Support */
    subject: Reference;
    /** Must Support */
    author: Reference[];
    /** Must Support */
    attester?: CompositionAttester[];
    /** Must Support */
    custodian?: Reference;
    /** Must Support */
    section: CompositionUvIpsSection[];
    extension?: (Extension | VersionNumber)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateCompositionUvIps(resource: CompositionUvIps, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
