import { CodeableConceptIPS } from "./CodeableConceptIPS";
import { Procedure, Reference } from "fhir/r4";
export interface ProcedureUvIps extends Omit<Procedure, 'code' | 'subject' | 'bodySite'> {
    /** Must Support | @see {@link ./valuesets/ValueSet-ProceduresSnomedAbsentUnknownUvIps.ts} for valid codes (2 codes) */
    code: CodeableConceptIPS;
    /** Must Support */
    subject: Reference;
    /** @see {@link ./valuesets/ValueSet-BodySite.ts} for valid codes (15 codes) */
    bodySite?: CodeableConceptIPS[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateProcedureUvIps(resource: ProcedureUvIps, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
