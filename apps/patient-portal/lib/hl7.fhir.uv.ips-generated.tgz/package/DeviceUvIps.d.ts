import { CodeableConceptIPS } from "./CodeableConceptIPS";
import { Device, Reference } from "fhir/r4";
export interface DeviceUvIps extends Omit<Device, 'type' | 'patient'> {
    /** Must Support | @see {@link ./valuesets/ValueSet-MedicalDevicesSnomedAbsentUnknownUvIps.ts} for valid codes (2 codes) */
    type?: CodeableConceptIPS;
    /** Must Support */
    patient: Reference;
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateDeviceUvIps(resource: DeviceUvIps, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
