import { SimpleQuantity } from "fhir/r4";
export interface SimpleQuantityIPS extends Omit<SimpleQuantity, 'system' | 'code'> {
    system: "http://unitsofmeasure.org";
    /** Must Support */
    code: string;
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateSimpleQuantityIPS(resource: SimpleQuantityIPS, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
