import { QuantityIPS } from "./QuantityIPS";
import { Ratio } from "fhir/r4";
export interface RatioIPS extends Omit<Ratio, 'numerator' | 'denominator'> {
    /** Must Support */
    numerator?: QuantityIPS;
    /** Must Support */
    denominator?: QuantityIPS;
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateRatioIPS(resource: RatioIPS, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
