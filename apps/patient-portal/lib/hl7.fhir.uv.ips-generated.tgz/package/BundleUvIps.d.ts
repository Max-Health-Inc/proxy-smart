import { BackboneElement, Bundle, Identifier } from "fhir/r4";
export interface BundleUvIps extends Omit<Bundle, 'identifier' | 'type' | 'entry'> {
    /** Must Support */
    identifier: Identifier;
    type: "document";
    /** Must Support */
    entry: BackboneElement[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateBundleUvIps(resource: BundleUvIps, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
