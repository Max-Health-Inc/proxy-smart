import { CodeableConceptIPS } from "./CodeableConceptIPS";
import { Observation, ObservationComponent, Quantity, Reference } from "fhir/r4";
export interface ObservationResultsUvIps extends Omit<Observation, 'status' | 'code' | 'subject' | 'value' | 'component'> {
    status: "final";
    /** Must Support | @see {@link ./valuesets/ValueSet-ObservationCodes.ts} for valid codes (31 codes) */
    code: CodeableConceptIPS;
    /** Must Support */
    subject: Reference;
    /** Must Support */
    value?: Quantity;
    /** Must Support */
    component?: ObservationComponent[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateObservationResultsUvIps(resource: ObservationResultsUvIps, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
