import { CodeableConceptIPS } from "./CodeableConceptIPS";
import { DiagnosticReport, Reference } from "fhir/r4";
export interface DiagnosticReportUvIps extends Omit<DiagnosticReport, 'status' | 'category' | 'code' | 'subject' | 'performer' | 'result'> {
    status: "final";
    /** Must Support | @see {@link ./valuesets/ValueSet-DiagnosticServiceSectionCodes.ts} for valid codes (45 codes) */
    category: CodeableConceptIPS[];
    /** Must Support | @see {@link ./valuesets/ValueSet-LOINCDiagnosticReportCodes.ts} for valid codes (100 codes) */
    code: CodeableConceptIPS;
    /** Must Support */
    subject: Reference;
    /** Must Support */
    performer?: Reference[];
    /** Must Support */
    result?: Reference[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateDiagnosticReportUvIps(resource: DiagnosticReportUvIps, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
