import { Observation, Reference } from "fhir/r4";
export interface ObservationResultsPathologyUvIps extends Omit<Observation, 'status' | 'performer'> {
    status: "final";
    /** Must Support */
    performer: Reference[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateObservationResultsPathologyUvIps(resource: ObservationResultsPathologyUvIps, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
