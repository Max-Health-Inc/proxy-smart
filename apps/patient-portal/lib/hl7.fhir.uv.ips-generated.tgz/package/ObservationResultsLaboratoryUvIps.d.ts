import { CodeableConceptIPS } from "./CodeableConceptIPS";
import { Observation, Reference } from "fhir/r4";
export interface ObservationResultsLaboratoryUvIps extends Omit<Observation, 'status' | 'performer' | 'interpretation'> {
    status: "final";
    /** Must Support */
    performer: Reference[];
    /** @see {@link ./valuesets/ValueSet-ObservationInterpretationCodes.ts} for valid codes (57 codes) */
    interpretation?: CodeableConceptIPS[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateObservationResultsLaboratoryUvIps(resource: ObservationResultsLaboratoryUvIps, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
