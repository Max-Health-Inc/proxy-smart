import { Extension } from "fhir/r4";
export interface DataAbsentReason extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/StructureDefinition/data-absent-reason";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateDataAbsentReason(resource: DataAbsentReason, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
