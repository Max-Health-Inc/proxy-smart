import { CodeableConceptIPS } from "./CodeableConceptIPS";
import { Media, Reference } from "fhir/r4";
export interface MediaObservationUvIps extends Omit<Media, 'status' | 'type' | 'subject'> {
    status: "completed";
    /** @see {@link ./valuesets/ValueSet-MediaType.ts} for valid codes (3 codes) */
    type?: CodeableConceptIPS;
    subject: Reference;
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateMediaObservationUvIps(resource: MediaObservationUvIps, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
