export { createDicomwebClient, getModalityInfo, } from "@babelfhir-ts/dicomweb";
export type { DicomwebClient, DicomwebClientConfig, ModalityInfo, } from "@babelfhir-ts/dicomweb";
import type { ImagingStudyUvIps } from "../index.js";
/** Union of all ImagingStudy profiles in this IG */
export type ImagingStudyProfile = ImagingStudyUvIps;
/** Extract the DICOM Study Instance UID from a profiled ImagingStudy */
export declare function getStudyInstanceUID(study: ImagingStudyProfile): string | null;
/** Get the primary modality from a profiled ImagingStudy */
export declare function getPrimaryModality(study: ImagingStudyProfile): string | null;
/** Get a display title for a profiled ImagingStudy */
export declare function getStudyTitle(study: ImagingStudyProfile): string;
