// Re-export all DICOMweb helpers from @babelfhir-ts/dicomweb
export { createDicomwebClient, getModalityInfo, } from "@babelfhir-ts/dicomweb";
// ── Typed wrappers for IG-specific ImagingStudy profiles ──────────
import { getStudyInstanceUID as _getStudyInstanceUID, getPrimaryModality as _getPrimaryModality, getStudyTitle as _getStudyTitle, } from "@babelfhir-ts/dicomweb";
/** Extract the DICOM Study Instance UID from a profiled ImagingStudy */
export function getStudyInstanceUID(study) {
    return _getStudyInstanceUID(study);
}
/** Get the primary modality from a profiled ImagingStudy */
export function getPrimaryModality(study) {
    return _getPrimaryModality(study);
}
/** Get a display title for a profiled ImagingStudy */
export function getStudyTitle(study) {
    return _getStudyTitle(study);
}
