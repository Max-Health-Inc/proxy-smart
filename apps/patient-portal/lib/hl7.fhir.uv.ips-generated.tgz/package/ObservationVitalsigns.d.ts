import { DataAbsentReasonCode } from "./valuesets/ValueSet-DataAbsentReason";
import { ObservationCategoryCodesCode } from "./valuesets/ValueSet-ObservationCategoryCodes";
import { VitalSignsCode } from "./valuesets/ValueSet-VitalSigns";
import { CodeableConcept, Observation, ObservationComponent, Quantity, Reference } from "fhir/r4";
export interface ObservationVitalsigns extends Omit<Observation, 'category' | 'code' | 'subject' | 'value' | 'dataAbsentReason' | 'component'> {
    /** Must Support | @see {@link ./valuesets/ValueSet-ObservationCategoryCodes.ts} for valid codes (9 codes) */
    category: (CodeableConcept & {
        coding: Array<{
            code: ObservationCategoryCodesCode;
            system: "http://terminology.hl7.org/CodeSystem/observation-category";
        }>;
    } | CodeableConcept)[];
    /** Must Support | @see {@link ./valuesets/ValueSet-VitalSigns.ts} for valid codes (13 codes) */
    code: CodeableConcept & {
        coding: Array<{
            code: VitalSignsCode;
            system: "http://loinc.org";
        }>;
    };
    /** Must Support */
    subject: Reference;
    /** Must Support */
    value?: Quantity;
    /** Must Support | @see {@link ./valuesets/ValueSet-DataAbsentReason.ts} for valid codes (8 codes) */
    dataAbsentReason?: CodeableConcept & {
        coding: Array<{
            code: DataAbsentReasonCode;
            system: "http://terminology.hl7.org/CodeSystem/data-absent-reason";
        }>;
    };
    /** Must Support */
    component?: ObservationComponent[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateObservationVitalsigns(resource: ObservationVitalsigns, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
