import { Extension, RelatedArtifact } from "fhir/r4";
export interface RelatedArtifactExtension extends Omit<Extension, 'url' | 'value'> {
    url: "http://hl7.org/fhir/StructureDefinition/workflow-relatedArtifact";
    value: RelatedArtifact;
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateRelatedArtifactExtension(resource: RelatedArtifactExtension, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
