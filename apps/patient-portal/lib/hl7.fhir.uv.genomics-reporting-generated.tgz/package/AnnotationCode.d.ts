import { Extension } from "fhir/r4";
export interface AnnotationCode extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/annotation-code";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateAnnotationCode(resource: AnnotationCode, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
