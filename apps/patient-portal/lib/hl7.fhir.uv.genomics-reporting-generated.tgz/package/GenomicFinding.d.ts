import { BodyStructureReference } from "./BodyStructureReference";
import { Extension, Observation } from "fhir/r4";
import { SecondaryFinding } from "./SecondaryFinding";
export interface GenomicFinding extends Omit<Observation, 'extension'> {
    extension?: (Extension | SecondaryFinding | BodyStructureReference)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateGenomicFinding(resource: GenomicFinding, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
