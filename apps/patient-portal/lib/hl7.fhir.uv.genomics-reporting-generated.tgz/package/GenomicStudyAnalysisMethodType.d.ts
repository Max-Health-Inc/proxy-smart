import { Extension } from "fhir/r4";
export interface GenomicStudyAnalysisMethodType extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-analysis-method-type";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateGenomicStudyAnalysisMethodType(resource: GenomicStudyAnalysisMethodType, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
