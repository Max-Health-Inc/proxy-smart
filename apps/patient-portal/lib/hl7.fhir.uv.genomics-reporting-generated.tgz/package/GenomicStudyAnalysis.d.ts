import { GenomicStudyAnalysisChangeType } from "./GenomicStudyAnalysisChangeType";
import { GenomicStudyAnalysisDevice } from "./GenomicStudyAnalysisDevice";
import { GenomicStudyAnalysisFocus } from "./GenomicStudyAnalysisFocus";
import { GenomicStudyAnalysisGenomeBuild } from "./GenomicStudyAnalysisGenomeBuild";
import { GenomicStudyAnalysisGenomicSourceClass } from "./GenomicStudyAnalysisGenomicSourceClass";
import { GenomicStudyAnalysisInput } from "./GenomicStudyAnalysisInput";
import { GenomicStudyAnalysisMethodType } from "./GenomicStudyAnalysisMethodType";
import { GenomicStudyAnalysisMetrics } from "./GenomicStudyAnalysisMetrics";
import { GenomicStudyAnalysisOutput } from "./GenomicStudyAnalysisOutput";
import { GenomicStudyAnalysisProtocolPerformed } from "./GenomicStudyAnalysisProtocolPerformed";
import { GenomicStudyAnalysisRegions } from "./GenomicStudyAnalysisRegions";
import { GenomicStudyAnalysisSpecimen } from "./GenomicStudyAnalysisSpecimen";
import { GenomicStudyAnalysisTitle } from "./GenomicStudyAnalysisTitle";
import { Extension, Procedure } from "fhir/r4";
export interface GenomicStudyAnalysis extends Omit<Procedure, 'status' | 'extension'> {
    status: "completed";
    extension?: (Extension | GenomicStudyAnalysisMethodType | GenomicStudyAnalysisChangeType | GenomicStudyAnalysisGenomeBuild | GenomicStudyAnalysisGenomicSourceClass | GenomicStudyAnalysisTitle | GenomicStudyAnalysisFocus | GenomicStudyAnalysisSpecimen | GenomicStudyAnalysisMetrics | GenomicStudyAnalysisRegions | GenomicStudyAnalysisDevice | GenomicStudyAnalysisProtocolPerformed | GenomicStudyAnalysisInput | GenomicStudyAnalysisOutput)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateGenomicStudyAnalysis(resource: GenomicStudyAnalysis, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
