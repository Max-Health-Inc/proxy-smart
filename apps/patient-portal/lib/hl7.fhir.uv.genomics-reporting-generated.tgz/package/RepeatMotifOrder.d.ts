import { Extension } from "fhir/r4";
export interface RepeatMotifOrder extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/repeat-motif-order";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateRepeatMotifOrder(resource: RepeatMotifOrder, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
