import { Extension } from "fhir/r4";
export interface GenomicRiskAssessment extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-risk-assessment";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateGenomicRiskAssessment(resource: GenomicRiskAssessment, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
