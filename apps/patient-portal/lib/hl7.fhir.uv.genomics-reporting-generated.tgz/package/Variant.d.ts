import { BodyStructureReference } from "./BodyStructureReference";
import { CodeableConcept, Coding, Extension, Observation, ObservationComponent } from "fhir/r4";
import { RepeatMotifOrder } from "./RepeatMotifOrder";
import { SecondaryFinding } from "./SecondaryFinding";
export interface VariantCodeCoding extends Omit<Coding, 'system' | 'code'> {
    system: "http://loinc.org";
    code: "69548-6";
}
export interface VariantComponent extends Omit<ObservationComponent, 'code' | 'extension'> {
    /** @see {@link ./valuesets/ValueSet-ObservationCodes.ts} for valid codes (100 codes) */
    code: CodeableConcept;
    extension?: (Extension | RepeatMotifOrder | RepeatMotifOrder)[];
}
export interface Variant extends Omit<Observation, 'code' | 'component' | 'extension'> {
    code: {
        coding: VariantCodeCoding[];
    };
    component?: VariantComponent[];
    extension?: (Extension | SecondaryFinding | BodyStructureReference)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateVariant(resource: Variant, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
