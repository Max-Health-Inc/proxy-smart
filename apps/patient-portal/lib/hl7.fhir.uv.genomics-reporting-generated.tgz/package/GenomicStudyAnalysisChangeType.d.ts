import { Extension } from "fhir/r4";
export interface GenomicStudyAnalysisChangeType extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-analysis-change-type";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateGenomicStudyAnalysisChangeType(resource: GenomicStudyAnalysisChangeType, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
