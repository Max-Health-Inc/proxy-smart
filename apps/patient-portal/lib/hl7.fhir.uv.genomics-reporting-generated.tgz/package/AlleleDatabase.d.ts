import { CodeableConcept, Extension } from "fhir/r4";
export interface AlleleDatabase extends Omit<Extension, 'url' | 'value'> {
    url: "http://hl7.org/fhir/StructureDefinition/hla-genotyping-results-allele-database";
    value: CodeableConcept;
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateAlleleDatabase(resource: AlleleDatabase, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
