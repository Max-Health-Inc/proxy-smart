import { Extension, Reference } from "fhir/r4";
export interface BodyStructureReference extends Omit<Extension, 'url' | 'value'> {
    url: "http://hl7.org/fhir/StructureDefinition/bodySite";
    value: Reference;
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateBodyStructureReference(resource: BodyStructureReference, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
