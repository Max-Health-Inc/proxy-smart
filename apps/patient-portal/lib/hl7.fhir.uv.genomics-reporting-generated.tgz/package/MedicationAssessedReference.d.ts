import { Extension } from "fhir/r4";
export interface MedicationAssessedReference extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/medication-assessed-reference";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateMedicationAssessedReference(resource: MedicationAssessedReference, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
