import { Extension } from "fhir/r4";
export interface GenomicStudyReferrerExt extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-referrer-ext";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateGenomicStudyReferrerExt(resource: GenomicStudyReferrerExt, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
