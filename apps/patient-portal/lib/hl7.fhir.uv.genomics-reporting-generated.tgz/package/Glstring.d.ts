import { Extension } from "fhir/r4";
export interface Glstring extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/StructureDefinition/hla-genotyping-results-glstring";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateGlstring(resource: Glstring, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
