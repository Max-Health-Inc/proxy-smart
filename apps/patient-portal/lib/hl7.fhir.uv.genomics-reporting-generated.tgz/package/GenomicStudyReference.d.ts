import { Extension } from "fhir/r4";
export interface GenomicStudyReference extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-reference";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateGenomicStudyReference(resource: GenomicStudyReference, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
