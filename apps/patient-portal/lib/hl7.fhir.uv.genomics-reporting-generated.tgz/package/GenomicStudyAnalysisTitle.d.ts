import { Extension } from "fhir/r4";
export interface GenomicStudyAnalysisTitle extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-analysis-title";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateGenomicStudyAnalysisTitle(resource: GenomicStudyAnalysisTitle, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
