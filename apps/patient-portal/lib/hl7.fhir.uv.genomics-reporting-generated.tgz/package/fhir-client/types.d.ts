import type * as GeneratedTypes from "../index.js";
/**
 * A FHIR resource with an ID
 */
export type WithId<T> = {
    id: string;
} & T;
/**
 * Search parameters for FHIR resources
 */
export type SearchParams = Record<string, boolean | number | string | string[] | undefined>;
/**
 * Bundle of FHIR resources
 */
export interface Bundle<T> {
    resourceType: "Bundle";
    type: "collection" | "searchset" | "transaction-response" | "transaction";
    total?: number;
    link?: {
        relation: string;
        url: string;
    }[];
    entry?: {
        resource: T;
        fullUrl?: string;
    }[];
}
/**
 * Type-safe FHIR resource types
 */
export type FhirResource = GeneratedTypes.DiagnosticImplication | GeneratedTypes.FollowupRecommendation | GeneratedTypes.GenomicBase | GeneratedTypes.GenomicFinding | GeneratedTypes.GenomicImplication | GeneratedTypes.GenomicReport | GeneratedTypes.GenomicStudy | GeneratedTypes.GenomicStudyAnalysis | GeneratedTypes.Genotype | GeneratedTypes.Haplotype | GeneratedTypes.MedicationRecommendation | GeneratedTypes.MolecularConsequence | GeneratedTypes.SequencePhaseRelationship | GeneratedTypes.TherapeuticImplication | GeneratedTypes.Variant;
