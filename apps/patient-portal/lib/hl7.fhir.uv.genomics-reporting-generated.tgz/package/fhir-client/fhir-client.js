import { FhirReadClient as BaseFhirReadClient, FhirWriteClient as BaseFhirWriteClient, } from "@babelfhir-ts/client-r4";
/**
 * Profile-specific FHIR Read Client.
 * Extends the base R4 read client with typed profile accessors.
 * Inherits all base R4 resource methods from @babelfhir-ts/client-r4.
 */
export class FhirReadClient extends BaseFhirReadClient {
    diagnosticImplication() {
        return this.forType("Observation");
    }
    followupRecommendation() {
        return this.forType("Task");
    }
    genomicBase() {
        return this.forType("Observation");
    }
    genomicFinding() {
        return this.forType("Observation");
    }
    genomicImplication() {
        return this.forType("Observation");
    }
    genomicReport() {
        return this.forType("DiagnosticReport");
    }
    genomicStudy() {
        return this.forType("Procedure");
    }
    genomicStudyAnalysis() {
        return this.forType("Procedure");
    }
    genotype() {
        return this.forType("Observation");
    }
    haplotype() {
        return this.forType("Observation");
    }
    medicationRecommendation() {
        return this.forType("Task");
    }
    molecularConsequence() {
        return this.forType("Observation");
    }
    sequencePhaseRelationship() {
        return this.forType("Observation");
    }
    therapeuticImplication() {
        return this.forType("Observation");
    }
    variant() {
        return this.forType("Observation");
    }
}
/**
 * Profile-specific FHIR Write Client.
 * Extends the base R4 write client with typed profile accessors.
 * Inherits all base R4 resource methods from @babelfhir-ts/client-r4.
 */
export class FhirWriteClient extends BaseFhirWriteClient {
    diagnosticImplication() {
        return this.forType("Observation");
    }
    followupRecommendation() {
        return this.forType("Task");
    }
    genomicBase() {
        return this.forType("Observation");
    }
    genomicFinding() {
        return this.forType("Observation");
    }
    genomicImplication() {
        return this.forType("Observation");
    }
    genomicReport() {
        return this.forType("DiagnosticReport");
    }
    genomicStudy() {
        return this.forType("Procedure");
    }
    genomicStudyAnalysis() {
        return this.forType("Procedure");
    }
    genotype() {
        return this.forType("Observation");
    }
    haplotype() {
        return this.forType("Observation");
    }
    medicationRecommendation() {
        return this.forType("Task");
    }
    molecularConsequence() {
        return this.forType("Observation");
    }
    sequencePhaseRelationship() {
        return this.forType("Observation");
    }
    therapeuticImplication() {
        return this.forType("Observation");
    }
    variant() {
        return this.forType("Observation");
    }
}
/**
 * Main FHIR Client — works with plain fetch or an authenticated fetch wrapper.
 * Provides both base R4 accessors (inherited) and profile-specific accessors.
 *
 * @example
 * // Unauthenticated
 * const client = new FhirClient("https://fhir.example.com");
 *
 * // With custom fetch (e.g. from SmartFhirClient)
 * const client = new FhirClient("https://fhir.example.com", authenticatedFetch);
 *
 * // Base R4 methods (inherited from @babelfhir-ts/client-r4)
 * const pt = await client.read().patient().read("123");
 *
 * // Profile-specific methods (generated)
 * const claim = await client.read().pASClaim().search({ status: "active" });
 */
export class FhirClient {
    constructor(baseUrl, fetchFn) {
        this.baseUrl = baseUrl;
        this.readClient = new FhirReadClient(baseUrl, fetchFn);
        this.writeClient = new FhirWriteClient(baseUrl, fetchFn);
    }
    /**
     * Get a read client for querying resources
     */
    read() {
        return this.readClient;
    }
    /**
     * Get a write client for creating/updating resources
     */
    write() {
        return this.writeClient;
    }
}
