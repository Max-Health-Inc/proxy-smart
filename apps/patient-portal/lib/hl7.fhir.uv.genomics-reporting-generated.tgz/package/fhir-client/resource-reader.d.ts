import type * as GeneratedTypes from "../index.js";
import type { Bundle, SearchParams, WithId } from "./types.js";
/**
 * Generic FHIR resource searcher/reader
 */
export interface FhirResourceSearcher<T> {
    readonly baseUrl: string;
    readonly resourceType: string;
    /**
     * Read a resource by ID
     */
    read(id: string): Promise<WithId<T>>;
    /**
     * Search for resources
     */
    search(params?: SearchParams): Promise<Bundle<WithId<T>>>;
    /**
     * Search and return first result or undefined
     */
    searchOne(params?: SearchParams): Promise<undefined | WithId<T>>;
    /**
     * Search and return all results (handles pagination)
     */
    searchAll(params?: SearchParams): Promise<WithId<T>[]>;
}
/**
 * Specific reader types for type safety
 */
export type DiagnosticImplicationReader = FhirResourceSearcher<GeneratedTypes.DiagnosticImplication>;
export type FollowupRecommendationReader = FhirResourceSearcher<GeneratedTypes.FollowupRecommendation>;
export type GenomicBaseReader = FhirResourceSearcher<GeneratedTypes.GenomicBase>;
export type GenomicFindingReader = FhirResourceSearcher<GeneratedTypes.GenomicFinding>;
export type GenomicImplicationReader = FhirResourceSearcher<GeneratedTypes.GenomicImplication>;
export type GenomicReportReader = FhirResourceSearcher<GeneratedTypes.GenomicReport>;
export type GenomicStudyReader = FhirResourceSearcher<GeneratedTypes.GenomicStudy>;
export type GenomicStudyAnalysisReader = FhirResourceSearcher<GeneratedTypes.GenomicStudyAnalysis>;
export type GenotypeReader = FhirResourceSearcher<GeneratedTypes.Genotype>;
export type HaplotypeReader = FhirResourceSearcher<GeneratedTypes.Haplotype>;
export type MedicationRecommendationReader = FhirResourceSearcher<GeneratedTypes.MedicationRecommendation>;
export type MolecularConsequenceReader = FhirResourceSearcher<GeneratedTypes.MolecularConsequence>;
export type SequencePhaseRelationshipReader = FhirResourceSearcher<GeneratedTypes.SequencePhaseRelationship>;
export type TherapeuticImplicationReader = FhirResourceSearcher<GeneratedTypes.TherapeuticImplication>;
export type VariantReader = FhirResourceSearcher<GeneratedTypes.Variant>;
/**
 * Custom fetch function type for injecting auth headers
 */
export type FetchFn = typeof globalThis.fetch;
/**
 * Implementation of FHIR resource reader
 */
export declare class FhirResourceReader<T> implements FhirResourceSearcher<T> {
    readonly baseUrl: string;
    readonly resourceType: string;
    private readonly fetchFn;
    constructor(baseUrl: string, resourceType: string, fetchFn?: FetchFn);
    read(id: string): Promise<WithId<T>>;
    search(params?: SearchParams): Promise<Bundle<WithId<T>>>;
    searchOne(params?: SearchParams): Promise<undefined | WithId<T>>;
    searchAll(params?: SearchParams): Promise<WithId<T>[]>;
}
