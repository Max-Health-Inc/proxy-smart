import type * as GeneratedTypes from "../index.js";
import type { WithId } from "./types.js";
/**
 * Generic FHIR resource writer
 */
export interface FhirResourceWriter<T> {
    readonly baseUrl: string;
    readonly resourceType: string;
    /**
     * Create a new resource
     */
    create(resource: T): Promise<WithId<T>>;
    /**
     * Update an existing resource
     */
    update(resource: WithId<T>): Promise<WithId<T>>;
    /**
     * Delete a resource
     */
    delete(id: string): Promise<void>;
    /**
     * Create or update (upsert)
     */
    createOrUpdate(resource: T | WithId<T>): Promise<WithId<T>>;
}
/**
 * Specific writer types for type safety
 */
export type DiagnosticImplicationWriter = FhirResourceWriter<GeneratedTypes.DiagnosticImplication>;
export type FollowupRecommendationWriter = FhirResourceWriter<GeneratedTypes.FollowupRecommendation>;
export type GenomicBaseWriter = FhirResourceWriter<GeneratedTypes.GenomicBase>;
export type GenomicFindingWriter = FhirResourceWriter<GeneratedTypes.GenomicFinding>;
export type GenomicImplicationWriter = FhirResourceWriter<GeneratedTypes.GenomicImplication>;
export type GenomicReportWriter = FhirResourceWriter<GeneratedTypes.GenomicReport>;
export type GenomicStudyWriter = FhirResourceWriter<GeneratedTypes.GenomicStudy>;
export type GenomicStudyAnalysisWriter = FhirResourceWriter<GeneratedTypes.GenomicStudyAnalysis>;
export type GenotypeWriter = FhirResourceWriter<GeneratedTypes.Genotype>;
export type HaplotypeWriter = FhirResourceWriter<GeneratedTypes.Haplotype>;
export type MedicationRecommendationWriter = FhirResourceWriter<GeneratedTypes.MedicationRecommendation>;
export type MolecularConsequenceWriter = FhirResourceWriter<GeneratedTypes.MolecularConsequence>;
export type SequencePhaseRelationshipWriter = FhirResourceWriter<GeneratedTypes.SequencePhaseRelationship>;
export type TherapeuticImplicationWriter = FhirResourceWriter<GeneratedTypes.TherapeuticImplication>;
export type VariantWriter = FhirResourceWriter<GeneratedTypes.Variant>;
import type { FetchFn } from "./resource-reader.js";
/**
 * Implementation of FHIR resource writer
 */
export declare class FhirResourceWriterImpl<T> implements FhirResourceWriter<T> {
    readonly baseUrl: string;
    readonly resourceType: string;
    private readonly fetchFn;
    constructor(baseUrl: string, resourceType: string, fetchFn?: FetchFn);
    create(resource: T): Promise<WithId<T>>;
    update(resource: WithId<T>): Promise<WithId<T>>;
    delete(id: string): Promise<void>;
    createOrUpdate(resource: T | WithId<T>): Promise<WithId<T>>;
}
