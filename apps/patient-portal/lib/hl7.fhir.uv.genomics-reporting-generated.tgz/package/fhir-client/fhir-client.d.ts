import { FhirReadClient as BaseFhirReadClient, FhirWriteClient as BaseFhirWriteClient, type FetchFn } from "@babelfhir-ts/client-r4";
import type * as GeneratedTypes from "../index.js";
/**
 * Profile-specific FHIR Read Client.
 * Extends the base R4 read client with typed profile accessors.
 * Inherits all base R4 resource methods from @babelfhir-ts/client-r4.
 */
export declare class FhirReadClient extends BaseFhirReadClient {
    diagnosticImplication(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.DiagnosticImplication>;
    followupRecommendation(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.FollowupRecommendation>;
    genomicBase(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.GenomicBase>;
    genomicFinding(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.GenomicFinding>;
    genomicImplication(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.GenomicImplication>;
    genomicReport(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.GenomicReport>;
    genomicStudy(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.GenomicStudy>;
    genomicStudyAnalysis(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.GenomicStudyAnalysis>;
    genotype(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.Genotype>;
    haplotype(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.Haplotype>;
    medicationRecommendation(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.MedicationRecommendation>;
    molecularConsequence(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.MolecularConsequence>;
    sequencePhaseRelationship(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.SequencePhaseRelationship>;
    therapeuticImplication(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.TherapeuticImplication>;
    variant(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.Variant>;
}
/**
 * Profile-specific FHIR Write Client.
 * Extends the base R4 write client with typed profile accessors.
 * Inherits all base R4 resource methods from @babelfhir-ts/client-r4.
 */
export declare class FhirWriteClient extends BaseFhirWriteClient {
    diagnosticImplication(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.DiagnosticImplication>;
    followupRecommendation(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.FollowupRecommendation>;
    genomicBase(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.GenomicBase>;
    genomicFinding(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.GenomicFinding>;
    genomicImplication(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.GenomicImplication>;
    genomicReport(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.GenomicReport>;
    genomicStudy(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.GenomicStudy>;
    genomicStudyAnalysis(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.GenomicStudyAnalysis>;
    genotype(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.Genotype>;
    haplotype(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.Haplotype>;
    medicationRecommendation(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.MedicationRecommendation>;
    molecularConsequence(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.MolecularConsequence>;
    sequencePhaseRelationship(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.SequencePhaseRelationship>;
    therapeuticImplication(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.TherapeuticImplication>;
    variant(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.Variant>;
}
/**
 * Main FHIR Client — works with plain fetch or an authenticated fetch wrapper.
 * Provides both base R4 accessors (inherited) and profile-specific accessors.
 *
 * @example
 * // Unauthenticated
 * const client = new FhirClient("https://fhir.example.com");
 *
 * // With custom fetch (e.g. from SmartFhirClient)
 * const client = new FhirClient("https://fhir.example.com", authenticatedFetch);
 *
 * // Base R4 methods (inherited from @babelfhir-ts/client-r4)
 * const pt = await client.read().patient().read("123");
 *
 * // Profile-specific methods (generated)
 * const claim = await client.read().pASClaim().search({ status: "active" });
 */
export declare class FhirClient {
    readonly baseUrl: string;
    private readonly readClient;
    private readonly writeClient;
    constructor(baseUrl: string, fetchFn?: FetchFn);
    /**
     * Get a read client for querying resources
     */
    read(): FhirReadClient;
    /**
     * Get a write client for creating/updating resources
     */
    write(): FhirWriteClient;
}
