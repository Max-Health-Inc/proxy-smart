import { Extension } from "fhir/r4";
export interface GenomicStudyAnalysisSpecimen extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-analysis-specimen";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateGenomicStudyAnalysisSpecimen(resource: GenomicStudyAnalysisSpecimen, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
