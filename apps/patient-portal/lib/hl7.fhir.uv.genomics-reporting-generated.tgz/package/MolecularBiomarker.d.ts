import { Observation } from "fhir/r4";
export type MolecularBiomarker = Observation;
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateMolecularBiomarker(resource: MolecularBiomarker, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
