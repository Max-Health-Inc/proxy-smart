import { validateVariant } from "./Variant.js";
// Only import helpers actually referenced below (dynamic based on required fields)
import { randomId, setRandomSeed, enrichResource } from "./random/index.js";
import { createRequire } from 'module';
const __require = createRequire(import.meta.url);
function ensureProfile(res, profile) {
    if (!res.meta) {
        res.meta = { profile: [profile] };
        return;
    }
    if (!res.meta.profile) {
        res.meta.profile = [profile];
        return;
    }
    if (!res.meta.profile.includes(profile)) {
        res.meta.profile = [...res.meta.profile, profile];
    }
}
// Internal helper (emitted per class file) to clone without resorting to 'any'.
function safeClone(value) {
    // Use native structuredClone if present; otherwise fallback to JSON round-trip.
    // We intentionally avoid casting through any to satisfy no-explicit-any lint rule.
    const g = globalThis;
    // Narrow globalThis to an object potentially containing structuredClone.
    if (typeof g.structuredClone === 'function') {
        return g.structuredClone(value);
    }
    return JSON.parse(JSON.stringify(value)); // best-effort deep clone
}
export class VariantClass {
    constructor(resource) {
        this.resource = resource;
        ensureProfile(this.resource, 'http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/variant');
    }
    /** Validate current resource instance. */
    async validate(options) {
        return validateVariant(this.resource, options);
    }
    getResource() {
        return this.resource;
    }
    setResource(resource) {
        this.resource = resource;
        ensureProfile(this.resource, 'http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/variant');
    }
    /**
     * Returns a plain JSON clone of the underlying resource ONLY if the last validation succeeded with zero errors.
     * Call validate() first; otherwise this method throws to prevent accidental use of invalid / unchecked data.
     */
    async toJSON() {
        return safeClone(this.resource);
    }
    /**
     * Create an empty instance for parity testing: for true FHIR resources, includes only resourceType; for datatypes, returns an empty object.
     * Note: meta.profile (when applicable) will be ensured by the constructor when wrapping this resource.
     */
    static empty(overrides = {}) {
        // For Resource profiles, include only resourceType. For Extension profiles, include url so the instance is minimally meaningful.
        const base = {
            resourceType: 'Observation',
        };
        return { ...base, ...overrides };
    }
    /**
     * Create a minimal randomized instance of Variant.
     * Populates id, resourceType (if applicable) and primitive required (min>0) top-level fields with placeholders.
     */
    static random(overrides = {}, opts) {
        if (opts?.seed !== undefined) {
            // Direct call (no dynamic require) to ensure deterministic seeding works under ESM.
            setRandomSeed(opts.seed);
        }
        // Start with a Partial to avoid unsafe casting errors; we'll assert at the end.
        const base = { resourceType: 'Observation', id: randomId(), status: "final", category: [{ coding: [{ "system": "http://terminology.hl7.org/CodeSystem/observation-category", "code": "laboratory" }] }, { coding: [{ "system": "http://terminology.hl7.org/CodeSystem/v2-0074", "code": "GE" }] }], code: { coding: [{ system: "http://loinc.org", code: "69548-6" }] }, };
        // Always include meta.profile with this profile's canonical URL if available & only for resource profiles
        ensureProfile(base, 'http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/variant');
        // Enrich the base resource with common fields using centralized enrichment logic
        enrichResource(base, 'Observation', 'http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/variant', VariantClass._fieldPatterns, VariantClass._forbiddenFields, VariantClass.valueSetBindings, VariantClass._codeResolver, VariantClass._fieldOrder);
        // Cast through unknown to acknowledge dynamic enrichment
        return { ...base, ...overrides };
    }
    /** Convenience: returns a class instance wrapping a randomized resource. */
    static randomClass(overrides = {}, opts) {
        return new VariantClass(this.random(overrides, opts));
    }
}
/** Pattern constraints for profile fields (used by random() generator) */
VariantClass._fieldPatterns = {
    "category": {
        "coding": [
            {
                "system": "http://terminology.hl7.org/CodeSystem/observation-category",
                "code": "laboratory"
            },
            {
                "system": "http://terminology.hl7.org/CodeSystem/v2-0074",
                "code": "GE"
            }
        ]
    },
    "code": {
        "coding": [
            {
                "system": "http://loinc.org",
                "code": "69548-6"
            }
        ]
    },
    "component.code": "2571-8",
    "conclusion-string.code": {
        "coding": [
            {
                "system": "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
                "code": "conclusion-string"
            }
        ]
    },
    "gene-studied.code": {
        "coding": [
            {
                "system": "http://loinc.org",
                "code": "48018-6"
            }
        ]
    },
    "cytogenetic-location.code": {
        "coding": [
            {
                "system": "http://loinc.org",
                "code": "48001-2"
            }
        ]
    },
    "reference-sequence-assembly.code": {
        "coding": [
            {
                "system": "http://loinc.org",
                "code": "62374-4"
            }
        ]
    },
    "chromosome-identifier.code": {
        "coding": [
            {
                "system": "http://loinc.org",
                "code": "48000-4"
            }
        ]
    },
    "representative-coding-hgvs.code": {
        "coding": [
            {
                "system": "http://loinc.org",
                "code": "48004-6"
            }
        ]
    },
    "genomic-hgvs.code": {
        "coding": [
            {
                "system": "http://loinc.org",
                "code": "81290-9"
            }
        ]
    },
    "cytogenomic-nomenclature.code": {
        "coding": [
            {
                "system": "http://loinc.org",
                "code": "81291-7"
            }
        ]
    },
    "genomic-ref-seq.code": {
        "coding": [
            {
                "system": "http://loinc.org",
                "code": "48013-7"
            }
        ]
    },
    "representative-protein-ref-seq.code": {
        "coding": [
            {
                "system": "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
                "code": "protein-ref-seq"
            }
        ]
    },
    "representative-transcript-ref-seq.code": {
        "coding": [
            {
                "system": "http://loinc.org",
                "code": "51958-7"
            }
        ]
    },
    "exact-start-end.code": {
        "coding": [
            {
                "system": "http://loinc.org",
                "code": "81254-5"
            }
        ]
    },
    "inner-start-end.code": {
        "coding": [
            {
                "system": "http://loinc.org",
                "code": "81302-2"
            }
        ]
    },
    "outer-start-end.code": {
        "coding": [
            {
                "system": "http://loinc.org",
                "code": "81301-4"
            }
        ]
    },
    "coordinate-system.code": {
        "coding": [
            {
                "system": "http://loinc.org",
                "code": "92822-6"
            }
        ]
    },
    "ref-allele.code": {
        "coding": [
            {
                "system": "http://loinc.org",
                "code": "69547-8"
            }
        ]
    },
    "alt-allele.code": {
        "coding": [
            {
                "system": "http://loinc.org",
                "code": "69551-0"
            }
        ]
    },
    "coding-change-type.code": {
        "coding": [
            {
                "system": "http://loinc.org",
                "code": "48019-4"
            }
        ]
    },
    "genomic-source-class.code": {
        "coding": [
            {
                "system": "http://loinc.org",
                "code": "48002-0"
            }
        ]
    },
    "sample-allelic-frequency.code": {
        "coding": [
            {
                "system": "http://loinc.org",
                "code": "81258-6"
            }
        ]
    },
    "sample-allelic-frequency.comparator": ">",
    "sample-allelic-frequency.system": "http://unitsofmeasure.org",
    "allelic-read-depth.code": {
        "coding": [
            {
                "system": "http://loinc.org",
                "code": "82121-5"
            }
        ]
    },
    "allelic-state.code": {
        "coding": [
            {
                "system": "http://loinc.org",
                "code": "53034-5"
            }
        ]
    },
    "variant-inheritance.code": {
        "coding": [
            {
                "system": "http://loinc.org",
                "code": "94186-4"
            }
        ]
    },
    "variant-inheritance-basis.code": {
        "coding": [
            {
                "system": "http://loinc.org",
                "code": "82309-6"
            }
        ]
    },
    "variation-code.code": {
        "coding": [
            {
                "system": "http://loinc.org",
                "code": "81252-9"
            }
        ]
    },
    "representative-protein-hgvs.code": {
        "coding": [
            {
                "system": "http://loinc.org",
                "code": "48005-3"
            }
        ]
    },
    "copy-number.code": {
        "coding": [
            {
                "system": "http://loinc.org",
                "code": "82155-3"
            }
        ]
    },
    "variant-confidence-status.code": {
        "coding": [
            {
                "system": "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
                "code": "variant-confidence-status"
            }
        ]
    },
    "repeat-motif.code": {
        "coding": [
            {
                "system": "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
                "code": "repeat-motif"
            }
        ]
    },
    "repeat-number.code": {
        "coding": [
            {
                "system": "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
                "code": "repeat-number"
            }
        ]
    },
    "_refReq_category": {
        "coding": true
    },
    "_refReq_component": {
        "code": true,
        "valueCodeableConcept": true,
        "valueString": true,
        "valueQuantity": true
    },
    "_choiceType_effective[x]": [
        "dateTime",
        "Period",
        "Timing",
        "instant"
    ],
    "_choiceType_value[x]": [
        "Quantity",
        "CodeableConcept",
        "string",
        "boolean",
        "integer",
        "Range",
        "Ratio",
        "SampledData",
        "time",
        "dateTime",
        "Period"
    ]
};
/** Fields that are forbidden (max=0) in this profile - must not be generated */
VariantClass._forbiddenFields = [];
/** FHIR element ordering for this profile's base resource (used by enrichResource for correct JSON field order) */
VariantClass._fieldOrder = ["id", "meta", "implicitRules", "language", "text", "contained", "extension", "modifierExtension", "identifier", "basedOn", "partOf", "status", "category", "code", "subject", "focus", "encounter", "effective[x]", "issued", "performer", "value[x]", "dataAbsentReason", "interpretation", "note", "bodySite", "method", "specimen", "device", "referenceRange", "hasMember", "derivedFrom", "component"];
/** ValueSet bindings for coded fields - maps field name to ValueSet URL */
VariantClass.valueSetBindings = {
    "language": "http://hl7.org/fhir/ValueSet/languages",
    "status": "http://hl7.org/fhir/ValueSet/observation-status|4.0.1",
    "category": "http://hl7.org/fhir/ValueSet/observation-category",
    "code": "http://hl7.org/fhir/ValueSet/observation-codes",
    "value[x]": "http://loinc.org/vs/LL1971-2",
    "dataAbsentReason": "http://hl7.org/fhir/ValueSet/data-absent-reason",
    "interpretation": "http://hl7.org/fhir/ValueSet/observation-interpretation",
    "bodySite": "http://hl7.org/fhir/ValueSet/body-site",
    "method": "http://loinc.org/vs/LL4048-6",
    "referenceRange.type": "http://hl7.org/fhir/ValueSet/referencerange-meaning",
    "referenceRange.appliesTo": "http://hl7.org/fhir/ValueSet/referencerange-appliesto",
    "component.code": "http://hl7.org/fhir/ValueSet/observation-codes",
    "component.dataAbsentReason": "http://hl7.org/fhir/ValueSet/data-absent-reason",
    "component.interpretation": "http://hl7.org/fhir/ValueSet/observation-interpretation",
    "component.value[x]": "http://hl7.org/fhir/uv/genomics-reporting/ValueSet/hgnc-vs",
    "component.value[x].comparator": "http://hl7.org/fhir/ValueSet/quantity-comparator|4.0.1"
};
/** Code resolver for ValueSet bindings - returns a random valid code from a ValueSet by URL */
VariantClass._codeResolver = (() => {
    // Try to load the ValueSetRegistry - it may not exist if no ValueSets were generated
    try {
        const registry = __require('./valuesets/index.js');
        if (registry && typeof registry.getRandomConceptByUrl === 'function') {
            return registry.getRandomConceptByUrl;
        }
    }
    catch { /* ValueSetRegistry not available */ }
    return undefined;
})();
