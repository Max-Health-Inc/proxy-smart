import { Extension } from "fhir/r4";
export interface GenomicStudyAnalysisMetrics extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-analysis-metrics";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateGenomicStudyAnalysisMetrics(resource: GenomicStudyAnalysisMetrics, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
