import { CodeableConcept, Extension } from "fhir/r4";
export interface SecondaryFinding extends Omit<Extension, 'url' | 'value'> {
    url: "http://hl7.org/fhir/StructureDefinition/observation-secondaryFinding";
    value: CodeableConcept;
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateSecondaryFinding(resource: SecondaryFinding, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
