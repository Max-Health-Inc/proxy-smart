import { Extension } from "fhir/r4";
export interface RelatedArtifactComponent extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/workflow-relatedArtifactComponent";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateRelatedArtifactComponent(resource: RelatedArtifactComponent, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
