import { CodedAnnotation } from "./CodedAnnotation";
import { Extension } from "fhir/r4";
export interface GenomicReportNote extends Omit<Extension, 'url' | 'value'> {
    url: "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-report-note";
    value?: CodedAnnotation;
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateGenomicReportNote(resource: GenomicReportNote, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
