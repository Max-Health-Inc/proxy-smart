import { Extension } from "fhir/r4";
export interface GenomicStudyAnalysisDevice extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-analysis-device";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateGenomicStudyAnalysisDevice(resource: GenomicStudyAnalysisDevice, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
