import { Extension } from "fhir/r4";
export interface GenomicStudyAnalysisRegions extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-analysis-regions";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateGenomicStudyAnalysisRegions(resource: GenomicStudyAnalysisRegions, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
