import { Extension } from "fhir/r4";
export interface GenomicStudyAnalysisOutput extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-analysis-output";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateGenomicStudyAnalysisOutput(resource: GenomicStudyAnalysisOutput, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
