import { DocumentReference } from "fhir/r4";
export type GenomicDataFile = DocumentReference;
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateGenomicDataFile(resource: GenomicDataFile, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
