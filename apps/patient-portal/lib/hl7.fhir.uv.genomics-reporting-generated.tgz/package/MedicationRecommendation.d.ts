import { Task } from "fhir/r4";
export interface MedicationRecommendation extends Omit<Task, 'status' | 'intent'> {
    status: "requested";
    intent: "proposal";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateMedicationRecommendation(resource: MedicationRecommendation, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
