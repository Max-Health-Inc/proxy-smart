import { AnnotationCode } from "./AnnotationCode";
import { Annotation, Extension } from "fhir/r4";
export interface CodedAnnotation extends Omit<Annotation, 'extension'> {
    extension?: (Extension | AnnotationCode)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateCodedAnnotation(resource: CodedAnnotation, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
