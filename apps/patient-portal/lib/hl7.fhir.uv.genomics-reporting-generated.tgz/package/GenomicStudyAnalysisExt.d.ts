import { Extension } from "fhir/r4";
export interface GenomicStudyAnalysisExt extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-analysis-ext";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateGenomicStudyAnalysisExt(resource: GenomicStudyAnalysisExt, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
