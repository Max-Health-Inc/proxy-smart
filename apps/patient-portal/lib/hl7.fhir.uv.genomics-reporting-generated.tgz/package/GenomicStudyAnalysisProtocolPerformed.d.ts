import { Extension } from "fhir/r4";
export interface GenomicStudyAnalysisProtocolPerformed extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-analysis-protocol-performed";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateGenomicStudyAnalysisProtocolPerformed(resource: GenomicStudyAnalysisProtocolPerformed, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
