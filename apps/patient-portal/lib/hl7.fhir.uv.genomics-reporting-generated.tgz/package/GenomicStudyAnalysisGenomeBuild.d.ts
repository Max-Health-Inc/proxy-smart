import { Extension } from "fhir/r4";
export interface GenomicStudyAnalysisGenomeBuild extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-analysis-genome-build";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateGenomicStudyAnalysisGenomeBuild(resource: GenomicStudyAnalysisGenomeBuild, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
