import { GenomicStudyAnalysisExt } from "./GenomicStudyAnalysisExt";
import { GenomicStudyReferrerExt } from "./GenomicStudyReferrerExt";
import { Extension, Procedure } from "fhir/r4";
export interface GenomicStudy extends Omit<Procedure, 'extension'> {
    extension?: (Extension | GenomicStudyAnalysisExt | GenomicStudyReferrerExt)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateGenomicStudy(resource: GenomicStudy, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
