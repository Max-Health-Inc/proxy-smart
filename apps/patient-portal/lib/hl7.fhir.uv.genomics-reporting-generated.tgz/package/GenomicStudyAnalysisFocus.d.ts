import { Extension } from "fhir/r4";
export interface GenomicStudyAnalysisFocus extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-analysis-focus";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateGenomicStudyAnalysisFocus(resource: GenomicStudyAnalysisFocus, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
