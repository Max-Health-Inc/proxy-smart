import { Extension, Reference } from "fhir/r4";
export interface SupportingInfo extends Omit<Extension, 'url' | 'value'> {
    url: "http://hl7.org/fhir/StructureDefinition/workflow-supportingInfo";
    value: Reference;
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateSupportingInfo(resource: SupportingInfo, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
