import { BodyStructureReference } from "./BodyStructureReference";
import { CodeableConcept, Coding, Extension, Observation } from "fhir/r4";
import { SecondaryFinding } from "./SecondaryFinding";
export interface HaplotypeCodeCoding extends Omit<Coding, 'system' | 'code'> {
    system: "http://loinc.org";
    code: "84414-2";
}
export interface Haplotype extends Omit<Observation, 'code' | 'value' | 'extension'> {
    code: {
        coding: HaplotypeCodeCoding[];
    };
    value: CodeableConcept;
    extension?: (Extension | SecondaryFinding | BodyStructureReference)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateHaplotype(resource: Haplotype, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
