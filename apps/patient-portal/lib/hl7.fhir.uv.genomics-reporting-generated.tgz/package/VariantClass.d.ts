import { Variant } from "./Variant.js";
import type { ValidatorOptions } from "./ValidatorOptions.js";
export declare class VariantClass {
    private resource;
    /** Pattern constraints for profile fields (used by random() generator) */
    protected static readonly _fieldPatterns: {
        category: {
            coding: {
                system: string;
                code: string;
            }[];
        };
        code: {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "component.code": string;
        "conclusion-string.code": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "gene-studied.code": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "cytogenetic-location.code": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "reference-sequence-assembly.code": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "chromosome-identifier.code": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "representative-coding-hgvs.code": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "genomic-hgvs.code": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "cytogenomic-nomenclature.code": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "genomic-ref-seq.code": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "representative-protein-ref-seq.code": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "representative-transcript-ref-seq.code": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "exact-start-end.code": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "inner-start-end.code": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "outer-start-end.code": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "coordinate-system.code": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "ref-allele.code": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "alt-allele.code": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "coding-change-type.code": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "genomic-source-class.code": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "sample-allelic-frequency.code": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "sample-allelic-frequency.comparator": string;
        "sample-allelic-frequency.system": string;
        "allelic-read-depth.code": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "allelic-state.code": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "variant-inheritance.code": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "variant-inheritance-basis.code": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "variation-code.code": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "representative-protein-hgvs.code": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "copy-number.code": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "variant-confidence-status.code": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "repeat-motif.code": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "repeat-number.code": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        _refReq_category: {
            coding: boolean;
        };
        _refReq_component: {
            code: boolean;
            valueCodeableConcept: boolean;
            valueString: boolean;
            valueQuantity: boolean;
        };
        "_choiceType_effective[x]": string[];
        "_choiceType_value[x]": string[];
    };
    /** Fields that are forbidden (max=0) in this profile - must not be generated */
    protected static readonly _forbiddenFields: string[];
    /** FHIR element ordering for this profile's base resource (used by enrichResource for correct JSON field order) */
    protected static readonly _fieldOrder: string[];
    /** ValueSet bindings for coded fields - maps field name to ValueSet URL */
    static readonly valueSetBindings: Record<string, string>;
    /** Code resolver for ValueSet bindings - returns a random valid code from a ValueSet by URL */
    protected static readonly _codeResolver: ((url: string) => {
        code: string;
        system: string;
        display?: string;
    } | undefined) | undefined;
    constructor(resource: Variant);
    /** Validate current resource instance. */
    validate(options?: ValidatorOptions): Promise<{
        errors: string[];
        warnings: string[];
    }>;
    getResource(): Variant;
    setResource(resource: Variant): void;
    /**
     * Returns a plain JSON clone of the underlying resource ONLY if the last validation succeeded with zero errors.
     * Call validate() first; otherwise this method throws to prevent accidental use of invalid / unchecked data.
     */
    toJSON(): Promise<Variant>;
    /**
     * Create an empty instance for parity testing: for true FHIR resources, includes only resourceType; for datatypes, returns an empty object.
     * Note: meta.profile (when applicable) will be ensured by the constructor when wrapping this resource.
     */
    static empty(overrides?: Partial<Variant>): Variant;
    /**
     * Create a minimal randomized instance of Variant.
     * Populates id, resourceType (if applicable) and primitive required (min>0) top-level fields with placeholders.
     */
    static random(overrides?: Partial<Variant>, opts?: {
        seed?: number;
    }): Variant;
    /** Convenience: returns a class instance wrapping a randomized resource. */
    static randomClass(overrides?: Partial<Variant>, opts?: {
        seed?: number;
    }): VariantClass;
}
