import { Extension } from "fhir/r4";
export interface RecommendedAction extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/recommended-action";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateRecommendedAction(resource: RecommendedAction, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
