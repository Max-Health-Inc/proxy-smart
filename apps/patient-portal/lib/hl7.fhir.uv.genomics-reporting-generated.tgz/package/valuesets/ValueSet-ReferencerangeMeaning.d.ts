/**
 * ValueSet: referencerange-meaning
 * URL: http://hl7.org/fhir/ValueSet/referencerange-meaning
 * Size: 13 concepts
 */
export declare const ReferencerangeMeaningConcepts: readonly [{
    readonly code: "type";
    readonly system: "http://terminology.hl7.org/CodeSystem/referencerange-meaning";
}, {
    readonly code: "normal";
    readonly system: "http://terminology.hl7.org/CodeSystem/referencerange-meaning";
}, {
    readonly code: "recommended";
    readonly system: "http://terminology.hl7.org/CodeSystem/referencerange-meaning";
}, {
    readonly code: "treatment";
    readonly system: "http://terminology.hl7.org/CodeSystem/referencerange-meaning";
}, {
    readonly code: "therapeutic";
    readonly system: "http://terminology.hl7.org/CodeSystem/referencerange-meaning";
}, {
    readonly code: "pre";
    readonly system: "http://terminology.hl7.org/CodeSystem/referencerange-meaning";
}, {
    readonly code: "post";
    readonly system: "http://terminology.hl7.org/CodeSystem/referencerange-meaning";
}, {
    readonly code: "endocrine";
    readonly system: "http://terminology.hl7.org/CodeSystem/referencerange-meaning";
}, {
    readonly code: "pre-puberty";
    readonly system: "http://terminology.hl7.org/CodeSystem/referencerange-meaning";
}, {
    readonly code: "follicular";
    readonly system: "http://terminology.hl7.org/CodeSystem/referencerange-meaning";
}, {
    readonly code: "midcycle";
    readonly system: "http://terminology.hl7.org/CodeSystem/referencerange-meaning";
}, {
    readonly code: "luteal";
    readonly system: "http://terminology.hl7.org/CodeSystem/referencerange-meaning";
}, {
    readonly code: "postmenopausal";
    readonly system: "http://terminology.hl7.org/CodeSystem/referencerange-meaning";
}];
/** Union type of all valid codes in this ValueSet */
export type ReferencerangeMeaningCode = "type" | "normal" | "recommended" | "treatment" | "therapeutic" | "pre" | "post" | "endocrine" | "pre-puberty" | "follicular" | "midcycle" | "luteal" | "postmenopausal";
/** Type representing a concept from this ValueSet */
export type ReferencerangeMeaningConcept = typeof ReferencerangeMeaningConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidReferencerangeMeaningCode(code: string): code is ReferencerangeMeaningCode;
/**
 * Get concept details by code
 */
export declare function getReferencerangeMeaningConcept(code: string): ReferencerangeMeaningConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ReferencerangeMeaningCodes: ("type" | "normal" | "pre" | "recommended" | "treatment" | "therapeutic" | "post" | "endocrine" | "pre-puberty" | "follicular" | "midcycle" | "luteal" | "postmenopausal")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomReferencerangeMeaningCode(): ReferencerangeMeaningCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomReferencerangeMeaningConcept(): ReferencerangeMeaningConcept;
