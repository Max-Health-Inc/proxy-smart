/**
 * ValueSet: MolecularBiomarkerCategoryVS
 * URL: http://hl7.org/fhir/uv/genomics-reporting/ValueSet/molecular-biomarker-category-vs
 * Size: 17 concepts
 */
export const MolecularBiomarkerCategoryVSConcepts = [
    { code: "_physiologyBiomarkerCategory", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs" },
    { code: "antibody", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs" },
    { code: "antgen", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs" },
    { code: "cellReceptor", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs" },
    { code: "cellReceptorLigand", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs" },
    { code: "_moleculeTypeBiomarkerCategory", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs" },
    { code: "carbohydrate", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs" },
    { code: "lipid", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs" },
    { code: "nucleicAcid", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs" },
    { code: "protein", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs" },
    { code: "_methodBiomarkerCategory", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs" },
    { code: "enzymeAssay", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs" },
    { code: "flowCytometry", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs" },
    { code: "immuneStain", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs" },
    { code: "immunoassay", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs" },
    { code: "methylationAnalysis", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs" },
    { code: "molgen", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidMolecularBiomarkerCategoryVSCode(code) {
    return MolecularBiomarkerCategoryVSConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getMolecularBiomarkerCategoryVSConcept(code) {
    return MolecularBiomarkerCategoryVSConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const MolecularBiomarkerCategoryVSCodes = MolecularBiomarkerCategoryVSConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomMolecularBiomarkerCategoryVSCode() {
    return MolecularBiomarkerCategoryVSCodes[Math.floor(Math.random() * MolecularBiomarkerCategoryVSCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomMolecularBiomarkerCategoryVSConcept() {
    return MolecularBiomarkerCategoryVSConcepts[Math.floor(Math.random() * MolecularBiomarkerCategoryVSConcepts.length)];
}
