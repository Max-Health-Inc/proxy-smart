/**
 * ValueSet: EvidenceLevelExampleVS
 * URL: http://hl7.org/fhir/uv/genomics-reporting/ValueSet/evidence-level-example-vs
 * Size: 11 concepts
 */
export declare const EvidenceLevelExampleVSConcepts: readonly [{
    readonly code: "4-star";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/clinvar-evidence-level-custom-cs";
}, {
    readonly code: "3-star";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/clinvar-evidence-level-custom-cs";
}, {
    readonly code: "2-star";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/clinvar-evidence-level-custom-cs";
}, {
    readonly code: "1-star";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/clinvar-evidence-level-custom-cs";
}, {
    readonly code: "no-star";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/clinvar-evidence-level-custom-cs";
}, {
    readonly code: "1A";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/pharmgkb-evidence-level-custom-cs";
}, {
    readonly code: "1B";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/pharmgkb-evidence-level-custom-cs";
}, {
    readonly code: "2A";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/pharmgkb-evidence-level-custom-cs";
}, {
    readonly code: "2B";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/pharmgkb-evidence-level-custom-cs";
}, {
    readonly code: "3";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/pharmgkb-evidence-level-custom-cs";
}, {
    readonly code: "4";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/pharmgkb-evidence-level-custom-cs";
}];
/** Union type of all valid codes in this ValueSet */
export type EvidenceLevelExampleVSCode = "4-star" | "3-star" | "2-star" | "1-star" | "no-star" | "1A" | "1B" | "2A" | "2B" | "3" | "4";
/** Type representing a concept from this ValueSet */
export type EvidenceLevelExampleVSConcept = typeof EvidenceLevelExampleVSConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidEvidenceLevelExampleVSCode(code: string): code is EvidenceLevelExampleVSCode;
/**
 * Get concept details by code
 */
export declare function getEvidenceLevelExampleVSConcept(code: string): EvidenceLevelExampleVSConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const EvidenceLevelExampleVSCodes: ("3" | "4" | "4-star" | "3-star" | "2-star" | "1-star" | "no-star" | "1A" | "1B" | "2A" | "2B")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomEvidenceLevelExampleVSCode(): EvidenceLevelExampleVSCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomEvidenceLevelExampleVSConcept(): EvidenceLevelExampleVSConcept;
