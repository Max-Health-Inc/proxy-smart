/**
 * ValueSet: LL4050-2
 * URL: http://loinc.org/vs/LL4050-2
 * Size: 4 concepts
 */
export const LL40502Concepts = [
    { code: "LA26426-9", system: "http://loinc.org", display: "Directly measured" },
    { code: "LA26427-7", system: "http://loinc.org", display: "Family DNA" },
    { code: "LA26428-5", system: "http://loinc.org", display: "Family history" },
    { code: "LA26429-3", system: "http://loinc.org", display: "Inferred from population data" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidLL40502Code(code) {
    return LL40502Concepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getLL40502Concept(code) {
    return LL40502Concepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const LL40502Codes = LL40502Concepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomLL40502Code() {
    return LL40502Codes[Math.floor(Math.random() * LL40502Codes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomLL40502Concept() {
    return LL40502Concepts[Math.floor(Math.random() * LL40502Concepts.length)];
}
