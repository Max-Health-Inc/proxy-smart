/**
 * ValueSet: GeneticTherapeuticImplicationsVS
 * URL: http://hl7.org/fhir/uv/genomics-reporting/ValueSet/genetic-therapeutic-implications-vs
 * Size: 21 concepts
 */
export const GeneticTherapeuticImplicationsVSConcepts = [
    { code: "LA10315-2", system: "http://loinc.org", display: "Ultrarapid metabolizer" },
    { code: "LA25391-6", system: "http://loinc.org", display: "Normal metabolizer" },
    { code: "LA25390-8", system: "http://loinc.org", display: "Rapid metabolizer" },
    { code: "LA10317-8", system: "http://loinc.org", display: "Intermediate metabolizer" },
    { code: "LA9657-3", system: "http://loinc.org", display: "Poor metabolizer" },
    { code: "LA19542-2", system: "http://loinc.org", display: "Low Risk" },
    { code: "LA19541-4", system: "http://loinc.org", display: "High Risk" },
    { code: "LA6676-6", system: "http://loinc.org", display: "Resistant" },
    { code: "LA6677-4", system: "http://loinc.org", display: "Responsive" },
    { code: "LA9660-7", system: "http://loinc.org", display: "Presumed resistant" },
    { code: "LA9661-5", system: "http://loinc.org", display: "Presumed responsive" },
    { code: "LA6682-4", system: "http://loinc.org", display: "Unknown Significance" },
    { code: "LA6675-8", system: "http://loinc.org", display: "Benign" },
    { code: "LA6674-1", system: "http://loinc.org", display: "Presumed Benign" },
    { code: "LA9662-3", system: "http://loinc.org", display: "Presumed non-responsive" },
    { code: "LA25392-4", system: "http://loinc.org", display: "Increased function" },
    { code: "LA25393-2", system: "http://loinc.org", display: "Normal function" },
    { code: "LA25395-7", system: "http://loinc.org", display: "Decreased function" },
    { code: "LA25394-0", system: "http://loinc.org", display: "Poor function" },
    { code: "444734003", system: "http://snomed.info/sct", display: "Does not meet eligibility criteria for clinical trial (finding)" },
    { code: "399223003", system: "http://snomed.info/sct", display: "Patient eligible for clinical trial (finding)" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidGeneticTherapeuticImplicationsVSCode(code) {
    return GeneticTherapeuticImplicationsVSConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getGeneticTherapeuticImplicationsVSConcept(code) {
    return GeneticTherapeuticImplicationsVSConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const GeneticTherapeuticImplicationsVSCodes = GeneticTherapeuticImplicationsVSConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomGeneticTherapeuticImplicationsVSCode() {
    return GeneticTherapeuticImplicationsVSCodes[Math.floor(Math.random() * GeneticTherapeuticImplicationsVSCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomGeneticTherapeuticImplicationsVSConcept() {
    return GeneticTherapeuticImplicationsVSConcepts[Math.floor(Math.random() * GeneticTherapeuticImplicationsVSConcepts.length)];
}
