/**
 * ValueSet: LL378-1
 * URL: http://loinc.org/vs/LL378-1
 * Size: 8 concepts
 */
export const LL3781Concepts = [
    { code: "LA6683-2", system: "http://loinc.org", display: "Germline" },
    { code: "LA6684-0", system: "http://loinc.org", display: "Somatic" },
    { code: "LA10429-1", system: "http://loinc.org", display: "Fetal" },
    { code: "LA18194-3", system: "http://loinc.org", display: "Likely germline" },
    { code: "LA18195-0", system: "http://loinc.org", display: "Likely somatic" },
    { code: "LA18196-8", system: "http://loinc.org", display: "Likely fetal" },
    { code: "LA18197-6", system: "http://loinc.org", display: "Unknown genomic origin" },
    { code: "LA26807-0", system: "http://loinc.org", display: "De novo" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidLL3781Code(code) {
    return LL3781Concepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getLL3781Concept(code) {
    return LL3781Concepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const LL3781Codes = LL3781Concepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomLL3781Code() {
    return LL3781Codes[Math.floor(Math.random() * LL3781Codes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomLL3781Concept() {
    return LL3781Concepts[Math.floor(Math.random() * LL3781Concepts.length)];
}
