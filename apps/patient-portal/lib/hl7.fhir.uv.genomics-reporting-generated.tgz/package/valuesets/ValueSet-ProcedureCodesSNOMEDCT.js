/**
 * ValueSet: ProcedureCodes(SNOMEDCT)
 * URL: http://hl7.org/fhir/ValueSet/procedure-code
 * Size: 100 concepts
 */
export const ProcedureCodesSNOMEDCTConcepts = [
    { code: "71388002", system: "http://snomed.info/sct", display: "Procedure" },
    { code: "104001", system: "http://snomed.info/sct", display: "Excision of lesion of patella" },
    { code: "115006", system: "http://snomed.info/sct", display: "Removable appliance therapy" },
    { code: "119000", system: "http://snomed.info/sct", display: "Thoracoscopic partial lobectomy of lung" },
    { code: "128004", system: "http://snomed.info/sct", display: "Hand microscope examination of skin" },
    { code: "133000", system: "http://snomed.info/sct", display: "Percutaneous implantation of neurostimulator electrodes into neuromuscular component" },
    { code: "135007", system: "http://snomed.info/sct", display: "Arthrotomy of wrist joint with exploration and biopsy" },
    { code: "142007", system: "http://snomed.info/sct", display: "Excision of tumor from shoulder area, deep, intramuscular" },
    { code: "146005", system: "http://snomed.info/sct", display: "Repair of nonunion of metatarsal with bone graft" },
    { code: "153001", system: "http://snomed.info/sct", display: "Cystourethroscopy with resection of ureterocele" },
    { code: "166001", system: "http://snomed.info/sct", display: "Behavioral therapy" },
    { code: "170009", system: "http://snomed.info/sct", display: "Special potency disk identification, vancomycin test" },
    { code: "174000", system: "http://snomed.info/sct", display: "Harrison-Richardson operation on vagina" },
    { code: "176003", system: "http://snomed.info/sct", display: "Anastomosis of rectum" },
    { code: "189009", system: "http://snomed.info/sct", display: "Excision of lesion of artery" },
    { code: "197002", system: "http://snomed.info/sct", display: "Mold to yeast conversion test" },
    { code: "230009", system: "http://snomed.info/sct", display: "Miller operation, urethrovesical suspension" },
    { code: "243009", system: "http://snomed.info/sct", display: "Replacement of cerebral ventricular tube" },
    { code: "245002", system: "http://snomed.info/sct", display: "Division of nerve ganglion" },
    { code: "262007", system: "http://snomed.info/sct", display: "Percutaneous aspiration of renal pelvis" },
    { code: "267001", system: "http://snomed.info/sct", display: "Anal fistulectomy, multiple" },
    { code: "285008", system: "http://snomed.info/sct", display: "Incision and drainage of vulva" },
    { code: "294002", system: "http://snomed.info/sct", display: "Excisional biopsy of joint structure of spine" },
    { code: "295001", system: "http://snomed.info/sct", display: "Nonexcisional destruction of cyst of ciliary body" },
    { code: "306005", system: "http://snomed.info/sct", display: "Echography of kidney" },
    { code: "316002", system: "http://snomed.info/sct", display: "Partial dacryocystectomy" },
    { code: "334003", system: "http://snomed.info/sct", display: "Panorex examination of mandible" },
    { code: "342002", system: "http://snomed.info/sct", display: "Amobarbital interview" },
    { code: "348003", system: "http://snomed.info/sct", display: "Radionuclide dynamic function study" },
    { code: "351005", system: "http://snomed.info/sct", display: "Urinary undiversion of ureteral anastomosis" },
    { code: "352003", system: "http://snomed.info/sct", display: "Reagent RBC, preparation antibody sensitized pool" },
    { code: "374009", system: "http://snomed.info/sct", display: "Costosternoplasty for pectus excavatum repair" },
    { code: "388008", system: "http://snomed.info/sct", display: "Blepharorrhaphy" },
    { code: "389000", system: "http://snomed.info/sct", display: "Tobramycin measurement" },
    { code: "401004", system: "http://snomed.info/sct", display: "Distal subtotal pancreatectomy" },
    { code: "406009", system: "http://snomed.info/sct", display: "Fulguration of stomach lesion" },
    { code: "417005", system: "http://snomed.info/sct", display: "Hospital re-admission" },
    { code: "435001", system: "http://snomed.info/sct", display: "Pulmonary inhalation study" },
    { code: "445004", system: "http://snomed.info/sct", display: "Repair of malunion of tibia" },
    { code: "456004", system: "http://snomed.info/sct", display: "Total abdominal colectomy with ileostomy" },
    { code: "459006", system: "http://snomed.info/sct", display: "Closed condylotomy of mandible" },
    { code: "463004", system: "http://snomed.info/sct", display: "Closed reduction of coxofemoral joint dislocation with splint" },
    { code: "468008", system: "http://snomed.info/sct", display: "Glutathione measurement" },
    { code: "474008", system: "http://snomed.info/sct", display: "Esophagoenteric anastomosis, intrathoracic" },
    { code: "489004", system: "http://snomed.info/sct", display: "Ferritin measurement" },
    { code: "493005", system: "http://snomed.info/sct", display: "Urobilinogen measurement, 48-hour, feces" },
    { code: "494004", system: "http://snomed.info/sct", display: "Excision of lesion of tonsil" },
    { code: "497006", system: "http://snomed.info/sct", display: "Replacement of cochlear prosthesis, multiple channels" },
    { code: "531007", system: "http://snomed.info/sct", display: "Open pulmonary valve commissurotomy with inflow occlusion" },
    { code: "533005", system: "http://snomed.info/sct", display: "Repair of vesicocolic fistula" },
    { code: "535003", system: "http://snomed.info/sct", display: "Closure of ureterovesicovaginal fistula" },
    { code: "540006", system: "http://snomed.info/sct", display: "Antibody to single and double stranded DNA measurement" },
    { code: "543008", system: "http://snomed.info/sct", display: "Choledochostomy with transduodenal sphincteroplasty" },
    { code: "545001", system: "http://snomed.info/sct", display: "Operative procedure on lower leg" },
    { code: "549007", system: "http://snomed.info/sct", display: "Incision of intracranial vein" },
    { code: "550007", system: "http://snomed.info/sct", display: "Excision of lesion of adenoids" },
    { code: "559008", system: "http://snomed.info/sct", display: "Excision of varicose vein" },
    { code: "574005", system: "http://snomed.info/sct", display: "Benzodiazepine measurement" },
    { code: "617002", system: "http://snomed.info/sct", display: "Bone graft to mandible" },
    { code: "618007", system: "http://snomed.info/sct", display: "Frontal sinusectomy" },
    { code: "625000", system: "http://snomed.info/sct", display: "Removal of supernumerary digit" },
    { code: "628003", system: "http://snomed.info/sct", display: "Steinman test" },
    { code: "629006", system: "http://snomed.info/sct", display: "Lysis of adhesions of urethra" },
    { code: "633004", system: "http://snomed.info/sct", display: "Chart review by physician" },
    { code: "637003", system: "http://snomed.info/sct", display: "Lysis of adhesions of nose" },
    { code: "642006", system: "http://snomed.info/sct", display: "Cerebral thermography" },
    { code: "647000", system: "http://snomed.info/sct", display: "Excision of cervix by electroconization" },
    { code: "657004", system: "http://snomed.info/sct", display: "Operation on bursa" },
    { code: "665001", system: "http://snomed.info/sct", display: "Partial meniscectomy of temporomandibular joint" },
    { code: "670008", system: "http://snomed.info/sct", display: "Electrosurgical epilation of eyebrow" },
    { code: "671007", system: "http://snomed.info/sct", display: "Transplantation of testis" },
    { code: "673005", system: "http://snomed.info/sct", display: "Indirect laryngoscopy" },
    { code: "674004", system: "http://snomed.info/sct", display: "Abduction test" },
    { code: "676002", system: "http://snomed.info/sct", display: "Peritoneal dialysis including cannulation" },
    { code: "680007", system: "http://snomed.info/sct", display: "Radiation physics consultation" },
    { code: "687005", system: "http://snomed.info/sct", display: "Albumin/Globulin ratio" },
    { code: "695009", system: "http://snomed.info/sct", display: "Destructive procedure of lesion on skin of trunk" },
    { code: "697001", system: "http://snomed.info/sct", display: "Hepatitis A virus antibody measurement" },
    { code: "710006", system: "http://snomed.info/sct", display: "Thromboendarterectomy with graft of mesenteric artery" },
    { code: "712003", system: "http://snomed.info/sct", display: "Closed chest suction" },
    { code: "722009", system: "http://snomed.info/sct", display: "Fine needle biopsy of thymus" },
    { code: "726007", system: "http://snomed.info/sct", display: "Pathology consultation, comprehensive, records and specimen with report" },
    { code: "730005", system: "http://snomed.info/sct", display: "Incision of subcutaneous tissue" },
    { code: "741007", system: "http://snomed.info/sct", display: "Operation on prostate" },
    { code: "746002", system: "http://snomed.info/sct", display: "Chiropractic adjustment of coccyx subluxation" },
    { code: "753006", system: "http://snomed.info/sct", display: "Manipulation of ankle and foot, NOS" },
    { code: "754000", system: "http://snomed.info/sct", display: "Total urethrectomy" },
    { code: "759005", system: "http://snomed.info/sct", display: "Intracerebral electroencephalogram" },
    { code: "762008", system: "http://snomed.info/sct", display: "Computerized axial tomography of cervical spine with contrast" },
    { code: "764009", system: "http://snomed.info/sct", display: "Arthrodesis of interphalangeal joint of great toe" },
    { code: "767002", system: "http://snomed.info/sct", display: "White blood cell count" },
    { code: "789003", system: "http://snomed.info/sct", display: "Cranial decompression, subtemporal, supratentorial" },
    { code: "791006", system: "http://snomed.info/sct", display: "Dressing and fixation procedure" },
    { code: "807005", system: "http://snomed.info/sct", display: "Excision of brain" },
    { code: "814007", system: "http://snomed.info/sct", display: "Electrophoresis measurement" },
    { code: "817000", system: "http://snomed.info/sct", display: "Excision of cyst of spleen" },
    { code: "831000", system: "http://snomed.info/sct", display: "Drawer test" },
    { code: "853003", system: "http://snomed.info/sct", display: "Fecal fat measurement, 72-hour collection" },
    { code: "867007", system: "http://snomed.info/sct", display: "Facial-hypoglossal nerve anastomosis" },
    { code: "870006", system: "http://snomed.info/sct", display: "Carbamazepine measurement" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidProcedureCodesSNOMEDCTCode(code) {
    return ProcedureCodesSNOMEDCTConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getProcedureCodesSNOMEDCTConcept(code) {
    return ProcedureCodesSNOMEDCTConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ProcedureCodesSNOMEDCTCodes = ProcedureCodesSNOMEDCTConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomProcedureCodesSNOMEDCTCode() {
    return ProcedureCodesSNOMEDCTCodes[Math.floor(Math.random() * ProcedureCodesSNOMEDCTCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomProcedureCodesSNOMEDCTConcept() {
    return ProcedureCodesSNOMEDCTConcepts[Math.floor(Math.random() * ProcedureCodesSNOMEDCTConcepts.length)];
}
