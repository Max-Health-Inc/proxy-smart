/**
 * ValueSet: c80-facilitycodes
 * URL: http://hl7.org/fhir/ValueSet/c80-facilitycodes
 * Size: 79 concepts
 */
export declare const C80FacilitycodesConcepts: readonly [{
    readonly code: "82242000";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "225732001";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "79993009";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "32074000";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "4322002";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "224687002";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "62480006";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "80522000";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "36125001";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "48311003";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "284546000";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "42665001";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "45618002";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "418518002";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "73770003";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "69362002";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "52668009";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "360957003";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "10206005";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "37550003";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "73644007";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "31628002";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "58482006";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "90484001";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "1814000";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "22549003";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "56293002";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "360966004";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "2849009";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "14866005";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "38238005";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "56189001";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "89972002";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "78088001";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "78001009";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "23392004";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "36293008";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "3729002";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "5584006";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "37546005";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "57159002";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "331006";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "50569004";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "79491001";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "33022008";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "19602009";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "39350007";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "83891005";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "394759007";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "405607001";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "309900005";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "275576008";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "10531005";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "91154008";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "41844007";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "45899008";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "51563005";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "1773006";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "72311000";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "6827000";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "309898008";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "39913001";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "77931003";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "25681007";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "20078004";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "46224007";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "81234003";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "35971002";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "11424001";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "409519008";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "901005";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "2081004";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "59374000";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "413456002";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "413817003";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "310205006";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "419955002";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "272501009";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "394777002";
    readonly system: "http://snomed.info/sct";
}];
/** String type (ValueSet too large for union type) */
export type C80FacilitycodesCode = string;
/** Type representing a concept from this ValueSet */
export type C80FacilitycodesConcept = typeof C80FacilitycodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidC80FacilitycodesCode(code: string): code is C80FacilitycodesCode;
/**
 * Get concept details by code
 */
export declare function getC80FacilitycodesConcept(code: string): C80FacilitycodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const C80FacilitycodesCodes: ("331006" | "82242000" | "225732001" | "79993009" | "32074000" | "4322002" | "224687002" | "62480006" | "80522000" | "36125001" | "48311003" | "284546000" | "42665001" | "45618002" | "418518002" | "73770003" | "69362002" | "52668009" | "360957003" | "10206005" | "37550003" | "73644007" | "31628002" | "58482006" | "90484001" | "1814000" | "22549003" | "56293002" | "360966004" | "2849009" | "14866005" | "38238005" | "56189001" | "89972002" | "78088001" | "78001009" | "23392004" | "36293008" | "3729002" | "5584006" | "37546005" | "57159002" | "50569004" | "79491001" | "33022008" | "19602009" | "39350007" | "83891005" | "394759007" | "405607001" | "309900005" | "275576008" | "10531005" | "91154008" | "41844007" | "45899008" | "51563005" | "1773006" | "72311000" | "6827000" | "309898008" | "39913001" | "77931003" | "25681007" | "20078004" | "46224007" | "81234003" | "35971002" | "11424001" | "409519008" | "901005" | "2081004" | "59374000" | "413456002" | "413817003" | "310205006" | "419955002" | "272501009" | "394777002")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomC80FacilitycodesCode(): C80FacilitycodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomC80FacilitycodesConcept(): C80FacilitycodesConcept;
