/**
 * ValueSet: c80-facilitycodes
 * URL: http://hl7.org/fhir/ValueSet/c80-facilitycodes
 * Size: 79 concepts
 */
export declare const C80FacilitycodesConcepts: readonly [{
    readonly code: "82242000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Children's hospital";
}, {
    readonly code: "225732001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Community hospital";
}, {
    readonly code: "79993009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Government hospital";
}, {
    readonly code: "32074000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Long term care hospital";
}, {
    readonly code: "4322002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Military field hospital";
}, {
    readonly code: "224687002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Prison hospital";
}, {
    readonly code: "62480006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Psychiatric hospital";
}, {
    readonly code: "80522000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Rehabilitation hospital";
}, {
    readonly code: "36125001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Trauma center";
}, {
    readonly code: "48311003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Veteran's administration hospital";
}, {
    readonly code: "284546000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hospice";
}, {
    readonly code: "42665001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Nursing home";
}, {
    readonly code: "45618002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Skilled nursing facility";
}, {
    readonly code: "418518002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Dialysis unit (environment)";
}, {
    readonly code: "73770003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hospital-based outpatient emergency care center";
}, {
    readonly code: "69362002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hospital-based ambulatory surgery facility";
}, {
    readonly code: "52668009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hospital-based birthing center";
}, {
    readonly code: "360957003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hospital-based outpatient allergy clinic";
}, {
    readonly code: "10206005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hospital-based outpatient dental clinic";
}, {
    readonly code: "37550003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hospital-based outpatient dermatology clinic";
}, {
    readonly code: "73644007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hospital-based outpatient endocrinology clinic";
}, {
    readonly code: "31628002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hospital-based outpatient family medicine clinic";
}, {
    readonly code: "58482006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hospital-based outpatient gastroenterology clinic";
}, {
    readonly code: "90484001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hospital-based outpatient general surgery clinic";
}, {
    readonly code: "1814000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hospital-based outpatient geriatric clinic";
}, {
    readonly code: "22549003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hospital-based outpatient gynecology clinic";
}, {
    readonly code: "56293002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hospital-based outpatient hematology clinic";
}, {
    readonly code: "360966004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hospital-based outpatient immunology clinic";
}, {
    readonly code: "2849009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hospital-based outpatient infectious disease clinic";
}, {
    readonly code: "14866005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hospital-based outpatient mental health clinic";
}, {
    readonly code: "38238005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hospital-based outpatient neurology clinic";
}, {
    readonly code: "56189001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hospital-based outpatient obstetrical clinic";
}, {
    readonly code: "89972002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hospital-based outpatient oncology clinic";
}, {
    readonly code: "78088001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hospital-based outpatient ophthalmology clinic";
}, {
    readonly code: "78001009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hospital-based outpatient orthopedics clinic";
}, {
    readonly code: "23392004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hospital-based outpatient otorhinolaryngology clinic";
}, {
    readonly code: "36293008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hospital-based outpatient pain clinic";
}, {
    readonly code: "3729002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hospital-based outpatient pediatric clinic";
}, {
    readonly code: "5584006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hospital-based outpatient peripheral vascular clinic";
}, {
    readonly code: "37546005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hospital-based outpatient rehabilitation clinic";
}, {
    readonly code: "57159002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hospital-based outpatient respiratory disease clinic";
}, {
    readonly code: "331006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hospital-based outpatient rheumatology clinic";
}, {
    readonly code: "50569004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hospital-based outpatient urology clinic";
}, {
    readonly code: "79491001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hospital-based radiology facility";
}, {
    readonly code: "33022008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hospital-based outpatient department";
}, {
    readonly code: "19602009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Fee-for-service private physicians' group office";
}, {
    readonly code: "39350007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Private physicians' group office";
}, {
    readonly code: "83891005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Solo practice private office";
}, {
    readonly code: "394759007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Independent provider site (environment)";
}, {
    readonly code: "405607001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Ambulatory surgery center (environment)";
}, {
    readonly code: "309900005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Care of the elderly day hospital";
}, {
    readonly code: "275576008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Elderly assessment clinic";
}, {
    readonly code: "10531005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Free-standing ambulatory surgery facility";
}, {
    readonly code: "91154008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Free-standing birthing center";
}, {
    readonly code: "41844007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Free-standing geriatric clinic";
}, {
    readonly code: "45899008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Free-standing laboratory facility";
}, {
    readonly code: "51563005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Free-standing mental health clinic";
}, {
    readonly code: "1773006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Free-standing radiology facility";
}, {
    readonly code: "72311000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Health maintenance organization";
}, {
    readonly code: "6827000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Local community health center";
}, {
    readonly code: "309898008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Psychogeriatric day hospital";
}, {
    readonly code: "39913001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Residential school infirmary";
}, {
    readonly code: "77931003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Rural health center";
}, {
    readonly code: "25681007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Sexually transmitted disease clinic";
}, {
    readonly code: "20078004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Substance abuse treatment center";
}, {
    readonly code: "46224007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Vaccination clinic";
}, {
    readonly code: "81234003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Walk-in clinic";
}, {
    readonly code: "35971002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Ambulatory care site";
}, {
    readonly code: "11424001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Ambulance-based care";
}, {
    readonly code: "409519008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Contained casualty setting (environment)";
}, {
    readonly code: "901005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Helicopter-based care";
}, {
    readonly code: "2081004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hospital ship";
}, {
    readonly code: "59374000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Traveler's aid clinic";
}, {
    readonly code: "413456002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Adult day care center (environment)";
}, {
    readonly code: "413817003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Child day care center (environment)";
}, {
    readonly code: "310205006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Private residential home";
}, {
    readonly code: "419955002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Residential institution (environment)";
}, {
    readonly code: "272501009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Sports facility";
}, {
    readonly code: "394777002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Health encounter sites (environment)";
}];
/** String type (ValueSet too large for union type) */
export type C80FacilitycodesCode = string;
/** Type representing a concept from this ValueSet */
export type C80FacilitycodesConcept = typeof C80FacilitycodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidC80FacilitycodesCode(code: string): code is C80FacilitycodesCode;
/**
 * Get concept details by code
 */
export declare function getC80FacilitycodesConcept(code: string): C80FacilitycodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const C80FacilitycodesCodes: ("331006" | "82242000" | "225732001" | "79993009" | "32074000" | "4322002" | "224687002" | "62480006" | "80522000" | "36125001" | "48311003" | "284546000" | "42665001" | "45618002" | "418518002" | "73770003" | "69362002" | "52668009" | "360957003" | "10206005" | "37550003" | "73644007" | "31628002" | "58482006" | "90484001" | "1814000" | "22549003" | "56293002" | "360966004" | "2849009" | "14866005" | "38238005" | "56189001" | "89972002" | "78088001" | "78001009" | "23392004" | "36293008" | "3729002" | "5584006" | "37546005" | "57159002" | "50569004" | "79491001" | "33022008" | "19602009" | "39350007" | "83891005" | "394759007" | "405607001" | "309900005" | "275576008" | "10531005" | "91154008" | "41844007" | "45899008" | "51563005" | "1773006" | "72311000" | "6827000" | "309898008" | "39913001" | "77931003" | "25681007" | "20078004" | "46224007" | "81234003" | "35971002" | "11424001" | "409519008" | "901005" | "2081004" | "59374000" | "413456002" | "413817003" | "310205006" | "419955002" | "272501009" | "394777002")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomC80FacilitycodesCode(): C80FacilitycodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomC80FacilitycodesConcept(): C80FacilitycodesConcept;
