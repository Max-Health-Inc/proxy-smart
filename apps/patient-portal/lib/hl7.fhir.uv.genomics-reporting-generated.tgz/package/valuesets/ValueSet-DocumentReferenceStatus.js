/**
 * ValueSet: document-reference-status
 * URL: http://hl7.org/fhir/ValueSet/document-reference-status
 * Size: 3 concepts
 */
export const DocumentReferenceStatusConcepts = [
    { code: "current", system: "http://hl7.org/fhir/document-reference-status" },
    { code: "superseded", system: "http://hl7.org/fhir/document-reference-status" },
    { code: "entered-in-error", system: "http://hl7.org/fhir/document-reference-status" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidDocumentReferenceStatusCode(code) {
    return DocumentReferenceStatusConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getDocumentReferenceStatusConcept(code) {
    return DocumentReferenceStatusConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const DocumentReferenceStatusCodes = DocumentReferenceStatusConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomDocumentReferenceStatusCode() {
    return DocumentReferenceStatusCodes[Math.floor(Math.random() * DocumentReferenceStatusCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomDocumentReferenceStatusConcept() {
    return DocumentReferenceStatusConcepts[Math.floor(Math.random() * DocumentReferenceStatusConcepts.length)];
}
