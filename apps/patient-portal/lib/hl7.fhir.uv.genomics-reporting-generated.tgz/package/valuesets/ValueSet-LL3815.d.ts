/**
 * ValueSet: LL381-5
 * URL: http://loinc.org/vs/LL381-5
 * Size: 5 concepts
 */
export declare const LL3815Concepts: readonly [{
    readonly code: "LA6703-8";
    readonly system: "http://loinc.org";
    readonly display: "Heteroplasmic";
}, {
    readonly code: "LA6704-6";
    readonly system: "http://loinc.org";
    readonly display: "Homoplasmic";
}, {
    readonly code: "LA6705-3";
    readonly system: "http://loinc.org";
    readonly display: "Homozygous";
}, {
    readonly code: "LA6706-1";
    readonly system: "http://loinc.org";
    readonly display: "Heterozygous";
}, {
    readonly code: "LA6707-9";
    readonly system: "http://loinc.org";
    readonly display: "Hemizygous";
}];
/** Union type of all valid codes in this ValueSet */
export type LL3815Code = "LA6703-8" | "LA6704-6" | "LA6705-3" | "LA6706-1" | "LA6707-9";
/** Type representing a concept from this ValueSet */
export type LL3815Concept = typeof LL3815Concepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidLL3815Code(code: string): code is LL3815Code;
/**
 * Get concept details by code
 */
export declare function getLL3815Concept(code: string): LL3815Concept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const LL3815Codes: ("LA6703-8" | "LA6704-6" | "LA6705-3" | "LA6706-1" | "LA6707-9")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomLL3815Code(): LL3815Code;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomLL3815Concept(): LL3815Concept;
