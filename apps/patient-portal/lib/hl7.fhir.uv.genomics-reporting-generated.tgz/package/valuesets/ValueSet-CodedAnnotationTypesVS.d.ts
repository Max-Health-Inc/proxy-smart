/**
 * ValueSet: CodedAnnotationTypesVS
 * URL: http://hl7.org/fhir/uv/genomics-reporting/ValueSet/coded-annotation-types-vs
 * Size: 3 concepts
 */
export declare const CodedAnnotationTypesVSConcepts: readonly [{
    readonly code: "test-disclaimer";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/coded-annotation-types-cs";
}, {
    readonly code: "test-methodology";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/coded-annotation-types-cs";
}, {
    readonly code: "result-confirmation";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/coded-annotation-types-cs";
}];
/** Union type of all valid codes in this ValueSet */
export type CodedAnnotationTypesVSCode = "test-disclaimer" | "test-methodology" | "result-confirmation";
/** Type representing a concept from this ValueSet */
export type CodedAnnotationTypesVSConcept = typeof CodedAnnotationTypesVSConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidCodedAnnotationTypesVSCode(code: string): code is CodedAnnotationTypesVSCode;
/**
 * Get concept details by code
 */
export declare function getCodedAnnotationTypesVSConcept(code: string): CodedAnnotationTypesVSConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const CodedAnnotationTypesVSCodes: ("test-disclaimer" | "test-methodology" | "result-confirmation")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomCodedAnnotationTypesVSCode(): CodedAnnotationTypesVSCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomCodedAnnotationTypesVSConcept(): CodedAnnotationTypesVSConcept;
