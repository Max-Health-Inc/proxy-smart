/**
 * ValueSet: diagnostic-report-status
 * URL: http://hl7.org/fhir/ValueSet/diagnostic-report-status
 * Size: 7 concepts
 */
export declare const DiagnosticReportStatusConcepts: readonly [{
    readonly code: "registered";
    readonly system: "http://hl7.org/fhir/diagnostic-report-status";
    readonly display: "Registered";
}, {
    readonly code: "partial";
    readonly system: "http://hl7.org/fhir/diagnostic-report-status";
    readonly display: "Partial";
}, {
    readonly code: "final";
    readonly system: "http://hl7.org/fhir/diagnostic-report-status";
    readonly display: "Final";
}, {
    readonly code: "amended";
    readonly system: "http://hl7.org/fhir/diagnostic-report-status";
    readonly display: "Amended";
}, {
    readonly code: "cancelled";
    readonly system: "http://hl7.org/fhir/diagnostic-report-status";
    readonly display: "Cancelled";
}, {
    readonly code: "entered-in-error";
    readonly system: "http://hl7.org/fhir/diagnostic-report-status";
    readonly display: "Entered in Error";
}, {
    readonly code: "unknown";
    readonly system: "http://hl7.org/fhir/diagnostic-report-status";
    readonly display: "Unknown";
}];
/** Union type of all valid codes in this ValueSet */
export type DiagnosticReportStatusCode = "registered" | "partial" | "final" | "amended" | "cancelled" | "entered-in-error" | "unknown";
/** Type representing a concept from this ValueSet */
export type DiagnosticReportStatusConcept = typeof DiagnosticReportStatusConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidDiagnosticReportStatusCode(code: string): code is DiagnosticReportStatusCode;
/**
 * Get concept details by code
 */
export declare function getDiagnosticReportStatusConcept(code: string): DiagnosticReportStatusConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const DiagnosticReportStatusCodes: ("unknown" | "entered-in-error" | "final" | "registered" | "amended" | "cancelled" | "partial")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomDiagnosticReportStatusCode(): DiagnosticReportStatusCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomDiagnosticReportStatusConcept(): DiagnosticReportStatusConcept;
