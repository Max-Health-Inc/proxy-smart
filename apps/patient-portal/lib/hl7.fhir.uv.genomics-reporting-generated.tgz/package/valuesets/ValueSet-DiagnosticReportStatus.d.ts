/**
 * ValueSet: diagnostic-report-status
 * URL: http://hl7.org/fhir/ValueSet/diagnostic-report-status
 * Size: 10 concepts
 */
export declare const DiagnosticReportStatusConcepts: readonly [{
    readonly code: "registered";
    readonly system: "http://hl7.org/fhir/diagnostic-report-status";
}, {
    readonly code: "partial";
    readonly system: "http://hl7.org/fhir/diagnostic-report-status";
}, {
    readonly code: "preliminary";
    readonly system: "http://hl7.org/fhir/diagnostic-report-status";
}, {
    readonly code: "final";
    readonly system: "http://hl7.org/fhir/diagnostic-report-status";
}, {
    readonly code: "amended";
    readonly system: "http://hl7.org/fhir/diagnostic-report-status";
}, {
    readonly code: "corrected";
    readonly system: "http://hl7.org/fhir/diagnostic-report-status";
}, {
    readonly code: "appended";
    readonly system: "http://hl7.org/fhir/diagnostic-report-status";
}, {
    readonly code: "cancelled";
    readonly system: "http://hl7.org/fhir/diagnostic-report-status";
}, {
    readonly code: "entered-in-error";
    readonly system: "http://hl7.org/fhir/diagnostic-report-status";
}, {
    readonly code: "unknown";
    readonly system: "http://hl7.org/fhir/diagnostic-report-status";
}];
/** Union type of all valid codes in this ValueSet */
export type DiagnosticReportStatusCode = "registered" | "partial" | "preliminary" | "final" | "amended" | "corrected" | "appended" | "cancelled" | "entered-in-error" | "unknown";
/** Type representing a concept from this ValueSet */
export type DiagnosticReportStatusConcept = typeof DiagnosticReportStatusConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidDiagnosticReportStatusCode(code: string): code is DiagnosticReportStatusCode;
/**
 * Get concept details by code
 */
export declare function getDiagnosticReportStatusConcept(code: string): DiagnosticReportStatusConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const DiagnosticReportStatusCodes: ("unknown" | "entered-in-error" | "final" | "registered" | "preliminary" | "amended" | "corrected" | "cancelled" | "partial" | "appended")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomDiagnosticReportStatusCode(): DiagnosticReportStatusCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomDiagnosticReportStatusConcept(): DiagnosticReportStatusConcept;
