/**
 * ValueSet: c80-doc-typecodes
 * URL: http://hl7.org/fhir/ValueSet/c80-doc-typecodes
 * Size: 6401 concepts
 */
interface C80DocTypecodesConceptDef {
    readonly code: string;
    readonly system: string;
    readonly display?: string;
}
export declare const C80DocTypecodesConcepts: readonly C80DocTypecodesConceptDef[];
/** String type (ValueSet too large for union type) */
export type C80DocTypecodesCode = string;
/** Type representing a concept from this ValueSet */
export type C80DocTypecodesConcept = C80DocTypecodesConceptDef;
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidC80DocTypecodesCode(code: string): code is C80DocTypecodesCode;
/**
 * Get concept details by code
 */
export declare function getC80DocTypecodesConcept(code: string): C80DocTypecodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const C80DocTypecodesCodes: string[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomC80DocTypecodesCode(): C80DocTypecodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomC80DocTypecodesConcept(): C80DocTypecodesConcept;
export {};
