/**
 * ValueSet: c80-doc-typecodes
 * URL: http://hl7.org/fhir/ValueSet/c80-doc-typecodes
 * Size: 100 concepts
 */
export declare const C80DocTypecodesConcepts: readonly [{
    readonly code: "55107-7";
    readonly system: "http://loinc.org";
    readonly display: "Addendum Document";
}, {
    readonly code: "74155-3";
    readonly system: "http://loinc.org";
    readonly display: "ADHD action plan";
}, {
    readonly code: "51851-4";
    readonly system: "http://loinc.org";
    readonly display: "Administrative note";
}, {
    readonly code: "67851-6";
    readonly system: "http://loinc.org";
    readonly display: "Admission evaluation note";
}, {
    readonly code: "34744-3";
    readonly system: "http://loinc.org";
    readonly display: "Nurse Admission evaluation note";
}, {
    readonly code: "34873-0";
    readonly system: "http://loinc.org";
    readonly display: "Surgery Admission evaluation note";
}, {
    readonly code: "68552-9";
    readonly system: "http://loinc.org";
    readonly display: "Emergency medicine Emergency department Admission evaluation note";
}, {
    readonly code: "67852-4";
    readonly system: "http://loinc.org";
    readonly display: "Hospital Admission evaluation note";
}, {
    readonly code: "68471-2";
    readonly system: "http://loinc.org";
    readonly display: "Cardiology Hospital Admission evaluation note";
}, {
    readonly code: "68483-7";
    readonly system: "http://loinc.org";
    readonly display: "Cardiology Medical student Hospital Admission evaluation note";
}, {
    readonly code: "64058-1";
    readonly system: "http://loinc.org";
    readonly display: "Critical care medicine Hospital Admission evaluation note";
}, {
    readonly code: "64070-6";
    readonly system: "http://loinc.org";
    readonly display: "Critical care medicine Medical student Hospital Admission evaluation note";
}, {
    readonly code: "64053-2";
    readonly system: "http://loinc.org";
    readonly display: "General medicine Hospital Admission evaluation note";
}, {
    readonly code: "64054-0";
    readonly system: "http://loinc.org";
    readonly display: "General medicine Medical student Hospital Admission evaluation note";
}, {
    readonly code: "34862-3";
    readonly system: "http://loinc.org";
    readonly display: "General medicine Attending Hospital Admission evaluation note";
}, {
    readonly code: "64062-3";
    readonly system: "http://loinc.org";
    readonly display: "Pulmonary Hospital Admission evaluation note";
}, {
    readonly code: "64078-9";
    readonly system: "http://loinc.org";
    readonly display: "Pulmonary Medical student Hospital Admission evaluation note";
}, {
    readonly code: "64066-4";
    readonly system: "http://loinc.org";
    readonly display: "Surgery Medical student Hospital Admission evaluation note";
}, {
    readonly code: "64060-7";
    readonly system: "http://loinc.org";
    readonly display: "Cardiothoracic surgery Hospital Admission evaluation note";
}, {
    readonly code: "64074-8";
    readonly system: "http://loinc.org";
    readonly display: "Cardiothoracic surgery Medical student Hospital Admission evaluation note";
}, {
    readonly code: "51849-8";
    readonly system: "http://loinc.org";
    readonly display: "Admission history and physical note";
}, {
    readonly code: "34763-3";
    readonly system: "http://loinc.org";
    readonly display: "General medicine Admission history and physical note";
}, {
    readonly code: "47039-3";
    readonly system: "http://loinc.org";
    readonly display: "Hospital Admission history and physical note";
}, {
    readonly code: "34094-3";
    readonly system: "http://loinc.org";
    readonly display: "Cardiology Hospital Admission history and physical note";
}, {
    readonly code: "57830-2";
    readonly system: "http://loinc.org";
    readonly display: "Admission request Document";
}, {
    readonly code: "48765-2";
    readonly system: "http://loinc.org";
    readonly display: "Allergies and adverse reactions Document";
}, {
    readonly code: "74152-0";
    readonly system: "http://loinc.org";
    readonly display: "Anaphylaxis action plan";
}, {
    readonly code: "61359-6";
    readonly system: "http://loinc.org";
    readonly display: "Anesthesia consent Document";
}, {
    readonly code: "57055-6";
    readonly system: "http://loinc.org";
    readonly display: "Antepartum summary note";
}, {
    readonly code: "56446-8";
    readonly system: "http://loinc.org";
    readonly display: "Appointment summary Document";
}, {
    readonly code: "51848-0";
    readonly system: "http://loinc.org";
    readonly display: "Evaluation note";
}, {
    readonly code: "68814-3";
    readonly system: "http://loinc.org";
    readonly display: "Pediatrics Evaluation note";
}, {
    readonly code: "64064-9";
    readonly system: "http://loinc.org";
    readonly display: "Pastoral care Hospital Evaluation note";
}, {
    readonly code: "51847-2";
    readonly system: "http://loinc.org";
    readonly display: "Evaluation + Plan note";
}, {
    readonly code: "69981-9";
    readonly system: "http://loinc.org";
    readonly display: "Asthma action plan";
}, {
    readonly code: "74154-6";
    readonly system: "http://loinc.org";
    readonly display: "Autism action plan";
}, {
    readonly code: "71230-7";
    readonly system: "http://loinc.org";
    readonly display: "Birth certificate";
}, {
    readonly code: "72134-0";
    readonly system: "http://loinc.org";
    readonly display: "Cancer event report";
}, {
    readonly code: "55108-5";
    readonly system: "http://loinc.org";
    readonly display: "Clinical presentation Document";
}, {
    readonly code: "73568-8";
    readonly system: "http://loinc.org";
    readonly display: "Communication of critical results [Description] Document";
}, {
    readonly code: "74144-7";
    readonly system: "http://loinc.org";
    readonly display: "Complex medical conditions action plan";
}, {
    readonly code: "55109-3";
    readonly system: "http://loinc.org";
    readonly display: "Complications Document";
}, {
    readonly code: "34095-0";
    readonly system: "http://loinc.org";
    readonly display: "Comprehensive history and physical note";
}, {
    readonly code: "34096-8";
    readonly system: "http://loinc.org";
    readonly display: "Nursing facility Comprehensive history and physical note";
}, {
    readonly code: "63485-7";
    readonly system: "http://loinc.org";
    readonly display: "Computer generated recommendation Document";
}, {
    readonly code: "55110-1";
    readonly system: "http://loinc.org";
    readonly display: "Conclusions [Interpretation] Document";
}, {
    readonly code: "34098-4";
    readonly system: "http://loinc.org";
    readonly display: "Conference note";
}, {
    readonly code: "34097-6";
    readonly system: "http://loinc.org";
    readonly display: "Nursing facility Conference note";
}, {
    readonly code: "47040-1";
    readonly system: "http://loinc.org";
    readonly display: "Consultation 2nd opinion";
}, {
    readonly code: "47041-9";
    readonly system: "http://loinc.org";
    readonly display: "Hospital Consultation 2nd opinion";
}, {
    readonly code: "59284-0";
    readonly system: "http://loinc.org";
    readonly display: "Consent Document";
}, {
    readonly code: "11488-4";
    readonly system: "http://loinc.org";
    readonly display: "Consult note";
}, {
    readonly code: "34099-2";
    readonly system: "http://loinc.org";
    readonly display: "Cardiology Consult note";
}, {
    readonly code: "34756-7";
    readonly system: "http://loinc.org";
    readonly display: "Dentistry Consult note";
}, {
    readonly code: "34758-3";
    readonly system: "http://loinc.org";
    readonly display: "Dermatology Consult note";
}, {
    readonly code: "34760-9";
    readonly system: "http://loinc.org";
    readonly display: "Diabetology Consult note";
}, {
    readonly code: "34879-7";
    readonly system: "http://loinc.org";
    readonly display: "Endocrinology Consult note";
}, {
    readonly code: "34761-7";
    readonly system: "http://loinc.org";
    readonly display: "Gastroenterology Consult note";
}, {
    readonly code: "34764-1";
    readonly system: "http://loinc.org";
    readonly display: "General medicine Consult note";
}, {
    readonly code: "34776-5";
    readonly system: "http://loinc.org";
    readonly display: "Geriatric medicine Consult note";
}, {
    readonly code: "34779-9";
    readonly system: "http://loinc.org";
    readonly display: "Hematology+Medical oncology Consult note";
}, {
    readonly code: "34781-5";
    readonly system: "http://loinc.org";
    readonly display: "Infectious disease Consult note";
}, {
    readonly code: "72555-6";
    readonly system: "http://loinc.org";
    readonly display: "Interventional radiology Consult note";
}, {
    readonly code: "34783-1";
    readonly system: "http://loinc.org";
    readonly display: "Kinesiotherapy Consult note";
}, {
    readonly code: "34785-6";
    readonly system: "http://loinc.org";
    readonly display: "Mental health Consult note";
}, {
    readonly code: "34795-5";
    readonly system: "http://loinc.org";
    readonly display: "Nephrology Consult note";
}, {
    readonly code: "34798-9";
    readonly system: "http://loinc.org";
    readonly display: "Neurological surgery Consult note";
}, {
    readonly code: "34797-1";
    readonly system: "http://loinc.org";
    readonly display: "Neurology Consult note";
}, {
    readonly code: "34800-3";
    readonly system: "http://loinc.org";
    readonly display: "Nutrition and dietetics Consult note";
}, {
    readonly code: "34777-3";
    readonly system: "http://loinc.org";
    readonly display: "Obstetrics and Gynecology Consult note";
}, {
    readonly code: "34803-7";
    readonly system: "http://loinc.org";
    readonly display: "Occupational medicine Consult note";
}, {
    readonly code: "34855-7";
    readonly system: "http://loinc.org";
    readonly display: "Occupational therapy Consult note";
}, {
    readonly code: "34805-2";
    readonly system: "http://loinc.org";
    readonly display: "Oncology Consult note";
}, {
    readonly code: "34807-8";
    readonly system: "http://loinc.org";
    readonly display: "Ophthalmology Consult note";
}, {
    readonly code: "34810-2";
    readonly system: "http://loinc.org";
    readonly display: "Optometry Consult note";
}, {
    readonly code: "34812-8";
    readonly system: "http://loinc.org";
    readonly display: "Oral and Maxillofacial Surgery Consult note";
}, {
    readonly code: "34814-4";
    readonly system: "http://loinc.org";
    readonly display: "Orthopaedic surgery Consult note";
}, {
    readonly code: "34816-9";
    readonly system: "http://loinc.org";
    readonly display: "Otolaryngology Consult note";
}, {
    readonly code: "34820-1";
    readonly system: "http://loinc.org";
    readonly display: "Pharmacology Consult note";
}, {
    readonly code: "34822-7";
    readonly system: "http://loinc.org";
    readonly display: "Physical medicine and rehab Consult note";
}, {
    readonly code: "34824-3";
    readonly system: "http://loinc.org";
    readonly display: "Physical therapy Consult note";
}, {
    readonly code: "34826-8";
    readonly system: "http://loinc.org";
    readonly display: "Plastic surgery Consult note";
}, {
    readonly code: "34828-4";
    readonly system: "http://loinc.org";
    readonly display: "Podiatry Consult note";
}, {
    readonly code: "34788-0";
    readonly system: "http://loinc.org";
    readonly display: "Psychiatry Consult note";
}, {
    readonly code: "34791-4";
    readonly system: "http://loinc.org";
    readonly display: "Psychology Consult note";
}, {
    readonly code: "34103-2";
    readonly system: "http://loinc.org";
    readonly display: "Pulmonary Consult note";
}, {
    readonly code: "34831-8";
    readonly system: "http://loinc.org";
    readonly display: "Radiation oncology Consult note";
}, {
    readonly code: "73575-3";
    readonly system: "http://loinc.org";
    readonly display: "Radiology Consult note";
}, {
    readonly code: "34833-4";
    readonly system: "http://loinc.org";
    readonly display: "Recreational therapy Consult note";
}, {
    readonly code: "34837-5";
    readonly system: "http://loinc.org";
    readonly display: "Respiratory therapy Consult note";
}, {
    readonly code: "34839-1";
    readonly system: "http://loinc.org";
    readonly display: "Rheumatology Consult note";
}, {
    readonly code: "34841-7";
    readonly system: "http://loinc.org";
    readonly display: "Social worker Consult note";
}, {
    readonly code: "34845-8";
    readonly system: "http://loinc.org";
    readonly display: "Speech-language pathology+Audiology Consult note";
}, {
    readonly code: "34847-4";
    readonly system: "http://loinc.org";
    readonly display: "Surgery Consult note";
}, {
    readonly code: "34849-0";
    readonly system: "http://loinc.org";
    readonly display: "Cardiothoracic surgery Consult note";
}, {
    readonly code: "34851-6";
    readonly system: "http://loinc.org";
    readonly display: "Urology Consult note";
}, {
    readonly code: "34853-2";
    readonly system: "http://loinc.org";
    readonly display: "Vascular surgery Consult note";
}, {
    readonly code: "51846-4";
    readonly system: "http://loinc.org";
    readonly display: "Emergency department Consult note";
}, {
    readonly code: "34104-0";
    readonly system: "http://loinc.org";
    readonly display: "Hospital Consult note";
}, {
    readonly code: "68619-6";
    readonly system: "http://loinc.org";
    readonly display: "Adolescent medicine Hospital Consult note";
}];
/** String type (ValueSet too large for union type) */
export type C80DocTypecodesCode = string;
/** Type representing a concept from this ValueSet */
export type C80DocTypecodesConcept = typeof C80DocTypecodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidC80DocTypecodesCode(code: string): code is C80DocTypecodesCode;
/**
 * Get concept details by code
 */
export declare function getC80DocTypecodesConcept(code: string): C80DocTypecodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const C80DocTypecodesCodes: ("48765-2" | "55107-7" | "74155-3" | "51851-4" | "67851-6" | "34744-3" | "34873-0" | "68552-9" | "67852-4" | "68471-2" | "68483-7" | "64058-1" | "64070-6" | "64053-2" | "64054-0" | "34862-3" | "64062-3" | "64078-9" | "64066-4" | "64060-7" | "64074-8" | "51849-8" | "34763-3" | "47039-3" | "34094-3" | "57830-2" | "74152-0" | "61359-6" | "57055-6" | "56446-8" | "51848-0" | "68814-3" | "64064-9" | "51847-2" | "69981-9" | "74154-6" | "71230-7" | "72134-0" | "55108-5" | "73568-8" | "74144-7" | "55109-3" | "34095-0" | "34096-8" | "63485-7" | "55110-1" | "34098-4" | "34097-6" | "47040-1" | "47041-9" | "59284-0" | "11488-4" | "34099-2" | "34756-7" | "34758-3" | "34760-9" | "34879-7" | "34761-7" | "34764-1" | "34776-5" | "34779-9" | "34781-5" | "72555-6" | "34783-1" | "34785-6" | "34795-5" | "34798-9" | "34797-1" | "34800-3" | "34777-3" | "34803-7" | "34855-7" | "34805-2" | "34807-8" | "34810-2" | "34812-8" | "34814-4" | "34816-9" | "34820-1" | "34822-7" | "34824-3" | "34826-8" | "34828-4" | "34788-0" | "34791-4" | "34103-2" | "34831-8" | "73575-3" | "34833-4" | "34837-5" | "34839-1" | "34841-7" | "34845-8" | "34847-4" | "34849-0" | "34851-6" | "34853-2" | "51846-4" | "34104-0" | "68619-6")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomC80DocTypecodesCode(): C80DocTypecodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomC80DocTypecodesConcept(): C80DocTypecodesConcept;
/**
 * Multi-language display translations
 * Maps code → language → display string
 */
export declare const C80DocTypecodesDisplays: Record<string, Record<string, string>>;
/**
 * Get the display string for a code in a specific language
 */
export declare function getC80DocTypecodesDisplay(code: string, lang: string): string | undefined;
