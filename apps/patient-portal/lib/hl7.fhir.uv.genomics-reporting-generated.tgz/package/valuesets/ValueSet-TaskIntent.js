/**
 * ValueSet: TaskIntent
 * URL: http://hl7.org/fhir/ValueSet/task-intent
 * Size: 8 concepts
 */
export const TaskIntentConcepts = [
    { code: "proposal", system: "http://hl7.org/fhir/request-intent" },
    { code: "plan", system: "http://hl7.org/fhir/request-intent" },
    { code: "order", system: "http://hl7.org/fhir/request-intent" },
    { code: "original-order", system: "http://hl7.org/fhir/request-intent" },
    { code: "reflex-order", system: "http://hl7.org/fhir/request-intent" },
    { code: "filler-order", system: "http://hl7.org/fhir/request-intent" },
    { code: "instance-order", system: "http://hl7.org/fhir/request-intent" },
    { code: "option", system: "http://hl7.org/fhir/request-intent" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidTaskIntentCode(code) {
    return TaskIntentConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getTaskIntentConcept(code) {
    return TaskIntentConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const TaskIntentCodes = TaskIntentConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomTaskIntentCode() {
    return TaskIntentCodes[Math.floor(Math.random() * TaskIntentCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomTaskIntentConcept() {
    return TaskIntentConcepts[Math.floor(Math.random() * TaskIntentConcepts.length)];
}
