/**
 * ValueSet: task-intent
 * URL: http://hl7.org/fhir/ValueSet/task-intent
 * Size: 9 concepts
 */
export const TaskIntentConcepts = [
    { code: "unknown", system: "http://hl7.org/fhir/task-intent", display: "Unknown" },
    { code: "proposal", system: "http://hl7.org/fhir/request-intent", display: "Proposal" },
    { code: "plan", system: "http://hl7.org/fhir/request-intent", display: "Plan" },
    { code: "order", system: "http://hl7.org/fhir/request-intent", display: "Order" },
    { code: "original-order", system: "http://hl7.org/fhir/request-intent", display: "Original Order" },
    { code: "reflex-order", system: "http://hl7.org/fhir/request-intent", display: "Reflex Order" },
    { code: "filler-order", system: "http://hl7.org/fhir/request-intent", display: "Filler Order" },
    { code: "instance-order", system: "http://hl7.org/fhir/request-intent", display: "Instance Order" },
    { code: "option", system: "http://hl7.org/fhir/request-intent", display: "Option" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidTaskIntentCode(code) {
    return TaskIntentConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getTaskIntentConcept(code) {
    return TaskIntentConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const TaskIntentCodes = TaskIntentConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomTaskIntentCode() {
    return TaskIntentCodes[Math.floor(Math.random() * TaskIntentCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomTaskIntentConcept() {
    return TaskIntentConcepts[Math.floor(Math.random() * TaskIntentConcepts.length)];
}
