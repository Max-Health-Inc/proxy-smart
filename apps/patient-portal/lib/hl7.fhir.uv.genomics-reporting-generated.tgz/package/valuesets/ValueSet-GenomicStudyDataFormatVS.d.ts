/**
 * ValueSet: GenomicStudyDataFormatVS
 * URL: http://hl7.org/fhir/uv/genomics-reporting/ValueSet/genomic-study-data-format-vs
 * Size: 40 concepts
 */
export declare const GenomicStudyDataFormatVSConcepts: readonly [{
    readonly code: "bam";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "bed";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "bedpe";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "bedgraph";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "bigbed";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "bigWig";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "birdsuite-files";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "broadpeak";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "cbs";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "chemical-reactivity-probing-profiles";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "chrom-sizes";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "cn";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "custom-file-formats";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "cytoband";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "fasta";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "gct";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "cram";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "genepred";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "gff-gtf";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "gistic";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "goby";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "gwas";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "igv";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "loh";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "maf-multiple-alignment-format";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "maf-mutation-annotation-format";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "merged-bam-file";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "mut";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "narrowpeak";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "psl";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "res";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "rna-secondary-structure-formats";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "sam";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "sample-info-attributes-file";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "seg";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "tdf";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "track-line";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "type-line";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "vcf";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}, {
    readonly code: "wig";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs";
}];
/** String type (ValueSet too large for union type) */
export type GenomicStudyDataFormatVSCode = string;
/** Type representing a concept from this ValueSet */
export type GenomicStudyDataFormatVSConcept = typeof GenomicStudyDataFormatVSConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidGenomicStudyDataFormatVSCode(code: string): code is GenomicStudyDataFormatVSCode;
/**
 * Get concept details by code
 */
export declare function getGenomicStudyDataFormatVSConcept(code: string): GenomicStudyDataFormatVSConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const GenomicStudyDataFormatVSCodes: ("bam" | "bed" | "bedpe" | "bedgraph" | "bigbed" | "bigWig" | "birdsuite-files" | "broadpeak" | "cbs" | "chemical-reactivity-probing-profiles" | "chrom-sizes" | "cn" | "custom-file-formats" | "cytoband" | "fasta" | "gct" | "cram" | "genepred" | "gff-gtf" | "gistic" | "goby" | "gwas" | "igv" | "loh" | "maf-multiple-alignment-format" | "maf-mutation-annotation-format" | "merged-bam-file" | "mut" | "narrowpeak" | "psl" | "res" | "rna-secondary-structure-formats" | "sam" | "sample-info-attributes-file" | "seg" | "tdf" | "track-line" | "type-line" | "vcf" | "wig")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomGenomicStudyDataFormatVSCode(): GenomicStudyDataFormatVSCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomGenomicStudyDataFormatVSConcept(): GenomicStudyDataFormatVSConcept;
