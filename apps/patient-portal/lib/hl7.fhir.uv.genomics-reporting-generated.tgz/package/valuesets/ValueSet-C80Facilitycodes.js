/**
 * ValueSet: c80-facilitycodes
 * URL: http://hl7.org/fhir/ValueSet/c80-facilitycodes
 * Size: 79 concepts
 */
export const C80FacilitycodesConcepts = [
    { code: "82242000", system: "http://snomed.info/sct", display: "Children's hospital" },
    { code: "225732001", system: "http://snomed.info/sct", display: "Community hospital" },
    { code: "79993009", system: "http://snomed.info/sct", display: "Government hospital" },
    { code: "32074000", system: "http://snomed.info/sct", display: "Long term care hospital" },
    { code: "4322002", system: "http://snomed.info/sct", display: "Military field hospital" },
    { code: "224687002", system: "http://snomed.info/sct", display: "Prison hospital" },
    { code: "62480006", system: "http://snomed.info/sct", display: "Psychiatric hospital" },
    { code: "80522000", system: "http://snomed.info/sct", display: "Rehabilitation hospital" },
    { code: "36125001", system: "http://snomed.info/sct", display: "Trauma center" },
    { code: "48311003", system: "http://snomed.info/sct", display: "Veteran's administration hospital" },
    { code: "284546000", system: "http://snomed.info/sct", display: "Hospice" },
    { code: "42665001", system: "http://snomed.info/sct", display: "Nursing home" },
    { code: "45618002", system: "http://snomed.info/sct", display: "Skilled nursing facility" },
    { code: "418518002", system: "http://snomed.info/sct", display: "Dialysis unit (environment)" },
    { code: "73770003", system: "http://snomed.info/sct", display: "Hospital-based outpatient emergency care center" },
    { code: "69362002", system: "http://snomed.info/sct", display: "Hospital-based ambulatory surgery facility" },
    { code: "52668009", system: "http://snomed.info/sct", display: "Hospital-based birthing center" },
    { code: "360957003", system: "http://snomed.info/sct", display: "Hospital-based outpatient allergy clinic" },
    { code: "10206005", system: "http://snomed.info/sct", display: "Hospital-based outpatient dental clinic" },
    { code: "37550003", system: "http://snomed.info/sct", display: "Hospital-based outpatient dermatology clinic" },
    { code: "73644007", system: "http://snomed.info/sct", display: "Hospital-based outpatient endocrinology clinic" },
    { code: "31628002", system: "http://snomed.info/sct", display: "Hospital-based outpatient family medicine clinic" },
    { code: "58482006", system: "http://snomed.info/sct", display: "Hospital-based outpatient gastroenterology clinic" },
    { code: "90484001", system: "http://snomed.info/sct", display: "Hospital-based outpatient general surgery clinic" },
    { code: "1814000", system: "http://snomed.info/sct", display: "Hospital-based outpatient geriatric clinic" },
    { code: "22549003", system: "http://snomed.info/sct", display: "Hospital-based outpatient gynecology clinic" },
    { code: "56293002", system: "http://snomed.info/sct", display: "Hospital-based outpatient hematology clinic" },
    { code: "360966004", system: "http://snomed.info/sct", display: "Hospital-based outpatient immunology clinic" },
    { code: "2849009", system: "http://snomed.info/sct", display: "Hospital-based outpatient infectious disease clinic" },
    { code: "14866005", system: "http://snomed.info/sct", display: "Hospital-based outpatient mental health clinic" },
    { code: "38238005", system: "http://snomed.info/sct", display: "Hospital-based outpatient neurology clinic" },
    { code: "56189001", system: "http://snomed.info/sct", display: "Hospital-based outpatient obstetrical clinic" },
    { code: "89972002", system: "http://snomed.info/sct", display: "Hospital-based outpatient oncology clinic" },
    { code: "78088001", system: "http://snomed.info/sct", display: "Hospital-based outpatient ophthalmology clinic" },
    { code: "78001009", system: "http://snomed.info/sct", display: "Hospital-based outpatient orthopedics clinic" },
    { code: "23392004", system: "http://snomed.info/sct", display: "Hospital-based outpatient otorhinolaryngology clinic" },
    { code: "36293008", system: "http://snomed.info/sct", display: "Hospital-based outpatient pain clinic" },
    { code: "3729002", system: "http://snomed.info/sct", display: "Hospital-based outpatient pediatric clinic" },
    { code: "5584006", system: "http://snomed.info/sct", display: "Hospital-based outpatient peripheral vascular clinic" },
    { code: "37546005", system: "http://snomed.info/sct", display: "Hospital-based outpatient rehabilitation clinic" },
    { code: "57159002", system: "http://snomed.info/sct", display: "Hospital-based outpatient respiratory disease clinic" },
    { code: "331006", system: "http://snomed.info/sct", display: "Hospital-based outpatient rheumatology clinic" },
    { code: "50569004", system: "http://snomed.info/sct", display: "Hospital-based outpatient urology clinic" },
    { code: "79491001", system: "http://snomed.info/sct", display: "Hospital-based radiology facility" },
    { code: "33022008", system: "http://snomed.info/sct", display: "Hospital-based outpatient department" },
    { code: "19602009", system: "http://snomed.info/sct", display: "Fee-for-service private physicians' group office" },
    { code: "39350007", system: "http://snomed.info/sct", display: "Private physicians' group office" },
    { code: "83891005", system: "http://snomed.info/sct", display: "Solo practice private office" },
    { code: "394759007", system: "http://snomed.info/sct", display: "Independent provider site (environment)" },
    { code: "405607001", system: "http://snomed.info/sct", display: "Ambulatory surgery center (environment)" },
    { code: "309900005", system: "http://snomed.info/sct", display: "Care of the elderly day hospital" },
    { code: "275576008", system: "http://snomed.info/sct", display: "Elderly assessment clinic" },
    { code: "10531005", system: "http://snomed.info/sct", display: "Free-standing ambulatory surgery facility" },
    { code: "91154008", system: "http://snomed.info/sct", display: "Free-standing birthing center" },
    { code: "41844007", system: "http://snomed.info/sct", display: "Free-standing geriatric clinic" },
    { code: "45899008", system: "http://snomed.info/sct", display: "Free-standing laboratory facility" },
    { code: "51563005", system: "http://snomed.info/sct", display: "Free-standing mental health clinic" },
    { code: "1773006", system: "http://snomed.info/sct", display: "Free-standing radiology facility" },
    { code: "72311000", system: "http://snomed.info/sct", display: "Health maintenance organization" },
    { code: "6827000", system: "http://snomed.info/sct", display: "Local community health center" },
    { code: "309898008", system: "http://snomed.info/sct", display: "Psychogeriatric day hospital" },
    { code: "39913001", system: "http://snomed.info/sct", display: "Residential school infirmary" },
    { code: "77931003", system: "http://snomed.info/sct", display: "Rural health center" },
    { code: "25681007", system: "http://snomed.info/sct", display: "Sexually transmitted disease clinic" },
    { code: "20078004", system: "http://snomed.info/sct", display: "Substance abuse treatment center" },
    { code: "46224007", system: "http://snomed.info/sct", display: "Vaccination clinic" },
    { code: "81234003", system: "http://snomed.info/sct", display: "Walk-in clinic" },
    { code: "35971002", system: "http://snomed.info/sct", display: "Ambulatory care site" },
    { code: "11424001", system: "http://snomed.info/sct", display: "Ambulance-based care" },
    { code: "409519008", system: "http://snomed.info/sct", display: "Contained casualty setting (environment)" },
    { code: "901005", system: "http://snomed.info/sct", display: "Helicopter-based care" },
    { code: "2081004", system: "http://snomed.info/sct", display: "Hospital ship" },
    { code: "59374000", system: "http://snomed.info/sct", display: "Traveler's aid clinic" },
    { code: "413456002", system: "http://snomed.info/sct", display: "Adult day care center (environment)" },
    { code: "413817003", system: "http://snomed.info/sct", display: "Child day care center (environment)" },
    { code: "310205006", system: "http://snomed.info/sct", display: "Private residential home" },
    { code: "419955002", system: "http://snomed.info/sct", display: "Residential institution (environment)" },
    { code: "272501009", system: "http://snomed.info/sct", display: "Sports facility" },
    { code: "394777002", system: "http://snomed.info/sct", display: "Health encounter sites (environment)" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidC80FacilitycodesCode(code) {
    return C80FacilitycodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getC80FacilitycodesConcept(code) {
    return C80FacilitycodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const C80FacilitycodesCodes = C80FacilitycodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomC80FacilitycodesCode() {
    return C80FacilitycodesCodes[Math.floor(Math.random() * C80FacilitycodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomC80FacilitycodesConcept() {
    return C80FacilitycodesConcepts[Math.floor(Math.random() * C80FacilitycodesConcepts.length)];
}
