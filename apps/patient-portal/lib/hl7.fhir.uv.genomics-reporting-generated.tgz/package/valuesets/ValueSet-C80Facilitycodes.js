/**
 * ValueSet: c80-facilitycodes
 * URL: http://hl7.org/fhir/ValueSet/c80-facilitycodes
 * Size: 79 concepts
 */
export const C80FacilitycodesConcepts = [
    { code: "82242000", system: "http://snomed.info/sct" },
    { code: "225732001", system: "http://snomed.info/sct" },
    { code: "79993009", system: "http://snomed.info/sct" },
    { code: "32074000", system: "http://snomed.info/sct" },
    { code: "4322002", system: "http://snomed.info/sct" },
    { code: "224687002", system: "http://snomed.info/sct" },
    { code: "62480006", system: "http://snomed.info/sct" },
    { code: "80522000", system: "http://snomed.info/sct" },
    { code: "36125001", system: "http://snomed.info/sct" },
    { code: "48311003", system: "http://snomed.info/sct" },
    { code: "284546000", system: "http://snomed.info/sct" },
    { code: "42665001", system: "http://snomed.info/sct" },
    { code: "45618002", system: "http://snomed.info/sct" },
    { code: "418518002", system: "http://snomed.info/sct" },
    { code: "73770003", system: "http://snomed.info/sct" },
    { code: "69362002", system: "http://snomed.info/sct" },
    { code: "52668009", system: "http://snomed.info/sct" },
    { code: "360957003", system: "http://snomed.info/sct" },
    { code: "10206005", system: "http://snomed.info/sct" },
    { code: "37550003", system: "http://snomed.info/sct" },
    { code: "73644007", system: "http://snomed.info/sct" },
    { code: "31628002", system: "http://snomed.info/sct" },
    { code: "58482006", system: "http://snomed.info/sct" },
    { code: "90484001", system: "http://snomed.info/sct" },
    { code: "1814000", system: "http://snomed.info/sct" },
    { code: "22549003", system: "http://snomed.info/sct" },
    { code: "56293002", system: "http://snomed.info/sct" },
    { code: "360966004", system: "http://snomed.info/sct" },
    { code: "2849009", system: "http://snomed.info/sct" },
    { code: "14866005", system: "http://snomed.info/sct" },
    { code: "38238005", system: "http://snomed.info/sct" },
    { code: "56189001", system: "http://snomed.info/sct" },
    { code: "89972002", system: "http://snomed.info/sct" },
    { code: "78088001", system: "http://snomed.info/sct" },
    { code: "78001009", system: "http://snomed.info/sct" },
    { code: "23392004", system: "http://snomed.info/sct" },
    { code: "36293008", system: "http://snomed.info/sct" },
    { code: "3729002", system: "http://snomed.info/sct" },
    { code: "5584006", system: "http://snomed.info/sct" },
    { code: "37546005", system: "http://snomed.info/sct" },
    { code: "57159002", system: "http://snomed.info/sct" },
    { code: "331006", system: "http://snomed.info/sct" },
    { code: "50569004", system: "http://snomed.info/sct" },
    { code: "79491001", system: "http://snomed.info/sct" },
    { code: "33022008", system: "http://snomed.info/sct" },
    { code: "19602009", system: "http://snomed.info/sct" },
    { code: "39350007", system: "http://snomed.info/sct" },
    { code: "83891005", system: "http://snomed.info/sct" },
    { code: "394759007", system: "http://snomed.info/sct" },
    { code: "405607001", system: "http://snomed.info/sct" },
    { code: "309900005", system: "http://snomed.info/sct" },
    { code: "275576008", system: "http://snomed.info/sct" },
    { code: "10531005", system: "http://snomed.info/sct" },
    { code: "91154008", system: "http://snomed.info/sct" },
    { code: "41844007", system: "http://snomed.info/sct" },
    { code: "45899008", system: "http://snomed.info/sct" },
    { code: "51563005", system: "http://snomed.info/sct" },
    { code: "1773006", system: "http://snomed.info/sct" },
    { code: "72311000", system: "http://snomed.info/sct" },
    { code: "6827000", system: "http://snomed.info/sct" },
    { code: "309898008", system: "http://snomed.info/sct" },
    { code: "39913001", system: "http://snomed.info/sct" },
    { code: "77931003", system: "http://snomed.info/sct" },
    { code: "25681007", system: "http://snomed.info/sct" },
    { code: "20078004", system: "http://snomed.info/sct" },
    { code: "46224007", system: "http://snomed.info/sct" },
    { code: "81234003", system: "http://snomed.info/sct" },
    { code: "35971002", system: "http://snomed.info/sct" },
    { code: "11424001", system: "http://snomed.info/sct" },
    { code: "409519008", system: "http://snomed.info/sct" },
    { code: "901005", system: "http://snomed.info/sct" },
    { code: "2081004", system: "http://snomed.info/sct" },
    { code: "59374000", system: "http://snomed.info/sct" },
    { code: "413456002", system: "http://snomed.info/sct" },
    { code: "413817003", system: "http://snomed.info/sct" },
    { code: "310205006", system: "http://snomed.info/sct" },
    { code: "419955002", system: "http://snomed.info/sct" },
    { code: "272501009", system: "http://snomed.info/sct" },
    { code: "394777002", system: "http://snomed.info/sct" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidC80FacilitycodesCode(code) {
    return C80FacilitycodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getC80FacilitycodesConcept(code) {
    return C80FacilitycodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const C80FacilitycodesCodes = C80FacilitycodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomC80FacilitycodesCode() {
    return C80FacilitycodesCodes[Math.floor(Math.random() * C80FacilitycodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomC80FacilitycodesConcept() {
    return C80FacilitycodesConcepts[Math.floor(Math.random() * C80FacilitycodesConcepts.length)];
}
