/**
 * ValueSet: LL4034-6
 * URL: http://loinc.org/vs/LL4034-6
 * Size: 5 concepts
 */
export declare const LL40346Concepts: readonly [{
    readonly code: "LA6668-3";
    readonly system: "http://loinc.org";
    readonly display: "Pathogenic";
}, {
    readonly code: "LA26332-9";
    readonly system: "http://loinc.org";
    readonly display: "Likely pathogenic";
}, {
    readonly code: "LA26333-7";
    readonly system: "http://loinc.org";
    readonly display: "Uncertain significance";
}, {
    readonly code: "LA26334-5";
    readonly system: "http://loinc.org";
    readonly display: "Likely benign";
}, {
    readonly code: "LA6675-8";
    readonly system: "http://loinc.org";
    readonly display: "Benign";
}];
/** Union type of all valid codes in this ValueSet */
export type LL40346Code = "LA6668-3" | "LA26332-9" | "LA26333-7" | "LA26334-5" | "LA6675-8";
/** Type representing a concept from this ValueSet */
export type LL40346Concept = typeof LL40346Concepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidLL40346Code(code: string): code is LL40346Code;
/**
 * Get concept details by code
 */
export declare function getLL40346Concept(code: string): LL40346Concept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const LL40346Codes: ("LA6675-8" | "LA6668-3" | "LA26332-9" | "LA26333-7" | "LA26334-5")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomLL40346Code(): LL40346Code;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomLL40346Concept(): LL40346Concept;
