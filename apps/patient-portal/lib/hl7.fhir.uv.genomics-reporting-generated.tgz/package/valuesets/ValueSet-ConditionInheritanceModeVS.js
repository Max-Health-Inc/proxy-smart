/**
 * ValueSet: ConditionInheritanceModeVS
 * URL: http://hl7.org/fhir/uv/genomics-reporting/ValueSet/condition-inheritance-mode-vs
 * Size: 17 concepts
 */
export const ConditionInheritanceModeVSConcepts = [
    { code: "HP:0000006", system: "http://human-phenotype-ontology.org", display: "Autosomal dominant inheritance" },
    { code: "HP:0000007", system: "http://human-phenotype-ontology.org", display: "Autosomal recessive inheritance" },
    { code: "HP:0001417", system: "http://human-phenotype-ontology.org", display: "X-linked inheritance" },
    { code: "HP:0001419", system: "http://human-phenotype-ontology.org", display: "X-linked recessive inheritance" },
    { code: "HP:0001423", system: "http://human-phenotype-ontology.org", display: "X-linked dominant inheritance" },
    { code: "HP:0001426", system: "http://human-phenotype-ontology.org", display: "Multifactorial inheritance" },
    { code: "HP:0001427", system: "http://human-phenotype-ontology.org", display: "Mitochondrial inheritance" },
    { code: "HP:0001442", system: "http://human-phenotype-ontology.org", display: "Typified by somatic mosaicism" },
    { code: "HP:0001450", system: "http://human-phenotype-ontology.org", display: "Y-linked inheritance" },
    { code: "HP:0001470", system: "http://human-phenotype-ontology.org", display: "Sex-limited expression" },
    { code: "HP:0003743", system: "http://human-phenotype-ontology.org", display: "Genetic anticipation" },
    { code: "HP:0003745", system: "http://human-phenotype-ontology.org", display: "Sporadic" },
    { code: "HP:0010983", system: "http://human-phenotype-ontology.org", display: "Oligogenic inheritance" },
    { code: "HP:0012274", system: "http://human-phenotype-ontology.org", display: "Autosomal dominant inheritance with paternal imprinting" },
    { code: "HP:0012275", system: "http://human-phenotype-ontology.org", display: "Autosomal dominant inheritance with maternal imprinting" },
    { code: "HP:0025352", system: "http://human-phenotype-ontology.org", display: "Typically de novo" },
    { code: "HP:0032113", system: "http://human-phenotype-ontology.org", display: "Semidominant inheritance" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidConditionInheritanceModeVSCode(code) {
    return ConditionInheritanceModeVSConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getConditionInheritanceModeVSConcept(code) {
    return ConditionInheritanceModeVSConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ConditionInheritanceModeVSCodes = ConditionInheritanceModeVSConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomConditionInheritanceModeVSCode() {
    return ConditionInheritanceModeVSCodes[Math.floor(Math.random() * ConditionInheritanceModeVSCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomConditionInheritanceModeVSConcept() {
    return ConditionInheritanceModeVSConcepts[Math.floor(Math.random() * ConditionInheritanceModeVSConcepts.length)];
}
