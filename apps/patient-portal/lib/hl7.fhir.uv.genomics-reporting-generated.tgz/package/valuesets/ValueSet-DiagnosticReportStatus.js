/**
 * ValueSet: diagnostic-report-status
 * URL: http://hl7.org/fhir/ValueSet/diagnostic-report-status
 * Size: 10 concepts
 */
export const DiagnosticReportStatusConcepts = [
    { code: "registered", system: "http://hl7.org/fhir/diagnostic-report-status" },
    { code: "partial", system: "http://hl7.org/fhir/diagnostic-report-status" },
    { code: "preliminary", system: "http://hl7.org/fhir/diagnostic-report-status" },
    { code: "final", system: "http://hl7.org/fhir/diagnostic-report-status" },
    { code: "amended", system: "http://hl7.org/fhir/diagnostic-report-status" },
    { code: "corrected", system: "http://hl7.org/fhir/diagnostic-report-status" },
    { code: "appended", system: "http://hl7.org/fhir/diagnostic-report-status" },
    { code: "cancelled", system: "http://hl7.org/fhir/diagnostic-report-status" },
    { code: "entered-in-error", system: "http://hl7.org/fhir/diagnostic-report-status" },
    { code: "unknown", system: "http://hl7.org/fhir/diagnostic-report-status" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidDiagnosticReportStatusCode(code) {
    return DiagnosticReportStatusConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getDiagnosticReportStatusConcept(code) {
    return DiagnosticReportStatusConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const DiagnosticReportStatusCodes = DiagnosticReportStatusConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomDiagnosticReportStatusCode() {
    return DiagnosticReportStatusCodes[Math.floor(Math.random() * DiagnosticReportStatusCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomDiagnosticReportStatusConcept() {
    return DiagnosticReportStatusConcepts[Math.floor(Math.random() * DiagnosticReportStatusConcepts.length)];
}
