/**
 * ValueSet: VariantConfidenceStatusVS
 * URL: http://hl7.org/fhir/uv/genomics-reporting/ValueSet/variant-confidence-status-vs
 * Size: 3 concepts
 */
export declare const VariantConfidenceStatusVSConcepts: readonly [{
    readonly code: "high";
    readonly system: "http://terminology.hl7.org/CodeSystem/variant-confidence-status-cs";
}, {
    readonly code: "intermediate";
    readonly system: "http://terminology.hl7.org/CodeSystem/variant-confidence-status-cs";
}, {
    readonly code: "low";
    readonly system: "http://terminology.hl7.org/CodeSystem/variant-confidence-status-cs";
}];
/** Union type of all valid codes in this ValueSet */
export type VariantConfidenceStatusVSCode = "high" | "intermediate" | "low";
/** Type representing a concept from this ValueSet */
export type VariantConfidenceStatusVSConcept = typeof VariantConfidenceStatusVSConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidVariantConfidenceStatusVSCode(code: string): code is VariantConfidenceStatusVSCode;
/**
 * Get concept details by code
 */
export declare function getVariantConfidenceStatusVSConcept(code: string): VariantConfidenceStatusVSConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const VariantConfidenceStatusVSCodes: ("high" | "intermediate" | "low")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomVariantConfidenceStatusVSCode(): VariantConfidenceStatusVSCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomVariantConfidenceStatusVSConcept(): VariantConfidenceStatusVSConcept;
