/**
 * ValueSet: TBDCodesVS
 * URL: http://hl7.org/fhir/uv/genomics-reporting/ValueSet/tbd-codes-vs
 * Size: 13 concepts
 */
export declare const TBDCodesVSConcepts: readonly [{
    readonly code: "associated-therapy";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs";
}, {
    readonly code: "molecular-consequence";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs";
}, {
    readonly code: "feature-consequence";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs";
}, {
    readonly code: "diagnostic-implication";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs";
}, {
    readonly code: "therapeutic-implication";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs";
}, {
    readonly code: "functional-effect";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs";
}, {
    readonly code: "conclusion-string";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs";
}, {
    readonly code: "condition-inheritance";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs";
}, {
    readonly code: "variant-confidence-status";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs";
}, {
    readonly code: "repeat-motif";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs";
}, {
    readonly code: "repeat-number";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs";
}, {
    readonly code: "biomarker-category";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs";
}, {
    readonly code: "protein-ref-seq";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs";
}];
/** Union type of all valid codes in this ValueSet */
export type TBDCodesVSCode = "associated-therapy" | "molecular-consequence" | "feature-consequence" | "diagnostic-implication" | "therapeutic-implication" | "functional-effect" | "conclusion-string" | "condition-inheritance" | "variant-confidence-status" | "repeat-motif" | "repeat-number" | "biomarker-category" | "protein-ref-seq";
/** Type representing a concept from this ValueSet */
export type TBDCodesVSConcept = typeof TBDCodesVSConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidTBDCodesVSCode(code: string): code is TBDCodesVSCode;
/**
 * Get concept details by code
 */
export declare function getTBDCodesVSConcept(code: string): TBDCodesVSConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const TBDCodesVSCodes: ("diagnostic-implication" | "conclusion-string" | "condition-inheritance" | "biomarker-category" | "molecular-consequence" | "protein-ref-seq" | "feature-consequence" | "functional-effect" | "therapeutic-implication" | "associated-therapy" | "variant-confidence-status" | "repeat-motif" | "repeat-number")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomTBDCodesVSCode(): TBDCodesVSCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomTBDCodesVSConcept(): TBDCodesVSConcept;
