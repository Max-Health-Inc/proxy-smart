/**
 * ValueSet: SequencePhaseRelationshipVS
 * URL: http://hl7.org/fhir/uv/genomics-reporting/ValueSet/sequence-phase-relationship-vs
 * Size: 4 concepts
 */
export const SequencePhaseRelationshipVSConcepts = [
    { code: "Cis", system: "http://terminology.hl7.org/CodeSystem/sequence-phase-relationship-cs" },
    { code: "Trans", system: "http://terminology.hl7.org/CodeSystem/sequence-phase-relationship-cs" },
    { code: "Indeterminate", system: "http://terminology.hl7.org/CodeSystem/sequence-phase-relationship-cs" },
    { code: "Unknown", system: "http://terminology.hl7.org/CodeSystem/sequence-phase-relationship-cs" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidSequencePhaseRelationshipVSCode(code) {
    return SequencePhaseRelationshipVSConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getSequencePhaseRelationshipVSConcept(code) {
    return SequencePhaseRelationshipVSConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const SequencePhaseRelationshipVSCodes = SequencePhaseRelationshipVSConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomSequencePhaseRelationshipVSCode() {
    return SequencePhaseRelationshipVSCodes[Math.floor(Math.random() * SequencePhaseRelationshipVSCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomSequencePhaseRelationshipVSConcept() {
    return SequencePhaseRelationshipVSConcepts[Math.floor(Math.random() * SequencePhaseRelationshipVSConcepts.length)];
}
