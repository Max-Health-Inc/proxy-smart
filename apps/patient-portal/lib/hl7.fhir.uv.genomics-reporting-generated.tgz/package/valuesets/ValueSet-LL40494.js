/**
 * ValueSet: LL4049-4
 * URL: http://loinc.org/vs/LL4049-4
 * Size: 5 concepts
 */
export const LL40494Concepts = [
    { code: "LA26421-0", system: "http://loinc.org", display: "Consider alternative medication" },
    { code: "LA26422-8", system: "http://loinc.org", display: "Decrease dose" },
    { code: "LA26423-6", system: "http://loinc.org", display: "Increase dose" },
    { code: "LA26424-4", system: "http://loinc.org", display: "Use caution" },
    { code: "LA26425-1", system: "http://loinc.org", display: "Normal response expected" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidLL40494Code(code) {
    return LL40494Concepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getLL40494Concept(code) {
    return LL40494Concepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const LL40494Codes = LL40494Concepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomLL40494Code() {
    return LL40494Codes[Math.floor(Math.random() * LL40494Codes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomLL40494Concept() {
    return LL40494Concepts[Math.floor(Math.random() * LL40494Concepts.length)];
}
