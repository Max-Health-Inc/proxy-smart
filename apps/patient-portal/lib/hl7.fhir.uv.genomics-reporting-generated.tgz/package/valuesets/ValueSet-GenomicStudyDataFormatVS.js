/**
 * ValueSet: GenomicStudyDataFormatVS
 * URL: http://hl7.org/fhir/uv/genomics-reporting/ValueSet/genomic-study-data-format-vs
 * Size: 40 concepts
 */
export const GenomicStudyDataFormatVSConcepts = [
    { code: "bam", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "bed", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "bedpe", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "bedgraph", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "bigbed", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "bigWig", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "birdsuite-files", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "broadpeak", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "cbs", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "chemical-reactivity-probing-profiles", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "chrom-sizes", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "cn", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "custom-file-formats", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "cytoband", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "fasta", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "gct", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "cram", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "genepred", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "gff-gtf", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "gistic", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "goby", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "gwas", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "igv", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "loh", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "maf-multiple-alignment-format", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "maf-mutation-annotation-format", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "merged-bam-file", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "mut", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "narrowpeak", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "psl", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "res", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "rna-secondary-structure-formats", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "sam", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "sample-info-attributes-file", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "seg", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "tdf", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "track-line", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "type-line", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "vcf", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
    { code: "wig", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-data-format-cs" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidGenomicStudyDataFormatVSCode(code) {
    return GenomicStudyDataFormatVSConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getGenomicStudyDataFormatVSConcept(code) {
    return GenomicStudyDataFormatVSConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const GenomicStudyDataFormatVSCodes = GenomicStudyDataFormatVSConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomGenomicStudyDataFormatVSCode() {
    return GenomicStudyDataFormatVSCodes[Math.floor(Math.random() * GenomicStudyDataFormatVSCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomGenomicStudyDataFormatVSConcept() {
    return GenomicStudyDataFormatVSConcepts[Math.floor(Math.random() * GenomicStudyDataFormatVSConcepts.length)];
}
