/**
 * ValueSet: LL381-5
 * URL: http://loinc.org/vs/LL381-5
 * Size: 5 concepts
 */
export const LL3815Concepts = [
    { code: "LA6703-8", system: "http://loinc.org", display: "Heteroplasmic" },
    { code: "LA6704-6", system: "http://loinc.org", display: "Homoplasmic" },
    { code: "LA6705-3", system: "http://loinc.org", display: "Homozygous" },
    { code: "LA6706-1", system: "http://loinc.org", display: "Heterozygous" },
    { code: "LA6707-9", system: "http://loinc.org", display: "Hemizygous" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidLL3815Code(code) {
    return LL3815Concepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getLL3815Concept(code) {
    return LL3815Concepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const LL3815Codes = LL3815Concepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomLL3815Code() {
    return LL3815Codes[Math.floor(Math.random() * LL3815Codes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomLL3815Concept() {
    return LL3815Concepts[Math.floor(Math.random() * LL3815Concepts.length)];
}
