/**
 * ValueSet: LL1037-2
 * URL: http://loinc.org/vs/LL1037-2
 * Size: 3 concepts
 */
export const LL10372Concepts = [
    { code: "LA14020-4", system: "http://loinc.org", display: "Genetic counseling recommended" },
    { code: "LA14021-2", system: "http://loinc.org", display: "Confirmatory testing recommended" },
    { code: "LA14022-0", system: "http://loinc.org", display: "Additional testing recommended" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidLL10372Code(code) {
    return LL10372Concepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getLL10372Concept(code) {
    return LL10372Concepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const LL10372Codes = LL10372Concepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomLL10372Code() {
    return LL10372Codes[Math.floor(Math.random() * LL10372Codes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomLL10372Concept() {
    return LL10372Concepts[Math.floor(Math.random() * LL10372Concepts.length)];
}
