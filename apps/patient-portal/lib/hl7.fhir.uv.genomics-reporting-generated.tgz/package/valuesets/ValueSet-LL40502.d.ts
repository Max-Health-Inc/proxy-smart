/**
 * ValueSet: LL4050-2
 * URL: http://loinc.org/vs/LL4050-2
 * Size: 4 concepts
 */
export declare const LL40502Concepts: readonly [{
    readonly code: "LA26426-9";
    readonly system: "http://loinc.org";
    readonly display: "Directly measured";
}, {
    readonly code: "LA26427-7";
    readonly system: "http://loinc.org";
    readonly display: "Family DNA";
}, {
    readonly code: "LA26428-5";
    readonly system: "http://loinc.org";
    readonly display: "Family history";
}, {
    readonly code: "LA26429-3";
    readonly system: "http://loinc.org";
    readonly display: "Inferred from population data";
}];
/** Union type of all valid codes in this ValueSet */
export type LL40502Code = "LA26426-9" | "LA26427-7" | "LA26428-5" | "LA26429-3";
/** Type representing a concept from this ValueSet */
export type LL40502Concept = typeof LL40502Concepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidLL40502Code(code: string): code is LL40502Code;
/**
 * Get concept details by code
 */
export declare function getLL40502Concept(code: string): LL40502Concept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const LL40502Codes: ("LA26426-9" | "LA26427-7" | "LA26428-5" | "LA26429-3")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomLL40502Code(): LL40502Code;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomLL40502Concept(): LL40502Concept;
