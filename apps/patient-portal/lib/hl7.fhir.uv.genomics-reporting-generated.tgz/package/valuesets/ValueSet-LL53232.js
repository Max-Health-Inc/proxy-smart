/**
 * ValueSet: LL5323-2
 * URL: http://loinc.org/vs/LL5323-2
 * Size: 3 concepts
 */
export const LL53232Concepts = [
    { code: "LA30100-4", system: "http://loinc.org", display: "0-based interval counting" },
    { code: "LA30101-2", system: "http://loinc.org", display: "0-based character counting" },
    { code: "LA30102-0", system: "http://loinc.org", display: "1-based character counting" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidLL53232Code(code) {
    return LL53232Concepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getLL53232Concept(code) {
    return LL53232Concepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const LL53232Codes = LL53232Concepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomLL53232Code() {
    return LL53232Codes[Math.floor(Math.random() * LL53232Codes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomLL53232Concept() {
    return LL53232Concepts[Math.floor(Math.random() * LL53232Concepts.length)];
}
