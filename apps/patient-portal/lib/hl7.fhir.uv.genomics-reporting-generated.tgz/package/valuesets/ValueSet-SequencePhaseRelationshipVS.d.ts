/**
 * ValueSet: SequencePhaseRelationshipVS
 * URL: http://hl7.org/fhir/uv/genomics-reporting/ValueSet/sequence-phase-relationship-vs
 * Size: 4 concepts
 */
export declare const SequencePhaseRelationshipVSConcepts: readonly [{
    readonly code: "Cis";
    readonly system: "http://terminology.hl7.org/CodeSystem/sequence-phase-relationship-cs";
}, {
    readonly code: "Trans";
    readonly system: "http://terminology.hl7.org/CodeSystem/sequence-phase-relationship-cs";
}, {
    readonly code: "Indeterminate";
    readonly system: "http://terminology.hl7.org/CodeSystem/sequence-phase-relationship-cs";
}, {
    readonly code: "Unknown";
    readonly system: "http://terminology.hl7.org/CodeSystem/sequence-phase-relationship-cs";
}];
/** Union type of all valid codes in this ValueSet */
export type SequencePhaseRelationshipVSCode = "Cis" | "Trans" | "Indeterminate" | "Unknown";
/** Type representing a concept from this ValueSet */
export type SequencePhaseRelationshipVSConcept = typeof SequencePhaseRelationshipVSConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidSequencePhaseRelationshipVSCode(code: string): code is SequencePhaseRelationshipVSCode;
/**
 * Get concept details by code
 */
export declare function getSequencePhaseRelationshipVSConcept(code: string): SequencePhaseRelationshipVSConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const SequencePhaseRelationshipVSCodes: ("Unknown" | "Cis" | "Trans" | "Indeterminate")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomSequencePhaseRelationshipVSCode(): SequencePhaseRelationshipVSCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomSequencePhaseRelationshipVSConcept(): SequencePhaseRelationshipVSConcept;
