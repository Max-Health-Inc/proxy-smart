/**
 * ValueSet: MolecularBiomarkerCodeVS
 * URL: http://hl7.org/fhir/uv/genomics-reporting/ValueSet/molecular-biomarker-code-vs
 * Size: 17 concepts
 */
export declare const MolecularBiomarkerCodeVSConcepts: readonly [{
    readonly code: "85337-4";
    readonly system: "http://loinc.org";
    readonly display: "Estrogen receptor Ag Immune stain Ql (Breast cancer specimen)";
}, {
    readonly code: "72382-5";
    readonly system: "http://loinc.org";
    readonly display: "HER2 IA Qn (Tiss)";
}, {
    readonly code: "77637-7";
    readonly system: "http://loinc.org";
    readonly display: "HLA-A and B and C (class I) IgG panel IA [Identifier]";
}, {
    readonly code: "40557-1";
    readonly system: "http://loinc.org";
    readonly display: "Progesterone receptor Ag Immune stain Ql (Tiss)";
}, {
    readonly code: "85147-7";
    readonly system: "http://loinc.org";
    readonly display: "PD-L1 by clone 22C3 Immune stain Doc (Tiss)";
}, {
    readonly code: "59025-7";
    readonly system: "http://loinc.org";
    readonly display: "Neutrophil Ab FC Qn (S)";
}, {
    readonly code: "59003-4";
    readonly system: "http://loinc.org";
    readonly display: "Lactoferrin Ab IA Qn (S)";
}, {
    readonly code: "10495-0";
    readonly system: "http://loinc.org";
    readonly display: "Insulin Ag Immune stain Ql (Tiss)";
}, {
    readonly code: "16550-6";
    readonly system: "http://loinc.org";
    readonly display: "Carbohydrates Nom (U)";
}, {
    readonly code: "2569-2";
    readonly system: "http://loinc.org";
    readonly display: "Lipids (S) [Mass/Vol]";
}, {
    readonly code: "4551-8";
    readonly system: "http://loinc.org";
    readonly display: "Hemoglobin A2 (Bld) [Mass fraction]";
}, {
    readonly code: "19195-7";
    readonly system: "http://loinc.org";
    readonly display: "Prostate specific Ag Qn";
}, {
    readonly code: "64083-9";
    readonly system: "http://loinc.org";
    readonly display: "MGMT gene methylation score Molgen (Tiss) [Ratio]";
}, {
    readonly code: "62862-8";
    readonly system: "http://loinc.org";
    readonly display: "Microsatellite instability Immune stain Ql (Tiss)";
}, {
    readonly code: "81704-9";
    readonly system: "http://loinc.org";
    readonly display: "Microsatellite instability marker D17S250 Ql (Cancer specimen)";
}, {
    readonly code: "94077-5";
    readonly system: "http://loinc.org";
    readonly display: "Tumor mutation burden Ql (Tumor) [Interp]";
}, {
    readonly code: "C120465";
    readonly system: "http://ncicb.nci.nih.gov/xml/owl/EVS/Thesaurus.owl";
    readonly display: "Homologous Recombination Repair Deficiency";
}];
/** Union type of all valid codes in this ValueSet */
export type MolecularBiomarkerCodeVSCode = "85337-4" | "72382-5" | "77637-7" | "40557-1" | "85147-7" | "59025-7" | "59003-4" | "10495-0" | "16550-6" | "2569-2" | "4551-8" | "19195-7" | "64083-9" | "62862-8" | "81704-9" | "94077-5" | "C120465";
/** Type representing a concept from this ValueSet */
export type MolecularBiomarkerCodeVSConcept = typeof MolecularBiomarkerCodeVSConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidMolecularBiomarkerCodeVSCode(code: string): code is MolecularBiomarkerCodeVSCode;
/**
 * Get concept details by code
 */
export declare function getMolecularBiomarkerCodeVSConcept(code: string): MolecularBiomarkerCodeVSConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const MolecularBiomarkerCodeVSCodes: ("62862-8" | "85337-4" | "72382-5" | "77637-7" | "40557-1" | "85147-7" | "59025-7" | "59003-4" | "10495-0" | "16550-6" | "2569-2" | "4551-8" | "19195-7" | "64083-9" | "81704-9" | "94077-5" | "C120465")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomMolecularBiomarkerCodeVSCode(): MolecularBiomarkerCodeVSCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomMolecularBiomarkerCodeVSConcept(): MolecularBiomarkerCodeVSConcept;
