/**
 * ValueSet: LL1971-2
 * URL: http://loinc.org/vs/LL1971-2
 * Size: 4 concepts
 */
export const LL19712Concepts = [
    { code: "LA9633-4", system: "http://loinc.org", display: "Present" },
    { code: "LA9634-2", system: "http://loinc.org", display: "Absent" },
    { code: "LA18198-4", system: "http://loinc.org", display: "No call" },
    { code: "LA11884-6", system: "http://loinc.org", display: "Indeterminate" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidLL19712Code(code) {
    return LL19712Concepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getLL19712Concept(code) {
    return LL19712Concepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const LL19712Codes = LL19712Concepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomLL19712Code() {
    return LL19712Codes[Math.floor(Math.random() * LL19712Codes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomLL19712Concept() {
    return LL19712Concepts[Math.floor(Math.random() * LL19712Concepts.length)];
}
