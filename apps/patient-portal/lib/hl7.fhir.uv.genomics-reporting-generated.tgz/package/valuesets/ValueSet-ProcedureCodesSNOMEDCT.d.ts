/**
 * ValueSet: ProcedureCodes(SNOMEDCT)
 * URL: http://hl7.org/fhir/ValueSet/procedure-code
 * Size: 100 concepts
 */
export declare const ProcedureCodesSNOMEDCTConcepts: readonly [{
    readonly code: "71388002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Procedure";
}, {
    readonly code: "104001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Excision of lesion of patella";
}, {
    readonly code: "115006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Removable appliance therapy";
}, {
    readonly code: "119000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Thoracoscopic partial lobectomy of lung";
}, {
    readonly code: "128004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hand microscope examination of skin";
}, {
    readonly code: "133000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Percutaneous implantation of neurostimulator electrodes into neuromuscular component";
}, {
    readonly code: "135007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Arthrotomy of wrist joint with exploration and biopsy";
}, {
    readonly code: "142007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Excision of tumor from shoulder area, deep, intramuscular";
}, {
    readonly code: "146005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Repair of nonunion of metatarsal with bone graft";
}, {
    readonly code: "153001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Cystourethroscopy with resection of ureterocele";
}, {
    readonly code: "166001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Behavioral therapy";
}, {
    readonly code: "170009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Special potency disk identification, vancomycin test";
}, {
    readonly code: "174000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Harrison-Richardson operation on vagina";
}, {
    readonly code: "176003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Anastomosis of rectum";
}, {
    readonly code: "189009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Excision of lesion of artery";
}, {
    readonly code: "197002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Mold to yeast conversion test";
}, {
    readonly code: "230009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Miller operation, urethrovesical suspension";
}, {
    readonly code: "243009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Replacement of cerebral ventricular tube";
}, {
    readonly code: "245002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Division of nerve ganglion";
}, {
    readonly code: "262007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Percutaneous aspiration of renal pelvis";
}, {
    readonly code: "267001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Anal fistulectomy, multiple";
}, {
    readonly code: "285008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Incision and drainage of vulva";
}, {
    readonly code: "294002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Excisional biopsy of joint structure of spine";
}, {
    readonly code: "295001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Nonexcisional destruction of cyst of ciliary body";
}, {
    readonly code: "306005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Echography of kidney";
}, {
    readonly code: "316002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Partial dacryocystectomy";
}, {
    readonly code: "334003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Panorex examination of mandible";
}, {
    readonly code: "342002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Amobarbital interview";
}, {
    readonly code: "348003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Radionuclide dynamic function study";
}, {
    readonly code: "351005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Urinary undiversion of ureteral anastomosis";
}, {
    readonly code: "352003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Reagent RBC, preparation antibody sensitized pool";
}, {
    readonly code: "374009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Costosternoplasty for pectus excavatum repair";
}, {
    readonly code: "388008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Blepharorrhaphy";
}, {
    readonly code: "389000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Tobramycin measurement";
}, {
    readonly code: "401004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Distal subtotal pancreatectomy";
}, {
    readonly code: "406009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Fulguration of stomach lesion";
}, {
    readonly code: "417005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hospital re-admission";
}, {
    readonly code: "435001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Pulmonary inhalation study";
}, {
    readonly code: "445004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Repair of malunion of tibia";
}, {
    readonly code: "456004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Total abdominal colectomy with ileostomy";
}, {
    readonly code: "459006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Closed condylotomy of mandible";
}, {
    readonly code: "463004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Closed reduction of coxofemoral joint dislocation with splint";
}, {
    readonly code: "468008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Glutathione measurement";
}, {
    readonly code: "474008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Esophagoenteric anastomosis, intrathoracic";
}, {
    readonly code: "489004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Ferritin measurement";
}, {
    readonly code: "493005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Urobilinogen measurement, 48-hour, feces";
}, {
    readonly code: "494004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Excision of lesion of tonsil";
}, {
    readonly code: "497006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Replacement of cochlear prosthesis, multiple channels";
}, {
    readonly code: "531007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Open pulmonary valve commissurotomy with inflow occlusion";
}, {
    readonly code: "533005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Repair of vesicocolic fistula";
}, {
    readonly code: "535003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Closure of ureterovesicovaginal fistula";
}, {
    readonly code: "540006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Antibody to single and double stranded DNA measurement";
}, {
    readonly code: "543008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Choledochostomy with transduodenal sphincteroplasty";
}, {
    readonly code: "545001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Operative procedure on lower leg";
}, {
    readonly code: "549007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Incision of intracranial vein";
}, {
    readonly code: "550007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Excision of lesion of adenoids";
}, {
    readonly code: "559008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Excision of varicose vein";
}, {
    readonly code: "574005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Benzodiazepine measurement";
}, {
    readonly code: "617002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Bone graft to mandible";
}, {
    readonly code: "618007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Frontal sinusectomy";
}, {
    readonly code: "625000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Removal of supernumerary digit";
}, {
    readonly code: "628003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Steinman test";
}, {
    readonly code: "629006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Lysis of adhesions of urethra";
}, {
    readonly code: "633004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Chart review by physician";
}, {
    readonly code: "637003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Lysis of adhesions of nose";
}, {
    readonly code: "642006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Cerebral thermography";
}, {
    readonly code: "647000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Excision of cervix by electroconization";
}, {
    readonly code: "657004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Operation on bursa";
}, {
    readonly code: "665001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Partial meniscectomy of temporomandibular joint";
}, {
    readonly code: "670008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Electrosurgical epilation of eyebrow";
}, {
    readonly code: "671007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Transplantation of testis";
}, {
    readonly code: "673005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Indirect laryngoscopy";
}, {
    readonly code: "674004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Abduction test";
}, {
    readonly code: "676002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Peritoneal dialysis including cannulation";
}, {
    readonly code: "680007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Radiation physics consultation";
}, {
    readonly code: "687005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Albumin/Globulin ratio";
}, {
    readonly code: "695009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Destructive procedure of lesion on skin of trunk";
}, {
    readonly code: "697001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hepatitis A virus antibody measurement";
}, {
    readonly code: "710006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Thromboendarterectomy with graft of mesenteric artery";
}, {
    readonly code: "712003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Closed chest suction";
}, {
    readonly code: "722009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Fine needle biopsy of thymus";
}, {
    readonly code: "726007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Pathology consultation, comprehensive, records and specimen with report";
}, {
    readonly code: "730005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Incision of subcutaneous tissue";
}, {
    readonly code: "741007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Operation on prostate";
}, {
    readonly code: "746002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Chiropractic adjustment of coccyx subluxation";
}, {
    readonly code: "753006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Manipulation of ankle and foot, NOS";
}, {
    readonly code: "754000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Total urethrectomy";
}, {
    readonly code: "759005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Intracerebral electroencephalogram";
}, {
    readonly code: "762008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Computerized axial tomography of cervical spine with contrast";
}, {
    readonly code: "764009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Arthrodesis of interphalangeal joint of great toe";
}, {
    readonly code: "767002";
    readonly system: "http://snomed.info/sct";
    readonly display: "White blood cell count";
}, {
    readonly code: "789003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Cranial decompression, subtemporal, supratentorial";
}, {
    readonly code: "791006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Dressing and fixation procedure";
}, {
    readonly code: "807005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Excision of brain";
}, {
    readonly code: "814007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Electrophoresis measurement";
}, {
    readonly code: "817000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Excision of cyst of spleen";
}, {
    readonly code: "831000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Drawer test";
}, {
    readonly code: "853003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Fecal fat measurement, 72-hour collection";
}, {
    readonly code: "867007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Facial-hypoglossal nerve anastomosis";
}, {
    readonly code: "870006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Carbamazepine measurement";
}];
/** String type (ValueSet too large for union type) */
export type ProcedureCodesSNOMEDCTCode = string;
/** Type representing a concept from this ValueSet */
export type ProcedureCodesSNOMEDCTConcept = typeof ProcedureCodesSNOMEDCTConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidProcedureCodesSNOMEDCTCode(code: string): code is ProcedureCodesSNOMEDCTCode;
/**
 * Get concept details by code
 */
export declare function getProcedureCodesSNOMEDCTConcept(code: string): ProcedureCodesSNOMEDCTConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ProcedureCodesSNOMEDCTCodes: ("71388002" | "104001" | "115006" | "119000" | "128004" | "133000" | "135007" | "142007" | "146005" | "153001" | "166001" | "170009" | "174000" | "176003" | "189009" | "197002" | "230009" | "243009" | "245002" | "262007" | "267001" | "285008" | "294002" | "295001" | "306005" | "316002" | "334003" | "342002" | "348003" | "351005" | "352003" | "374009" | "388008" | "389000" | "401004" | "406009" | "417005" | "435001" | "445004" | "456004" | "459006" | "463004" | "468008" | "474008" | "489004" | "493005" | "494004" | "497006" | "531007" | "533005" | "535003" | "540006" | "543008" | "545001" | "549007" | "550007" | "559008" | "574005" | "617002" | "618007" | "625000" | "628003" | "629006" | "633004" | "637003" | "642006" | "647000" | "657004" | "665001" | "670008" | "671007" | "673005" | "674004" | "676002" | "680007" | "687005" | "695009" | "697001" | "710006" | "712003" | "722009" | "726007" | "730005" | "741007" | "746002" | "753006" | "754000" | "759005" | "762008" | "764009" | "767002" | "789003" | "791006" | "807005" | "814007" | "817000" | "831000" | "853003" | "867007" | "870006")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomProcedureCodesSNOMEDCTCode(): ProcedureCodesSNOMEDCTCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomProcedureCodesSNOMEDCTConcept(): ProcedureCodesSNOMEDCTConcept;
