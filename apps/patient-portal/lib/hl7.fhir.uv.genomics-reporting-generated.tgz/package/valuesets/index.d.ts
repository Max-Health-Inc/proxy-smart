/**
 * ValueSet Registry
 * Central registry of all loaded ValueSets with explicit codes
 */
import * as BodySite from './ValueSet-BodySite.js';
import * as C80DocTypecodes from './ValueSet-C80DocTypecodes.js';
import * as C80Facilitycodes from './ValueSet-C80Facilitycodes.js';
import * as C80PracticeCodes from './ValueSet-C80PracticeCodes.js';
import * as ClinicalFindings from './ValueSet-ClinicalFindings.js';
import * as CodedAnnotationTypesVS from './ValueSet-CodedAnnotationTypesVS.js';
import * as CompositionStatus from './ValueSet-CompositionStatus.js';
import * as ConditionCode from './ValueSet-ConditionCode.js';
import * as ConditionInheritanceModeVS from './ValueSet-ConditionInheritanceModeVS.js';
import * as DataAbsentReason from './ValueSet-DataAbsentReason.js';
import * as DiagnosticReportStatus from './ValueSet-DiagnosticReportStatus.js';
import * as DiagnosticServiceSections from './ValueSet-DiagnosticServiceSections.js';
import * as DocumentClasscodes from './ValueSet-DocumentClasscodes.js';
import * as DocumentReferenceStatus from './ValueSet-DocumentReferenceStatus.js';
import * as DocumentRelationshipType from './ValueSet-DocumentRelationshipType.js';
import * as EventStatus from './ValueSet-EventStatus.js';
import * as EvidenceLevelExampleVS from './ValueSet-EvidenceLevelExampleVS.js';
import * as GeneticTherapeuticImplicationsVS from './ValueSet-GeneticTherapeuticImplicationsVS.js';
import * as GenomicStudyChangeTypeVS from './ValueSet-GenomicStudyChangeTypeVS.js';
import * as GenomicStudyDataFormatVS from './ValueSet-GenomicStudyDataFormatVS.js';
import * as GenomicStudyMethodTypeVS from './ValueSet-GenomicStudyMethodTypeVS.js';
import * as GenomicStudyStatusVS from './ValueSet-GenomicStudyStatusVS.js';
import * as GenomicStudyTypeVS from './ValueSet-GenomicStudyTypeVS.js';
import * as Languages from './ValueSet-Languages.js';
import * as MolecularBiomarkerCategoryVS from './ValueSet-MolecularBiomarkerCategoryVS.js';
import * as MolecularBiomarkerCodeVS from './ValueSet-MolecularBiomarkerCodeVS.js';
import * as ObservationCategory from './ValueSet-ObservationCategory.js';
import * as ObservationCodes from './ValueSet-ObservationCodes.js';
import * as ObservationInterpretation from './ValueSet-ObservationInterpretation.js';
import * as ObservationMethods from './ValueSet-ObservationMethods.js';
import * as ObservationStatus from './ValueSet-ObservationStatus.js';
import * as ProcedureCategory from './ValueSet-ProcedureCategory.js';
import * as ProcedureFollowup from './ValueSet-ProcedureFollowup.js';
import * as ProcedureOutcome from './ValueSet-ProcedureOutcome.js';
import * as QuantityComparator from './ValueSet-QuantityComparator.js';
import * as ReferencerangeAppliesto from './ValueSet-ReferencerangeAppliesto.js';
import * as ReferencerangeMeaning from './ValueSet-ReferencerangeMeaning.js';
import * as ReportCodes from './ValueSet-ReportCodes.js';
import * as RequestPriority from './ValueSet-RequestPriority.js';
import * as SecurityLabels from './ValueSet-SecurityLabels.js';
import * as SequencePhaseRelationshipVS from './ValueSet-SequencePhaseRelationshipVS.js';
import * as TaskIntent from './ValueSet-TaskIntent.js';
import * as TaskStatus from './ValueSet-TaskStatus.js';
import * as TBDCodesVS from './ValueSet-TBDCodesVS.js';
import * as V3ActCode from './ValueSet-V3ActCode.js';
import * as VariantConfidenceStatusVS from './ValueSet-VariantConfidenceStatusVS.js';
export declare const ValueSetRegistry: {
    readonly BodySite: typeof BodySite;
    readonly C80DocTypecodes: typeof C80DocTypecodes;
    readonly C80Facilitycodes: typeof C80Facilitycodes;
    readonly C80PracticeCodes: typeof C80PracticeCodes;
    readonly ClinicalFindings: typeof ClinicalFindings;
    readonly CodedAnnotationTypesVS: typeof CodedAnnotationTypesVS;
    readonly CompositionStatus: typeof CompositionStatus;
    readonly ConditionCode: typeof ConditionCode;
    readonly ConditionInheritanceModeVS: typeof ConditionInheritanceModeVS;
    readonly DataAbsentReason: typeof DataAbsentReason;
    readonly DiagnosticReportStatus: typeof DiagnosticReportStatus;
    readonly DiagnosticServiceSections: typeof DiagnosticServiceSections;
    readonly DocumentClasscodes: typeof DocumentClasscodes;
    readonly DocumentReferenceStatus: typeof DocumentReferenceStatus;
    readonly DocumentRelationshipType: typeof DocumentRelationshipType;
    readonly EventStatus: typeof EventStatus;
    readonly EvidenceLevelExampleVS: typeof EvidenceLevelExampleVS;
    readonly GeneticTherapeuticImplicationsVS: typeof GeneticTherapeuticImplicationsVS;
    readonly GenomicStudyChangeTypeVS: typeof GenomicStudyChangeTypeVS;
    readonly GenomicStudyDataFormatVS: typeof GenomicStudyDataFormatVS;
    readonly GenomicStudyMethodTypeVS: typeof GenomicStudyMethodTypeVS;
    readonly GenomicStudyStatusVS: typeof GenomicStudyStatusVS;
    readonly GenomicStudyTypeVS: typeof GenomicStudyTypeVS;
    readonly Languages: typeof Languages;
    readonly MolecularBiomarkerCategoryVS: typeof MolecularBiomarkerCategoryVS;
    readonly MolecularBiomarkerCodeVS: typeof MolecularBiomarkerCodeVS;
    readonly ObservationCategory: typeof ObservationCategory;
    readonly ObservationCodes: typeof ObservationCodes;
    readonly ObservationInterpretation: typeof ObservationInterpretation;
    readonly ObservationMethods: typeof ObservationMethods;
    readonly ObservationStatus: typeof ObservationStatus;
    readonly ProcedureCategory: typeof ProcedureCategory;
    readonly ProcedureFollowup: typeof ProcedureFollowup;
    readonly ProcedureOutcome: typeof ProcedureOutcome;
    readonly QuantityComparator: typeof QuantityComparator;
    readonly ReferencerangeAppliesto: typeof ReferencerangeAppliesto;
    readonly ReferencerangeMeaning: typeof ReferencerangeMeaning;
    readonly ReportCodes: typeof ReportCodes;
    readonly RequestPriority: typeof RequestPriority;
    readonly SecurityLabels: typeof SecurityLabels;
    readonly SequencePhaseRelationshipVS: typeof SequencePhaseRelationshipVS;
    readonly TaskIntent: typeof TaskIntent;
    readonly TaskStatus: typeof TaskStatus;
    readonly TBDCodesVS: typeof TBDCodesVS;
    readonly V3ActCode: typeof V3ActCode;
    readonly VariantConfidenceStatusVS: typeof VariantConfidenceStatusVS;
};
export type ValueSetName = keyof typeof ValueSetRegistry;
export declare function getValueSet(name: ValueSetName): typeof BodySite | typeof C80DocTypecodes | typeof C80Facilitycodes | typeof C80PracticeCodes | typeof ClinicalFindings | typeof CodedAnnotationTypesVS | typeof CompositionStatus | typeof ConditionCode | typeof ConditionInheritanceModeVS | typeof DataAbsentReason | typeof DiagnosticReportStatus | typeof DiagnosticServiceSections | typeof DocumentClasscodes | typeof DocumentReferenceStatus | typeof DocumentRelationshipType | typeof EventStatus | typeof EvidenceLevelExampleVS | typeof GeneticTherapeuticImplicationsVS | typeof GenomicStudyChangeTypeVS | typeof GenomicStudyDataFormatVS | typeof GenomicStudyMethodTypeVS | typeof GenomicStudyStatusVS | typeof GenomicStudyTypeVS | typeof Languages | typeof MolecularBiomarkerCategoryVS | typeof MolecularBiomarkerCodeVS | typeof ObservationCategory | typeof ObservationCodes | typeof ObservationInterpretation | typeof ObservationMethods | typeof ObservationStatus | typeof ProcedureCategory | typeof ProcedureFollowup | typeof ProcedureOutcome | typeof QuantityComparator | typeof ReferencerangeAppliesto | typeof ReferencerangeMeaning | typeof ReportCodes | typeof RequestPriority | typeof SecurityLabels | typeof SequencePhaseRelationshipVS | typeof TaskIntent | typeof TaskStatus | typeof TBDCodesVS | typeof V3ActCode | typeof VariantConfidenceStatusVS;
/** Map from ValueSet URL to registry name */
export declare const ValueSetUrlMap: Record<string, ValueSetName>;
/**
 * Get a random code from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A random code string, or undefined if ValueSet not found
 */
export declare function getRandomCodeByUrl(url: string): string | undefined;
/**
 * Get a random concept (code, system, display) from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A concept object with code, system, and optional display, or undefined if ValueSet not found
 */
export declare function getRandomConceptByUrl(url: string): {
    code: string;
    system: string;
    display?: string;
} | undefined;
