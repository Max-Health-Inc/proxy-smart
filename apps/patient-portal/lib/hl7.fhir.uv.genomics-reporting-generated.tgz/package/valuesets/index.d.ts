/**
 * ValueSet Registry
 * Central registry of all loaded ValueSets with explicit codes
 */
import * as BodySite from './ValueSet-BodySite.js';
import * as ClinicalFindings from './ValueSet-ClinicalFindings.js';
import * as CodedAnnotationTypesVS from './ValueSet-CodedAnnotationTypesVS.js';
import * as CompositionStatus from './ValueSet-CompositionStatus.js';
import * as ConditionCode from './ValueSet-ConditionCode.js';
import * as ConditionInheritanceModeVS from './ValueSet-ConditionInheritanceModeVS.js';
import * as DiagnosticReportStatus from './ValueSet-DiagnosticReportStatus.js';
import * as DocumentReferenceStatus from './ValueSet-DocumentReferenceStatus.js';
import * as EventStatus from './ValueSet-EventStatus.js';
import * as EvidenceLevelExampleVS from './ValueSet-EvidenceLevelExampleVS.js';
import * as GeneticTherapeuticImplicationsVS from './ValueSet-GeneticTherapeuticImplicationsVS.js';
import * as GenomicStudyChangeTypeVS from './ValueSet-GenomicStudyChangeTypeVS.js';
import * as GenomicStudyDataFormatVS from './ValueSet-GenomicStudyDataFormatVS.js';
import * as GenomicStudyMethodTypeVS from './ValueSet-GenomicStudyMethodTypeVS.js';
import * as GenomicStudyStatusVS from './ValueSet-GenomicStudyStatusVS.js';
import * as GenomicStudyTypeVS from './ValueSet-GenomicStudyTypeVS.js';
import * as MolecularBiomarkerCategoryVS from './ValueSet-MolecularBiomarkerCategoryVS.js';
import * as MolecularBiomarkerCodeVS from './ValueSet-MolecularBiomarkerCodeVS.js';
import * as ObservationCodes from './ValueSet-ObservationCodes.js';
import * as ObservationMethods from './ValueSet-ObservationMethods.js';
import * as ObservationStatus from './ValueSet-ObservationStatus.js';
import * as QuantityComparator from './ValueSet-QuantityComparator.js';
import * as RequestPriority from './ValueSet-RequestPriority.js';
import * as SequencePhaseRelationshipVS from './ValueSet-SequencePhaseRelationshipVS.js';
import * as TaskStatus from './ValueSet-TaskStatus.js';
import * as TBDCodesVS from './ValueSet-TBDCodesVS.js';
import * as VariantConfidenceStatusVS from './ValueSet-VariantConfidenceStatusVS.js';
export declare const ValueSetRegistry: {
    readonly BodySite: typeof BodySite;
    readonly ClinicalFindings: typeof ClinicalFindings;
    readonly CodedAnnotationTypesVS: typeof CodedAnnotationTypesVS;
    readonly CompositionStatus: typeof CompositionStatus;
    readonly ConditionCode: typeof ConditionCode;
    readonly ConditionInheritanceModeVS: typeof ConditionInheritanceModeVS;
    readonly DiagnosticReportStatus: typeof DiagnosticReportStatus;
    readonly DocumentReferenceStatus: typeof DocumentReferenceStatus;
    readonly EventStatus: typeof EventStatus;
    readonly EvidenceLevelExampleVS: typeof EvidenceLevelExampleVS;
    readonly GeneticTherapeuticImplicationsVS: typeof GeneticTherapeuticImplicationsVS;
    readonly GenomicStudyChangeTypeVS: typeof GenomicStudyChangeTypeVS;
    readonly GenomicStudyDataFormatVS: typeof GenomicStudyDataFormatVS;
    readonly GenomicStudyMethodTypeVS: typeof GenomicStudyMethodTypeVS;
    readonly GenomicStudyStatusVS: typeof GenomicStudyStatusVS;
    readonly GenomicStudyTypeVS: typeof GenomicStudyTypeVS;
    readonly MolecularBiomarkerCategoryVS: typeof MolecularBiomarkerCategoryVS;
    readonly MolecularBiomarkerCodeVS: typeof MolecularBiomarkerCodeVS;
    readonly ObservationCodes: typeof ObservationCodes;
    readonly ObservationMethods: typeof ObservationMethods;
    readonly ObservationStatus: typeof ObservationStatus;
    readonly QuantityComparator: typeof QuantityComparator;
    readonly RequestPriority: typeof RequestPriority;
    readonly SequencePhaseRelationshipVS: typeof SequencePhaseRelationshipVS;
    readonly TaskStatus: typeof TaskStatus;
    readonly TBDCodesVS: typeof TBDCodesVS;
    readonly VariantConfidenceStatusVS: typeof VariantConfidenceStatusVS;
};
export type ValueSetName = keyof typeof ValueSetRegistry;
export declare function getValueSet(name: ValueSetName): typeof BodySite | typeof ClinicalFindings | typeof CodedAnnotationTypesVS | typeof CompositionStatus | typeof ConditionCode | typeof ConditionInheritanceModeVS | typeof DiagnosticReportStatus | typeof DocumentReferenceStatus | typeof EventStatus | typeof EvidenceLevelExampleVS | typeof GeneticTherapeuticImplicationsVS | typeof GenomicStudyChangeTypeVS | typeof GenomicStudyDataFormatVS | typeof GenomicStudyMethodTypeVS | typeof GenomicStudyStatusVS | typeof GenomicStudyTypeVS | typeof MolecularBiomarkerCategoryVS | typeof MolecularBiomarkerCodeVS | typeof ObservationCodes | typeof ObservationMethods | typeof ObservationStatus | typeof QuantityComparator | typeof RequestPriority | typeof SequencePhaseRelationshipVS | typeof TaskStatus | typeof TBDCodesVS | typeof VariantConfidenceStatusVS;
/** Map from ValueSet URL to registry name */
export declare const ValueSetUrlMap: Record<string, ValueSetName>;
/**
 * Get a random code from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A random code string, or undefined if ValueSet not found
 */
export declare function getRandomCodeByUrl(url: string): string | undefined;
/**
 * Get a random concept (code, system, display) from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A concept object with code, system, and optional display, or undefined if ValueSet not found
 */
export declare function getRandomConceptByUrl(url: string): {
    code: string;
    system: string;
    display?: string;
} | undefined;
