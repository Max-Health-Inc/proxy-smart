/**
 * ValueSet Registry
 * Central registry of all loaded ValueSets with explicit codes
 */
import * as AllSecurityLabels from './ValueSet-AllSecurityLabels.js';
import * as BodySite from './ValueSet-BodySite.js';
import * as ClinicalFindings from './ValueSet-ClinicalFindings.js';
import * as CodedAnnotationTypesVS from './ValueSet-CodedAnnotationTypesVS.js';
import * as CommonLanguages from './ValueSet-CommonLanguages.js';
import * as CompositionStatus from './ValueSet-CompositionStatus.js';
import * as ConditionCode from './ValueSet-ConditionCode.js';
import * as ConditionInheritanceModeVS from './ValueSet-ConditionInheritanceModeVS.js';
import * as DataAbsentReason from './ValueSet-DataAbsentReason.js';
import * as DiagnosticReportStatus from './ValueSet-DiagnosticReportStatus.js';
import * as DiagnosticServiceSectionCodes from './ValueSet-DiagnosticServiceSectionCodes.js';
import * as DocumentClassValueSet from './ValueSet-DocumentClassValueSet.js';
import * as DocumentReferenceStatus from './ValueSet-DocumentReferenceStatus.js';
import * as DocumentRelationshipType from './ValueSet-DocumentRelationshipType.js';
import * as DocumentTypeValueSet from './ValueSet-DocumentTypeValueSet.js';
import * as EventStatus from './ValueSet-EventStatus.js';
import * as EvidenceLevelExampleVS from './ValueSet-EvidenceLevelExampleVS.js';
import * as FacilityTypeCodeValueSet from './ValueSet-FacilityTypeCodeValueSet.js';
import * as FHIRDeviceTypes from './ValueSet-FHIRDeviceTypes.js';
import * as GeneticTherapeuticImplicationsVS from './ValueSet-GeneticTherapeuticImplicationsVS.js';
import * as GenomicStudyChangeTypeVS from './ValueSet-GenomicStudyChangeTypeVS.js';
import * as GenomicStudyDataFormatVS from './ValueSet-GenomicStudyDataFormatVS.js';
import * as GenomicStudyMethodTypeVS from './ValueSet-GenomicStudyMethodTypeVS.js';
import * as GenomicStudyStatusVS from './ValueSet-GenomicStudyStatusVS.js';
import * as GenomicStudyTypeVS from './ValueSet-GenomicStudyTypeVS.js';
import * as LL10372 from './ValueSet-LL10372.js';
import * as LL10406 from './ValueSet-LL10406.js';
import * as LL19712 from './ValueSet-LL19712.js';
import * as LL29380 from './ValueSet-LL29380.js';
import * as LL3781 from './ValueSet-LL3781.js';
import * as LL3815 from './ValueSet-LL3815.js';
import * as LL40346 from './ValueSet-LL40346.js';
import * as LL40486 from './ValueSet-LL40486.js';
import * as LL40494 from './ValueSet-LL40494.js';
import * as LL40502 from './ValueSet-LL40502.js';
import * as LL53232 from './ValueSet-LL53232.js';
import * as LL54891 from './ValueSet-LL54891.js';
import * as LOINCDiagnosticReportCodes from './ValueSet-LOINCDiagnosticReportCodes.js';
import * as MolecularBiomarkerCategoryVS from './ValueSet-MolecularBiomarkerCategoryVS.js';
import * as MolecularBiomarkerCodeVS from './ValueSet-MolecularBiomarkerCodeVS.js';
import * as ObservationCategoryCodes from './ValueSet-ObservationCategoryCodes.js';
import * as ObservationCodes from './ValueSet-ObservationCodes.js';
import * as ObservationInterpretationCodes from './ValueSet-ObservationInterpretationCodes.js';
import * as ObservationMethods from './ValueSet-ObservationMethods.js';
import * as ObservationReferenceRangeAppliesToCodes from './ValueSet-ObservationReferenceRangeAppliesToCodes.js';
import * as ObservationReferenceRangeMeaningCodes from './ValueSet-ObservationReferenceRangeMeaningCodes.js';
import * as ObservationStatus from './ValueSet-ObservationStatus.js';
import * as PracticeSettingCodeValueSet from './ValueSet-PracticeSettingCodeValueSet.js';
import * as ProcedureCategoryCodesSNOMEDCT from './ValueSet-ProcedureCategoryCodesSNOMEDCT.js';
import * as ProcedureCodesSNOMEDCT from './ValueSet-ProcedureCodesSNOMEDCT.js';
import * as ProcedureDeviceActionCodes from './ValueSet-ProcedureDeviceActionCodes.js';
import * as ProcedureFollowUpCodesSNOMEDCT from './ValueSet-ProcedureFollowUpCodesSNOMEDCT.js';
import * as ProcedureNotPerformedReasonSNOMEDCT from './ValueSet-ProcedureNotPerformedReasonSNOMEDCT.js';
import * as ProcedureOutcomeCodesSNOMEDCT from './ValueSet-ProcedureOutcomeCodesSNOMEDCT.js';
import * as ProcedurePerformerRoleCodes from './ValueSet-ProcedurePerformerRoleCodes.js';
import * as ProcedureReasonCodes from './ValueSet-ProcedureReasonCodes.js';
import * as QuantityComparator from './ValueSet-QuantityComparator.js';
import * as RequestPriority from './ValueSet-RequestPriority.js';
import * as SequencePhaseRelationshipVS from './ValueSet-SequencePhaseRelationshipVS.js';
import * as TaskIntent from './ValueSet-TaskIntent.js';
import * as TaskStatus from './ValueSet-TaskStatus.js';
import * as TBDCodesVS from './ValueSet-TBDCodesVS.js';
import * as V3ActCode from './ValueSet-V3ActCode.js';
import * as VariantConfidenceStatusVS from './ValueSet-VariantConfidenceStatusVS.js';
export declare const ValueSetRegistry: {
    readonly AllSecurityLabels: typeof AllSecurityLabels;
    readonly BodySite: typeof BodySite;
    readonly ClinicalFindings: typeof ClinicalFindings;
    readonly CodedAnnotationTypesVS: typeof CodedAnnotationTypesVS;
    readonly CommonLanguages: typeof CommonLanguages;
    readonly CompositionStatus: typeof CompositionStatus;
    readonly ConditionCode: typeof ConditionCode;
    readonly ConditionInheritanceModeVS: typeof ConditionInheritanceModeVS;
    readonly DataAbsentReason: typeof DataAbsentReason;
    readonly DiagnosticReportStatus: typeof DiagnosticReportStatus;
    readonly DiagnosticServiceSectionCodes: typeof DiagnosticServiceSectionCodes;
    readonly DocumentClassValueSet: typeof DocumentClassValueSet;
    readonly DocumentReferenceStatus: typeof DocumentReferenceStatus;
    readonly DocumentRelationshipType: typeof DocumentRelationshipType;
    readonly DocumentTypeValueSet: typeof DocumentTypeValueSet;
    readonly EventStatus: typeof EventStatus;
    readonly EvidenceLevelExampleVS: typeof EvidenceLevelExampleVS;
    readonly FacilityTypeCodeValueSet: typeof FacilityTypeCodeValueSet;
    readonly FHIRDeviceTypes: typeof FHIRDeviceTypes;
    readonly GeneticTherapeuticImplicationsVS: typeof GeneticTherapeuticImplicationsVS;
    readonly GenomicStudyChangeTypeVS: typeof GenomicStudyChangeTypeVS;
    readonly GenomicStudyDataFormatVS: typeof GenomicStudyDataFormatVS;
    readonly GenomicStudyMethodTypeVS: typeof GenomicStudyMethodTypeVS;
    readonly GenomicStudyStatusVS: typeof GenomicStudyStatusVS;
    readonly GenomicStudyTypeVS: typeof GenomicStudyTypeVS;
    readonly LL10372: typeof LL10372;
    readonly LL10406: typeof LL10406;
    readonly LL19712: typeof LL19712;
    readonly LL29380: typeof LL29380;
    readonly LL3781: typeof LL3781;
    readonly LL3815: typeof LL3815;
    readonly LL40346: typeof LL40346;
    readonly LL40486: typeof LL40486;
    readonly LL40494: typeof LL40494;
    readonly LL40502: typeof LL40502;
    readonly LL53232: typeof LL53232;
    readonly LL54891: typeof LL54891;
    readonly LOINCDiagnosticReportCodes: typeof LOINCDiagnosticReportCodes;
    readonly MolecularBiomarkerCategoryVS: typeof MolecularBiomarkerCategoryVS;
    readonly MolecularBiomarkerCodeVS: typeof MolecularBiomarkerCodeVS;
    readonly ObservationCategoryCodes: typeof ObservationCategoryCodes;
    readonly ObservationCodes: typeof ObservationCodes;
    readonly ObservationInterpretationCodes: typeof ObservationInterpretationCodes;
    readonly ObservationMethods: typeof ObservationMethods;
    readonly ObservationReferenceRangeAppliesToCodes: typeof ObservationReferenceRangeAppliesToCodes;
    readonly ObservationReferenceRangeMeaningCodes: typeof ObservationReferenceRangeMeaningCodes;
    readonly ObservationStatus: typeof ObservationStatus;
    readonly PracticeSettingCodeValueSet: typeof PracticeSettingCodeValueSet;
    readonly ProcedureCategoryCodesSNOMEDCT: typeof ProcedureCategoryCodesSNOMEDCT;
    readonly ProcedureCodesSNOMEDCT: typeof ProcedureCodesSNOMEDCT;
    readonly ProcedureDeviceActionCodes: typeof ProcedureDeviceActionCodes;
    readonly ProcedureFollowUpCodesSNOMEDCT: typeof ProcedureFollowUpCodesSNOMEDCT;
    readonly ProcedureNotPerformedReasonSNOMEDCT: typeof ProcedureNotPerformedReasonSNOMEDCT;
    readonly ProcedureOutcomeCodesSNOMEDCT: typeof ProcedureOutcomeCodesSNOMEDCT;
    readonly ProcedurePerformerRoleCodes: typeof ProcedurePerformerRoleCodes;
    readonly ProcedureReasonCodes: typeof ProcedureReasonCodes;
    readonly QuantityComparator: typeof QuantityComparator;
    readonly RequestPriority: typeof RequestPriority;
    readonly SequencePhaseRelationshipVS: typeof SequencePhaseRelationshipVS;
    readonly TaskIntent: typeof TaskIntent;
    readonly TaskStatus: typeof TaskStatus;
    readonly TBDCodesVS: typeof TBDCodesVS;
    readonly V3ActCode: typeof V3ActCode;
    readonly VariantConfidenceStatusVS: typeof VariantConfidenceStatusVS;
};
export type ValueSetName = keyof typeof ValueSetRegistry;
export declare function getValueSet(name: ValueSetName): typeof AllSecurityLabels | typeof BodySite | typeof ClinicalFindings | typeof CodedAnnotationTypesVS | typeof CommonLanguages | typeof CompositionStatus | typeof ConditionCode | typeof ConditionInheritanceModeVS | typeof DataAbsentReason | typeof DiagnosticReportStatus | typeof DiagnosticServiceSectionCodes | typeof DocumentClassValueSet | typeof DocumentReferenceStatus | typeof DocumentRelationshipType | typeof DocumentTypeValueSet | typeof EventStatus | typeof EvidenceLevelExampleVS | typeof FacilityTypeCodeValueSet | typeof FHIRDeviceTypes | typeof GeneticTherapeuticImplicationsVS | typeof GenomicStudyChangeTypeVS | typeof GenomicStudyDataFormatVS | typeof GenomicStudyMethodTypeVS | typeof GenomicStudyStatusVS | typeof GenomicStudyTypeVS | typeof LL10372 | typeof LL10406 | typeof LL19712 | typeof LL29380 | typeof LL3781 | typeof LL3815 | typeof LL40346 | typeof LL40486 | typeof LL40494 | typeof LL40502 | typeof LL53232 | typeof LL54891 | typeof LOINCDiagnosticReportCodes | typeof MolecularBiomarkerCategoryVS | typeof MolecularBiomarkerCodeVS | typeof ObservationCategoryCodes | typeof ObservationCodes | typeof ObservationInterpretationCodes | typeof ObservationMethods | typeof ObservationReferenceRangeAppliesToCodes | typeof ObservationReferenceRangeMeaningCodes | typeof ObservationStatus | typeof PracticeSettingCodeValueSet | typeof ProcedureCategoryCodesSNOMEDCT | typeof ProcedureCodesSNOMEDCT | typeof ProcedureDeviceActionCodes | typeof ProcedureFollowUpCodesSNOMEDCT | typeof ProcedureNotPerformedReasonSNOMEDCT | typeof ProcedureOutcomeCodesSNOMEDCT | typeof ProcedurePerformerRoleCodes | typeof ProcedureReasonCodes | typeof QuantityComparator | typeof RequestPriority | typeof SequencePhaseRelationshipVS | typeof TaskIntent | typeof TaskStatus | typeof TBDCodesVS | typeof V3ActCode | typeof VariantConfidenceStatusVS;
/** Map from ValueSet URL to registry name */
export declare const ValueSetUrlMap: Record<string, ValueSetName>;
/**
 * Get a random code from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A random code string, or undefined if ValueSet not found
 */
export declare function getRandomCodeByUrl(url: string): string | undefined;
/**
 * Get a random concept (code, system, display) from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A concept object with code, system, and optional display, or undefined if ValueSet not found
 */
export declare function getRandomConceptByUrl(url: string): {
    code: string;
    system: string;
    display?: string;
} | undefined;
