/**
 * ValueSet: LL1040-6
 * URL: http://loinc.org/vs/LL1040-6
 * Size: 5 concepts
 */
export declare const LL10406Concepts: readonly [{
    readonly code: "LA14032-9";
    readonly system: "http://loinc.org";
    readonly display: "NCBI Build 34";
}, {
    readonly code: "LA14029-5";
    readonly system: "http://loinc.org";
    readonly display: "GRCh37";
}, {
    readonly code: "LA14030-3";
    readonly system: "http://loinc.org";
    readonly display: "NCBI Build 36.1";
}, {
    readonly code: "LA14031-1";
    readonly system: "http://loinc.org";
    readonly display: "NCBI Build 35";
}, {
    readonly code: "LA26806-2";
    readonly system: "http://loinc.org";
    readonly display: "GRCh38";
}];
/** Union type of all valid codes in this ValueSet */
export type LL10406Code = "LA14032-9" | "LA14029-5" | "LA14030-3" | "LA14031-1" | "LA26806-2";
/** Type representing a concept from this ValueSet */
export type LL10406Concept = typeof LL10406Concepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidLL10406Code(code: string): code is LL10406Code;
/**
 * Get concept details by code
 */
export declare function getLL10406Concept(code: string): LL10406Concept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const LL10406Codes: ("LA14032-9" | "LA14029-5" | "LA14030-3" | "LA14031-1" | "LA26806-2")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomLL10406Code(): LL10406Code;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomLL10406Concept(): LL10406Concept;
