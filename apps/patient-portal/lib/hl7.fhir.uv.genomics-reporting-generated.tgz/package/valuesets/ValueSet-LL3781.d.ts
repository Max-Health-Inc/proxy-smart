/**
 * ValueSet: LL378-1
 * URL: http://loinc.org/vs/LL378-1
 * Size: 8 concepts
 */
export declare const LL3781Concepts: readonly [{
    readonly code: "LA6683-2";
    readonly system: "http://loinc.org";
    readonly display: "Germline";
}, {
    readonly code: "LA6684-0";
    readonly system: "http://loinc.org";
    readonly display: "Somatic";
}, {
    readonly code: "LA10429-1";
    readonly system: "http://loinc.org";
    readonly display: "Fetal";
}, {
    readonly code: "LA18194-3";
    readonly system: "http://loinc.org";
    readonly display: "Likely germline";
}, {
    readonly code: "LA18195-0";
    readonly system: "http://loinc.org";
    readonly display: "Likely somatic";
}, {
    readonly code: "LA18196-8";
    readonly system: "http://loinc.org";
    readonly display: "Likely fetal";
}, {
    readonly code: "LA18197-6";
    readonly system: "http://loinc.org";
    readonly display: "Unknown genomic origin";
}, {
    readonly code: "LA26807-0";
    readonly system: "http://loinc.org";
    readonly display: "De novo";
}];
/** Union type of all valid codes in this ValueSet */
export type LL3781Code = "LA6683-2" | "LA6684-0" | "LA10429-1" | "LA18194-3" | "LA18195-0" | "LA18196-8" | "LA18197-6" | "LA26807-0";
/** Type representing a concept from this ValueSet */
export type LL3781Concept = typeof LL3781Concepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidLL3781Code(code: string): code is LL3781Code;
/**
 * Get concept details by code
 */
export declare function getLL3781Concept(code: string): LL3781Concept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const LL3781Codes: ("LA6683-2" | "LA6684-0" | "LA10429-1" | "LA18194-3" | "LA18195-0" | "LA18196-8" | "LA18197-6" | "LA26807-0")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomLL3781Code(): LL3781Code;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomLL3781Concept(): LL3781Concept;
