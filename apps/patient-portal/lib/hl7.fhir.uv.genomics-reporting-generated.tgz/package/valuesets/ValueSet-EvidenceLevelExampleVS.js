/**
 * ValueSet: EvidenceLevelExampleVS
 * URL: http://hl7.org/fhir/uv/genomics-reporting/ValueSet/evidence-level-example-vs
 * Size: 11 concepts
 */
export const EvidenceLevelExampleVSConcepts = [
    { code: "4-star", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/clinvar-evidence-level-custom-cs" },
    { code: "3-star", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/clinvar-evidence-level-custom-cs" },
    { code: "2-star", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/clinvar-evidence-level-custom-cs" },
    { code: "1-star", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/clinvar-evidence-level-custom-cs" },
    { code: "no-star", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/clinvar-evidence-level-custom-cs" },
    { code: "1A", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/pharmgkb-evidence-level-custom-cs" },
    { code: "1B", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/pharmgkb-evidence-level-custom-cs" },
    { code: "2A", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/pharmgkb-evidence-level-custom-cs" },
    { code: "2B", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/pharmgkb-evidence-level-custom-cs" },
    { code: "3", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/pharmgkb-evidence-level-custom-cs" },
    { code: "4", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/pharmgkb-evidence-level-custom-cs" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidEvidenceLevelExampleVSCode(code) {
    return EvidenceLevelExampleVSConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getEvidenceLevelExampleVSConcept(code) {
    return EvidenceLevelExampleVSConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const EvidenceLevelExampleVSCodes = EvidenceLevelExampleVSConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomEvidenceLevelExampleVSCode() {
    return EvidenceLevelExampleVSCodes[Math.floor(Math.random() * EvidenceLevelExampleVSCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomEvidenceLevelExampleVSConcept() {
    return EvidenceLevelExampleVSConcepts[Math.floor(Math.random() * EvidenceLevelExampleVSConcepts.length)];
}
