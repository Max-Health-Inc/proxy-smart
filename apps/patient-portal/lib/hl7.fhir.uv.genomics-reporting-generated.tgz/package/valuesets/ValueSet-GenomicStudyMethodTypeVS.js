/**
 * ValueSet: GenomicStudyMethodTypeVS
 * URL: http://hl7.org/fhir/uv/genomics-reporting/ValueSet/genomic-study-method-type-vs
 * Size: 81 concepts
 */
export const GenomicStudyMethodTypeVSConcepts = [
    { code: "biochemical-genetics", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "cytogenetics", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "molecular-genetics", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "analyte", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "chromosome-breakage-studies", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "deletion-duplication-analysis", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "detection-of-homozygosity", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "enzyme-assay", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "fish-interphase", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "fish-metaphase", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "flow-cytometry", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "fish", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "immunohistochemistry", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "karyotyping", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "linkage-analysis", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "methylation-analysis", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "msi", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "m-fish", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "mutation-scanning-of-select-exons", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "mutation-scanning-of-the-entire-coding-region", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "protein-analysis", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "protein-expression", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "rna-analysis", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "sequence-analysis-of-select-exons", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "sequence-analysis-of-the-entire-coding-region", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "sister-chromatid-exchange", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "targeted-variant-analysis", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "udp", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "aspe", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "alternative-splicing-detection", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "bi-directional-sanger-sequence-analysis", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "c-banding", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "cia", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "chromatin-immunoprecipitation-on-chip", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "comparative-genomic-hybridization", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "damid", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "digital-virtual-karyotyping", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "digital-microfluidic-microspheres", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "enzymatic-levels", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "enzyme-activity", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "elisa", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "fluorometry", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "fusion-genes-microarrays", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "g-banding", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "gc-ms", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "gene-expression-profiling", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "gene-id", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "gold-nanoparticle-probe-technology", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "hplc", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "lc-ms", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "lc-ms-ms", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "metabolite-levels", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "methylation-specific-pcr", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "microarray", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "mlpa", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "ngs-mps", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "ola", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "oligonucleotide-hybridization-based-dna-sequencing", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "other", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "pcr", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "pcr-with-allele-specific-hybridization", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "pcr-rflp-with-southern-hybridization", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "protein-truncation-test", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "pyrosequencing", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "q-banding", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "qpcr", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "r-banding", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "rflp", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "rt-lamp", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "rt-pcr", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "rt-pcr-with-gel-analysis", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "rt-qpcr", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "snp-detection", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "silver-staining", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "sky", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "t-banding", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "ms-ms", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "tetra-nucleotide-repeat-by-pcr-or-southern-blot", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "tiling-arrays", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "trinucleotide-repeat-by-pcr-or-southern-blot", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
    { code: "uni-directional-sanger-sequencing", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidGenomicStudyMethodTypeVSCode(code) {
    return GenomicStudyMethodTypeVSConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getGenomicStudyMethodTypeVSConcept(code) {
    return GenomicStudyMethodTypeVSConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const GenomicStudyMethodTypeVSCodes = GenomicStudyMethodTypeVSConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomGenomicStudyMethodTypeVSCode() {
    return GenomicStudyMethodTypeVSCodes[Math.floor(Math.random() * GenomicStudyMethodTypeVSCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomGenomicStudyMethodTypeVSConcept() {
    return GenomicStudyMethodTypeVSConcepts[Math.floor(Math.random() * GenomicStudyMethodTypeVSConcepts.length)];
}
