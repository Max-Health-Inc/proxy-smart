/**
 * ValueSet: LL2938-0
 * URL: http://loinc.org/vs/LL2938-0
 * Size: 24 concepts
 */
export const LL29380Concepts = [
    { code: "LA21254-0", system: "http://loinc.org", display: "Chromosome 1" },
    { code: "LA21255-7", system: "http://loinc.org", display: "Chromosome 2" },
    { code: "LA21256-5", system: "http://loinc.org", display: "Chromosome 3" },
    { code: "LA21257-3", system: "http://loinc.org", display: "Chromosome 4" },
    { code: "LA21258-1", system: "http://loinc.org", display: "Chromosome 5" },
    { code: "LA21259-9", system: "http://loinc.org", display: "Chromosome 6" },
    { code: "LA21260-7", system: "http://loinc.org", display: "Chromosome 7" },
    { code: "LA21261-5", system: "http://loinc.org", display: "Chromosome 8" },
    { code: "LA21262-3", system: "http://loinc.org", display: "Chromosome 9" },
    { code: "LA21263-1", system: "http://loinc.org", display: "Chromosome 10" },
    { code: "LA21264-9", system: "http://loinc.org", display: "Chromosome 11" },
    { code: "LA21265-6", system: "http://loinc.org", display: "Chromosome 12" },
    { code: "LA21266-4", system: "http://loinc.org", display: "Chromosome 13" },
    { code: "LA21267-2", system: "http://loinc.org", display: "Chromosome 14" },
    { code: "LA21268-0", system: "http://loinc.org", display: "Chromosome 15" },
    { code: "LA21269-8", system: "http://loinc.org", display: "Chromosome 16" },
    { code: "LA21270-6", system: "http://loinc.org", display: "Chromosome 17" },
    { code: "LA21271-4", system: "http://loinc.org", display: "Chromosome 18" },
    { code: "LA21272-2", system: "http://loinc.org", display: "Chromosome 19" },
    { code: "LA21273-0", system: "http://loinc.org", display: "Chromosome 20" },
    { code: "LA21274-8", system: "http://loinc.org", display: "Chromosome 21" },
    { code: "LA21275-5", system: "http://loinc.org", display: "Chromosome 22" },
    { code: "LA21276-3", system: "http://loinc.org", display: "Chromosome X" },
    { code: "LA21277-1", system: "http://loinc.org", display: "Chromosome Y" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidLL29380Code(code) {
    return LL29380Concepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getLL29380Concept(code) {
    return LL29380Concepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const LL29380Codes = LL29380Concepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomLL29380Code() {
    return LL29380Codes[Math.floor(Math.random() * LL29380Codes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomLL29380Concept() {
    return LL29380Concepts[Math.floor(Math.random() * LL29380Concepts.length)];
}
