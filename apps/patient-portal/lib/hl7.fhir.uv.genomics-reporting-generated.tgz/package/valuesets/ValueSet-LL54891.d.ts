/**
 * ValueSet: LL5489-1
 * URL: http://loinc.org/vs/LL5489-1
 * Size: 5 concepts
 */
export declare const LL54891Concepts: readonly [{
    readonly code: "LA26320-4";
    readonly system: "http://loinc.org";
    readonly display: "Maternal";
}, {
    readonly code: "LA26321-2";
    readonly system: "http://loinc.org";
    readonly display: "Paternal";
}, {
    readonly code: "LA26807-0";
    readonly system: "http://loinc.org";
    readonly display: "De novo";
}, {
    readonly code: "LA4489-6";
    readonly system: "http://loinc.org";
    readonly display: "Unknown";
}, {
    readonly code: "LA30680-5";
    readonly system: "http://loinc.org";
    readonly display: "Parental";
}];
/** Union type of all valid codes in this ValueSet */
export type LL54891Code = "LA26320-4" | "LA26321-2" | "LA26807-0" | "LA4489-6" | "LA30680-5";
/** Type representing a concept from this ValueSet */
export type LL54891Concept = typeof LL54891Concepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidLL54891Code(code: string): code is LL54891Code;
/**
 * Get concept details by code
 */
export declare function getLL54891Concept(code: string): LL54891Concept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const LL54891Codes: ("LA26807-0" | "LA26320-4" | "LA26321-2" | "LA4489-6" | "LA30680-5")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomLL54891Code(): LL54891Code;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomLL54891Concept(): LL54891Concept;
