/**
 * ValueSet: GenomicStudyTypeVS
 * URL: http://hl7.org/fhir/uv/genomics-reporting/ValueSet/genomic-study-type-vs
 * Size: 12 concepts
 */
export const GenomicStudyTypeVSConcepts = [
    { code: "alt-splc", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-type-cs" },
    { code: "chromatin", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-type-cs" },
    { code: "cnv", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-type-cs" },
    { code: "epi-alt-hist", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-type-cs" },
    { code: "epi-alt-dna", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-type-cs" },
    { code: "fam-var-segr", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-type-cs" },
    { code: "func-var", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-type-cs" },
    { code: "gene-expression", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-type-cs" },
    { code: "post-trans-mod", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-type-cs" },
    { code: "snp", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-type-cs" },
    { code: "str", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-type-cs" },
    { code: "struc-var", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-type-cs" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidGenomicStudyTypeVSCode(code) {
    return GenomicStudyTypeVSConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getGenomicStudyTypeVSConcept(code) {
    return GenomicStudyTypeVSConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const GenomicStudyTypeVSCodes = GenomicStudyTypeVSConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomGenomicStudyTypeVSCode() {
    return GenomicStudyTypeVSCodes[Math.floor(Math.random() * GenomicStudyTypeVSCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomGenomicStudyTypeVSConcept() {
    return GenomicStudyTypeVSConcepts[Math.floor(Math.random() * GenomicStudyTypeVSConcepts.length)];
}
