/**
 * ValueSet: referencerange-appliesto
 * URL: http://hl7.org/fhir/ValueSet/referencerange-appliesto
 * Size: 3 concepts
 */
export declare const ReferencerangeAppliestoConcepts: readonly [{
    readonly code: "248153007";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "248152002";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "77386006";
    readonly system: "http://snomed.info/sct";
}];
/** Union type of all valid codes in this ValueSet */
export type ReferencerangeAppliestoCode = "248153007" | "248152002" | "77386006";
/** Type representing a concept from this ValueSet */
export type ReferencerangeAppliestoConcept = typeof ReferencerangeAppliestoConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidReferencerangeAppliestoCode(code: string): code is ReferencerangeAppliestoCode;
/**
 * Get concept details by code
 */
export declare function getReferencerangeAppliestoConcept(code: string): ReferencerangeAppliestoConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ReferencerangeAppliestoCodes: ("77386006" | "248153007" | "248152002")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomReferencerangeAppliestoCode(): ReferencerangeAppliestoCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomReferencerangeAppliestoConcept(): ReferencerangeAppliestoConcept;
