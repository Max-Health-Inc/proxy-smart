/**
 * ValueSet: LL5489-1
 * URL: http://loinc.org/vs/LL5489-1
 * Size: 5 concepts
 */
export const LL54891Concepts = [
    { code: "LA26320-4", system: "http://loinc.org", display: "Maternal" },
    { code: "LA26321-2", system: "http://loinc.org", display: "Paternal" },
    { code: "LA26807-0", system: "http://loinc.org", display: "De novo" },
    { code: "LA4489-6", system: "http://loinc.org", display: "Unknown" },
    { code: "LA30680-5", system: "http://loinc.org", display: "Parental" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidLL54891Code(code) {
    return LL54891Concepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getLL54891Concept(code) {
    return LL54891Concepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const LL54891Codes = LL54891Concepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomLL54891Code() {
    return LL54891Codes[Math.floor(Math.random() * LL54891Codes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomLL54891Concept() {
    return LL54891Concepts[Math.floor(Math.random() * LL54891Concepts.length)];
}
