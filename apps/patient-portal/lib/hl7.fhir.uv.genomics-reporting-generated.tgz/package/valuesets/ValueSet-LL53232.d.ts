/**
 * ValueSet: LL5323-2
 * URL: http://loinc.org/vs/LL5323-2
 * Size: 3 concepts
 */
export declare const LL53232Concepts: readonly [{
    readonly code: "LA30100-4";
    readonly system: "http://loinc.org";
    readonly display: "0-based interval counting";
}, {
    readonly code: "LA30101-2";
    readonly system: "http://loinc.org";
    readonly display: "0-based character counting";
}, {
    readonly code: "LA30102-0";
    readonly system: "http://loinc.org";
    readonly display: "1-based character counting";
}];
/** Union type of all valid codes in this ValueSet */
export type LL53232Code = "LA30100-4" | "LA30101-2" | "LA30102-0";
/** Type representing a concept from this ValueSet */
export type LL53232Concept = typeof LL53232Concepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidLL53232Code(code: string): code is LL53232Code;
/**
 * Get concept details by code
 */
export declare function getLL53232Concept(code: string): LL53232Concept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const LL53232Codes: ("LA30100-4" | "LA30101-2" | "LA30102-0")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomLL53232Code(): LL53232Code;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomLL53232Concept(): LL53232Concept;
