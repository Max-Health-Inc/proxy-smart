/**
 * ValueSet: GenomicStudyChangeTypeVS
 * URL: http://hl7.org/fhir/uv/genomics-reporting/ValueSet/genomic-study-change-type-vs
 * Size: 5 concepts
 */
export declare const GenomicStudyChangeTypeVSConcepts: readonly [{
    readonly code: "DNA";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-change-type-cs";
}, {
    readonly code: "RNA";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-change-type-cs";
}, {
    readonly code: "AA";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-change-type-cs";
}, {
    readonly code: "CHR";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-change-type-cs";
}, {
    readonly code: "CNV";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-change-type-cs";
}];
/** Union type of all valid codes in this ValueSet */
export type GenomicStudyChangeTypeVSCode = "DNA" | "RNA" | "AA" | "CHR" | "CNV";
/** Type representing a concept from this ValueSet */
export type GenomicStudyChangeTypeVSConcept = typeof GenomicStudyChangeTypeVSConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidGenomicStudyChangeTypeVSCode(code: string): code is GenomicStudyChangeTypeVSCode;
/**
 * Get concept details by code
 */
export declare function getGenomicStudyChangeTypeVSConcept(code: string): GenomicStudyChangeTypeVSConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const GenomicStudyChangeTypeVSCodes: ("DNA" | "RNA" | "AA" | "CHR" | "CNV")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomGenomicStudyChangeTypeVSCode(): GenomicStudyChangeTypeVSCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomGenomicStudyChangeTypeVSConcept(): GenomicStudyChangeTypeVSConcept;
