/**
 * ValueSet: CodedAnnotationTypesVS
 * URL: http://hl7.org/fhir/uv/genomics-reporting/ValueSet/coded-annotation-types-vs
 * Size: 3 concepts
 */
export const CodedAnnotationTypesVSConcepts = [
    { code: "test-disclaimer", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/coded-annotation-types-cs" },
    { code: "test-methodology", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/coded-annotation-types-cs" },
    { code: "result-confirmation", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/coded-annotation-types-cs" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidCodedAnnotationTypesVSCode(code) {
    return CodedAnnotationTypesVSConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getCodedAnnotationTypesVSConcept(code) {
    return CodedAnnotationTypesVSConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const CodedAnnotationTypesVSCodes = CodedAnnotationTypesVSConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomCodedAnnotationTypesVSCode() {
    return CodedAnnotationTypesVSCodes[Math.floor(Math.random() * CodedAnnotationTypesVSCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomCodedAnnotationTypesVSConcept() {
    return CodedAnnotationTypesVSConcepts[Math.floor(Math.random() * CodedAnnotationTypesVSConcepts.length)];
}
