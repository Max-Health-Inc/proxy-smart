/**
 * ValueSet: MolecularBiomarkerCodeVS
 * URL: http://hl7.org/fhir/uv/genomics-reporting/ValueSet/molecular-biomarker-code-vs
 * Size: 17 concepts
 */
export const MolecularBiomarkerCodeVSConcepts = [
    { code: "85337-4", system: "http://loinc.org", display: "Estrogen receptor Ag Immune stain Ql (Breast cancer specimen)" },
    { code: "72382-5", system: "http://loinc.org", display: "HER2 IA Qn (Tiss)" },
    { code: "77637-7", system: "http://loinc.org", display: "HLA-A and B and C (class I) IgG panel IA [Identifier]" },
    { code: "40557-1", system: "http://loinc.org", display: "Progesterone receptor Ag Immune stain Ql (Tiss)" },
    { code: "85147-7", system: "http://loinc.org", display: "PD-L1 by clone 22C3 Immune stain Doc (Tiss)" },
    { code: "59025-7", system: "http://loinc.org", display: "Neutrophil Ab FC Qn (S)" },
    { code: "59003-4", system: "http://loinc.org", display: "Lactoferrin Ab IA Qn (S)" },
    { code: "10495-0", system: "http://loinc.org", display: "Insulin Ag Immune stain Ql (Tiss)" },
    { code: "16550-6", system: "http://loinc.org", display: "Carbohydrates Nom (U)" },
    { code: "2569-2", system: "http://loinc.org", display: "Lipids (S) [Mass/Vol]" },
    { code: "4551-8", system: "http://loinc.org", display: "Hemoglobin A2 (Bld) [Mass fraction]" },
    { code: "19195-7", system: "http://loinc.org", display: "Prostate specific Ag Qn" },
    { code: "64083-9", system: "http://loinc.org", display: "MGMT gene methylation score Molgen (Tiss) [Ratio]" },
    { code: "62862-8", system: "http://loinc.org", display: "Microsatellite instability Immune stain Ql (Tiss)" },
    { code: "81704-9", system: "http://loinc.org", display: "Microsatellite instability marker D17S250 Ql (Cancer specimen)" },
    { code: "94077-5", system: "http://loinc.org", display: "Tumor mutation burden Ql (Tumor) [Interp]" },
    { code: "C120465", system: "http://ncicb.nci.nih.gov/xml/owl/EVS/Thesaurus.owl", display: "Homologous Recombination Repair Deficiency" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidMolecularBiomarkerCodeVSCode(code) {
    return MolecularBiomarkerCodeVSConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getMolecularBiomarkerCodeVSConcept(code) {
    return MolecularBiomarkerCodeVSConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const MolecularBiomarkerCodeVSCodes = MolecularBiomarkerCodeVSConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomMolecularBiomarkerCodeVSCode() {
    return MolecularBiomarkerCodeVSCodes[Math.floor(Math.random() * MolecularBiomarkerCodeVSCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomMolecularBiomarkerCodeVSConcept() {
    return MolecularBiomarkerCodeVSConcepts[Math.floor(Math.random() * MolecularBiomarkerCodeVSConcepts.length)];
}
