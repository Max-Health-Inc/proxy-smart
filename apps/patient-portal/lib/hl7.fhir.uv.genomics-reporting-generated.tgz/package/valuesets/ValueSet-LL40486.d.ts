/**
 * ValueSet: LL4048-6
 * URL: http://loinc.org/vs/LL4048-6
 * Size: 23 concepts
 */
export declare const LL40486Concepts: readonly [{
    readonly code: "LA26398-0";
    readonly system: "http://loinc.org";
    readonly display: "Sequencing";
}, {
    readonly code: "LA26399-8";
    readonly system: "http://loinc.org";
    readonly display: "Oligo aCGH";
}, {
    readonly code: "LA26400-4";
    readonly system: "http://loinc.org";
    readonly display: "SNP array";
}, {
    readonly code: "LA26401-2";
    readonly system: "http://loinc.org";
    readonly display: "BAC aCGH";
}, {
    readonly code: "LA26402-0";
    readonly system: "http://loinc.org";
    readonly display: "Curated";
}, {
    readonly code: "LA26403-8";
    readonly system: "http://loinc.org";
    readonly display: "Digital array";
}, {
    readonly code: "LA26404-6";
    readonly system: "http://loinc.org";
    readonly display: "FISH";
}, {
    readonly code: "LA26405-3";
    readonly system: "http://loinc.org";
    readonly display: "Gene expression array";
}, {
    readonly code: "LA26406-1";
    readonly system: "http://loinc.org";
    readonly display: "Karyotyping";
}, {
    readonly code: "LA26407-9";
    readonly system: "http://loinc.org";
    readonly display: "MAPH";
}, {
    readonly code: "LA26408-7";
    readonly system: "http://loinc.org";
    readonly display: "MALDI-TOF";
}, {
    readonly code: "LA26808-8";
    readonly system: "http://loinc.org";
    readonly display: "Merging";
}, {
    readonly code: "LA26414-5";
    readonly system: "http://loinc.org";
    readonly display: "Multiple complete digestion";
}, {
    readonly code: "LA26415-2";
    readonly system: "http://loinc.org";
    readonly display: "MLPA";
}, {
    readonly code: "LA26417-8";
    readonly system: "http://loinc.org";
    readonly display: "Optical mapping";
}, {
    readonly code: "LA26418-6";
    readonly system: "http://loinc.org";
    readonly display: "PCR";
}, {
    readonly code: "LA26419-4";
    readonly system: "http://loinc.org";
    readonly display: "qPCR (real-time PCR)";
}, {
    readonly code: "LA26420-2";
    readonly system: "http://loinc.org";
    readonly display: "ROMA";
}, {
    readonly code: "LA26809-6";
    readonly system: "http://loinc.org";
    readonly display: "Denaturing high-pressure liquid chromatography (DHPLC)";
}, {
    readonly code: "LA26810-4";
    readonly system: "http://loinc.org";
    readonly display: "DNA hybridization";
}, {
    readonly code: "LA26811-2";
    readonly system: "http://loinc.org";
    readonly display: "Computational analysis";
}, {
    readonly code: "LA26812-0";
    readonly system: "http://loinc.org";
    readonly display: "Single-stranded conformational polymorphism (SSCP)";
}, {
    readonly code: "LA26813-8";
    readonly system: "http://loinc.org";
    readonly display: "Restriction fragment length polymorphism (RFLP)";
}];
/** String type (ValueSet too large for union type) */
export type LL40486Code = string;
/** Type representing a concept from this ValueSet */
export type LL40486Concept = typeof LL40486Concepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidLL40486Code(code: string): code is LL40486Code;
/**
 * Get concept details by code
 */
export declare function getLL40486Concept(code: string): LL40486Concept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const LL40486Codes: ("LA26398-0" | "LA26399-8" | "LA26400-4" | "LA26401-2" | "LA26402-0" | "LA26403-8" | "LA26404-6" | "LA26405-3" | "LA26406-1" | "LA26407-9" | "LA26408-7" | "LA26808-8" | "LA26414-5" | "LA26415-2" | "LA26417-8" | "LA26418-6" | "LA26419-4" | "LA26420-2" | "LA26809-6" | "LA26810-4" | "LA26811-2" | "LA26812-0" | "LA26813-8")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomLL40486Code(): LL40486Code;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomLL40486Concept(): LL40486Concept;
