/**
 * ValueSet: ObservationReferenceRangeAppliesToCodes
 * URL: http://hl7.org/fhir/ValueSet/referencerange-appliesto
 * Size: 3 concepts
 */
export declare const ObservationReferenceRangeAppliesToCodesConcepts: readonly [{
    readonly code: "248153007";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "248152002";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "77386006";
    readonly system: "http://snomed.info/sct";
}];
/** Union type of all valid codes in this ValueSet */
export type ObservationReferenceRangeAppliesToCodesCode = "248153007" | "248152002" | "77386006";
/** Type representing a concept from this ValueSet */
export type ObservationReferenceRangeAppliesToCodesConcept = typeof ObservationReferenceRangeAppliesToCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidObservationReferenceRangeAppliesToCodesCode(code: string): code is ObservationReferenceRangeAppliesToCodesCode;
/**
 * Get concept details by code
 */
export declare function getObservationReferenceRangeAppliesToCodesConcept(code: string): ObservationReferenceRangeAppliesToCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ObservationReferenceRangeAppliesToCodesCodes: ("77386006" | "248153007" | "248152002")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomObservationReferenceRangeAppliesToCodesCode(): ObservationReferenceRangeAppliesToCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomObservationReferenceRangeAppliesToCodesConcept(): ObservationReferenceRangeAppliesToCodesConcept;
