/**
 * ValueSet: DocumentTypeValueSet
 * URL: http://hl7.org/fhir/ValueSet/c80-doc-typecodes
 * Size: 6401 concepts
 */
interface DocumentTypeValueSetConceptDef {
    readonly code: string;
    readonly system: string;
    readonly display?: string;
}
export declare const DocumentTypeValueSetConcepts: readonly DocumentTypeValueSetConceptDef[];
/** String type (ValueSet too large for union type) */
export type DocumentTypeValueSetCode = string;
/** Type representing a concept from this ValueSet */
export type DocumentTypeValueSetConcept = DocumentTypeValueSetConceptDef;
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidDocumentTypeValueSetCode(code: string): code is DocumentTypeValueSetCode;
/**
 * Get concept details by code
 */
export declare function getDocumentTypeValueSetConcept(code: string): DocumentTypeValueSetConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const DocumentTypeValueSetCodes: string[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomDocumentTypeValueSetCode(): DocumentTypeValueSetCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomDocumentTypeValueSetConcept(): DocumentTypeValueSetConcept;
export {};
