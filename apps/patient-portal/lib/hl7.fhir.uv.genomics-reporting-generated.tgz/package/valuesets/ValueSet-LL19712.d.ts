/**
 * ValueSet: LL1971-2
 * URL: http://loinc.org/vs/LL1971-2
 * Size: 4 concepts
 */
export declare const LL19712Concepts: readonly [{
    readonly code: "LA9633-4";
    readonly system: "http://loinc.org";
    readonly display: "Present";
}, {
    readonly code: "LA9634-2";
    readonly system: "http://loinc.org";
    readonly display: "Absent";
}, {
    readonly code: "LA18198-4";
    readonly system: "http://loinc.org";
    readonly display: "No call";
}, {
    readonly code: "LA11884-6";
    readonly system: "http://loinc.org";
    readonly display: "Indeterminate";
}];
/** Union type of all valid codes in this ValueSet */
export type LL19712Code = "LA9633-4" | "LA9634-2" | "LA18198-4" | "LA11884-6";
/** Type representing a concept from this ValueSet */
export type LL19712Concept = typeof LL19712Concepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidLL19712Code(code: string): code is LL19712Code;
/**
 * Get concept details by code
 */
export declare function getLL19712Concept(code: string): LL19712Concept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const LL19712Codes: ("LA9633-4" | "LA9634-2" | "LA18198-4" | "LA11884-6")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomLL19712Code(): LL19712Code;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomLL19712Concept(): LL19712Concept;
