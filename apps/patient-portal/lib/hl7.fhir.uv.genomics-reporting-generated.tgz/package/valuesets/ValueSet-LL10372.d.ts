/**
 * ValueSet: LL1037-2
 * URL: http://loinc.org/vs/LL1037-2
 * Size: 3 concepts
 */
export declare const LL10372Concepts: readonly [{
    readonly code: "LA14020-4";
    readonly system: "http://loinc.org";
    readonly display: "Genetic counseling recommended";
}, {
    readonly code: "LA14021-2";
    readonly system: "http://loinc.org";
    readonly display: "Confirmatory testing recommended";
}, {
    readonly code: "LA14022-0";
    readonly system: "http://loinc.org";
    readonly display: "Additional testing recommended";
}];
/** Union type of all valid codes in this ValueSet */
export type LL10372Code = "LA14020-4" | "LA14021-2" | "LA14022-0";
/** Type representing a concept from this ValueSet */
export type LL10372Concept = typeof LL10372Concepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidLL10372Code(code: string): code is LL10372Code;
/**
 * Get concept details by code
 */
export declare function getLL10372Concept(code: string): LL10372Concept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const LL10372Codes: ("LA14020-4" | "LA14021-2" | "LA14022-0")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomLL10372Code(): LL10372Code;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomLL10372Concept(): LL10372Concept;
