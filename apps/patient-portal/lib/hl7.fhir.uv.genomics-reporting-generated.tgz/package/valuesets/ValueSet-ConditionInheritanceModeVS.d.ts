/**
 * ValueSet: ConditionInheritanceModeVS
 * URL: http://hl7.org/fhir/uv/genomics-reporting/ValueSet/condition-inheritance-mode-vs
 * Size: 17 concepts
 */
export declare const ConditionInheritanceModeVSConcepts: readonly [{
    readonly code: "HP:0000006";
    readonly system: "http://human-phenotype-ontology.org";
    readonly display: "Autosomal dominant inheritance";
}, {
    readonly code: "HP:0000007";
    readonly system: "http://human-phenotype-ontology.org";
    readonly display: "Autosomal recessive inheritance";
}, {
    readonly code: "HP:0001417";
    readonly system: "http://human-phenotype-ontology.org";
    readonly display: "X-linked inheritance";
}, {
    readonly code: "HP:0001419";
    readonly system: "http://human-phenotype-ontology.org";
    readonly display: "X-linked recessive inheritance";
}, {
    readonly code: "HP:0001423";
    readonly system: "http://human-phenotype-ontology.org";
    readonly display: "X-linked dominant inheritance";
}, {
    readonly code: "HP:0001426";
    readonly system: "http://human-phenotype-ontology.org";
    readonly display: "Multifactorial inheritance";
}, {
    readonly code: "HP:0001427";
    readonly system: "http://human-phenotype-ontology.org";
    readonly display: "Mitochondrial inheritance";
}, {
    readonly code: "HP:0001442";
    readonly system: "http://human-phenotype-ontology.org";
    readonly display: "Typified by somatic mosaicism";
}, {
    readonly code: "HP:0001450";
    readonly system: "http://human-phenotype-ontology.org";
    readonly display: "Y-linked inheritance";
}, {
    readonly code: "HP:0001470";
    readonly system: "http://human-phenotype-ontology.org";
    readonly display: "Sex-limited expression";
}, {
    readonly code: "HP:0003743";
    readonly system: "http://human-phenotype-ontology.org";
    readonly display: "Genetic anticipation";
}, {
    readonly code: "HP:0003745";
    readonly system: "http://human-phenotype-ontology.org";
    readonly display: "Sporadic";
}, {
    readonly code: "HP:0010983";
    readonly system: "http://human-phenotype-ontology.org";
    readonly display: "Oligogenic inheritance";
}, {
    readonly code: "HP:0012274";
    readonly system: "http://human-phenotype-ontology.org";
    readonly display: "Autosomal dominant inheritance with paternal imprinting";
}, {
    readonly code: "HP:0012275";
    readonly system: "http://human-phenotype-ontology.org";
    readonly display: "Autosomal dominant inheritance with maternal imprinting";
}, {
    readonly code: "HP:0025352";
    readonly system: "http://human-phenotype-ontology.org";
    readonly display: "Typically de novo";
}, {
    readonly code: "HP:0032113";
    readonly system: "http://human-phenotype-ontology.org";
    readonly display: "Semidominant inheritance";
}];
/** Union type of all valid codes in this ValueSet */
export type ConditionInheritanceModeVSCode = "HP:0000006" | "HP:0000007" | "HP:0001417" | "HP:0001419" | "HP:0001423" | "HP:0001426" | "HP:0001427" | "HP:0001442" | "HP:0001450" | "HP:0001470" | "HP:0003743" | "HP:0003745" | "HP:0010983" | "HP:0012274" | "HP:0012275" | "HP:0025352" | "HP:0032113";
/** Type representing a concept from this ValueSet */
export type ConditionInheritanceModeVSConcept = typeof ConditionInheritanceModeVSConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidConditionInheritanceModeVSCode(code: string): code is ConditionInheritanceModeVSCode;
/**
 * Get concept details by code
 */
export declare function getConditionInheritanceModeVSConcept(code: string): ConditionInheritanceModeVSConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ConditionInheritanceModeVSCodes: ("HP:0000006" | "HP:0000007" | "HP:0001417" | "HP:0001419" | "HP:0001423" | "HP:0001426" | "HP:0001427" | "HP:0001442" | "HP:0001450" | "HP:0001470" | "HP:0003743" | "HP:0003745" | "HP:0010983" | "HP:0012274" | "HP:0012275" | "HP:0025352" | "HP:0032113")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomConditionInheritanceModeVSCode(): ConditionInheritanceModeVSCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomConditionInheritanceModeVSConcept(): ConditionInheritanceModeVSConcept;
