/**
 * ValueSet: GenomicStudyTypeVS
 * URL: http://hl7.org/fhir/uv/genomics-reporting/ValueSet/genomic-study-type-vs
 * Size: 12 concepts
 */
export declare const GenomicStudyTypeVSConcepts: readonly [{
    readonly code: "alt-splc";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-type-cs";
}, {
    readonly code: "chromatin";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-type-cs";
}, {
    readonly code: "cnv";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-type-cs";
}, {
    readonly code: "epi-alt-hist";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-type-cs";
}, {
    readonly code: "epi-alt-dna";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-type-cs";
}, {
    readonly code: "fam-var-segr";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-type-cs";
}, {
    readonly code: "func-var";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-type-cs";
}, {
    readonly code: "gene-expression";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-type-cs";
}, {
    readonly code: "post-trans-mod";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-type-cs";
}, {
    readonly code: "snp";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-type-cs";
}, {
    readonly code: "str";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-type-cs";
}, {
    readonly code: "struc-var";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-type-cs";
}];
/** Union type of all valid codes in this ValueSet */
export type GenomicStudyTypeVSCode = "alt-splc" | "chromatin" | "cnv" | "epi-alt-hist" | "epi-alt-dna" | "fam-var-segr" | "func-var" | "gene-expression" | "post-trans-mod" | "snp" | "str" | "struc-var";
/** Type representing a concept from this ValueSet */
export type GenomicStudyTypeVSConcept = typeof GenomicStudyTypeVSConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidGenomicStudyTypeVSCode(code: string): code is GenomicStudyTypeVSCode;
/**
 * Get concept details by code
 */
export declare function getGenomicStudyTypeVSConcept(code: string): GenomicStudyTypeVSConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const GenomicStudyTypeVSCodes: ("alt-splc" | "chromatin" | "cnv" | "epi-alt-hist" | "epi-alt-dna" | "fam-var-segr" | "func-var" | "gene-expression" | "post-trans-mod" | "snp" | "str" | "struc-var")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomGenomicStudyTypeVSCode(): GenomicStudyTypeVSCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomGenomicStudyTypeVSConcept(): GenomicStudyTypeVSConcept;
