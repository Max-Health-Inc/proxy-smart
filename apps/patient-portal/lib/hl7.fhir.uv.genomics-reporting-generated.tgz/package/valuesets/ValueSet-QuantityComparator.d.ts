/**
 * ValueSet: quantity-comparator
 * URL: http://hl7.org/fhir/ValueSet/quantity-comparator
 * Size: 4 concepts
 */
export declare const QuantityComparatorConcepts: readonly [{
    readonly code: "<";
    readonly system: "http://hl7.org/fhir/quantity-comparator";
}, {
    readonly code: "<=";
    readonly system: "http://hl7.org/fhir/quantity-comparator";
}, {
    readonly code: ">=";
    readonly system: "http://hl7.org/fhir/quantity-comparator";
}, {
    readonly code: ">";
    readonly system: "http://hl7.org/fhir/quantity-comparator";
}];
/** Union type of all valid codes in this ValueSet */
export type QuantityComparatorCode = "<" | "<=" | ">=" | ">";
/** Type representing a concept from this ValueSet */
export type QuantityComparatorConcept = typeof QuantityComparatorConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidQuantityComparatorCode(code: string): code is QuantityComparatorCode;
/**
 * Get concept details by code
 */
export declare function getQuantityComparatorConcept(code: string): QuantityComparatorConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const QuantityComparatorCodes: ("<" | "<=" | ">=" | ">")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomQuantityComparatorCode(): QuantityComparatorCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomQuantityComparatorConcept(): QuantityComparatorConcept;
