/**
 * ValueSet: quantity-comparator
 * URL: http://hl7.org/fhir/ValueSet/quantity-comparator
 * Size: 4 concepts
 */
export const QuantityComparatorConcepts = [
    { code: "<", system: "http://hl7.org/fhir/quantity-comparator" },
    { code: "<=", system: "http://hl7.org/fhir/quantity-comparator" },
    { code: ">=", system: "http://hl7.org/fhir/quantity-comparator" },
    { code: ">", system: "http://hl7.org/fhir/quantity-comparator" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidQuantityComparatorCode(code) {
    return QuantityComparatorConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getQuantityComparatorConcept(code) {
    return QuantityComparatorConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const QuantityComparatorCodes = QuantityComparatorConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomQuantityComparatorCode() {
    return QuantityComparatorCodes[Math.floor(Math.random() * QuantityComparatorCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomQuantityComparatorConcept() {
    return QuantityComparatorConcepts[Math.floor(Math.random() * QuantityComparatorConcepts.length)];
}
