/**
 * ValueSet: task-status
 * URL: http://hl7.org/fhir/ValueSet/task-status
 * Size: 12 concepts
 */
export const TaskStatusConcepts = [
    { code: "draft", system: "http://hl7.org/fhir/task-status", display: "Draft" },
    { code: "requested", system: "http://hl7.org/fhir/task-status", display: "Requested" },
    { code: "received", system: "http://hl7.org/fhir/task-status", display: "Received" },
    { code: "accepted", system: "http://hl7.org/fhir/task-status", display: "Accepted" },
    { code: "rejected", system: "http://hl7.org/fhir/task-status", display: "Rejected" },
    { code: "ready", system: "http://hl7.org/fhir/task-status", display: "Ready" },
    { code: "cancelled", system: "http://hl7.org/fhir/task-status", display: "Cancelled" },
    { code: "in-progress", system: "http://hl7.org/fhir/task-status", display: "In Progress" },
    { code: "on-hold", system: "http://hl7.org/fhir/task-status", display: "On Hold" },
    { code: "failed", system: "http://hl7.org/fhir/task-status", display: "Failed" },
    { code: "completed", system: "http://hl7.org/fhir/task-status", display: "Completed" },
    { code: "entered-in-error", system: "http://hl7.org/fhir/task-status", display: "Entered in Error" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidTaskStatusCode(code) {
    return TaskStatusConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getTaskStatusConcept(code) {
    return TaskStatusConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const TaskStatusCodes = TaskStatusConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomTaskStatusCode() {
    return TaskStatusCodes[Math.floor(Math.random() * TaskStatusCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomTaskStatusConcept() {
    return TaskStatusConcepts[Math.floor(Math.random() * TaskStatusConcepts.length)];
}
