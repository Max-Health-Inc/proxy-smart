/**
 * ValueSet Registry
 * Central registry of all loaded ValueSets with explicit codes
 */
import * as AllSecurityLabels from './ValueSet-AllSecurityLabels.js';
import * as BodySite from './ValueSet-BodySite.js';
import * as C80DocTypecodes from './ValueSet-C80DocTypecodes.js';
import * as C80Facilitycodes from './ValueSet-C80Facilitycodes.js';
import * as C80PracticeCodes from './ValueSet-C80PracticeCodes.js';
import * as ClinicalFindings from './ValueSet-ClinicalFindings.js';
import * as CodedAnnotationTypesVS from './ValueSet-CodedAnnotationTypesVS.js';
import * as CompositionStatus from './ValueSet-CompositionStatus.js';
import * as ConditionCode from './ValueSet-ConditionCode.js';
import * as ConditionInheritanceModeVS from './ValueSet-ConditionInheritanceModeVS.js';
import * as DataAbsentReason from './ValueSet-DataAbsentReason.js';
import * as DiagnosticReportStatus from './ValueSet-DiagnosticReportStatus.js';
import * as DiagnosticServiceSections from './ValueSet-DiagnosticServiceSections.js';
import * as DocumentClasscodes from './ValueSet-DocumentClasscodes.js';
import * as DocumentReferenceStatus from './ValueSet-DocumentReferenceStatus.js';
import * as DocumentRelationshipType from './ValueSet-DocumentRelationshipType.js';
import * as EventStatus from './ValueSet-EventStatus.js';
import * as EvidenceLevelExampleVS from './ValueSet-EvidenceLevelExampleVS.js';
import * as FHIRDeviceTypes from './ValueSet-FHIRDeviceTypes.js';
import * as GeneticTherapeuticImplicationsVS from './ValueSet-GeneticTherapeuticImplicationsVS.js';
import * as GenomicStudyChangeTypeVS from './ValueSet-GenomicStudyChangeTypeVS.js';
import * as GenomicStudyDataFormatVS from './ValueSet-GenomicStudyDataFormatVS.js';
import * as GenomicStudyMethodTypeVS from './ValueSet-GenomicStudyMethodTypeVS.js';
import * as GenomicStudyStatusVS from './ValueSet-GenomicStudyStatusVS.js';
import * as GenomicStudyTypeVS from './ValueSet-GenomicStudyTypeVS.js';
import * as Languages from './ValueSet-Languages.js';
import * as LL10372 from './ValueSet-LL10372.js';
import * as LL10406 from './ValueSet-LL10406.js';
import * as LL19712 from './ValueSet-LL19712.js';
import * as LL29380 from './ValueSet-LL29380.js';
import * as LL3781 from './ValueSet-LL3781.js';
import * as LL3815 from './ValueSet-LL3815.js';
import * as LL40346 from './ValueSet-LL40346.js';
import * as LL40486 from './ValueSet-LL40486.js';
import * as LL40494 from './ValueSet-LL40494.js';
import * as LL40502 from './ValueSet-LL40502.js';
import * as LL53232 from './ValueSet-LL53232.js';
import * as LL54891 from './ValueSet-LL54891.js';
import * as MolecularBiomarkerCategoryVS from './ValueSet-MolecularBiomarkerCategoryVS.js';
import * as MolecularBiomarkerCodeVS from './ValueSet-MolecularBiomarkerCodeVS.js';
import * as ObservationCategory from './ValueSet-ObservationCategory.js';
import * as ObservationCodes from './ValueSet-ObservationCodes.js';
import * as ObservationInterpretation from './ValueSet-ObservationInterpretation.js';
import * as ObservationMethods from './ValueSet-ObservationMethods.js';
import * as ObservationStatus from './ValueSet-ObservationStatus.js';
import * as ProcedureCategory from './ValueSet-ProcedureCategory.js';
import * as ProcedureCodesSNOMEDCT from './ValueSet-ProcedureCodesSNOMEDCT.js';
import * as ProcedureDeviceActionCodes from './ValueSet-ProcedureDeviceActionCodes.js';
import * as ProcedureFollowup from './ValueSet-ProcedureFollowup.js';
import * as ProcedureNotPerformedReasonSNOMEDCT from './ValueSet-ProcedureNotPerformedReasonSNOMEDCT.js';
import * as ProcedureOutcome from './ValueSet-ProcedureOutcome.js';
import * as ProcedurePerformerRoleCodes from './ValueSet-ProcedurePerformerRoleCodes.js';
import * as ProcedureReasonCodes from './ValueSet-ProcedureReasonCodes.js';
import * as QuantityComparator from './ValueSet-QuantityComparator.js';
import * as ReferencerangeAppliesto from './ValueSet-ReferencerangeAppliesto.js';
import * as ReferencerangeMeaning from './ValueSet-ReferencerangeMeaning.js';
import * as ReportCodes from './ValueSet-ReportCodes.js';
import * as RequestPriority from './ValueSet-RequestPriority.js';
import * as SequencePhaseRelationshipVS from './ValueSet-SequencePhaseRelationshipVS.js';
import * as TaskIntent from './ValueSet-TaskIntent.js';
import * as TaskStatus from './ValueSet-TaskStatus.js';
import * as TBDCodesVS from './ValueSet-TBDCodesVS.js';
import * as V3ActCode from './ValueSet-V3ActCode.js';
import * as VariantConfidenceStatusVS from './ValueSet-VariantConfidenceStatusVS.js';
export const ValueSetRegistry = {
    AllSecurityLabels,
    BodySite,
    C80DocTypecodes,
    C80Facilitycodes,
    C80PracticeCodes,
    ClinicalFindings,
    CodedAnnotationTypesVS,
    CompositionStatus,
    ConditionCode,
    ConditionInheritanceModeVS,
    DataAbsentReason,
    DiagnosticReportStatus,
    DiagnosticServiceSections,
    DocumentClasscodes,
    DocumentReferenceStatus,
    DocumentRelationshipType,
    EventStatus,
    EvidenceLevelExampleVS,
    FHIRDeviceTypes,
    GeneticTherapeuticImplicationsVS,
    GenomicStudyChangeTypeVS,
    GenomicStudyDataFormatVS,
    GenomicStudyMethodTypeVS,
    GenomicStudyStatusVS,
    GenomicStudyTypeVS,
    Languages,
    LL10372,
    LL10406,
    LL19712,
    LL29380,
    LL3781,
    LL3815,
    LL40346,
    LL40486,
    LL40494,
    LL40502,
    LL53232,
    LL54891,
    MolecularBiomarkerCategoryVS,
    MolecularBiomarkerCodeVS,
    ObservationCategory,
    ObservationCodes,
    ObservationInterpretation,
    ObservationMethods,
    ObservationStatus,
    ProcedureCategory,
    ProcedureCodesSNOMEDCT,
    ProcedureDeviceActionCodes,
    ProcedureFollowup,
    ProcedureNotPerformedReasonSNOMEDCT,
    ProcedureOutcome,
    ProcedurePerformerRoleCodes,
    ProcedureReasonCodes,
    QuantityComparator,
    ReferencerangeAppliesto,
    ReferencerangeMeaning,
    ReportCodes,
    RequestPriority,
    SequencePhaseRelationshipVS,
    TaskIntent,
    TaskStatus,
    TBDCodesVS,
    V3ActCode,
    VariantConfidenceStatusVS,
};
export function getValueSet(name) {
    return ValueSetRegistry[name];
}
/** Map from ValueSet URL to registry name */
export const ValueSetUrlMap = {
    'http://hl7.org/fhir/ValueSet/security-labels': 'AllSecurityLabels',
    'http://hl7.org/fhir/ValueSet/body-site': 'BodySite',
    'http://hl7.org/fhir/ValueSet/c80-doc-typecodes': 'C80DocTypecodes',
    'http://hl7.org/fhir/ValueSet/c80-facilitycodes': 'C80Facilitycodes',
    'http://hl7.org/fhir/ValueSet/c80-practice-codes': 'C80PracticeCodes',
    'http://hl7.org/fhir/ValueSet/clinical-findings': 'ClinicalFindings',
    'http://hl7.org/fhir/uv/genomics-reporting/ValueSet/coded-annotation-types-vs': 'CodedAnnotationTypesVS',
    'http://hl7.org/fhir/ValueSet/composition-status': 'CompositionStatus',
    'http://hl7.org/fhir/ValueSet/condition-code': 'ConditionCode',
    'http://hl7.org/fhir/uv/genomics-reporting/ValueSet/condition-inheritance-mode-vs': 'ConditionInheritanceModeVS',
    'http://hl7.org/fhir/ValueSet/data-absent-reason': 'DataAbsentReason',
    'http://hl7.org/fhir/ValueSet/diagnostic-report-status': 'DiagnosticReportStatus',
    'http://hl7.org/fhir/ValueSet/diagnostic-service-sections': 'DiagnosticServiceSections',
    'http://hl7.org/fhir/ValueSet/document-classcodes': 'DocumentClasscodes',
    'http://hl7.org/fhir/ValueSet/document-reference-status': 'DocumentReferenceStatus',
    'http://hl7.org/fhir/ValueSet/document-relationship-type': 'DocumentRelationshipType',
    'http://hl7.org/fhir/ValueSet/event-status': 'EventStatus',
    'http://hl7.org/fhir/uv/genomics-reporting/ValueSet/evidence-level-example-vs': 'EvidenceLevelExampleVS',
    'http://hl7.org/fhir/ValueSet/device-kind': 'FHIRDeviceTypes',
    'http://hl7.org/fhir/uv/genomics-reporting/ValueSet/genetic-therapeutic-implications-vs': 'GeneticTherapeuticImplicationsVS',
    'http://hl7.org/fhir/uv/genomics-reporting/ValueSet/genomic-study-change-type-vs': 'GenomicStudyChangeTypeVS',
    'http://hl7.org/fhir/uv/genomics-reporting/ValueSet/genomic-study-data-format-vs': 'GenomicStudyDataFormatVS',
    'http://hl7.org/fhir/uv/genomics-reporting/ValueSet/genomic-study-method-type-vs': 'GenomicStudyMethodTypeVS',
    'http://hl7.org/fhir/uv/genomics-reporting/ValueSet/genomic-study-status-vs': 'GenomicStudyStatusVS',
    'http://hl7.org/fhir/uv/genomics-reporting/ValueSet/genomic-study-type-vs': 'GenomicStudyTypeVS',
    'http://hl7.org/fhir/ValueSet/languages': 'Languages',
    'http://loinc.org/vs/LL1037-2': 'LL10372',
    'http://loinc.org/vs/LL1040-6': 'LL10406',
    'http://loinc.org/vs/LL1971-2': 'LL19712',
    'http://loinc.org/vs/LL2938-0': 'LL29380',
    'http://loinc.org/vs/LL378-1': 'LL3781',
    'http://loinc.org/vs/LL381-5': 'LL3815',
    'http://loinc.org/vs/LL4034-6': 'LL40346',
    'http://loinc.org/vs/LL4048-6': 'LL40486',
    'http://loinc.org/vs/LL4049-4': 'LL40494',
    'http://loinc.org/vs/LL4050-2': 'LL40502',
    'http://loinc.org/vs/LL5323-2': 'LL53232',
    'http://loinc.org/vs/LL5489-1': 'LL54891',
    'http://hl7.org/fhir/uv/genomics-reporting/ValueSet/molecular-biomarker-category-vs': 'MolecularBiomarkerCategoryVS',
    'http://hl7.org/fhir/uv/genomics-reporting/ValueSet/molecular-biomarker-code-vs': 'MolecularBiomarkerCodeVS',
    'http://hl7.org/fhir/ValueSet/observation-category': 'ObservationCategory',
    'http://hl7.org/fhir/ValueSet/observation-codes': 'ObservationCodes',
    'http://hl7.org/fhir/ValueSet/observation-interpretation': 'ObservationInterpretation',
    'http://hl7.org/fhir/ValueSet/observation-methods': 'ObservationMethods',
    'http://hl7.org/fhir/ValueSet/observation-status': 'ObservationStatus',
    'http://hl7.org/fhir/ValueSet/procedure-category': 'ProcedureCategory',
    'http://hl7.org/fhir/ValueSet/procedure-code': 'ProcedureCodesSNOMEDCT',
    'http://hl7.org/fhir/ValueSet/device-action': 'ProcedureDeviceActionCodes',
    'http://hl7.org/fhir/ValueSet/procedure-followup': 'ProcedureFollowup',
    'http://hl7.org/fhir/ValueSet/procedure-not-performed-reason': 'ProcedureNotPerformedReasonSNOMEDCT',
    'http://hl7.org/fhir/ValueSet/procedure-outcome': 'ProcedureOutcome',
    'http://hl7.org/fhir/ValueSet/performer-role': 'ProcedurePerformerRoleCodes',
    'http://hl7.org/fhir/ValueSet/procedure-reason': 'ProcedureReasonCodes',
    'http://hl7.org/fhir/ValueSet/quantity-comparator': 'QuantityComparator',
    'http://hl7.org/fhir/ValueSet/referencerange-appliesto': 'ReferencerangeAppliesto',
    'http://hl7.org/fhir/ValueSet/referencerange-meaning': 'ReferencerangeMeaning',
    'http://hl7.org/fhir/ValueSet/report-codes': 'ReportCodes',
    'http://hl7.org/fhir/ValueSet/request-priority': 'RequestPriority',
    'http://hl7.org/fhir/uv/genomics-reporting/ValueSet/sequence-phase-relationship-vs': 'SequencePhaseRelationshipVS',
    'http://hl7.org/fhir/ValueSet/task-intent': 'TaskIntent',
    'http://hl7.org/fhir/ValueSet/task-status': 'TaskStatus',
    'http://hl7.org/fhir/uv/genomics-reporting/ValueSet/tbd-codes-vs': 'TBDCodesVS',
    'http://terminology.hl7.org/ValueSet/v3-ActCode': 'V3ActCode',
    'http://hl7.org/fhir/uv/genomics-reporting/ValueSet/variant-confidence-status-vs': 'VariantConfidenceStatusVS',
};
function stripVersionFromUrl(url) {
    const pipeIndex = url.indexOf('|');
    return pipeIndex >= 0 ? url.substring(0, pipeIndex) : url;
}
/**
 * Get a random code from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A random code string, or undefined if ValueSet not found
 */
export function getRandomCodeByUrl(url) {
    const cleanUrl = stripVersionFromUrl(url);
    const name = ValueSetUrlMap[cleanUrl];
    if (!name)
        return undefined;
    const vs = ValueSetRegistry[name];
    // Each ValueSet exports random<Name>Code() function
    const randomFn = vs['random' + name + 'Code'];
    return randomFn?.();
}
/**
 * Get a random concept (code, system, display) from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A concept object with code, system, and optional display, or undefined if ValueSet not found
 */
export function getRandomConceptByUrl(url) {
    const cleanUrl = stripVersionFromUrl(url);
    const name = ValueSetUrlMap[cleanUrl];
    if (!name)
        return undefined;
    const vs = ValueSetRegistry[name];
    // Each ValueSet exports random<Name>Concept() function
    const randomFn = vs['random' + name + 'Concept'];
    return randomFn?.();
}
