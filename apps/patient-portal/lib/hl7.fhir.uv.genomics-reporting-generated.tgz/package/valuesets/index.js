/**
 * ValueSet Registry
 * Central registry of all loaded ValueSets with explicit codes
 */
import * as BodySite from './ValueSet-BodySite.js';
import * as ClinicalFindings from './ValueSet-ClinicalFindings.js';
import * as CodedAnnotationTypesVS from './ValueSet-CodedAnnotationTypesVS.js';
import * as CompositionStatus from './ValueSet-CompositionStatus.js';
import * as ConditionCode from './ValueSet-ConditionCode.js';
import * as ConditionInheritanceModeVS from './ValueSet-ConditionInheritanceModeVS.js';
import * as DiagnosticReportStatus from './ValueSet-DiagnosticReportStatus.js';
import * as DocumentReferenceStatus from './ValueSet-DocumentReferenceStatus.js';
import * as EventStatus from './ValueSet-EventStatus.js';
import * as EvidenceLevelExampleVS from './ValueSet-EvidenceLevelExampleVS.js';
import * as GeneticTherapeuticImplicationsVS from './ValueSet-GeneticTherapeuticImplicationsVS.js';
import * as GenomicStudyChangeTypeVS from './ValueSet-GenomicStudyChangeTypeVS.js';
import * as GenomicStudyDataFormatVS from './ValueSet-GenomicStudyDataFormatVS.js';
import * as GenomicStudyMethodTypeVS from './ValueSet-GenomicStudyMethodTypeVS.js';
import * as GenomicStudyStatusVS from './ValueSet-GenomicStudyStatusVS.js';
import * as GenomicStudyTypeVS from './ValueSet-GenomicStudyTypeVS.js';
import * as MolecularBiomarkerCategoryVS from './ValueSet-MolecularBiomarkerCategoryVS.js';
import * as MolecularBiomarkerCodeVS from './ValueSet-MolecularBiomarkerCodeVS.js';
import * as ObservationCodes from './ValueSet-ObservationCodes.js';
import * as ObservationMethods from './ValueSet-ObservationMethods.js';
import * as ObservationStatus from './ValueSet-ObservationStatus.js';
import * as QuantityComparator from './ValueSet-QuantityComparator.js';
import * as RequestPriority from './ValueSet-RequestPriority.js';
import * as SequencePhaseRelationshipVS from './ValueSet-SequencePhaseRelationshipVS.js';
import * as TaskStatus from './ValueSet-TaskStatus.js';
import * as TBDCodesVS from './ValueSet-TBDCodesVS.js';
import * as VariantConfidenceStatusVS from './ValueSet-VariantConfidenceStatusVS.js';
export const ValueSetRegistry = {
    BodySite,
    ClinicalFindings,
    CodedAnnotationTypesVS,
    CompositionStatus,
    ConditionCode,
    ConditionInheritanceModeVS,
    DiagnosticReportStatus,
    DocumentReferenceStatus,
    EventStatus,
    EvidenceLevelExampleVS,
    GeneticTherapeuticImplicationsVS,
    GenomicStudyChangeTypeVS,
    GenomicStudyDataFormatVS,
    GenomicStudyMethodTypeVS,
    GenomicStudyStatusVS,
    GenomicStudyTypeVS,
    MolecularBiomarkerCategoryVS,
    MolecularBiomarkerCodeVS,
    ObservationCodes,
    ObservationMethods,
    ObservationStatus,
    QuantityComparator,
    RequestPriority,
    SequencePhaseRelationshipVS,
    TaskStatus,
    TBDCodesVS,
    VariantConfidenceStatusVS,
};
export function getValueSet(name) {
    return ValueSetRegistry[name];
}
/** Map from ValueSet URL to registry name */
export const ValueSetUrlMap = {
    'http://hl7.org/fhir/ValueSet/body-site': 'BodySite',
    'http://hl7.org/fhir/ValueSet/clinical-findings': 'ClinicalFindings',
    'http://hl7.org/fhir/uv/genomics-reporting/ValueSet/coded-annotation-types-vs': 'CodedAnnotationTypesVS',
    'http://hl7.org/fhir/ValueSet/composition-status': 'CompositionStatus',
    'http://hl7.org/fhir/ValueSet/condition-code': 'ConditionCode',
    'http://hl7.org/fhir/uv/genomics-reporting/ValueSet/condition-inheritance-mode-vs': 'ConditionInheritanceModeVS',
    'http://hl7.org/fhir/ValueSet/diagnostic-report-status': 'DiagnosticReportStatus',
    'http://hl7.org/fhir/ValueSet/document-reference-status': 'DocumentReferenceStatus',
    'http://hl7.org/fhir/ValueSet/event-status': 'EventStatus',
    'http://hl7.org/fhir/uv/genomics-reporting/ValueSet/evidence-level-example-vs': 'EvidenceLevelExampleVS',
    'http://hl7.org/fhir/uv/genomics-reporting/ValueSet/genetic-therapeutic-implications-vs': 'GeneticTherapeuticImplicationsVS',
    'http://hl7.org/fhir/uv/genomics-reporting/ValueSet/genomic-study-change-type-vs': 'GenomicStudyChangeTypeVS',
    'http://hl7.org/fhir/uv/genomics-reporting/ValueSet/genomic-study-data-format-vs': 'GenomicStudyDataFormatVS',
    'http://hl7.org/fhir/uv/genomics-reporting/ValueSet/genomic-study-method-type-vs': 'GenomicStudyMethodTypeVS',
    'http://hl7.org/fhir/uv/genomics-reporting/ValueSet/genomic-study-status-vs': 'GenomicStudyStatusVS',
    'http://hl7.org/fhir/uv/genomics-reporting/ValueSet/genomic-study-type-vs': 'GenomicStudyTypeVS',
    'http://hl7.org/fhir/uv/genomics-reporting/ValueSet/molecular-biomarker-category-vs': 'MolecularBiomarkerCategoryVS',
    'http://hl7.org/fhir/uv/genomics-reporting/ValueSet/molecular-biomarker-code-vs': 'MolecularBiomarkerCodeVS',
    'http://hl7.org/fhir/ValueSet/observation-codes': 'ObservationCodes',
    'http://hl7.org/fhir/ValueSet/observation-methods': 'ObservationMethods',
    'http://hl7.org/fhir/ValueSet/observation-status': 'ObservationStatus',
    'http://hl7.org/fhir/ValueSet/quantity-comparator': 'QuantityComparator',
    'http://hl7.org/fhir/ValueSet/request-priority': 'RequestPriority',
    'http://hl7.org/fhir/uv/genomics-reporting/ValueSet/sequence-phase-relationship-vs': 'SequencePhaseRelationshipVS',
    'http://hl7.org/fhir/ValueSet/task-status': 'TaskStatus',
    'http://hl7.org/fhir/uv/genomics-reporting/ValueSet/tbd-codes-vs': 'TBDCodesVS',
    'http://hl7.org/fhir/uv/genomics-reporting/ValueSet/variant-confidence-status-vs': 'VariantConfidenceStatusVS',
};
function stripVersionFromUrl(url) {
    const pipeIndex = url.indexOf('|');
    return pipeIndex >= 0 ? url.substring(0, pipeIndex) : url;
}
/**
 * Get a random code from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A random code string, or undefined if ValueSet not found
 */
export function getRandomCodeByUrl(url) {
    const cleanUrl = stripVersionFromUrl(url);
    const name = ValueSetUrlMap[cleanUrl];
    if (!name)
        return undefined;
    const vs = ValueSetRegistry[name];
    // Each ValueSet exports random<Name>Code() function
    const randomFn = vs['random' + name + 'Code'];
    return randomFn?.();
}
/**
 * Get a random concept (code, system, display) from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A concept object with code, system, and optional display, or undefined if ValueSet not found
 */
export function getRandomConceptByUrl(url) {
    const cleanUrl = stripVersionFromUrl(url);
    const name = ValueSetUrlMap[cleanUrl];
    if (!name)
        return undefined;
    const vs = ValueSetRegistry[name];
    // Each ValueSet exports random<Name>Concept() function
    const randomFn = vs['random' + name + 'Concept'];
    return randomFn?.();
}
