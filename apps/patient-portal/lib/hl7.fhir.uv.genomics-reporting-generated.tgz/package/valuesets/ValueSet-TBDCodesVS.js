/**
 * ValueSet: TBDCodesVS
 * URL: http://hl7.org/fhir/uv/genomics-reporting/ValueSet/tbd-codes-vs
 * Size: 13 concepts
 */
export const TBDCodesVSConcepts = [
    { code: "associated-therapy", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs" },
    { code: "molecular-consequence", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs" },
    { code: "feature-consequence", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs" },
    { code: "diagnostic-implication", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs" },
    { code: "therapeutic-implication", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs" },
    { code: "functional-effect", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs" },
    { code: "conclusion-string", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs" },
    { code: "condition-inheritance", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs" },
    { code: "variant-confidence-status", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs" },
    { code: "repeat-motif", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs" },
    { code: "repeat-number", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs" },
    { code: "biomarker-category", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs" },
    { code: "protein-ref-seq", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidTBDCodesVSCode(code) {
    return TBDCodesVSConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getTBDCodesVSConcept(code) {
    return TBDCodesVSConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const TBDCodesVSCodes = TBDCodesVSConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomTBDCodesVSCode() {
    return TBDCodesVSCodes[Math.floor(Math.random() * TBDCodesVSCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomTBDCodesVSConcept() {
    return TBDCodesVSConcepts[Math.floor(Math.random() * TBDCodesVSConcepts.length)];
}
