/**
 * ValueSet: GenomicStudyStatusVS
 * URL: http://hl7.org/fhir/uv/genomics-reporting/ValueSet/genomic-study-status-vs
 * Size: 5 concepts
 */
export const GenomicStudyStatusVSConcepts = [
    { code: "registered", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-status-cs" },
    { code: "available", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-status-cs" },
    { code: "cancelled", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-status-cs" },
    { code: "entered-in-error", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-status-cs" },
    { code: "unknown", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-status-cs" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidGenomicStudyStatusVSCode(code) {
    return GenomicStudyStatusVSConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getGenomicStudyStatusVSConcept(code) {
    return GenomicStudyStatusVSConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const GenomicStudyStatusVSCodes = GenomicStudyStatusVSConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomGenomicStudyStatusVSCode() {
    return GenomicStudyStatusVSCodes[Math.floor(Math.random() * GenomicStudyStatusVSCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomGenomicStudyStatusVSConcept() {
    return GenomicStudyStatusVSConcepts[Math.floor(Math.random() * GenomicStudyStatusVSConcepts.length)];
}
