/**
 * ValueSet: document-reference-status
 * URL: http://hl7.org/fhir/ValueSet/document-reference-status
 * Size: 3 concepts
 */
export declare const DocumentReferenceStatusConcepts: readonly [{
    readonly code: "current";
    readonly system: "http://hl7.org/fhir/document-reference-status";
}, {
    readonly code: "superseded";
    readonly system: "http://hl7.org/fhir/document-reference-status";
}, {
    readonly code: "entered-in-error";
    readonly system: "http://hl7.org/fhir/document-reference-status";
}];
/** Union type of all valid codes in this ValueSet */
export type DocumentReferenceStatusCode = "current" | "superseded" | "entered-in-error";
/** Type representing a concept from this ValueSet */
export type DocumentReferenceStatusConcept = typeof DocumentReferenceStatusConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidDocumentReferenceStatusCode(code: string): code is DocumentReferenceStatusCode;
/**
 * Get concept details by code
 */
export declare function getDocumentReferenceStatusConcept(code: string): DocumentReferenceStatusConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const DocumentReferenceStatusCodes: ("entered-in-error" | "current" | "superseded")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomDocumentReferenceStatusCode(): DocumentReferenceStatusCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomDocumentReferenceStatusConcept(): DocumentReferenceStatusConcept;
