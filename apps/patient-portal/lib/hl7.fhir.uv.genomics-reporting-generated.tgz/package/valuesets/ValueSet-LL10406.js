/**
 * ValueSet: LL1040-6
 * URL: http://loinc.org/vs/LL1040-6
 * Size: 5 concepts
 */
export const LL10406Concepts = [
    { code: "LA14032-9", system: "http://loinc.org", display: "NCBI Build 34" },
    { code: "LA14029-5", system: "http://loinc.org", display: "GRCh37" },
    { code: "LA14030-3", system: "http://loinc.org", display: "NCBI Build 36.1" },
    { code: "LA14031-1", system: "http://loinc.org", display: "NCBI Build 35" },
    { code: "LA26806-2", system: "http://loinc.org", display: "GRCh38" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidLL10406Code(code) {
    return LL10406Concepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getLL10406Concept(code) {
    return LL10406Concepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const LL10406Codes = LL10406Concepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomLL10406Code() {
    return LL10406Codes[Math.floor(Math.random() * LL10406Codes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomLL10406Concept() {
    return LL10406Concepts[Math.floor(Math.random() * LL10406Concepts.length)];
}
