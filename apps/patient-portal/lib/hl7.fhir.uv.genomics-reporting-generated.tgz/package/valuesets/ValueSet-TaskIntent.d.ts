/**
 * ValueSet: task-intent
 * URL: http://hl7.org/fhir/ValueSet/task-intent
 * Size: 9 concepts
 */
export declare const TaskIntentConcepts: readonly [{
    readonly code: "unknown";
    readonly system: "http://hl7.org/fhir/task-intent";
}, {
    readonly code: "proposal";
    readonly system: "http://hl7.org/fhir/request-intent";
}, {
    readonly code: "plan";
    readonly system: "http://hl7.org/fhir/request-intent";
}, {
    readonly code: "order";
    readonly system: "http://hl7.org/fhir/request-intent";
}, {
    readonly code: "original-order";
    readonly system: "http://hl7.org/fhir/request-intent";
}, {
    readonly code: "reflex-order";
    readonly system: "http://hl7.org/fhir/request-intent";
}, {
    readonly code: "filler-order";
    readonly system: "http://hl7.org/fhir/request-intent";
}, {
    readonly code: "instance-order";
    readonly system: "http://hl7.org/fhir/request-intent";
}, {
    readonly code: "option";
    readonly system: "http://hl7.org/fhir/request-intent";
}];
/** Union type of all valid codes in this ValueSet */
export type TaskIntentCode = "unknown" | "proposal" | "plan" | "order" | "original-order" | "reflex-order" | "filler-order" | "instance-order" | "option";
/** Type representing a concept from this ValueSet */
export type TaskIntentConcept = typeof TaskIntentConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidTaskIntentCode(code: string): code is TaskIntentCode;
/**
 * Get concept details by code
 */
export declare function getTaskIntentConcept(code: string): TaskIntentConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const TaskIntentCodes: ("unknown" | "order" | "proposal" | "plan" | "original-order" | "reflex-order" | "filler-order" | "instance-order" | "option")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomTaskIntentCode(): TaskIntentCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomTaskIntentConcept(): TaskIntentConcept;
