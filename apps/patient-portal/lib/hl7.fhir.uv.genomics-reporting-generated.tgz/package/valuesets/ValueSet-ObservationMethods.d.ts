/**
 * ValueSet: observation-methods
 * URL: http://hl7.org/fhir/ValueSet/observation-methods
 * Size: 15 concepts
 */
export declare const ObservationMethodsConcepts: readonly [{
    readonly code: "27113001";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "50373000";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "75367002";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "364075005";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "86290005";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "386725007";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "431314004";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "60621009";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "271649006";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "271650006";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "404684003";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "118228005";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "250171008";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "363787002";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "386661006";
    readonly system: "http://snomed.info/sct";
}];
/** Union type of all valid codes in this ValueSet */
export type ObservationMethodsCode = "27113001" | "50373000" | "75367002" | "364075005" | "86290005" | "386725007" | "431314004" | "60621009" | "271649006" | "271650006" | "404684003" | "118228005" | "250171008" | "363787002" | "386661006";
/** Type representing a concept from this ValueSet */
export type ObservationMethodsConcept = typeof ObservationMethodsConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidObservationMethodsCode(code: string): code is ObservationMethodsCode;
/**
 * Get concept details by code
 */
export declare function getObservationMethodsConcept(code: string): ObservationMethodsConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ObservationMethodsCodes: ("404684003" | "27113001" | "50373000" | "75367002" | "364075005" | "86290005" | "386725007" | "431314004" | "60621009" | "271649006" | "271650006" | "118228005" | "250171008" | "363787002" | "386661006")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomObservationMethodsCode(): ObservationMethodsCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomObservationMethodsConcept(): ObservationMethodsConcept;
