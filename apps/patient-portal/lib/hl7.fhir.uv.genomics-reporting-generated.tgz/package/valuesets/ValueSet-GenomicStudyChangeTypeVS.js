/**
 * ValueSet: GenomicStudyChangeTypeVS
 * URL: http://hl7.org/fhir/uv/genomics-reporting/ValueSet/genomic-study-change-type-vs
 * Size: 5 concepts
 */
export const GenomicStudyChangeTypeVSConcepts = [
    { code: "DNA", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-change-type-cs" },
    { code: "RNA", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-change-type-cs" },
    { code: "AA", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-change-type-cs" },
    { code: "CHR", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-change-type-cs" },
    { code: "CNV", system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-change-type-cs" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidGenomicStudyChangeTypeVSCode(code) {
    return GenomicStudyChangeTypeVSConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getGenomicStudyChangeTypeVSConcept(code) {
    return GenomicStudyChangeTypeVSConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const GenomicStudyChangeTypeVSCodes = GenomicStudyChangeTypeVSConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomGenomicStudyChangeTypeVSCode() {
    return GenomicStudyChangeTypeVSCodes[Math.floor(Math.random() * GenomicStudyChangeTypeVSCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomGenomicStudyChangeTypeVSConcept() {
    return GenomicStudyChangeTypeVSConcepts[Math.floor(Math.random() * GenomicStudyChangeTypeVSConcepts.length)];
}
