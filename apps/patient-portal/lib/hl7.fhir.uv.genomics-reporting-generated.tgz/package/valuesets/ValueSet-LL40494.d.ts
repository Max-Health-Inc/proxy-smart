/**
 * ValueSet: LL4049-4
 * URL: http://loinc.org/vs/LL4049-4
 * Size: 5 concepts
 */
export declare const LL40494Concepts: readonly [{
    readonly code: "LA26421-0";
    readonly system: "http://loinc.org";
    readonly display: "Consider alternative medication";
}, {
    readonly code: "LA26422-8";
    readonly system: "http://loinc.org";
    readonly display: "Decrease dose";
}, {
    readonly code: "LA26423-6";
    readonly system: "http://loinc.org";
    readonly display: "Increase dose";
}, {
    readonly code: "LA26424-4";
    readonly system: "http://loinc.org";
    readonly display: "Use caution";
}, {
    readonly code: "LA26425-1";
    readonly system: "http://loinc.org";
    readonly display: "Normal response expected";
}];
/** Union type of all valid codes in this ValueSet */
export type LL40494Code = "LA26421-0" | "LA26422-8" | "LA26423-6" | "LA26424-4" | "LA26425-1";
/** Type representing a concept from this ValueSet */
export type LL40494Concept = typeof LL40494Concepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidLL40494Code(code: string): code is LL40494Code;
/**
 * Get concept details by code
 */
export declare function getLL40494Concept(code: string): LL40494Concept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const LL40494Codes: ("LA26421-0" | "LA26422-8" | "LA26423-6" | "LA26424-4" | "LA26425-1")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomLL40494Code(): LL40494Code;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomLL40494Concept(): LL40494Concept;
