/**
 * ValueSet: GenomicStudyStatusVS
 * URL: http://hl7.org/fhir/uv/genomics-reporting/ValueSet/genomic-study-status-vs
 * Size: 5 concepts
 */
export declare const GenomicStudyStatusVSConcepts: readonly [{
    readonly code: "registered";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-status-cs";
}, {
    readonly code: "available";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-status-cs";
}, {
    readonly code: "cancelled";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-status-cs";
}, {
    readonly code: "entered-in-error";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-status-cs";
}, {
    readonly code: "unknown";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-status-cs";
}];
/** Union type of all valid codes in this ValueSet */
export type GenomicStudyStatusVSCode = "registered" | "available" | "cancelled" | "entered-in-error" | "unknown";
/** Type representing a concept from this ValueSet */
export type GenomicStudyStatusVSConcept = typeof GenomicStudyStatusVSConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidGenomicStudyStatusVSCode(code: string): code is GenomicStudyStatusVSCode;
/**
 * Get concept details by code
 */
export declare function getGenomicStudyStatusVSConcept(code: string): GenomicStudyStatusVSConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const GenomicStudyStatusVSCodes: ("unknown" | "entered-in-error" | "registered" | "cancelled" | "available")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomGenomicStudyStatusVSCode(): GenomicStudyStatusVSCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomGenomicStudyStatusVSConcept(): GenomicStudyStatusVSConcept;
