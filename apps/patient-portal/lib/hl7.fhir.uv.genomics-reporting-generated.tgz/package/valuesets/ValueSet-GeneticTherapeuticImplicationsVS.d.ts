/**
 * ValueSet: GeneticTherapeuticImplicationsVS
 * URL: http://hl7.org/fhir/uv/genomics-reporting/ValueSet/genetic-therapeutic-implications-vs
 * Size: 21 concepts
 */
export declare const GeneticTherapeuticImplicationsVSConcepts: readonly [{
    readonly code: "LA10315-2";
    readonly system: "http://loinc.org";
    readonly display: "Ultrarapid metabolizer";
}, {
    readonly code: "LA25391-6";
    readonly system: "http://loinc.org";
    readonly display: "Normal metabolizer";
}, {
    readonly code: "LA25390-8";
    readonly system: "http://loinc.org";
    readonly display: "Rapid metabolizer";
}, {
    readonly code: "LA10317-8";
    readonly system: "http://loinc.org";
    readonly display: "Intermediate metabolizer";
}, {
    readonly code: "LA9657-3";
    readonly system: "http://loinc.org";
    readonly display: "Poor metabolizer";
}, {
    readonly code: "LA19542-2";
    readonly system: "http://loinc.org";
    readonly display: "Low Risk";
}, {
    readonly code: "LA19541-4";
    readonly system: "http://loinc.org";
    readonly display: "High Risk";
}, {
    readonly code: "LA6676-6";
    readonly system: "http://loinc.org";
    readonly display: "Resistant";
}, {
    readonly code: "LA6677-4";
    readonly system: "http://loinc.org";
    readonly display: "Responsive";
}, {
    readonly code: "LA9660-7";
    readonly system: "http://loinc.org";
    readonly display: "Presumed resistant";
}, {
    readonly code: "LA9661-5";
    readonly system: "http://loinc.org";
    readonly display: "Presumed responsive";
}, {
    readonly code: "LA6682-4";
    readonly system: "http://loinc.org";
    readonly display: "Unknown Significance";
}, {
    readonly code: "LA6675-8";
    readonly system: "http://loinc.org";
    readonly display: "Benign";
}, {
    readonly code: "LA6674-1";
    readonly system: "http://loinc.org";
    readonly display: "Presumed Benign";
}, {
    readonly code: "LA9662-3";
    readonly system: "http://loinc.org";
    readonly display: "Presumed non-responsive";
}, {
    readonly code: "LA25392-4";
    readonly system: "http://loinc.org";
    readonly display: "Increased function";
}, {
    readonly code: "LA25393-2";
    readonly system: "http://loinc.org";
    readonly display: "Normal function";
}, {
    readonly code: "LA25395-7";
    readonly system: "http://loinc.org";
    readonly display: "Decreased function";
}, {
    readonly code: "LA25394-0";
    readonly system: "http://loinc.org";
    readonly display: "Poor function";
}, {
    readonly code: "444734003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Does not meet eligibility criteria for clinical trial (finding)";
}, {
    readonly code: "399223003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Patient eligible for clinical trial (finding)";
}];
/** String type (ValueSet too large for union type) */
export type GeneticTherapeuticImplicationsVSCode = string;
/** Type representing a concept from this ValueSet */
export type GeneticTherapeuticImplicationsVSConcept = typeof GeneticTherapeuticImplicationsVSConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidGeneticTherapeuticImplicationsVSCode(code: string): code is GeneticTherapeuticImplicationsVSCode;
/**
 * Get concept details by code
 */
export declare function getGeneticTherapeuticImplicationsVSConcept(code: string): GeneticTherapeuticImplicationsVSConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const GeneticTherapeuticImplicationsVSCodes: ("LA10315-2" | "LA25391-6" | "LA25390-8" | "LA10317-8" | "LA9657-3" | "LA19542-2" | "LA19541-4" | "LA6676-6" | "LA6677-4" | "LA9660-7" | "LA9661-5" | "LA6682-4" | "LA6675-8" | "LA6674-1" | "LA9662-3" | "LA25392-4" | "LA25393-2" | "LA25395-7" | "LA25394-0" | "444734003" | "399223003")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomGeneticTherapeuticImplicationsVSCode(): GeneticTherapeuticImplicationsVSCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomGeneticTherapeuticImplicationsVSConcept(): GeneticTherapeuticImplicationsVSConcept;
