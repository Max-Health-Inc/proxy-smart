/**
 * ValueSet: LL4034-6
 * URL: http://loinc.org/vs/LL4034-6
 * Size: 5 concepts
 */
export const LL40346Concepts = [
    { code: "LA6668-3", system: "http://loinc.org", display: "Pathogenic" },
    { code: "LA26332-9", system: "http://loinc.org", display: "Likely pathogenic" },
    { code: "LA26333-7", system: "http://loinc.org", display: "Uncertain significance" },
    { code: "LA26334-5", system: "http://loinc.org", display: "Likely benign" },
    { code: "LA6675-8", system: "http://loinc.org", display: "Benign" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidLL40346Code(code) {
    return LL40346Concepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getLL40346Concept(code) {
    return LL40346Concepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const LL40346Codes = LL40346Concepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomLL40346Code() {
    return LL40346Codes[Math.floor(Math.random() * LL40346Codes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomLL40346Concept() {
    return LL40346Concepts[Math.floor(Math.random() * LL40346Concepts.length)];
}
