/**
 * ValueSet: LL4048-6
 * URL: http://loinc.org/vs/LL4048-6
 * Size: 23 concepts
 */
export const LL40486Concepts = [
    { code: "LA26398-0", system: "http://loinc.org", display: "Sequencing" },
    { code: "LA26399-8", system: "http://loinc.org", display: "Oligo aCGH" },
    { code: "LA26400-4", system: "http://loinc.org", display: "SNP array" },
    { code: "LA26401-2", system: "http://loinc.org", display: "BAC aCGH" },
    { code: "LA26402-0", system: "http://loinc.org", display: "Curated" },
    { code: "LA26403-8", system: "http://loinc.org", display: "Digital array" },
    { code: "LA26404-6", system: "http://loinc.org", display: "FISH" },
    { code: "LA26405-3", system: "http://loinc.org", display: "Gene expression array" },
    { code: "LA26406-1", system: "http://loinc.org", display: "Karyotyping" },
    { code: "LA26407-9", system: "http://loinc.org", display: "MAPH" },
    { code: "LA26408-7", system: "http://loinc.org", display: "MALDI-TOF" },
    { code: "LA26808-8", system: "http://loinc.org", display: "Merging" },
    { code: "LA26414-5", system: "http://loinc.org", display: "Multiple complete digestion" },
    { code: "LA26415-2", system: "http://loinc.org", display: "MLPA" },
    { code: "LA26417-8", system: "http://loinc.org", display: "Optical mapping" },
    { code: "LA26418-6", system: "http://loinc.org", display: "PCR" },
    { code: "LA26419-4", system: "http://loinc.org", display: "qPCR (real-time PCR)" },
    { code: "LA26420-2", system: "http://loinc.org", display: "ROMA" },
    { code: "LA26809-6", system: "http://loinc.org", display: "Denaturing high-pressure liquid chromatography (DHPLC)" },
    { code: "LA26810-4", system: "http://loinc.org", display: "DNA hybridization" },
    { code: "LA26811-2", system: "http://loinc.org", display: "Computational analysis" },
    { code: "LA26812-0", system: "http://loinc.org", display: "Single-stranded conformational polymorphism (SSCP)" },
    { code: "LA26813-8", system: "http://loinc.org", display: "Restriction fragment length polymorphism (RFLP)" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidLL40486Code(code) {
    return LL40486Concepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getLL40486Concept(code) {
    return LL40486Concepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const LL40486Codes = LL40486Concepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomLL40486Code() {
    return LL40486Codes[Math.floor(Math.random() * LL40486Codes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomLL40486Concept() {
    return LL40486Concepts[Math.floor(Math.random() * LL40486Concepts.length)];
}
