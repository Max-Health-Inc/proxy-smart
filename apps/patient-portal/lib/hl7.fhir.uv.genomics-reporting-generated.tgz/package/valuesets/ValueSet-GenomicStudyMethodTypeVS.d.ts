/**
 * ValueSet: GenomicStudyMethodTypeVS
 * URL: http://hl7.org/fhir/uv/genomics-reporting/ValueSet/genomic-study-method-type-vs
 * Size: 81 concepts
 */
export declare const GenomicStudyMethodTypeVSConcepts: readonly [{
    readonly code: "biochemical-genetics";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "cytogenetics";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "molecular-genetics";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "analyte";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "chromosome-breakage-studies";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "deletion-duplication-analysis";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "detection-of-homozygosity";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "enzyme-assay";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "fish-interphase";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "fish-metaphase";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "flow-cytometry";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "fish";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "immunohistochemistry";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "karyotyping";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "linkage-analysis";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "methylation-analysis";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "msi";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "m-fish";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "mutation-scanning-of-select-exons";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "mutation-scanning-of-the-entire-coding-region";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "protein-analysis";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "protein-expression";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "rna-analysis";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "sequence-analysis-of-select-exons";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "sequence-analysis-of-the-entire-coding-region";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "sister-chromatid-exchange";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "targeted-variant-analysis";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "udp";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "aspe";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "alternative-splicing-detection";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "bi-directional-sanger-sequence-analysis";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "c-banding";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "cia";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "chromatin-immunoprecipitation-on-chip";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "comparative-genomic-hybridization";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "damid";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "digital-virtual-karyotyping";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "digital-microfluidic-microspheres";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "enzymatic-levels";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "enzyme-activity";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "elisa";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "fluorometry";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "fusion-genes-microarrays";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "g-banding";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "gc-ms";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "gene-expression-profiling";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "gene-id";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "gold-nanoparticle-probe-technology";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "hplc";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "lc-ms";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "lc-ms-ms";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "metabolite-levels";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "methylation-specific-pcr";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "microarray";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "mlpa";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "ngs-mps";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "ola";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "oligonucleotide-hybridization-based-dna-sequencing";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "other";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "pcr";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "pcr-with-allele-specific-hybridization";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "pcr-rflp-with-southern-hybridization";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "protein-truncation-test";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "pyrosequencing";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "q-banding";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "qpcr";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "r-banding";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "rflp";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "rt-lamp";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "rt-pcr";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "rt-pcr-with-gel-analysis";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "rt-qpcr";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "snp-detection";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "silver-staining";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "sky";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "t-banding";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "ms-ms";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "tetra-nucleotide-repeat-by-pcr-or-southern-blot";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "tiling-arrays";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "trinucleotide-repeat-by-pcr-or-southern-blot";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}, {
    readonly code: "uni-directional-sanger-sequencing";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/genomic-study-method-type-cs";
}];
/** String type (ValueSet too large for union type) */
export type GenomicStudyMethodTypeVSCode = string;
/** Type representing a concept from this ValueSet */
export type GenomicStudyMethodTypeVSConcept = typeof GenomicStudyMethodTypeVSConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidGenomicStudyMethodTypeVSCode(code: string): code is GenomicStudyMethodTypeVSCode;
/**
 * Get concept details by code
 */
export declare function getGenomicStudyMethodTypeVSConcept(code: string): GenomicStudyMethodTypeVSConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const GenomicStudyMethodTypeVSCodes: ("biochemical-genetics" | "cytogenetics" | "molecular-genetics" | "analyte" | "chromosome-breakage-studies" | "deletion-duplication-analysis" | "detection-of-homozygosity" | "enzyme-assay" | "fish-interphase" | "fish-metaphase" | "flow-cytometry" | "fish" | "immunohistochemistry" | "karyotyping" | "linkage-analysis" | "methylation-analysis" | "msi" | "m-fish" | "mutation-scanning-of-select-exons" | "mutation-scanning-of-the-entire-coding-region" | "protein-analysis" | "protein-expression" | "rna-analysis" | "sequence-analysis-of-select-exons" | "sequence-analysis-of-the-entire-coding-region" | "sister-chromatid-exchange" | "targeted-variant-analysis" | "udp" | "aspe" | "alternative-splicing-detection" | "bi-directional-sanger-sequence-analysis" | "c-banding" | "cia" | "chromatin-immunoprecipitation-on-chip" | "comparative-genomic-hybridization" | "damid" | "digital-virtual-karyotyping" | "digital-microfluidic-microspheres" | "enzymatic-levels" | "enzyme-activity" | "elisa" | "fluorometry" | "fusion-genes-microarrays" | "g-banding" | "gc-ms" | "gene-expression-profiling" | "gene-id" | "gold-nanoparticle-probe-technology" | "hplc" | "lc-ms" | "lc-ms-ms" | "metabolite-levels" | "methylation-specific-pcr" | "microarray" | "mlpa" | "ngs-mps" | "ola" | "oligonucleotide-hybridization-based-dna-sequencing" | "other" | "pcr" | "pcr-with-allele-specific-hybridization" | "pcr-rflp-with-southern-hybridization" | "protein-truncation-test" | "pyrosequencing" | "q-banding" | "qpcr" | "r-banding" | "rflp" | "rt-lamp" | "rt-pcr" | "rt-pcr-with-gel-analysis" | "rt-qpcr" | "snp-detection" | "silver-staining" | "sky" | "t-banding" | "ms-ms" | "tetra-nucleotide-repeat-by-pcr-or-southern-blot" | "tiling-arrays" | "trinucleotide-repeat-by-pcr-or-southern-blot" | "uni-directional-sanger-sequencing")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomGenomicStudyMethodTypeVSCode(): GenomicStudyMethodTypeVSCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomGenomicStudyMethodTypeVSConcept(): GenomicStudyMethodTypeVSConcept;
