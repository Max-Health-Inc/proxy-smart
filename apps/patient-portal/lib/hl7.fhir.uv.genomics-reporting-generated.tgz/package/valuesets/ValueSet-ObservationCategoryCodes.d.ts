/**
 * ValueSet: ObservationCategoryCodes
 * URL: http://hl7.org/fhir/ValueSet/observation-category
 * Size: 9 concepts
 */
export declare const ObservationCategoryCodesConcepts: readonly [{
    readonly code: "social-history";
    readonly system: "http://terminology.hl7.org/CodeSystem/observation-category";
    readonly display: "Social History";
}, {
    readonly code: "vital-signs";
    readonly system: "http://terminology.hl7.org/CodeSystem/observation-category";
    readonly display: "Vital Signs";
}, {
    readonly code: "imaging";
    readonly system: "http://terminology.hl7.org/CodeSystem/observation-category";
    readonly display: "Imaging";
}, {
    readonly code: "laboratory";
    readonly system: "http://terminology.hl7.org/CodeSystem/observation-category";
    readonly display: "Laboratory";
}, {
    readonly code: "procedure";
    readonly system: "http://terminology.hl7.org/CodeSystem/observation-category";
    readonly display: "Procedure";
}, {
    readonly code: "survey";
    readonly system: "http://terminology.hl7.org/CodeSystem/observation-category";
    readonly display: "Survey";
}, {
    readonly code: "exam";
    readonly system: "http://terminology.hl7.org/CodeSystem/observation-category";
    readonly display: "Exam";
}, {
    readonly code: "therapy";
    readonly system: "http://terminology.hl7.org/CodeSystem/observation-category";
    readonly display: "Therapy";
}, {
    readonly code: "activity";
    readonly system: "http://terminology.hl7.org/CodeSystem/observation-category";
    readonly display: "Activity";
}];
/** Union type of all valid codes in this ValueSet */
export type ObservationCategoryCodesCode = "social-history" | "vital-signs" | "imaging" | "laboratory" | "procedure" | "survey" | "exam" | "therapy" | "activity";
/** Type representing a concept from this ValueSet */
export type ObservationCategoryCodesConcept = typeof ObservationCategoryCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidObservationCategoryCodesCode(code: string): code is ObservationCategoryCodesCode;
/**
 * Get concept details by code
 */
export declare function getObservationCategoryCodesConcept(code: string): ObservationCategoryCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ObservationCategoryCodesCodes: ("laboratory" | "vital-signs" | "social-history" | "imaging" | "procedure" | "survey" | "exam" | "therapy" | "activity")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomObservationCategoryCodesCode(): ObservationCategoryCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomObservationCategoryCodesConcept(): ObservationCategoryCodesConcept;
