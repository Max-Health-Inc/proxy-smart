/**
 * ValueSet: VariantConfidenceStatusVS
 * URL: http://hl7.org/fhir/uv/genomics-reporting/ValueSet/variant-confidence-status-vs
 * Size: 3 concepts
 */
export const VariantConfidenceStatusVSConcepts = [
    { code: "high", system: "http://terminology.hl7.org/CodeSystem/variant-confidence-status-cs" },
    { code: "intermediate", system: "http://terminology.hl7.org/CodeSystem/variant-confidence-status-cs" },
    { code: "low", system: "http://terminology.hl7.org/CodeSystem/variant-confidence-status-cs" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidVariantConfidenceStatusVSCode(code) {
    return VariantConfidenceStatusVSConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getVariantConfidenceStatusVSConcept(code) {
    return VariantConfidenceStatusVSConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const VariantConfidenceStatusVSCodes = VariantConfidenceStatusVSConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomVariantConfidenceStatusVSCode() {
    return VariantConfidenceStatusVSCodes[Math.floor(Math.random() * VariantConfidenceStatusVSCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomVariantConfidenceStatusVSConcept() {
    return VariantConfidenceStatusVSConcepts[Math.floor(Math.random() * VariantConfidenceStatusVSConcepts.length)];
}
