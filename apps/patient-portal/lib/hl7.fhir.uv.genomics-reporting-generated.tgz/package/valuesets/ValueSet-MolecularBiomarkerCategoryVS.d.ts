/**
 * ValueSet: MolecularBiomarkerCategoryVS
 * URL: http://hl7.org/fhir/uv/genomics-reporting/ValueSet/molecular-biomarker-category-vs
 * Size: 17 concepts
 */
export declare const MolecularBiomarkerCategoryVSConcepts: readonly [{
    readonly code: "_physiologyBiomarkerCategory";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs";
}, {
    readonly code: "antibody";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs";
}, {
    readonly code: "antgen";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs";
}, {
    readonly code: "cellReceptor";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs";
}, {
    readonly code: "cellReceptorLigand";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs";
}, {
    readonly code: "_moleculeTypeBiomarkerCategory";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs";
}, {
    readonly code: "carbohydrate";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs";
}, {
    readonly code: "lipid";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs";
}, {
    readonly code: "nucleicAcid";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs";
}, {
    readonly code: "protein";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs";
}, {
    readonly code: "_methodBiomarkerCategory";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs";
}, {
    readonly code: "enzymeAssay";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs";
}, {
    readonly code: "flowCytometry";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs";
}, {
    readonly code: "immuneStain";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs";
}, {
    readonly code: "immunoassay";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs";
}, {
    readonly code: "methylationAnalysis";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs";
}, {
    readonly code: "molgen";
    readonly system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/molecular-biomarker-ontology-cs";
}];
/** Union type of all valid codes in this ValueSet */
export type MolecularBiomarkerCategoryVSCode = "_physiologyBiomarkerCategory" | "antibody" | "antgen" | "cellReceptor" | "cellReceptorLigand" | "_moleculeTypeBiomarkerCategory" | "carbohydrate" | "lipid" | "nucleicAcid" | "protein" | "_methodBiomarkerCategory" | "enzymeAssay" | "flowCytometry" | "immuneStain" | "immunoassay" | "methylationAnalysis" | "molgen";
/** Type representing a concept from this ValueSet */
export type MolecularBiomarkerCategoryVSConcept = typeof MolecularBiomarkerCategoryVSConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidMolecularBiomarkerCategoryVSCode(code: string): code is MolecularBiomarkerCategoryVSCode;
/**
 * Get concept details by code
 */
export declare function getMolecularBiomarkerCategoryVSConcept(code: string): MolecularBiomarkerCategoryVSConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const MolecularBiomarkerCategoryVSCodes: ("_physiologyBiomarkerCategory" | "antibody" | "antgen" | "cellReceptor" | "cellReceptorLigand" | "_moleculeTypeBiomarkerCategory" | "carbohydrate" | "lipid" | "nucleicAcid" | "protein" | "_methodBiomarkerCategory" | "enzymeAssay" | "flowCytometry" | "immuneStain" | "immunoassay" | "methylationAnalysis" | "molgen")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomMolecularBiomarkerCategoryVSCode(): MolecularBiomarkerCategoryVSCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomMolecularBiomarkerCategoryVSConcept(): MolecularBiomarkerCategoryVSConcept;
