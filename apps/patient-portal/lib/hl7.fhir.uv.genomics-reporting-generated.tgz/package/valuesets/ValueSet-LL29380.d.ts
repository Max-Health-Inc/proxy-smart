/**
 * ValueSet: LL2938-0
 * URL: http://loinc.org/vs/LL2938-0
 * Size: 24 concepts
 */
export declare const LL29380Concepts: readonly [{
    readonly code: "LA21254-0";
    readonly system: "http://loinc.org";
    readonly display: "Chromosome 1";
}, {
    readonly code: "LA21255-7";
    readonly system: "http://loinc.org";
    readonly display: "Chromosome 2";
}, {
    readonly code: "LA21256-5";
    readonly system: "http://loinc.org";
    readonly display: "Chromosome 3";
}, {
    readonly code: "LA21257-3";
    readonly system: "http://loinc.org";
    readonly display: "Chromosome 4";
}, {
    readonly code: "LA21258-1";
    readonly system: "http://loinc.org";
    readonly display: "Chromosome 5";
}, {
    readonly code: "LA21259-9";
    readonly system: "http://loinc.org";
    readonly display: "Chromosome 6";
}, {
    readonly code: "LA21260-7";
    readonly system: "http://loinc.org";
    readonly display: "Chromosome 7";
}, {
    readonly code: "LA21261-5";
    readonly system: "http://loinc.org";
    readonly display: "Chromosome 8";
}, {
    readonly code: "LA21262-3";
    readonly system: "http://loinc.org";
    readonly display: "Chromosome 9";
}, {
    readonly code: "LA21263-1";
    readonly system: "http://loinc.org";
    readonly display: "Chromosome 10";
}, {
    readonly code: "LA21264-9";
    readonly system: "http://loinc.org";
    readonly display: "Chromosome 11";
}, {
    readonly code: "LA21265-6";
    readonly system: "http://loinc.org";
    readonly display: "Chromosome 12";
}, {
    readonly code: "LA21266-4";
    readonly system: "http://loinc.org";
    readonly display: "Chromosome 13";
}, {
    readonly code: "LA21267-2";
    readonly system: "http://loinc.org";
    readonly display: "Chromosome 14";
}, {
    readonly code: "LA21268-0";
    readonly system: "http://loinc.org";
    readonly display: "Chromosome 15";
}, {
    readonly code: "LA21269-8";
    readonly system: "http://loinc.org";
    readonly display: "Chromosome 16";
}, {
    readonly code: "LA21270-6";
    readonly system: "http://loinc.org";
    readonly display: "Chromosome 17";
}, {
    readonly code: "LA21271-4";
    readonly system: "http://loinc.org";
    readonly display: "Chromosome 18";
}, {
    readonly code: "LA21272-2";
    readonly system: "http://loinc.org";
    readonly display: "Chromosome 19";
}, {
    readonly code: "LA21273-0";
    readonly system: "http://loinc.org";
    readonly display: "Chromosome 20";
}, {
    readonly code: "LA21274-8";
    readonly system: "http://loinc.org";
    readonly display: "Chromosome 21";
}, {
    readonly code: "LA21275-5";
    readonly system: "http://loinc.org";
    readonly display: "Chromosome 22";
}, {
    readonly code: "LA21276-3";
    readonly system: "http://loinc.org";
    readonly display: "Chromosome X";
}, {
    readonly code: "LA21277-1";
    readonly system: "http://loinc.org";
    readonly display: "Chromosome Y";
}];
/** String type (ValueSet too large for union type) */
export type LL29380Code = string;
/** Type representing a concept from this ValueSet */
export type LL29380Concept = typeof LL29380Concepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidLL29380Code(code: string): code is LL29380Code;
/**
 * Get concept details by code
 */
export declare function getLL29380Concept(code: string): LL29380Concept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const LL29380Codes: ("LA21254-0" | "LA21255-7" | "LA21256-5" | "LA21257-3" | "LA21258-1" | "LA21259-9" | "LA21260-7" | "LA21261-5" | "LA21262-3" | "LA21263-1" | "LA21264-9" | "LA21265-6" | "LA21266-4" | "LA21267-2" | "LA21268-0" | "LA21269-8" | "LA21270-6" | "LA21271-4" | "LA21272-2" | "LA21273-0" | "LA21274-8" | "LA21275-5" | "LA21276-3" | "LA21277-1")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomLL29380Code(): LL29380Code;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomLL29380Concept(): LL29380Concept;
