import { validateGenomicReport } from "./GenomicReport.js";
// Only import helpers actually referenced below (dynamic based on required fields)
import { randomId, setRandomSeed, enrichResource } from "./random/index.js";
import { createRequire } from 'module';
const __require = createRequire(import.meta.url);
function ensureProfile(res, profile) {
    if (!res.meta) {
        res.meta = { profile: [profile] };
        return;
    }
    if (!res.meta.profile) {
        res.meta.profile = [profile];
        return;
    }
    if (!res.meta.profile.includes(profile)) {
        res.meta.profile = [...res.meta.profile, profile];
    }
}
// Internal helper (emitted per class file) to clone without resorting to 'any'.
function safeClone(value) {
    // Use native structuredClone if present; otherwise fallback to JSON round-trip.
    // We intentionally avoid casting through any to satisfy no-explicit-any lint rule.
    const g = globalThis;
    // Narrow globalThis to an object potentially containing structuredClone.
    if (typeof g.structuredClone === 'function') {
        return g.structuredClone(value);
    }
    return JSON.parse(JSON.stringify(value)); // best-effort deep clone
}
export class GenomicReportClass {
    constructor(resource) {
        this.resource = resource;
        ensureProfile(this.resource, 'http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-report');
    }
    /** Validate current resource instance. */
    async validate(options) {
        return validateGenomicReport(this.resource, options);
    }
    getResource() {
        return this.resource;
    }
    setResource(resource) {
        this.resource = resource;
        ensureProfile(this.resource, 'http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-report');
    }
    /**
     * Returns a plain JSON clone of the underlying resource ONLY if the last validation succeeded with zero errors.
     * Call validate() first; otherwise this method throws to prevent accidental use of invalid / unchecked data.
     */
    async toJSON() {
        return safeClone(this.resource);
    }
    /**
     * Create an empty instance for parity testing: for true FHIR resources, includes only resourceType; for datatypes, returns an empty object.
     * Note: meta.profile (when applicable) will be ensured by the constructor when wrapping this resource.
     */
    static empty(overrides = {}) {
        // For Resource profiles, include only resourceType. For Extension profiles, include url so the instance is minimally meaningful.
        const base = {
            resourceType: 'DiagnosticReport',
        };
        return { ...base, ...overrides };
    }
    /**
     * Create a minimal randomized instance of GenomicReport.
     * Populates id, resourceType (if applicable) and primitive required (min>0) top-level fields with placeholders.
     */
    static random(overrides = {}, opts) {
        if (opts?.seed !== undefined) {
            // Direct call (no dynamic require) to ensure deterministic seeding works under ESM.
            setRandomSeed(opts.seed);
        }
        // Start with a Partial to avoid unsafe casting errors; we'll assert at the end.
        const base = { resourceType: 'DiagnosticReport', id: randomId(), status: "registered", category: [{ "coding": [{ "system": "http://terminology.hl7.org/CodeSystem/v2-0074", "code": "AU" }] }], code: { coding: [{ system: "http://loinc.org", code: "51969-4" }] }, };
        // Always include meta.profile with this profile's canonical URL if available & only for resource profiles
        ensureProfile(base, 'http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-report');
        // Enrich the base resource with common fields using centralized enrichment logic
        enrichResource(base, 'DiagnosticReport', 'http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-report', GenomicReportClass._fieldPatterns, GenomicReportClass._forbiddenFields, GenomicReportClass.valueSetBindings, GenomicReportClass._codeResolver, GenomicReportClass._fieldOrder);
        // Cast through unknown to acknowledge dynamic enrichment
        return { ...base, ...overrides };
    }
    /** Convenience: returns a class instance wrapping a randomized resource. */
    static randomClass(overrides = {}, opts) {
        return new GenomicReportClass(this.random(overrides, opts));
    }
}
/** Pattern constraints for profile fields (used by random() generator) */
GenomicReportClass._fieldPatterns = {
    "category": {
        "coding": [
            {
                "system": "http://terminology.hl7.org/CodeSystem/v2-0074",
                "code": "GE"
            }
        ]
    },
    "code": {
        "coding": [
            {
                "system": "http://loinc.org",
                "code": "51969-4"
            }
        ]
    },
    "_refReq_category": {
        "coding": true
    },
    "_refReq_media": {
        "link": true
    },
    "_choiceType_effective[x]": [
        "dateTime"
    ]
};
/** Fields that are forbidden (max=0) in this profile - must not be generated */
GenomicReportClass._forbiddenFields = [];
/** FHIR element ordering for this profile's base resource (used by enrichResource for correct JSON field order) */
GenomicReportClass._fieldOrder = ["id", "meta", "implicitRules", "language", "text", "contained", "extension", "modifierExtension", "identifier", "basedOn", "status", "category", "code", "subject", "encounter", "effective[x]", "issued", "performer", "resultsInterpreter", "specimen", "result", "imagingStudy", "media", "conclusion", "conclusionCode", "presentedForm"];
/** ValueSet bindings for coded fields - maps field name to ValueSet URL */
GenomicReportClass.valueSetBindings = {
    "language": "http://hl7.org/fhir/ValueSet/languages",
    "status": "http://hl7.org/fhir/ValueSet/diagnostic-report-status|4.0.1",
    "category": "http://hl7.org/fhir/ValueSet/diagnostic-service-sections",
    "code": "http://hl7.org/fhir/ValueSet/report-codes",
    "conclusionCode": "http://hl7.org/fhir/ValueSet/clinical-findings"
};
/** Code resolver for ValueSet bindings - returns a random valid code from a ValueSet by URL */
GenomicReportClass._codeResolver = (() => {
    // Try to load the ValueSetRegistry - it may not exist if no ValueSets were generated
    try {
        const registry = __require('./valuesets/index.js');
        if (registry && typeof registry.getRandomConceptByUrl === 'function') {
            return registry.getRandomConceptByUrl;
        }
    }
    catch { /* ValueSetRegistry not available */ }
    return undefined;
})();
