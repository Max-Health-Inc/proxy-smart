import { Extension } from "fhir/r4";
export interface GenomicStudyAnalysisGenomicSourceClass extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-analysis-genomic-source-class";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateGenomicStudyAnalysisGenomicSourceClass(resource: GenomicStudyAnalysisGenomicSourceClass, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
