import { Extension } from "fhir/r4";
export interface GenomicStudyAnalysisInput extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-analysis-input";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateGenomicStudyAnalysisInput(resource: GenomicStudyAnalysisInput, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
