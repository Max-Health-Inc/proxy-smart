import { Extension } from "fhir/r4";
export interface TherapyAssessedReference extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/therapy-assessed-reference";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateTherapyAssessedReference(resource: TherapyAssessedReference, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
