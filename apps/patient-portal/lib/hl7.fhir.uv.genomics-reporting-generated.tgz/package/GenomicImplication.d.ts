import { BodyStructureReference } from "./BodyStructureReference";
import { CodeableConcept, Extension, Observation, ObservationComponent, Reference } from "fhir/r4";
import { RelatedArtifactComponent } from "./RelatedArtifactComponent";
import { RelatedArtifactExtension } from "./RelatedArtifactExtension";
import { SecondaryFinding } from "./SecondaryFinding";
export interface WorkflowRelatedArtifactComponent extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/workflow-relatedArtifactComponent';
}
export interface GenomicImplicationComponent extends Omit<ObservationComponent, 'code' | 'extension'> {
    /** @see {@link ./valuesets/ValueSet-ObservationCodes.ts} for valid codes (100 codes) */
    code: CodeableConcept;
    extension?: (Extension | RelatedArtifactComponent | RelatedArtifactComponent)[];
}
export interface GenomicImplication extends Omit<Observation, 'derivedFrom' | 'component' | 'extension'> {
    derivedFrom: Reference[];
    component?: GenomicImplicationComponent[];
    extension?: (Extension | SecondaryFinding | BodyStructureReference | RelatedArtifactExtension)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateGenomicImplication(resource: GenomicImplication, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
