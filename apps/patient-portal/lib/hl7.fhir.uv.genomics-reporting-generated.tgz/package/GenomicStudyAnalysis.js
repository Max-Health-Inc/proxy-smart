import fhirpath from "fhirpath";
import fhirpath_model from "fhirpath/fhir-context/r4/index.js";
import { isValidEventStatusCode } from './valuesets/ValueSet-EventStatus.js';
export async function validateGenomicStudyAnalysis(resource, options) {
    const errors = [];
    const warnings = [];
    const fhirpathOptions = {
        preciseMath: true,
        traceFn: options?.traceFn ?? (() => { }),
        ...(options?.signal ? { signal: options.signal } : {}),
        ...(options?.httpHeaders ? { httpHeaders: options.httpHeaders } : {}),
    };
    const result0 = await fhirpath.evaluate(resource, "Procedure.all(contained.contained.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result0.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL NOT contain nested Resources");
    }
    const result1 = await fhirpath.evaluate(resource, "Procedure.all(contained.where((('#'+id in (%resource.descendants().reference | %resource.descendants().as(canonical) | %resource.descendants().as(uri) | %resource.descendants().as(url))) or descendants().where(reference = '#').exists() or descendants().where(as(canonical) = '#').exists() or descendants().where(as(canonical) = '#').exists()).not()).trace('unmatched', id).empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result1.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL be referred to from elsewhere in the resource or SHALL refer to the containing resource");
    }
    const result2 = await fhirpath.evaluate(resource, "Procedure.all(contained.meta.versionId.empty() and contained.meta.lastUpdated.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result2.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a meta.versionId or a meta.lastUpdated");
    }
    const result3 = await fhirpath.evaluate(resource, "Procedure.all(contained.meta.security.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result3.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a security label");
    }
    const result4 = await fhirpath.evaluate(resource, "Procedure.all(text.`div`.exists())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result4.every(Boolean)) {
        warnings.push("Constraint violation: A resource should have narrative for robust management");
    }
    const result5 = await fhirpath.evaluate(resource, "meta.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result5.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result6 = await fhirpath.evaluate(resource, "implicitRules.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result6.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result7 = await fhirpath.evaluate(resource, "language.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result7.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result8 = await fhirpath.evaluate(resource, "text.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result8.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result9 = await fhirpath.evaluate(resource, "extension.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result9.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result10 = await fhirpath.evaluate(resource, "modifierExtension.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result10.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result11 = await fhirpath.evaluate(resource, "identifier.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result11.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result12 = await fhirpath.evaluate(resource, "instantiatesCanonical.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result12.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result13 = await fhirpath.evaluate(resource, "instantiatesUri.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result13.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result14 = await fhirpath.evaluate(resource, "basedOn.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result14.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result15 = await fhirpath.evaluate(resource, "partOf.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result15.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result16 = await fhirpath.evaluate(resource, "status.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result16.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result17 = await fhirpath.evaluate(resource, "statusReason.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result17.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result18 = await fhirpath.evaluate(resource, "category.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result18.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result19 = await fhirpath.evaluate(resource, "code.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result19.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result20 = await fhirpath.evaluate(resource, "subject.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result20.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result21 = await fhirpath.evaluate(resource, "encounter.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result21.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result22 = await fhirpath.evaluate(resource, "performedDateTime.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result22.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result23 = await fhirpath.evaluate(resource, "recorder.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result23.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result24 = await fhirpath.evaluate(resource, "asserter.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result24.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result25 = await fhirpath.evaluate(resource, "performer.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result25.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result26 = await fhirpath.evaluate(resource, "location.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result26.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result27 = await fhirpath.evaluate(resource, "reasonCode.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result27.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result28 = await fhirpath.evaluate(resource, "reasonReference.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result28.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result29 = await fhirpath.evaluate(resource, "bodySite.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result29.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result30 = await fhirpath.evaluate(resource, "outcome.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result30.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result31 = await fhirpath.evaluate(resource, "report.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result31.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result32 = await fhirpath.evaluate(resource, "complication.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result32.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result33 = await fhirpath.evaluate(resource, "complicationDetail.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result33.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result34 = await fhirpath.evaluate(resource, "followUp.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result34.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result35 = await fhirpath.evaluate(resource, "note.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result35.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result36 = await fhirpath.evaluate(resource, "focalDevice.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result36.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result37 = await fhirpath.evaluate(resource, "usedReference.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result37.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result38 = await fhirpath.evaluate(resource, "usedCode.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result38.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result39 = await fhirpath.evaluate(resource, "DomainResource.all(contained.contained.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result39.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL NOT contain nested Resources");
    }
    const result40 = await fhirpath.evaluate(resource, "DomainResource.all(contained.where((('#'+id in (%resource.descendants().reference | %resource.descendants().as(canonical) | %resource.descendants().as(uri) | %resource.descendants().as(url))) or descendants().where(reference = '#').exists() or descendants().where(as(canonical) = '#').exists() or descendants().where(as(canonical) = '#').exists()).not()).trace('unmatched', id).empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result40.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL be referred to from elsewhere in the resource or SHALL refer to the containing resource");
    }
    const result41 = await fhirpath.evaluate(resource, "DomainResource.all(contained.meta.versionId.empty() and contained.meta.lastUpdated.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result41.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a meta.versionId or a meta.lastUpdated");
    }
    const result42 = await fhirpath.evaluate(resource, "DomainResource.all(contained.meta.security.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result42.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a security label");
    }
    const result43 = await fhirpath.evaluate(resource, "DomainResource.all(text.`div`.exists())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result43.every(Boolean)) {
        warnings.push("Constraint violation: A resource should have narrative for robust management");
    }
    const result44 = await fhirpath.evaluate(resource, "status.exists()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result44.every(Boolean)) {
        errors.push("Constraint violation: status must be present");
    }
    const result45 = await fhirpath.evaluate(resource, "category.exists()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result45.every(Boolean)) {
        errors.push("Constraint violation: category must be present");
    }
    const result46 = await fhirpath.evaluate(resource, "subject.exists()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result46.every(Boolean)) {
        errors.push("Constraint violation: subject must be present");
    }
    const result47 = await fhirpath.evaluate(resource, "basedOn.count() <= 0", { resource }, fhirpath_model, fhirpathOptions);
    if (!result47.every(Boolean)) {
        errors.push("Constraint violation: basedOn must contain at most 0 elements");
    }
    const result48 = await fhirpath.evaluate(resource, "partOf.count() <= 0", { resource }, fhirpath_model, fhirpathOptions);
    if (!result48.every(Boolean)) {
        errors.push("Constraint violation: partOf must contain at most 0 elements");
    }
    const result49 = await fhirpath.evaluate(resource, "reasonCode.count() <= 0", { resource }, fhirpath_model, fhirpathOptions);
    if (!result49.every(Boolean)) {
        errors.push("Constraint violation: reasonCode must contain at most 0 elements");
    }
    const result50 = await fhirpath.evaluate(resource, "reasonReference.count() <= 0", { resource }, fhirpath_model, fhirpathOptions);
    if (!result50.every(Boolean)) {
        errors.push("Constraint violation: reasonReference must contain at most 0 elements");
    }
    const result51 = await fhirpath.evaluate(resource, "bodySite.count() <= 0", { resource }, fhirpath_model, fhirpathOptions);
    if (!result51.every(Boolean)) {
        errors.push("Constraint violation: bodySite must contain at most 0 elements");
    }
    const result52 = await fhirpath.evaluate(resource, "report.count() <= 0", { resource }, fhirpath_model, fhirpathOptions);
    if (!result52.every(Boolean)) {
        errors.push("Constraint violation: report must contain at most 0 elements");
    }
    const result53 = await fhirpath.evaluate(resource, "complication.count() <= 0", { resource }, fhirpath_model, fhirpathOptions);
    if (!result53.every(Boolean)) {
        errors.push("Constraint violation: complication must contain at most 0 elements");
    }
    const result54 = await fhirpath.evaluate(resource, "complicationDetail.count() <= 0", { resource }, fhirpath_model, fhirpathOptions);
    if (!result54.every(Boolean)) {
        errors.push("Constraint violation: complicationDetail must contain at most 0 elements");
    }
    const result55 = await fhirpath.evaluate(resource, "followUp.count() <= 0", { resource }, fhirpath_model, fhirpathOptions);
    if (!result55.every(Boolean)) {
        errors.push("Constraint violation: followUp must contain at most 0 elements");
    }
    const result56 = await fhirpath.evaluate(resource, "focalDevice.count() <= 0", { resource }, fhirpath_model, fhirpathOptions);
    if (!result56.every(Boolean)) {
        errors.push("Constraint violation: focalDevice must contain at most 0 elements");
    }
    const result57 = await fhirpath.evaluate(resource, "usedReference.count() <= 0", { resource }, fhirpath_model, fhirpathOptions);
    if (!result57.every(Boolean)) {
        errors.push("Constraint violation: usedReference must contain at most 0 elements");
    }
    const result58 = await fhirpath.evaluate(resource, "usedCode.count() <= 0", { resource }, fhirpath_model, fhirpathOptions);
    if (!result58.every(Boolean)) {
        errors.push("Constraint violation: usedCode must contain at most 0 elements");
    }
    const result59 = await fhirpath.evaluate(resource, "basedOn.exists().not()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result59.every(Boolean)) {
        errors.push("Constraint violation: basedOn: max allowed = 0, but found 1");
    }
    const result60 = await fhirpath.evaluate(resource, "partOf.exists().not()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result60.every(Boolean)) {
        errors.push("Constraint violation: partOf: max allowed = 0, but found 1");
    }
    const result61 = await fhirpath.evaluate(resource, "statusReason.exists().not()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result61.every(Boolean)) {
        errors.push("Constraint violation: statusReason: max allowed = 0, but found 1");
    }
    const result62 = await fhirpath.evaluate(resource, "code.exists().not()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result62.every(Boolean)) {
        errors.push("Constraint violation: code: max allowed = 0, but found 1");
    }
    const result63 = await fhirpath.evaluate(resource, "encounter.exists().not()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result63.every(Boolean)) {
        errors.push("Constraint violation: encounter: max allowed = 0, but found 1");
    }
    const result64 = await fhirpath.evaluate(resource, "recorder.exists().not()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result64.every(Boolean)) {
        errors.push("Constraint violation: recorder: max allowed = 0, but found 1");
    }
    const result65 = await fhirpath.evaluate(resource, "asserter.exists().not()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result65.every(Boolean)) {
        errors.push("Constraint violation: asserter: max allowed = 0, but found 1");
    }
    const result66 = await fhirpath.evaluate(resource, "location.exists().not()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result66.every(Boolean)) {
        errors.push("Constraint violation: location: max allowed = 0, but found 1");
    }
    const result67 = await fhirpath.evaluate(resource, "reasonCode.exists().not()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result67.every(Boolean)) {
        errors.push("Constraint violation: reasonCode: max allowed = 0, but found 1");
    }
    const result68 = await fhirpath.evaluate(resource, "reasonReference.exists().not()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result68.every(Boolean)) {
        errors.push("Constraint violation: reasonReference: max allowed = 0, but found 1");
    }
    const result69 = await fhirpath.evaluate(resource, "bodySite.exists().not()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result69.every(Boolean)) {
        errors.push("Constraint violation: bodySite: max allowed = 0, but found 1");
    }
    const result70 = await fhirpath.evaluate(resource, "outcome.exists().not()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result70.every(Boolean)) {
        errors.push("Constraint violation: outcome: max allowed = 0, but found 1");
    }
    const result71 = await fhirpath.evaluate(resource, "report.exists().not()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result71.every(Boolean)) {
        errors.push("Constraint violation: report: max allowed = 0, but found 1");
    }
    const result72 = await fhirpath.evaluate(resource, "complication.exists().not()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result72.every(Boolean)) {
        errors.push("Constraint violation: complication: max allowed = 0, but found 1");
    }
    const result73 = await fhirpath.evaluate(resource, "complicationDetail.exists().not()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result73.every(Boolean)) {
        errors.push("Constraint violation: complicationDetail: max allowed = 0, but found 1");
    }
    const result74 = await fhirpath.evaluate(resource, "followUp.exists().not()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result74.every(Boolean)) {
        errors.push("Constraint violation: followUp: max allowed = 0, but found 1");
    }
    const result75 = await fhirpath.evaluate(resource, "focalDevice.exists().not()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result75.every(Boolean)) {
        errors.push("Constraint violation: focalDevice: max allowed = 0, but found 1");
    }
    const result76 = await fhirpath.evaluate(resource, "usedReference.exists().not()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result76.every(Boolean)) {
        errors.push("Constraint violation: usedReference: max allowed = 0, but found 1");
    }
    const result77 = await fhirpath.evaluate(resource, "usedCode.exists().not()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result77.every(Boolean)) {
        errors.push("Constraint violation: usedCode: max allowed = 0, but found 1");
    }
    // Nested required field: performer.actor (min=1)
    if (resource.performer && Array.isArray(resource.performer)) {
        for (const _el of resource.performer) {
            if ((_el.actor === undefined || _el.actor === null) || Array.isArray(_el.actor)) {
                errors.push("Missing required member: 'actor'");
            }
        }
    }
    // Nested required field: focalDevice.manipulated (min=1)
    if (resource.focalDevice && Array.isArray(resource.focalDevice)) {
        for (const _el of resource.focalDevice) {
            if ((_el.manipulated === undefined || _el.manipulated === null) || Array.isArray(_el.manipulated)) {
                errors.push("Missing required member: 'manipulated'");
            }
        }
    }
    // Fixed value constraint for status
    if (resource.status !== undefined && resource.status !== "completed") {
        errors.push("status must have the fixed value 'completed'");
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const _bRes = resource;
    // Prohibited field: Procedure.basedOn (max=0)
    if (_bRes.basedOn !== undefined) {
        errors.push("Procedure.basedOn: max allowed = 0, but found 1");
    }
    // Prohibited field: Procedure.partOf (max=0)
    if (_bRes.partOf !== undefined) {
        errors.push("Procedure.partOf: max allowed = 0, but found 1");
    }
    // Prohibited field: Procedure.statusReason (max=0)
    if (_bRes.statusReason !== undefined) {
        errors.push("Procedure.statusReason: max allowed = 0, but found 1");
    }
    // Prohibited field: Procedure.code (max=0)
    if (_bRes.code !== undefined) {
        errors.push("Procedure.code: max allowed = 0, but found 1");
    }
    // Prohibited field: Procedure.encounter (max=0)
    if (_bRes.encounter !== undefined) {
        errors.push("Procedure.encounter: max allowed = 0, but found 1");
    }
    // Prohibited field: Procedure.recorder (max=0)
    if (_bRes.recorder !== undefined) {
        errors.push("Procedure.recorder: max allowed = 0, but found 1");
    }
    // Prohibited field: Procedure.asserter (max=0)
    if (_bRes.asserter !== undefined) {
        errors.push("Procedure.asserter: max allowed = 0, but found 1");
    }
    // Prohibited field: Procedure.location (max=0)
    if (_bRes.location !== undefined) {
        errors.push("Procedure.location: max allowed = 0, but found 1");
    }
    // Prohibited field: Procedure.reasonCode (max=0)
    if (_bRes.reasonCode !== undefined) {
        errors.push("Procedure.reasonCode: max allowed = 0, but found 1");
    }
    // Prohibited field: Procedure.reasonReference (max=0)
    if (_bRes.reasonReference !== undefined) {
        errors.push("Procedure.reasonReference: max allowed = 0, but found 1");
    }
    // Prohibited field: Procedure.bodySite (max=0)
    if (_bRes.bodySite !== undefined) {
        errors.push("Procedure.bodySite: max allowed = 0, but found 1");
    }
    // Prohibited field: Procedure.outcome (max=0)
    if (_bRes.outcome !== undefined) {
        errors.push("Procedure.outcome: max allowed = 0, but found 1");
    }
    // Prohibited field: Procedure.report (max=0)
    if (_bRes.report !== undefined) {
        errors.push("Procedure.report: max allowed = 0, but found 1");
    }
    // Prohibited field: Procedure.complication (max=0)
    if (_bRes.complication !== undefined) {
        errors.push("Procedure.complication: max allowed = 0, but found 1");
    }
    // Prohibited field: Procedure.complicationDetail (max=0)
    if (_bRes.complicationDetail !== undefined) {
        errors.push("Procedure.complicationDetail: max allowed = 0, but found 1");
    }
    // Prohibited field: Procedure.followUp (max=0)
    if (_bRes.followUp !== undefined) {
        errors.push("Procedure.followUp: max allowed = 0, but found 1");
    }
    // Prohibited field: Procedure.focalDevice (max=0)
    if (_bRes.focalDevice !== undefined) {
        errors.push("Procedure.focalDevice: max allowed = 0, but found 1");
    }
    // Prohibited field: Procedure.usedReference (max=0)
    if (_bRes.usedReference !== undefined) {
        errors.push("Procedure.usedReference: max allowed = 0, but found 1");
    }
    // Prohibited field: Procedure.usedCode (max=0)
    if (_bRes.usedCode !== undefined) {
        errors.push("Procedure.usedCode: max allowed = 0, but found 1");
    }
    // Required ValueSet binding validation for status
    if (_bRes.status !== undefined && !isValidEventStatusCode(_bRes.status)) {
        errors.push("Code '" + _bRes.status + "' does not exist in the value set 'event-status' (http://hl7.org/fhir/ValueSet/event-status), but the binding is of strength 'required'");
    }
    // dateTime format validation for performedDateTime (choice type)
    if (typeof _bRes.performedDateTime === 'string' && !/^\d{4}(-\d{2}(-\d{2}(T\d{2}:\d{2}(:\d{2}(\.\d+)?)?(Z|[+-]\d{2}:\d{2})?)?)?)?$/.test(_bRes.performedDateTime)) {
        errors.push("Not a valid date/time format: '" + _bRes.performedDateTime + "'");
    }
    // Choice-type narrowing: performed[x] allows only: dateTime
    {
        const _ckAllowed = ['performedDateTime'];
        for (const _ckKey of Object.keys(_bRes)) {
            if (_ckKey.startsWith('performed') && _ckKey.length > 9 && _ckKey.charCodeAt(9) >= 65 && _ckKey.charCodeAt(9) <= 90 && !_ckAllowed.includes(_ckKey) && _bRes[_ckKey] !== undefined) {
                errors.push("The Profile 'http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-analysis' definition allows for the type dateTime but found type " + _ckKey.substring(9));
            }
        }
    }
    // Base FHIR structural validation: extension.url required, ext-1 constraint, empty objects
    {
        const _checkExtensions = (obj, path, depth) => {
            if (!obj || typeof obj !== 'object')
                return;
            if (Array.isArray(obj)) {
                obj.forEach((item, i) => _checkExtensions(item, path + '[' + i + ']', depth + 1));
                return;
            }
            const rec = obj;
            // Empty object check — HL7 validates all FHIR elements must have content
            if (depth > 0 && Object.keys(rec).length === 0) {
                errors.push('Object must have some content');
            }
            // per-1: If present, start SHALL have a lower value than end (Period structural check)
            if (typeof rec.start === 'string' && typeof rec.end === 'string' && rec.start > rec.end) {
                errors.push('If present, start SHALL have a lower value than end');
            }
            // Validate extension arrays
            for (const extKey of ['extension', 'modifierExtension']) {
                const exts = rec[extKey];
                if (Array.isArray(exts)) {
                    for (const ext of exts) {
                        if (ext && typeof ext === 'object' && !Array.isArray(ext)) {
                            const e = ext;
                            if (typeof e.url !== 'string' || !e.url) {
                                errors.push('Extension.url is required in order to identify, use and validate the extension');
                            }
                            // ext-1: Must have either extensions or value[x], not both
                            const hasNestedExt = Array.isArray(e.extension) && e.extension.length > 0;
                            const hasValue = Object.keys(e).some(k => k.startsWith('value') && k !== 'value' && k.length > 5);
                            if (hasNestedExt && hasValue) {
                                errors.push('Must have either extensions or value[x], not both');
                            }
                        }
                    }
                }
            }
            // Recurse into child objects (skip primitive values)
            for (const [_key, _val] of Object.entries(rec)) {
                if (_val && typeof _val === 'object') {
                    _checkExtensions(_val, path + '.' + _key, depth + 1);
                }
            }
        };
        _checkExtensions(resource, '', 0);
    }
    // Standalone contained reference resolution: verify #id references resolve to contained[] entries
    {
        const _res = resource;
        const _containedIds = new Set();
        if (Array.isArray(_res.contained)) {
            for (const _c of _res.contained) {
                if (_c && typeof _c.id === 'string')
                    _containedIds.add(_c.id);
            }
        }
        const _checkContainedRef = (obj) => {
            if (!obj || typeof obj !== 'object')
                return;
            if (Array.isArray(obj)) {
                obj.forEach(_checkContainedRef);
                return;
            }
            const _rec = obj;
            if (typeof _rec.reference === 'string') {
                const _ref = _rec.reference;
                if (_ref.startsWith('#')) {
                    const _id = _ref.substring(1);
                    if (_id && !_containedIds.has(_id)) {
                        errors.push('Contained reference not found: ' + _ref);
                    }
                }
            }
            for (const [_k, _v] of Object.entries(_rec)) {
                if (_k !== 'contained')
                    _checkContainedRef(_v);
            }
        };
        _checkContainedRef(_res);
    }
    return { errors, warnings };
}
