import { Extension } from "fhir/r4";
export interface ContainedReference extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/us/davinci-dtr/StructureDefinition/containedReference";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateContainedReference(resource: ContainedReference, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
