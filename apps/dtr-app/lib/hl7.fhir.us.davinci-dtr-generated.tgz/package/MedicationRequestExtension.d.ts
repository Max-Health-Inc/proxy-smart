import { ConditionCodeCode } from "./valuesets/ValueSet-ConditionCode";
import { CoverageInformation } from "./CoverageInformation";
import { CodeableConcept, Dosage, Extension, Identifier, MedicationRequest, MedicationRequestDispenseRequest, MedicationRequestSubstitution, Reference, SimpleQuantity } from "fhir/r4";
export interface MedicationRequestExtensionDosageInstruction extends Omit<Dosage, 'text' | 'maxDosePerAdministration' | 'maxDosePerLifetime'> {
    /** Must Support */
    text?: string;
    maxDosePerAdministration?: SimpleQuantity;
    maxDosePerLifetime?: SimpleQuantity;
}
export interface MedicationRequestExtensionDispenseRequest extends Omit<MedicationRequestDispenseRequest, 'quantity'> {
    quantity?: SimpleQuantity;
}
export interface MedicationRequestExtension extends Omit<MedicationRequest, 'identifier' | 'status' | 'subject' | 'encounter' | 'requester' | 'performer' | 'reasonCode' | 'reasonReference' | 'dosageInstruction' | 'dispenseRequest' | 'substitution' | 'priorPrescription' | 'extension'> {
    resourceType: 'MedicationRequest';
    /** Must Support */
    identifier?: Identifier[];
    status: "draft";
    /** Must Support */
    subject: Reference;
    /** Must Support */
    encounter?: Reference;
    /** Must Support */
    requester: Reference;
    /** Must Support */
    performer?: Reference;
    /** Must Support | @see {@link ./valuesets/ValueSet-ConditionCode.ts} for valid codes (1 codes) */
    reasonCode?: CodeableConcept & {
        coding: Array<{
            code: ConditionCodeCode;
            system: "http://snomed.info/sct";
        }>;
    }[];
    /** Must Support */
    reasonReference?: Reference[];
    /** Must Support */
    dosageInstruction?: MedicationRequestExtensionDosageInstruction[];
    /** Must Support */
    dispenseRequest?: MedicationRequestExtensionDispenseRequest;
    /** Must Support */
    substitution?: MedicationRequestSubstitution;
    /** Must Support */
    priorPrescription?: Reference;
    extension?: (Extension | CoverageInformation)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateMedicationRequestExtension(resource: MedicationRequestExtension, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
