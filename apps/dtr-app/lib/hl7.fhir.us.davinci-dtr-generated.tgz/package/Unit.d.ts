import { Coding, Extension } from "fhir/r4";
export interface Unit extends Omit<Extension, 'url' | 'value'> {
    url: "http://hl7.org/fhir/StructureDefinition/questionnaire-unit";
    value: Coding;
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateUnit(resource: Unit, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
