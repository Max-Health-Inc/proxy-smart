import { Extension } from "fhir/r4";
export interface OrdinalValue extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/StructureDefinition/ordinalValue";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateOrdinalValue(resource: OrdinalValue, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
