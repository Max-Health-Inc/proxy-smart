import { Extension } from "fhir/r4";
export interface ContextExpressionExtension extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-contextExpression";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateContextExpressionExtension(resource: ContextExpressionExtension, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
