import { FhirReadClient as BaseFhirReadClient, FhirWriteClient as BaseFhirWriteClient, } from "@babelfhir-ts/client-r4";
/**
 * Profile-specific FHIR Read Client.
 * Extends the base R4 read client with typed profile accessors.
 * Inherits all base R4 resource methods from @babelfhir-ts/client-r4.
 */
export class FhirReadClient extends BaseFhirReadClient {
    dTRLogErrorsInputParameters() {
        return this.forType("Parameters");
    }
    dTRQuestionnaireAdapt() {
        return this.forType("Questionnaire");
    }
    dTRQuestionnaireAdaptSearch() {
        return this.forType("Questionnaire");
    }
    dTRQuestionnairePackageBundle() {
        return this.forType("Bundle");
    }
    dTRQuestionnairePackageInputParameters() {
        return this.forType("Parameters");
    }
    dTRQuestionnairePackageOutputParameters() {
        return this.forType("Parameters");
    }
    dTRQuestionnaireResponse() {
        return this.forType("QuestionnaireResponse");
    }
    dTRQuestionnaireResponseBundle() {
        return this.forType("Bundle");
    }
    dTRStdQuestionnaire() {
        return this.forType("Questionnaire");
    }
}
/**
 * Profile-specific FHIR Write Client.
 * Extends the base R4 write client with typed profile accessors.
 * Inherits all base R4 resource methods from @babelfhir-ts/client-r4.
 */
export class FhirWriteClient extends BaseFhirWriteClient {
    dTRLogErrorsInputParameters() {
        return this.forType("Parameters");
    }
    dTRQuestionnaireAdapt() {
        return this.forType("Questionnaire");
    }
    dTRQuestionnaireAdaptSearch() {
        return this.forType("Questionnaire");
    }
    dTRQuestionnairePackageBundle() {
        return this.forType("Bundle");
    }
    dTRQuestionnairePackageInputParameters() {
        return this.forType("Parameters");
    }
    dTRQuestionnairePackageOutputParameters() {
        return this.forType("Parameters");
    }
    dTRQuestionnaireResponse() {
        return this.forType("QuestionnaireResponse");
    }
    dTRQuestionnaireResponseBundle() {
        return this.forType("Bundle");
    }
    dTRStdQuestionnaire() {
        return this.forType("Questionnaire");
    }
}
/**
 * Main FHIR Client — works with plain fetch or an authenticated fetch wrapper.
 * Provides both base R4 accessors (inherited) and profile-specific accessors.
 *
 * @example
 * // Unauthenticated
 * const client = new FhirClient("https://fhir.example.com");
 *
 * // With custom fetch (e.g. from SmartFhirClient)
 * const client = new FhirClient("https://fhir.example.com", authenticatedFetch);
 *
 * // Base R4 methods (inherited from @babelfhir-ts/client-r4)
 * const pt = await client.read().patient().read("123");
 *
 * // Profile-specific methods (generated)
 * const claim = await client.read().pASClaim().search({ status: "active" });
 */
export class FhirClient {
    constructor(baseUrl, fetchFn) {
        this.baseUrl = baseUrl;
        this.readClient = new FhirReadClient(baseUrl, fetchFn);
        this.writeClient = new FhirWriteClient(baseUrl, fetchFn);
    }
    /**
     * Get a read client for querying resources
     */
    read() {
        return this.readClient;
    }
    /**
     * Get a write client for creating/updating resources
     */
    write() {
        return this.writeClient;
    }
}
