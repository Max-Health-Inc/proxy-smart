import type * as GeneratedTypes from "../index.js";
import type { Bundle, SearchParams, WithId } from "./types.js";
/**
 * Generic FHIR resource searcher/reader
 */
export interface FhirResourceSearcher<T> {
    readonly baseUrl: string;
    readonly resourceType: string;
    /**
     * Read a resource by ID
     */
    read(id: string): Promise<WithId<T>>;
    /**
     * Search for resources
     */
    search(params?: SearchParams): Promise<Bundle<WithId<T>>>;
    /**
     * Search and return first result or undefined
     */
    searchOne(params?: SearchParams): Promise<undefined | WithId<T>>;
    /**
     * Search and return all results (handles pagination)
     */
    searchAll(params?: SearchParams): Promise<WithId<T>[]>;
}
/**
 * Specific reader types for type safety
 */
export type DTRLogErrorsInputParametersReader = FhirResourceSearcher<GeneratedTypes.DTRLogErrorsInputParameters>;
export type DTRQuestionnaireAdaptReader = FhirResourceSearcher<GeneratedTypes.DTRQuestionnaireAdapt>;
export type DTRQuestionnaireAdaptSearchReader = FhirResourceSearcher<GeneratedTypes.DTRQuestionnaireAdaptSearch>;
export type DTRQuestionnairePackageBundleReader = FhirResourceSearcher<GeneratedTypes.DTRQuestionnairePackageBundle>;
export type DTRQuestionnairePackageInputParametersReader = FhirResourceSearcher<GeneratedTypes.DTRQuestionnairePackageInputParameters>;
export type DTRQuestionnairePackageOutputParametersReader = FhirResourceSearcher<GeneratedTypes.DTRQuestionnairePackageOutputParameters>;
export type DTRQuestionnaireResponseReader = FhirResourceSearcher<GeneratedTypes.DTRQuestionnaireResponse>;
export type DTRQuestionnaireResponseBundleReader = FhirResourceSearcher<GeneratedTypes.DTRQuestionnaireResponseBundle>;
export type DTRStdQuestionnaireReader = FhirResourceSearcher<GeneratedTypes.DTRStdQuestionnaire>;
/**
 * Custom fetch function type for injecting auth headers
 */
export type FetchFn = typeof globalThis.fetch;
/**
 * Implementation of FHIR resource reader
 */
export declare class FhirResourceReader<T> implements FhirResourceSearcher<T> {
    readonly baseUrl: string;
    readonly resourceType: string;
    private readonly fetchFn;
    constructor(baseUrl: string, resourceType: string, fetchFn?: FetchFn);
    read(id: string): Promise<WithId<T>>;
    search(params?: SearchParams): Promise<Bundle<WithId<T>>>;
    searchOne(params?: SearchParams): Promise<undefined | WithId<T>>;
    searchAll(params?: SearchParams): Promise<WithId<T>[]>;
}
