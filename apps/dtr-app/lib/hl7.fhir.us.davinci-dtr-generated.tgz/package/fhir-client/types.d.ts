import type * as GeneratedTypes from "../index.js";
/**
 * A FHIR resource with an ID
 */
export type WithId<T> = {
    id: string;
} & T;
/**
 * Search parameter value type — all values are serialized to query strings.
 */
export type SearchParamValue = boolean | number | string | string[] | undefined;
/**
 * Search parameters for FHIR resources (generic untyped version).
 */
export type SearchParams = Record<string, SearchParamValue>;
/**
 * Common search parameters supported by all FHIR resources.
 * Includes an index signature to allow search parameter modifiers (e.g. name:exact).
 */
export interface CommonSearchParams {
    _id?: SearchParamValue;
    _lastUpdated?: SearchParamValue;
    _tag?: SearchParamValue;
    _profile?: SearchParamValue;
    _security?: SearchParamValue;
    _count?: SearchParamValue;
    _sort?: SearchParamValue;
    _include?: SearchParamValue;
    _revinclude?: SearchParamValue;
    _summary?: SearchParamValue;
    _elements?: SearchParamValue;
    _total?: SearchParamValue;
    [key: string]: SearchParamValue;
}
/**
 * Bundle of FHIR resources
 */
export interface Bundle<T> {
    resourceType: "Bundle";
    type: "collection" | "searchset" | "transaction-response" | "transaction";
    total?: number;
    link?: {
        relation: string;
        url: string;
    }[];
    entry?: {
        resource: T;
        fullUrl?: string;
    }[];
}
/**
 * Type-safe FHIR resource types
 */
export type FhirResource = GeneratedTypes.DTRLogErrorsInputParameters | GeneratedTypes.DTRQuestionnaireAdapt | GeneratedTypes.DTRQuestionnaireAdaptSearch | GeneratedTypes.DTRQuestionnairePackageBundle | GeneratedTypes.DTRQuestionnairePackageInputParameters | GeneratedTypes.DTRQuestionnairePackageOutputParameters | GeneratedTypes.DTRQuestionnaireResponse | GeneratedTypes.DTRQuestionnaireResponseBundle | GeneratedTypes.DTRStdQuestionnaire;
/**
 * Typed search parameters for Questionnaire resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface QuestionnaireSearchParams extends CommonSearchParams {
    "code"?: SearchParamValue;
    "context"?: SearchParamValue;
    "context-quantity"?: SearchParamValue;
    "context-type"?: SearchParamValue;
    "context-type-quantity"?: SearchParamValue;
    "context-type-value"?: SearchParamValue;
    "date"?: SearchParamValue;
    "definition"?: SearchParamValue;
    "description"?: SearchParamValue;
    "effective"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "jurisdiction"?: SearchParamValue;
    "name"?: SearchParamValue;
    "publisher"?: SearchParamValue;
    "status"?: SearchParamValue;
    "subject-type"?: SearchParamValue;
    "title"?: SearchParamValue;
    "url"?: SearchParamValue;
    "version"?: SearchParamValue;
}
/**
 * Typed search parameters for Bundle resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface BundleSearchParams extends CommonSearchParams {
    "composition"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "message"?: SearchParamValue;
    "timestamp"?: SearchParamValue;
    "type"?: SearchParamValue;
}
/**
 * Typed search parameters for QuestionnaireResponse resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface QuestionnaireResponseSearchParams extends CommonSearchParams {
    "author"?: SearchParamValue;
    "authored"?: SearchParamValue;
    "based-on"?: SearchParamValue;
    "context"?: SearchParamValue;
    "encounter"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "item-subject"?: SearchParamValue;
    "part-of"?: SearchParamValue;
    "patient"?: SearchParamValue;
    "questionnaire"?: SearchParamValue;
    "source"?: SearchParamValue;
    "status"?: SearchParamValue;
    "subject"?: SearchParamValue;
}
