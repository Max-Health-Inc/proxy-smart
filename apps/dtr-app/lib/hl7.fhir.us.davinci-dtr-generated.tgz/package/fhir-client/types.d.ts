import type * as GeneratedTypes from "../index.js";
/**
 * A FHIR resource with an ID
 */
export type WithId<T> = {
    id: string;
} & T;
/**
 * Search parameters for FHIR resources
 */
export type SearchParams = Record<string, boolean | number | string | string[] | undefined>;
/**
 * Bundle of FHIR resources
 */
export interface Bundle<T> {
    resourceType: "Bundle";
    type: "collection" | "searchset" | "transaction-response" | "transaction";
    total?: number;
    link?: {
        relation: string;
        url: string;
    }[];
    entry?: {
        resource: T;
        fullUrl?: string;
    }[];
}
/**
 * Type-safe FHIR resource types
 */
export type FhirResource = GeneratedTypes.DTRLogErrorsInputParameters | GeneratedTypes.DTRQuestionnaireAdapt | GeneratedTypes.DTRQuestionnaireAdaptSearch | GeneratedTypes.DTRQuestionnairePackageBundle | GeneratedTypes.DTRQuestionnairePackageInputParameters | GeneratedTypes.DTRQuestionnairePackageOutputParameters | GeneratedTypes.DTRQuestionnaireResponse | GeneratedTypes.DTRQuestionnaireResponseBundle | GeneratedTypes.DTRStdQuestionnaire;
