import { FhirReadClient as BaseFhirReadClient, FhirWriteClient as BaseFhirWriteClient, type FetchFn } from "@babelfhir-ts/client-r4";
import type * as GeneratedTypes from "../index.js";
/**
 * Profile-specific FHIR Read Client.
 * Extends the base R4 read client with typed profile accessors.
 * Inherits all base R4 resource methods from @babelfhir-ts/client-r4.
 */
export declare class FhirReadClient extends BaseFhirReadClient {
    dTRLogErrorsInputParameters(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.DTRLogErrorsInputParameters>;
    dTRQuestionnaireAdapt(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.DTRQuestionnaireAdapt>;
    dTRQuestionnaireAdaptSearch(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.DTRQuestionnaireAdaptSearch>;
    dTRQuestionnairePackageBundle(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.DTRQuestionnairePackageBundle>;
    dTRQuestionnairePackageInputParameters(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.DTRQuestionnairePackageInputParameters>;
    dTRQuestionnairePackageOutputParameters(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.DTRQuestionnairePackageOutputParameters>;
    dTRQuestionnaireResponse(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.DTRQuestionnaireResponse>;
    dTRQuestionnaireResponseBundle(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.DTRQuestionnaireResponseBundle>;
    dTRStdQuestionnaire(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.DTRStdQuestionnaire>;
}
/**
 * Profile-specific FHIR Write Client.
 * Extends the base R4 write client with typed profile accessors.
 * Inherits all base R4 resource methods from @babelfhir-ts/client-r4.
 */
export declare class FhirWriteClient extends BaseFhirWriteClient {
    dTRLogErrorsInputParameters(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.DTRLogErrorsInputParameters>;
    dTRQuestionnaireAdapt(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.DTRQuestionnaireAdapt>;
    dTRQuestionnaireAdaptSearch(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.DTRQuestionnaireAdaptSearch>;
    dTRQuestionnairePackageBundle(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.DTRQuestionnairePackageBundle>;
    dTRQuestionnairePackageInputParameters(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.DTRQuestionnairePackageInputParameters>;
    dTRQuestionnairePackageOutputParameters(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.DTRQuestionnairePackageOutputParameters>;
    dTRQuestionnaireResponse(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.DTRQuestionnaireResponse>;
    dTRQuestionnaireResponseBundle(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.DTRQuestionnaireResponseBundle>;
    dTRStdQuestionnaire(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.DTRStdQuestionnaire>;
}
/**
 * Main FHIR Client — works with plain fetch or an authenticated fetch wrapper.
 * Provides both base R4 accessors (inherited) and profile-specific accessors.
 *
 * @example
 * // Unauthenticated
 * const client = new FhirClient("https://fhir.example.com");
 *
 * // With custom fetch (e.g. from SmartFhirClient)
 * const client = new FhirClient("https://fhir.example.com", authenticatedFetch);
 *
 * // Base R4 methods (inherited from @babelfhir-ts/client-r4)
 * const pt = await client.read().patient().read("123");
 *
 * // Profile-specific methods (generated)
 * const claim = await client.read().pASClaim().search({ status: "active" });
 */
export declare class FhirClient {
    readonly baseUrl: string;
    private readonly readClient;
    private readonly writeClient;
    constructor(baseUrl: string, fetchFn?: FetchFn);
    /**
     * Get a read client for querying resources
     */
    read(): FhirReadClient;
    /**
     * Get a write client for creating/updating resources
     */
    write(): FhirWriteClient;
}
