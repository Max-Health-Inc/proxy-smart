import { BackboneElement, Parameters } from "fhir/r4";
export interface DTRQuestionnairePackageOutputParameters extends Omit<Parameters, 'parameter'> {
    /** Must Support */
    parameter: BackboneElement[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateDTRQuestionnairePackageOutputParameters(resource: DTRQuestionnairePackageOutputParameters, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
