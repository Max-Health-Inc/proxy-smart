import { Extension } from "fhir/r4";
export interface UnitValueSet extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/StructureDefinition/questionnaire-unitValueSet";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateUnitValueSet(resource: UnitValueSet, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
