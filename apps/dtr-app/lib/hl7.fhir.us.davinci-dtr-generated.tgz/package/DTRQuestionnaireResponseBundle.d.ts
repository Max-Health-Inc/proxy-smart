import { Bundle } from "fhir/r4";
export interface DTRQuestionnaireResponseBundle extends Omit<Bundle, 'type'> {
    resourceType: 'Bundle';
    type: "collection";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateDTRQuestionnaireResponseBundle(resource: DTRQuestionnaireResponseBundle, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
