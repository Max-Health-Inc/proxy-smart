import { Extension } from "fhir/r4";
export interface ItemMedia extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-itemMedia";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateItemMedia(resource: ItemMedia, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
