import { BackboneElement, Parameters } from "fhir/r4";
export interface DTRQuestionnairePackageInputParameters extends Omit<Parameters, 'parameter'> {
    /** Must Support */
    parameter: BackboneElement[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateDTRQuestionnairePackageInputParameters(resource: DTRQuestionnairePackageInputParameters, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
