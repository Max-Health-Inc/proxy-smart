import { Parameters, ParametersParameter } from "fhir/r4";
export interface DTRQuestionnairePackageInputParameters extends Omit<Parameters, 'parameter'> {
    resourceType: 'Parameters';
    /** Must Support */
    parameter: ParametersParameter[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateDTRQuestionnairePackageInputParameters(resource: DTRQuestionnairePackageInputParameters, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
