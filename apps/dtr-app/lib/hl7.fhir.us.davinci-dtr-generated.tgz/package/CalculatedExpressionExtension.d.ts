import { Expression, Extension } from "fhir/r4";
export interface CalculatedExpressionExtension extends Omit<Extension, 'url' | 'value'> {
    url: "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression";
    value: Expression;
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateCalculatedExpressionExtension(resource: CalculatedExpressionExtension, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
