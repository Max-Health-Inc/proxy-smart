import { Parameters, ParametersParameter } from "fhir/r4";
export interface DTRLogErrorsInputParameters extends Omit<Parameters, 'parameter'> {
    /** Must Support */
    parameter: ParametersParameter[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateDTRLogErrorsInputParameters(resource: DTRLogErrorsInputParameters, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
