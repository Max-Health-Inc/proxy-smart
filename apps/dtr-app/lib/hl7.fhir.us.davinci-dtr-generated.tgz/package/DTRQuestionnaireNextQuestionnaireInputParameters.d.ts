import { Parameters } from "fhir/r4";
export type DTRQuestionnaireNextQuestionnaireInputParameters = Parameters;
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateDTRQuestionnaireNextQuestionnaireInputParameters(resource: DTRQuestionnaireNextQuestionnaireInputParameters, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
