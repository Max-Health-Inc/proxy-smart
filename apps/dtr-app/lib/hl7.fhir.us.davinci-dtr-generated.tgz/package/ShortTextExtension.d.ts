import { Extension } from "fhir/r4";
export interface ShortTextExtension extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-shortText";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateShortTextExtension(resource: ShortTextExtension, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
