import { SubscriberRelationshipCodesCode } from "./valuesets/ValueSet-SubscriberRelationshipCodes";
import { CodeableConcept, Coverage, CoverageClass, CoverageCostToBeneficiary, Identifier, Period, Reference, SimpleQuantity } from "fhir/r4";
export interface CoverageExtensionCostToBeneficiary extends Omit<CoverageCostToBeneficiary, 'value'> {
    value: SimpleQuantity;
}
export interface CoverageExtension extends Omit<Coverage, 'identifier' | 'type' | 'policyHolder' | 'subscriber' | 'relationship' | 'period' | 'payor' | 'class' | 'costToBeneficiary'> {
    /** Must Support */
    identifier?: Identifier[];
    /** Must Support | @see {@link ./valuesets/ValueSet-VS21684011142224113591.ts} for valid codes (167 codes) */
    type?: CodeableConcept;
    /** Must Support */
    policyHolder?: Reference;
    /** Must Support */
    subscriber?: Reference;
    /** Must Support | @see {@link ./valuesets/ValueSet-SubscriberRelationshipCodes.ts} for valid codes (7 codes) */
    relationship?: CodeableConcept & {
        coding: Array<{
            code: SubscriberRelationshipCodesCode;
            system: "http://terminology.hl7.org/CodeSystem/subscriber-relationship";
        }>;
    };
    /** Must Support */
    period?: Period;
    /** Must Support */
    payor: Reference[];
    /** Must Support */
    class?: CoverageClass[];
    costToBeneficiary?: CoverageExtensionCostToBeneficiary[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateCoverageExtension(resource: CoverageExtension, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
