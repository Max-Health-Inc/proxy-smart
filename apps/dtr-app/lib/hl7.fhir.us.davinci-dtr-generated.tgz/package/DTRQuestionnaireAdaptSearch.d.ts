import { LibraryExtension } from "./LibraryExtension";
import { DesignNote } from "./DesignNote";
import { SignatureRequired } from "./SignatureRequired";
import { Style } from "./Style";
import { StyleSensitive } from "./StyleSensitive";
import { Xhtml } from "./Xhtml";
import { AssembleExpectation } from "./AssembleExpectation";
import { EntryMode } from "./EntryMode";
import { PerformerTypeExtension } from "./PerformerTypeExtension";
import { PreferredTerminologyServer } from "./PreferredTerminologyServer";
import { QuestionnaireAdaptiveExtension } from "./QuestionnaireAdaptiveExtension";
import { Element, Extension, Period, Questionnaire, QuestionnaireItem } from "fhir/r4";
export interface DTRQuestionnaireAdaptSearchTitleElement extends Omit<Element, 'extension'> {
    extension?: (Extension | Style | Xhtml)[];
}
export interface DTRQuestionnaireAdaptSearch extends Omit<Questionnaire, '_title' | 'title' | 'effectivePeriod' | 'extension' | 'item'> {
    _title?: DTRQuestionnaireAdaptSearchTitleElement;
    /** Must Support */
    title?: string;
    /** Must Support */
    effectivePeriod?: Period;
    extension?: (Extension | DesignNote | PreferredTerminologyServer | PerformerTypeExtension | AssembleExpectation | QuestionnaireAdaptiveExtension | StyleSensitive | EntryMode | SignatureRequired | LibraryExtension)[];
    item?: DTRQuestionnaireAdaptSearchItem[];
}
export interface DTRQuestionnaireAdaptSearchItem extends Omit<QuestionnaireItem, 'extension'> {
    extension?: (Extension | DesignNote | PreferredTerminologyServer)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateDTRQuestionnaireAdaptSearch(resource: DTRQuestionnaireAdaptSearch, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
