import { validateDTRMetricData } from "./DTRMetricData.js";
// Only import helpers actually referenced below (dynamic based on required fields)
import { randomId, setRandomSeed, enrichResource, randomDate } from "./random/index.js";
import { createRequire } from 'module';
const __require = createRequire(import.meta.url);
// Helper emitted only when meta.profile enforcement is applicable (resource profiles)
// Internal helper (emitted per class file) to clone without resorting to 'any'.
function safeClone(value) {
    // Use native structuredClone if present; otherwise fallback to JSON round-trip.
    // We intentionally avoid casting through any to satisfy no-explicit-any lint rule.
    const g = globalThis;
    // Narrow globalThis to an object potentially containing structuredClone.
    if (typeof g.structuredClone === 'function') {
        return g.structuredClone(value);
    }
    return JSON.parse(JSON.stringify(value)); // best-effort deep clone
}
export class DTRMetricDataClass {
    constructor(resource) {
        this.resource = resource;
    }
    /** Validate current resource instance. */
    async validate(options) {
        return validateDTRMetricData(this.resource, options);
    }
    getResource() {
        return this.resource;
    }
    setResource(resource) {
        this.resource = resource;
    }
    /**
     * Returns a plain JSON clone of the underlying resource ONLY if the last validation succeeded with zero errors.
     * Call validate() first; otherwise this method throws to prevent accidental use of invalid / unchecked data.
     */
    async toJSON() {
        return safeClone(this.resource);
    }
    /**
     * Create an empty instance for parity testing: for true FHIR resources, includes only resourceType; for datatypes, returns an empty object.
     * Note: meta.profile (when applicable) will be ensured by the constructor when wrapping this resource.
     */
    static empty(overrides = {}) {
        // For Resource profiles, include only resourceType. For Extension profiles, include url so the instance is minimally meaningful.
        const base = {};
        return { ...base, ...overrides };
    }
    /**
     * Create a minimal randomized instance of DTRMetricData.
     * Populates id, resourceType (if applicable) and primitive required (min>0) top-level fields with placeholders.
     */
    static random(overrides = {}, opts) {
        if (opts?.seed !== undefined) {
            // Direct call (no dynamic require) to ensure deterministic seeding works under ESM.
            setRandomSeed(opts.seed);
        }
        // Start with a Partial to avoid unsafe casting errors; we'll assert at the end.
        const base = { id: randomId(), source: "provider-src", providerId: { value: "Example-value", system: "http://hl7.org/fhir/sid/us-npi" }, groupId: { value: "Example-value", system: "http://hl7.org/fhir/sid/us-npi" }, payerId: { system: 'https://babelfhir.dev/' + randomId(), value: "Example-value" }, orderItem: [({ coding: [{ system: "http://loinc.org", code: "3141-9" }] })], action: [({ actionDetail: "userresponse", requestTime: randomDate(), issue: [{ code: "invalid" }] })], };
        // Always include meta.profile with this profile's canonical URL if available & only for resource profiles
        // (no profileUrl provided or profile targets a datatype â€“ meta.profile not applicable)
        // Enrich the base resource with common fields using centralized enrichment logic
        enrichResource(base, 'Base', 'http://hl7.org/fhir/us/davinci-dtr/StructureDefinition/DTRMetricData', DTRMetricDataClass._fieldPatterns, DTRMetricDataClass._forbiddenFields, DTRMetricDataClass.valueSetBindings, DTRMetricDataClass._codeResolver, DTRMetricDataClass._fieldOrder);
        // Cast through unknown to acknowledge dynamic enrichment
        return { ...base, ...overrides };
    }
    /** Convenience: returns a class instance wrapping a randomized resource. */
    static randomClass(overrides = {}, opts) {
        return new DTRMetricDataClass(this.random(overrides, opts));
    }
}
/** Pattern constraints for profile fields (used by random() generator) */
DTRMetricDataClass._fieldPatterns = {
    "providerId.use": "old",
    "providerId.type": "TAX",
    "providerId.system": "http://hl7.org/fhir/sid/us-npi",
    "groupId.use": "old",
    "groupId.type": "TAX",
    "groupId.system": "http://hl7.org/fhir/sid/us-npi",
    "payerId.use": "old",
    "payerId.type": "TAX",
    "action.actionDetail": "userresponse",
    "action.issue.code": "invalid",
    "action.issue.details": "MSG_ID_TOO_LONG",
    "resources.type": "SearchParameter",
    "questionnaire.failure": "invalid",
    "questionnaire.roleInteraction.role": "374700000X",
    "questionnaire.roleInteraction.roleAction": "manual",
    "coverageInfo.covered": "not-covered",
    "coverageInfo.paNeeded": "satisfied",
    "coverageInfo.docNeeded": "admin",
    "coverageInfo.infoNeeded": "location",
    "_refReq_providerId": {
        "system": true,
        "value": true
    },
    "_refReq_groupId": {
        "system": true,
        "value": true
    },
    "_refReq_payerId": {
        "system": true,
        "value": true
    },
    "_refReq_action": {
        "actionDetail": true,
        "requestTime": true,
        "issue.code": true
    },
    "_refReq_resources": {
        "type": true,
        "count": true
    },
    "_refReq_questionnaire": {
        "reference": true,
        "roleInteraction.role": true,
        "roleInteraction.roleAction": true,
        "roleInteraction.count": true,
        "elapsedTime": true
    },
    "_refReq_coverageInfo": {
        "questionnaire.reference": true,
        "questionnaire.adaptive": true,
        "questionnaire.response": true,
        "assertionId": true
    }
};
/** Fields that are forbidden (max=0) in this profile - must not be generated */
DTRMetricDataClass._forbiddenFields = [];
/** FHIR element ordering for this profile's base resource (used by enrichResource for correct JSON field order) */
DTRMetricDataClass._fieldOrder = ["source", "sofApp", "providerId", "groupId", "payerId", "assertionId", "docReason", "launchMode", "orderItem", "action", "resources", "questionnaire", "coverageInfo"];
/** ValueSet bindings for coded fields - maps field name to ValueSet URL */
DTRMetricDataClass.valueSetBindings = {
    "source": "http://hl7.org/fhir/us/davinci-dtr/ValueSet/metric-Source",
    "providerId.use": "http://hl7.org/fhir/ValueSet/identifier-use|4.0.1",
    "providerId.type": "http://hl7.org/fhir/ValueSet/identifier-type",
    "groupId.use": "http://hl7.org/fhir/ValueSet/identifier-use|4.0.1",
    "groupId.type": "http://hl7.org/fhir/ValueSet/identifier-type",
    "payerId.use": "http://hl7.org/fhir/ValueSet/identifier-use|4.0.1",
    "payerId.type": "http://hl7.org/fhir/ValueSet/identifier-type",
    "docReason": "http://hl7.org/fhir/us/davinci-crd/ValueSet/DocReason",
    "launchMode": "http://hl7.org/fhir/us/davinci-dtr/ValueSet/metric-launchmode",
    "orderItem": "http://hl7.org/fhir/us/davinci-crd/ValueSet/orderDetail",
    "action.actionDetail": "http://hl7.org/fhir/us/davinci-dtr/ValueSet/metric-Action",
    "action.issue.code": "http://hl7.org/fhir/ValueSet/issue-type",
    "action.issue.details": "http://hl7.org/fhir/ValueSet/operation-outcome",
    "resources.type": "http://hl7.org/fhir/ValueSet/resource-types",
    "questionnaire.failure": "http://hl7.org/fhir/ValueSet/issue-type",
    "questionnaire.roleInteraction.role": "http://hl7.org/fhir/us/core/ValueSet/us-core-provider-role",
    "questionnaire.roleInteraction.roleAction": "http://hl7.org/fhir/us/davinci-dtr/ValueSet/MetricsinformationOrigins",
    "coverageInfo.covered": "http://hl7.org/fhir/us/davinci-crd/ValueSet/coverageInfo",
    "coverageInfo.paNeeded": "http://hl7.org/fhir/us/davinci-crd/ValueSet/coveragePaDetail",
    "coverageInfo.docNeeded": "http://hl7.org/fhir/us/davinci-crd/ValueSet/AdditionalDocumentation",
    "coverageInfo.infoNeeded": "http://hl7.org/fhir/us/davinci-crd/ValueSet/informationNeeded"
};
/** Code resolver for ValueSet bindings - returns a random valid code from a ValueSet by URL */
DTRMetricDataClass._codeResolver = (() => {
    // Try to load the ValueSetRegistry - it may not exist if no ValueSets were generated
    try {
        const registry = __require('./valuesets/index.js');
        if (registry && typeof registry.getRandomConceptByUrl === 'function') {
            return registry.getRandomConceptByUrl;
        }
    }
    catch { /* ValueSetRegistry not available */ }
    return undefined;
})();
