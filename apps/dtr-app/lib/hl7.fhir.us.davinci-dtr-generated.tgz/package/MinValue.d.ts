import { Extension } from "fhir/r4";
export interface MinValue extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/StructureDefinition/minValue";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateMinValue(resource: MinValue, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
