import { Extension, Signature } from "fhir/r4";
export interface SignatureExtension extends Omit<Extension, 'url' | 'value'> {
    url: "http://hl7.org/fhir/StructureDefinition/questionnaireresponse-signature";
    value: Signature;
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateSignatureExtension(resource: SignatureExtension, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
