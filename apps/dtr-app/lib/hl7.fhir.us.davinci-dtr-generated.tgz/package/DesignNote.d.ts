import { Extension } from "fhir/r4";
export interface DesignNote extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/StructureDefinition/designNote";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateDesignNote(resource: DesignNote, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
