import { Extension } from "fhir/r4";
export interface MaxValue extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/StructureDefinition/maxValue";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateMaxValue(resource: MaxValue, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
