import { Extension } from "fhir/r4";
export interface ItemPopulationContextExtension extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-itemPopulationContext";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateItemPopulationContextExtension(resource: ItemPopulationContextExtension, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
