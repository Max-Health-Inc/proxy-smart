import { Extension } from "fhir/r4";
export interface DisplayName extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/StructureDefinition/display";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateDisplayName(resource: DisplayName, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
