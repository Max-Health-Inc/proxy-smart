import { Expression, Extension } from "fhir/r4";
export interface Variable extends Omit<Extension, 'url' | 'value'> {
    url: "http://hl7.org/fhir/StructureDefinition/variable";
    value: Expression;
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateVariable(resource: Variable, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
