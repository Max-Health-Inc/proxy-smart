import { DocReasonCode } from "./valuesets/ValueSet-DocReason";
import { CodeableConcept, Extension } from "fhir/r4";
export interface IntendedUse extends Omit<Extension, 'url' | 'value'> {
    url: "http://hl7.org/fhir/us/davinci-dtr/StructureDefinition/intendedUse";
    /** @see {@link ./valuesets/ValueSet-DocReason.ts} for valid codes (5 codes) */
    value: CodeableConcept & {
        coding: Array<{
            code: DocReasonCode;
        }>;
    };
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateIntendedUse(resource: IntendedUse, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
