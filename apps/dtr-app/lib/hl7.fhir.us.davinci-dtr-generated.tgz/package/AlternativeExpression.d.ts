import { Expression, Extension } from "fhir/r4";
export interface AlternativeExpression extends Omit<Extension, 'url' | 'value'> {
    url: "http://hl7.org/fhir/us/davinci-dtr/StructureDefinition/alternativeExpression";
    value: Expression;
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateAlternativeExpression(resource: AlternativeExpression, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
