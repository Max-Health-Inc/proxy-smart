import { Extension } from "fhir/r4";
export interface MimeType extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/StructureDefinition/mimeType";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateMimeType(resource: MimeType, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
