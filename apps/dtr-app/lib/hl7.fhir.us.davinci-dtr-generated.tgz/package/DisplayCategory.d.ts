import { CodeableConcept, Extension } from "fhir/r4";
export interface DisplayCategory extends Omit<Extension, 'url' | 'value'> {
    url: "http://hl7.org/fhir/StructureDefinition/questionnaire-displayCategory";
    value: CodeableConcept;
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateDisplayCategory(resource: DisplayCategory, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
