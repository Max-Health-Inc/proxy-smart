/**
 * ValueSet: coveragePaDetail
 * URL: http://hl7.org/fhir/us/davinci-crd/ValueSet/coveragePaDetail
 * Size: 5 concepts
 */
export const CoveragePaDetailConcepts = [
    { code: "no-auth", system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp" },
    { code: "auth-needed", system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp" },
    { code: "satisfied", system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp" },
    { code: "performpa", system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp" },
    { code: "conditional", system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidCoveragePaDetailCode(code) {
    return CoveragePaDetailConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getCoveragePaDetailConcept(code) {
    return CoveragePaDetailConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const CoveragePaDetailCodes = CoveragePaDetailConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomCoveragePaDetailCode() {
    return CoveragePaDetailCodes[Math.floor(Math.random() * CoveragePaDetailCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomCoveragePaDetailConcept() {
    return CoveragePaDetailConcepts[Math.floor(Math.random() * CoveragePaDetailConcepts.length)];
}
