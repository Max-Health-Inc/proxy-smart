/**
 * ValueSet: 2.16.840.1.114222.4.11.3591
 * URL: http://cts.nlm.nih.gov/fhir/ValueSet/2.16.840.1.114222.4.11.3591
 * Size: 167 concepts
 */
interface VS21684011142224113591ConceptDef {
    readonly code: string;
    readonly system: string;
    readonly display?: string;
}
export declare const VS21684011142224113591Concepts: readonly VS21684011142224113591ConceptDef[];
/** String type (ValueSet too large for union type) */
export type VS21684011142224113591Code = string;
/** Type representing a concept from this ValueSet */
export type VS21684011142224113591Concept = VS21684011142224113591ConceptDef;
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidVS21684011142224113591Code(code: string): code is VS21684011142224113591Code;
/**
 * Get concept details by code
 */
export declare function getVS21684011142224113591Concept(code: string): VS21684011142224113591Concept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const VS21684011142224113591Codes: string[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomVS21684011142224113591Code(): VS21684011142224113591Code;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomVS21684011142224113591Concept(): VS21684011142224113591Concept;
export {};
