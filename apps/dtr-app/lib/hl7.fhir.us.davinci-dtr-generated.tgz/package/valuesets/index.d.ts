/**
 * ValueSet Registry
 * Central registry of all loaded ValueSets with explicit codes
 */
import * as AdditionalDocumentation from './ValueSet-AdditionalDocumentation.js';
import * as BodySite from './ValueSet-BodySite.js';
import * as BundleType from './ValueSet-BundleType.js';
import * as ConditionCode from './ValueSet-ConditionCode.js';
import * as CoverageInfo from './ValueSet-CoverageInfo.js';
import * as CoveragePaDetail from './ValueSet-CoveragePaDetail.js';
import * as DocReason from './ValueSet-DocReason.js';
import * as DTRInformationOrigins from './ValueSet-DTRInformationOrigins.js';
import * as EncounterStatus from './ValueSet-EncounterStatus.js';
import * as FmStatus from './ValueSet-FmStatus.js';
import * as HttpVerb from './ValueSet-HttpVerb.js';
import * as IdentifierUse from './ValueSet-IdentifierUse.js';
import * as InformationNeeded from './ValueSet-InformationNeeded.js';
import * as ItemType from './ValueSet-ItemType.js';
import * as MedicationrequestStatus from './ValueSet-MedicationrequestStatus.js';
import * as MetricAction from './ValueSet-MetricAction.js';
import * as MetricLaunchMode from './ValueSet-MetricLaunchMode.js';
import * as MetricsInformationOrigins from './ValueSet-MetricsInformationOrigins.js';
import * as MetricSource from './ValueSet-MetricSource.js';
import * as NarrativeStatus from './ValueSet-NarrativeStatus.js';
import * as OrderDetail from './ValueSet-OrderDetail.js';
import * as PublicationStatus from './ValueSet-PublicationStatus.js';
import * as QuestionnaireAnswersStatus from './ValueSet-QuestionnaireAnswersStatus.js';
import * as RequestIntent from './ValueSet-RequestIntent.js';
import * as RequestPriority from './ValueSet-RequestPriority.js';
import * as RequestStatus from './ValueSet-RequestStatus.js';
import * as ServiceRequestCodes from './ValueSet-ServiceRequestCodes.js';
import * as UsCoreProviderRole from './ValueSet-UsCoreProviderRole.js';
import * as V20092 from './ValueSet-V20092.js';
import * as V20276 from './ValueSet-V20276.js';
import * as V3ActPriority from './ValueSet-V3ActPriority.js';
import * as V3ActReason from './ValueSet-V3ActReason.js';
import * as V3ParticipationMode from './ValueSet-V3ParticipationMode.js';
import * as VS21684011142224113591 from './ValueSet-VS21684011142224113591.js';
export declare const ValueSetRegistry: {
    readonly AdditionalDocumentation: typeof AdditionalDocumentation;
    readonly BodySite: typeof BodySite;
    readonly BundleType: typeof BundleType;
    readonly ConditionCode: typeof ConditionCode;
    readonly CoverageInfo: typeof CoverageInfo;
    readonly CoveragePaDetail: typeof CoveragePaDetail;
    readonly DocReason: typeof DocReason;
    readonly DTRInformationOrigins: typeof DTRInformationOrigins;
    readonly EncounterStatus: typeof EncounterStatus;
    readonly FmStatus: typeof FmStatus;
    readonly HttpVerb: typeof HttpVerb;
    readonly IdentifierUse: typeof IdentifierUse;
    readonly InformationNeeded: typeof InformationNeeded;
    readonly ItemType: typeof ItemType;
    readonly MedicationrequestStatus: typeof MedicationrequestStatus;
    readonly MetricAction: typeof MetricAction;
    readonly MetricLaunchMode: typeof MetricLaunchMode;
    readonly MetricsInformationOrigins: typeof MetricsInformationOrigins;
    readonly MetricSource: typeof MetricSource;
    readonly NarrativeStatus: typeof NarrativeStatus;
    readonly OrderDetail: typeof OrderDetail;
    readonly PublicationStatus: typeof PublicationStatus;
    readonly QuestionnaireAnswersStatus: typeof QuestionnaireAnswersStatus;
    readonly RequestIntent: typeof RequestIntent;
    readonly RequestPriority: typeof RequestPriority;
    readonly RequestStatus: typeof RequestStatus;
    readonly ServiceRequestCodes: typeof ServiceRequestCodes;
    readonly UsCoreProviderRole: typeof UsCoreProviderRole;
    readonly V20092: typeof V20092;
    readonly V20276: typeof V20276;
    readonly V3ActPriority: typeof V3ActPriority;
    readonly V3ActReason: typeof V3ActReason;
    readonly V3ParticipationMode: typeof V3ParticipationMode;
    readonly VS21684011142224113591: typeof VS21684011142224113591;
};
export type ValueSetName = keyof typeof ValueSetRegistry;
export declare function getValueSet(name: ValueSetName): typeof AdditionalDocumentation | typeof BodySite | typeof BundleType | typeof ConditionCode | typeof CoverageInfo | typeof CoveragePaDetail | typeof DocReason | typeof DTRInformationOrigins | typeof EncounterStatus | typeof FmStatus | typeof HttpVerb | typeof IdentifierUse | typeof InformationNeeded | typeof ItemType | typeof MedicationrequestStatus | typeof MetricAction | typeof MetricLaunchMode | typeof MetricsInformationOrigins | typeof MetricSource | typeof NarrativeStatus | typeof OrderDetail | typeof PublicationStatus | typeof QuestionnaireAnswersStatus | typeof RequestIntent | typeof RequestPriority | typeof RequestStatus | typeof ServiceRequestCodes | typeof UsCoreProviderRole | typeof V20092 | typeof V20276 | typeof V3ActPriority | typeof V3ActReason | typeof V3ParticipationMode | typeof VS21684011142224113591;
/** Map from ValueSet URL to registry name */
export declare const ValueSetUrlMap: Record<string, ValueSetName>;
/**
 * Get a random code from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A random code string, or undefined if ValueSet not found
 */
export declare function getRandomCodeByUrl(url: string): string | undefined;
/**
 * Get a random concept (code, system, display) from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A concept object with code, system, and optional display, or undefined if ValueSet not found
 */
export declare function getRandomConceptByUrl(url: string): {
    code: string;
    system: string;
    display?: string;
} | undefined;
