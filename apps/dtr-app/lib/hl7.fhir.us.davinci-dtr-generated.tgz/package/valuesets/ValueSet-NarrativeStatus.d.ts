/**
 * ValueSet: narrative-status
 * URL: http://hl7.org/fhir/ValueSet/narrative-status
 * Size: 4 concepts
 */
export declare const NarrativeStatusConcepts: readonly [{
    readonly code: "generated";
    readonly system: "http://hl7.org/fhir/narrative-status";
}, {
    readonly code: "extensions";
    readonly system: "http://hl7.org/fhir/narrative-status";
}, {
    readonly code: "additional";
    readonly system: "http://hl7.org/fhir/narrative-status";
}, {
    readonly code: "empty";
    readonly system: "http://hl7.org/fhir/narrative-status";
}];
/** Union type of all valid codes in this ValueSet */
export type NarrativeStatusCode = "generated" | "extensions" | "additional" | "empty";
/** Type representing a concept from this ValueSet */
export type NarrativeStatusConcept = typeof NarrativeStatusConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidNarrativeStatusCode(code: string): code is NarrativeStatusCode;
/**
 * Get concept details by code
 */
export declare function getNarrativeStatusConcept(code: string): NarrativeStatusConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const NarrativeStatusCodes: ("generated" | "extensions" | "additional" | "empty")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomNarrativeStatusCode(): NarrativeStatusCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomNarrativeStatusConcept(): NarrativeStatusConcept;
