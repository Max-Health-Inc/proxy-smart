/**
 * ValueSet: participationstatus
 * URL: http://hl7.org/fhir/ValueSet/participationstatus
 * Size: 4 concepts
 */
export declare const ParticipationstatusConcepts: readonly [{
    readonly code: "accepted";
    readonly system: "http://hl7.org/fhir/participationstatus";
}, {
    readonly code: "declined";
    readonly system: "http://hl7.org/fhir/participationstatus";
}, {
    readonly code: "tentative";
    readonly system: "http://hl7.org/fhir/participationstatus";
}, {
    readonly code: "needs-action";
    readonly system: "http://hl7.org/fhir/participationstatus";
}];
/** Union type of all valid codes in this ValueSet */
export type ParticipationstatusCode = "accepted" | "declined" | "tentative" | "needs-action";
/** Type representing a concept from this ValueSet */
export type ParticipationstatusConcept = typeof ParticipationstatusConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidParticipationstatusCode(code: string): code is ParticipationstatusCode;
/**
 * Get concept details by code
 */
export declare function getParticipationstatusConcept(code: string): ParticipationstatusConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ParticipationstatusCodes: ("accepted" | "declined" | "tentative" | "needs-action")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomParticipationstatusCode(): ParticipationstatusCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomParticipationstatusConcept(): ParticipationstatusConcept;
