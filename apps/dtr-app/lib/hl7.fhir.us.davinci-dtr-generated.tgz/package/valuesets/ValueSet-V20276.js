/**
 * ValueSet: v2-0276
 * URL: http://terminology.hl7.org/ValueSet/v2-0276
 * Size: 5 concepts
 */
export const V20276Concepts = [
    { code: "ROUTINE", system: "http://terminology.hl7.org/CodeSystem/v2-0276" },
    { code: "WALKIN", system: "http://terminology.hl7.org/CodeSystem/v2-0276" },
    { code: "CHECKUP", system: "http://terminology.hl7.org/CodeSystem/v2-0276" },
    { code: "FOLLOWUP", system: "http://terminology.hl7.org/CodeSystem/v2-0276" },
    { code: "EMERGENCY", system: "http://terminology.hl7.org/CodeSystem/v2-0276" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidV20276Code(code) {
    return V20276Concepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getV20276Concept(code) {
    return V20276Concepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const V20276Codes = V20276Concepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomV20276Code() {
    return V20276Codes[Math.floor(Math.random() * V20276Codes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomV20276Concept() {
    return V20276Concepts[Math.floor(Math.random() * V20276Concepts.length)];
}
