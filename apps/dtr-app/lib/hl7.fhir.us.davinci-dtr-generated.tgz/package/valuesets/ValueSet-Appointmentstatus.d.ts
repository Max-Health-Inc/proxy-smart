/**
 * ValueSet: appointmentstatus
 * URL: http://hl7.org/fhir/ValueSet/appointmentstatus
 * Size: 10 concepts
 */
export declare const AppointmentstatusConcepts: readonly [{
    readonly code: "proposed";
    readonly system: "http://hl7.org/fhir/appointmentstatus";
}, {
    readonly code: "pending";
    readonly system: "http://hl7.org/fhir/appointmentstatus";
}, {
    readonly code: "booked";
    readonly system: "http://hl7.org/fhir/appointmentstatus";
}, {
    readonly code: "arrived";
    readonly system: "http://hl7.org/fhir/appointmentstatus";
}, {
    readonly code: "fulfilled";
    readonly system: "http://hl7.org/fhir/appointmentstatus";
}, {
    readonly code: "cancelled";
    readonly system: "http://hl7.org/fhir/appointmentstatus";
}, {
    readonly code: "noshow";
    readonly system: "http://hl7.org/fhir/appointmentstatus";
}, {
    readonly code: "entered-in-error";
    readonly system: "http://hl7.org/fhir/appointmentstatus";
}, {
    readonly code: "checked-in";
    readonly system: "http://hl7.org/fhir/appointmentstatus";
}, {
    readonly code: "waitlist";
    readonly system: "http://hl7.org/fhir/appointmentstatus";
}];
/** Union type of all valid codes in this ValueSet */
export type AppointmentstatusCode = "proposed" | "pending" | "booked" | "arrived" | "fulfilled" | "cancelled" | "noshow" | "entered-in-error" | "checked-in" | "waitlist";
/** Type representing a concept from this ValueSet */
export type AppointmentstatusConcept = typeof AppointmentstatusConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidAppointmentstatusCode(code: string): code is AppointmentstatusCode;
/**
 * Get concept details by code
 */
export declare function getAppointmentstatusConcept(code: string): AppointmentstatusConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const AppointmentstatusCodes: ("entered-in-error" | "proposed" | "pending" | "booked" | "arrived" | "fulfilled" | "cancelled" | "noshow" | "checked-in" | "waitlist")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomAppointmentstatusCode(): AppointmentstatusCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomAppointmentstatusConcept(): AppointmentstatusConcept;
