/**
 * ValueSet: EnableWhenBehavior
 * URL: http://hl7.org/fhir/ValueSet/questionnaire-enable-behavior
 * Size: 2 concepts
 */
export const EnableWhenBehaviorConcepts = [
    { code: "all", system: "http://hl7.org/fhir/questionnaire-enable-behavior", display: "All" },
    { code: "any", system: "http://hl7.org/fhir/questionnaire-enable-behavior", display: "Any" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidEnableWhenBehaviorCode(code) {
    return EnableWhenBehaviorConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getEnableWhenBehaviorConcept(code) {
    return EnableWhenBehaviorConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const EnableWhenBehaviorCodes = EnableWhenBehaviorConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomEnableWhenBehaviorCode() {
    return EnableWhenBehaviorCodes[Math.floor(Math.random() * EnableWhenBehaviorCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomEnableWhenBehaviorConcept() {
    return EnableWhenBehaviorConcepts[Math.floor(Math.random() * EnableWhenBehaviorConcepts.length)];
}
