/**
 * ValueSet: MetricLaunchMode
 * URL: http://hl7.org/fhir/us/davinci-dtr/ValueSet/metric-launchmode
 * Size: 4 concepts
 */
export declare const MetricLaunchModeConcepts: readonly [{
    readonly code: "crdlaunch";
    readonly system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp";
}, {
    readonly code: "relaunch";
    readonly system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp";
}, {
    readonly code: "salaunch";
    readonly system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp";
}, {
    readonly code: "cdexlaunch";
    readonly system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp";
}];
/** Union type of all valid codes in this ValueSet */
export type MetricLaunchModeCode = "crdlaunch" | "relaunch" | "salaunch" | "cdexlaunch";
/** Type representing a concept from this ValueSet */
export type MetricLaunchModeConcept = typeof MetricLaunchModeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidMetricLaunchModeCode(code: string): code is MetricLaunchModeCode;
/**
 * Get concept details by code
 */
export declare function getMetricLaunchModeConcept(code: string): MetricLaunchModeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const MetricLaunchModeCodes: ("crdlaunch" | "relaunch" | "salaunch" | "cdexlaunch")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomMetricLaunchModeCode(): MetricLaunchModeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomMetricLaunchModeConcept(): MetricLaunchModeConcept;
