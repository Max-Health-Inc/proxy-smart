/**
 * ValueSet: informationNeeded
 * URL: http://hl7.org/fhir/us/davinci-crd/ValueSet/informationNeeded
 * Size: 5 concepts
 */
export declare const InformationNeededConcepts: readonly [{
    readonly code: "performer";
    readonly system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp";
}, {
    readonly code: "location";
    readonly system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp";
}, {
    readonly code: "timeframe";
    readonly system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp";
}, {
    readonly code: "contract-window";
    readonly system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp";
}, {
    readonly code: "OTH";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-NullFlavor";
}];
/** Union type of all valid codes in this ValueSet */
export type InformationNeededCode = "performer" | "location" | "timeframe" | "contract-window" | "OTH";
/** Type representing a concept from this ValueSet */
export type InformationNeededConcept = typeof InformationNeededConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidInformationNeededCode(code: string): code is InformationNeededCode;
/**
 * Get concept details by code
 */
export declare function getInformationNeededConcept(code: string): InformationNeededConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const InformationNeededCodes: ("OTH" | "performer" | "location" | "timeframe" | "contract-window")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomInformationNeededCode(): InformationNeededCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomInformationNeededConcept(): InformationNeededConcept;
