/**
 * ValueSet: AdditionalDocumentation
 * URL: http://hl7.org/fhir/us/davinci-crd/ValueSet/AdditionalDocumentation
 * Size: 4 concepts
 */
export const AdditionalDocumentationConcepts = [
    { code: "clinical", system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp" },
    { code: "admin", system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp" },
    { code: "patient", system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp" },
    { code: "conditional", system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidAdditionalDocumentationCode(code) {
    return AdditionalDocumentationConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getAdditionalDocumentationConcept(code) {
    return AdditionalDocumentationConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const AdditionalDocumentationCodes = AdditionalDocumentationConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomAdditionalDocumentationCode() {
    return AdditionalDocumentationCodes[Math.floor(Math.random() * AdditionalDocumentationCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomAdditionalDocumentationConcept() {
    return AdditionalDocumentationConcepts[Math.floor(Math.random() * AdditionalDocumentationConcepts.length)];
}
