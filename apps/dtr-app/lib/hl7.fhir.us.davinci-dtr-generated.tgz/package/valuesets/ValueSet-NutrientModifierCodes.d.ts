/**
 * ValueSet: NutrientModifierCodes
 * URL: http://hl7.org/fhir/ValueSet/nutrient-code
 * Size: Infinity concepts
 */
export declare const NutrientModifierCodesConcepts: readonly [{
    readonly code: "33463005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Fluid";
}, {
    readonly code: "39972003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Sodium";
}, {
    readonly code: "88480006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Potassium";
}];
/** String type (ValueSet too large for union type) */
export type NutrientModifierCodesCode = string;
/** Type representing a concept from this ValueSet */
export type NutrientModifierCodesConcept = typeof NutrientModifierCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidNutrientModifierCodesCode(code: string): code is NutrientModifierCodesCode;
/**
 * Get concept details by code
 */
export declare function getNutrientModifierCodesConcept(code: string): NutrientModifierCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const NutrientModifierCodesCodes: ("33463005" | "39972003" | "88480006")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomNutrientModifierCodesCode(): NutrientModifierCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomNutrientModifierCodesConcept(): NutrientModifierCodesConcept;
