/**
 * ValueSet: request-intent
 * URL: http://hl7.org/fhir/ValueSet/request-intent
 * Size: 9 concepts
 */
export declare const RequestIntentConcepts: readonly [{
    readonly code: "proposal";
    readonly system: "http://hl7.org/fhir/request-intent";
}, {
    readonly code: "plan";
    readonly system: "http://hl7.org/fhir/request-intent";
}, {
    readonly code: "directive";
    readonly system: "http://hl7.org/fhir/request-intent";
}, {
    readonly code: "order";
    readonly system: "http://hl7.org/fhir/request-intent";
}, {
    readonly code: "original-order";
    readonly system: "http://hl7.org/fhir/request-intent";
}, {
    readonly code: "reflex-order";
    readonly system: "http://hl7.org/fhir/request-intent";
}, {
    readonly code: "filler-order";
    readonly system: "http://hl7.org/fhir/request-intent";
}, {
    readonly code: "instance-order";
    readonly system: "http://hl7.org/fhir/request-intent";
}, {
    readonly code: "option";
    readonly system: "http://hl7.org/fhir/request-intent";
}];
/** Union type of all valid codes in this ValueSet */
export type RequestIntentCode = "proposal" | "plan" | "directive" | "order" | "original-order" | "reflex-order" | "filler-order" | "instance-order" | "option";
/** Type representing a concept from this ValueSet */
export type RequestIntentConcept = typeof RequestIntentConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidRequestIntentCode(code: string): code is RequestIntentCode;
/**
 * Get concept details by code
 */
export declare function getRequestIntentConcept(code: string): RequestIntentConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const RequestIntentCodes: ("order" | "option" | "proposal" | "plan" | "directive" | "original-order" | "reflex-order" | "filler-order" | "instance-order")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomRequestIntentCode(): RequestIntentCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomRequestIntentConcept(): RequestIntentConcept;
