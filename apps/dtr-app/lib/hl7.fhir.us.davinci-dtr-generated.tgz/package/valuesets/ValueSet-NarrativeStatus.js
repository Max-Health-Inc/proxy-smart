/**
 * ValueSet: narrative-status
 * URL: http://hl7.org/fhir/ValueSet/narrative-status
 * Size: 4 concepts
 */
export const NarrativeStatusConcepts = [
    { code: "generated", system: "http://hl7.org/fhir/narrative-status" },
    { code: "extensions", system: "http://hl7.org/fhir/narrative-status" },
    { code: "additional", system: "http://hl7.org/fhir/narrative-status" },
    { code: "empty", system: "http://hl7.org/fhir/narrative-status" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidNarrativeStatusCode(code) {
    return NarrativeStatusConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getNarrativeStatusConcept(code) {
    return NarrativeStatusConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const NarrativeStatusCodes = NarrativeStatusConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomNarrativeStatusCode() {
    return NarrativeStatusCodes[Math.floor(Math.random() * NarrativeStatusCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomNarrativeStatusConcept() {
    return NarrativeStatusConcepts[Math.floor(Math.random() * NarrativeStatusConcepts.length)];
}
