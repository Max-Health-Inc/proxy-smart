/**
 * ValueSet: enteral-route
 * URL: http://hl7.org/fhir/ValueSet/enteral-route
 * Size: 9 concepts
 */
export declare const EnteralRouteConcepts: readonly [{
    readonly code: "PO";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-RouteOfAdministration";
}, {
    readonly code: "EFT";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-RouteOfAdministration";
}, {
    readonly code: "ENTINSTL";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-RouteOfAdministration";
}, {
    readonly code: "GT";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-RouteOfAdministration";
}, {
    readonly code: "NGT";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-RouteOfAdministration";
}, {
    readonly code: "OGT";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-RouteOfAdministration";
}, {
    readonly code: "GJT";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-RouteOfAdministration";
}, {
    readonly code: "JJTINSTL";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-RouteOfAdministration";
}, {
    readonly code: "OJJ";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-RouteOfAdministration";
}];
/** Union type of all valid codes in this ValueSet */
export type EnteralRouteCode = "PO" | "EFT" | "ENTINSTL" | "GT" | "NGT" | "OGT" | "GJT" | "JJTINSTL" | "OJJ";
/** Type representing a concept from this ValueSet */
export type EnteralRouteConcept = typeof EnteralRouteConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidEnteralRouteCode(code: string): code is EnteralRouteCode;
/**
 * Get concept details by code
 */
export declare function getEnteralRouteConcept(code: string): EnteralRouteConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const EnteralRouteCodes: ("PO" | "EFT" | "ENTINSTL" | "GT" | "NGT" | "OGT" | "GJT" | "JJTINSTL" | "OJJ")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomEnteralRouteCode(): EnteralRouteCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomEnteralRouteConcept(): EnteralRouteConcept;
