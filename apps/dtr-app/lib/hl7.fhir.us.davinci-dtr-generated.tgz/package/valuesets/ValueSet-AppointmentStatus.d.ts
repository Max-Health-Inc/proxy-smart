/**
 * ValueSet: AppointmentStatus
 * URL: http://hl7.org/fhir/ValueSet/appointmentstatus
 * Size: 10 concepts
 */
export declare const AppointmentStatusConcepts: readonly [{
    readonly code: "proposed";
    readonly system: "http://hl7.org/fhir/appointmentstatus";
    readonly display: "Proposed";
}, {
    readonly code: "pending";
    readonly system: "http://hl7.org/fhir/appointmentstatus";
    readonly display: "Pending";
}, {
    readonly code: "booked";
    readonly system: "http://hl7.org/fhir/appointmentstatus";
    readonly display: "Booked";
}, {
    readonly code: "arrived";
    readonly system: "http://hl7.org/fhir/appointmentstatus";
    readonly display: "Arrived";
}, {
    readonly code: "fulfilled";
    readonly system: "http://hl7.org/fhir/appointmentstatus";
    readonly display: "Fulfilled";
}, {
    readonly code: "cancelled";
    readonly system: "http://hl7.org/fhir/appointmentstatus";
    readonly display: "Cancelled";
}, {
    readonly code: "noshow";
    readonly system: "http://hl7.org/fhir/appointmentstatus";
    readonly display: "No Show";
}, {
    readonly code: "entered-in-error";
    readonly system: "http://hl7.org/fhir/appointmentstatus";
    readonly display: "Entered in error";
}, {
    readonly code: "checked-in";
    readonly system: "http://hl7.org/fhir/appointmentstatus";
    readonly display: "Checked In";
}, {
    readonly code: "waitlist";
    readonly system: "http://hl7.org/fhir/appointmentstatus";
    readonly display: "Waitlisted";
}];
/** Union type of all valid codes in this ValueSet */
export type AppointmentStatusCode = "proposed" | "pending" | "booked" | "arrived" | "fulfilled" | "cancelled" | "noshow" | "entered-in-error" | "checked-in" | "waitlist";
/** Type representing a concept from this ValueSet */
export type AppointmentStatusConcept = typeof AppointmentStatusConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidAppointmentStatusCode(code: string): code is AppointmentStatusCode;
/**
 * Get concept details by code
 */
export declare function getAppointmentStatusConcept(code: string): AppointmentStatusConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const AppointmentStatusCodes: ("entered-in-error" | "proposed" | "pending" | "booked" | "arrived" | "fulfilled" | "cancelled" | "noshow" | "checked-in" | "waitlist")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomAppointmentStatusCode(): AppointmentStatusCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomAppointmentStatusConcept(): AppointmentStatusConcept;
