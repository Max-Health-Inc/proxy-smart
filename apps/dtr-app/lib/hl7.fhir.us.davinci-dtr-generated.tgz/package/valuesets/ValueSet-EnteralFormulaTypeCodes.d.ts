/**
 * ValueSet: EnteralFormulaTypeCodes
 * URL: http://hl7.org/fhir/ValueSet/entformula-type
 * Size: 36 concepts
 */
export declare const EnteralFormulaTypeCodesConcepts: readonly [{
    readonly code: "443031000124106";
    readonly system: "http://snomed.info/sct";
    readonly display: "Adult critical care formula";
}, {
    readonly code: "443051000124104";
    readonly system: "http://snomed.info/sct";
    readonly display: "Adult diabetes specialty formula";
}, {
    readonly code: "442911000124109";
    readonly system: "http://snomed.info/sct";
    readonly display: "Adult elemental formula";
}, {
    readonly code: "443021000124108";
    readonly system: "http://snomed.info/sct";
    readonly display: "Adult hepatic specialty formula";
}, {
    readonly code: "442971000124100";
    readonly system: "http://snomed.info/sct";
    readonly display: "Adult high energy formula";
}, {
    readonly code: "442981000124102";
    readonly system: "http://snomed.info/sct";
    readonly display: "Adult hydrolyzed protein formula";
}, {
    readonly code: "442991000124104";
    readonly system: "http://snomed.info/sct";
    readonly display: "Adult high protein formula";
}, {
    readonly code: "443011000124100";
    readonly system: "http://snomed.info/sct";
    readonly display: "Adult high protein high fiber formula";
}, {
    readonly code: "442961000124107";
    readonly system: "http://snomed.info/sct";
    readonly display: "Adult low carbohydrate formula";
}, {
    readonly code: "442951000124105";
    readonly system: "http://snomed.info/sct";
    readonly display: "Adult pulmonary specialty formula";
}, {
    readonly code: "442941000124108";
    readonly system: "http://snomed.info/sct";
    readonly display: "Adult renal specialty formula";
}, {
    readonly code: "442921000124101";
    readonly system: "http://snomed.info/sct";
    readonly display: "Adult standard formula";
}, {
    readonly code: "442931000124103";
    readonly system: "http://snomed.info/sct";
    readonly display: "Adult soy protein isolate formula";
}, {
    readonly code: "443361000124100";
    readonly system: "http://snomed.info/sct";
    readonly display: "Pediatric Formula";
}, {
    readonly code: "443401000124105";
    readonly system: "http://snomed.info/sct";
    readonly display: "Pediatric elemental formula";
}, {
    readonly code: "443491000124103";
    readonly system: "http://snomed.info/sct";
    readonly display: "Pediatric high energy formula";
}, {
    readonly code: "443501000124106";
    readonly system: "http://snomed.info/sct";
    readonly display: "Pediatric high energy formula with increased fiber";
}, {
    readonly code: "443421000124100";
    readonly system: "http://snomed.info/sct";
    readonly display: "Pediatric hydrolyzed protein formula";
}, {
    readonly code: "443471000124104";
    readonly system: "http://snomed.info/sct";
    readonly display: "Pediatric increased fiber formula";
}, {
    readonly code: "444431000124104";
    readonly system: "http://snomed.info/sct";
    readonly display: "Pediatric reduced energy formula";
}, {
    readonly code: "443451000124109";
    readonly system: "http://snomed.info/sct";
    readonly display: "Pediatric standard formula";
}, {
    readonly code: "441561000124106";
    readonly system: "http://snomed.info/sct";
    readonly display: "Standard enteral formula with fiber";
}, {
    readonly code: "443461000124106";
    readonly system: "http://snomed.info/sct";
    readonly display: "Standard Formula";
}, {
    readonly code: "441531000124102";
    readonly system: "http://snomed.info/sct";
    readonly display: "Standard Enteral Formula";
}, {
    readonly code: "443561000124107";
    readonly system: "http://snomed.info/sct";
    readonly display: "Soy based formula";
}, {
    readonly code: "443481000124101";
    readonly system: "http://snomed.info/sct";
    readonly display: "Renal Formula";
}, {
    readonly code: "441571000124104";
    readonly system: "http://snomed.info/sct";
    readonly display: "High energy enteral formula with fiber";
}, {
    readonly code: "441591000124103";
    readonly system: "http://snomed.info/sct";
    readonly display: "Diabetic enteral formula with fiber";
}, {
    readonly code: "441601000124106";
    readonly system: "http://snomed.info/sct";
    readonly display: "Diabetic high calorie high protein enteral formula with fiber";
}, {
    readonly code: "443351000124102";
    readonly system: "http://snomed.info/sct";
    readonly display: "Increased fiber formula";
}, {
    readonly code: "443771000124106";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hydrolyzed protein formula";
}, {
    readonly code: "441671000124100";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hydrolyzed peptide-based high protein enteral formula";
}, {
    readonly code: "443111000124101";
    readonly system: "http://snomed.info/sct";
    readonly display: "High protein formula";
}, {
    readonly code: "443431000124102";
    readonly system: "http://snomed.info/sct";
    readonly display: "High Energy Formula";
}, {
    readonly code: "443411000124108";
    readonly system: "http://snomed.info/sct";
    readonly display: "Elemental Formula";
}, {
    readonly code: "442651000124102";
    readonly system: "http://snomed.info/sct";
    readonly display: "Adult formula";
}];
/** String type (ValueSet too large for union type) */
export type EnteralFormulaTypeCodesCode = string;
/** Type representing a concept from this ValueSet */
export type EnteralFormulaTypeCodesConcept = typeof EnteralFormulaTypeCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidEnteralFormulaTypeCodesCode(code: string): code is EnteralFormulaTypeCodesCode;
/**
 * Get concept details by code
 */
export declare function getEnteralFormulaTypeCodesConcept(code: string): EnteralFormulaTypeCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const EnteralFormulaTypeCodesCodes: ("443031000124106" | "443051000124104" | "442911000124109" | "443021000124108" | "442971000124100" | "442981000124102" | "442991000124104" | "443011000124100" | "442961000124107" | "442951000124105" | "442941000124108" | "442921000124101" | "442931000124103" | "443361000124100" | "443401000124105" | "443491000124103" | "443501000124106" | "443421000124100" | "443471000124104" | "444431000124104" | "443451000124109" | "441561000124106" | "443461000124106" | "441531000124102" | "443561000124107" | "443481000124101" | "441571000124104" | "441591000124103" | "441601000124106" | "443351000124102" | "443771000124106" | "441671000124100" | "443111000124101" | "443431000124102" | "443411000124108" | "442651000124102")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomEnteralFormulaTypeCodesCode(): EnteralFormulaTypeCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomEnteralFormulaTypeCodesConcept(): EnteralFormulaTypeCodesConcept;
