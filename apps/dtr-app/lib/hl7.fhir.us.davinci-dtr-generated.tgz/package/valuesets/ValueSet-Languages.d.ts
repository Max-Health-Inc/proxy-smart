/**
 * ValueSet: languages
 * URL: http://hl7.org/fhir/ValueSet/languages
 * Size: 56 concepts
 */
export declare const LanguagesConcepts: readonly [{
    readonly code: "ar";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "bn";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "cs";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "da";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "de";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "de-AT";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "de-CH";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "de-DE";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "el";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "en";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "en-AU";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "en-CA";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "en-GB";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "en-IN";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "en-NZ";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "en-SG";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "en-US";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "es";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "es-AR";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "es-ES";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "es-UY";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "fi";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "fr";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "fr-BE";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "fr-CH";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "fr-FR";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "fy";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "fy-NL";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "hi";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "hr";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "it";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "it-CH";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "it-IT";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "ja";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "ko";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "nl";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "nl-BE";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "nl-NL";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "no";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "no-NO";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "pa";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "pl";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "pt";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "pt-BR";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "ru";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "ru-RU";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "sr";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "sr-RS";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "sv";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "sv-SE";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "te";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "zh";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "zh-CN";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "zh-HK";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "zh-SG";
    readonly system: "urn:ietf:bcp:47";
}, {
    readonly code: "zh-TW";
    readonly system: "urn:ietf:bcp:47";
}];
/** String type (ValueSet too large for union type) */
export type LanguagesCode = string;
/** Type representing a concept from this ValueSet */
export type LanguagesConcept = typeof LanguagesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidLanguagesCode(code: string): code is LanguagesCode;
/**
 * Get concept details by code
 */
export declare function getLanguagesConcept(code: string): LanguagesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const LanguagesCodes: ("ar" | "bn" | "cs" | "da" | "de" | "de-AT" | "de-CH" | "de-DE" | "el" | "en" | "en-AU" | "en-CA" | "en-GB" | "en-IN" | "en-NZ" | "en-SG" | "en-US" | "es" | "es-AR" | "es-ES" | "es-UY" | "fi" | "fr" | "fr-BE" | "fr-CH" | "fr-FR" | "fy" | "fy-NL" | "hi" | "hr" | "it" | "it-CH" | "it-IT" | "ja" | "ko" | "nl" | "nl-BE" | "nl-NL" | "no" | "no-NO" | "pa" | "pl" | "pt" | "pt-BR" | "ru" | "ru-RU" | "sr" | "sr-RS" | "sv" | "sv-SE" | "te" | "zh" | "zh-CN" | "zh-HK" | "zh-SG" | "zh-TW")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomLanguagesCode(): LanguagesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomLanguagesConcept(): LanguagesConcept;
