/**
 * ValueSet: orderDetail
 * URL: http://hl7.org/fhir/us/davinci-crd/ValueSet/orderDetail
 * Size: 2 concepts
 */
export const OrderDetailConcepts = [
    { code: "lens", system: "http://terminology.hl7.org/CodeSystem/ex-visionprescriptionproduct" },
    { code: "contact", system: "http://terminology.hl7.org/CodeSystem/ex-visionprescriptionproduct" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidOrderDetailCode(code) {
    return OrderDetailConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getOrderDetailConcept(code) {
    return OrderDetailConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const OrderDetailCodes = OrderDetailConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomOrderDetailCode() {
    return OrderDetailCodes[Math.floor(Math.random() * OrderDetailCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomOrderDetailConcept() {
    return OrderDetailConcepts[Math.floor(Math.random() * OrderDetailConcepts.length)];
}
