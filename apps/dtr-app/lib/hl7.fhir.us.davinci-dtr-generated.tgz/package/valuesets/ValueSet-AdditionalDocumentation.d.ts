/**
 * ValueSet: AdditionalDocumentation
 * URL: http://hl7.org/fhir/us/davinci-crd/ValueSet/AdditionalDocumentation
 * Size: 4 concepts
 */
export declare const AdditionalDocumentationConcepts: readonly [{
    readonly code: "clinical";
    readonly system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp";
}, {
    readonly code: "admin";
    readonly system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp";
}, {
    readonly code: "patient";
    readonly system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp";
}, {
    readonly code: "conditional";
    readonly system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp";
}];
/** Union type of all valid codes in this ValueSet */
export type AdditionalDocumentationCode = "clinical" | "admin" | "patient" | "conditional";
/** Type representing a concept from this ValueSet */
export type AdditionalDocumentationConcept = typeof AdditionalDocumentationConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidAdditionalDocumentationCode(code: string): code is AdditionalDocumentationCode;
/**
 * Get concept details by code
 */
export declare function getAdditionalDocumentationConcept(code: string): AdditionalDocumentationConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const AdditionalDocumentationCodes: ("patient" | "conditional" | "clinical" | "admin")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomAdditionalDocumentationCode(): AdditionalDocumentationCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomAdditionalDocumentationConcept(): AdditionalDocumentationConcept;
