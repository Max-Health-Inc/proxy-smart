/**
 * ValueSet: encounter-status
 * URL: http://hl7.org/fhir/ValueSet/encounter-status
 * Size: 9 concepts
 */
export declare const EncounterStatusConcepts: readonly [{
    readonly code: "planned";
    readonly system: "http://hl7.org/fhir/encounter-status";
}, {
    readonly code: "arrived";
    readonly system: "http://hl7.org/fhir/encounter-status";
}, {
    readonly code: "triaged";
    readonly system: "http://hl7.org/fhir/encounter-status";
}, {
    readonly code: "in-progress";
    readonly system: "http://hl7.org/fhir/encounter-status";
}, {
    readonly code: "onleave";
    readonly system: "http://hl7.org/fhir/encounter-status";
}, {
    readonly code: "finished";
    readonly system: "http://hl7.org/fhir/encounter-status";
}, {
    readonly code: "cancelled";
    readonly system: "http://hl7.org/fhir/encounter-status";
}, {
    readonly code: "entered-in-error";
    readonly system: "http://hl7.org/fhir/encounter-status";
}, {
    readonly code: "unknown";
    readonly system: "http://hl7.org/fhir/encounter-status";
}];
/** Union type of all valid codes in this ValueSet */
export type EncounterStatusCode = "planned" | "arrived" | "triaged" | "in-progress" | "onleave" | "finished" | "cancelled" | "entered-in-error" | "unknown";
/** Type representing a concept from this ValueSet */
export type EncounterStatusConcept = typeof EncounterStatusConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidEncounterStatusCode(code: string): code is EncounterStatusCode;
/**
 * Get concept details by code
 */
export declare function getEncounterStatusConcept(code: string): EncounterStatusConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const EncounterStatusCodes: ("unknown" | "entered-in-error" | "finished" | "arrived" | "cancelled" | "in-progress" | "planned" | "triaged" | "onleave")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomEncounterStatusCode(): EncounterStatusCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomEncounterStatusConcept(): EncounterStatusConcept;
