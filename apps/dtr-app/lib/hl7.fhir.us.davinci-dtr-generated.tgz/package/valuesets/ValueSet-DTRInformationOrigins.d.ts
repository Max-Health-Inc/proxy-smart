/**
 * ValueSet: DTRInformationOrigins
 * URL: http://hl7.org/fhir/us/davinci-dtr/ValueSet/informationOrigins
 * Size: 3 concepts
 */
export declare const DTRInformationOriginsConcepts: readonly [{
    readonly code: "auto";
    readonly system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp";
}, {
    readonly code: "override";
    readonly system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp";
}, {
    readonly code: "manual";
    readonly system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp";
}];
/** Union type of all valid codes in this ValueSet */
export type DTRInformationOriginsCode = "auto" | "override" | "manual";
/** Type representing a concept from this ValueSet */
export type DTRInformationOriginsConcept = typeof DTRInformationOriginsConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidDTRInformationOriginsCode(code: string): code is DTRInformationOriginsCode;
/**
 * Get concept details by code
 */
export declare function getDTRInformationOriginsConcept(code: string): DTRInformationOriginsConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const DTRInformationOriginsCodes: ("manual" | "auto" | "override")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomDTRInformationOriginsCode(): DTRInformationOriginsCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomDTRInformationOriginsConcept(): DTRInformationOriginsConcept;
