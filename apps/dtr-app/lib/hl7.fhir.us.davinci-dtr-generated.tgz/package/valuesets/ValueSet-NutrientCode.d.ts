/**
 * ValueSet: nutrient-code
 * URL: http://hl7.org/fhir/ValueSet/nutrient-code
 * Size: 3 concepts
 */
export declare const NutrientCodeConcepts: readonly [{
    readonly code: "33463005";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "39972003";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "88480006";
    readonly system: "http://snomed.info/sct";
}];
/** Union type of all valid codes in this ValueSet */
export type NutrientCodeCode = "33463005" | "39972003" | "88480006";
/** Type representing a concept from this ValueSet */
export type NutrientCodeConcept = typeof NutrientCodeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidNutrientCodeCode(code: string): code is NutrientCodeCode;
/**
 * Get concept details by code
 */
export declare function getNutrientCodeConcept(code: string): NutrientCodeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const NutrientCodeCodes: ("33463005" | "39972003" | "88480006")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomNutrientCodeCode(): NutrientCodeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomNutrientCodeConcept(): NutrientCodeConcept;
