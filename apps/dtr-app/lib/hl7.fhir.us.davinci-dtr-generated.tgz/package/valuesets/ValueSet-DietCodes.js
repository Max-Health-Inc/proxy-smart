/**
 * ValueSet: DietCodes
 * URL: http://hl7.org/fhir/ValueSet/diet-type
 * Size: 100 concepts
 */
export const DietCodesConcepts = [
    { code: "182922004", system: "http://snomed.info/sct", display: "Dietary regime" },
    { code: "182923009", system: "http://snomed.info/sct", display: "Nil by mouth" },
    { code: "223456000", system: "http://snomed.info/sct", display: "Provision of a special diet" },
    { code: "289165000", system: "http://snomed.info/sct", display: "Restricting food intake" },
    { code: "386261001", system: "http://snomed.info/sct", display: "Diet staging (regime/therapy)" },
    { code: "404919001", system: "http://snomed.info/sct", display: "Wheat-free diet (regime/therapy)" },
    { code: "416576000", system: "http://snomed.info/sct", display: "Carbohydrate counting (regime/therapy)" },
    { code: "425458000", system: "http://snomed.info/sct", display: "Lactose-free diet (regime/therapy)" },
    { code: "709564003", system: "http://snomed.info/sct", display: "Restricting oral intake" },
    { code: "762104002", system: "http://snomed.info/sct", display: "Modified fluid diet (regime/therapy)" },
    { code: "765021002", system: "http://snomed.info/sct", display: "Vegetarian diet (regime/therapy)" },
    { code: "765022009", system: "http://snomed.info/sct", display: "Lacto-vegetarian diet" },
    { code: "765023004", system: "http://snomed.info/sct", display: "Lacto-ovo-vegetarian diet" },
    { code: "765024005", system: "http://snomed.info/sct", display: "Atkins diet" },
    { code: "765025006", system: "http://snomed.info/sct", display: "Kosher diet" },
    { code: "765052001", system: "http://snomed.info/sct", display: "Hindu diet (regime/therapy)" },
    { code: "765053006", system: "http://snomed.info/sct", display: "Low fructose diet (regime/therapy)" },
    { code: "765060000", system: "http://snomed.info/sct", display: "Ketogenic diet" },
    { code: "765063003", system: "http://snomed.info/sct", display: "Cantonese diet" },
    { code: "792805006", system: "http://snomed.info/sct", display: "Fasting" },
    { code: "1052337007", system: "http://snomed.info/sct", display: "Protein modified diet" },
    { code: "1055200005", system: "http://snomed.info/sct", display: "Increased protein diet" },
    { code: "1055201009", system: "http://snomed.info/sct", display: "Decreased protein diet" },
    { code: "1055202002", system: "http://snomed.info/sct", display: "Consistent protein and protein derivative diet" },
    { code: "1055203007", system: "http://snomed.info/sct", display: "Increased fat and oil diet" },
    { code: "1055204001", system: "http://snomed.info/sct", display: "Fat and oil modified diet" },
    { code: "1055207008", system: "http://snomed.info/sct", display: "Decreased fat diet" },
    { code: "1137465007", system: "http://snomed.info/sct", display: "Increased galactose diet (regime/therapy)" },
    { code: "1141680002", system: "http://snomed.info/sct", display: "Increased lactose diet (regime/therapy)" },
    { code: "1141683000", system: "http://snomed.info/sct", display: "Fructose modified diet (regime/therapy)" },
    { code: "1141684006", system: "http://snomed.info/sct", display: "Increased fructose diet (regime/therapy)" },
    { code: "1141931005", system: "http://snomed.info/sct", display: "Vitamin A and vitamin A derivative modified diet (regime/therapy)" },
    { code: "1141932003", system: "http://snomed.info/sct", display: "Increased vitamin A and vitamin A derivative diet (regime/therapy)" },
    { code: "1141933008", system: "http://snomed.info/sct", display: "Decreased vitamin A and vitamin A derivative diet" },
    { code: "1141934002", system: "http://snomed.info/sct", display: "Decreased vitamin D and vitamin D derivative diet (regime/therapy)" },
    { code: "1141935001", system: "http://snomed.info/sct", display: "Increased vitamin D and vitamin D derivative diet (regime/therapy)" },
    { code: "1141936000", system: "http://snomed.info/sct", display: "Vitamin D and vitamin D derivative modified diet" },
    { code: "1142125005", system: "http://snomed.info/sct", display: "Decreased linoleic acid diet" },
    { code: "1142126006", system: "http://snomed.info/sct", display: "Increased linoleic acid diet (regime/therapy)" },
    { code: "1142127002", system: "http://snomed.info/sct", display: "Omega 3 fatty acid modified diet" },
    { code: "1142128007", system: "http://snomed.info/sct", display: "Medium chain triglyceride modified diet (regime/therapy)" },
    { code: "1142129004", system: "http://snomed.info/sct", display: "Decreased N-3 fatty acid diet" },
    { code: "1142131008", system: "http://snomed.info/sct", display: "Increased omega 3 fatty acid diet" },
    { code: "1142132001", system: "http://snomed.info/sct", display: "Decreased medium chain triglyceride diet (regime/therapy)" },
    { code: "1142133006", system: "http://snomed.info/sct", display: "Increased medium chain triglyceride diet" },
    { code: "1142162007", system: "http://snomed.info/sct", display: "Decreased linolenic acid diet" },
    { code: "1142163002", system: "http://snomed.info/sct", display: "Decreased eicosapentaenoic acid diet" },
    { code: "1142164008", system: "http://snomed.info/sct", display: "Decreased docosahexaenoic acid diet (regime/therapy)" },
    { code: "1142165009", system: "http://snomed.info/sct", display: "Increased linolenic acid diet (regime/therapy)" },
    { code: "1142166005", system: "http://snomed.info/sct", display: "Increased eicosapentaenoic acid diet (regime/therapy)" },
    { code: "1142167001", system: "http://snomed.info/sct", display: "Increased docosahexaenoic acid diet" },
    { code: "1144595005", system: "http://snomed.info/sct", display: "Vitamin E and vitamin E derivative modified diet (regime/therapy)" },
    { code: "1144596006", system: "http://snomed.info/sct", display: "Increased vitamin E and vitamin E derivative diet" },
    { code: "1144598007", system: "http://snomed.info/sct", display: "Decreased vitamin E and vitamin E derivative diet (regime/therapy)" },
    { code: "1144599004", system: "http://snomed.info/sct", display: "Increased vitamin K and vitamin K derivative diet (regime/therapy)" },
    { code: "1144600001", system: "http://snomed.info/sct", display: "Decreased vitamin K and vitamin K derivative diet (regime/therapy)" },
    { code: "1144601002", system: "http://snomed.info/sct", display: "Vitamin K and vitamin K derivative modified diet" },
    { code: "1144800003", system: "http://snomed.info/sct", display: "Folate and folate derivative modified diet (regime/therapy)" },
    { code: "1144801004", system: "http://snomed.info/sct", display: "Increased folate and folate derivative diet (regime/therapy)" },
    { code: "1144802006", system: "http://snomed.info/sct", display: "Decreased folate and folate derivative diet (regime/therapy)" },
    { code: "1144804007", system: "http://snomed.info/sct", display: "Vitamin B6 and vitamin B6 derivative modified diet (regime/therapy)" },
    { code: "1144806009", system: "http://snomed.info/sct", display: "Increased vitamin B6 and vitamin B6 derivative diet" },
    { code: "1144808005", system: "http://snomed.info/sct", display: "Decreased vitamin B6 and vitamin B6 derivative diet" },
    { code: "1144996003", system: "http://snomed.info/sct", display: "Vitamin B12 and vitamin B12 derivative modified diet (regime/therapy)" },
    { code: "1144999005", system: "http://snomed.info/sct", display: "Decreased vitamin B12 and vitamin B12 derivative diet (regime/therapy)" },
    { code: "1145000005", system: "http://snomed.info/sct", display: "Increased vitamin B12 and vitamin B12 derivative diet" },
    { code: "1148495004", system: "http://snomed.info/sct", display: "Increased complex carbohydrate diet (regime/therapy)" },
    { code: "1148496003", system: "http://snomed.info/sct", display: "Decreased complex carbohydrate diet (regime/therapy)" },
    { code: "1148497007", system: "http://snomed.info/sct", display: "Increased simple carbohydrate diet" },
    { code: "1148499005", system: "http://snomed.info/sct", display: "Decreased simple carbohydrate diet (regime/therapy)" },
    { code: "1148501002", system: "http://snomed.info/sct", display: "Increased phenylalanine diet (regime/therapy)" },
    { code: "1148502009", system: "http://snomed.info/sct", display: "Phenylalanine modified diet (regime/therapy)" },
    { code: "1155728004", system: "http://snomed.info/sct", display: "Decreased chromium diet" },
    { code: "1155729007", system: "http://snomed.info/sct", display: "Sulfate salt modified diet (regime/therapy)" },
    { code: "1156314000", system: "http://snomed.info/sct", display: "Chloride salt modified diet (regime/therapy)" },
    { code: "1156315004", system: "http://snomed.info/sct", display: "Plant fiber modified diet (regime/therapy)" },
    { code: "1156443007", system: "http://snomed.info/sct", display: "Increased plant fiber diet" },
    { code: "1156444001", system: "http://snomed.info/sct", display: "Decreased plant fiber diet" },
    { code: "1156717005", system: "http://snomed.info/sct", display: "CHILD-1 - Cardiovascular Health Integrated Lifestyle Diet 1" },
    { code: "1156718000", system: "http://snomed.info/sct", display: "Cardiovascular Health Integrated Lifestyle Diet 2 Triglyceride" },
    { code: "1156719008", system: "http://snomed.info/sct", display: "Cardiovascular Health Integrated Lifestyle Diet 2 Low Density Lipoprotein" },
    { code: "1162720001", system: "http://snomed.info/sct", display: "Grain modified diet" },
    { code: "1162721002", system: "http://snomed.info/sct", display: "Vegetable modified diet" },
    { code: "1162722009", system: "http://snomed.info/sct", display: "Protein food modified diet" },
    { code: "1162724005", system: "http://snomed.info/sct", display: "Egg modified diet" },
    { code: "1162725006", system: "http://snomed.info/sct", display: "Raw egg free diet (regime/therapy)" },
    { code: "1162726007", system: "http://snomed.info/sct", display: "Fruit modified diet" },
    { code: "1162729000", system: "http://snomed.info/sct", display: "Modification of nutrition intake schedule to limit fasting" },
    { code: "1230134005", system: "http://snomed.info/sct", display: "Diet modified for uncooked food starch (regime/therapy)" },
    { code: "1230138008", system: "http://snomed.info/sct", display: "Diet modified for low protein medical food" },
    { code: "1254992009", system: "http://snomed.info/sct", display: "Caffeine free diet (regime/therapy)" },
    { code: "1254993004", system: "http://snomed.info/sct", display: "Lupin free diet (regime/therapy)" },
    { code: "1254994005", system: "http://snomed.info/sct", display: "Mammalian meat free diet" },
    { code: "1254995006", system: "http://snomed.info/sct", display: "Egg free diet (regime/therapy)" },
    { code: "1254996007", system: "http://snomed.info/sct", display: "Tree nut free diet" },
    { code: "1254998008", system: "http://snomed.info/sct", display: "Sesame free diet" },
    { code: "1254999000", system: "http://snomed.info/sct", display: "Fish free diet" },
    { code: "1255001001", system: "http://snomed.info/sct", display: "Soy free diet" },
    { code: "1255002008", system: "http://snomed.info/sct", display: "Shellfish free diet" },
    { code: "1255003003", system: "http://snomed.info/sct", display: "Peanut free diet (regime/therapy)" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidDietCodesCode(code) {
    return DietCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getDietCodesConcept(code) {
    return DietCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const DietCodesCodes = DietCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomDietCodesCode() {
    return DietCodesCodes[Math.floor(Math.random() * DietCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomDietCodesConcept() {
    return DietCodesConcepts[Math.floor(Math.random() * DietCodesConcepts.length)];
}
