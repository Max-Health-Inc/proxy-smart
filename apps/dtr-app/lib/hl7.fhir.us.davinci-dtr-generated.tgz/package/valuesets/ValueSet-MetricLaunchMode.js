/**
 * ValueSet: MetricLaunchMode
 * URL: http://hl7.org/fhir/us/davinci-dtr/ValueSet/metric-launchmode
 * Size: 4 concepts
 */
export const MetricLaunchModeConcepts = [
    { code: "crdlaunch", system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp" },
    { code: "relaunch", system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp" },
    { code: "salaunch", system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp" },
    { code: "cdexlaunch", system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidMetricLaunchModeCode(code) {
    return MetricLaunchModeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getMetricLaunchModeConcept(code) {
    return MetricLaunchModeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const MetricLaunchModeCodes = MetricLaunchModeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomMetricLaunchModeCode() {
    return MetricLaunchModeCodes[Math.floor(Math.random() * MetricLaunchModeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomMetricLaunchModeConcept() {
    return MetricLaunchModeConcepts[Math.floor(Math.random() * MetricLaunchModeConcepts.length)];
}
