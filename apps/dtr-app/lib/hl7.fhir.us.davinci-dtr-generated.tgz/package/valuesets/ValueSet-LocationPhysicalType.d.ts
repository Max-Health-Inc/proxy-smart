/**
 * ValueSet: location-physical-type
 * URL: http://hl7.org/fhir/ValueSet/location-physical-type
 * Size: 14 concepts
 */
export declare const LocationPhysicalTypeConcepts: readonly [{
    readonly code: "si";
    readonly system: "http://terminology.hl7.org/CodeSystem/location-physical-type";
}, {
    readonly code: "bu";
    readonly system: "http://terminology.hl7.org/CodeSystem/location-physical-type";
}, {
    readonly code: "wi";
    readonly system: "http://terminology.hl7.org/CodeSystem/location-physical-type";
}, {
    readonly code: "wa";
    readonly system: "http://terminology.hl7.org/CodeSystem/location-physical-type";
}, {
    readonly code: "lvl";
    readonly system: "http://terminology.hl7.org/CodeSystem/location-physical-type";
}, {
    readonly code: "co";
    readonly system: "http://terminology.hl7.org/CodeSystem/location-physical-type";
}, {
    readonly code: "ro";
    readonly system: "http://terminology.hl7.org/CodeSystem/location-physical-type";
}, {
    readonly code: "bd";
    readonly system: "http://terminology.hl7.org/CodeSystem/location-physical-type";
}, {
    readonly code: "ve";
    readonly system: "http://terminology.hl7.org/CodeSystem/location-physical-type";
}, {
    readonly code: "ho";
    readonly system: "http://terminology.hl7.org/CodeSystem/location-physical-type";
}, {
    readonly code: "ca";
    readonly system: "http://terminology.hl7.org/CodeSystem/location-physical-type";
}, {
    readonly code: "rd";
    readonly system: "http://terminology.hl7.org/CodeSystem/location-physical-type";
}, {
    readonly code: "area";
    readonly system: "http://terminology.hl7.org/CodeSystem/location-physical-type";
}, {
    readonly code: "jdn";
    readonly system: "http://terminology.hl7.org/CodeSystem/location-physical-type";
}];
/** Union type of all valid codes in this ValueSet */
export type LocationPhysicalTypeCode = "si" | "bu" | "wi" | "wa" | "lvl" | "co" | "ro" | "bd" | "ve" | "ho" | "ca" | "rd" | "area" | "jdn";
/** Type representing a concept from this ValueSet */
export type LocationPhysicalTypeConcept = typeof LocationPhysicalTypeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidLocationPhysicalTypeCode(code: string): code is LocationPhysicalTypeCode;
/**
 * Get concept details by code
 */
export declare function getLocationPhysicalTypeConcept(code: string): LocationPhysicalTypeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const LocationPhysicalTypeCodes: ("si" | "bu" | "wi" | "wa" | "lvl" | "co" | "ro" | "bd" | "ve" | "ho" | "ca" | "rd" | "area" | "jdn")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomLocationPhysicalTypeCode(): LocationPhysicalTypeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomLocationPhysicalTypeConcept(): LocationPhysicalTypeConcept;
