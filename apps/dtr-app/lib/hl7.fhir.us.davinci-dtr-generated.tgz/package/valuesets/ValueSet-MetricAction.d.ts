/**
 * ValueSet: MetricAction
 * URL: http://hl7.org/fhir/us/davinci-dtr/ValueSet/metric-Action
 * Size: 6 concepts
 */
export declare const MetricActionConcepts: readonly [{
    readonly code: "launch";
    readonly system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp";
}, {
    readonly code: "qpackage";
    readonly system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp";
}, {
    readonly code: "mrquery";
    readonly system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp";
}, {
    readonly code: "nextq";
    readonly system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp";
}, {
    readonly code: "userresponse";
    readonly system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp";
}, {
    readonly code: "storeqr";
    readonly system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp";
}];
/** Union type of all valid codes in this ValueSet */
export type MetricActionCode = "launch" | "qpackage" | "mrquery" | "nextq" | "userresponse" | "storeqr";
/** Type representing a concept from this ValueSet */
export type MetricActionConcept = typeof MetricActionConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidMetricActionCode(code: string): code is MetricActionCode;
/**
 * Get concept details by code
 */
export declare function getMetricActionConcept(code: string): MetricActionConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const MetricActionCodes: ("launch" | "qpackage" | "mrquery" | "nextq" | "userresponse" | "storeqr")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomMetricActionCode(): MetricActionCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomMetricActionConcept(): MetricActionConcept;
