/**
 * ValueSet: entformula-type
 * URL: http://hl7.org/fhir/ValueSet/entformula-type
 * Size: 36 concepts
 */
export const EntformulaTypeConcepts = [
    { code: "443031000124106", system: "http://snomed.info/sct" },
    { code: "443051000124104", system: "http://snomed.info/sct" },
    { code: "442911000124109", system: "http://snomed.info/sct" },
    { code: "443021000124108", system: "http://snomed.info/sct" },
    { code: "442971000124100", system: "http://snomed.info/sct" },
    { code: "442981000124102", system: "http://snomed.info/sct" },
    { code: "442991000124104", system: "http://snomed.info/sct" },
    { code: "443011000124100", system: "http://snomed.info/sct" },
    { code: "442961000124107", system: "http://snomed.info/sct" },
    { code: "442951000124105", system: "http://snomed.info/sct" },
    { code: "442941000124108", system: "http://snomed.info/sct" },
    { code: "442921000124101", system: "http://snomed.info/sct" },
    { code: "442931000124103", system: "http://snomed.info/sct" },
    { code: "443361000124100", system: "http://snomed.info/sct" },
    { code: "443401000124105", system: "http://snomed.info/sct" },
    { code: "443491000124103", system: "http://snomed.info/sct" },
    { code: "443501000124106", system: "http://snomed.info/sct" },
    { code: "443421000124100", system: "http://snomed.info/sct" },
    { code: "443471000124104", system: "http://snomed.info/sct" },
    { code: "444431000124104", system: "http://snomed.info/sct" },
    { code: "443451000124109", system: "http://snomed.info/sct" },
    { code: "441561000124106", system: "http://snomed.info/sct" },
    { code: "443461000124106", system: "http://snomed.info/sct" },
    { code: "441531000124102", system: "http://snomed.info/sct" },
    { code: "443561000124107", system: "http://snomed.info/sct" },
    { code: "443481000124101", system: "http://snomed.info/sct" },
    { code: "441571000124104", system: "http://snomed.info/sct" },
    { code: "441591000124103", system: "http://snomed.info/sct" },
    { code: "441601000124106", system: "http://snomed.info/sct" },
    { code: "443351000124102", system: "http://snomed.info/sct" },
    { code: "443771000124106", system: "http://snomed.info/sct" },
    { code: "441671000124100", system: "http://snomed.info/sct" },
    { code: "443111000124101", system: "http://snomed.info/sct" },
    { code: "443431000124102", system: "http://snomed.info/sct" },
    { code: "443411000124108", system: "http://snomed.info/sct" },
    { code: "442651000124102", system: "http://snomed.info/sct" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidEntformulaTypeCode(code) {
    return EntformulaTypeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getEntformulaTypeConcept(code) {
    return EntformulaTypeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const EntformulaTypeCodes = EntformulaTypeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomEntformulaTypeCode() {
    return EntformulaTypeCodes[Math.floor(Math.random() * EntformulaTypeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomEntformulaTypeConcept() {
    return EntformulaTypeConcepts[Math.floor(Math.random() * EntformulaTypeConcepts.length)];
}
