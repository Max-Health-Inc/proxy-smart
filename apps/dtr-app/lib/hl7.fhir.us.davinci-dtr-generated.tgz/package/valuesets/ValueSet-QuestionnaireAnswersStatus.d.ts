/**
 * ValueSet: questionnaire-answers-status
 * URL: http://hl7.org/fhir/ValueSet/questionnaire-answers-status
 * Size: 5 concepts
 */
export declare const QuestionnaireAnswersStatusConcepts: readonly [{
    readonly code: "in-progress";
    readonly system: "http://hl7.org/fhir/questionnaire-answers-status";
}, {
    readonly code: "completed";
    readonly system: "http://hl7.org/fhir/questionnaire-answers-status";
}, {
    readonly code: "amended";
    readonly system: "http://hl7.org/fhir/questionnaire-answers-status";
}, {
    readonly code: "entered-in-error";
    readonly system: "http://hl7.org/fhir/questionnaire-answers-status";
}, {
    readonly code: "stopped";
    readonly system: "http://hl7.org/fhir/questionnaire-answers-status";
}];
/** Union type of all valid codes in this ValueSet */
export type QuestionnaireAnswersStatusCode = "in-progress" | "completed" | "amended" | "entered-in-error" | "stopped";
/** Type representing a concept from this ValueSet */
export type QuestionnaireAnswersStatusConcept = typeof QuestionnaireAnswersStatusConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidQuestionnaireAnswersStatusCode(code: string): code is QuestionnaireAnswersStatusCode;
/**
 * Get concept details by code
 */
export declare function getQuestionnaireAnswersStatusConcept(code: string): QuestionnaireAnswersStatusConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const QuestionnaireAnswersStatusCodes: ("entered-in-error" | "completed" | "in-progress" | "amended" | "stopped")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomQuestionnaireAnswersStatusCode(): QuestionnaireAnswersStatusCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomQuestionnaireAnswersStatusConcept(): QuestionnaireAnswersStatusConcept;
