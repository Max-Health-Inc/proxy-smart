/**
 * ValueSet: encounter-admit-source
 * URL: http://hl7.org/fhir/ValueSet/encounter-admit-source
 * Size: 10 concepts
 */
export declare const EncounterAdmitSourceConcepts: readonly [{
    readonly code: "hosp-trans";
    readonly system: "http://terminology.hl7.org/CodeSystem/admit-source";
}, {
    readonly code: "emd";
    readonly system: "http://terminology.hl7.org/CodeSystem/admit-source";
}, {
    readonly code: "outp";
    readonly system: "http://terminology.hl7.org/CodeSystem/admit-source";
}, {
    readonly code: "born";
    readonly system: "http://terminology.hl7.org/CodeSystem/admit-source";
}, {
    readonly code: "gp";
    readonly system: "http://terminology.hl7.org/CodeSystem/admit-source";
}, {
    readonly code: "mp";
    readonly system: "http://terminology.hl7.org/CodeSystem/admit-source";
}, {
    readonly code: "nursing";
    readonly system: "http://terminology.hl7.org/CodeSystem/admit-source";
}, {
    readonly code: "psych";
    readonly system: "http://terminology.hl7.org/CodeSystem/admit-source";
}, {
    readonly code: "rehab";
    readonly system: "http://terminology.hl7.org/CodeSystem/admit-source";
}, {
    readonly code: "other";
    readonly system: "http://terminology.hl7.org/CodeSystem/admit-source";
}];
/** Union type of all valid codes in this ValueSet */
export type EncounterAdmitSourceCode = "hosp-trans" | "emd" | "outp" | "born" | "gp" | "mp" | "nursing" | "psych" | "rehab" | "other";
/** Type representing a concept from this ValueSet */
export type EncounterAdmitSourceConcept = typeof EncounterAdmitSourceConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidEncounterAdmitSourceCode(code: string): code is EncounterAdmitSourceCode;
/**
 * Get concept details by code
 */
export declare function getEncounterAdmitSourceConcept(code: string): EncounterAdmitSourceConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const EncounterAdmitSourceCodes: ("other" | "hosp-trans" | "emd" | "outp" | "born" | "gp" | "mp" | "nursing" | "psych" | "rehab")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomEncounterAdmitSourceCode(): EncounterAdmitSourceCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomEncounterAdmitSourceConcept(): EncounterAdmitSourceConcept;
