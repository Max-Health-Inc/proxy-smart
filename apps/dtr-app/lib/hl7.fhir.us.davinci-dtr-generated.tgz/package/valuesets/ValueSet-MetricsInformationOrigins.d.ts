/**
 * ValueSet: MetricsInformationOrigins
 * URL: http://hl7.org/fhir/us/davinci-dtr/ValueSet/MetricsinformationOrigins
 * Size: 2 concepts
 */
export declare const MetricsInformationOriginsConcepts: readonly [{
    readonly code: "override";
    readonly system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp";
}, {
    readonly code: "manual";
    readonly system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp";
}];
/** Union type of all valid codes in this ValueSet */
export type MetricsInformationOriginsCode = "override" | "manual";
/** Type representing a concept from this ValueSet */
export type MetricsInformationOriginsConcept = typeof MetricsInformationOriginsConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidMetricsInformationOriginsCode(code: string): code is MetricsInformationOriginsCode;
/**
 * Get concept details by code
 */
export declare function getMetricsInformationOriginsConcept(code: string): MetricsInformationOriginsConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const MetricsInformationOriginsCodes: ("manual" | "override")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomMetricsInformationOriginsCode(): MetricsInformationOriginsCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomMetricsInformationOriginsConcept(): MetricsInformationOriginsConcept;
