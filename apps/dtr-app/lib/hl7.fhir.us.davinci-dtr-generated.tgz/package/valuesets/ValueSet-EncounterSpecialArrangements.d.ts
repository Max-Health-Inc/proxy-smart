/**
 * ValueSet: encounter-special-arrangements
 * URL: http://hl7.org/fhir/ValueSet/encounter-special-arrangements
 * Size: 5 concepts
 */
export declare const EncounterSpecialArrangementsConcepts: readonly [{
    readonly code: "wheel";
    readonly system: "http://terminology.hl7.org/CodeSystem/encounter-special-arrangements";
}, {
    readonly code: "add-bed";
    readonly system: "http://terminology.hl7.org/CodeSystem/encounter-special-arrangements";
}, {
    readonly code: "int";
    readonly system: "http://terminology.hl7.org/CodeSystem/encounter-special-arrangements";
}, {
    readonly code: "att";
    readonly system: "http://terminology.hl7.org/CodeSystem/encounter-special-arrangements";
}, {
    readonly code: "dog";
    readonly system: "http://terminology.hl7.org/CodeSystem/encounter-special-arrangements";
}];
/** Union type of all valid codes in this ValueSet */
export type EncounterSpecialArrangementsCode = "wheel" | "add-bed" | "int" | "att" | "dog";
/** Type representing a concept from this ValueSet */
export type EncounterSpecialArrangementsConcept = typeof EncounterSpecialArrangementsConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidEncounterSpecialArrangementsCode(code: string): code is EncounterSpecialArrangementsCode;
/**
 * Get concept details by code
 */
export declare function getEncounterSpecialArrangementsConcept(code: string): EncounterSpecialArrangementsConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const EncounterSpecialArrangementsCodes: ("wheel" | "add-bed" | "int" | "att" | "dog")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomEncounterSpecialArrangementsCode(): EncounterSpecialArrangementsCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomEncounterSpecialArrangementsConcept(): EncounterSpecialArrangementsConcept;
