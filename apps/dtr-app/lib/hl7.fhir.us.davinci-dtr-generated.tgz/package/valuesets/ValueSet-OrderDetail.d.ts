/**
 * ValueSet: orderDetail
 * URL: http://hl7.org/fhir/us/davinci-crd/ValueSet/orderDetail
 * Size: 2 concepts
 */
export declare const OrderDetailConcepts: readonly [{
    readonly code: "lens";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-visionprescriptionproduct";
}, {
    readonly code: "contact";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-visionprescriptionproduct";
}];
/** Union type of all valid codes in this ValueSet */
export type OrderDetailCode = "lens" | "contact";
/** Type representing a concept from this ValueSet */
export type OrderDetailConcept = typeof OrderDetailConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidOrderDetailCode(code: string): code is OrderDetailCode;
/**
 * Get concept details by code
 */
export declare function getOrderDetailConcept(code: string): OrderDetailConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const OrderDetailCodes: ("contact" | "lens")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomOrderDetailCode(): OrderDetailCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomOrderDetailConcept(): OrderDetailConcept;
