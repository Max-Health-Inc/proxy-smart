/**
 * ValueSet: condition-code
 * URL: http://hl7.org/fhir/ValueSet/condition-code
 * Size: 15 concepts
 */
export const ConditionCodeConcepts = [
    { code: "27113001", system: "http://snomed.info/sct" },
    { code: "50373000", system: "http://snomed.info/sct" },
    { code: "75367002", system: "http://snomed.info/sct" },
    { code: "364075005", system: "http://snomed.info/sct" },
    { code: "86290005", system: "http://snomed.info/sct" },
    { code: "386725007", system: "http://snomed.info/sct" },
    { code: "431314004", system: "http://snomed.info/sct" },
    { code: "60621009", system: "http://snomed.info/sct" },
    { code: "271649006", system: "http://snomed.info/sct" },
    { code: "271650006", system: "http://snomed.info/sct" },
    { code: "404684003", system: "http://snomed.info/sct" },
    { code: "118228005", system: "http://snomed.info/sct" },
    { code: "250171008", system: "http://snomed.info/sct" },
    { code: "363787002", system: "http://snomed.info/sct" },
    { code: "386661006", system: "http://snomed.info/sct" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidConditionCodeCode(code) {
    return ConditionCodeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getConditionCodeConcept(code) {
    return ConditionCodeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ConditionCodeCodes = ConditionCodeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomConditionCodeCode() {
    return ConditionCodeCodes[Math.floor(Math.random() * ConditionCodeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomConditionCodeConcept() {
    return ConditionCodeConcepts[Math.floor(Math.random() * ConditionCodeConcepts.length)];
}
