/**
 * ValueSet: ParticipationStatus
 * URL: http://hl7.org/fhir/ValueSet/participationstatus
 * Size: 4 concepts
 */
export declare const ParticipationStatusConcepts: readonly [{
    readonly code: "accepted";
    readonly system: "http://hl7.org/fhir/participationstatus";
    readonly display: "Accepted";
}, {
    readonly code: "declined";
    readonly system: "http://hl7.org/fhir/participationstatus";
    readonly display: "Declined";
}, {
    readonly code: "tentative";
    readonly system: "http://hl7.org/fhir/participationstatus";
    readonly display: "Tentative";
}, {
    readonly code: "needs-action";
    readonly system: "http://hl7.org/fhir/participationstatus";
    readonly display: "Needs Action";
}];
/** Union type of all valid codes in this ValueSet */
export type ParticipationStatusCode = "accepted" | "declined" | "tentative" | "needs-action";
/** Type representing a concept from this ValueSet */
export type ParticipationStatusConcept = typeof ParticipationStatusConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidParticipationStatusCode(code: string): code is ParticipationStatusCode;
/**
 * Get concept details by code
 */
export declare function getParticipationStatusConcept(code: string): ParticipationStatusConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ParticipationStatusCodes: ("accepted" | "declined" | "tentative" | "needs-action")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomParticipationStatusCode(): ParticipationStatusCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomParticipationStatusConcept(): ParticipationStatusConcept;
