/**
 * ValueSet: MetricsInformationOrigins
 * URL: http://hl7.org/fhir/us/davinci-dtr/ValueSet/MetricsinformationOrigins
 * Size: 2 concepts
 */
export const MetricsInformationOriginsConcepts = [
    { code: "override", system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp" },
    { code: "manual", system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidMetricsInformationOriginsCode(code) {
    return MetricsInformationOriginsConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getMetricsInformationOriginsConcept(code) {
    return MetricsInformationOriginsConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const MetricsInformationOriginsCodes = MetricsInformationOriginsConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomMetricsInformationOriginsCode() {
    return MetricsInformationOriginsCodes[Math.floor(Math.random() * MetricsInformationOriginsCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomMetricsInformationOriginsConcept() {
    return MetricsInformationOriginsConcepts[Math.floor(Math.random() * MetricsInformationOriginsConcepts.length)];
}
