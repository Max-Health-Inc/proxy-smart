/**
 * ValueSet: medicationRequest Intent
 * URL: http://hl7.org/fhir/ValueSet/medicationrequest-intent
 * Size: 8 concepts
 */
export declare const MedicationRequestIntentConcepts: readonly [{
    readonly code: "proposal";
    readonly system: "http://hl7.org/fhir/CodeSystem/medicationrequest-intent";
    readonly display: "Proposal";
}, {
    readonly code: "plan";
    readonly system: "http://hl7.org/fhir/CodeSystem/medicationrequest-intent";
    readonly display: "Plan";
}, {
    readonly code: "order";
    readonly system: "http://hl7.org/fhir/CodeSystem/medicationrequest-intent";
    readonly display: "Order";
}, {
    readonly code: "original-order";
    readonly system: "http://hl7.org/fhir/CodeSystem/medicationrequest-intent";
    readonly display: "Original Order";
}, {
    readonly code: "reflex-order";
    readonly system: "http://hl7.org/fhir/CodeSystem/medicationrequest-intent";
    readonly display: "Reflex Order";
}, {
    readonly code: "filler-order";
    readonly system: "http://hl7.org/fhir/CodeSystem/medicationrequest-intent";
    readonly display: "Filler Order";
}, {
    readonly code: "instance-order";
    readonly system: "http://hl7.org/fhir/CodeSystem/medicationrequest-intent";
    readonly display: "Instance Order";
}, {
    readonly code: "option";
    readonly system: "http://hl7.org/fhir/CodeSystem/medicationrequest-intent";
    readonly display: "Option";
}];
/** Union type of all valid codes in this ValueSet */
export type MedicationRequestIntentCode = "proposal" | "plan" | "order" | "original-order" | "reflex-order" | "filler-order" | "instance-order" | "option";
/** Type representing a concept from this ValueSet */
export type MedicationRequestIntentConcept = typeof MedicationRequestIntentConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidMedicationRequestIntentCode(code: string): code is MedicationRequestIntentCode;
/**
 * Get concept details by code
 */
export declare function getMedicationRequestIntentConcept(code: string): MedicationRequestIntentConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const MedicationRequestIntentCodes: ("order" | "option" | "proposal" | "plan" | "original-order" | "reflex-order" | "filler-order" | "instance-order")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomMedicationRequestIntentCode(): MedicationRequestIntentCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomMedicationRequestIntentConcept(): MedicationRequestIntentConcept;
