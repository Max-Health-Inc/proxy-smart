/**
 * ValueSet: Jurisdiction ValueSet
 * URL: http://hl7.org/fhir/ValueSet/jurisdiction
 * Size: 100 concepts
 */
export const JurisdictionValueSetConcepts = [
    { code: "AD", system: "urn:iso:std:iso:3166", display: "Andorra" },
    { code: "AE", system: "urn:iso:std:iso:3166", display: "United Arab Emirates" },
    { code: "AF", system: "urn:iso:std:iso:3166", display: "Afghanistan" },
    { code: "AG", system: "urn:iso:std:iso:3166", display: "Antigua and Barbuda" },
    { code: "AI", system: "urn:iso:std:iso:3166", display: "Anguilla" },
    { code: "AL", system: "urn:iso:std:iso:3166", display: "Albania" },
    { code: "AM", system: "urn:iso:std:iso:3166", display: "Armenia" },
    { code: "AO", system: "urn:iso:std:iso:3166", display: "Angola" },
    { code: "AQ", system: "urn:iso:std:iso:3166", display: "Antarctica" },
    { code: "AR", system: "urn:iso:std:iso:3166", display: "Argentina" },
    { code: "AS", system: "urn:iso:std:iso:3166", display: "American Samoa" },
    { code: "AT", system: "urn:iso:std:iso:3166", display: "Austria" },
    { code: "AU", system: "urn:iso:std:iso:3166", display: "Australia" },
    { code: "AW", system: "urn:iso:std:iso:3166", display: "Aruba" },
    { code: "AX", system: "urn:iso:std:iso:3166", display: "Åland Islands" },
    { code: "AZ", system: "urn:iso:std:iso:3166", display: "Azerbaijan" },
    { code: "BA", system: "urn:iso:std:iso:3166", display: "Bosnia and Herzegovina" },
    { code: "BB", system: "urn:iso:std:iso:3166", display: "Barbados" },
    { code: "BD", system: "urn:iso:std:iso:3166", display: "Bangladesh" },
    { code: "BE", system: "urn:iso:std:iso:3166", display: "Belgium" },
    { code: "BF", system: "urn:iso:std:iso:3166", display: "Burkina Faso" },
    { code: "BG", system: "urn:iso:std:iso:3166", display: "Bulgaria" },
    { code: "BH", system: "urn:iso:std:iso:3166", display: "Bahrain" },
    { code: "BI", system: "urn:iso:std:iso:3166", display: "Burundi" },
    { code: "BJ", system: "urn:iso:std:iso:3166", display: "Benin" },
    { code: "BL", system: "urn:iso:std:iso:3166", display: "Saint Barthélemy" },
    { code: "BM", system: "urn:iso:std:iso:3166", display: "Bermuda" },
    { code: "BN", system: "urn:iso:std:iso:3166", display: "Brunei Darussalam" },
    { code: "BO", system: "urn:iso:std:iso:3166", display: "Bolivia, Plurinational State of" },
    { code: "BQ", system: "urn:iso:std:iso:3166", display: "Bonaire, Sint Eustatius and Saba" },
    { code: "BR", system: "urn:iso:std:iso:3166", display: "Brazil" },
    { code: "BS", system: "urn:iso:std:iso:3166", display: "Bahamas" },
    { code: "BT", system: "urn:iso:std:iso:3166", display: "Bhutan" },
    { code: "BV", system: "urn:iso:std:iso:3166", display: "Bouvet Island" },
    { code: "BW", system: "urn:iso:std:iso:3166", display: "Botswana" },
    { code: "BY", system: "urn:iso:std:iso:3166", display: "Belarus" },
    { code: "BZ", system: "urn:iso:std:iso:3166", display: "Belize" },
    { code: "CA", system: "urn:iso:std:iso:3166", display: "Canada" },
    { code: "CC", system: "urn:iso:std:iso:3166", display: "Cocos (Keeling) Islands" },
    { code: "CD", system: "urn:iso:std:iso:3166", display: "Congo, the Democratic Republic of the" },
    { code: "CF", system: "urn:iso:std:iso:3166", display: "Central African Republic" },
    { code: "CG", system: "urn:iso:std:iso:3166", display: "Congo" },
    { code: "CH", system: "urn:iso:std:iso:3166", display: "Switzerland" },
    { code: "CI", system: "urn:iso:std:iso:3166", display: "Côte d'Ivoire" },
    { code: "CK", system: "urn:iso:std:iso:3166", display: "Cook Islands" },
    { code: "CL", system: "urn:iso:std:iso:3166", display: "Chile" },
    { code: "CM", system: "urn:iso:std:iso:3166", display: "Cameroon" },
    { code: "CN", system: "urn:iso:std:iso:3166", display: "China" },
    { code: "CO", system: "urn:iso:std:iso:3166", display: "Colombia" },
    { code: "CR", system: "urn:iso:std:iso:3166", display: "Costa Rica" },
    { code: "CU", system: "urn:iso:std:iso:3166", display: "Cuba" },
    { code: "CV", system: "urn:iso:std:iso:3166", display: "Cabo Verde" },
    { code: "CW", system: "urn:iso:std:iso:3166", display: "Curaçao" },
    { code: "CX", system: "urn:iso:std:iso:3166", display: "Christmas Island" },
    { code: "CY", system: "urn:iso:std:iso:3166", display: "Cyprus" },
    { code: "CZ", system: "urn:iso:std:iso:3166", display: "Czechia" },
    { code: "DE", system: "urn:iso:std:iso:3166", display: "Germany" },
    { code: "DJ", system: "urn:iso:std:iso:3166", display: "Djibouti" },
    { code: "DK", system: "urn:iso:std:iso:3166", display: "Denmark" },
    { code: "DM", system: "urn:iso:std:iso:3166", display: "Dominica" },
    { code: "DO", system: "urn:iso:std:iso:3166", display: "Dominican Republic" },
    { code: "DZ", system: "urn:iso:std:iso:3166", display: "Algeria" },
    { code: "EC", system: "urn:iso:std:iso:3166", display: "Ecuador" },
    { code: "EE", system: "urn:iso:std:iso:3166", display: "Estonia" },
    { code: "EG", system: "urn:iso:std:iso:3166", display: "Egypt" },
    { code: "EH", system: "urn:iso:std:iso:3166", display: "Western Sahara" },
    { code: "ER", system: "urn:iso:std:iso:3166", display: "Eritrea" },
    { code: "ES", system: "urn:iso:std:iso:3166", display: "Spain" },
    { code: "ET", system: "urn:iso:std:iso:3166", display: "Ethiopia" },
    { code: "FI", system: "urn:iso:std:iso:3166", display: "Finland" },
    { code: "FJ", system: "urn:iso:std:iso:3166", display: "Fiji" },
    { code: "FK", system: "urn:iso:std:iso:3166", display: "Falkland Islands (Malvinas)" },
    { code: "FM", system: "urn:iso:std:iso:3166", display: "Micronesia, Federated States of" },
    { code: "FO", system: "urn:iso:std:iso:3166", display: "Faroe Islands" },
    { code: "FR", system: "urn:iso:std:iso:3166", display: "France" },
    { code: "GA", system: "urn:iso:std:iso:3166", display: "Gabon" },
    { code: "GB", system: "urn:iso:std:iso:3166", display: "United Kingdom of Great Britain and Northern Ireland" },
    { code: "GD", system: "urn:iso:std:iso:3166", display: "Grenada" },
    { code: "GE", system: "urn:iso:std:iso:3166", display: "Georgia" },
    { code: "GF", system: "urn:iso:std:iso:3166", display: "French Guiana" },
    { code: "GG", system: "urn:iso:std:iso:3166", display: "Guernsey" },
    { code: "GH", system: "urn:iso:std:iso:3166", display: "Ghana" },
    { code: "GI", system: "urn:iso:std:iso:3166", display: "Gibraltar" },
    { code: "GL", system: "urn:iso:std:iso:3166", display: "Greenland" },
    { code: "GM", system: "urn:iso:std:iso:3166", display: "Gambia" },
    { code: "GN", system: "urn:iso:std:iso:3166", display: "Guinea" },
    { code: "GP", system: "urn:iso:std:iso:3166", display: "Guadeloupe" },
    { code: "GQ", system: "urn:iso:std:iso:3166", display: "Equatorial Guinea" },
    { code: "GR", system: "urn:iso:std:iso:3166", display: "Greece" },
    { code: "GS", system: "urn:iso:std:iso:3166", display: "South Georgia and the South Sandwich Islands" },
    { code: "GT", system: "urn:iso:std:iso:3166", display: "Guatemala" },
    { code: "GU", system: "urn:iso:std:iso:3166", display: "Guam" },
    { code: "GW", system: "urn:iso:std:iso:3166", display: "Guinea-Bissau" },
    { code: "GY", system: "urn:iso:std:iso:3166", display: "Guyana" },
    { code: "HK", system: "urn:iso:std:iso:3166", display: "Hong Kong" },
    { code: "HM", system: "urn:iso:std:iso:3166", display: "Heard Island and McDonald Islands" },
    { code: "HN", system: "urn:iso:std:iso:3166", display: "Honduras" },
    { code: "HR", system: "urn:iso:std:iso:3166", display: "Croatia" },
    { code: "HT", system: "urn:iso:std:iso:3166", display: "Haiti" },
    { code: "HU", system: "urn:iso:std:iso:3166", display: "Hungary" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidJurisdictionValueSetCode(code) {
    return JurisdictionValueSetConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getJurisdictionValueSetConcept(code) {
    return JurisdictionValueSetConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const JurisdictionValueSetCodes = JurisdictionValueSetConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomJurisdictionValueSetCode() {
    return JurisdictionValueSetCodes[Math.floor(Math.random() * JurisdictionValueSetCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomJurisdictionValueSetConcept() {
    return JurisdictionValueSetConcepts[Math.floor(Math.random() * JurisdictionValueSetConcepts.length)];
}
