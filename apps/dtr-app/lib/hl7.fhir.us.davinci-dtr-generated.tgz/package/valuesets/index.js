/**
 * ValueSet Registry
 * Central registry of all loaded ValueSets with explicit codes
 */
import * as AdditionalDocumentation from './ValueSet-AdditionalDocumentation.js';
import * as BodySite from './ValueSet-BodySite.js';
import * as BundleType from './ValueSet-BundleType.js';
import * as ConditionCode from './ValueSet-ConditionCode.js';
import * as CoverageInfo from './ValueSet-CoverageInfo.js';
import * as CoveragePaDetail from './ValueSet-CoveragePaDetail.js';
import * as DocReason from './ValueSet-DocReason.js';
import * as DTRInformationOrigins from './ValueSet-DTRInformationOrigins.js';
import * as EncounterStatus from './ValueSet-EncounterStatus.js';
import * as FmStatus from './ValueSet-FmStatus.js';
import * as HttpVerb from './ValueSet-HttpVerb.js';
import * as IdentifierUse from './ValueSet-IdentifierUse.js';
import * as InformationNeeded from './ValueSet-InformationNeeded.js';
import * as ItemType from './ValueSet-ItemType.js';
import * as MedicationrequestStatus from './ValueSet-MedicationrequestStatus.js';
import * as MetricAction from './ValueSet-MetricAction.js';
import * as MetricLaunchMode from './ValueSet-MetricLaunchMode.js';
import * as MetricsInformationOrigins from './ValueSet-MetricsInformationOrigins.js';
import * as MetricSource from './ValueSet-MetricSource.js';
import * as NarrativeStatus from './ValueSet-NarrativeStatus.js';
import * as OrderDetail from './ValueSet-OrderDetail.js';
import * as PublicationStatus from './ValueSet-PublicationStatus.js';
import * as QuestionnaireAnswersStatus from './ValueSet-QuestionnaireAnswersStatus.js';
import * as RequestIntent from './ValueSet-RequestIntent.js';
import * as RequestPriority from './ValueSet-RequestPriority.js';
import * as RequestStatus from './ValueSet-RequestStatus.js';
import * as ServiceRequestCodes from './ValueSet-ServiceRequestCodes.js';
import * as UsCoreProviderRole from './ValueSet-UsCoreProviderRole.js';
import * as V20092 from './ValueSet-V20092.js';
import * as V20276 from './ValueSet-V20276.js';
import * as V3ActPriority from './ValueSet-V3ActPriority.js';
import * as V3ActReason from './ValueSet-V3ActReason.js';
import * as V3ParticipationMode from './ValueSet-V3ParticipationMode.js';
import * as VS21684011142224113591 from './ValueSet-VS21684011142224113591.js';
export const ValueSetRegistry = {
    AdditionalDocumentation,
    BodySite,
    BundleType,
    ConditionCode,
    CoverageInfo,
    CoveragePaDetail,
    DocReason,
    DTRInformationOrigins,
    EncounterStatus,
    FmStatus,
    HttpVerb,
    IdentifierUse,
    InformationNeeded,
    ItemType,
    MedicationrequestStatus,
    MetricAction,
    MetricLaunchMode,
    MetricsInformationOrigins,
    MetricSource,
    NarrativeStatus,
    OrderDetail,
    PublicationStatus,
    QuestionnaireAnswersStatus,
    RequestIntent,
    RequestPriority,
    RequestStatus,
    ServiceRequestCodes,
    UsCoreProviderRole,
    V20092,
    V20276,
    V3ActPriority,
    V3ActReason,
    V3ParticipationMode,
    VS21684011142224113591,
};
export function getValueSet(name) {
    return ValueSetRegistry[name];
}
/** Map from ValueSet URL to registry name */
export const ValueSetUrlMap = {
    'http://hl7.org/fhir/us/davinci-crd/ValueSet/AdditionalDocumentation': 'AdditionalDocumentation',
    'http://hl7.org/fhir/ValueSet/body-site': 'BodySite',
    'http://hl7.org/fhir/ValueSet/bundle-type': 'BundleType',
    'http://hl7.org/fhir/ValueSet/condition-code': 'ConditionCode',
    'http://hl7.org/fhir/us/davinci-crd/ValueSet/coverageInfo': 'CoverageInfo',
    'http://hl7.org/fhir/us/davinci-crd/ValueSet/coveragePaDetail': 'CoveragePaDetail',
    'http://hl7.org/fhir/us/davinci-crd/ValueSet/DocReason': 'DocReason',
    'http://hl7.org/fhir/us/davinci-dtr/ValueSet/informationOrigins': 'DTRInformationOrigins',
    'http://hl7.org/fhir/ValueSet/encounter-status': 'EncounterStatus',
    'http://hl7.org/fhir/ValueSet/fm-status': 'FmStatus',
    'http://hl7.org/fhir/ValueSet/http-verb': 'HttpVerb',
    'http://hl7.org/fhir/ValueSet/identifier-use': 'IdentifierUse',
    'http://hl7.org/fhir/us/davinci-crd/ValueSet/informationNeeded': 'InformationNeeded',
    'http://hl7.org/fhir/ValueSet/item-type': 'ItemType',
    'http://hl7.org/fhir/ValueSet/medicationrequest-status': 'MedicationrequestStatus',
    'http://hl7.org/fhir/us/davinci-dtr/ValueSet/metric-Action': 'MetricAction',
    'http://hl7.org/fhir/us/davinci-dtr/ValueSet/metric-launchmode': 'MetricLaunchMode',
    'http://hl7.org/fhir/us/davinci-dtr/ValueSet/MetricsinformationOrigins': 'MetricsInformationOrigins',
    'http://hl7.org/fhir/us/davinci-dtr/ValueSet/metric-Source': 'MetricSource',
    'http://hl7.org/fhir/ValueSet/narrative-status': 'NarrativeStatus',
    'http://hl7.org/fhir/us/davinci-crd/ValueSet/orderDetail': 'OrderDetail',
    'http://hl7.org/fhir/ValueSet/publication-status': 'PublicationStatus',
    'http://hl7.org/fhir/ValueSet/questionnaire-answers-status': 'QuestionnaireAnswersStatus',
    'http://hl7.org/fhir/ValueSet/request-intent': 'RequestIntent',
    'http://hl7.org/fhir/ValueSet/request-priority': 'RequestPriority',
    'http://hl7.org/fhir/ValueSet/request-status': 'RequestStatus',
    'http://hl7.org/fhir/us/davinci-crd/ValueSet/serviceRequestCodes': 'ServiceRequestCodes',
    'http://hl7.org/fhir/us/core/ValueSet/us-core-provider-role': 'UsCoreProviderRole',
    'http://terminology.hl7.org/ValueSet/v2-0092': 'V20092',
    'http://terminology.hl7.org/ValueSet/v2-0276': 'V20276',
    'http://terminology.hl7.org/ValueSet/v3-ActPriority': 'V3ActPriority',
    'http://terminology.hl7.org/ValueSet/v3-ActReason': 'V3ActReason',
    'http://terminology.hl7.org/ValueSet/v3-ParticipationMode': 'V3ParticipationMode',
    'http://cts.nlm.nih.gov/fhir/ValueSet/2.16.840.1.114222.4.11.3591': 'VS21684011142224113591',
};
function stripVersionFromUrl(url) {
    const pipeIndex = url.indexOf('|');
    return pipeIndex >= 0 ? url.substring(0, pipeIndex) : url;
}
/**
 * Get a random code from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A random code string, or undefined if ValueSet not found
 */
export function getRandomCodeByUrl(url) {
    const cleanUrl = stripVersionFromUrl(url);
    const name = ValueSetUrlMap[cleanUrl];
    if (!name)
        return undefined;
    const vs = ValueSetRegistry[name];
    // Each ValueSet exports random<Name>Code() function
    const randomFn = vs['random' + name + 'Code'];
    return randomFn?.();
}
/**
 * Get a random concept (code, system, display) from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A concept object with code, system, and optional display, or undefined if ValueSet not found
 */
export function getRandomConceptByUrl(url) {
    const cleanUrl = stripVersionFromUrl(url);
    const name = ValueSetUrlMap[cleanUrl];
    if (!name)
        return undefined;
    const vs = ValueSetRegistry[name];
    // Each ValueSet exports random<Name>Concept() function
    const randomFn = vs['random' + name + 'Concept'];
    return randomFn?.();
}
