/**
 * ValueSet Registry
 * Central registry of all loaded ValueSets with explicit codes
 */
import * as AdditionalDocumentation from './ValueSet-AdditionalDocumentation.js';
import * as AdmitSource from './ValueSet-AdmitSource.js';
import * as AppointmentCancellationReason from './ValueSet-AppointmentCancellationReason.js';
import * as AppointmentStatus from './ValueSet-AppointmentStatus.js';
import * as BodySite from './ValueSet-BodySite.js';
import * as BundleType from './ValueSet-BundleType.js';
import * as CommonLanguages from './ValueSet-CommonLanguages.js';
import * as CommunicationCategory from './ValueSet-CommunicationCategory.js';
import * as ConditionCode from './ValueSet-ConditionCode.js';
import * as CoverageClassCodes from './ValueSet-CoverageClassCodes.js';
import * as CoverageCopayTypeCodes from './ValueSet-CoverageCopayTypeCodes.js';
import * as CoverageInfo from './ValueSet-CoverageInfo.js';
import * as CoveragePaDetail from './ValueSet-CoveragePaDetail.js';
import * as DiagnosisRole from './ValueSet-DiagnosisRole.js';
import * as Diet from './ValueSet-Diet.js';
import * as DietCodes from './ValueSet-DietCodes.js';
import * as DischargeDisposition from './ValueSet-DischargeDisposition.js';
import * as DocReason from './ValueSet-DocReason.js';
import * as DoseAndRateType from './ValueSet-DoseAndRateType.js';
import * as DTRInformationOrigins from './ValueSet-DTRInformationOrigins.js';
import * as EnableWhenBehavior from './ValueSet-EnableWhenBehavior.js';
import * as EncounterLocationStatus from './ValueSet-EncounterLocationStatus.js';
import * as EncounterReasonCodes from './ValueSet-EncounterReasonCodes.js';
import * as EncounterStatus from './ValueSet-EncounterStatus.js';
import * as EnteralFormulaAdditiveTypeCode from './ValueSet-EnteralFormulaAdditiveTypeCode.js';
import * as EnteralFormulaTypeCodes from './ValueSet-EnteralFormulaTypeCodes.js';
import * as EnteralRouteCodes from './ValueSet-EnteralRouteCodes.js';
import * as ExampleCoverageFinancialExceptionCodes from './ValueSet-ExampleCoverageFinancialExceptionCodes.js';
import * as ExampleVisionPrescriptionProductCodes from './ValueSet-ExampleVisionPrescriptionProductCodes.js';
import * as FluidConsistencyTypeCodes from './ValueSet-FluidConsistencyTypeCodes.js';
import * as FmStatus from './ValueSet-FmStatus.js';
import * as FoodTypeCodes from './ValueSet-FoodTypeCodes.js';
import * as HttpVerb from './ValueSet-HttpVerb.js';
import * as IdentifierTypeCodes from './ValueSet-IdentifierTypeCodes.js';
import * as IdentifierUse from './ValueSet-IdentifierUse.js';
import * as InformationNeeded from './ValueSet-InformationNeeded.js';
import * as IssueType from './ValueSet-IssueType.js';
import * as ItemType from './ValueSet-ItemType.js';
import * as JurisdictionValueSet from './ValueSet-JurisdictionValueSet.js';
import * as LocationType from './ValueSet-LocationType.js';
import * as MedicationRequestCategoryCodes from './ValueSet-MedicationRequestCategoryCodes.js';
import * as MedicationRequestCourseOfTherapyCodes from './ValueSet-MedicationRequestCourseOfTherapyCodes.js';
import * as MedicationRequestIntent from './ValueSet-MedicationRequestIntent.js';
import * as MedicationrequestStatus from './ValueSet-MedicationrequestStatus.js';
import * as MedicationRequestStatusReasonCodes from './ValueSet-MedicationRequestStatusReasonCodes.js';
import * as MetricAction from './ValueSet-MetricAction.js';
import * as MetricLaunchMode from './ValueSet-MetricLaunchMode.js';
import * as MetricsInformationOrigins from './ValueSet-MetricsInformationOrigins.js';
import * as MetricSource from './ValueSet-MetricSource.js';
import * as NarrativeStatus from './ValueSet-NarrativeStatus.js';
import * as NutrientModifierCodes from './ValueSet-NutrientModifierCodes.js';
import * as OperationOutcomeCodes from './ValueSet-OperationOutcomeCodes.js';
import * as OrderDetail from './ValueSet-OrderDetail.js';
import * as ParticipantRequired from './ValueSet-ParticipantRequired.js';
import * as ParticipantRoles from './ValueSet-ParticipantRoles.js';
import * as ParticipantType from './ValueSet-ParticipantType.js';
import * as ParticipationStatus from './ValueSet-ParticipationStatus.js';
import * as PracticeSettingCodeValueSet from './ValueSet-PracticeSettingCodeValueSet.js';
import * as ProcedurePerformerRoleCodes from './ValueSet-ProcedurePerformerRoleCodes.js';
import * as ProcedureReasonCodes from './ValueSet-ProcedureReasonCodes.js';
import * as PublicationStatus from './ValueSet-PublicationStatus.js';
import * as QuestionnaireAnswersStatus from './ValueSet-QuestionnaireAnswersStatus.js';
import * as QuestionnaireEntryMode from './ValueSet-QuestionnaireEntryMode.js';
import * as QuestionnaireItemOperator from './ValueSet-QuestionnaireItemOperator.js';
import * as QuestionnaireQuestionCodes from './ValueSet-QuestionnaireQuestionCodes.js';
import * as RequestIntent from './ValueSet-RequestIntent.js';
import * as RequestPriority from './ValueSet-RequestPriority.js';
import * as RequestStatus from './ValueSet-RequestStatus.js';
import * as ResourceType from './ValueSet-ResourceType.js';
import * as SearchEntryMode from './ValueSet-SearchEntryMode.js';
import * as ServiceCategory from './ValueSet-ServiceCategory.js';
import * as ServiceRequestCategoryCodes from './ValueSet-ServiceRequestCategoryCodes.js';
import * as ServiceRequestCodes from './ValueSet-ServiceRequestCodes.js';
import * as ServiceRequestOrderDetailsCodes from './ValueSet-ServiceRequestOrderDetailsCodes.js';
import * as ServiceType from './ValueSet-ServiceType.js';
import * as SNOMEDCTAdditionalDosageInstructions from './ValueSet-SNOMEDCTAdditionalDosageInstructions.js';
import * as SNOMEDCTAdministrationMethodCodes from './ValueSet-SNOMEDCTAdministrationMethodCodes.js';
import * as SNOMEDCTAnatomicalStructureForAdministrationSiteCodes from './ValueSet-SNOMEDCTAnatomicalStructureForAdministrationSiteCodes.js';
import * as SNOMEDCTMedicationAsNeededReasonCodes from './ValueSet-SNOMEDCTMedicationAsNeededReasonCodes.js';
import * as SNOMEDCTRouteCodes from './ValueSet-SNOMEDCTRouteCodes.js';
import * as SpecialArrangements from './ValueSet-SpecialArrangements.js';
import * as SpecialCourtesy from './ValueSet-SpecialCourtesy.js';
import * as SubscriberRelationshipCodes from './ValueSet-SubscriberRelationshipCodes.js';
import * as SupplementTypeCodes from './ValueSet-SupplementTypeCodes.js';
import * as TextureModifiedFoodTypeCodes from './ValueSet-TextureModifiedFoodTypeCodes.js';
import * as TextureModifierCodes from './ValueSet-TextureModifierCodes.js';
import * as UsCoreProviderRole from './ValueSet-UsCoreProviderRole.js';
import * as V20092 from './ValueSet-V20092.js';
import * as V20276 from './ValueSet-V20276.js';
import * as V3ActEncounterCode from './ValueSet-V3ActEncounterCode.js';
import * as V3ActPriority from './ValueSet-V3ActPriority.js';
import * as V3ActReason from './ValueSet-V3ActReason.js';
import * as V3ActSubstanceAdminSubstitutionCode from './ValueSet-V3ActSubstanceAdminSubstitutionCode.js';
import * as V3ParticipationMode from './ValueSet-V3ParticipationMode.js';
import * as V3ServiceDeliveryLocationRoleType from './ValueSet-V3ServiceDeliveryLocationRoleType.js';
import * as V3SubstanceAdminSubstitutionReason from './ValueSet-V3SubstanceAdminSubstitutionReason.js';
import * as VisionBase from './ValueSet-VisionBase.js';
import * as VisionEyes from './ValueSet-VisionEyes.js';
import * as VS21684011142224113591 from './ValueSet-VS21684011142224113591.js';
export const ValueSetRegistry = {
    AdditionalDocumentation,
    AdmitSource,
    AppointmentCancellationReason,
    AppointmentStatus,
    BodySite,
    BundleType,
    CommonLanguages,
    CommunicationCategory,
    ConditionCode,
    CoverageClassCodes,
    CoverageCopayTypeCodes,
    CoverageInfo,
    CoveragePaDetail,
    DiagnosisRole,
    Diet,
    DietCodes,
    DischargeDisposition,
    DocReason,
    DoseAndRateType,
    DTRInformationOrigins,
    EnableWhenBehavior,
    EncounterLocationStatus,
    EncounterReasonCodes,
    EncounterStatus,
    EnteralFormulaAdditiveTypeCode,
    EnteralFormulaTypeCodes,
    EnteralRouteCodes,
    ExampleCoverageFinancialExceptionCodes,
    ExampleVisionPrescriptionProductCodes,
    FluidConsistencyTypeCodes,
    FmStatus,
    FoodTypeCodes,
    HttpVerb,
    IdentifierTypeCodes,
    IdentifierUse,
    InformationNeeded,
    IssueType,
    ItemType,
    JurisdictionValueSet,
    LocationType,
    MedicationRequestCategoryCodes,
    MedicationRequestCourseOfTherapyCodes,
    MedicationRequestIntent,
    MedicationrequestStatus,
    MedicationRequestStatusReasonCodes,
    MetricAction,
    MetricLaunchMode,
    MetricsInformationOrigins,
    MetricSource,
    NarrativeStatus,
    NutrientModifierCodes,
    OperationOutcomeCodes,
    OrderDetail,
    ParticipantRequired,
    ParticipantRoles,
    ParticipantType,
    ParticipationStatus,
    PracticeSettingCodeValueSet,
    ProcedurePerformerRoleCodes,
    ProcedureReasonCodes,
    PublicationStatus,
    QuestionnaireAnswersStatus,
    QuestionnaireEntryMode,
    QuestionnaireItemOperator,
    QuestionnaireQuestionCodes,
    RequestIntent,
    RequestPriority,
    RequestStatus,
    ResourceType,
    SearchEntryMode,
    ServiceCategory,
    ServiceRequestCategoryCodes,
    ServiceRequestCodes,
    ServiceRequestOrderDetailsCodes,
    ServiceType,
    SNOMEDCTAdditionalDosageInstructions,
    SNOMEDCTAdministrationMethodCodes,
    SNOMEDCTAnatomicalStructureForAdministrationSiteCodes,
    SNOMEDCTMedicationAsNeededReasonCodes,
    SNOMEDCTRouteCodes,
    SpecialArrangements,
    SpecialCourtesy,
    SubscriberRelationshipCodes,
    SupplementTypeCodes,
    TextureModifiedFoodTypeCodes,
    TextureModifierCodes,
    UsCoreProviderRole,
    V20092,
    V20276,
    V3ActEncounterCode,
    V3ActPriority,
    V3ActReason,
    V3ActSubstanceAdminSubstitutionCode,
    V3ParticipationMode,
    V3ServiceDeliveryLocationRoleType,
    V3SubstanceAdminSubstitutionReason,
    VisionBase,
    VisionEyes,
    VS21684011142224113591,
};
export function getValueSet(name) {
    return ValueSetRegistry[name];
}
/** Map from ValueSet URL to registry name */
export const ValueSetUrlMap = {
    'http://hl7.org/fhir/us/davinci-crd/ValueSet/AdditionalDocumentation': 'AdditionalDocumentation',
    'http://hl7.org/fhir/ValueSet/encounter-admit-source': 'AdmitSource',
    'http://hl7.org/fhir/ValueSet/appointment-cancellation-reason': 'AppointmentCancellationReason',
    'http://hl7.org/fhir/ValueSet/appointmentstatus': 'AppointmentStatus',
    'http://hl7.org/fhir/ValueSet/body-site': 'BodySite',
    'http://hl7.org/fhir/ValueSet/bundle-type': 'BundleType',
    'http://hl7.org/fhir/ValueSet/languages': 'CommonLanguages',
    'http://hl7.org/fhir/ValueSet/communication-category': 'CommunicationCategory',
    'http://hl7.org/fhir/ValueSet/condition-code': 'ConditionCode',
    'http://hl7.org/fhir/ValueSet/coverage-class': 'CoverageClassCodes',
    'http://hl7.org/fhir/ValueSet/coverage-copay-type': 'CoverageCopayTypeCodes',
    'http://hl7.org/fhir/us/davinci-crd/ValueSet/coverageInfo': 'CoverageInfo',
    'http://hl7.org/fhir/us/davinci-crd/ValueSet/coveragePaDetail': 'CoveragePaDetail',
    'http://hl7.org/fhir/ValueSet/diagnosis-role': 'DiagnosisRole',
    'http://hl7.org/fhir/ValueSet/encounter-diet': 'Diet',
    'http://hl7.org/fhir/ValueSet/diet-type': 'DietCodes',
    'http://hl7.org/fhir/ValueSet/encounter-discharge-disposition': 'DischargeDisposition',
    'http://hl7.org/fhir/us/davinci-crd/ValueSet/DocReason': 'DocReason',
    'http://hl7.org/fhir/ValueSet/dose-rate-type': 'DoseAndRateType',
    'http://hl7.org/fhir/us/davinci-dtr/ValueSet/informationOrigins': 'DTRInformationOrigins',
    'http://hl7.org/fhir/ValueSet/questionnaire-enable-behavior': 'EnableWhenBehavior',
    'http://hl7.org/fhir/ValueSet/encounter-location-status': 'EncounterLocationStatus',
    'http://hl7.org/fhir/ValueSet/encounter-reason': 'EncounterReasonCodes',
    'http://hl7.org/fhir/ValueSet/encounter-status': 'EncounterStatus',
    'http://hl7.org/fhir/ValueSet/entformula-additive': 'EnteralFormulaAdditiveTypeCode',
    'http://hl7.org/fhir/ValueSet/entformula-type': 'EnteralFormulaTypeCodes',
    'http://hl7.org/fhir/ValueSet/enteral-route': 'EnteralRouteCodes',
    'http://hl7.org/fhir/ValueSet/coverage-financial-exception': 'ExampleCoverageFinancialExceptionCodes',
    'http://hl7.org/fhir/ValueSet/vision-product': 'ExampleVisionPrescriptionProductCodes',
    'http://hl7.org/fhir/ValueSet/consistency-type': 'FluidConsistencyTypeCodes',
    'http://hl7.org/fhir/ValueSet/fm-status': 'FmStatus',
    'http://hl7.org/fhir/ValueSet/food-type': 'FoodTypeCodes',
    'http://hl7.org/fhir/ValueSet/http-verb': 'HttpVerb',
    'http://hl7.org/fhir/ValueSet/identifier-type': 'IdentifierTypeCodes',
    'http://hl7.org/fhir/ValueSet/identifier-use': 'IdentifierUse',
    'http://hl7.org/fhir/us/davinci-crd/ValueSet/informationNeeded': 'InformationNeeded',
    'http://hl7.org/fhir/ValueSet/issue-type': 'IssueType',
    'http://hl7.org/fhir/ValueSet/item-type': 'ItemType',
    'http://hl7.org/fhir/ValueSet/jurisdiction': 'JurisdictionValueSet',
    'http://hl7.org/fhir/ValueSet/location-physical-type': 'LocationType',
    'http://hl7.org/fhir/ValueSet/medicationrequest-category': 'MedicationRequestCategoryCodes',
    'http://hl7.org/fhir/ValueSet/medicationrequest-course-of-therapy': 'MedicationRequestCourseOfTherapyCodes',
    'http://hl7.org/fhir/ValueSet/medicationrequest-intent': 'MedicationRequestIntent',
    'http://hl7.org/fhir/ValueSet/medicationrequest-status': 'MedicationrequestStatus',
    'http://hl7.org/fhir/ValueSet/medicationrequest-status-reason': 'MedicationRequestStatusReasonCodes',
    'http://hl7.org/fhir/us/davinci-dtr/ValueSet/metric-Action': 'MetricAction',
    'http://hl7.org/fhir/us/davinci-dtr/ValueSet/metric-launchmode': 'MetricLaunchMode',
    'http://hl7.org/fhir/us/davinci-dtr/ValueSet/MetricsinformationOrigins': 'MetricsInformationOrigins',
    'http://hl7.org/fhir/us/davinci-dtr/ValueSet/metric-Source': 'MetricSource',
    'http://hl7.org/fhir/ValueSet/narrative-status': 'NarrativeStatus',
    'http://hl7.org/fhir/ValueSet/nutrient-code': 'NutrientModifierCodes',
    'http://hl7.org/fhir/ValueSet/operation-outcome': 'OperationOutcomeCodes',
    'http://hl7.org/fhir/us/davinci-crd/ValueSet/orderDetail': 'OrderDetail',
    'http://hl7.org/fhir/ValueSet/participantrequired': 'ParticipantRequired',
    'http://hl7.org/fhir/ValueSet/participant-role': 'ParticipantRoles',
    'http://hl7.org/fhir/ValueSet/encounter-participant-type': 'ParticipantType',
    'http://hl7.org/fhir/ValueSet/participationstatus': 'ParticipationStatus',
    'http://hl7.org/fhir/ValueSet/c80-practice-codes': 'PracticeSettingCodeValueSet',
    'http://hl7.org/fhir/ValueSet/performer-role': 'ProcedurePerformerRoleCodes',
    'http://hl7.org/fhir/ValueSet/procedure-reason': 'ProcedureReasonCodes',
    'http://hl7.org/fhir/ValueSet/publication-status': 'PublicationStatus',
    'http://hl7.org/fhir/ValueSet/questionnaire-answers-status': 'QuestionnaireAnswersStatus',
    'http://hl7.org/fhir/uv/sdc/ValueSet/entryMode': 'QuestionnaireEntryMode',
    'http://hl7.org/fhir/ValueSet/questionnaire-enable-operator': 'QuestionnaireItemOperator',
    'http://hl7.org/fhir/ValueSet/questionnaire-questions': 'QuestionnaireQuestionCodes',
    'http://hl7.org/fhir/ValueSet/request-intent': 'RequestIntent',
    'http://hl7.org/fhir/ValueSet/request-priority': 'RequestPriority',
    'http://hl7.org/fhir/ValueSet/request-status': 'RequestStatus',
    'http://hl7.org/fhir/ValueSet/resource-types': 'ResourceType',
    'http://hl7.org/fhir/ValueSet/search-entry-mode': 'SearchEntryMode',
    'http://hl7.org/fhir/ValueSet/service-category': 'ServiceCategory',
    'http://hl7.org/fhir/ValueSet/servicerequest-category': 'ServiceRequestCategoryCodes',
    'http://hl7.org/fhir/us/davinci-crd/ValueSet/serviceRequestCodes': 'ServiceRequestCodes',
    'http://hl7.org/fhir/ValueSet/servicerequest-orderdetail': 'ServiceRequestOrderDetailsCodes',
    'http://hl7.org/fhir/ValueSet/service-type': 'ServiceType',
    'http://hl7.org/fhir/ValueSet/additional-instruction-codes': 'SNOMEDCTAdditionalDosageInstructions',
    'http://hl7.org/fhir/ValueSet/administration-method-codes': 'SNOMEDCTAdministrationMethodCodes',
    'http://hl7.org/fhir/ValueSet/approach-site-codes': 'SNOMEDCTAnatomicalStructureForAdministrationSiteCodes',
    'http://hl7.org/fhir/ValueSet/medication-as-needed-reason': 'SNOMEDCTMedicationAsNeededReasonCodes',
    'http://hl7.org/fhir/ValueSet/route-codes': 'SNOMEDCTRouteCodes',
    'http://hl7.org/fhir/ValueSet/encounter-special-arrangements': 'SpecialArrangements',
    'http://hl7.org/fhir/ValueSet/encounter-special-courtesy': 'SpecialCourtesy',
    'http://hl7.org/fhir/ValueSet/subscriber-relationship': 'SubscriberRelationshipCodes',
    'http://hl7.org/fhir/ValueSet/supplement-type': 'SupplementTypeCodes',
    'http://hl7.org/fhir/ValueSet/modified-foodtype': 'TextureModifiedFoodTypeCodes',
    'http://hl7.org/fhir/ValueSet/texture-code': 'TextureModifierCodes',
    'http://hl7.org/fhir/us/core/ValueSet/us-core-provider-role': 'UsCoreProviderRole',
    'http://terminology.hl7.org/ValueSet/v2-0092': 'V20092',
    'http://terminology.hl7.org/ValueSet/v2-0276': 'V20276',
    'http://terminology.hl7.org/ValueSet/v3-ActEncounterCode': 'V3ActEncounterCode',
    'http://terminology.hl7.org/ValueSet/v3-ActPriority': 'V3ActPriority',
    'http://terminology.hl7.org/ValueSet/v3-ActReason': 'V3ActReason',
    'http://terminology.hl7.org/ValueSet/v3-ActSubstanceAdminSubstitutionCode': 'V3ActSubstanceAdminSubstitutionCode',
    'http://terminology.hl7.org/ValueSet/v3-ParticipationMode': 'V3ParticipationMode',
    'http://terminology.hl7.org/ValueSet/v3-ServiceDeliveryLocationRoleType': 'V3ServiceDeliveryLocationRoleType',
    'http://terminology.hl7.org/ValueSet/v3-SubstanceAdminSubstitutionReason': 'V3SubstanceAdminSubstitutionReason',
    'http://hl7.org/fhir/ValueSet/vision-base-codes': 'VisionBase',
    'http://hl7.org/fhir/ValueSet/vision-eye-codes': 'VisionEyes',
    'http://cts.nlm.nih.gov/fhir/ValueSet/2.16.840.1.114222.4.11.3591': 'VS21684011142224113591',
};
function stripVersionFromUrl(url) {
    const pipeIndex = url.indexOf('|');
    return pipeIndex >= 0 ? url.substring(0, pipeIndex) : url;
}
/**
 * Get a random code from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A random code string, or undefined if ValueSet not found
 */
export function getRandomCodeByUrl(url) {
    const cleanUrl = stripVersionFromUrl(url);
    const name = ValueSetUrlMap[cleanUrl];
    if (!name)
        return undefined;
    const vs = ValueSetRegistry[name];
    // Each ValueSet exports random<Name>Code() function
    const randomFn = vs['random' + name + 'Code'];
    return randomFn?.();
}
/**
 * Get a random concept (code, system, display) from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A concept object with code, system, and optional display, or undefined if ValueSet not found
 */
export function getRandomConceptByUrl(url) {
    const cleanUrl = stripVersionFromUrl(url);
    const name = ValueSetUrlMap[cleanUrl];
    if (!name)
        return undefined;
    const vs = ValueSetRegistry[name];
    // Each ValueSet exports random<Name>Concept() function
    const randomFn = vs['random' + name + 'Concept'];
    return randomFn?.();
}
