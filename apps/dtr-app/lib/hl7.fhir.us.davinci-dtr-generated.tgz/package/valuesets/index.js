/**
 * ValueSet Registry
 * Central registry of all loaded ValueSets with explicit codes
 */
import * as AdditionalDocumentation from './ValueSet-AdditionalDocumentation.js';
import * as AppointmentCancellationReason from './ValueSet-AppointmentCancellationReason.js';
import * as Appointmentstatus from './ValueSet-Appointmentstatus.js';
import * as BodySite from './ValueSet-BodySite.js';
import * as BundleType from './ValueSet-BundleType.js';
import * as C80PracticeCodes from './ValueSet-C80PracticeCodes.js';
import * as CommunicationCategory from './ValueSet-CommunicationCategory.js';
import * as ConditionCode from './ValueSet-ConditionCode.js';
import * as ConsistencyType from './ValueSet-ConsistencyType.js';
import * as CoverageClass from './ValueSet-CoverageClass.js';
import * as CoverageCopayType from './ValueSet-CoverageCopayType.js';
import * as CoverageFinancialException from './ValueSet-CoverageFinancialException.js';
import * as CoverageInfo from './ValueSet-CoverageInfo.js';
import * as CoveragePaDetail from './ValueSet-CoveragePaDetail.js';
import * as DiagnosisRole from './ValueSet-DiagnosisRole.js';
import * as DietCodes from './ValueSet-DietCodes.js';
import * as DocReason from './ValueSet-DocReason.js';
import * as DoseRateType from './ValueSet-DoseRateType.js';
import * as DTRInformationOrigins from './ValueSet-DTRInformationOrigins.js';
import * as EncounterAdmitSource from './ValueSet-EncounterAdmitSource.js';
import * as EncounterDiet from './ValueSet-EncounterDiet.js';
import * as EncounterDischargeDisposition from './ValueSet-EncounterDischargeDisposition.js';
import * as EncounterLocationStatus from './ValueSet-EncounterLocationStatus.js';
import * as EncounterParticipantType from './ValueSet-EncounterParticipantType.js';
import * as EncounterReasonCodes from './ValueSet-EncounterReasonCodes.js';
import * as EncounterSpecialArrangements from './ValueSet-EncounterSpecialArrangements.js';
import * as EncounterSpecialCourtesy from './ValueSet-EncounterSpecialCourtesy.js';
import * as EncounterStatus from './ValueSet-EncounterStatus.js';
import * as EnteralRoute from './ValueSet-EnteralRoute.js';
import * as EntformulaAdditive from './ValueSet-EntformulaAdditive.js';
import * as EntformulaType from './ValueSet-EntformulaType.js';
import * as EntryMode from './ValueSet-EntryMode.js';
import * as FmStatus from './ValueSet-FmStatus.js';
import * as FoodTypeCodes from './ValueSet-FoodTypeCodes.js';
import * as HttpVerb from './ValueSet-HttpVerb.js';
import * as IdentifierType from './ValueSet-IdentifierType.js';
import * as IdentifierUse from './ValueSet-IdentifierUse.js';
import * as InformationNeeded from './ValueSet-InformationNeeded.js';
import * as IssueType from './ValueSet-IssueType.js';
import * as ItemType from './ValueSet-ItemType.js';
import * as JurisdictionValueSet from './ValueSet-JurisdictionValueSet.js';
import * as Languages from './ValueSet-Languages.js';
import * as LocationPhysicalType from './ValueSet-LocationPhysicalType.js';
import * as MedicationrequestCategory from './ValueSet-MedicationrequestCategory.js';
import * as MedicationrequestCourseOfTherapy from './ValueSet-MedicationrequestCourseOfTherapy.js';
import * as MedicationrequestIntent from './ValueSet-MedicationrequestIntent.js';
import * as MedicationrequestStatus from './ValueSet-MedicationrequestStatus.js';
import * as MedicationrequestStatusReason from './ValueSet-MedicationrequestStatusReason.js';
import * as MetricAction from './ValueSet-MetricAction.js';
import * as MetricLaunchMode from './ValueSet-MetricLaunchMode.js';
import * as MetricsInformationOrigins from './ValueSet-MetricsInformationOrigins.js';
import * as MetricSource from './ValueSet-MetricSource.js';
import * as ModifiedFoodtype from './ValueSet-ModifiedFoodtype.js';
import * as NarrativeStatus from './ValueSet-NarrativeStatus.js';
import * as NutrientCode from './ValueSet-NutrientCode.js';
import * as OperationOutcome from './ValueSet-OperationOutcome.js';
import * as OrderDetail from './ValueSet-OrderDetail.js';
import * as Participantrequired from './ValueSet-Participantrequired.js';
import * as ParticipantRoles from './ValueSet-ParticipantRoles.js';
import * as Participationstatus from './ValueSet-Participationstatus.js';
import * as ProcedurePerformerRoleCodes from './ValueSet-ProcedurePerformerRoleCodes.js';
import * as ProcedureReasonCodes from './ValueSet-ProcedureReasonCodes.js';
import * as PublicationStatus from './ValueSet-PublicationStatus.js';
import * as QuestionnaireAnswers from './ValueSet-QuestionnaireAnswers.js';
import * as QuestionnaireAnswersStatus from './ValueSet-QuestionnaireAnswersStatus.js';
import * as QuestionnaireEnableBehavior from './ValueSet-QuestionnaireEnableBehavior.js';
import * as QuestionnaireEnableOperator from './ValueSet-QuestionnaireEnableOperator.js';
import * as QuestionnaireQuestions from './ValueSet-QuestionnaireQuestions.js';
import * as RequestIntent from './ValueSet-RequestIntent.js';
import * as RequestPriority from './ValueSet-RequestPriority.js';
import * as RequestStatus from './ValueSet-RequestStatus.js';
import * as ResourceTypes from './ValueSet-ResourceTypes.js';
import * as SearchEntryMode from './ValueSet-SearchEntryMode.js';
import * as ServiceCategory from './ValueSet-ServiceCategory.js';
import * as ServicerequestCategory from './ValueSet-ServicerequestCategory.js';
import * as ServiceRequestCodes from './ValueSet-ServiceRequestCodes.js';
import * as ServicerequestOrderdetail from './ValueSet-ServicerequestOrderdetail.js';
import * as ServiceType from './ValueSet-ServiceType.js';
import * as SNOMEDCTAdditionalDosageInstructions from './ValueSet-SNOMEDCTAdditionalDosageInstructions.js';
import * as SNOMEDCTAdministrationMethodCodes from './ValueSet-SNOMEDCTAdministrationMethodCodes.js';
import * as SNOMEDCTAnatomicalStructureForAdministrationSiteCodes from './ValueSet-SNOMEDCTAnatomicalStructureForAdministrationSiteCodes.js';
import * as SNOMEDCTMedicationAsNeededReasonCodes from './ValueSet-SNOMEDCTMedicationAsNeededReasonCodes.js';
import * as SNOMEDCTRouteCodes from './ValueSet-SNOMEDCTRouteCodes.js';
import * as SubscriberRelationship from './ValueSet-SubscriberRelationship.js';
import * as SupplementType from './ValueSet-SupplementType.js';
import * as TextureCode from './ValueSet-TextureCode.js';
import * as UsCoreProviderRole from './ValueSet-UsCoreProviderRole.js';
import * as V20092 from './ValueSet-V20092.js';
import * as V20276 from './ValueSet-V20276.js';
import * as V3ActEncounterCode from './ValueSet-V3ActEncounterCode.js';
import * as V3ActPriority from './ValueSet-V3ActPriority.js';
import * as V3ActReason from './ValueSet-V3ActReason.js';
import * as V3ActSubstanceAdminSubstitutionCode from './ValueSet-V3ActSubstanceAdminSubstitutionCode.js';
import * as V3ParticipationMode from './ValueSet-V3ParticipationMode.js';
import * as V3ServiceDeliveryLocationRoleType from './ValueSet-V3ServiceDeliveryLocationRoleType.js';
import * as V3SubstanceAdminSubstitutionReason from './ValueSet-V3SubstanceAdminSubstitutionReason.js';
import * as VisionBaseCodes from './ValueSet-VisionBaseCodes.js';
import * as VisionEyeCodes from './ValueSet-VisionEyeCodes.js';
import * as VisionProduct from './ValueSet-VisionProduct.js';
import * as VS21684011142224113591 from './ValueSet-VS21684011142224113591.js';
export const ValueSetRegistry = {
    AdditionalDocumentation,
    AppointmentCancellationReason,
    Appointmentstatus,
    BodySite,
    BundleType,
    C80PracticeCodes,
    CommunicationCategory,
    ConditionCode,
    ConsistencyType,
    CoverageClass,
    CoverageCopayType,
    CoverageFinancialException,
    CoverageInfo,
    CoveragePaDetail,
    DiagnosisRole,
    DietCodes,
    DocReason,
    DoseRateType,
    DTRInformationOrigins,
    EncounterAdmitSource,
    EncounterDiet,
    EncounterDischargeDisposition,
    EncounterLocationStatus,
    EncounterParticipantType,
    EncounterReasonCodes,
    EncounterSpecialArrangements,
    EncounterSpecialCourtesy,
    EncounterStatus,
    EnteralRoute,
    EntformulaAdditive,
    EntformulaType,
    EntryMode,
    FmStatus,
    FoodTypeCodes,
    HttpVerb,
    IdentifierType,
    IdentifierUse,
    InformationNeeded,
    IssueType,
    ItemType,
    JurisdictionValueSet,
    Languages,
    LocationPhysicalType,
    MedicationrequestCategory,
    MedicationrequestCourseOfTherapy,
    MedicationrequestIntent,
    MedicationrequestStatus,
    MedicationrequestStatusReason,
    MetricAction,
    MetricLaunchMode,
    MetricsInformationOrigins,
    MetricSource,
    ModifiedFoodtype,
    NarrativeStatus,
    NutrientCode,
    OperationOutcome,
    OrderDetail,
    Participantrequired,
    ParticipantRoles,
    Participationstatus,
    ProcedurePerformerRoleCodes,
    ProcedureReasonCodes,
    PublicationStatus,
    QuestionnaireAnswers,
    QuestionnaireAnswersStatus,
    QuestionnaireEnableBehavior,
    QuestionnaireEnableOperator,
    QuestionnaireQuestions,
    RequestIntent,
    RequestPriority,
    RequestStatus,
    ResourceTypes,
    SearchEntryMode,
    ServiceCategory,
    ServicerequestCategory,
    ServiceRequestCodes,
    ServicerequestOrderdetail,
    ServiceType,
    SNOMEDCTAdditionalDosageInstructions,
    SNOMEDCTAdministrationMethodCodes,
    SNOMEDCTAnatomicalStructureForAdministrationSiteCodes,
    SNOMEDCTMedicationAsNeededReasonCodes,
    SNOMEDCTRouteCodes,
    SubscriberRelationship,
    SupplementType,
    TextureCode,
    UsCoreProviderRole,
    V20092,
    V20276,
    V3ActEncounterCode,
    V3ActPriority,
    V3ActReason,
    V3ActSubstanceAdminSubstitutionCode,
    V3ParticipationMode,
    V3ServiceDeliveryLocationRoleType,
    V3SubstanceAdminSubstitutionReason,
    VisionBaseCodes,
    VisionEyeCodes,
    VisionProduct,
    VS21684011142224113591,
};
export function getValueSet(name) {
    return ValueSetRegistry[name];
}
/** Map from ValueSet URL to registry name */
export const ValueSetUrlMap = {
    'http://hl7.org/fhir/us/davinci-crd/ValueSet/AdditionalDocumentation': 'AdditionalDocumentation',
    'http://hl7.org/fhir/ValueSet/appointment-cancellation-reason': 'AppointmentCancellationReason',
    'http://hl7.org/fhir/ValueSet/appointmentstatus': 'Appointmentstatus',
    'http://hl7.org/fhir/ValueSet/body-site': 'BodySite',
    'http://hl7.org/fhir/ValueSet/bundle-type': 'BundleType',
    'http://hl7.org/fhir/ValueSet/c80-practice-codes': 'C80PracticeCodes',
    'http://hl7.org/fhir/ValueSet/communication-category': 'CommunicationCategory',
    'http://hl7.org/fhir/ValueSet/condition-code': 'ConditionCode',
    'http://hl7.org/fhir/ValueSet/consistency-type': 'ConsistencyType',
    'http://hl7.org/fhir/ValueSet/coverage-class': 'CoverageClass',
    'http://hl7.org/fhir/ValueSet/coverage-copay-type': 'CoverageCopayType',
    'http://hl7.org/fhir/ValueSet/coverage-financial-exception': 'CoverageFinancialException',
    'http://hl7.org/fhir/us/davinci-crd/ValueSet/coverageInfo': 'CoverageInfo',
    'http://hl7.org/fhir/us/davinci-crd/ValueSet/coveragePaDetail': 'CoveragePaDetail',
    'http://hl7.org/fhir/ValueSet/diagnosis-role': 'DiagnosisRole',
    'http://hl7.org/fhir/ValueSet/diet-type': 'DietCodes',
    'http://hl7.org/fhir/us/davinci-crd/ValueSet/DocReason': 'DocReason',
    'http://hl7.org/fhir/ValueSet/dose-rate-type': 'DoseRateType',
    'http://hl7.org/fhir/us/davinci-dtr/ValueSet/informationOrigins': 'DTRInformationOrigins',
    'http://hl7.org/fhir/ValueSet/encounter-admit-source': 'EncounterAdmitSource',
    'http://hl7.org/fhir/ValueSet/encounter-diet': 'EncounterDiet',
    'http://hl7.org/fhir/ValueSet/encounter-discharge-disposition': 'EncounterDischargeDisposition',
    'http://hl7.org/fhir/ValueSet/encounter-location-status': 'EncounterLocationStatus',
    'http://hl7.org/fhir/ValueSet/encounter-participant-type': 'EncounterParticipantType',
    'http://hl7.org/fhir/ValueSet/encounter-reason': 'EncounterReasonCodes',
    'http://hl7.org/fhir/ValueSet/encounter-special-arrangements': 'EncounterSpecialArrangements',
    'http://hl7.org/fhir/ValueSet/encounter-special-courtesy': 'EncounterSpecialCourtesy',
    'http://hl7.org/fhir/ValueSet/encounter-status': 'EncounterStatus',
    'http://hl7.org/fhir/ValueSet/enteral-route': 'EnteralRoute',
    'http://hl7.org/fhir/ValueSet/entformula-additive': 'EntformulaAdditive',
    'http://hl7.org/fhir/ValueSet/entformula-type': 'EntformulaType',
    'http://hl7.org/fhir/uv/sdc/ValueSet/entryMode': 'EntryMode',
    'http://hl7.org/fhir/ValueSet/fm-status': 'FmStatus',
    'http://hl7.org/fhir/ValueSet/food-type': 'FoodTypeCodes',
    'http://hl7.org/fhir/ValueSet/http-verb': 'HttpVerb',
    'http://hl7.org/fhir/ValueSet/identifier-type': 'IdentifierType',
    'http://hl7.org/fhir/ValueSet/identifier-use': 'IdentifierUse',
    'http://hl7.org/fhir/us/davinci-crd/ValueSet/informationNeeded': 'InformationNeeded',
    'http://hl7.org/fhir/ValueSet/issue-type': 'IssueType',
    'http://hl7.org/fhir/ValueSet/item-type': 'ItemType',
    'http://hl7.org/fhir/ValueSet/jurisdiction': 'JurisdictionValueSet',
    'http://hl7.org/fhir/ValueSet/languages': 'Languages',
    'http://hl7.org/fhir/ValueSet/location-physical-type': 'LocationPhysicalType',
    'http://hl7.org/fhir/ValueSet/medicationrequest-category': 'MedicationrequestCategory',
    'http://hl7.org/fhir/ValueSet/medicationrequest-course-of-therapy': 'MedicationrequestCourseOfTherapy',
    'http://hl7.org/fhir/ValueSet/medicationrequest-intent': 'MedicationrequestIntent',
    'http://hl7.org/fhir/ValueSet/medicationrequest-status': 'MedicationrequestStatus',
    'http://hl7.org/fhir/ValueSet/medicationrequest-status-reason': 'MedicationrequestStatusReason',
    'http://hl7.org/fhir/us/davinci-dtr/ValueSet/metric-Action': 'MetricAction',
    'http://hl7.org/fhir/us/davinci-dtr/ValueSet/metric-launchmode': 'MetricLaunchMode',
    'http://hl7.org/fhir/us/davinci-dtr/ValueSet/MetricsinformationOrigins': 'MetricsInformationOrigins',
    'http://hl7.org/fhir/us/davinci-dtr/ValueSet/metric-Source': 'MetricSource',
    'http://hl7.org/fhir/ValueSet/modified-foodtype': 'ModifiedFoodtype',
    'http://hl7.org/fhir/ValueSet/narrative-status': 'NarrativeStatus',
    'http://hl7.org/fhir/ValueSet/nutrient-code': 'NutrientCode',
    'http://hl7.org/fhir/ValueSet/operation-outcome': 'OperationOutcome',
    'http://hl7.org/fhir/us/davinci-crd/ValueSet/orderDetail': 'OrderDetail',
    'http://hl7.org/fhir/ValueSet/participantrequired': 'Participantrequired',
    'http://hl7.org/fhir/ValueSet/participant-role': 'ParticipantRoles',
    'http://hl7.org/fhir/ValueSet/participationstatus': 'Participationstatus',
    'http://hl7.org/fhir/ValueSet/performer-role': 'ProcedurePerformerRoleCodes',
    'http://hl7.org/fhir/ValueSet/procedure-reason': 'ProcedureReasonCodes',
    'http://hl7.org/fhir/ValueSet/publication-status': 'PublicationStatus',
    'http://hl7.org/fhir/ValueSet/questionnaire-answers': 'QuestionnaireAnswers',
    'http://hl7.org/fhir/ValueSet/questionnaire-answers-status': 'QuestionnaireAnswersStatus',
    'http://hl7.org/fhir/ValueSet/questionnaire-enable-behavior': 'QuestionnaireEnableBehavior',
    'http://hl7.org/fhir/ValueSet/questionnaire-enable-operator': 'QuestionnaireEnableOperator',
    'http://hl7.org/fhir/ValueSet/questionnaire-questions': 'QuestionnaireQuestions',
    'http://hl7.org/fhir/ValueSet/request-intent': 'RequestIntent',
    'http://hl7.org/fhir/ValueSet/request-priority': 'RequestPriority',
    'http://hl7.org/fhir/ValueSet/request-status': 'RequestStatus',
    'http://hl7.org/fhir/ValueSet/resource-types': 'ResourceTypes',
    'http://hl7.org/fhir/ValueSet/search-entry-mode': 'SearchEntryMode',
    'http://hl7.org/fhir/ValueSet/service-category': 'ServiceCategory',
    'http://hl7.org/fhir/ValueSet/servicerequest-category': 'ServicerequestCategory',
    'http://hl7.org/fhir/us/davinci-crd/ValueSet/serviceRequestCodes': 'ServiceRequestCodes',
    'http://hl7.org/fhir/ValueSet/servicerequest-orderdetail': 'ServicerequestOrderdetail',
    'http://hl7.org/fhir/ValueSet/service-type': 'ServiceType',
    'http://hl7.org/fhir/ValueSet/additional-instruction-codes': 'SNOMEDCTAdditionalDosageInstructions',
    'http://hl7.org/fhir/ValueSet/administration-method-codes': 'SNOMEDCTAdministrationMethodCodes',
    'http://hl7.org/fhir/ValueSet/approach-site-codes': 'SNOMEDCTAnatomicalStructureForAdministrationSiteCodes',
    'http://hl7.org/fhir/ValueSet/medication-as-needed-reason': 'SNOMEDCTMedicationAsNeededReasonCodes',
    'http://hl7.org/fhir/ValueSet/route-codes': 'SNOMEDCTRouteCodes',
    'http://hl7.org/fhir/ValueSet/subscriber-relationship': 'SubscriberRelationship',
    'http://hl7.org/fhir/ValueSet/supplement-type': 'SupplementType',
    'http://hl7.org/fhir/ValueSet/texture-code': 'TextureCode',
    'http://hl7.org/fhir/us/core/ValueSet/us-core-provider-role': 'UsCoreProviderRole',
    'http://terminology.hl7.org/ValueSet/v2-0092': 'V20092',
    'http://terminology.hl7.org/ValueSet/v2-0276': 'V20276',
    'http://terminology.hl7.org/ValueSet/v3-ActEncounterCode': 'V3ActEncounterCode',
    'http://terminology.hl7.org/ValueSet/v3-ActPriority': 'V3ActPriority',
    'http://terminology.hl7.org/ValueSet/v3-ActReason': 'V3ActReason',
    'http://terminology.hl7.org/ValueSet/v3-ActSubstanceAdminSubstitutionCode': 'V3ActSubstanceAdminSubstitutionCode',
    'http://terminology.hl7.org/ValueSet/v3-ParticipationMode': 'V3ParticipationMode',
    'http://terminology.hl7.org/ValueSet/v3-ServiceDeliveryLocationRoleType': 'V3ServiceDeliveryLocationRoleType',
    'http://terminology.hl7.org/ValueSet/v3-SubstanceAdminSubstitutionReason': 'V3SubstanceAdminSubstitutionReason',
    'http://hl7.org/fhir/ValueSet/vision-base-codes': 'VisionBaseCodes',
    'http://hl7.org/fhir/ValueSet/vision-eye-codes': 'VisionEyeCodes',
    'http://hl7.org/fhir/ValueSet/vision-product': 'VisionProduct',
    'http://cts.nlm.nih.gov/fhir/ValueSet/2.16.840.1.114222.4.11.3591': 'VS21684011142224113591',
};
function stripVersionFromUrl(url) {
    const pipeIndex = url.indexOf('|');
    return pipeIndex >= 0 ? url.substring(0, pipeIndex) : url;
}
/**
 * Get a random code from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A random code string, or undefined if ValueSet not found
 */
export function getRandomCodeByUrl(url) {
    const cleanUrl = stripVersionFromUrl(url);
    const name = ValueSetUrlMap[cleanUrl];
    if (!name)
        return undefined;
    const vs = ValueSetRegistry[name];
    // Each ValueSet exports random<Name>Code() function
    const randomFn = vs['random' + name + 'Code'];
    return randomFn?.();
}
/**
 * Get a random concept (code, system, display) from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A concept object with code, system, and optional display, or undefined if ValueSet not found
 */
export function getRandomConceptByUrl(url) {
    const cleanUrl = stripVersionFromUrl(url);
    const name = ValueSetUrlMap[cleanUrl];
    if (!name)
        return undefined;
    const vs = ValueSetRegistry[name];
    // Each ValueSet exports random<Name>Concept() function
    const randomFn = vs['random' + name + 'Concept'];
    return randomFn?.();
}
