/**
 * ValueSet: entryMode
 * URL: http://hl7.org/fhir/uv/sdc/ValueSet/entryMode
 * Size: 3 concepts
 */
export const EntryModeConcepts = [
    { code: "sequential", system: "http://hl7.org/fhir/uv/sdc/CodeSystem/entryMode" },
    { code: "prior-edit", system: "http://hl7.org/fhir/uv/sdc/CodeSystem/entryMode" },
    { code: "random", system: "http://hl7.org/fhir/uv/sdc/CodeSystem/entryMode" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidEntryModeCode(code) {
    return EntryModeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getEntryModeConcept(code) {
    return EntryModeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const EntryModeCodes = EntryModeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomEntryModeCode() {
    return EntryModeCodes[Math.floor(Math.random() * EntryModeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomEntryModeConcept() {
    return EntryModeConcepts[Math.floor(Math.random() * EntryModeConcepts.length)];
}
