/**
 * ValueSet: identifier-type
 * URL: http://hl7.org/fhir/ValueSet/identifier-type
 * Size: 18 concepts
 */
export declare const IdentifierTypeConcepts: readonly [{
    readonly code: "DL";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0203";
}, {
    readonly code: "PPN";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0203";
}, {
    readonly code: "BRN";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0203";
}, {
    readonly code: "MR";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0203";
}, {
    readonly code: "MCN";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0203";
}, {
    readonly code: "EN";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0203";
}, {
    readonly code: "TAX";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0203";
}, {
    readonly code: "NIIP";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0203";
}, {
    readonly code: "PRN";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0203";
}, {
    readonly code: "MD";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0203";
}, {
    readonly code: "DR";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0203";
}, {
    readonly code: "ACSN";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0203";
}, {
    readonly code: "UDI";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0203";
}, {
    readonly code: "SNO";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0203";
}, {
    readonly code: "SB";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0203";
}, {
    readonly code: "PLAC";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0203";
}, {
    readonly code: "FILL";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0203";
}, {
    readonly code: "JHN";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0203";
}];
/** Union type of all valid codes in this ValueSet */
export type IdentifierTypeCode = "DL" | "PPN" | "BRN" | "MR" | "MCN" | "EN" | "TAX" | "NIIP" | "PRN" | "MD" | "DR" | "ACSN" | "UDI" | "SNO" | "SB" | "PLAC" | "FILL" | "JHN";
/** Type representing a concept from this ValueSet */
export type IdentifierTypeConcept = typeof IdentifierTypeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidIdentifierTypeCode(code: string): code is IdentifierTypeCode;
/**
 * Get concept details by code
 */
export declare function getIdentifierTypeConcept(code: string): IdentifierTypeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const IdentifierTypeCodes: ("DL" | "PPN" | "BRN" | "MR" | "MCN" | "EN" | "TAX" | "NIIP" | "PRN" | "MD" | "DR" | "ACSN" | "UDI" | "SNO" | "SB" | "PLAC" | "FILL" | "JHN")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomIdentifierTypeCode(): IdentifierTypeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomIdentifierTypeConcept(): IdentifierTypeConcept;
