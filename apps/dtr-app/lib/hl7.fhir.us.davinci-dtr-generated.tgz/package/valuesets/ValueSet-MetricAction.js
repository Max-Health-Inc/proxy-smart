/**
 * ValueSet: MetricAction
 * URL: http://hl7.org/fhir/us/davinci-dtr/ValueSet/metric-Action
 * Size: 6 concepts
 */
export const MetricActionConcepts = [
    { code: "launch", system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp" },
    { code: "qpackage", system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp" },
    { code: "mrquery", system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp" },
    { code: "nextq", system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp" },
    { code: "userresponse", system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp" },
    { code: "storeqr", system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidMetricActionCode(code) {
    return MetricActionConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getMetricActionConcept(code) {
    return MetricActionConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const MetricActionCodes = MetricActionConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomMetricActionCode() {
    return MetricActionCodes[Math.floor(Math.random() * MetricActionCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomMetricActionConcept() {
    return MetricActionConcepts[Math.floor(Math.random() * MetricActionConcepts.length)];
}
