/**
 * ValueSet: ParticipationStatus
 * URL: http://hl7.org/fhir/ValueSet/participationstatus
 * Size: 4 concepts
 */
export const ParticipationStatusConcepts = [
    { code: "accepted", system: "http://hl7.org/fhir/participationstatus", display: "Accepted" },
    { code: "declined", system: "http://hl7.org/fhir/participationstatus", display: "Declined" },
    { code: "tentative", system: "http://hl7.org/fhir/participationstatus", display: "Tentative" },
    { code: "needs-action", system: "http://hl7.org/fhir/participationstatus", display: "Needs Action" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidParticipationStatusCode(code) {
    return ParticipationStatusConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getParticipationStatusConcept(code) {
    return ParticipationStatusConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ParticipationStatusCodes = ParticipationStatusConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomParticipationStatusCode() {
    return ParticipationStatusCodes[Math.floor(Math.random() * ParticipationStatusCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomParticipationStatusConcept() {
    return ParticipationStatusConcepts[Math.floor(Math.random() * ParticipationStatusConcepts.length)];
}
