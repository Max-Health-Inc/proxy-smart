/**
 * ValueSet: v3-ActPriority
 * URL: http://terminology.hl7.org/ValueSet/v3-ActPriority
 * Size: 12 concepts
 */
export const V3ActPriorityConcepts = [
    { code: "A", system: "http://terminology.hl7.org/CodeSystem/v3-ActPriority" },
    { code: "CR", system: "http://terminology.hl7.org/CodeSystem/v3-ActPriority" },
    { code: "EL", system: "http://terminology.hl7.org/CodeSystem/v3-ActPriority" },
    { code: "EM", system: "http://terminology.hl7.org/CodeSystem/v3-ActPriority" },
    { code: "P", system: "http://terminology.hl7.org/CodeSystem/v3-ActPriority" },
    { code: "PRN", system: "http://terminology.hl7.org/CodeSystem/v3-ActPriority" },
    { code: "R", system: "http://terminology.hl7.org/CodeSystem/v3-ActPriority" },
    { code: "RR", system: "http://terminology.hl7.org/CodeSystem/v3-ActPriority" },
    { code: "S", system: "http://terminology.hl7.org/CodeSystem/v3-ActPriority" },
    { code: "T", system: "http://terminology.hl7.org/CodeSystem/v3-ActPriority" },
    { code: "UD", system: "http://terminology.hl7.org/CodeSystem/v3-ActPriority" },
    { code: "UR", system: "http://terminology.hl7.org/CodeSystem/v3-ActPriority" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidV3ActPriorityCode(code) {
    return V3ActPriorityConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getV3ActPriorityConcept(code) {
    return V3ActPriorityConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const V3ActPriorityCodes = V3ActPriorityConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomV3ActPriorityCode() {
    return V3ActPriorityCodes[Math.floor(Math.random() * V3ActPriorityCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomV3ActPriorityConcept() {
    return V3ActPriorityConcepts[Math.floor(Math.random() * V3ActPriorityConcepts.length)];
}
