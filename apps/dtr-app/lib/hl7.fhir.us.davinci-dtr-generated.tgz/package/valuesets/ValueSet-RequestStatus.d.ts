/**
 * ValueSet: request-status
 * URL: http://hl7.org/fhir/ValueSet/request-status
 * Size: 7 concepts
 */
export declare const RequestStatusConcepts: readonly [{
    readonly code: "draft";
    readonly system: "http://hl7.org/fhir/request-status";
}, {
    readonly code: "active";
    readonly system: "http://hl7.org/fhir/request-status";
}, {
    readonly code: "on-hold";
    readonly system: "http://hl7.org/fhir/request-status";
}, {
    readonly code: "revoked";
    readonly system: "http://hl7.org/fhir/request-status";
}, {
    readonly code: "completed";
    readonly system: "http://hl7.org/fhir/request-status";
}, {
    readonly code: "entered-in-error";
    readonly system: "http://hl7.org/fhir/request-status";
}, {
    readonly code: "unknown";
    readonly system: "http://hl7.org/fhir/request-status";
}];
/** Union type of all valid codes in this ValueSet */
export type RequestStatusCode = "draft" | "active" | "on-hold" | "revoked" | "completed" | "entered-in-error" | "unknown";
/** Type representing a concept from this ValueSet */
export type RequestStatusConcept = typeof RequestStatusConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidRequestStatusCode(code: string): code is RequestStatusCode;
/**
 * Get concept details by code
 */
export declare function getRequestStatusConcept(code: string): RequestStatusConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const RequestStatusCodes: ("active" | "unknown" | "entered-in-error" | "completed" | "draft" | "on-hold" | "revoked")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomRequestStatusCode(): RequestStatusCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomRequestStatusConcept(): RequestStatusConcept;
