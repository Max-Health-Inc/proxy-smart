/**
 * ValueSet: AdmitSource
 * URL: http://hl7.org/fhir/ValueSet/encounter-admit-source
 * Size: 10 concepts
 */
export const AdmitSourceConcepts = [
    { code: "hosp-trans", system: "http://terminology.hl7.org/CodeSystem/admit-source", display: "Transferred from other hospital" },
    { code: "emd", system: "http://terminology.hl7.org/CodeSystem/admit-source", display: "From accident/emergency department" },
    { code: "outp", system: "http://terminology.hl7.org/CodeSystem/admit-source", display: "From outpatient department" },
    { code: "born", system: "http://terminology.hl7.org/CodeSystem/admit-source", display: "Born in hospital" },
    { code: "gp", system: "http://terminology.hl7.org/CodeSystem/admit-source", display: "General Practitioner referral" },
    { code: "mp", system: "http://terminology.hl7.org/CodeSystem/admit-source", display: "Medical Practitioner/physician referral" },
    { code: "nursing", system: "http://terminology.hl7.org/CodeSystem/admit-source", display: "From nursing home" },
    { code: "psych", system: "http://terminology.hl7.org/CodeSystem/admit-source", display: "From psychiatric hospital" },
    { code: "rehab", system: "http://terminology.hl7.org/CodeSystem/admit-source", display: "From rehabilitation facility" },
    { code: "other", system: "http://terminology.hl7.org/CodeSystem/admit-source", display: "Other" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidAdmitSourceCode(code) {
    return AdmitSourceConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getAdmitSourceConcept(code) {
    return AdmitSourceConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const AdmitSourceCodes = AdmitSourceConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomAdmitSourceCode() {
    return AdmitSourceCodes[Math.floor(Math.random() * AdmitSourceCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomAdmitSourceConcept() {
    return AdmitSourceConcepts[Math.floor(Math.random() * AdmitSourceConcepts.length)];
}
