/**
 * ValueSet: fm-status
 * URL: http://hl7.org/fhir/ValueSet/fm-status
 * Size: 4 concepts
 */
export const FmStatusConcepts = [
    { code: "active", system: "http://hl7.org/fhir/fm-status" },
    { code: "cancelled", system: "http://hl7.org/fhir/fm-status" },
    { code: "draft", system: "http://hl7.org/fhir/fm-status" },
    { code: "entered-in-error", system: "http://hl7.org/fhir/fm-status" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidFmStatusCode(code) {
    return FmStatusConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getFmStatusConcept(code) {
    return FmStatusConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const FmStatusCodes = FmStatusConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomFmStatusCode() {
    return FmStatusCodes[Math.floor(Math.random() * FmStatusCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomFmStatusConcept() {
    return FmStatusConcepts[Math.floor(Math.random() * FmStatusConcepts.length)];
}
