/**
 * ValueSet: identifier-use
 * URL: http://hl7.org/fhir/ValueSet/identifier-use
 * Size: 5 concepts
 */
export const IdentifierUseConcepts = [
    { code: "usual", system: "http://hl7.org/fhir/identifier-use" },
    { code: "official", system: "http://hl7.org/fhir/identifier-use" },
    { code: "temp", system: "http://hl7.org/fhir/identifier-use" },
    { code: "secondary", system: "http://hl7.org/fhir/identifier-use" },
    { code: "old", system: "http://hl7.org/fhir/identifier-use" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidIdentifierUseCode(code) {
    return IdentifierUseConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getIdentifierUseConcept(code) {
    return IdentifierUseConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const IdentifierUseCodes = IdentifierUseConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomIdentifierUseCode() {
    return IdentifierUseCodes[Math.floor(Math.random() * IdentifierUseCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomIdentifierUseConcept() {
    return IdentifierUseConcepts[Math.floor(Math.random() * IdentifierUseConcepts.length)];
}
