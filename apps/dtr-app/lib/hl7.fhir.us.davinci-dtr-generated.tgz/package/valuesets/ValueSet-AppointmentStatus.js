/**
 * ValueSet: AppointmentStatus
 * URL: http://hl7.org/fhir/ValueSet/appointmentstatus
 * Size: 10 concepts
 */
export const AppointmentStatusConcepts = [
    { code: "proposed", system: "http://hl7.org/fhir/appointmentstatus", display: "Proposed" },
    { code: "pending", system: "http://hl7.org/fhir/appointmentstatus", display: "Pending" },
    { code: "booked", system: "http://hl7.org/fhir/appointmentstatus", display: "Booked" },
    { code: "arrived", system: "http://hl7.org/fhir/appointmentstatus", display: "Arrived" },
    { code: "fulfilled", system: "http://hl7.org/fhir/appointmentstatus", display: "Fulfilled" },
    { code: "cancelled", system: "http://hl7.org/fhir/appointmentstatus", display: "Cancelled" },
    { code: "noshow", system: "http://hl7.org/fhir/appointmentstatus", display: "No Show" },
    { code: "entered-in-error", system: "http://hl7.org/fhir/appointmentstatus", display: "Entered in error" },
    { code: "checked-in", system: "http://hl7.org/fhir/appointmentstatus", display: "Checked In" },
    { code: "waitlist", system: "http://hl7.org/fhir/appointmentstatus", display: "Waitlisted" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidAppointmentStatusCode(code) {
    return AppointmentStatusConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getAppointmentStatusConcept(code) {
    return AppointmentStatusConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const AppointmentStatusCodes = AppointmentStatusConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomAppointmentStatusCode() {
    return AppointmentStatusCodes[Math.floor(Math.random() * AppointmentStatusCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomAppointmentStatusConcept() {
    return AppointmentStatusConcepts[Math.floor(Math.random() * AppointmentStatusConcepts.length)];
}
