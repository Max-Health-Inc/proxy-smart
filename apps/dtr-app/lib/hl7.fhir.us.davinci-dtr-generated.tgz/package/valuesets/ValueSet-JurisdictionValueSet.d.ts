/**
 * ValueSet: Jurisdiction ValueSet
 * URL: http://hl7.org/fhir/ValueSet/jurisdiction
 * Size: 100 concepts
 */
export declare const JurisdictionValueSetConcepts: readonly [{
    readonly code: "AD";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Andorra";
}, {
    readonly code: "AE";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "United Arab Emirates";
}, {
    readonly code: "AF";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Afghanistan";
}, {
    readonly code: "AG";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Antigua and Barbuda";
}, {
    readonly code: "AI";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Anguilla";
}, {
    readonly code: "AL";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Albania";
}, {
    readonly code: "AM";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Armenia";
}, {
    readonly code: "AO";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Angola";
}, {
    readonly code: "AQ";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Antarctica";
}, {
    readonly code: "AR";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Argentina";
}, {
    readonly code: "AS";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "American Samoa";
}, {
    readonly code: "AT";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Austria";
}, {
    readonly code: "AU";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Australia";
}, {
    readonly code: "AW";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Aruba";
}, {
    readonly code: "AX";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Åland Islands";
}, {
    readonly code: "AZ";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Azerbaijan";
}, {
    readonly code: "BA";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Bosnia and Herzegovina";
}, {
    readonly code: "BB";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Barbados";
}, {
    readonly code: "BD";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Bangladesh";
}, {
    readonly code: "BE";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Belgium";
}, {
    readonly code: "BF";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Burkina Faso";
}, {
    readonly code: "BG";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Bulgaria";
}, {
    readonly code: "BH";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Bahrain";
}, {
    readonly code: "BI";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Burundi";
}, {
    readonly code: "BJ";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Benin";
}, {
    readonly code: "BL";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Saint Barthélemy";
}, {
    readonly code: "BM";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Bermuda";
}, {
    readonly code: "BN";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Brunei Darussalam";
}, {
    readonly code: "BO";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Bolivia, Plurinational State of";
}, {
    readonly code: "BQ";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Bonaire, Sint Eustatius and Saba";
}, {
    readonly code: "BR";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Brazil";
}, {
    readonly code: "BS";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Bahamas";
}, {
    readonly code: "BT";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Bhutan";
}, {
    readonly code: "BV";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Bouvet Island";
}, {
    readonly code: "BW";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Botswana";
}, {
    readonly code: "BY";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Belarus";
}, {
    readonly code: "BZ";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Belize";
}, {
    readonly code: "CA";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Canada";
}, {
    readonly code: "CC";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Cocos (Keeling) Islands";
}, {
    readonly code: "CD";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Congo, the Democratic Republic of the";
}, {
    readonly code: "CF";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Central African Republic";
}, {
    readonly code: "CG";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Congo";
}, {
    readonly code: "CH";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Switzerland";
}, {
    readonly code: "CI";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Côte d'Ivoire";
}, {
    readonly code: "CK";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Cook Islands";
}, {
    readonly code: "CL";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Chile";
}, {
    readonly code: "CM";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Cameroon";
}, {
    readonly code: "CN";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "China";
}, {
    readonly code: "CO";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Colombia";
}, {
    readonly code: "CR";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Costa Rica";
}, {
    readonly code: "CU";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Cuba";
}, {
    readonly code: "CV";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Cabo Verde";
}, {
    readonly code: "CW";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Curaçao";
}, {
    readonly code: "CX";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Christmas Island";
}, {
    readonly code: "CY";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Cyprus";
}, {
    readonly code: "CZ";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Czechia";
}, {
    readonly code: "DE";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Germany";
}, {
    readonly code: "DJ";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Djibouti";
}, {
    readonly code: "DK";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Denmark";
}, {
    readonly code: "DM";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Dominica";
}, {
    readonly code: "DO";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Dominican Republic";
}, {
    readonly code: "DZ";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Algeria";
}, {
    readonly code: "EC";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Ecuador";
}, {
    readonly code: "EE";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Estonia";
}, {
    readonly code: "EG";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Egypt";
}, {
    readonly code: "EH";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Western Sahara";
}, {
    readonly code: "ER";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Eritrea";
}, {
    readonly code: "ES";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Spain";
}, {
    readonly code: "ET";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Ethiopia";
}, {
    readonly code: "FI";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Finland";
}, {
    readonly code: "FJ";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Fiji";
}, {
    readonly code: "FK";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Falkland Islands (Malvinas)";
}, {
    readonly code: "FM";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Micronesia, Federated States of";
}, {
    readonly code: "FO";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Faroe Islands";
}, {
    readonly code: "FR";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "France";
}, {
    readonly code: "GA";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Gabon";
}, {
    readonly code: "GB";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "United Kingdom of Great Britain and Northern Ireland";
}, {
    readonly code: "GD";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Grenada";
}, {
    readonly code: "GE";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Georgia";
}, {
    readonly code: "GF";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "French Guiana";
}, {
    readonly code: "GG";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Guernsey";
}, {
    readonly code: "GH";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Ghana";
}, {
    readonly code: "GI";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Gibraltar";
}, {
    readonly code: "GL";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Greenland";
}, {
    readonly code: "GM";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Gambia";
}, {
    readonly code: "GN";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Guinea";
}, {
    readonly code: "GP";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Guadeloupe";
}, {
    readonly code: "GQ";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Equatorial Guinea";
}, {
    readonly code: "GR";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Greece";
}, {
    readonly code: "GS";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "South Georgia and the South Sandwich Islands";
}, {
    readonly code: "GT";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Guatemala";
}, {
    readonly code: "GU";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Guam";
}, {
    readonly code: "GW";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Guinea-Bissau";
}, {
    readonly code: "GY";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Guyana";
}, {
    readonly code: "HK";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Hong Kong";
}, {
    readonly code: "HM";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Heard Island and McDonald Islands";
}, {
    readonly code: "HN";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Honduras";
}, {
    readonly code: "HR";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Croatia";
}, {
    readonly code: "HT";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Haiti";
}, {
    readonly code: "HU";
    readonly system: "urn:iso:std:iso:3166";
    readonly display: "Hungary";
}];
/** String type (ValueSet too large for union type) */
export type JurisdictionValueSetCode = string;
/** Type representing a concept from this ValueSet */
export type JurisdictionValueSetConcept = typeof JurisdictionValueSetConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidJurisdictionValueSetCode(code: string): code is JurisdictionValueSetCode;
/**
 * Get concept details by code
 */
export declare function getJurisdictionValueSetConcept(code: string): JurisdictionValueSetConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const JurisdictionValueSetCodes: ("AD" | "CC" | "CM" | "GT" | "AE" | "AF" | "AG" | "AI" | "AL" | "AM" | "AO" | "AQ" | "AR" | "AS" | "AT" | "AU" | "AW" | "AX" | "AZ" | "BA" | "BB" | "BD" | "BE" | "BF" | "BG" | "BH" | "BI" | "BJ" | "BL" | "BM" | "BN" | "BO" | "BQ" | "BR" | "BS" | "BT" | "BV" | "BW" | "BY" | "BZ" | "CA" | "CD" | "CF" | "CG" | "CH" | "CI" | "CK" | "CL" | "CN" | "CO" | "CR" | "CU" | "CV" | "CW" | "CX" | "CY" | "CZ" | "DE" | "DJ" | "DK" | "DM" | "DO" | "DZ" | "EC" | "EE" | "EG" | "EH" | "ER" | "ES" | "ET" | "FI" | "FJ" | "FK" | "FM" | "FO" | "FR" | "GA" | "GB" | "GD" | "GE" | "GF" | "GG" | "GH" | "GI" | "GL" | "GM" | "GN" | "GP" | "GQ" | "GR" | "GS" | "GU" | "GW" | "GY" | "HK" | "HM" | "HN" | "HR" | "HT" | "HU")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomJurisdictionValueSetCode(): JurisdictionValueSetCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomJurisdictionValueSetConcept(): JurisdictionValueSetConcept;
