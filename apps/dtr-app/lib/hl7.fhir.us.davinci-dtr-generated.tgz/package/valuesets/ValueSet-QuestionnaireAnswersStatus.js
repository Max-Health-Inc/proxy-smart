/**
 * ValueSet: questionnaire-answers-status
 * URL: http://hl7.org/fhir/ValueSet/questionnaire-answers-status
 * Size: 5 concepts
 */
export const QuestionnaireAnswersStatusConcepts = [
    { code: "in-progress", system: "http://hl7.org/fhir/questionnaire-answers-status" },
    { code: "completed", system: "http://hl7.org/fhir/questionnaire-answers-status" },
    { code: "amended", system: "http://hl7.org/fhir/questionnaire-answers-status" },
    { code: "entered-in-error", system: "http://hl7.org/fhir/questionnaire-answers-status" },
    { code: "stopped", system: "http://hl7.org/fhir/questionnaire-answers-status" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidQuestionnaireAnswersStatusCode(code) {
    return QuestionnaireAnswersStatusConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getQuestionnaireAnswersStatusConcept(code) {
    return QuestionnaireAnswersStatusConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const QuestionnaireAnswersStatusCodes = QuestionnaireAnswersStatusConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomQuestionnaireAnswersStatusCode() {
    return QuestionnaireAnswersStatusCodes[Math.floor(Math.random() * QuestionnaireAnswersStatusCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomQuestionnaireAnswersStatusConcept() {
    return QuestionnaireAnswersStatusConcepts[Math.floor(Math.random() * QuestionnaireAnswersStatusConcepts.length)];
}
