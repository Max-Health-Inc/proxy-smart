/**
 * ValueSet: coverageInfo
 * URL: http://hl7.org/fhir/us/davinci-crd/ValueSet/coverageInfo
 * Size: 3 concepts
 */
export declare const CoverageInfoConcepts: readonly [{
    readonly code: "not-covered";
    readonly system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp";
}, {
    readonly code: "covered";
    readonly system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp";
}, {
    readonly code: "conditional";
    readonly system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp";
}];
/** Union type of all valid codes in this ValueSet */
export type CoverageInfoCode = "not-covered" | "covered" | "conditional";
/** Type representing a concept from this ValueSet */
export type CoverageInfoConcept = typeof CoverageInfoConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidCoverageInfoCode(code: string): code is CoverageInfoCode;
/**
 * Get concept details by code
 */
export declare function getCoverageInfoConcept(code: string): CoverageInfoConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const CoverageInfoCodes: ("not-covered" | "covered" | "conditional")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomCoverageInfoCode(): CoverageInfoCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomCoverageInfoConcept(): CoverageInfoConcept;
