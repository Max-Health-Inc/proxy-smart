/**
 * ValueSet: entformula-type
 * URL: http://hl7.org/fhir/ValueSet/entformula-type
 * Size: 36 concepts
 */
export declare const EntformulaTypeConcepts: readonly [{
    readonly code: "443031000124106";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "443051000124104";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "442911000124109";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "443021000124108";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "442971000124100";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "442981000124102";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "442991000124104";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "443011000124100";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "442961000124107";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "442951000124105";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "442941000124108";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "442921000124101";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "442931000124103";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "443361000124100";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "443401000124105";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "443491000124103";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "443501000124106";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "443421000124100";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "443471000124104";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "444431000124104";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "443451000124109";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "441561000124106";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "443461000124106";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "441531000124102";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "443561000124107";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "443481000124101";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "441571000124104";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "441591000124103";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "441601000124106";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "443351000124102";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "443771000124106";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "441671000124100";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "443111000124101";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "443431000124102";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "443411000124108";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "442651000124102";
    readonly system: "http://snomed.info/sct";
}];
/** String type (ValueSet too large for union type) */
export type EntformulaTypeCode = string;
/** Type representing a concept from this ValueSet */
export type EntformulaTypeConcept = typeof EntformulaTypeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidEntformulaTypeCode(code: string): code is EntformulaTypeCode;
/**
 * Get concept details by code
 */
export declare function getEntformulaTypeConcept(code: string): EntformulaTypeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const EntformulaTypeCodes: ("443031000124106" | "443051000124104" | "442911000124109" | "443021000124108" | "442971000124100" | "442981000124102" | "442991000124104" | "443011000124100" | "442961000124107" | "442951000124105" | "442941000124108" | "442921000124101" | "442931000124103" | "443361000124100" | "443401000124105" | "443491000124103" | "443501000124106" | "443421000124100" | "443471000124104" | "444431000124104" | "443451000124109" | "441561000124106" | "443461000124106" | "441531000124102" | "443561000124107" | "443481000124101" | "441571000124104" | "441591000124103" | "441601000124106" | "443351000124102" | "443771000124106" | "441671000124100" | "443111000124101" | "443431000124102" | "443411000124108" | "442651000124102")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomEntformulaTypeCode(): EntformulaTypeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomEntformulaTypeConcept(): EntformulaTypeConcept;
