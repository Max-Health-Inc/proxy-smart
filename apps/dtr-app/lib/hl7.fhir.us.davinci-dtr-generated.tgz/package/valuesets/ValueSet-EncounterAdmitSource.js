/**
 * ValueSet: encounter-admit-source
 * URL: http://hl7.org/fhir/ValueSet/encounter-admit-source
 * Size: 10 concepts
 */
export const EncounterAdmitSourceConcepts = [
    { code: "hosp-trans", system: "http://terminology.hl7.org/CodeSystem/admit-source" },
    { code: "emd", system: "http://terminology.hl7.org/CodeSystem/admit-source" },
    { code: "outp", system: "http://terminology.hl7.org/CodeSystem/admit-source" },
    { code: "born", system: "http://terminology.hl7.org/CodeSystem/admit-source" },
    { code: "gp", system: "http://terminology.hl7.org/CodeSystem/admit-source" },
    { code: "mp", system: "http://terminology.hl7.org/CodeSystem/admit-source" },
    { code: "nursing", system: "http://terminology.hl7.org/CodeSystem/admit-source" },
    { code: "psych", system: "http://terminology.hl7.org/CodeSystem/admit-source" },
    { code: "rehab", system: "http://terminology.hl7.org/CodeSystem/admit-source" },
    { code: "other", system: "http://terminology.hl7.org/CodeSystem/admit-source" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidEncounterAdmitSourceCode(code) {
    return EncounterAdmitSourceConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getEncounterAdmitSourceConcept(code) {
    return EncounterAdmitSourceConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const EncounterAdmitSourceCodes = EncounterAdmitSourceConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomEncounterAdmitSourceCode() {
    return EncounterAdmitSourceCodes[Math.floor(Math.random() * EncounterAdmitSourceCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomEncounterAdmitSourceConcept() {
    return EncounterAdmitSourceConcepts[Math.floor(Math.random() * EncounterAdmitSourceConcepts.length)];
}
