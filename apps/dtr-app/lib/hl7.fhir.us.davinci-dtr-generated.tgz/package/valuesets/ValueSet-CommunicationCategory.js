/**
 * ValueSet: CommunicationCategory
 * URL: http://hl7.org/fhir/ValueSet/communication-category
 * Size: 4 concepts
 */
export const CommunicationCategoryConcepts = [
    { code: "alert", system: "http://terminology.hl7.org/CodeSystem/communication-category", display: "Alert" },
    { code: "notification", system: "http://terminology.hl7.org/CodeSystem/communication-category", display: "Notification" },
    { code: "reminder", system: "http://terminology.hl7.org/CodeSystem/communication-category", display: "Reminder" },
    { code: "instruction", system: "http://terminology.hl7.org/CodeSystem/communication-category", display: "Instruction" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidCommunicationCategoryCode(code) {
    return CommunicationCategoryConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getCommunicationCategoryConcept(code) {
    return CommunicationCategoryConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const CommunicationCategoryCodes = CommunicationCategoryConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomCommunicationCategoryCode() {
    return CommunicationCategoryCodes[Math.floor(Math.random() * CommunicationCategoryCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomCommunicationCategoryConcept() {
    return CommunicationCategoryConcepts[Math.floor(Math.random() * CommunicationCategoryConcepts.length)];
}
