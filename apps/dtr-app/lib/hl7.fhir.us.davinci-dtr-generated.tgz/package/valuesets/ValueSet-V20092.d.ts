/**
 * ValueSet: v2-0092
 * URL: http://terminology.hl7.org/ValueSet/v2-0092
 * Size: 1 concepts
 */
export declare const V20092Concepts: readonly [{
    readonly code: "R";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0092";
}];
/** Union type of all valid codes in this ValueSet */
export type V20092Code = "R";
/** Type representing a concept from this ValueSet */
export type V20092Concept = typeof V20092Concepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidV20092Code(code: string): code is V20092Code;
/**
 * Get concept details by code
 */
export declare function getV20092Concept(code: string): V20092Concept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const V20092Codes: "R"[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomV20092Code(): V20092Code;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomV20092Concept(): V20092Concept;
