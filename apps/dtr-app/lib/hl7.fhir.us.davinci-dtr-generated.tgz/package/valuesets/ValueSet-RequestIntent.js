/**
 * ValueSet: request-intent
 * URL: http://hl7.org/fhir/ValueSet/request-intent
 * Size: 9 concepts
 */
export const RequestIntentConcepts = [
    { code: "proposal", system: "http://hl7.org/fhir/request-intent" },
    { code: "plan", system: "http://hl7.org/fhir/request-intent" },
    { code: "directive", system: "http://hl7.org/fhir/request-intent" },
    { code: "order", system: "http://hl7.org/fhir/request-intent" },
    { code: "original-order", system: "http://hl7.org/fhir/request-intent" },
    { code: "reflex-order", system: "http://hl7.org/fhir/request-intent" },
    { code: "filler-order", system: "http://hl7.org/fhir/request-intent" },
    { code: "instance-order", system: "http://hl7.org/fhir/request-intent" },
    { code: "option", system: "http://hl7.org/fhir/request-intent" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidRequestIntentCode(code) {
    return RequestIntentConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getRequestIntentConcept(code) {
    return RequestIntentConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const RequestIntentCodes = RequestIntentConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomRequestIntentCode() {
    return RequestIntentCodes[Math.floor(Math.random() * RequestIntentCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomRequestIntentConcept() {
    return RequestIntentConcepts[Math.floor(Math.random() * RequestIntentConcepts.length)];
}
