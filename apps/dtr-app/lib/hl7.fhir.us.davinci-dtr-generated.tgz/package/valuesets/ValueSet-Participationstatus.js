/**
 * ValueSet: participationstatus
 * URL: http://hl7.org/fhir/ValueSet/participationstatus
 * Size: 4 concepts
 */
export const ParticipationstatusConcepts = [
    { code: "accepted", system: "http://hl7.org/fhir/participationstatus" },
    { code: "declined", system: "http://hl7.org/fhir/participationstatus" },
    { code: "tentative", system: "http://hl7.org/fhir/participationstatus" },
    { code: "needs-action", system: "http://hl7.org/fhir/participationstatus" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidParticipationstatusCode(code) {
    return ParticipationstatusConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getParticipationstatusConcept(code) {
    return ParticipationstatusConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ParticipationstatusCodes = ParticipationstatusConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomParticipationstatusCode() {
    return ParticipationstatusCodes[Math.floor(Math.random() * ParticipationstatusCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomParticipationstatusConcept() {
    return ParticipationstatusConcepts[Math.floor(Math.random() * ParticipationstatusConcepts.length)];
}
