/**
 * ValueSet: DTRInformationOrigins
 * URL: http://hl7.org/fhir/us/davinci-dtr/ValueSet/informationOrigins
 * Size: 3 concepts
 */
export const DTRInformationOriginsConcepts = [
    { code: "auto", system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp" },
    { code: "override", system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp" },
    { code: "manual", system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidDTRInformationOriginsCode(code) {
    return DTRInformationOriginsConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getDTRInformationOriginsConcept(code) {
    return DTRInformationOriginsConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const DTRInformationOriginsCodes = DTRInformationOriginsConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomDTRInformationOriginsCode() {
    return DTRInformationOriginsCodes[Math.floor(Math.random() * DTRInformationOriginsCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomDTRInformationOriginsConcept() {
    return DTRInformationOriginsConcepts[Math.floor(Math.random() * DTRInformationOriginsConcepts.length)];
}
