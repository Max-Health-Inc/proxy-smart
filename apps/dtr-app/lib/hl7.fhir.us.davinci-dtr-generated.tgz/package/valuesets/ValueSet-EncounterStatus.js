/**
 * ValueSet: encounter-status
 * URL: http://hl7.org/fhir/ValueSet/encounter-status
 * Size: 9 concepts
 */
export const EncounterStatusConcepts = [
    { code: "planned", system: "http://hl7.org/fhir/encounter-status" },
    { code: "arrived", system: "http://hl7.org/fhir/encounter-status" },
    { code: "triaged", system: "http://hl7.org/fhir/encounter-status" },
    { code: "in-progress", system: "http://hl7.org/fhir/encounter-status" },
    { code: "onleave", system: "http://hl7.org/fhir/encounter-status" },
    { code: "finished", system: "http://hl7.org/fhir/encounter-status" },
    { code: "cancelled", system: "http://hl7.org/fhir/encounter-status" },
    { code: "entered-in-error", system: "http://hl7.org/fhir/encounter-status" },
    { code: "unknown", system: "http://hl7.org/fhir/encounter-status" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidEncounterStatusCode(code) {
    return EncounterStatusConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getEncounterStatusConcept(code) {
    return EncounterStatusConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const EncounterStatusCodes = EncounterStatusConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomEncounterStatusCode() {
    return EncounterStatusCodes[Math.floor(Math.random() * EncounterStatusCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomEncounterStatusConcept() {
    return EncounterStatusConcepts[Math.floor(Math.random() * EncounterStatusConcepts.length)];
}
