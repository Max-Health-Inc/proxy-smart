/**
 * ValueSet: EnableWhenBehavior
 * URL: http://hl7.org/fhir/ValueSet/questionnaire-enable-behavior
 * Size: 2 concepts
 */
export declare const EnableWhenBehaviorConcepts: readonly [{
    readonly code: "all";
    readonly system: "http://hl7.org/fhir/questionnaire-enable-behavior";
    readonly display: "All";
}, {
    readonly code: "any";
    readonly system: "http://hl7.org/fhir/questionnaire-enable-behavior";
    readonly display: "Any";
}];
/** Union type of all valid codes in this ValueSet */
export type EnableWhenBehaviorCode = "all" | "any";
/** Type representing a concept from this ValueSet */
export type EnableWhenBehaviorConcept = typeof EnableWhenBehaviorConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidEnableWhenBehaviorCode(code: string): code is EnableWhenBehaviorCode;
/**
 * Get concept details by code
 */
export declare function getEnableWhenBehaviorConcept(code: string): EnableWhenBehaviorConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const EnableWhenBehaviorCodes: ("all" | "any")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomEnableWhenBehaviorCode(): EnableWhenBehaviorCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomEnableWhenBehaviorConcept(): EnableWhenBehaviorConcept;
