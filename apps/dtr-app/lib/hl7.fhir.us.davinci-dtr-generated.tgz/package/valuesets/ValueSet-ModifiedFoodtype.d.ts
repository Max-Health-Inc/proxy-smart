/**
 * ValueSet: modified-foodtype
 * URL: http://hl7.org/fhir/ValueSet/modified-foodtype
 * Size: 14 concepts
 */
export declare const ModifiedFoodtypeConcepts: readonly [{
    readonly code: "255620007";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "28647000";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "22836000";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "72511004";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "226760005";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "226887002";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "102263004";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "74242007";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "227415002";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "264331002";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "227518002";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "44027008";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "226529007";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "227210005";
    readonly system: "http://snomed.info/sct";
}];
/** Union type of all valid codes in this ValueSet */
export type ModifiedFoodtypeCode = "255620007" | "28647000" | "22836000" | "72511004" | "226760005" | "226887002" | "102263004" | "74242007" | "227415002" | "264331002" | "227518002" | "44027008" | "226529007" | "227210005";
/** Type representing a concept from this ValueSet */
export type ModifiedFoodtypeConcept = typeof ModifiedFoodtypeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidModifiedFoodtypeCode(code: string): code is ModifiedFoodtypeCode;
/**
 * Get concept details by code
 */
export declare function getModifiedFoodtypeConcept(code: string): ModifiedFoodtypeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ModifiedFoodtypeCodes: ("255620007" | "22836000" | "28647000" | "44027008" | "72511004" | "74242007" | "102263004" | "226760005" | "226887002" | "227415002" | "264331002" | "227518002" | "226529007" | "227210005")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomModifiedFoodtypeCode(): ModifiedFoodtypeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomModifiedFoodtypeConcept(): ModifiedFoodtypeConcept;
