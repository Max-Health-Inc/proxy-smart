/**
 * ValueSet: DocReason
 * URL: http://hl7.org/fhir/us/davinci-crd/ValueSet/DocReason
 * Size: 5 concepts
 */
export const DocReasonConcepts = [
    { code: "withpa", system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp" },
    { code: "withclaim", system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp" },
    { code: "withorder", system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp" },
    { code: "retain-doc", system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp" },
    { code: "OTH", system: "http://terminology.hl7.org/CodeSystem/v3-NullFlavor" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidDocReasonCode(code) {
    return DocReasonConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getDocReasonConcept(code) {
    return DocReasonConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const DocReasonCodes = DocReasonConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomDocReasonCode() {
    return DocReasonCodes[Math.floor(Math.random() * DocReasonCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomDocReasonConcept() {
    return DocReasonConcepts[Math.floor(Math.random() * DocReasonConcepts.length)];
}
