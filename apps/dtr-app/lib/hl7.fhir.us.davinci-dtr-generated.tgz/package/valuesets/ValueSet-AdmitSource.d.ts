/**
 * ValueSet: AdmitSource
 * URL: http://hl7.org/fhir/ValueSet/encounter-admit-source
 * Size: 10 concepts
 */
export declare const AdmitSourceConcepts: readonly [{
    readonly code: "hosp-trans";
    readonly system: "http://terminology.hl7.org/CodeSystem/admit-source";
    readonly display: "Transferred from other hospital";
}, {
    readonly code: "emd";
    readonly system: "http://terminology.hl7.org/CodeSystem/admit-source";
    readonly display: "From accident/emergency department";
}, {
    readonly code: "outp";
    readonly system: "http://terminology.hl7.org/CodeSystem/admit-source";
    readonly display: "From outpatient department";
}, {
    readonly code: "born";
    readonly system: "http://terminology.hl7.org/CodeSystem/admit-source";
    readonly display: "Born in hospital";
}, {
    readonly code: "gp";
    readonly system: "http://terminology.hl7.org/CodeSystem/admit-source";
    readonly display: "General Practitioner referral";
}, {
    readonly code: "mp";
    readonly system: "http://terminology.hl7.org/CodeSystem/admit-source";
    readonly display: "Medical Practitioner/physician referral";
}, {
    readonly code: "nursing";
    readonly system: "http://terminology.hl7.org/CodeSystem/admit-source";
    readonly display: "From nursing home";
}, {
    readonly code: "psych";
    readonly system: "http://terminology.hl7.org/CodeSystem/admit-source";
    readonly display: "From psychiatric hospital";
}, {
    readonly code: "rehab";
    readonly system: "http://terminology.hl7.org/CodeSystem/admit-source";
    readonly display: "From rehabilitation facility";
}, {
    readonly code: "other";
    readonly system: "http://terminology.hl7.org/CodeSystem/admit-source";
    readonly display: "Other";
}];
/** Union type of all valid codes in this ValueSet */
export type AdmitSourceCode = "hosp-trans" | "emd" | "outp" | "born" | "gp" | "mp" | "nursing" | "psych" | "rehab" | "other";
/** Type representing a concept from this ValueSet */
export type AdmitSourceConcept = typeof AdmitSourceConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidAdmitSourceCode(code: string): code is AdmitSourceCode;
/**
 * Get concept details by code
 */
export declare function getAdmitSourceConcept(code: string): AdmitSourceConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const AdmitSourceCodes: ("other" | "hosp-trans" | "emd" | "outp" | "born" | "gp" | "mp" | "nursing" | "psych" | "rehab")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomAdmitSourceCode(): AdmitSourceCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomAdmitSourceConcept(): AdmitSourceConcept;
