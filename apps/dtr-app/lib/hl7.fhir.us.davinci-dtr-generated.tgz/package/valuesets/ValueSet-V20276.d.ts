/**
 * ValueSet: v2-0276
 * URL: http://terminology.hl7.org/ValueSet/v2-0276
 * Size: 5 concepts
 */
export declare const V20276Concepts: readonly [{
    readonly code: "ROUTINE";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0276";
}, {
    readonly code: "WALKIN";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0276";
}, {
    readonly code: "CHECKUP";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0276";
}, {
    readonly code: "FOLLOWUP";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0276";
}, {
    readonly code: "EMERGENCY";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0276";
}];
/** Union type of all valid codes in this ValueSet */
export type V20276Code = "ROUTINE" | "WALKIN" | "CHECKUP" | "FOLLOWUP" | "EMERGENCY";
/** Type representing a concept from this ValueSet */
export type V20276Concept = typeof V20276Concepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidV20276Code(code: string): code is V20276Code;
/**
 * Get concept details by code
 */
export declare function getV20276Concept(code: string): V20276Concept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const V20276Codes: ("ROUTINE" | "WALKIN" | "CHECKUP" | "FOLLOWUP" | "EMERGENCY")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomV20276Code(): V20276Code;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomV20276Concept(): V20276Concept;
