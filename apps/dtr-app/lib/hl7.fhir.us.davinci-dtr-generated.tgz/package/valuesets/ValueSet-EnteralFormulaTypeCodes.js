/**
 * ValueSet: EnteralFormulaTypeCodes
 * URL: http://hl7.org/fhir/ValueSet/entformula-type
 * Size: 36 concepts
 */
export const EnteralFormulaTypeCodesConcepts = [
    { code: "443031000124106", system: "http://snomed.info/sct", display: "Adult critical care formula" },
    { code: "443051000124104", system: "http://snomed.info/sct", display: "Adult diabetes specialty formula" },
    { code: "442911000124109", system: "http://snomed.info/sct", display: "Adult elemental formula" },
    { code: "443021000124108", system: "http://snomed.info/sct", display: "Adult hepatic specialty formula" },
    { code: "442971000124100", system: "http://snomed.info/sct", display: "Adult high energy formula" },
    { code: "442981000124102", system: "http://snomed.info/sct", display: "Adult hydrolyzed protein formula" },
    { code: "442991000124104", system: "http://snomed.info/sct", display: "Adult high protein formula" },
    { code: "443011000124100", system: "http://snomed.info/sct", display: "Adult high protein high fiber formula" },
    { code: "442961000124107", system: "http://snomed.info/sct", display: "Adult low carbohydrate formula" },
    { code: "442951000124105", system: "http://snomed.info/sct", display: "Adult pulmonary specialty formula" },
    { code: "442941000124108", system: "http://snomed.info/sct", display: "Adult renal specialty formula" },
    { code: "442921000124101", system: "http://snomed.info/sct", display: "Adult standard formula" },
    { code: "442931000124103", system: "http://snomed.info/sct", display: "Adult soy protein isolate formula" },
    { code: "443361000124100", system: "http://snomed.info/sct", display: "Pediatric Formula" },
    { code: "443401000124105", system: "http://snomed.info/sct", display: "Pediatric elemental formula" },
    { code: "443491000124103", system: "http://snomed.info/sct", display: "Pediatric high energy formula" },
    { code: "443501000124106", system: "http://snomed.info/sct", display: "Pediatric high energy formula with increased fiber" },
    { code: "443421000124100", system: "http://snomed.info/sct", display: "Pediatric hydrolyzed protein formula" },
    { code: "443471000124104", system: "http://snomed.info/sct", display: "Pediatric increased fiber formula" },
    { code: "444431000124104", system: "http://snomed.info/sct", display: "Pediatric reduced energy formula" },
    { code: "443451000124109", system: "http://snomed.info/sct", display: "Pediatric standard formula" },
    { code: "441561000124106", system: "http://snomed.info/sct", display: "Standard enteral formula with fiber" },
    { code: "443461000124106", system: "http://snomed.info/sct", display: "Standard Formula" },
    { code: "441531000124102", system: "http://snomed.info/sct", display: "Standard Enteral Formula" },
    { code: "443561000124107", system: "http://snomed.info/sct", display: "Soy based formula" },
    { code: "443481000124101", system: "http://snomed.info/sct", display: "Renal Formula" },
    { code: "441571000124104", system: "http://snomed.info/sct", display: "High energy enteral formula with fiber" },
    { code: "441591000124103", system: "http://snomed.info/sct", display: "Diabetic enteral formula with fiber" },
    { code: "441601000124106", system: "http://snomed.info/sct", display: "Diabetic high calorie high protein enteral formula with fiber" },
    { code: "443351000124102", system: "http://snomed.info/sct", display: "Increased fiber formula" },
    { code: "443771000124106", system: "http://snomed.info/sct", display: "Hydrolyzed protein formula" },
    { code: "441671000124100", system: "http://snomed.info/sct", display: "Hydrolyzed peptide-based high protein enteral formula" },
    { code: "443111000124101", system: "http://snomed.info/sct", display: "High protein formula" },
    { code: "443431000124102", system: "http://snomed.info/sct", display: "High Energy Formula" },
    { code: "443411000124108", system: "http://snomed.info/sct", display: "Elemental Formula" },
    { code: "442651000124102", system: "http://snomed.info/sct", display: "Adult formula" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidEnteralFormulaTypeCodesCode(code) {
    return EnteralFormulaTypeCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getEnteralFormulaTypeCodesConcept(code) {
    return EnteralFormulaTypeCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const EnteralFormulaTypeCodesCodes = EnteralFormulaTypeCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomEnteralFormulaTypeCodesCode() {
    return EnteralFormulaTypeCodesCodes[Math.floor(Math.random() * EnteralFormulaTypeCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomEnteralFormulaTypeCodesConcept() {
    return EnteralFormulaTypeCodesConcepts[Math.floor(Math.random() * EnteralFormulaTypeCodesConcepts.length)];
}
