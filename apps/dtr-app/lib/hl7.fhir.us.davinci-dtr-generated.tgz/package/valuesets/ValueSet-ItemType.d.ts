/**
 * ValueSet: item-type
 * URL: http://hl7.org/fhir/ValueSet/item-type
 * Size: 17 concepts
 */
export declare const ItemTypeConcepts: readonly [{
    readonly code: "group";
    readonly system: "http://hl7.org/fhir/item-type";
}, {
    readonly code: "display";
    readonly system: "http://hl7.org/fhir/item-type";
}, {
    readonly code: "question";
    readonly system: "http://hl7.org/fhir/item-type";
}, {
    readonly code: "boolean";
    readonly system: "http://hl7.org/fhir/item-type";
}, {
    readonly code: "decimal";
    readonly system: "http://hl7.org/fhir/item-type";
}, {
    readonly code: "integer";
    readonly system: "http://hl7.org/fhir/item-type";
}, {
    readonly code: "date";
    readonly system: "http://hl7.org/fhir/item-type";
}, {
    readonly code: "dateTime";
    readonly system: "http://hl7.org/fhir/item-type";
}, {
    readonly code: "time";
    readonly system: "http://hl7.org/fhir/item-type";
}, {
    readonly code: "string";
    readonly system: "http://hl7.org/fhir/item-type";
}, {
    readonly code: "text";
    readonly system: "http://hl7.org/fhir/item-type";
}, {
    readonly code: "url";
    readonly system: "http://hl7.org/fhir/item-type";
}, {
    readonly code: "choice";
    readonly system: "http://hl7.org/fhir/item-type";
}, {
    readonly code: "open-choice";
    readonly system: "http://hl7.org/fhir/item-type";
}, {
    readonly code: "attachment";
    readonly system: "http://hl7.org/fhir/item-type";
}, {
    readonly code: "reference";
    readonly system: "http://hl7.org/fhir/item-type";
}, {
    readonly code: "quantity";
    readonly system: "http://hl7.org/fhir/item-type";
}];
/** Union type of all valid codes in this ValueSet */
export type ItemTypeCode = "group" | "display" | "question" | "boolean" | "decimal" | "integer" | "date" | "dateTime" | "time" | "string" | "text" | "url" | "choice" | "open-choice" | "attachment" | "reference" | "quantity";
/** Type representing a concept from this ValueSet */
export type ItemTypeConcept = typeof ItemTypeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidItemTypeCode(code: string): code is ItemTypeCode;
/**
 * Get concept details by code
 */
export declare function getItemTypeConcept(code: string): ItemTypeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ItemTypeCodes: ("string" | "boolean" | "url" | "reference" | "text" | "display" | "integer" | "dateTime" | "date" | "decimal" | "time" | "group" | "question" | "choice" | "open-choice" | "attachment" | "quantity")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomItemTypeCode(): ItemTypeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomItemTypeConcept(): ItemTypeConcept;
