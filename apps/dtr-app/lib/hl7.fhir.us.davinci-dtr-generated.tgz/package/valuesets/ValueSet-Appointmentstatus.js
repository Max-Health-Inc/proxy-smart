/**
 * ValueSet: appointmentstatus
 * URL: http://hl7.org/fhir/ValueSet/appointmentstatus
 * Size: 10 concepts
 */
export const AppointmentstatusConcepts = [
    { code: "proposed", system: "http://hl7.org/fhir/appointmentstatus" },
    { code: "pending", system: "http://hl7.org/fhir/appointmentstatus" },
    { code: "booked", system: "http://hl7.org/fhir/appointmentstatus" },
    { code: "arrived", system: "http://hl7.org/fhir/appointmentstatus" },
    { code: "fulfilled", system: "http://hl7.org/fhir/appointmentstatus" },
    { code: "cancelled", system: "http://hl7.org/fhir/appointmentstatus" },
    { code: "noshow", system: "http://hl7.org/fhir/appointmentstatus" },
    { code: "entered-in-error", system: "http://hl7.org/fhir/appointmentstatus" },
    { code: "checked-in", system: "http://hl7.org/fhir/appointmentstatus" },
    { code: "waitlist", system: "http://hl7.org/fhir/appointmentstatus" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidAppointmentstatusCode(code) {
    return AppointmentstatusConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getAppointmentstatusConcept(code) {
    return AppointmentstatusConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const AppointmentstatusCodes = AppointmentstatusConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomAppointmentstatusCode() {
    return AppointmentstatusCodes[Math.floor(Math.random() * AppointmentstatusCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomAppointmentstatusConcept() {
    return AppointmentstatusConcepts[Math.floor(Math.random() * AppointmentstatusConcepts.length)];
}
