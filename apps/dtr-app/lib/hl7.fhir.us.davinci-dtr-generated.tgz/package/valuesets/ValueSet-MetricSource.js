/**
 * ValueSet: MetricSource
 * URL: http://hl7.org/fhir/us/davinci-dtr/ValueSet/metric-Source
 * Size: 3 concepts
 */
export const MetricSourceConcepts = [
    { code: "payer-src", system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp" },
    { code: "provider-src", system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp" },
    { code: "DTRApp-src", system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidMetricSourceCode(code) {
    return MetricSourceConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getMetricSourceConcept(code) {
    return MetricSourceConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const MetricSourceCodes = MetricSourceConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomMetricSourceCode() {
    return MetricSourceCodes[Math.floor(Math.random() * MetricSourceCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomMetricSourceConcept() {
    return MetricSourceConcepts[Math.floor(Math.random() * MetricSourceConcepts.length)];
}
