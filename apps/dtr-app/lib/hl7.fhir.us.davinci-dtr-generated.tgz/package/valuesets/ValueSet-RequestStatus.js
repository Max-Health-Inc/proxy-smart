/**
 * ValueSet: request-status
 * URL: http://hl7.org/fhir/ValueSet/request-status
 * Size: 7 concepts
 */
export const RequestStatusConcepts = [
    { code: "draft", system: "http://hl7.org/fhir/request-status" },
    { code: "active", system: "http://hl7.org/fhir/request-status" },
    { code: "on-hold", system: "http://hl7.org/fhir/request-status" },
    { code: "revoked", system: "http://hl7.org/fhir/request-status" },
    { code: "completed", system: "http://hl7.org/fhir/request-status" },
    { code: "entered-in-error", system: "http://hl7.org/fhir/request-status" },
    { code: "unknown", system: "http://hl7.org/fhir/request-status" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidRequestStatusCode(code) {
    return RequestStatusConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getRequestStatusConcept(code) {
    return RequestStatusConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const RequestStatusCodes = RequestStatusConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomRequestStatusCode() {
    return RequestStatusCodes[Math.floor(Math.random() * RequestStatusCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomRequestStatusConcept() {
    return RequestStatusConcepts[Math.floor(Math.random() * RequestStatusConcepts.length)];
}
