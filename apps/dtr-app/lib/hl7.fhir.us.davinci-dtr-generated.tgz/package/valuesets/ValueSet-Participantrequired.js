/**
 * ValueSet: participantrequired
 * URL: http://hl7.org/fhir/ValueSet/participantrequired
 * Size: 3 concepts
 */
export const ParticipantrequiredConcepts = [
    { code: "required", system: "http://hl7.org/fhir/participantrequired" },
    { code: "optional", system: "http://hl7.org/fhir/participantrequired" },
    { code: "information-only", system: "http://hl7.org/fhir/participantrequired" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidParticipantrequiredCode(code) {
    return ParticipantrequiredConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getParticipantrequiredConcept(code) {
    return ParticipantrequiredConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ParticipantrequiredCodes = ParticipantrequiredConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomParticipantrequiredCode() {
    return ParticipantrequiredCodes[Math.floor(Math.random() * ParticipantrequiredCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomParticipantrequiredConcept() {
    return ParticipantrequiredConcepts[Math.floor(Math.random() * ParticipantrequiredConcepts.length)];
}
