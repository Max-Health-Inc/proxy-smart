/**
 * ValueSet: DietCodes
 * URL: http://hl7.org/fhir/ValueSet/diet-type
 * Size: 100 concepts
 */
export declare const DietCodesConcepts: readonly [{
    readonly code: "182922004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Dietary regime";
}, {
    readonly code: "182923009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Nil by mouth";
}, {
    readonly code: "223456000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Provision of a special diet";
}, {
    readonly code: "289165000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Restricting food intake";
}, {
    readonly code: "386261001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Diet staging (regime/therapy)";
}, {
    readonly code: "404919001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Wheat-free diet (regime/therapy)";
}, {
    readonly code: "416576000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Carbohydrate counting (regime/therapy)";
}, {
    readonly code: "425458000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Lactose-free diet (regime/therapy)";
}, {
    readonly code: "709564003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Restricting oral intake";
}, {
    readonly code: "762104002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Modified fluid diet (regime/therapy)";
}, {
    readonly code: "765021002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Vegetarian diet (regime/therapy)";
}, {
    readonly code: "765022009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Lacto-vegetarian diet";
}, {
    readonly code: "765023004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Lacto-ovo-vegetarian diet";
}, {
    readonly code: "765024005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Atkins diet";
}, {
    readonly code: "765025006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Kosher diet";
}, {
    readonly code: "765052001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hindu diet (regime/therapy)";
}, {
    readonly code: "765053006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Low fructose diet (regime/therapy)";
}, {
    readonly code: "765060000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Ketogenic diet";
}, {
    readonly code: "765063003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Cantonese diet";
}, {
    readonly code: "792805006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Fasting";
}, {
    readonly code: "1052337007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Protein modified diet";
}, {
    readonly code: "1055200005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Increased protein diet";
}, {
    readonly code: "1055201009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Decreased protein diet";
}, {
    readonly code: "1055202002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Consistent protein and protein derivative diet";
}, {
    readonly code: "1055203007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Increased fat and oil diet";
}, {
    readonly code: "1055204001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Fat and oil modified diet";
}, {
    readonly code: "1055207008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Decreased fat diet";
}, {
    readonly code: "1137465007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Increased galactose diet (regime/therapy)";
}, {
    readonly code: "1141680002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Increased lactose diet (regime/therapy)";
}, {
    readonly code: "1141683000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Fructose modified diet (regime/therapy)";
}, {
    readonly code: "1141684006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Increased fructose diet (regime/therapy)";
}, {
    readonly code: "1141931005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Vitamin A and vitamin A derivative modified diet (regime/therapy)";
}, {
    readonly code: "1141932003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Increased vitamin A and vitamin A derivative diet (regime/therapy)";
}, {
    readonly code: "1141933008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Decreased vitamin A and vitamin A derivative diet";
}, {
    readonly code: "1141934002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Decreased vitamin D and vitamin D derivative diet (regime/therapy)";
}, {
    readonly code: "1141935001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Increased vitamin D and vitamin D derivative diet (regime/therapy)";
}, {
    readonly code: "1141936000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Vitamin D and vitamin D derivative modified diet";
}, {
    readonly code: "1142125005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Decreased linoleic acid diet";
}, {
    readonly code: "1142126006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Increased linoleic acid diet (regime/therapy)";
}, {
    readonly code: "1142127002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Omega 3 fatty acid modified diet";
}, {
    readonly code: "1142128007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Medium chain triglyceride modified diet (regime/therapy)";
}, {
    readonly code: "1142129004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Decreased N-3 fatty acid diet";
}, {
    readonly code: "1142131008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Increased omega 3 fatty acid diet";
}, {
    readonly code: "1142132001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Decreased medium chain triglyceride diet (regime/therapy)";
}, {
    readonly code: "1142133006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Increased medium chain triglyceride diet";
}, {
    readonly code: "1142162007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Decreased linolenic acid diet";
}, {
    readonly code: "1142163002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Decreased eicosapentaenoic acid diet";
}, {
    readonly code: "1142164008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Decreased docosahexaenoic acid diet (regime/therapy)";
}, {
    readonly code: "1142165009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Increased linolenic acid diet (regime/therapy)";
}, {
    readonly code: "1142166005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Increased eicosapentaenoic acid diet (regime/therapy)";
}, {
    readonly code: "1142167001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Increased docosahexaenoic acid diet";
}, {
    readonly code: "1144595005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Vitamin E and vitamin E derivative modified diet (regime/therapy)";
}, {
    readonly code: "1144596006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Increased vitamin E and vitamin E derivative diet";
}, {
    readonly code: "1144598007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Decreased vitamin E and vitamin E derivative diet (regime/therapy)";
}, {
    readonly code: "1144599004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Increased vitamin K and vitamin K derivative diet (regime/therapy)";
}, {
    readonly code: "1144600001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Decreased vitamin K and vitamin K derivative diet (regime/therapy)";
}, {
    readonly code: "1144601002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Vitamin K and vitamin K derivative modified diet";
}, {
    readonly code: "1144800003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Folate and folate derivative modified diet (regime/therapy)";
}, {
    readonly code: "1144801004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Increased folate and folate derivative diet (regime/therapy)";
}, {
    readonly code: "1144802006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Decreased folate and folate derivative diet (regime/therapy)";
}, {
    readonly code: "1144804007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Vitamin B6 and vitamin B6 derivative modified diet (regime/therapy)";
}, {
    readonly code: "1144806009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Increased vitamin B6 and vitamin B6 derivative diet";
}, {
    readonly code: "1144808005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Decreased vitamin B6 and vitamin B6 derivative diet";
}, {
    readonly code: "1144996003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Vitamin B12 and vitamin B12 derivative modified diet (regime/therapy)";
}, {
    readonly code: "1144999005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Decreased vitamin B12 and vitamin B12 derivative diet (regime/therapy)";
}, {
    readonly code: "1145000005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Increased vitamin B12 and vitamin B12 derivative diet";
}, {
    readonly code: "1148495004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Increased complex carbohydrate diet (regime/therapy)";
}, {
    readonly code: "1148496003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Decreased complex carbohydrate diet (regime/therapy)";
}, {
    readonly code: "1148497007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Increased simple carbohydrate diet";
}, {
    readonly code: "1148499005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Decreased simple carbohydrate diet (regime/therapy)";
}, {
    readonly code: "1148501002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Increased phenylalanine diet (regime/therapy)";
}, {
    readonly code: "1148502009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Phenylalanine modified diet (regime/therapy)";
}, {
    readonly code: "1155728004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Decreased chromium diet";
}, {
    readonly code: "1155729007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Sulfate salt modified diet (regime/therapy)";
}, {
    readonly code: "1156314000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Chloride salt modified diet (regime/therapy)";
}, {
    readonly code: "1156315004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Plant fiber modified diet (regime/therapy)";
}, {
    readonly code: "1156443007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Increased plant fiber diet";
}, {
    readonly code: "1156444001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Decreased plant fiber diet";
}, {
    readonly code: "1156717005";
    readonly system: "http://snomed.info/sct";
    readonly display: "CHILD-1 - Cardiovascular Health Integrated Lifestyle Diet 1";
}, {
    readonly code: "1156718000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Cardiovascular Health Integrated Lifestyle Diet 2 Triglyceride";
}, {
    readonly code: "1156719008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Cardiovascular Health Integrated Lifestyle Diet 2 Low Density Lipoprotein";
}, {
    readonly code: "1162720001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Grain modified diet";
}, {
    readonly code: "1162721002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Vegetable modified diet";
}, {
    readonly code: "1162722009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Protein food modified diet";
}, {
    readonly code: "1162724005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Egg modified diet";
}, {
    readonly code: "1162725006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Raw egg free diet (regime/therapy)";
}, {
    readonly code: "1162726007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Fruit modified diet";
}, {
    readonly code: "1162729000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Modification of nutrition intake schedule to limit fasting";
}, {
    readonly code: "1230134005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Diet modified for uncooked food starch (regime/therapy)";
}, {
    readonly code: "1230138008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Diet modified for low protein medical food";
}, {
    readonly code: "1254992009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Caffeine free diet (regime/therapy)";
}, {
    readonly code: "1254993004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Lupin free diet (regime/therapy)";
}, {
    readonly code: "1254994005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Mammalian meat free diet";
}, {
    readonly code: "1254995006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Egg free diet (regime/therapy)";
}, {
    readonly code: "1254996007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Tree nut free diet";
}, {
    readonly code: "1254998008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Sesame free diet";
}, {
    readonly code: "1254999000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Fish free diet";
}, {
    readonly code: "1255001001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Soy free diet";
}, {
    readonly code: "1255002008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Shellfish free diet";
}, {
    readonly code: "1255003003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Peanut free diet (regime/therapy)";
}];
/** String type (ValueSet too large for union type) */
export type DietCodesCode = string;
/** Type representing a concept from this ValueSet */
export type DietCodesConcept = typeof DietCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidDietCodesCode(code: string): code is DietCodesCode;
/**
 * Get concept details by code
 */
export declare function getDietCodesConcept(code: string): DietCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const DietCodesCodes: ("182922004" | "182923009" | "223456000" | "289165000" | "386261001" | "404919001" | "416576000" | "425458000" | "709564003" | "762104002" | "765021002" | "765022009" | "765023004" | "765024005" | "765025006" | "765052001" | "765053006" | "765060000" | "765063003" | "792805006" | "1052337007" | "1055200005" | "1055201009" | "1055202002" | "1055203007" | "1055204001" | "1055207008" | "1137465007" | "1141680002" | "1141683000" | "1141684006" | "1141931005" | "1141932003" | "1141933008" | "1141934002" | "1141935001" | "1141936000" | "1142125005" | "1142126006" | "1142127002" | "1142128007" | "1142129004" | "1142131008" | "1142132001" | "1142133006" | "1142162007" | "1142163002" | "1142164008" | "1142165009" | "1142166005" | "1142167001" | "1144595005" | "1144596006" | "1144598007" | "1144599004" | "1144600001" | "1144601002" | "1144800003" | "1144801004" | "1144802006" | "1144804007" | "1144806009" | "1144808005" | "1144996003" | "1144999005" | "1145000005" | "1148495004" | "1148496003" | "1148497007" | "1148499005" | "1148501002" | "1148502009" | "1155728004" | "1155729007" | "1156314000" | "1156315004" | "1156443007" | "1156444001" | "1156717005" | "1156718000" | "1156719008" | "1162720001" | "1162721002" | "1162722009" | "1162724005" | "1162725006" | "1162726007" | "1162729000" | "1230134005" | "1230138008" | "1254992009" | "1254993004" | "1254994005" | "1254995006" | "1254996007" | "1254998008" | "1254999000" | "1255001001" | "1255002008" | "1255003003")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomDietCodesCode(): DietCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomDietCodesConcept(): DietCodesConcept;
