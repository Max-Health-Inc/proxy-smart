/**
 * ValueSet: coverageInfo
 * URL: http://hl7.org/fhir/us/davinci-crd/ValueSet/coverageInfo
 * Size: 3 concepts
 */
export const CoverageInfoConcepts = [
    { code: "not-covered", system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp" },
    { code: "covered", system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp" },
    { code: "conditional", system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidCoverageInfoCode(code) {
    return CoverageInfoConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getCoverageInfoConcept(code) {
    return CoverageInfoConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const CoverageInfoCodes = CoverageInfoConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomCoverageInfoCode() {
    return CoverageInfoCodes[Math.floor(Math.random() * CoverageInfoCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomCoverageInfoConcept() {
    return CoverageInfoConcepts[Math.floor(Math.random() * CoverageInfoConcepts.length)];
}
