/**
 * ValueSet: coveragePaDetail
 * URL: http://hl7.org/fhir/us/davinci-crd/ValueSet/coveragePaDetail
 * Size: 5 concepts
 */
export declare const CoveragePaDetailConcepts: readonly [{
    readonly code: "no-auth";
    readonly system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp";
}, {
    readonly code: "auth-needed";
    readonly system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp";
}, {
    readonly code: "satisfied";
    readonly system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp";
}, {
    readonly code: "performpa";
    readonly system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp";
}, {
    readonly code: "conditional";
    readonly system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp";
}];
/** Union type of all valid codes in this ValueSet */
export type CoveragePaDetailCode = "no-auth" | "auth-needed" | "satisfied" | "performpa" | "conditional";
/** Type representing a concept from this ValueSet */
export type CoveragePaDetailConcept = typeof CoveragePaDetailConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidCoveragePaDetailCode(code: string): code is CoveragePaDetailCode;
/**
 * Get concept details by code
 */
export declare function getCoveragePaDetailConcept(code: string): CoveragePaDetailConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const CoveragePaDetailCodes: ("conditional" | "no-auth" | "auth-needed" | "satisfied" | "performpa")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomCoveragePaDetailCode(): CoveragePaDetailCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomCoveragePaDetailConcept(): CoveragePaDetailConcept;
