/**
 * ValueSet: v3-ParticipationMode
 * URL: http://terminology.hl7.org/ValueSet/v3-ParticipationMode
 * Size: 2 concepts
 */
export declare const V3ParticipationModeConcepts: readonly [{
    readonly code: "PHYSICAL";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ParticipationMode";
}, {
    readonly code: "REMOTE";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ParticipationMode";
}];
/** Union type of all valid codes in this ValueSet */
export type V3ParticipationModeCode = "PHYSICAL" | "REMOTE";
/** Type representing a concept from this ValueSet */
export type V3ParticipationModeConcept = typeof V3ParticipationModeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidV3ParticipationModeCode(code: string): code is V3ParticipationModeCode;
/**
 * Get concept details by code
 */
export declare function getV3ParticipationModeConcept(code: string): V3ParticipationModeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const V3ParticipationModeCodes: ("PHYSICAL" | "REMOTE")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomV3ParticipationModeCode(): V3ParticipationModeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomV3ParticipationModeConcept(): V3ParticipationModeConcept;
