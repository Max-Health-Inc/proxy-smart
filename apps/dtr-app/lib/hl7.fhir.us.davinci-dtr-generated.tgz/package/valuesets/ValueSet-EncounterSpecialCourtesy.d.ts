/**
 * ValueSet: encounter-special-courtesy
 * URL: http://hl7.org/fhir/ValueSet/encounter-special-courtesy
 * Size: 6 concepts
 */
export declare const EncounterSpecialCourtesyConcepts: readonly [{
    readonly code: "EXT";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-EncounterSpecialCourtesy";
}, {
    readonly code: "NRM";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-EncounterSpecialCourtesy";
}, {
    readonly code: "PRF";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-EncounterSpecialCourtesy";
}, {
    readonly code: "STF";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-EncounterSpecialCourtesy";
}, {
    readonly code: "VIP";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-EncounterSpecialCourtesy";
}, {
    readonly code: "UNK";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-NullFlavor";
}];
/** Union type of all valid codes in this ValueSet */
export type EncounterSpecialCourtesyCode = "EXT" | "NRM" | "PRF" | "STF" | "VIP" | "UNK";
/** Type representing a concept from this ValueSet */
export type EncounterSpecialCourtesyConcept = typeof EncounterSpecialCourtesyConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidEncounterSpecialCourtesyCode(code: string): code is EncounterSpecialCourtesyCode;
/**
 * Get concept details by code
 */
export declare function getEncounterSpecialCourtesyConcept(code: string): EncounterSpecialCourtesyConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const EncounterSpecialCourtesyCodes: ("UNK" | "EXT" | "NRM" | "PRF" | "STF" | "VIP")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomEncounterSpecialCourtesyCode(): EncounterSpecialCourtesyCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomEncounterSpecialCourtesyConcept(): EncounterSpecialCourtesyConcept;
