/**
 * ValueSet: ExampleVisionPrescriptionProductCodes
 * URL: http://hl7.org/fhir/ValueSet/vision-product
 * Size: 2 concepts
 */
export const ExampleVisionPrescriptionProductCodesConcepts = [
    { code: "lens", system: "http://terminology.hl7.org/CodeSystem/ex-visionprescriptionproduct", display: "Lens" },
    { code: "contact", system: "http://terminology.hl7.org/CodeSystem/ex-visionprescriptionproduct", display: "Contact Lens" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidExampleVisionPrescriptionProductCodesCode(code) {
    return ExampleVisionPrescriptionProductCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getExampleVisionPrescriptionProductCodesConcept(code) {
    return ExampleVisionPrescriptionProductCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ExampleVisionPrescriptionProductCodesCodes = ExampleVisionPrescriptionProductCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomExampleVisionPrescriptionProductCodesCode() {
    return ExampleVisionPrescriptionProductCodesCodes[Math.floor(Math.random() * ExampleVisionPrescriptionProductCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomExampleVisionPrescriptionProductCodesConcept() {
    return ExampleVisionPrescriptionProductCodesConcepts[Math.floor(Math.random() * ExampleVisionPrescriptionProductCodesConcepts.length)];
}
