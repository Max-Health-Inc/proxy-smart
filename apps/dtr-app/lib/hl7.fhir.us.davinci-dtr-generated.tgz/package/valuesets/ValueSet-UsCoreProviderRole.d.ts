/**
 * ValueSet: us-core-provider-role
 * URL: http://hl7.org/fhir/us/core/ValueSet/us-core-provider-role
 * Size: 237 concepts
 */
interface UsCoreProviderRoleConceptDef {
    readonly code: string;
    readonly system: string;
    readonly display?: string;
}
export declare const UsCoreProviderRoleConcepts: readonly UsCoreProviderRoleConceptDef[];
/** String type (ValueSet too large for union type) */
export type UsCoreProviderRoleCode = string;
/** Type representing a concept from this ValueSet */
export type UsCoreProviderRoleConcept = UsCoreProviderRoleConceptDef;
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidUsCoreProviderRoleCode(code: string): code is UsCoreProviderRoleCode;
/**
 * Get concept details by code
 */
export declare function getUsCoreProviderRoleConcept(code: string): UsCoreProviderRoleConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const UsCoreProviderRoleCodes: string[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomUsCoreProviderRoleCode(): UsCoreProviderRoleCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomUsCoreProviderRoleConcept(): UsCoreProviderRoleConcept;
export {};
