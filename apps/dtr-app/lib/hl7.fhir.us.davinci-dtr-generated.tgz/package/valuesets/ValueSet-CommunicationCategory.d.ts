/**
 * ValueSet: communication-category
 * URL: http://hl7.org/fhir/ValueSet/communication-category
 * Size: 4 concepts
 */
export declare const CommunicationCategoryConcepts: readonly [{
    readonly code: "alert";
    readonly system: "http://terminology.hl7.org/CodeSystem/communication-category";
}, {
    readonly code: "notification";
    readonly system: "http://terminology.hl7.org/CodeSystem/communication-category";
}, {
    readonly code: "reminder";
    readonly system: "http://terminology.hl7.org/CodeSystem/communication-category";
}, {
    readonly code: "instruction";
    readonly system: "http://terminology.hl7.org/CodeSystem/communication-category";
}];
/** Union type of all valid codes in this ValueSet */
export type CommunicationCategoryCode = "alert" | "notification" | "reminder" | "instruction";
/** Type representing a concept from this ValueSet */
export type CommunicationCategoryConcept = typeof CommunicationCategoryConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidCommunicationCategoryCode(code: string): code is CommunicationCategoryCode;
/**
 * Get concept details by code
 */
export declare function getCommunicationCategoryConcept(code: string): CommunicationCategoryConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const CommunicationCategoryCodes: ("alert" | "notification" | "reminder" | "instruction")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomCommunicationCategoryCode(): CommunicationCategoryCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomCommunicationCategoryConcept(): CommunicationCategoryConcept;
