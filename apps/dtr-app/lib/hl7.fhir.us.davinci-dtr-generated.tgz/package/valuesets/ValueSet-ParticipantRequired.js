/**
 * ValueSet: ParticipantRequired
 * URL: http://hl7.org/fhir/ValueSet/participantrequired
 * Size: 3 concepts
 */
export const ParticipantRequiredConcepts = [
    { code: "required", system: "http://hl7.org/fhir/participantrequired", display: "Required" },
    { code: "optional", system: "http://hl7.org/fhir/participantrequired", display: "Optional" },
    { code: "information-only", system: "http://hl7.org/fhir/participantrequired", display: "Information Only" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidParticipantRequiredCode(code) {
    return ParticipantRequiredConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getParticipantRequiredConcept(code) {
    return ParticipantRequiredConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ParticipantRequiredCodes = ParticipantRequiredConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomParticipantRequiredCode() {
    return ParticipantRequiredCodes[Math.floor(Math.random() * ParticipantRequiredCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomParticipantRequiredConcept() {
    return ParticipantRequiredConcepts[Math.floor(Math.random() * ParticipantRequiredConcepts.length)];
}
