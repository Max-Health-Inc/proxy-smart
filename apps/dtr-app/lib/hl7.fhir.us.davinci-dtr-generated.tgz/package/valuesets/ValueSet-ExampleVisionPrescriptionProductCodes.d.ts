/**
 * ValueSet: ExampleVisionPrescriptionProductCodes
 * URL: http://hl7.org/fhir/ValueSet/vision-product
 * Size: 2 concepts
 */
export declare const ExampleVisionPrescriptionProductCodesConcepts: readonly [{
    readonly code: "lens";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-visionprescriptionproduct";
    readonly display: "Lens";
}, {
    readonly code: "contact";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-visionprescriptionproduct";
    readonly display: "Contact Lens";
}];
/** Union type of all valid codes in this ValueSet */
export type ExampleVisionPrescriptionProductCodesCode = "lens" | "contact";
/** Type representing a concept from this ValueSet */
export type ExampleVisionPrescriptionProductCodesConcept = typeof ExampleVisionPrescriptionProductCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidExampleVisionPrescriptionProductCodesCode(code: string): code is ExampleVisionPrescriptionProductCodesCode;
/**
 * Get concept details by code
 */
export declare function getExampleVisionPrescriptionProductCodesConcept(code: string): ExampleVisionPrescriptionProductCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ExampleVisionPrescriptionProductCodesCodes: ("contact" | "lens")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomExampleVisionPrescriptionProductCodesCode(): ExampleVisionPrescriptionProductCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomExampleVisionPrescriptionProductCodesConcept(): ExampleVisionPrescriptionProductCodesConcept;
