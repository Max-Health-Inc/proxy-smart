/**
 * ValueSet: AppointmentCancellationReason
 * URL: http://hl7.org/fhir/ValueSet/appointment-cancellation-reason
 * Size: 5 concepts
 */
export declare const AppointmentCancellationReasonConcepts: readonly [{
    readonly code: "pat";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
    readonly display: "Patient";
}, {
    readonly code: "prov";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
    readonly display: "Provider";
}, {
    readonly code: "maint";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
    readonly display: "Equipment Maintenance/Repair";
}, {
    readonly code: "meds-inc";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
    readonly display: "Prep/Med Incomplete";
}, {
    readonly code: "other";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
    readonly display: "Other";
}];
/** Union type of all valid codes in this ValueSet */
export type AppointmentCancellationReasonCode = "pat" | "prov" | "maint" | "meds-inc" | "other";
/** Type representing a concept from this ValueSet */
export type AppointmentCancellationReasonConcept = typeof AppointmentCancellationReasonConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidAppointmentCancellationReasonCode(code: string): code is AppointmentCancellationReasonCode;
/**
 * Get concept details by code
 */
export declare function getAppointmentCancellationReasonConcept(code: string): AppointmentCancellationReasonConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const AppointmentCancellationReasonCodes: ("other" | "pat" | "prov" | "maint" | "meds-inc")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomAppointmentCancellationReasonCode(): AppointmentCancellationReasonCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomAppointmentCancellationReasonConcept(): AppointmentCancellationReasonConcept;
