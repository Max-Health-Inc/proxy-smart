/**
 * ValueSet: appointment-cancellation-reason
 * URL: http://hl7.org/fhir/ValueSet/appointment-cancellation-reason
 * Size: 32 concepts
 */
export declare const AppointmentCancellationReasonConcepts: readonly [{
    readonly code: "pat";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
}, {
    readonly code: "pat-crs";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
}, {
    readonly code: "pat-cpp";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
}, {
    readonly code: "pat-dec";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
}, {
    readonly code: "pat-fb";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
}, {
    readonly code: "pat-lt";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
}, {
    readonly code: "pat-mt";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
}, {
    readonly code: "pat-mv";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
}, {
    readonly code: "pat-preg";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
}, {
    readonly code: "pat-swl";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
}, {
    readonly code: "pat-ucp";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
}, {
    readonly code: "prov";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
}, {
    readonly code: "prov-pers";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
}, {
    readonly code: "prov-dch";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
}, {
    readonly code: "prov-edu";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
}, {
    readonly code: "prov-hosp";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
}, {
    readonly code: "prov-labs";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
}, {
    readonly code: "prov-mri";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
}, {
    readonly code: "prov-onc";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
}, {
    readonly code: "maint";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
}, {
    readonly code: "meds-inc";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
}, {
    readonly code: "other";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
}, {
    readonly code: "oth-cms";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
}, {
    readonly code: "oth-err";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
}, {
    readonly code: "oth-fin";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
}, {
    readonly code: "oth-iv";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
}, {
    readonly code: "oth-int";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
}, {
    readonly code: "oth-mu";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
}, {
    readonly code: "oth-room";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
}, {
    readonly code: "oth-oerr";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
}, {
    readonly code: "oth-swie";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
}, {
    readonly code: "oth-weath";
    readonly system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason";
}];
/** String type (ValueSet too large for union type) */
export type AppointmentCancellationReasonCode = string;
/** Type representing a concept from this ValueSet */
export type AppointmentCancellationReasonConcept = typeof AppointmentCancellationReasonConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidAppointmentCancellationReasonCode(code: string): code is AppointmentCancellationReasonCode;
/**
 * Get concept details by code
 */
export declare function getAppointmentCancellationReasonConcept(code: string): AppointmentCancellationReasonConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const AppointmentCancellationReasonCodes: ("other" | "pat" | "pat-crs" | "pat-cpp" | "pat-dec" | "pat-fb" | "pat-lt" | "pat-mt" | "pat-mv" | "pat-preg" | "pat-swl" | "pat-ucp" | "prov" | "prov-pers" | "prov-dch" | "prov-edu" | "prov-hosp" | "prov-labs" | "prov-mri" | "prov-onc" | "maint" | "meds-inc" | "oth-cms" | "oth-err" | "oth-fin" | "oth-iv" | "oth-int" | "oth-mu" | "oth-room" | "oth-oerr" | "oth-swie" | "oth-weath")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomAppointmentCancellationReasonCode(): AppointmentCancellationReasonCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomAppointmentCancellationReasonConcept(): AppointmentCancellationReasonConcept;
