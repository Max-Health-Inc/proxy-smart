/**
 * ValueSet: fm-status
 * URL: http://hl7.org/fhir/ValueSet/fm-status
 * Size: 4 concepts
 */
export declare const FmStatusConcepts: readonly [{
    readonly code: "active";
    readonly system: "http://hl7.org/fhir/fm-status";
}, {
    readonly code: "cancelled";
    readonly system: "http://hl7.org/fhir/fm-status";
}, {
    readonly code: "draft";
    readonly system: "http://hl7.org/fhir/fm-status";
}, {
    readonly code: "entered-in-error";
    readonly system: "http://hl7.org/fhir/fm-status";
}];
/** Union type of all valid codes in this ValueSet */
export type FmStatusCode = "active" | "cancelled" | "draft" | "entered-in-error";
/** Type representing a concept from this ValueSet */
export type FmStatusConcept = typeof FmStatusConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidFmStatusCode(code: string): code is FmStatusCode;
/**
 * Get concept details by code
 */
export declare function getFmStatusConcept(code: string): FmStatusConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const FmStatusCodes: ("active" | "entered-in-error" | "draft" | "cancelled")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomFmStatusCode(): FmStatusCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomFmStatusConcept(): FmStatusConcept;
