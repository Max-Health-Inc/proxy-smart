/**
 * ValueSet: ParticipantRequired
 * URL: http://hl7.org/fhir/ValueSet/participantrequired
 * Size: 3 concepts
 */
export declare const ParticipantRequiredConcepts: readonly [{
    readonly code: "required";
    readonly system: "http://hl7.org/fhir/participantrequired";
    readonly display: "Required";
}, {
    readonly code: "optional";
    readonly system: "http://hl7.org/fhir/participantrequired";
    readonly display: "Optional";
}, {
    readonly code: "information-only";
    readonly system: "http://hl7.org/fhir/participantrequired";
    readonly display: "Information Only";
}];
/** Union type of all valid codes in this ValueSet */
export type ParticipantRequiredCode = "required" | "optional" | "information-only";
/** Type representing a concept from this ValueSet */
export type ParticipantRequiredConcept = typeof ParticipantRequiredConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidParticipantRequiredCode(code: string): code is ParticipantRequiredCode;
/**
 * Get concept details by code
 */
export declare function getParticipantRequiredConcept(code: string): ParticipantRequiredConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ParticipantRequiredCodes: ("required" | "optional" | "information-only")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomParticipantRequiredCode(): ParticipantRequiredCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomParticipantRequiredConcept(): ParticipantRequiredConcept;
