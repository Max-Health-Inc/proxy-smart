/**
 * ValueSet: publication-status
 * URL: http://hl7.org/fhir/ValueSet/publication-status
 * Size: 4 concepts
 */
export const PublicationStatusConcepts = [
    { code: "draft", system: "http://hl7.org/fhir/publication-status" },
    { code: "active", system: "http://hl7.org/fhir/publication-status" },
    { code: "retired", system: "http://hl7.org/fhir/publication-status" },
    { code: "unknown", system: "http://hl7.org/fhir/publication-status" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidPublicationStatusCode(code) {
    return PublicationStatusConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getPublicationStatusConcept(code) {
    return PublicationStatusConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const PublicationStatusCodes = PublicationStatusConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomPublicationStatusCode() {
    return PublicationStatusCodes[Math.floor(Math.random() * PublicationStatusCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomPublicationStatusConcept() {
    return PublicationStatusConcepts[Math.floor(Math.random() * PublicationStatusConcepts.length)];
}
