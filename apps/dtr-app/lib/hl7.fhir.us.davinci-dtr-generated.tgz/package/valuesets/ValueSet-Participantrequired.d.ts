/**
 * ValueSet: participantrequired
 * URL: http://hl7.org/fhir/ValueSet/participantrequired
 * Size: 3 concepts
 */
export declare const ParticipantrequiredConcepts: readonly [{
    readonly code: "required";
    readonly system: "http://hl7.org/fhir/participantrequired";
}, {
    readonly code: "optional";
    readonly system: "http://hl7.org/fhir/participantrequired";
}, {
    readonly code: "information-only";
    readonly system: "http://hl7.org/fhir/participantrequired";
}];
/** Union type of all valid codes in this ValueSet */
export type ParticipantrequiredCode = "required" | "optional" | "information-only";
/** Type representing a concept from this ValueSet */
export type ParticipantrequiredConcept = typeof ParticipantrequiredConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidParticipantrequiredCode(code: string): code is ParticipantrequiredCode;
/**
 * Get concept details by code
 */
export declare function getParticipantrequiredConcept(code: string): ParticipantrequiredConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ParticipantrequiredCodes: ("required" | "optional" | "information-only")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomParticipantrequiredCode(): ParticipantrequiredCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomParticipantrequiredConcept(): ParticipantrequiredConcept;
