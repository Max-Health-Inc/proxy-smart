/**
 * ValueSet: publication-status
 * URL: http://hl7.org/fhir/ValueSet/publication-status
 * Size: 4 concepts
 */
export declare const PublicationStatusConcepts: readonly [{
    readonly code: "draft";
    readonly system: "http://hl7.org/fhir/publication-status";
}, {
    readonly code: "active";
    readonly system: "http://hl7.org/fhir/publication-status";
}, {
    readonly code: "retired";
    readonly system: "http://hl7.org/fhir/publication-status";
}, {
    readonly code: "unknown";
    readonly system: "http://hl7.org/fhir/publication-status";
}];
/** Union type of all valid codes in this ValueSet */
export type PublicationStatusCode = "draft" | "active" | "retired" | "unknown";
/** Type representing a concept from this ValueSet */
export type PublicationStatusConcept = typeof PublicationStatusConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidPublicationStatusCode(code: string): code is PublicationStatusCode;
/**
 * Get concept details by code
 */
export declare function getPublicationStatusConcept(code: string): PublicationStatusConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const PublicationStatusCodes: ("active" | "unknown" | "draft" | "retired")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomPublicationStatusCode(): PublicationStatusCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomPublicationStatusConcept(): PublicationStatusConcept;
