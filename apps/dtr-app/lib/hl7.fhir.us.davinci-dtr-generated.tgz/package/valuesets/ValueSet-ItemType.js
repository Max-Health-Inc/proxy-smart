/**
 * ValueSet: item-type
 * URL: http://hl7.org/fhir/ValueSet/item-type
 * Size: 17 concepts
 */
export const ItemTypeConcepts = [
    { code: "group", system: "http://hl7.org/fhir/item-type" },
    { code: "display", system: "http://hl7.org/fhir/item-type" },
    { code: "question", system: "http://hl7.org/fhir/item-type" },
    { code: "boolean", system: "http://hl7.org/fhir/item-type" },
    { code: "decimal", system: "http://hl7.org/fhir/item-type" },
    { code: "integer", system: "http://hl7.org/fhir/item-type" },
    { code: "date", system: "http://hl7.org/fhir/item-type" },
    { code: "dateTime", system: "http://hl7.org/fhir/item-type" },
    { code: "time", system: "http://hl7.org/fhir/item-type" },
    { code: "string", system: "http://hl7.org/fhir/item-type" },
    { code: "text", system: "http://hl7.org/fhir/item-type" },
    { code: "url", system: "http://hl7.org/fhir/item-type" },
    { code: "choice", system: "http://hl7.org/fhir/item-type" },
    { code: "open-choice", system: "http://hl7.org/fhir/item-type" },
    { code: "attachment", system: "http://hl7.org/fhir/item-type" },
    { code: "reference", system: "http://hl7.org/fhir/item-type" },
    { code: "quantity", system: "http://hl7.org/fhir/item-type" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidItemTypeCode(code) {
    return ItemTypeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getItemTypeConcept(code) {
    return ItemTypeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ItemTypeCodes = ItemTypeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomItemTypeCode() {
    return ItemTypeCodes[Math.floor(Math.random() * ItemTypeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomItemTypeConcept() {
    return ItemTypeConcepts[Math.floor(Math.random() * ItemTypeConcepts.length)];
}
