/**
 * ValueSet: MetricSource
 * URL: http://hl7.org/fhir/us/davinci-dtr/ValueSet/metric-Source
 * Size: 3 concepts
 */
export declare const MetricSourceConcepts: readonly [{
    readonly code: "payer-src";
    readonly system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp";
}, {
    readonly code: "provider-src";
    readonly system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp";
}, {
    readonly code: "DTRApp-src";
    readonly system: "http://hl7.org/fhir/us/davinci-dtr/CodeSystem/temp";
}];
/** Union type of all valid codes in this ValueSet */
export type MetricSourceCode = "payer-src" | "provider-src" | "DTRApp-src";
/** Type representing a concept from this ValueSet */
export type MetricSourceConcept = typeof MetricSourceConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidMetricSourceCode(code: string): code is MetricSourceCode;
/**
 * Get concept details by code
 */
export declare function getMetricSourceConcept(code: string): MetricSourceConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const MetricSourceCodes: ("payer-src" | "provider-src" | "DTRApp-src")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomMetricSourceCode(): MetricSourceCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomMetricSourceConcept(): MetricSourceConcept;
