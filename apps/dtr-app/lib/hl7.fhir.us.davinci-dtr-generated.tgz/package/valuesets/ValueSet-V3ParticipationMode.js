/**
 * ValueSet: v3-ParticipationMode
 * URL: http://terminology.hl7.org/ValueSet/v3-ParticipationMode
 * Size: 2 concepts
 */
export const V3ParticipationModeConcepts = [
    { code: "PHYSICAL", system: "http://terminology.hl7.org/CodeSystem/v3-ParticipationMode" },
    { code: "REMOTE", system: "http://terminology.hl7.org/CodeSystem/v3-ParticipationMode" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidV3ParticipationModeCode(code) {
    return V3ParticipationModeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getV3ParticipationModeConcept(code) {
    return V3ParticipationModeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const V3ParticipationModeCodes = V3ParticipationModeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomV3ParticipationModeCode() {
    return V3ParticipationModeCodes[Math.floor(Math.random() * V3ParticipationModeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomV3ParticipationModeConcept() {
    return V3ParticipationModeConcepts[Math.floor(Math.random() * V3ParticipationModeConcepts.length)];
}
