/**
 * ValueSet: DischargeDisposition
 * URL: http://hl7.org/fhir/ValueSet/encounter-discharge-disposition
 * Size: 11 concepts
 */
export declare const DischargeDispositionConcepts: readonly [{
    readonly code: "home";
    readonly system: "http://terminology.hl7.org/CodeSystem/discharge-disposition";
    readonly display: "Home";
}, {
    readonly code: "alt-home";
    readonly system: "http://terminology.hl7.org/CodeSystem/discharge-disposition";
    readonly display: "Alternative home";
}, {
    readonly code: "other-hcf";
    readonly system: "http://terminology.hl7.org/CodeSystem/discharge-disposition";
    readonly display: "Other healthcare facility";
}, {
    readonly code: "hosp";
    readonly system: "http://terminology.hl7.org/CodeSystem/discharge-disposition";
    readonly display: "Hospice";
}, {
    readonly code: "long";
    readonly system: "http://terminology.hl7.org/CodeSystem/discharge-disposition";
    readonly display: "Long-term care";
}, {
    readonly code: "aadvice";
    readonly system: "http://terminology.hl7.org/CodeSystem/discharge-disposition";
    readonly display: "Left against advice";
}, {
    readonly code: "exp";
    readonly system: "http://terminology.hl7.org/CodeSystem/discharge-disposition";
    readonly display: "Expired";
}, {
    readonly code: "psy";
    readonly system: "http://terminology.hl7.org/CodeSystem/discharge-disposition";
    readonly display: "Psychiatric hospital";
}, {
    readonly code: "rehab";
    readonly system: "http://terminology.hl7.org/CodeSystem/discharge-disposition";
    readonly display: "Rehabilitation";
}, {
    readonly code: "snf";
    readonly system: "http://terminology.hl7.org/CodeSystem/discharge-disposition";
    readonly display: "Skilled nursing facility";
}, {
    readonly code: "oth";
    readonly system: "http://terminology.hl7.org/CodeSystem/discharge-disposition";
    readonly display: "Other";
}];
/** Union type of all valid codes in this ValueSet */
export type DischargeDispositionCode = "home" | "alt-home" | "other-hcf" | "hosp" | "long" | "aadvice" | "exp" | "psy" | "rehab" | "snf" | "oth";
/** Type representing a concept from this ValueSet */
export type DischargeDispositionConcept = typeof DischargeDispositionConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidDischargeDispositionCode(code: string): code is DischargeDispositionCode;
/**
 * Get concept details by code
 */
export declare function getDischargeDispositionConcept(code: string): DischargeDispositionConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const DischargeDispositionCodes: ("rehab" | "home" | "alt-home" | "other-hcf" | "hosp" | "long" | "aadvice" | "exp" | "psy" | "snf" | "oth")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomDischargeDispositionCode(): DischargeDispositionCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomDischargeDispositionConcept(): DischargeDispositionConcept;
