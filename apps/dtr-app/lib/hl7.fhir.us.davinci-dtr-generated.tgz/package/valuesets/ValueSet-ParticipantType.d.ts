/**
 * ValueSet: ParticipantType
 * URL: http://hl7.org/fhir/ValueSet/encounter-participant-type
 * Size: Infinity concepts
 */
export declare const ParticipantTypeConcepts: readonly [{
    readonly code: "SPRF";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ParticipationType";
}, {
    readonly code: "PPRF";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ParticipationType";
}, {
    readonly code: "PART";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ParticipationType";
}];
/** String type (ValueSet too large for union type) */
export type ParticipantTypeCode = string;
/** Type representing a concept from this ValueSet */
export type ParticipantTypeConcept = typeof ParticipantTypeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidParticipantTypeCode(code: string): code is ParticipantTypeCode;
/**
 * Get concept details by code
 */
export declare function getParticipantTypeConcept(code: string): ParticipantTypeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ParticipantTypeCodes: ("SPRF" | "PPRF" | "PART")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomParticipantTypeCode(): ParticipantTypeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomParticipantTypeConcept(): ParticipantTypeConcept;
