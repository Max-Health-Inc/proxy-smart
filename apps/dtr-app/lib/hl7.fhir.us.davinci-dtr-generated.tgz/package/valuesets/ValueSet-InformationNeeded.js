/**
 * ValueSet: informationNeeded
 * URL: http://hl7.org/fhir/us/davinci-crd/ValueSet/informationNeeded
 * Size: 5 concepts
 */
export const InformationNeededConcepts = [
    { code: "performer", system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp" },
    { code: "location", system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp" },
    { code: "timeframe", system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp" },
    { code: "contract-window", system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp" },
    { code: "OTH", system: "http://terminology.hl7.org/CodeSystem/v3-NullFlavor" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidInformationNeededCode(code) {
    return InformationNeededConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getInformationNeededConcept(code) {
    return InformationNeededConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const InformationNeededCodes = InformationNeededConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomInformationNeededCode() {
    return InformationNeededCodes[Math.floor(Math.random() * InformationNeededCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomInformationNeededConcept() {
    return InformationNeededConcepts[Math.floor(Math.random() * InformationNeededConcepts.length)];
}
