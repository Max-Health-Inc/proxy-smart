/**
 * ValueSet: DocReason
 * URL: http://hl7.org/fhir/us/davinci-crd/ValueSet/DocReason
 * Size: 5 concepts
 */
export declare const DocReasonConcepts: readonly [{
    readonly code: "withpa";
    readonly system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp";
}, {
    readonly code: "withclaim";
    readonly system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp";
}, {
    readonly code: "withorder";
    readonly system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp";
}, {
    readonly code: "retain-doc";
    readonly system: "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp";
}, {
    readonly code: "OTH";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-NullFlavor";
}];
/** Union type of all valid codes in this ValueSet */
export type DocReasonCode = "withpa" | "withclaim" | "withorder" | "retain-doc" | "OTH";
/** Type representing a concept from this ValueSet */
export type DocReasonConcept = typeof DocReasonConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidDocReasonCode(code: string): code is DocReasonCode;
/**
 * Get concept details by code
 */
export declare function getDocReasonConcept(code: string): DocReasonConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const DocReasonCodes: ("OTH" | "withpa" | "withclaim" | "withorder" | "retain-doc")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomDocReasonCode(): DocReasonCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomDocReasonConcept(): DocReasonConcept;
