/**
 * ValueSet: appointment-cancellation-reason
 * URL: http://hl7.org/fhir/ValueSet/appointment-cancellation-reason
 * Size: 32 concepts
 */
export const AppointmentCancellationReasonConcepts = [
    { code: "pat", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason" },
    { code: "pat-crs", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason" },
    { code: "pat-cpp", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason" },
    { code: "pat-dec", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason" },
    { code: "pat-fb", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason" },
    { code: "pat-lt", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason" },
    { code: "pat-mt", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason" },
    { code: "pat-mv", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason" },
    { code: "pat-preg", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason" },
    { code: "pat-swl", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason" },
    { code: "pat-ucp", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason" },
    { code: "prov", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason" },
    { code: "prov-pers", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason" },
    { code: "prov-dch", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason" },
    { code: "prov-edu", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason" },
    { code: "prov-hosp", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason" },
    { code: "prov-labs", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason" },
    { code: "prov-mri", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason" },
    { code: "prov-onc", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason" },
    { code: "maint", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason" },
    { code: "meds-inc", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason" },
    { code: "other", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason" },
    { code: "oth-cms", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason" },
    { code: "oth-err", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason" },
    { code: "oth-fin", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason" },
    { code: "oth-iv", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason" },
    { code: "oth-int", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason" },
    { code: "oth-mu", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason" },
    { code: "oth-room", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason" },
    { code: "oth-oerr", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason" },
    { code: "oth-swie", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason" },
    { code: "oth-weath", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidAppointmentCancellationReasonCode(code) {
    return AppointmentCancellationReasonConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getAppointmentCancellationReasonConcept(code) {
    return AppointmentCancellationReasonConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const AppointmentCancellationReasonCodes = AppointmentCancellationReasonConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomAppointmentCancellationReasonCode() {
    return AppointmentCancellationReasonCodes[Math.floor(Math.random() * AppointmentCancellationReasonCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomAppointmentCancellationReasonConcept() {
    return AppointmentCancellationReasonConcepts[Math.floor(Math.random() * AppointmentCancellationReasonConcepts.length)];
}
