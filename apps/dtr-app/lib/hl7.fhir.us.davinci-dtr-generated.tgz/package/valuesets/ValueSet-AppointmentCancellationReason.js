/**
 * ValueSet: AppointmentCancellationReason
 * URL: http://hl7.org/fhir/ValueSet/appointment-cancellation-reason
 * Size: 5 concepts
 */
export const AppointmentCancellationReasonConcepts = [
    { code: "pat", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason", display: "Patient" },
    { code: "prov", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason", display: "Provider" },
    { code: "maint", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason", display: "Equipment Maintenance/Repair" },
    { code: "meds-inc", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason", display: "Prep/Med Incomplete" },
    { code: "other", system: "http://terminology.hl7.org/CodeSystem/appointment-cancellation-reason", display: "Other" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidAppointmentCancellationReasonCode(code) {
    return AppointmentCancellationReasonConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getAppointmentCancellationReasonConcept(code) {
    return AppointmentCancellationReasonConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const AppointmentCancellationReasonCodes = AppointmentCancellationReasonConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomAppointmentCancellationReasonCode() {
    return AppointmentCancellationReasonCodes[Math.floor(Math.random() * AppointmentCancellationReasonCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomAppointmentCancellationReasonConcept() {
    return AppointmentCancellationReasonConcepts[Math.floor(Math.random() * AppointmentCancellationReasonConcepts.length)];
}
