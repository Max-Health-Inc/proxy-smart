/**
 * ValueSet: entryMode
 * URL: http://hl7.org/fhir/uv/sdc/ValueSet/entryMode
 * Size: 3 concepts
 */
export declare const EntryModeConcepts: readonly [{
    readonly code: "sequential";
    readonly system: "http://hl7.org/fhir/uv/sdc/CodeSystem/entryMode";
}, {
    readonly code: "prior-edit";
    readonly system: "http://hl7.org/fhir/uv/sdc/CodeSystem/entryMode";
}, {
    readonly code: "random";
    readonly system: "http://hl7.org/fhir/uv/sdc/CodeSystem/entryMode";
}];
/** Union type of all valid codes in this ValueSet */
export type EntryModeCode = "sequential" | "prior-edit" | "random";
/** Type representing a concept from this ValueSet */
export type EntryModeConcept = typeof EntryModeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidEntryModeCode(code: string): code is EntryModeCode;
/**
 * Get concept details by code
 */
export declare function getEntryModeConcept(code: string): EntryModeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const EntryModeCodes: ("sequential" | "prior-edit" | "random")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomEntryModeCode(): EntryModeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomEntryModeConcept(): EntryModeConcept;
