/**
 * ValueSet: v3-ActReason
 * URL: http://terminology.hl7.org/ValueSet/v3-ActReason
 * Size: 295 concepts
 */
interface V3ActReasonConceptDef {
    readonly code: string;
    readonly system: string;
    readonly display?: string;
}
export declare const V3ActReasonConcepts: readonly V3ActReasonConceptDef[];
/** String type (ValueSet too large for union type) */
export type V3ActReasonCode = string;
/** Type representing a concept from this ValueSet */
export type V3ActReasonConcept = V3ActReasonConceptDef;
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidV3ActReasonCode(code: string): code is V3ActReasonCode;
/**
 * Get concept details by code
 */
export declare function getV3ActReasonConcept(code: string): V3ActReasonConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const V3ActReasonCodes: string[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomV3ActReasonCode(): V3ActReasonCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomV3ActReasonConcept(): V3ActReasonConcept;
export {};
