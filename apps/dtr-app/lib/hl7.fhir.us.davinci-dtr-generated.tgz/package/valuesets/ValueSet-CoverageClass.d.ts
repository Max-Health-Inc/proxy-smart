/**
 * ValueSet: coverage-class
 * URL: http://hl7.org/fhir/ValueSet/coverage-class
 * Size: 11 concepts
 */
export declare const CoverageClassConcepts: readonly [{
    readonly code: "group";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-class";
}, {
    readonly code: "subgroup";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-class";
}, {
    readonly code: "plan";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-class";
}, {
    readonly code: "subplan";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-class";
}, {
    readonly code: "class";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-class";
}, {
    readonly code: "subclass";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-class";
}, {
    readonly code: "sequence";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-class";
}, {
    readonly code: "rxbin";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-class";
}, {
    readonly code: "rxpcn";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-class";
}, {
    readonly code: "rxid";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-class";
}, {
    readonly code: "rxgroup";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-class";
}];
/** Union type of all valid codes in this ValueSet */
export type CoverageClassCode = "group" | "subgroup" | "plan" | "subplan" | "class" | "subclass" | "sequence" | "rxbin" | "rxpcn" | "rxid" | "rxgroup";
/** Type representing a concept from this ValueSet */
export type CoverageClassConcept = typeof CoverageClassConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidCoverageClassCode(code: string): code is CoverageClassCode;
/**
 * Get concept details by code
 */
export declare function getCoverageClassConcept(code: string): CoverageClassConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const CoverageClassCodes: ("class" | "group" | "plan" | "subgroup" | "subplan" | "subclass" | "sequence" | "rxbin" | "rxpcn" | "rxid" | "rxgroup")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomCoverageClassCode(): CoverageClassCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomCoverageClassConcept(): CoverageClassConcept;
