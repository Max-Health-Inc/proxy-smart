import { Extension } from "fhir/r4";
export interface ReferenceProfile extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/StructureDefinition/questionnaire-referenceProfile";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateReferenceProfile(resource: ReferenceProfile, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
