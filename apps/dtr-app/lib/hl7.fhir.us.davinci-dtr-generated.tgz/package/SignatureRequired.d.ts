import { CodeableConcept, Extension } from "fhir/r4";
export interface SignatureRequired extends Omit<Extension, 'url' | 'value'> {
    url: "http://hl7.org/fhir/StructureDefinition/questionnaire-signatureRequired";
    value: CodeableConcept;
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateSignatureRequired(resource: SignatureRequired, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
