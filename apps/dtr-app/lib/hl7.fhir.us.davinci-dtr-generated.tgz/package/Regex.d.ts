import { Extension } from "fhir/r4";
export interface Regex extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/StructureDefinition/regex";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateRegex(resource: Regex, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
