import { AssembleExpectation } from "./AssembleExpectation";
import { CandidateExpressionExtension } from "./CandidateExpressionExtension";
import { ChoiceColumnExtension } from "./ChoiceColumnExtension";
import { ChoiceOrientation } from "./ChoiceOrientation";
import { CollapsibleExtension } from "./CollapsibleExtension";
import { ContextExpressionExtension } from "./ContextExpressionExtension";
import { ExpressionExtension } from "./ExpressionExtension";
import { DesignNote } from "./DesignNote";
import { DisplayCategory } from "./DisplayCategory";
import { EntryFormat } from "./EntryFormat";
import { EntryMode } from "./EntryMode";
import { Hidden } from "./Hidden";
import { InitialExpressionExtension } from "./InitialExpressionExtension";
import { ItemAnswerMedia } from "./ItemAnswerMedia";
import { ItemControl } from "./ItemControl";
import { ItemMedia } from "./ItemMedia";
import { ItemPopulationContextExtension } from "./ItemPopulationContextExtension";
import { LibraryExtension } from "./LibraryExtension";
import { MaxDecimalPlaces } from "./MaxDecimalPlaces";
import { MaxSize } from "./MaxSize";
import { MaxValue } from "./MaxValue";
import { MimeType } from "./MimeType";
import { MinLength } from "./MinLength";
import { MinValue } from "./MinValue";
import { OptionalDisplayExtension } from "./OptionalDisplayExtension";
import { OrdinalValue } from "./OrdinalValue";
import { PerformerTypeExtension } from "./PerformerTypeExtension";
import { PreferredTerminologyServer } from "./PreferredTerminologyServer";
import { MaxOccurs } from "./MaxOccurs";
import { MinOccurs } from "./MinOccurs";
import { OptionExclusive } from "./OptionExclusive";
import { ReferenceProfile } from "./ReferenceProfile";
import { ReferenceResource } from "./ReferenceResource";
import { UnitOption } from "./UnitOption";
import { UnitValueSet } from "./UnitValueSet";
import { UsageMode } from "./UsageMode";
import { Regex } from "./Regex";
import { SDCOpenLabel } from "./SDCOpenLabel";
import { AnswerOptionsToggleExpressionExtension } from "./AnswerOptionsToggleExpressionExtension";
import { CalculatedExpressionExtension } from "./CalculatedExpressionExtension";
import { EnableWhenExpressionExtension } from "./EnableWhenExpressionExtension";
import { EndpointExtension } from "./EndpointExtension";
import { LaunchContextExtension } from "./LaunchContextExtension";
import { LookupQuestionnaireExtension } from "./LookupQuestionnaireExtension";
import { MaxQuantityExtension } from "./MaxQuantityExtension";
import { MinQuantityExtension } from "./MinQuantityExtension";
import { ShortTextExtension } from "./ShortTextExtension";
import { SignatureRequired } from "./SignatureRequired";
import { SliderStepValue } from "./SliderStepValue";
import { Style } from "./Style";
import { StyleSensitive } from "./StyleSensitive";
import { SupportLink } from "./SupportLink";
import { TargetConstraint } from "./TargetConstraint";
import { Unit } from "./Unit";
import { Variable } from "./Variable";
import { WidthExtension } from "./WidthExtension";
import { Xhtml } from "./Xhtml";
import { BackboneElement, Element, Extension, Narrative, Period, Questionnaire, QuestionnaireItem } from "fhir/r4";
export interface DTRStdQuestionnaireTitleElement extends Omit<Element, 'extension'> {
    extension?: (Extension | Style | Xhtml)[];
}
export interface DTRStdQuestionnaire extends Omit<Questionnaire, 'text' | '_title' | 'title' | 'subjectType' | 'effectivePeriod' | 'extension' | 'item'> {
    resourceType: 'Questionnaire';
    text: Narrative;
    _title?: DTRStdQuestionnaireTitleElement;
    /** Must Support */
    title?: string;
    subjectType: ["Patient"];
    /** Must Support */
    effectivePeriod?: Period;
    extension?: (Extension | DesignNote | PreferredTerminologyServer | PerformerTypeExtension | AssembleExpectation | StyleSensitive | EntryMode | EndpointExtension | SignatureRequired | TargetConstraint | LibraryExtension | LaunchContextExtension | Variable | ItemPopulationContextExtension)[];
    item?: DTRStdQuestionnaireItem[];
}
export interface DTRStdQuestionnaireItem extends Omit<QuestionnaireItem, 'extension' | '_prefix' | '_text' | 'answerOption'> {
    extension?: (Extension | DesignNote | PreferredTerminologyServer | ItemMedia | OptionalDisplayExtension | ShortTextExtension | Hidden | SDCOpenLabel | ItemControl | ChoiceOrientation | DisplayCategory | SupportLink | ChoiceColumnExtension | WidthExtension | SliderStepValue | EntryFormat | CollapsibleExtension | UsageMode | SignatureRequired | MinOccurs | MaxOccurs | MinLength | Regex | MinValue | MaxValue | MinQuantityExtension | MaxQuantityExtension | MaxDecimalPlaces | MimeType | MaxSize | AnswerOptionsToggleExpressionExtension | UnitOption | UnitValueSet | ReferenceResource | ReferenceProfile | CandidateExpressionExtension | LookupQuestionnaireExtension | TargetConstraint | InitialExpressionExtension | CalculatedExpressionExtension | EnableWhenExpressionExtension | Unit | ContextExpressionExtension)[];
    _prefix?: DTRStdQuestionnaireItemPrefixElement;
    _text?: DTRStdQuestionnaireItemTextElement;
    answerOption: DTRStdQuestionnaireItemAnswerOption[];
}
export interface DTRStdQuestionnaireItemPrefixElement extends Omit<Element, 'extension'> {
    extension?: (Extension | Style | Xhtml)[];
}
export interface DTRStdQuestionnaireItemTextElement extends Omit<Element, 'extension'> {
    extension?: (Extension | Style | Xhtml | ExpressionExtension)[];
}
export interface DTRStdQuestionnaireItemAnswerOption extends Omit<BackboneElement, 'extension'> {
    extension?: (Extension | ItemAnswerMedia | OptionExclusive | OrdinalValue)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateDTRStdQuestionnaire(resource: DTRStdQuestionnaire, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
