import { Extension } from "fhir/r4";
export interface InitialExpressionExtension extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateInitialExpressionExtension(resource: InitialExpressionExtension, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
