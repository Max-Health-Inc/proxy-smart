import { validateDTRQuestionnaireResponse } from "./DTRQuestionnaireResponse.js";
// Only import helpers actually referenced below (dynamic based on required fields)
import { randomId, setRandomSeed, enrichResource, randomDate, skeletonReference } from "./random/index.js";
import { createRequire } from 'module';
const __require = createRequire(import.meta.url);
function ensureProfile(res, profile) {
    if (!res.meta) {
        res.meta = { profile: [profile] };
        return;
    }
    if (!res.meta.profile) {
        res.meta.profile = [profile];
        return;
    }
    if (!res.meta.profile.includes(profile)) {
        res.meta.profile = [...res.meta.profile, profile];
    }
}
// Internal helper (emitted per class file) to clone without resorting to 'any'.
function safeClone(value) {
    // Use native structuredClone if present; otherwise fallback to JSON round-trip.
    // We intentionally avoid casting through any to satisfy no-explicit-any lint rule.
    const g = globalThis;
    // Narrow globalThis to an object potentially containing structuredClone.
    if (typeof g.structuredClone === 'function') {
        return g.structuredClone(value);
    }
    return JSON.parse(JSON.stringify(value)); // best-effort deep clone
}
export class DTRQuestionnaireResponseClass {
    constructor(resource) {
        this.resource = resource;
        ensureProfile(this.resource, 'http://hl7.org/fhir/us/davinci-dtr/StructureDefinition/dtr-questionnaireresponse');
    }
    /** Validate current resource instance. */
    async validate(options) {
        return validateDTRQuestionnaireResponse(this.resource, options);
    }
    getResource() {
        return this.resource;
    }
    setResource(resource) {
        this.resource = resource;
        ensureProfile(this.resource, 'http://hl7.org/fhir/us/davinci-dtr/StructureDefinition/dtr-questionnaireresponse');
    }
    /**
     * Returns a plain JSON clone of the underlying resource ONLY if the last validation succeeded with zero errors.
     * Call validate() first; otherwise this method throws to prevent accidental use of invalid / unchecked data.
     */
    async toJSON() {
        return safeClone(this.resource);
    }
    /**
     * Create an empty instance for parity testing: for true FHIR resources, includes only resourceType; for datatypes, returns an empty object.
     * Note: meta.profile (when applicable) will be ensured by the constructor when wrapping this resource.
     */
    static empty(overrides = {}) {
        // For Resource profiles, include only resourceType. For Extension profiles, include url so the instance is minimally meaningful.
        const base = {
            resourceType: 'QuestionnaireResponse',
        };
        return { ...base, ...overrides };
    }
    /**
     * Create a minimal randomized instance of DTRQuestionnaireResponse.
     * Populates id, resourceType (if applicable) and primitive required (min>0) top-level fields with placeholders.
     */
    static random(overrides = {}, opts) {
        if (opts?.seed !== undefined) {
            // Direct call (no dynamic require) to ensure deterministic seeding works under ESM.
            setRandomSeed(opts.seed);
        }
        // Start with a Partial to avoid unsafe casting errors; we'll assert at the end.
        const base = { resourceType: 'QuestionnaireResponse', id: randomId(), extension: [{ url: "http://hl7.org/fhir/us/davinci-dtr/StructureDefinition/qr-context", valueReference: { reference: "Patient/example" } }, { url: "http://hl7.org/fhir/us/davinci-dtr/StructureDefinition/intendedUse", valueCodeableConcept: { coding: [{ "system": "http://hl7.org/fhir/us/davinci-crd/CodeSystem/temp", "code": "withpa" }] } }, { url: "http://hl7.org/fhir/StructureDefinition/questionnaireresponse-signature", valueSignature: { type: [{ system: "urn:iso-astm:E1762-95:2013", code: "1.2.840.10065.1.12.1.1" }], when: "2026-04-17T20:32:10.580Z", who: { reference: "Practitioner/example" } } }], questionnaire: 'https://babelfhir.dev/' + randomId(), status: "entered-in-error", subject: skeletonReference(), authored: randomDate(), item: [({ linkId: "Example-linkId", answer: [{ extension: [{}] }] })], };
        // Always include meta.profile with this profile's canonical URL if available & only for resource profiles
        ensureProfile(base, 'http://hl7.org/fhir/us/davinci-dtr/StructureDefinition/dtr-questionnaireresponse');
        // Enrich the base resource with common fields using centralized enrichment logic
        enrichResource(base, 'QuestionnaireResponse', 'http://hl7.org/fhir/us/davinci-dtr/StructureDefinition/dtr-questionnaireresponse', DTRQuestionnaireResponseClass._fieldPatterns, DTRQuestionnaireResponseClass._forbiddenFields, DTRQuestionnaireResponseClass.valueSetBindings, DTRQuestionnaireResponseClass._codeResolver, DTRQuestionnaireResponseClass._fieldOrder);
        // Cast through unknown to acknowledge dynamic enrichment
        return { ...base, ...overrides };
    }
    /** Convenience: returns a class instance wrapping a randomized resource. */
    static randomClass(overrides = {}, opts) {
        return new DTRQuestionnaireResponseClass(this.random(overrides, opts));
    }
}
/** Pattern constraints for profile fields (used by random() generator) */
DTRQuestionnaireResponseClass._fieldPatterns = {
    "item.answer": "75367002",
    "_refReq_item": {
        "linkId": true,
        "answer.extension": true
    }
};
/** Fields that are forbidden (max=0) in this profile - must not be generated */
DTRQuestionnaireResponseClass._forbiddenFields = ["basedOn", "partOf"];
/** FHIR element ordering for this profile's base resource (used by enrichResource for correct JSON field order) */
DTRQuestionnaireResponseClass._fieldOrder = ["id", "meta", "implicitRules", "language", "text", "contained", "extension", "modifierExtension", "identifier", "basedOn", "partOf", "questionnaire", "status", "subject", "encounter", "authored", "author", "source", "item"];
/** ValueSet bindings for coded fields - maps field name to ValueSet URL */
DTRQuestionnaireResponseClass.valueSetBindings = {
    "language": "http://hl7.org/fhir/ValueSet/languages",
    "status": "http://hl7.org/fhir/ValueSet/questionnaire-answers-status|4.0.1",
    "item.answer.value[x]": "http://hl7.org/fhir/ValueSet/questionnaire-answers"
};
/** Code resolver for ValueSet bindings - returns a random valid code from a ValueSet by URL */
DTRQuestionnaireResponseClass._codeResolver = (() => {
    // Try to load the ValueSetRegistry - it may not exist if no ValueSets were generated
    try {
        const registry = __require('./valuesets/index.js');
        if (registry && typeof registry.getRandomConceptByUrl === 'function') {
            return registry.getRandomConceptByUrl;
        }
    }
    catch { /* ValueSetRegistry not available */ }
    return undefined;
})();
