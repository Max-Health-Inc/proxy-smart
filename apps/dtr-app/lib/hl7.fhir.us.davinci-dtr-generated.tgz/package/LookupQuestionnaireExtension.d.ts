import { Extension } from "fhir/r4";
export interface LookupQuestionnaireExtension extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-lookupQuestionnaire";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateLookupQuestionnaireExtension(resource: LookupQuestionnaireExtension, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
