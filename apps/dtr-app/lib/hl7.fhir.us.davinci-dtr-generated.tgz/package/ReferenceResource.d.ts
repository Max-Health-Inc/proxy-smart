import { Extension } from "fhir/r4";
export interface ReferenceResource extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/StructureDefinition/questionnaire-referenceResource";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateReferenceResource(resource: ReferenceResource, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
