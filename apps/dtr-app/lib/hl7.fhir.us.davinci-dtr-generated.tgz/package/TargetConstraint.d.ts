import { Extension } from "fhir/r4";
export interface TargetConstraint extends Omit<Extension, 'extension' | 'url'> {
    extension: Extension[];
    url: "http://hl7.org/fhir/StructureDefinition/targetConstraint";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateTargetConstraint(resource: TargetConstraint, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
