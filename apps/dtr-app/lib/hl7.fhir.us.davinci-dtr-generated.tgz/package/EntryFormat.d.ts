import { Extension } from "fhir/r4";
export interface EntryFormat extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/StructureDefinition/entryFormat";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateEntryFormat(resource: EntryFormat, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
