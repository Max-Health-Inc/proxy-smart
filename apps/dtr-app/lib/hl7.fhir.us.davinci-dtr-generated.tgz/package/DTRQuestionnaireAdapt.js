import fhirpath from "fhirpath";
import fhirpath_model from "fhirpath/fhir-context/r4/index.js";
import { isValidPublicationStatusCode } from './valuesets/ValueSet-PublicationStatus.js';
import { isValidItemTypeCode } from './valuesets/ValueSet-ItemType.js';
export async function validateDTRQuestionnaireAdapt(resource, options) {
    const errors = [];
    const warnings = [];
    const fhirpathOptions = {
        preciseMath: true,
        traceFn: options?.traceFn ?? (() => { }),
        ...(options?.signal ? { signal: options.signal } : {}),
        ...(options?.httpHeaders ? { httpHeaders: options.httpHeaders } : {}),
        async: true,
        ...(options?.terminologyUrl ? { terminologyUrl: options.terminologyUrl } : {}),
        ...(options?.fhirServerUrl ? { fhirServerUrl: options.fhirServerUrl } : {}),
    };
    const result0 = await fhirpath.evaluate(resource, "Questionnaire.all(contained.contained.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result0.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL NOT contain nested Resources");
    }
    const result1 = await fhirpath.evaluate(resource, "Questionnaire.all(contained.where((('#'+id in (%resource.descendants().reference | %resource.descendants().as(canonical) | %resource.descendants().as(uri) | %resource.descendants().as(url))) or descendants().where(reference = '#').exists() or descendants().where(as(canonical) = '#').exists() or descendants().where(as(canonical) = '#').exists()).not()).trace('unmatched', id).empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result1.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL be referred to from elsewhere in the resource or SHALL refer to the containing resource");
    }
    const result2 = await fhirpath.evaluate(resource, "Questionnaire.all(contained.meta.versionId.empty() and contained.meta.lastUpdated.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result2.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a meta.versionId or a meta.lastUpdated");
    }
    const result3 = await fhirpath.evaluate(resource, "Questionnaire.all(contained.meta.security.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result3.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a security label");
    }
    const result4 = await fhirpath.evaluate(resource, "Questionnaire.all(text.`div`.exists())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result4.every(Boolean)) {
        warnings.push("Constraint violation: A resource should have narrative for robust management");
    }
    const result5 = await fhirpath.evaluate(resource, "Questionnaire.all(name.matches('[A-Z]([A-Za-z0-9_]){0,254}'))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result5.every(Boolean)) {
        warnings.push("Constraint violation: Name should be usable as an identifier for the module by machine processing applications such as code generation");
    }
    const result6 = await fhirpath.evaluate(resource, "Questionnaire.all(descendants().linkId.isDistinct())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result6.every(Boolean)) {
        errors.push("Constraint violation: The link ids for groups and questions must be unique within the questionnaire");
    }
    const result7 = await fhirpath.evaluate(resource, "meta.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result7.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result8 = await fhirpath.evaluate(resource, "implicitRules.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result8.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result9 = await fhirpath.evaluate(resource, "language.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result9.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result10 = await fhirpath.evaluate(resource, "text.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result10.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result11 = await fhirpath.evaluate(resource, "extension.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result11.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result12 = await fhirpath.evaluate(resource, "modifierExtension.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result12.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result13 = await fhirpath.evaluate(resource, "url.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result13.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result14 = await fhirpath.evaluate(resource, "identifier.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result14.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result15 = await fhirpath.evaluate(resource, "version.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result15.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result16 = await fhirpath.evaluate(resource, "name.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result16.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result17 = await fhirpath.evaluate(resource, "title.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result17.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result18 = await fhirpath.evaluate(resource, "derivedFrom.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result18.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result19 = await fhirpath.evaluate(resource, "status.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result19.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result20 = await fhirpath.evaluate(resource, "experimental.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result20.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result21 = await fhirpath.evaluate(resource, "subjectType.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result21.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result22 = await fhirpath.evaluate(resource, "date.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result22.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result23 = await fhirpath.evaluate(resource, "publisher.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result23.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result24 = await fhirpath.evaluate(resource, "contact.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result24.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result25 = await fhirpath.evaluate(resource, "description.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result25.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result26 = await fhirpath.evaluate(resource, "useContext.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result26.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result27 = await fhirpath.evaluate(resource, "jurisdiction.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result27.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result28 = await fhirpath.evaluate(resource, "purpose.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result28.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result29 = await fhirpath.evaluate(resource, "copyright.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result29.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result30 = await fhirpath.evaluate(resource, "approvalDate.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result30.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result31 = await fhirpath.evaluate(resource, "lastReviewDate.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result31.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result32 = await fhirpath.evaluate(resource, "effectivePeriod.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result32.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result33 = await fhirpath.evaluate(resource, "code.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result33.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result34 = await fhirpath.evaluate(resource, "item.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result34.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result35 = await fhirpath.evaluate(resource, "item.all((type='group' implies item.empty().not()) and (type.trace('type')='display' implies item.trace('item').empty()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result35.every(Boolean)) {
        errors.push("Constraint violation: Group items must have nested items, display items cannot have nested items");
    }
    const result36 = await fhirpath.evaluate(resource, "item.all(type!='display' or code.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result36.every(Boolean)) {
        errors.push("Constraint violation: Display items cannot have a \"code\" asserted");
    }
    const result37 = await fhirpath.evaluate(resource, "item.all(answerOption.empty() or answerValueSet.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result37.every(Boolean)) {
        errors.push("Constraint violation: A question cannot have both answerOption and answerValueSet");
    }
    const result38 = await fhirpath.evaluate(resource, "item.all((type ='choice' or type = 'open-choice' or type = 'decimal' or type = 'integer' or type = 'date' or type = 'dateTime' or type = 'time' or type = 'string' or type = 'quantity') or (answerValueSet.empty() and answerOption.empty()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result38.every(Boolean)) {
        errors.push("Constraint violation: Only 'choice' and 'open-choice' items can have answerValueSet");
    }
    const result39 = await fhirpath.evaluate(resource, "item.all(type!='display' or (required.empty() and repeats.empty()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result39.every(Boolean)) {
        errors.push("Constraint violation: Required and repeat aren't permitted for display items");
    }
    const result40 = await fhirpath.evaluate(resource, "item.all((type!='group' and type!='display') or initial.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result40.every(Boolean)) {
        errors.push("Constraint violation: Initial values can't be specified for groups or display items");
    }
    const result41 = await fhirpath.evaluate(resource, "item.all(type!='display' or readOnly.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result41.every(Boolean)) {
        errors.push("Constraint violation: Read-only can't be specified for \"display\" items");
    }
    const result42 = await fhirpath.evaluate(resource, "item.all((type in ('boolean' | 'decimal' | 'integer' | 'string' | 'text' | 'url' | 'open-choice')) or maxLength.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result42.every(Boolean)) {
        errors.push("Constraint violation: Maximum length can only be declared for simple question types");
    }
    const result43 = await fhirpath.evaluate(resource, "item.all(answerOption.empty() or initial.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result43.every(Boolean)) {
        errors.push("Constraint violation: If one or more answerOption is present, initial[x] must be missing");
    }
    const result44 = await fhirpath.evaluate(resource, "item.all(enableWhen.count() > 2 implies enableBehavior.exists())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result44.every(Boolean)) {
        errors.push("Constraint violation: If there are more than one enableWhen, enableBehavior must be specified");
    }
    const result45 = await fhirpath.evaluate(resource, "item.all(repeats=true or initial.count() <= 1)", { resource }, fhirpath_model, fhirpathOptions);
    if (!result45.every(Boolean)) {
        errors.push("Constraint violation: Can only have multiple initial values for repeating items");
    }
    const result46 = await fhirpath.evaluate(resource, "item.enableWhen.all(operator = 'exists' implies (answer is Boolean))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result46.every(Boolean)) {
        errors.push("Constraint violation: If the operator is 'exists', the value must be a boolean");
    }
    const result47 = await fhirpath.evaluate(resource, "DomainResource.all(contained.contained.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result47.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL NOT contain nested Resources");
    }
    const result48 = await fhirpath.evaluate(resource, "DomainResource.all(contained.where((('#'+id in (%resource.descendants().reference | %resource.descendants().as(canonical) | %resource.descendants().as(uri) | %resource.descendants().as(url))) or descendants().where(reference = '#').exists() or descendants().where(as(canonical) = '#').exists() or descendants().where(as(canonical) = '#').exists()).not()).trace('unmatched', id).empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result48.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL be referred to from elsewhere in the resource or SHALL refer to the containing resource");
    }
    const result49 = await fhirpath.evaluate(resource, "DomainResource.all(contained.meta.versionId.empty() and contained.meta.lastUpdated.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result49.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a meta.versionId or a meta.lastUpdated");
    }
    const result50 = await fhirpath.evaluate(resource, "DomainResource.all(contained.meta.security.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result50.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a security label");
    }
    const result51 = await fhirpath.evaluate(resource, "DomainResource.all(text.`div`.exists())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result51.every(Boolean)) {
        warnings.push("Constraint violation: A resource should have narrative for robust management");
    }
    const result52 = await fhirpath.evaluate(resource, "text.div.all(htmlChecks())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result52.every(Boolean)) {
        errors.push("Constraint violation: The narrative SHALL have some non-whitespace content");
    }
    const result53 = await fhirpath.evaluate(resource, "text.exists()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result53.every(Boolean)) {
        errors.push("Constraint violation: text must be present");
    }
    const result54 = await fhirpath.evaluate(resource, "extension.count() >= 1", { resource }, fhirpath_model, fhirpathOptions);
    if (!result54.every(Boolean)) {
        errors.push("Constraint violation: extension must contain at least one element");
    }
    const result55 = await fhirpath.evaluate(resource, "title.exists()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result55.every(Boolean)) {
        errors.push("Constraint violation: title must be present");
    }
    const result56 = await fhirpath.evaluate(resource, "derivedFrom.count() >= 1", { resource }, fhirpath_model, fhirpathOptions);
    if (!result56.every(Boolean)) {
        errors.push("Constraint violation: derivedFrom must contain at least one element");
    }
    const result57 = await fhirpath.evaluate(resource, "status.exists()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result57.every(Boolean)) {
        errors.push("Constraint violation: status must be present");
    }
    const result58 = await fhirpath.evaluate(resource, "derivedFrom.count() <= 1", { resource }, fhirpath_model, fhirpathOptions);
    if (!result58.every(Boolean)) {
        errors.push("Constraint violation: derivedFrom must contain at most one element");
    }
    const result59 = await fhirpath.evaluate(resource, "url.exists().not()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result59.every(Boolean)) {
        errors.push("Constraint violation: url: max allowed = 0, but found 1");
    }
    const result60 = await fhirpath.evaluate(resource, "enableWhen.all(item.enableWhen.exists().not())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result60.every(Boolean)) {
        errors.push("Constraint violation: item.enableWhen: max allowed = 0, but found 1");
    }
    const result61 = await fhirpath.evaluate(resource, "enableBehavior.all(item.enableBehavior.exists().not())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result61.every(Boolean)) {
        errors.push("Constraint violation: item.enableBehavior: max allowed = 0, but found 1");
    }
    if (options?.terminologyUrl) {
        const result62 = await fhirpath.evaluate(resource, "subjectType.all(memberOf('http://hl7.org/fhir/ValueSet/resource-types'))", { resource }, fhirpath_model, fhirpathOptions);
        if (!result62.every(Boolean)) {
            errors.push("Constraint violation: The value provided must be in the value set 'resource-types' (http://hl7.org/fhir/ValueSet/resource-types)");
        }
    }
    else {
        warnings.push("Constraint not evaluated (no terminologyUrl): The value provided must be in the value set 'resource-types' (http://hl7.org/fhir/ValueSet/resource-types)");
    }
    if (options?.terminologyUrl) {
        const result63 = await fhirpath.evaluate(resource, "item.enableWhen.operator.all(memberOf('http://hl7.org/fhir/ValueSet/questionnaire-enable-operator'))", { resource }, fhirpath_model, fhirpathOptions);
        if (!result63.every(Boolean)) {
            errors.push("Constraint violation: The value provided must be in the value set 'questionnaire-enable-operator' (http://hl7.org/fhir/ValueSet/questionnaire-enable-operator)");
        }
    }
    else {
        warnings.push("Constraint not evaluated (no terminologyUrl): The value provided must be in the value set 'questionnaire-enable-operator' (http://hl7.org/fhir/ValueSet/questionnaire-enable-operator)");
    }
    if (options?.terminologyUrl) {
        const result64 = await fhirpath.evaluate(resource, "item.enableBehavior.all(memberOf('http://hl7.org/fhir/ValueSet/questionnaire-enable-behavior'))", { resource }, fhirpath_model, fhirpathOptions);
        if (!result64.every(Boolean)) {
            errors.push("Constraint violation: The value provided must be in the value set 'questionnaire-enable-behavior' (http://hl7.org/fhir/ValueSet/questionnaire-enable-behavior)");
        }
    }
    else {
        warnings.push("Constraint not evaluated (no terminologyUrl): The value provided must be in the value set 'questionnaire-enable-behavior' (http://hl7.org/fhir/ValueSet/questionnaire-enable-behavior)");
    }
    // Nested required field: item.linkId (min=1)
    if (resource.item && Array.isArray(resource.item)) {
        for (const _el of resource.item) {
            if ((_el.linkId === undefined || _el.linkId === null) || Array.isArray(_el.linkId)) {
                errors.push("Missing required member: 'linkId'");
            }
        }
    }
    // Nested required field: item.text (min=1)
    if (resource.item && Array.isArray(resource.item)) {
        for (const _el of resource.item) {
            if ((_el.text === undefined || _el.text === null) || Array.isArray(_el.text)) {
                errors.push("Missing required member: 'text'");
            }
        }
    }
    // Nested required field: item.type (min=1)
    if (resource.item && Array.isArray(resource.item)) {
        for (const _el of resource.item) {
            if ((_el.type === undefined || _el.type === null) || Array.isArray(_el.type)) {
                errors.push("Missing required member: 'type'");
            }
        }
    }
    // Nested required field: item.enableWhen.question (min=1)
    if (resource.item && Array.isArray(resource.item)) {
        for (const _nrEl0 of resource.item) {
            if (_nrEl0.enableWhen && Array.isArray(_nrEl0.enableWhen)) {
                for (const _nrEl1 of _nrEl0.enableWhen) {
                    if ((_nrEl1.question === undefined || _nrEl1.question === null) || Array.isArray(_nrEl1.question)) {
                        errors.push("Missing required member: 'question'");
                    }
                }
            }
        }
    }
    // Nested required field: item.enableWhen.operator (min=1)
    if (resource.item && Array.isArray(resource.item)) {
        for (const _nrEl0 of resource.item) {
            if (_nrEl0.enableWhen && Array.isArray(_nrEl0.enableWhen)) {
                for (const _nrEl1 of _nrEl0.enableWhen) {
                    if ((_nrEl1.operator === undefined || _nrEl1.operator === null) || Array.isArray(_nrEl1.operator)) {
                        errors.push("Missing required member: 'operator'");
                    }
                }
            }
        }
    }
    // Nested required field: item.enableWhen.answerBackboneElement (min=1)
    if (resource.item && Array.isArray(resource.item)) {
        for (const _nrEl0 of resource.item) {
            if (_nrEl0.enableWhen && Array.isArray(_nrEl0.enableWhen)) {
                for (const _nrEl1 of _nrEl0.enableWhen) {
                    if ((_nrEl1.answerBackboneElement === undefined || _nrEl1.answerBackboneElement === null) || Array.isArray(_nrEl1.answerBackboneElement)) {
                        errors.push("Missing required member: 'answerBackboneElement'");
                    }
                }
            }
        }
    }
    // Nested required field: item.answerOption.valueBackboneElement (min=1)
    if (resource.item && Array.isArray(resource.item)) {
        for (const _nrEl0 of resource.item) {
            if (_nrEl0.answerOption && Array.isArray(_nrEl0.answerOption)) {
                for (const _nrEl1 of _nrEl0.answerOption) {
                    if ((_nrEl1.valueBackboneElement === undefined || _nrEl1.valueBackboneElement === null) || Array.isArray(_nrEl1.valueBackboneElement)) {
                        errors.push("Missing required member: 'valueBackboneElement'");
                    }
                }
            }
        }
    }
    // Nested required field: item.initial.valueBackboneElement (min=1)
    if (resource.item && Array.isArray(resource.item)) {
        for (const _nrEl0 of resource.item) {
            if (_nrEl0.initial && Array.isArray(_nrEl0.initial)) {
                for (const _nrEl1 of _nrEl0.initial) {
                    if ((_nrEl1.valueBackboneElement === undefined || _nrEl1.valueBackboneElement === null) || Array.isArray(_nrEl1.valueBackboneElement)) {
                        errors.push("Missing required member: 'valueBackboneElement'");
                    }
                }
            }
        }
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const _bRes = resource;
    // Prohibited field: Questionnaire.url (max=0)
    if (_bRes.url !== undefined) {
        errors.push("Questionnaire.url: max allowed = 0, but found 1");
    }
    // Prohibited field: Questionnaire.item.enableWhen (max=0)
    if (_bRes.item && Array.isArray(_bRes.item)) {
        for (const _el of _bRes.item) {
            const _e = _el;
            if (_e?.enableWhen !== undefined) {
                errors.push("Questionnaire.item.enableWhen: max allowed = 0, but found 1");
            }
        }
    }
    // Prohibited field: Questionnaire.item.enableBehavior (max=0)
    if (_bRes.item && Array.isArray(_bRes.item)) {
        for (const _el of _bRes.item) {
            const _e = _el;
            if (_e?.enableBehavior !== undefined) {
                errors.push("Questionnaire.item.enableBehavior: max allowed = 0, but found 1");
            }
        }
    }
    // Required ValueSet binding validation for status
    if (_bRes.status !== undefined && !isValidPublicationStatusCode(_bRes.status)) {
        errors.push("Code '" + _bRes.status + "' does not exist in the value set 'publication-status' (http://hl7.org/fhir/ValueSet/publication-status), but the binding is of strength 'required'");
    }
    // Required ValueSet binding validation for item.type (nested)
    if (resource.item && Array.isArray(resource.item)) {
        for (const _nb0 of resource.item) {
            if (_nb0.type !== undefined && !isValidItemTypeCode(_nb0.type)) {
                errors.push("Code '" + _nb0.type + "' does not exist in the value set 'item-type' (http://hl7.org/fhir/ValueSet/item-type), but the binding is of strength 'required'");
            }
        }
    }
    // dateTime format validation for date
    if (typeof _bRes.date === 'string' && !/^\d{4}(-\d{2}(-\d{2}(T\d{2}:\d{2}(:\d{2}(\.\d+)?)?(Z|[+-]\d{2}:\d{2})?)?)?)?$/.test(_bRes.date)) {
        errors.push("Not a valid date/time format: '" + _bRes.date + "'");
    }
    // date format validation for approvalDate
    if (typeof _bRes.approvalDate === 'string' && !/^\d{4}(-\d{2}(-\d{2})?)?$/.test(_bRes.approvalDate)) {
        errors.push("Not a valid date format: '" + _bRes.approvalDate + "'");
    }
    // date format validation for lastReviewDate
    if (typeof _bRes.lastReviewDate === 'string' && !/^\d{4}(-\d{2}(-\d{2})?)?$/.test(_bRes.lastReviewDate)) {
        errors.push("Not a valid date format: '" + _bRes.lastReviewDate + "'");
    }
    // Required extension slice validation for extension:questionnaireAdaptive (url discriminator)
    if (resource.extension && Array.isArray(resource.extension)) {
        const questionnaireAdaptiveElements = resource.extension.filter((item) => item.url === "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-questionnaireAdaptive");
        if (questionnaireAdaptiveElements.length < 1) {
            errors.push("Slice 'extension:questionnaireAdaptive': a matching slice is required, but not found");
        }
        // Extension value type + binding validation
        for (const _ext of questionnaireAdaptiveElements) {
            const _valEntry = Object.entries(_ext).find(([k]) => k.startsWith("value"));
            if (_valEntry && !["valueUrl"].includes(_valEntry[0])) {
                const _found = _valEntry[0].replace("value", "").toLowerCase();
                errors.push("The Profile 'http://hl7.org/fhir/us/davinci-dtr/StructureDefinition/dtr-questionnaire-adapt' definition allows for the type url but found type " + _found);
            }
        }
    }
    else {
        errors.push("Slice 'extension:questionnaireAdaptive': a matching slice is required, but not found");
    }
    // Base FHIR structural validation: extension.url required, ext-1 constraint, empty objects
    {
        const _checkExtensions = (obj, path, depth) => {
            if (!obj || typeof obj !== 'object')
                return;
            if (Array.isArray(obj)) {
                obj.forEach((item, i) => _checkExtensions(item, path + '[' + i + ']', depth + 1));
                return;
            }
            const rec = obj;
            // Empty object check — HL7 validates all FHIR elements must have content
            if (depth > 0 && Object.keys(rec).length === 0) {
                errors.push('Object must have some content');
            }
            // per-1: If present, start SHALL have a lower value than end (Period structural check)
            if (typeof rec.start === 'string' && typeof rec.end === 'string' && rec.start > rec.end) {
                errors.push('If present, start SHALL have a lower value than end');
            }
            // Validate extension arrays
            for (const extKey of ['extension', 'modifierExtension']) {
                const exts = rec[extKey];
                if (Array.isArray(exts)) {
                    for (const ext of exts) {
                        if (ext && typeof ext === 'object' && !Array.isArray(ext)) {
                            const e = ext;
                            if (typeof e.url !== 'string' || !e.url) {
                                errors.push('Extension.url is required in order to identify, use and validate the extension');
                            }
                            // ext-1: Must have either extensions or value[x], not both
                            const hasNestedExt = Array.isArray(e.extension) && e.extension.length > 0;
                            const hasValue = Object.keys(e).some(k => k.startsWith('value') && k !== 'value' && k.length > 5);
                            if (hasNestedExt && hasValue) {
                                errors.push('Must have either extensions or value[x], not both');
                            }
                        }
                    }
                }
            }
            // Recurse into child objects (skip primitive values)
            for (const [_key, _val] of Object.entries(rec)) {
                if (_val && typeof _val === 'object') {
                    _checkExtensions(_val, path + '.' + _key, depth + 1);
                }
            }
        };
        _checkExtensions(resource, '', 0);
    }
    // Standalone contained reference resolution: verify #id references resolve to contained[] entries
    {
        const _res = resource;
        const _containedIds = new Set();
        if (Array.isArray(_res.contained)) {
            for (const _c of _res.contained) {
                if (_c && typeof _c.id === 'string')
                    _containedIds.add(_c.id);
            }
        }
        const _checkContainedRef = (obj) => {
            if (!obj || typeof obj !== 'object')
                return;
            if (Array.isArray(obj)) {
                obj.forEach(_checkContainedRef);
                return;
            }
            const _rec = obj;
            if (typeof _rec.reference === 'string') {
                const _ref = _rec.reference;
                if (_ref.startsWith('#')) {
                    const _id = _ref.substring(1);
                    if (_id && !_containedIds.has(_id)) {
                        errors.push('Contained reference not found: ' + _ref);
                    }
                }
            }
            for (const [_k, _v] of Object.entries(_rec)) {
                if (_k !== 'contained')
                    _checkContainedRef(_v);
            }
        };
        _checkContainedRef(_res);
    }
    return { errors, warnings };
}
