import { validateDTRSupportedPayers } from "./DTRSupportedPayers.js";
// Only import helpers actually referenced below (dynamic based on required fields)
import { randomId, setRandomSeed, enrichResource } from "./random/index.js";
import { createRequire } from 'module';
const __require = createRequire(import.meta.url);
// Helper emitted only when meta.profile enforcement is applicable (resource profiles)
// Internal helper (emitted per class file) to clone without resorting to 'any'.
function safeClone(value) {
    // Use native structuredClone if present; otherwise fallback to JSON round-trip.
    // We intentionally avoid casting through any to satisfy no-explicit-any lint rule.
    const g = globalThis;
    // Narrow globalThis to an object potentially containing structuredClone.
    if (typeof g.structuredClone === 'function') {
        return g.structuredClone(value);
    }
    return JSON.parse(JSON.stringify(value)); // best-effort deep clone
}
export class DTRSupportedPayersClass {
    constructor(resource) {
        this.resource = resource;
    }
    /** Validate current resource instance. */
    async validate(options) {
        return validateDTRSupportedPayers(this.resource, options);
    }
    getResource() {
        return this.resource;
    }
    setResource(resource) {
        this.resource = resource;
    }
    /**
     * Returns a plain JSON clone of the underlying resource ONLY if the last validation succeeded with zero errors.
     * Call validate() first; otherwise this method throws to prevent accidental use of invalid / unchecked data.
     */
    async toJSON() {
        return safeClone(this.resource);
    }
    /**
     * Create an empty instance for parity testing: for true FHIR resources, includes only resourceType; for datatypes, returns an empty object.
     * Note: meta.profile (when applicable) will be ensured by the constructor when wrapping this resource.
     */
    static empty(overrides = {}) {
        // For Resource profiles, include only resourceType. For Extension profiles, include url so the instance is minimally meaningful.
        const base = {};
        return { ...base, ...overrides };
    }
    /**
     * Create a minimal randomized instance of DTRSupportedPayers.
     * Populates id, resourceType (if applicable) and primitive required (min>0) top-level fields with placeholders.
     */
    static random(overrides = {}, opts) {
        if (opts?.seed !== undefined) {
            // Direct call (no dynamic require) to ensure deterministic seeding works under ESM.
            setRandomSeed(opts.seed);
        }
        // Start with a Partial to avoid unsafe casting errors; we'll assert at the end.
        const base = { id: randomId(), };
        // Always include meta.profile with this profile's canonical URL if available & only for resource profiles
        // (no profileUrl provided or profile targets a datatype â€“ meta.profile not applicable)
        // Enrich the base resource with common fields using centralized enrichment logic
        enrichResource(base, 'Base', 'http://hl7.org/fhir/us/davinci-dtr/StructureDefinition/DTRSupportedPayers', DTRSupportedPayersClass._fieldPatterns, DTRSupportedPayersClass._forbiddenFields, DTRSupportedPayersClass.valueSetBindings, DTRSupportedPayersClass._codeResolver, DTRSupportedPayersClass._fieldOrder);
        // Cast through unknown to acknowledge dynamic enrichment
        return { ...base, ...overrides };
    }
    /** Convenience: returns a class instance wrapping a randomized resource. */
    static randomClass(overrides = {}, opts) {
        return new DTRSupportedPayersClass(this.random(overrides, opts));
    }
}
/** Pattern constraints for profile fields (used by random() generator) */
DTRSupportedPayersClass._fieldPatterns = {
    "payer.identifier.use": "old",
    "payer.identifier.type": "TAX",
    "_refReq_payer": {
        "name": true,
        "identifier": true,
        "identifier.system": true,
        "identifier.value": true
    }
};
/** Fields that are forbidden (max=0) in this profile - must not be generated */
DTRSupportedPayersClass._forbiddenFields = [];
/** FHIR element ordering for this profile's base resource (used by enrichResource for correct JSON field order) */
DTRSupportedPayersClass._fieldOrder = ["payer"];
/** ValueSet bindings for coded fields - maps field name to ValueSet URL */
DTRSupportedPayersClass.valueSetBindings = {
    "payer.identifier.use": "http://hl7.org/fhir/ValueSet/identifier-use|4.0.1",
    "payer.identifier.type": "http://hl7.org/fhir/ValueSet/identifier-type"
};
/** Code resolver for ValueSet bindings - returns a random valid code from a ValueSet by URL */
DTRSupportedPayersClass._codeResolver = (() => {
    // Try to load the ValueSetRegistry - it may not exist if no ValueSets were generated
    try {
        const registry = __require('./valuesets/index.js');
        if (registry && typeof registry.getRandomConceptByUrl === 'function') {
            return registry.getRandomConceptByUrl;
        }
    }
    catch { /* ValueSetRegistry not available */ }
    return undefined;
})();
