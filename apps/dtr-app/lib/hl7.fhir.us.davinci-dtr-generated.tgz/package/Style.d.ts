import { Extension } from "fhir/r4";
export interface Style extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/StructureDefinition/rendering-style";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateStyle(resource: Style, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
