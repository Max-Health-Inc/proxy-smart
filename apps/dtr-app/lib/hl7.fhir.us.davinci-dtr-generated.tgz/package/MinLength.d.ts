import { Extension } from "fhir/r4";
export interface MinLength extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/StructureDefinition/minLength";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateMinLength(resource: MinLength, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
