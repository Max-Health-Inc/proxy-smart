import fhirpath from "fhirpath";
import fhirpath_model from "fhirpath/fhir-context/r4/index.js";
import { isValidCoverageInfoCode } from './valuesets/ValueSet-CoverageInfo.js';
import { isValidCoveragePaDetailCode } from './valuesets/ValueSet-CoveragePaDetail.js';
import { isValidAdditionalDocumentationCode } from './valuesets/ValueSet-AdditionalDocumentation.js';
import { isValidDocReasonCode } from './valuesets/ValueSet-DocReason.js';
import { isValidInformationNeededCode } from './valuesets/ValueSet-InformationNeeded.js';
export async function validateCoverageInformation(resource, options) {
    const errors = [];
    const warnings = [];
    const fhirpathOptions = {
        preciseMath: true,
        traceFn: options?.traceFn ?? (() => { }),
        ...(options?.signal ? { signal: options.signal } : {}),
        ...(options?.httpHeaders ? { httpHeaders: options.httpHeaders } : {}),
    };
    const result0 = await fhirpath.evaluate(resource, "Extension.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result0.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result1 = await fhirpath.evaluate(resource, "Extension.all(extension.where(url='questionnaire' or url='response').exists() implies (extension.where(url = 'doc-needed').exists() and extension.where(url = 'doc-needed').all(value != 'no-doc')))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result1.every(Boolean)) {
        errors.push("Constraint violation: Questionnaire and QuestionnaireResponse are only allowed when doc-needed exists and not equal to 'no-doc'");
    }
    const result2 = await fhirpath.evaluate(resource, "Extension.all(extension.where(url = 'covered' and value != 'not-covered') implies extension.where(url = 'pa-needed').exists())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result2.every(Boolean)) {
        errors.push("Constraint violation: If covered is set to 'not-covered', then 'pa-needed' should not exist.");
    }
    const result3 = await fhirpath.evaluate(resource, "Extension.all(extension.where(url = 'info-needed').exists() implies extension.where((url = 'covered' or url = 'pa-needed' or url = 'doc-needed') and value = 'conditional').count() >= 1)", { resource }, fhirpath_model, fhirpathOptions);
    if (!result3.every(Boolean)) {
        errors.push("Constraint violation: If 'info-needed' exists, then at least one of 'covered', 'pa-needed', or 'doc-needed' must be 'conditional'.");
    }
    const result4 = await fhirpath.evaluate(resource, "Extension.all(extension.where(url = 'pa-needed' and value = 'satisfied') and extension.where(url = 'doc-purpose').exists() implies extension.where(url = 'doc-purpose').all(value != 'PA'))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result4.every(Boolean)) {
        errors.push("Constraint violation: If 'pa-needed' is 'satisfied', then 'Doc-purpose' can't be 'PA'.");
    }
    const result5 = await fhirpath.evaluate(resource, "Extension.all(extension.where(url = 'pa-needed' and value = 'satisfied').exists() = extension.where(url = 'satisfied-pa-id').exists())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result5.every(Boolean)) {
        errors.push("Constraint violation: 'satisfied-pa-id' must exist if and only if 'pa-needed' is set to 'satisfied'.");
    }
    const result6 = await fhirpath.evaluate(resource, "extension.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result6.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result7 = await fhirpath.evaluate(resource, "value.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result7.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result8 = await fhirpath.evaluate(resource, "Element.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result8.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result9 = await fhirpath.evaluate(resource, "extension.count() >= 4", { resource }, fhirpath_model, fhirpathOptions);
    if (!result9.every(Boolean)) {
        errors.push("Constraint violation: extension must contain at least 4 elements");
    }
    const result10 = await fhirpath.evaluate(resource, "url.exists()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result10.every(Boolean)) {
        errors.push("Constraint violation: url must be present");
    }
    const result11 = await fhirpath.evaluate(resource, "extension.count() >= 1", { resource }, fhirpath_model, fhirpathOptions);
    if (!result11.every(Boolean)) {
        errors.push("Constraint violation: extension must contain at least one element");
    }
    const result12 = await fhirpath.evaluate(resource, "value.exists().not()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result12.every(Boolean)) {
        errors.push("Constraint violation: value: max allowed = 0, but found 1");
    }
    // Fixed value constraint for url
    if (resource.url !== undefined && resource.url !== "http://hl7.org/fhir/us/davinci-crd/StructureDefinition/ext-coverage-information") {
        errors.push("url must have the fixed value 'http://hl7.org/fhir/us/davinci-crd/StructureDefinition/ext-coverage-information'");
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const _bRes = resource;
    // Structural type check: extension must be a JSON Array
    if (_bRes.extension !== undefined && _bRes.extension !== null && !Array.isArray(_bRes.extension)) {
        errors.push("The property extension must be a JSON Array, not an Object (at " + (_bRes.resourceType || "Resource") + ")");
    }
    // Structural type check: extension must be a JSON Array
    if (_bRes.extension !== undefined && _bRes.extension !== null && !Array.isArray(_bRes.extension)) {
        errors.push("The property extension must be a JSON Array, not an Object (at " + (_bRes.resourceType || "Resource") + ")");
    }
    // Prohibited field: Extension.value (max=0)
    if (_bRes.value !== undefined) {
        errors.push("Extension.value: max allowed = 0, but found 1");
    }
    // Required ValueSet binding validation for extension.valueCode (nested)
    if (resource.extension && Array.isArray(resource.extension)) {
        for (const _nb0 of resource.extension) {
            if (_nb0.valueCode !== undefined && !isValidCoverageInfoCode(_nb0.valueCode)) {
                errors.push("Code '" + _nb0.valueCode + "' does not exist in the value set 'coverageInfo' (http://hl7.org/fhir/us/davinci-crd/ValueSet/coverageInfo), but the binding is of strength 'required'");
            }
        }
    }
    // Required ValueSet binding validation for extension.valueCode (nested)
    if (resource.extension && Array.isArray(resource.extension)) {
        for (const _nb0 of resource.extension) {
            if (_nb0.valueCode !== undefined && !isValidCoveragePaDetailCode(_nb0.valueCode)) {
                errors.push("Code '" + _nb0.valueCode + "' does not exist in the value set 'coveragePaDetail' (http://hl7.org/fhir/us/davinci-crd/ValueSet/coveragePaDetail), but the binding is of strength 'required'");
            }
        }
    }
    // Required ValueSet binding validation for extension.valueCode (nested)
    if (resource.extension && Array.isArray(resource.extension)) {
        for (const _nb0 of resource.extension) {
            if (_nb0.valueCode !== undefined && !isValidAdditionalDocumentationCode(_nb0.valueCode)) {
                errors.push("Code '" + _nb0.valueCode + "' does not exist in the value set 'AdditionalDocumentation' (http://hl7.org/fhir/us/davinci-crd/ValueSet/AdditionalDocumentation), but the binding is of strength 'required'");
            }
        }
    }
    // Required ValueSet binding validation for extension.valueCode (nested)
    if (resource.extension && Array.isArray(resource.extension)) {
        for (const _nb0 of resource.extension) {
            if (_nb0.valueCode !== undefined && !isValidDocReasonCode(_nb0.valueCode)) {
                errors.push("Code '" + _nb0.valueCode + "' does not exist in the value set 'DocReason' (http://hl7.org/fhir/us/davinci-crd/ValueSet/DocReason), but the binding is of strength 'required'");
            }
        }
    }
    // Required ValueSet binding validation for extension.valueCode (nested)
    if (resource.extension && Array.isArray(resource.extension)) {
        for (const _nb0 of resource.extension) {
            if (_nb0.valueCode !== undefined && !isValidInformationNeededCode(_nb0.valueCode)) {
                errors.push("Code '" + _nb0.valueCode + "' does not exist in the value set 'informationNeeded' (http://hl7.org/fhir/us/davinci-crd/ValueSet/informationNeeded), but the binding is of strength 'required'");
            }
        }
    }
    // date format validation for valueDate (choice type)
    if (typeof _bRes.valueDate === 'string' && !/^\d{4}(-\d{2}(-\d{2})?)?$/.test(_bRes.valueDate)) {
        errors.push("Not a valid date format: '" + _bRes.valueDate + "'");
    }
    // dateTime format validation for valueDateTime (choice type)
    if (typeof _bRes.valueDateTime === 'string' && !/^\d{4}(-\d{2}(-\d{2}(T\d{2}:\d{2}(:\d{2}(\.\d+)?)?(Z|[+-]\d{2}:\d{2})?)?)?)?$/.test(_bRes.valueDateTime)) {
        errors.push("Not a valid date/time format: '" + _bRes.valueDateTime + "'");
    }
    // instant format validation for valueInstant (choice type)
    if (typeof _bRes.valueInstant === 'string' && !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2}(\.\d+)?)?(Z|[+-]\d{2}:\d{2})$/.test(_bRes.valueInstant)) {
        errors.push("Not a valid instant format: '" + _bRes.valueInstant + "'");
    }
    // time format validation for valueTime (choice type)
    if (typeof _bRes.valueTime === 'string' && !/^\d{2}:\d{2}(:\d{2}(\.\d+)?)?$/.test(_bRes.valueTime)) {
        errors.push("Not a valid time format: '" + _bRes.valueTime + "'");
    }
    // Required extension slice validation for extension:coverage (url discriminator)
    if (resource.extension && Array.isArray(resource.extension)) {
        const coverageElements = resource.extension.filter((item) => item.url === "coverage");
        if (coverageElements.length < 1) {
            errors.push("Slice 'extension:coverage': a matching slice is required, but not found");
        }
    }
    else {
        errors.push("Slice 'extension:coverage': a matching slice is required, but not found");
    }
    // Required extension slice validation for extension:covered (url discriminator)
    if (resource.extension && Array.isArray(resource.extension)) {
        const coveredElements = resource.extension.filter((item) => item.url === "covered");
        if (coveredElements.length < 1) {
            errors.push("Slice 'extension:covered': a matching slice is required, but not found");
        }
    }
    else {
        errors.push("Slice 'extension:covered': a matching slice is required, but not found");
    }
    // Required extension slice validation for extension:date (url discriminator)
    if (resource.extension && Array.isArray(resource.extension)) {
        const dateElements = resource.extension.filter((item) => item.url === "date");
        if (dateElements.length < 1) {
            errors.push("Slice 'extension:date': a matching slice is required, but not found");
        }
    }
    else {
        errors.push("Slice 'extension:date': a matching slice is required, but not found");
    }
    // Required extension slice validation for extension:coverage-assertion-id (url discriminator)
    if (resource.extension && Array.isArray(resource.extension)) {
        const coverage_assertion_idElements = resource.extension.filter((item) => item.url === "coverage-assertion-id");
        if (coverage_assertion_idElements.length < 1) {
            errors.push("Slice 'extension:coverage-assertion-id': a matching slice is required, but not found");
        }
    }
    else {
        errors.push("Slice 'extension:coverage-assertion-id': a matching slice is required, but not found");
    }
    // Required extension slice validation for extension.extension:code (url discriminator, nested in array)
    if (resource.extension && Array.isArray(resource.extension)) {
        for (const _el of resource.extension) {
            const _extArr = _el?.extension;
            if (Array.isArray(_extArr)) {
                const codeMatches = _extArr.filter((item) => item.url === "code");
                if (codeMatches.length < 1) {
                    errors.push("Slice 'extension:detail.extension:code': a matching slice is required, but not found");
                }
            }
        }
    }
    // Required extension slice validation for extension.extension:value (url discriminator, nested in array)
    if (resource.extension && Array.isArray(resource.extension)) {
        for (const _el of resource.extension) {
            const _extArr = _el?.extension;
            if (Array.isArray(_extArr)) {
                const valueMatches = _extArr.filter((item) => item.url === "value");
                if (valueMatches.length < 1) {
                    errors.push("Slice 'extension:detail.extension:value': a matching slice is required, but not found");
                }
            }
        }
    }
    // Base FHIR structural validation: extension.url required, ext-1 constraint, empty objects
    {
        const _checkExtensions = (obj, path, depth) => {
            if (!obj || typeof obj !== 'object')
                return;
            if (Array.isArray(obj)) {
                obj.forEach((item, i) => _checkExtensions(item, path + '[' + i + ']', depth + 1));
                return;
            }
            const rec = obj;
            // Empty object check — HL7 validates all FHIR elements must have content
            if (depth > 0 && Object.keys(rec).length === 0) {
                errors.push('Object must have some content');
            }
            // per-1: If present, start SHALL have a lower value than end (Period structural check)
            if (typeof rec.start === 'string' && typeof rec.end === 'string' && rec.start > rec.end) {
                errors.push('If present, start SHALL have a lower value than end');
            }
            // Validate extension arrays
            for (const extKey of ['extension', 'modifierExtension']) {
                const exts = rec[extKey];
                if (Array.isArray(exts)) {
                    for (const ext of exts) {
                        if (ext && typeof ext === 'object' && !Array.isArray(ext)) {
                            const e = ext;
                            if (typeof e.url !== 'string' || !e.url) {
                                errors.push('Extension.url is required in order to identify, use and validate the extension');
                            }
                            // ext-1: Must have either extensions or value[x], not both
                            const hasNestedExt = Array.isArray(e.extension) && e.extension.length > 0;
                            const hasValue = Object.keys(e).some(k => k.startsWith('value') && k !== 'value' && k.length > 5);
                            if (hasNestedExt && hasValue) {
                                errors.push('Must have either extensions or value[x], not both');
                            }
                        }
                    }
                }
            }
            // Recurse into child objects (skip primitive values)
            for (const [_key, _val] of Object.entries(rec)) {
                if (_val && typeof _val === 'object') {
                    _checkExtensions(_val, path + '.' + _key, depth + 1);
                }
            }
        };
        _checkExtensions(resource, '', 0);
    }
    // Standalone contained reference resolution: verify #id references resolve to contained[] entries
    {
        const _res = resource;
        const _containedIds = new Set();
        if (Array.isArray(_res.contained)) {
            for (const _c of _res.contained) {
                if (_c && typeof _c.id === 'string')
                    _containedIds.add(_c.id);
            }
        }
        const _checkContainedRef = (obj) => {
            if (!obj || typeof obj !== 'object')
                return;
            if (Array.isArray(obj)) {
                obj.forEach(_checkContainedRef);
                return;
            }
            const _rec = obj;
            if (typeof _rec.reference === 'string') {
                const _ref = _rec.reference;
                if (_ref.startsWith('#')) {
                    const _id = _ref.substring(1);
                    if (_id && !_containedIds.has(_id)) {
                        errors.push('Contained reference not found: ' + _ref);
                    }
                }
            }
            for (const [_k, _v] of Object.entries(_rec)) {
                if (_k !== 'contained')
                    _checkContainedRef(_v);
            }
        };
        _checkContainedRef(_res);
    }
    return { errors, warnings };
}
