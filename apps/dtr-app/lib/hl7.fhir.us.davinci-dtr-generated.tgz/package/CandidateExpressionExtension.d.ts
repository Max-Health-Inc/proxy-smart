import { Extension } from "fhir/r4";
export interface CandidateExpressionExtension extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-candidateExpression";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateCandidateExpressionExtension(resource: CandidateExpressionExtension, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
