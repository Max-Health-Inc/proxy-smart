import { Parameters } from "fhir/r4";
export type DTRQuestionnaireNextQuestionnaireOutputParameters = Parameters;
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateDTRQuestionnaireNextQuestionnaireOutputParameters(resource: DTRQuestionnaireNextQuestionnaireOutputParameters, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
