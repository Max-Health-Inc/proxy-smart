import { ConditionCodeCode } from "./valuesets/ValueSet-ConditionCode";
import { CoverageInformation } from "./CoverageInformation";
import { CodeableConcept, DeviceRequest, DeviceRequestParameter, Extension, Identifier, Reference } from "fhir/r4";
export interface DeviceRequestExtension extends Omit<DeviceRequest, 'identifier' | 'basedOn' | 'status' | 'parameter' | 'subject' | 'requester' | 'performer' | 'reasonCode' | 'reasonReference' | 'extension'> {
    resourceType: 'DeviceRequest';
    /** Must Support */
    identifier?: Identifier[];
    /** Must Support */
    basedOn?: Reference[];
    status: "draft";
    /** Must Support */
    parameter?: DeviceRequestParameter[];
    /** Must Support */
    subject: Reference;
    /** Must Support */
    requester: Reference;
    /** Must Support */
    performer?: Reference;
    /** Must Support | @see {@link ./valuesets/ValueSet-ConditionCode.ts} for valid codes (1 codes) */
    reasonCode?: CodeableConcept & {
        coding: Array<{
            code: ConditionCodeCode;
            system: "http://snomed.info/sct";
        }>;
    }[];
    /** Must Support */
    reasonReference?: Reference[];
    extension?: (Extension | CoverageInformation)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateDeviceRequestExtension(resource: DeviceRequestExtension, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
