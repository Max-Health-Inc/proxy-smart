import { Extension, Reference } from "fhir/r4";
export interface QuestionnaireResponseContext extends Omit<Extension, 'url' | 'value'> {
    url: "http://hl7.org/fhir/us/davinci-dtr/StructureDefinition/qr-context";
    value: Reference;
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateQuestionnaireResponseContext(resource: QuestionnaireResponseContext, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
