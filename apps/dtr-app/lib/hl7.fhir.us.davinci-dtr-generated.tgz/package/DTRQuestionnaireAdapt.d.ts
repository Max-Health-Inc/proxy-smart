import { EntryFormat } from "./EntryFormat";
import { LibraryExtension } from "./LibraryExtension";
import { QuestionnaireAdaptiveExtension } from "./QuestionnaireAdaptiveExtension";
import { ChoiceOrientation } from "./ChoiceOrientation";
import { DisplayCategory } from "./DisplayCategory";
import { Hidden } from "./Hidden";
import { ItemControl } from "./ItemControl";
import { SliderStepValue } from "./SliderStepValue";
import { SupportLink } from "./SupportLink";
import { Unit } from "./Unit";
import { CandidateExpressionExtension } from "./CandidateExpressionExtension";
import { ChoiceColumnExtension } from "./ChoiceColumnExtension";
import { CollapsibleExtension } from "./CollapsibleExtension";
import { ContextExpressionExtension } from "./ContextExpressionExtension";
import { InitialExpressionExtension } from "./InitialExpressionExtension";
import { ItemAnswerMedia } from "./ItemAnswerMedia";
import { ItemMedia } from "./ItemMedia";
import { ItemPopulationContextExtension } from "./ItemPopulationContextExtension";
import { SDCOpenLabel } from "./SDCOpenLabel";
import { OptionalDisplayExtension } from "./OptionalDisplayExtension";
import { ShortTextExtension } from "./ShortTextExtension";
import { WidthExtension } from "./WidthExtension";
import { Style } from "./Style";
import { StyleSensitive } from "./StyleSensitive";
import { Xhtml } from "./Xhtml";
import { BackboneElement, Element, Extension, Narrative, Period, Questionnaire, QuestionnaireItem } from "fhir/r4";
export interface DTRQuestionnaireAdaptTitleElement extends Omit<Element, 'extension'> {
    extension?: (Extension | Style | Xhtml)[];
}
export interface DTRQuestionnaireAdapt extends Omit<Questionnaire, 'text' | '_title' | 'title' | 'effectivePeriod' | 'extension' | 'item'> {
    text: Narrative;
    _title?: DTRQuestionnaireAdaptTitleElement;
    /** Must Support */
    title: string;
    /** Must Support */
    effectivePeriod?: Period;
    extension?: (Extension | QuestionnaireAdaptiveExtension | StyleSensitive | LibraryExtension | ItemPopulationContextExtension)[];
    item?: DTRQuestionnaireAdaptItem[];
}
export interface DTRQuestionnaireAdaptItem extends Omit<QuestionnaireItem, 'extension' | '_prefix' | '_text' | 'answerOption'> {
    extension?: (Extension | Hidden | ItemMedia | OptionalDisplayExtension | ShortTextExtension | SDCOpenLabel | ItemControl | ChoiceOrientation | DisplayCategory | SupportLink | ChoiceColumnExtension | WidthExtension | SliderStepValue | EntryFormat | CollapsibleExtension | InitialExpressionExtension | Unit | CandidateExpressionExtension | ContextExpressionExtension)[];
    _prefix?: DTRQuestionnaireAdaptItemPrefixElement;
    _text: DTRQuestionnaireAdaptItemTextElement;
    answerOption: DTRQuestionnaireAdaptItemAnswerOption[];
}
export interface DTRQuestionnaireAdaptItemPrefixElement extends Omit<Element, 'extension'> {
    extension?: (Extension | Style | Xhtml)[];
}
export interface DTRQuestionnaireAdaptItemTextElement extends Omit<Element, 'extension'> {
    extension?: (Extension | Style | Xhtml)[];
}
export interface DTRQuestionnaireAdaptItemAnswerOption extends Omit<BackboneElement, 'extension'> {
    extension?: (Extension | ItemAnswerMedia)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateDTRQuestionnaireAdapt(resource: DTRQuestionnaireAdapt, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
