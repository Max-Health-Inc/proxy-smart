import { Bundle } from "fhir/r4";
export interface DTRQuestionnairePackageBundle extends Omit<Bundle, 'type'> {
    type: "collection";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateDTRQuestionnairePackageBundle(resource: DTRQuestionnairePackageBundle, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
