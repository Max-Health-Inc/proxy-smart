import { Appointment, AppointmentParticipant } from "fhir/r4";
export interface CRDAppointmentBase extends Omit<Appointment, 'participant'> {
    /** Must Support */
    participant: AppointmentParticipant[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateCRDAppointmentBase(resource: CRDAppointmentBase, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
