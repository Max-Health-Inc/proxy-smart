import { Extension } from "fhir/r4";
export interface QuestionnaireAdaptiveExtension extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-questionnaireAdaptive";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateQuestionnaireAdaptiveExtension(resource: QuestionnaireAdaptiveExtension, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
