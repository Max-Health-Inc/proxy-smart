import { Extension } from "fhir/r4";
export interface UsageMode extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/StructureDefinition/questionnaire-usageMode";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateUsageMode(resource: UsageMode, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
