import { Extension } from "fhir/r4";
export interface EntryMode extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-entryMode";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateEntryMode(resource: EntryMode, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
