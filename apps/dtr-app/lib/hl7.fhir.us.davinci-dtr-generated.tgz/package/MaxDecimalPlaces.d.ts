import { Extension } from "fhir/r4";
export interface MaxDecimalPlaces extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/StructureDefinition/maxDecimalPlaces";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateMaxDecimalPlaces(resource: MaxDecimalPlaces, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
