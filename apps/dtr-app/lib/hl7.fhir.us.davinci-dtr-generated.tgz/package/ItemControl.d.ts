import { CodeableConcept, Extension } from "fhir/r4";
export interface ItemControl extends Omit<Extension, 'url' | 'value'> {
    url: "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl";
    value: CodeableConcept;
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateItemControl(resource: ItemControl, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
