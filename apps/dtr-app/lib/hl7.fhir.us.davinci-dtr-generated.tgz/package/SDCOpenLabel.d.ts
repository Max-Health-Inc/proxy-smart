import { Extension } from "fhir/r4";
export interface SDCOpenLabel extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-openLabel";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateSDCOpenLabel(resource: SDCOpenLabel, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
