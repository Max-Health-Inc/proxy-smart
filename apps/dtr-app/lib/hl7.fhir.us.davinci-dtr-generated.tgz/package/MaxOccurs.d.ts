import { Extension } from "fhir/r4";
export interface MaxOccurs extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/StructureDefinition/questionnaire-maxOccurs";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateMaxOccurs(resource: MaxOccurs, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
