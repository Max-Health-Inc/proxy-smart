import { CoverageInformation } from "./CoverageInformation";
import { CodeableConcept, Duration, Encounter, EncounterDiagnosis, Extension, Reference } from "fhir/r4";
export interface EncounterExtension extends Omit<Encounter, 'serviceType' | 'appointment' | 'length' | 'diagnosis' | 'extension'> {
    resourceType: 'Encounter';
    /** Must Support | @see {@link ./valuesets/ValueSet-ServiceType.ts} for valid codes (100 codes) */
    serviceType?: CodeableConcept;
    /** Must Support */
    appointment?: Reference[];
    /** Must Support */
    length?: Duration;
    /** Must Support */
    diagnosis?: EncounterDiagnosis[];
    extension?: (Extension | CoverageInformation)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateEncounterExtension(resource: EncounterExtension, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
