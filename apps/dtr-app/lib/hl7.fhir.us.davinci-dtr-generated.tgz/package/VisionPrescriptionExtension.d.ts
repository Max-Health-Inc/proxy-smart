import { CoverageInformation } from "./CoverageInformation";
import { CodeableConcept, Extension, Identifier, Reference, SimpleQuantity, VisionPrescription, VisionPrescriptionLensSpecification } from "fhir/r4";
export interface VisionPrescriptionExtensionLensSpecification extends Omit<VisionPrescriptionLensSpecification, 'product' | 'duration'> {
    /** Must Support */
    product: CodeableConcept;
    /** Must Support */
    duration?: SimpleQuantity;
}
export interface VisionPrescriptionExtension extends Omit<VisionPrescription, 'identifier' | 'status' | 'patient' | 'encounter' | 'prescriber' | 'lensSpecification' | 'extension'> {
    /** Must Support */
    identifier?: Identifier[];
    status: "draft";
    /** Must Support */
    patient: Reference;
    /** Must Support */
    encounter?: Reference;
    /** Must Support */
    prescriber: Reference;
    /** Must Support */
    lensSpecification: VisionPrescriptionExtensionLensSpecification[];
    extension?: (Extension | CoverageInformation)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateVisionPrescriptionExtension(resource: VisionPrescriptionExtension, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
