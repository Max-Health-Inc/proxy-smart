import { CodeableConcept, Extension } from "fhir/r4";
export interface CompletionMode extends Omit<Extension, 'url' | 'value'> {
    url: "http://hl7.org/fhir/StructureDefinition/questionnaireresponse-completionMode";
    value: CodeableConcept;
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateCompletionMode(resource: CompletionMode, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
