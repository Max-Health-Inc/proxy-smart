import { EncounterDietCode } from "./valuesets/ValueSet-EncounterDiet";
import { CoverageInformation } from "./CoverageInformation";
import { CodeableConcept, Extension, Identifier, NutritionOrder, NutritionOrderEnteralFormula, NutritionOrderSupplement, Reference, SimpleQuantity } from "fhir/r4";
export interface NutritionOrderExtensionSupplement extends Omit<NutritionOrderSupplement, 'quantity'> {
    quantity?: SimpleQuantity;
}
export interface NutritionOrderExtensionEnteralFormula extends Omit<NutritionOrderEnteralFormula, 'caloricDensity' | 'maxVolumeToDeliver'> {
    caloricDensity?: SimpleQuantity;
    maxVolumeToDeliver?: SimpleQuantity;
}
export interface NutritionOrderExtension extends Omit<NutritionOrder, 'identifier' | 'status' | 'patient' | 'encounter' | 'orderer' | 'allergyIntolerance' | 'foodPreferenceModifier' | 'excludeFoodModifier' | 'supplement' | 'enteralFormula' | 'extension'> {
    /** Must Support */
    identifier?: Identifier[];
    status: "draft";
    /** Must Support */
    patient: Reference;
    /** Must Support */
    encounter?: Reference;
    /** Must Support */
    orderer: Reference;
    /** Must Support */
    allergyIntolerance?: Reference[];
    /** Must Support | @see {@link ./valuesets/ValueSet-EncounterDiet.ts} for valid codes (7 codes) */
    foodPreferenceModifier?: CodeableConcept & {
        coding: Array<{
            code: EncounterDietCode;
            system: "http://terminology.hl7.org/CodeSystem/diet";
        }>;
    }[];
    /** Must Support | @see {@link ./valuesets/ValueSet-FoodTypeCodes.ts} for valid codes (100 codes) */
    excludeFoodModifier?: CodeableConcept[];
    /** Must Support */
    supplement?: NutritionOrderExtensionSupplement[];
    /** Must Support */
    enteralFormula?: NutritionOrderExtensionEnteralFormula;
    extension?: (Extension | CoverageInformation)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateNutritionOrderExtension(resource: NutritionOrderExtension, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
