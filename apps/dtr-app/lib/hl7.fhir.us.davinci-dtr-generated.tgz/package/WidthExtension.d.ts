import { Extension } from "fhir/r4";
export interface WidthExtension extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-width";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateWidthExtension(resource: WidthExtension, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
