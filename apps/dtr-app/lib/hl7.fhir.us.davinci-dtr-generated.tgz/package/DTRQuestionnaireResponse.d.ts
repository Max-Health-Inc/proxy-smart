import { ContainedReference } from "./ContainedReference";
import { DisplayName } from "./DisplayName";
import { CoverageInformation } from "./CoverageInformation";
import { InformationOrigin } from "./InformationOrigin";
import { IntendedUse } from "./IntendedUse";
import { ItemAnswerMedia } from "./ItemAnswerMedia";
import { ItemMedia } from "./ItemMedia";
import { OrdinalValue } from "./OrdinalValue";
import { QuestionnaireResponseContext } from "./QuestionnaireResponseContext";
import { CompletionMode } from "./CompletionMode";
import { SignatureExtension } from "./SignatureExtension";
import { BackboneElement, Element, Extension, QuestionnaireResponse, Reference } from "fhir/r4";
export interface DTRQuestionnaireResponseQuestionnaireElement extends Omit<Element, 'extension'> {
    extension?: (Extension | DisplayName)[];
}
export interface DTRQuestionnaireResponseItem extends Omit<BackboneElement, 'extension' | 'answer'> {
    extension?: (Extension | ItemMedia | SignatureExtension)[];
    answer: DTRQuestionnaireResponseItemAnswer[];
}
export interface DTRQuestionnaireResponse extends Omit<QuestionnaireResponse, '_questionnaire' | 'questionnaire' | 'subject' | 'item' | 'extension'> {
    resourceType: 'QuestionnaireResponse';
    _questionnaire?: DTRQuestionnaireResponseQuestionnaireElement;
    /** Must Support */
    questionnaire: string;
    /** Must Support */
    subject: Reference;
    /** Must Support */
    item: DTRQuestionnaireResponseItem[];
    extension?: (Extension | SignatureExtension | CompletionMode | QuestionnaireResponseContext | CoverageInformation | IntendedUse)[];
}
export interface DTRQuestionnaireResponseItemAnswer extends Omit<BackboneElement, 'extension'> {
    extension?: (Extension | ItemAnswerMedia | OrdinalValue | InformationOrigin | ContainedReference)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateDTRQuestionnaireResponse(resource: DTRQuestionnaireResponse, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
