import { Coding, Extension } from "fhir/r4";
export interface UnitOption extends Omit<Extension, 'url' | 'value'> {
    url: "http://hl7.org/fhir/StructureDefinition/questionnaire-unitOption";
    value: Coding;
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateUnitOption(resource: UnitOption, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
