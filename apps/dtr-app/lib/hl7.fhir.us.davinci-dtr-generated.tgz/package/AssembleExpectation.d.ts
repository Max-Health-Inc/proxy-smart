import { Extension } from "fhir/r4";
export interface AssembleExpectation extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-assemble-expectation";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateAssembleExpectation(resource: AssembleExpectation, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
