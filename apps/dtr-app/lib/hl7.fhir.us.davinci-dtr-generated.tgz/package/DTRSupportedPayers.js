import fhirpath from "fhirpath";
import fhirpath_model from "fhirpath/fhir-context/r4/index.js";
import { isValidIdentifierUseCode } from './valuesets/ValueSet-IdentifierUse.js';
export async function validateDTRSupportedPayers(resource, options) {
    const errors = [];
    const warnings = [];
    const fhirpathOptions = {
        preciseMath: true,
        traceFn: options?.traceFn ?? (() => { }),
        ...(options?.signal ? { signal: options.signal } : {}),
        ...(options?.httpHeaders ? { httpHeaders: options.httpHeaders } : {}),
    };
    const result0 = await fhirpath.evaluate(resource, "payer.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result0.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    // Nested required field: payer.name (min=1)
    if (resource.payer && Array.isArray(resource.payer)) {
        for (const _el of resource.payer) {
            if ((_el.name === undefined || _el.name === null) || Array.isArray(_el.name)) {
                errors.push("Missing required member: 'name'");
            }
        }
    }
    // Nested required field: payer.identifier (min=1)
    if (resource.payer && Array.isArray(resource.payer)) {
        for (const _el of resource.payer) {
            if ((_el.identifier === undefined || _el.identifier === null) || Array.isArray(_el.identifier)) {
                errors.push("Missing required member: 'identifier'");
            }
        }
    }
    // Deeply nested required field: payer.identifier.system (min=1)
    if (resource.payer && Array.isArray(resource.payer)) {
        for (const _el of resource.payer) {
            const _e = _el;
            if (_e?.identifier && ((_e.identifier.system === undefined || _e.identifier.system === null) || Array.isArray(_e.identifier.system))) {
                errors.push("Missing required member: 'system'");
            }
        }
    }
    // Deeply nested required field: payer.identifier.value (min=1)
    if (resource.payer && Array.isArray(resource.payer)) {
        for (const _el of resource.payer) {
            const _e = _el;
            if (_e?.identifier && ((_e.identifier.value === undefined || _e.identifier.value === null) || Array.isArray(_e.identifier.value))) {
                errors.push("Missing required member: 'value'");
            }
        }
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const _bRes = resource;
    // Required ValueSet binding validation for payer.identifier.use (nested)
    if (resource.payer && Array.isArray(resource.payer)) {
        for (const _nb0 of resource.payer) {
            if (_nb0.identifier !== undefined) {
                if (_nb0.identifier.use !== undefined && !isValidIdentifierUseCode(_nb0.identifier.use)) {
                    errors.push("Code '" + _nb0.identifier.use + "' does not exist in the value set 'identifier-use' (http://hl7.org/fhir/ValueSet/identifier-use), but the binding is of strength 'required'");
                }
            }
        }
    }
    // Base FHIR structural validation: extension.url required, ext-1 constraint, empty objects
    {
        const _checkExtensions = (obj, path, depth) => {
            if (!obj || typeof obj !== 'object')
                return;
            if (Array.isArray(obj)) {
                obj.forEach((item, i) => _checkExtensions(item, path + '[' + i + ']', depth + 1));
                return;
            }
            const rec = obj;
            // Empty object check — HL7 validates all FHIR elements must have content
            if (depth > 0 && Object.keys(rec).length === 0) {
                errors.push('Object must have some content');
            }
            // per-1: If present, start SHALL have a lower value than end (Period structural check)
            if (typeof rec.start === 'string' && typeof rec.end === 'string' && rec.start > rec.end) {
                errors.push('If present, start SHALL have a lower value than end');
            }
            // Validate extension arrays
            for (const extKey of ['extension', 'modifierExtension']) {
                const exts = rec[extKey];
                if (Array.isArray(exts)) {
                    for (const ext of exts) {
                        if (ext && typeof ext === 'object' && !Array.isArray(ext)) {
                            const e = ext;
                            if (typeof e.url !== 'string' || !e.url) {
                                errors.push('Extension.url is required in order to identify, use and validate the extension');
                            }
                            // ext-1: Must have either extensions or value[x], not both
                            const hasNestedExt = Array.isArray(e.extension) && e.extension.length > 0;
                            const hasValue = Object.keys(e).some(k => k.startsWith('value') && k !== 'value' && k.length > 5);
                            if (hasNestedExt && hasValue) {
                                errors.push('Must have either extensions or value[x], not both');
                            }
                        }
                    }
                }
            }
            // Recurse into child objects (skip primitive values)
            for (const [_key, _val] of Object.entries(rec)) {
                if (_val && typeof _val === 'object') {
                    _checkExtensions(_val, path + '.' + _key, depth + 1);
                }
            }
        };
        _checkExtensions(resource, '', 0);
    }
    // Standalone contained reference resolution: verify #id references resolve to contained[] entries
    {
        const _res = resource;
        const _containedIds = new Set();
        if (Array.isArray(_res.contained)) {
            for (const _c of _res.contained) {
                if (_c && typeof _c.id === 'string')
                    _containedIds.add(_c.id);
            }
        }
        const _checkContainedRef = (obj) => {
            if (!obj || typeof obj !== 'object')
                return;
            if (Array.isArray(obj)) {
                obj.forEach(_checkContainedRef);
                return;
            }
            const _rec = obj;
            if (typeof _rec.reference === 'string') {
                const _ref = _rec.reference;
                if (_ref.startsWith('#')) {
                    const _id = _ref.substring(1);
                    if (_id && !_containedIds.has(_id)) {
                        errors.push('Contained reference not found: ' + _ref);
                    }
                }
            }
            for (const [_k, _v] of Object.entries(_rec)) {
                if (_k !== 'contained')
                    _checkContainedRef(_v);
            }
        };
        _checkContainedRef(_res);
    }
    return { errors, warnings };
}
