import { Extension } from "fhir/r4";
export interface PerformerTypeExtension extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-performerType";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePerformerTypeExtension(resource: PerformerTypeExtension, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
