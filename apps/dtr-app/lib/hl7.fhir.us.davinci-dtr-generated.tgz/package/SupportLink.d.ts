import { Extension } from "fhir/r4";
export interface SupportLink extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/StructureDefinition/questionnaire-supportLink";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateSupportLink(resource: SupportLink, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
