import { Extension } from "fhir/r4";
export interface ChoiceColumnExtension extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-choiceColumn";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateChoiceColumnExtension(resource: ChoiceColumnExtension, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
