import { Extension } from "fhir/r4";
export interface Hidden extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateHidden(resource: Hidden, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
