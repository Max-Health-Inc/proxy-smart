import { DTRMetricData } from "./DTRMetricData.js";
import type { ValidatorOptions } from "./ValidatorOptions.js";
export declare class DTRMetricDataClass {
    private resource;
    /** Pattern constraints for profile fields (used by random() generator) */
    protected static readonly _fieldPatterns: {
        "providerId.use": string;
        "providerId.type": string;
        "providerId.system": string;
        "groupId.use": string;
        "groupId.type": string;
        "groupId.system": string;
        "payerId.use": string;
        "payerId.type": string;
        "action.actionDetail": string;
        "action.issue.code": string;
        "action.issue.details": string;
        "resources.type": string;
        "questionnaire.failure": string;
        "questionnaire.roleInteraction.role": string;
        "questionnaire.roleInteraction.roleAction": string;
        "coverageInfo.covered": string;
        "coverageInfo.paNeeded": string;
        "coverageInfo.docNeeded": string;
        "coverageInfo.infoNeeded": string;
        _refReq_providerId: {
            system: boolean;
            value: boolean;
        };
        _refReq_groupId: {
            system: boolean;
            value: boolean;
        };
        _refReq_payerId: {
            system: boolean;
            value: boolean;
        };
        _refReq_action: {
            actionDetail: boolean;
            requestTime: boolean;
            "issue.code": boolean;
        };
        _refReq_resources: {
            type: boolean;
            count: boolean;
        };
        _refReq_questionnaire: {
            reference: boolean;
            "roleInteraction.role": boolean;
            "roleInteraction.roleAction": boolean;
            "roleInteraction.count": boolean;
            elapsedTime: boolean;
        };
        _refReq_coverageInfo: {
            "questionnaire.reference": boolean;
            "questionnaire.adaptive": boolean;
            "questionnaire.response": boolean;
            assertionId: boolean;
        };
    };
    /** Fields that are forbidden (max=0) in this profile - must not be generated */
    protected static readonly _forbiddenFields: string[];
    /** FHIR element ordering for this profile's base resource (used by enrichResource for correct JSON field order) */
    protected static readonly _fieldOrder: string[];
    /** ValueSet bindings for coded fields - maps field name to ValueSet URL */
    static readonly valueSetBindings: Record<string, string>;
    /** Code resolver for ValueSet bindings - returns a random valid code from a ValueSet by URL */
    protected static readonly _codeResolver: ((url: string) => {
        code: string;
        system: string;
        display?: string;
    } | undefined) | undefined;
    constructor(resource: DTRMetricData);
    /** Validate current resource instance. */
    validate(options?: ValidatorOptions): Promise<{
        errors: string[];
        warnings: string[];
    }>;
    getResource(): DTRMetricData;
    setResource(resource: DTRMetricData): void;
    /**
     * Returns a plain JSON clone of the underlying resource ONLY if the last validation succeeded with zero errors.
     * Call validate() first; otherwise this method throws to prevent accidental use of invalid / unchecked data.
     */
    toJSON(): Promise<DTRMetricData>;
    /**
     * Create an empty instance for parity testing: for true FHIR resources, includes only resourceType; for datatypes, returns an empty object.
     * Note: meta.profile (when applicable) will be ensured by the constructor when wrapping this resource.
     */
    static empty(overrides?: Partial<DTRMetricData>): DTRMetricData;
    /**
     * Create a minimal randomized instance of DTRMetricData.
     * Populates id, resourceType (if applicable) and primitive required (min>0) top-level fields with placeholders.
     */
    static random(overrides?: Partial<DTRMetricData>, opts?: {
        seed?: number;
    }): DTRMetricData;
    /** Convenience: returns a class instance wrapping a randomized resource. */
    static randomClass(overrides?: Partial<DTRMetricData>, opts?: {
        seed?: number;
    }): DTRMetricDataClass;
}
