import { Expression, Extension } from "fhir/r4";
export interface ExpressionExtension extends Omit<Extension, 'url' | 'value'> {
    url: "http://hl7.org/fhir/StructureDefinition/cqf-expression";
    value: Expression;
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateExpressionExtension(resource: ExpressionExtension, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
