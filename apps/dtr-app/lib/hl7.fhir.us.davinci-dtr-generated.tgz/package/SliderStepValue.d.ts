import { Extension } from "fhir/r4";
export interface SliderStepValue extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/StructureDefinition/questionnaire-sliderStepValue";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateSliderStepValue(resource: SliderStepValue, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
