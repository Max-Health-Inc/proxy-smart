import { Extension } from "fhir/r4";
export interface StyleSensitive extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/StructureDefinition/rendering-styleSensitive";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateStyleSensitive(resource: StyleSensitive, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
