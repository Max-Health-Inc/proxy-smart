import { Extension } from "fhir/r4";
export interface InformationOrigin extends Omit<Extension, 'extension' | 'url'> {
    extension: Extension[];
    url: "http://hl7.org/fhir/us/davinci-dtr/StructureDefinition/information-origin";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateInformationOrigin(resource: InformationOrigin, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
