import { Extension } from "fhir/r4";
export interface EnableWhenExpressionExtension extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateEnableWhenExpressionExtension(resource: EnableWhenExpressionExtension, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
