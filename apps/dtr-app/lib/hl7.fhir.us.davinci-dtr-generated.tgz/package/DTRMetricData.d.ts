import { IdentifierTypeCode } from "./valuesets/ValueSet-IdentifierType";
import { IssueTypeCode } from "./valuesets/ValueSet-IssueType";
import { OperationOutcomeCode } from "./valuesets/ValueSet-OperationOutcome";
import { OrderDetailCode } from "./valuesets/ValueSet-OrderDetail";
import { BackboneElement, CodeableConcept, Extension, Identifier, Period, Reference } from "fhir/r4";
export interface DTRMetricDataProviderId extends Omit<Identifier, 'extension' | 'type' | 'system' | 'value' | 'period' | 'assigner'> {
    extension?: Extension[];
    /** @see {@link ./valuesets/ValueSet-IdentifierType.ts} for valid codes (18 codes) */
    type?: CodeableConcept & {
        coding: Array<{
            code: IdentifierTypeCode;
            system: "http://terminology.hl7.org/CodeSystem/v2-0203";
        }>;
    };
    system: "http://hl7.org/fhir/sid/us-npi";
    value: string;
    period?: Period;
    assigner?: Reference;
}
export interface DTRMetricDataGroupId extends Omit<Identifier, 'extension' | 'type' | 'system' | 'value' | 'period' | 'assigner'> {
    extension?: Extension[];
    /** @see {@link ./valuesets/ValueSet-IdentifierType.ts} for valid codes (18 codes) */
    type?: CodeableConcept & {
        coding: Array<{
            code: IdentifierTypeCode;
            system: "http://terminology.hl7.org/CodeSystem/v2-0203";
        }>;
    };
    system: "http://hl7.org/fhir/sid/us-npi";
    value: string;
    period?: Period;
    assigner?: Reference;
}
export interface DTRMetricDataPayerId extends Omit<Identifier, 'extension' | 'type' | 'system' | 'value' | 'period' | 'assigner'> {
    extension?: Extension[];
    /** @see {@link ./valuesets/ValueSet-IdentifierType.ts} for valid codes (18 codes) */
    type?: CodeableConcept & {
        coding: Array<{
            code: IdentifierTypeCode;
            system: "http://terminology.hl7.org/CodeSystem/v2-0203";
        }>;
    };
    system: string;
    value: string;
    period?: Period;
    assigner?: Reference;
}
export interface DTRMetricDataActionIssue extends Omit<BackboneElement, 'id' | 'extension' | 'modifierExtension' | 'code' | 'details'> {
    id?: string;
    extension?: Extension[];
    modifierExtension?: Extension[];
    /** @see {@link ./valuesets/ValueSet-IssueType.ts} for valid codes (31 codes) */
    code: string;
    /** @see {@link ./valuesets/ValueSet-OperationOutcome.ts} for valid codes (50 codes) */
    details?: CodeableConcept & {
        coding: Array<{
            code: OperationOutcomeCode;
            system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
        }>;
    };
}
export interface DTRMetricDataAction extends Omit<BackboneElement, 'id' | 'extension' | 'modifierExtension' | 'actionDetail' | 'requestTime' | 'responseTime' | 'httpResponse' | 'questionnaire' | 'issue'> {
    id?: string;
    extension?: Extension[];
    modifierExtension?: Extension[];
    /** @see {@link ./valuesets/ValueSet-MetricAction.ts} for valid codes (6 codes) */
    actionDetail: string;
    requestTime: string;
    responseTime?: string;
    httpResponse?: number;
    questionnaire?: string;
    issue?: DTRMetricDataActionIssue;
}
export interface DTRMetricDataResources extends Omit<BackboneElement, 'id' | 'extension' | 'modifierExtension' | 'type' | 'profile' | 'count'> {
    id?: string;
    extension?: Extension[];
    modifierExtension?: Extension[];
    /** @see {@link ./valuesets/ValueSet-ResourceTypes.ts} for valid codes (148 codes) */
    type: string;
    profile?: string;
    count: number;
}
export interface DTRMetricDataQuestionnaireRoleInteraction extends Omit<BackboneElement, 'id' | 'extension' | 'modifierExtension' | 'role' | 'roleAction' | 'count'> {
    id?: string;
    extension?: Extension[];
    modifierExtension?: Extension[];
    /** @see {@link ./valuesets/ValueSet-UsCoreProviderRole.ts} for valid codes (237 codes) */
    role: CodeableConcept;
    /** @see {@link ./valuesets/ValueSet-MetricsInformationOrigins.ts} for valid codes (2 codes) */
    roleAction: string;
    count: number;
}
export interface DTRMetricDataQuestionnaire extends Omit<BackboneElement, 'id' | 'extension' | 'modifierExtension' | 'reference' | 'adaptive' | 'populated' | 'failure' | 'reviewPrior' | 'enabledQuestions' | 'autoPopulated' | 'roleInteraction' | 'elapsedTime'> {
    id?: string;
    extension?: Extension[];
    modifierExtension?: Extension[];
    reference: string;
    adaptive?: boolean;
    populated?: boolean;
    /** @see {@link ./valuesets/ValueSet-IssueType.ts} for valid codes (31 codes) */
    failure?: CodeableConcept & {
        coding: Array<{
            code: IssueTypeCode;
            system: "http://hl7.org/fhir/issue-type";
        }>;
    };
    reviewPrior?: boolean;
    enabledQuestions?: number;
    autoPopulated?: number;
    roleInteraction?: DTRMetricDataQuestionnaireRoleInteraction;
    elapsedTime: string;
}
export interface DTRMetricDataCoverageInfoQuestionnaire extends Omit<BackboneElement, 'id' | 'extension' | 'modifierExtension' | 'reference' | 'adaptive' | 'response'> {
    id?: string;
    extension?: Extension[];
    modifierExtension?: Extension[];
    reference: string;
    adaptive: boolean;
    response: boolean;
}
export interface DTRMetricDataCoverageInfo extends Omit<BackboneElement, 'id' | 'extension' | 'modifierExtension' | 'covered' | 'paNeeded' | 'docNeeded' | 'infoNeeded' | 'questionnaire' | 'assertionId' | 'satisfiedId' | 'businessLine'> {
    id?: string;
    extension?: Extension[];
    modifierExtension?: Extension[];
    /** @see {@link ./valuesets/ValueSet-CoverageInfo.ts} for valid codes (3 codes) */
    covered?: string;
    /** @see {@link ./valuesets/ValueSet-CoveragePaDetail.ts} for valid codes (5 codes) */
    paNeeded?: string;
    /** @see {@link ./valuesets/ValueSet-AdditionalDocumentation.ts} for valid codes (4 codes) */
    docNeeded?: string;
    /** @see {@link ./valuesets/ValueSet-InformationNeeded.ts} for valid codes (5 codes) */
    infoNeeded?: string;
    questionnaire?: DTRMetricDataCoverageInfoQuestionnaire;
    assertionId: string;
    satisfiedId?: string;
    businessLine?: CodeableConcept;
}
export interface DTRMetricData {
    /** @see {@link ./valuesets/ValueSet-MetricSource.ts} for valid codes (3 codes) */
    source: string;
    sofApp?: string;
    providerId: DTRMetricDataProviderId;
    groupId: DTRMetricDataGroupId;
    payerId: DTRMetricDataPayerId;
    assertionId?: string[];
    /** @see {@link ./valuesets/ValueSet-DocReason.ts} for valid codes (5 codes) */
    docReason?: string[];
    /** @see {@link ./valuesets/ValueSet-MetricLaunchMode.ts} for valid codes (4 codes) */
    launchMode?: string;
    /** @see {@link ./valuesets/ValueSet-OrderDetail.ts} for valid codes (33 codes) */
    orderItem: CodeableConcept & {
        coding: Array<{
            code: OrderDetailCode;
        }>;
    }[];
    action: DTRMetricDataAction[];
    resources?: DTRMetricDataResources[];
    questionnaire?: DTRMetricDataQuestionnaire[];
    coverageInfo?: DTRMetricDataCoverageInfo[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateDTRMetricData(resource: DTRMetricData, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
