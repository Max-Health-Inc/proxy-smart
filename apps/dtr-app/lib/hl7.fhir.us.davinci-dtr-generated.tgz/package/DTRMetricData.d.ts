import { IdentifierTypeCodesCode } from "./valuesets/ValueSet-IdentifierTypeCodes";
import { IssueTypeCode } from "./valuesets/ValueSet-IssueType";
import { OperationOutcomeCodesCode } from "./valuesets/ValueSet-OperationOutcomeCodes";
import { OrderDetailCode } from "./valuesets/ValueSet-OrderDetail";
import { BackboneElement, CodeableConcept, Extension, Identifier, Period, Reference } from "fhir/r4";
export interface DTRMetricDataProviderId extends Omit<Identifier, 'extension' | 'type' | 'system' | 'value' | 'period' | 'assigner'> {
    extension?: Extension[];
    /** @see {@link ./valuesets/ValueSet-IdentifierTypeCodes.ts} for valid codes (18 codes) */
    type?: CodeableConcept & {
        coding: Array<{
            code: IdentifierTypeCodesCode;
            system: "http://terminology.hl7.org/CodeSystem/v2-0203";
        }>;
    };
    system: "http://hl7.org/fhir/sid/us-npi";
    value: string;
    period?: Period;
    assigner?: Reference;
}
export interface DTRMetricDataGroupId extends Omit<Identifier, 'extension' | 'type' | 'system' | 'value' | 'period' | 'assigner'> {
    extension?: Extension[];
    /** @see {@link ./valuesets/ValueSet-IdentifierTypeCodes.ts} for valid codes (18 codes) */
    type?: CodeableConcept & {
        coding: Array<{
            code: IdentifierTypeCodesCode;
            system: "http://terminology.hl7.org/CodeSystem/v2-0203";
        }>;
    };
    system: "http://hl7.org/fhir/sid/us-npi";
    value: string;
    period?: Period;
    assigner?: Reference;
}
export interface DTRMetricDataPayerId extends Omit<Identifier, 'extension' | 'type' | 'system' | 'value' | 'period' | 'assigner'> {
    extension?: Extension[];
    /** @see {@link ./valuesets/ValueSet-IdentifierTypeCodes.ts} for valid codes (18 codes) */
    type?: CodeableConcept & {
        coding: Array<{
            code: IdentifierTypeCodesCode;
            system: "http://terminology.hl7.org/CodeSystem/v2-0203";
        }>;
    };
    system: string;
    value: string;
    period?: Period;
    assigner?: Reference;
}
export interface DTRMetricDataActionIssue extends Omit<BackboneElement, 'id' | 'extension' | 'modifierExtension' | 'code' | 'details'> {
    id?: string;
    extension?: Extension[];
    modifierExtension?: Extension[];
    /** @see {@link ./valuesets/ValueSet-IssueType.ts} for valid codes (5 codes) */
    code: string;
    /** @see {@link ./valuesets/ValueSet-OperationOutcomeCodes.ts} for valid codes (50 codes) */
    details?: CodeableConcept & {
        coding: Array<{
            code: OperationOutcomeCodesCode;
            system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
        }>;
    };
}
export interface DTRMetricDataAction extends Omit<BackboneElement, 'id' | 'extension' | 'modifierExtension' | 'actionDetail' | 'requestTime' | 'responseTime' | 'httpResponse' | 'questionnaire' | 'issue'> {
    id?: string;
    extension?: Extension[];
    modifierExtension?: Extension[];
    /** @see {@link ./valuesets/ValueSet-MetricAction.ts} for valid codes (6 codes) */
    actionDetail: string;
    requestTime: string;
    responseTime?: string;
    httpResponse?: number;
    questionnaire?: string;
    issue?: DTRMetricDataActionIssue;
}
export interface DTRMetricDataResources extends Omit<BackboneElement, 'id' | 'extension' | 'modifierExtension' | 'type' | 'profile' | 'count'> {
    id?: string;
    extension?: Extension[];
    modifierExtension?: Extension[];
    /** @see {@link ./valuesets/ValueSet-ResourceType.ts} for valid codes (100 codes) */
    type: string;
    profile?: string;
    count: number;
}
export interface DTRMetricDataQuestionnaireRoleInteraction extends Omit<BackboneElement, 'id' | 'extension' | 'modifierExtension' | 'role' | 'roleAction' | 'count'> {
    id?: string;
    extension?: Extension[];
    modifierExtension?: Extension[];
    /** @see {@link ./valuesets/ValueSet-UsCoreProviderRole.ts} for valid codes (237 codes) */
    role: CodeableConcept;
    /** @see {@link ./valuesets/ValueSet-MetricsInformationOrigins.ts} for valid codes (2 codes) */
    roleAction: string;
    count: number;
}
export interface DTRMetricDataQuestionnaire extends Omit<BackboneElement, 'id' | 'extension' | 'modifierExtension' | 'reference' | 'adaptive' | 'populated' | 'failure' | 'reviewPrior' | 'enabledQuestions' | 'autoPopulated' | 'roleInteraction' | 'elapsedTime'> {
    id?: string;
    extension?: Extension[];
    modifierExtension?: Extension[];
    reference: string;
    adaptive?: boolean;
    populated?: boolean;
    /** @see {@link ./valuesets/ValueSet-IssueType.ts} for valid codes (5 codes) */
    failure?: CodeableConcept & {
        coding: Array<{
            code: IssueTypeCode;
            system: "http://hl7.org/fhir/issue-type";
        }>;
    };
    reviewPrior?: boolean;
    enabledQuestions?: number;
    autoPopulated?: number;
    roleInteraction?: DTRMetricDataQuestionnaireRoleInteraction;
    elapsedTime: string;
}
export interface DTRMetricDataCoverageInfoQuestionnaire extends Omit<BackboneElement, 'id' | 'extension' | 'modifierExtension' | 'reference' | 'adaptive' | 'response'> {
    id?: string;
    extension?: Extension[];
    modifierExtension?: Extension[];
    reference: string;
    adaptive: boolean;
    response: boolean;
}
export interface DTRMetricDataCoverageInfo extends Omit<BackboneElement, 'id' | 'extension' | 'modifierExtension' | 'covered' | 'paNeeded' | 'docNeeded' | 'infoNeeded' | 'questionnaire' | 'assertionId' | 'satisfiedId' | 'businessLine'> {
    id?: string;
    extension?: Extension[];
    modifierExtension?: Extension[];
    /** @see {@link ./valuesets/ValueSet-CoverageInfo.ts} for valid codes (3 codes) */
    covered?: string;
    /** @see {@link ./valuesets/ValueSet-CoveragePaDetail.ts} for valid codes (5 codes) */
    paNeeded?: string;
    /** @see {@link ./valuesets/ValueSet-AdditionalDocumentation.ts} for valid codes (4 codes) */
    docNeeded?: string;
    /** @see {@link ./valuesets/ValueSet-InformationNeeded.ts} for valid codes (5 codes) */
    infoNeeded?: string;
    questionnaire?: DTRMetricDataCoverageInfoQuestionnaire;
    assertionId: string;
    satisfiedId?: string;
    businessLine?: CodeableConcept;
}
export interface DTRMetricData {
    /** @see {@link ./valuesets/ValueSet-MetricSource.ts} for valid codes (3 codes) */
    source: string;
    sofApp?: string;
    providerId: DTRMetricDataProviderId;
    groupId: DTRMetricDataGroupId;
    payerId: DTRMetricDataPayerId;
    assertionId?: string[];
    /** @see {@link ./valuesets/ValueSet-DocReason.ts} for valid codes (5 codes) */
    docReason?: string[];
    /** @see {@link ./valuesets/ValueSet-MetricLaunchMode.ts} for valid codes (4 codes) */
    launchMode?: string;
    /** @see {@link ./valuesets/ValueSet-OrderDetail.ts} for valid codes (31 codes) */
    orderItem: CodeableConcept & {
        coding: Array<{
            code: OrderDetailCode;
            system: "http://loinc.org";
        }>;
    }[];
    action: DTRMetricDataAction[];
    resources?: DTRMetricDataResources[];
    questionnaire?: DTRMetricDataQuestionnaire[];
    coverageInfo?: DTRMetricDataCoverageInfo[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateDTRMetricData(resource: DTRMetricData, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
