import { Extension } from "fhir/r4";
export interface LibraryExtension extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/StructureDefinition/cqf-library";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateLibraryExtension(resource: LibraryExtension, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
