import { Extension } from "fhir/r4";
export interface Xhtml extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/StructureDefinition/rendering-xhtml";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateXhtml(resource: Xhtml, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
