import { Extension } from "fhir/r4";
export interface MaxQuantityExtension extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-maxQuantity";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateMaxQuantityExtension(resource: MaxQuantityExtension, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
