import { BackboneElement, CodeableConcept, Extension, Identifier, Period, Reference } from "fhir/r4";
export interface DTRSupportedPayersPayer extends Omit<BackboneElement, 'id' | 'extension' | 'modifierExtension' | 'name' | 'identifier' | 'type' | 'value' | 'period' | 'assigner'> {
    id?: string;
    extension?: Extension[];
    modifierExtension?: Extension[];
    name: string;
    identifier: Identifier;
    /** @see {@link ./valuesets/ValueSet-IdentifierType.ts} for valid codes (18 codes) */
    type?: CodeableConcept;
    value: string;
    period?: Period;
    assigner?: Reference;
}
export interface DTRSupportedPayers {
    payer?: DTRSupportedPayersPayer[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateDTRSupportedPayers(resource: DTRSupportedPayers, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
