import { validateDTRStdQuestionnaire } from "./DTRStdQuestionnaire.js";
// Only import helpers actually referenced below (dynamic based on required fields)
import { randomId, setRandomSeed, enrichResource } from "./random/index.js";
import { createRequire } from 'module';
const __require = createRequire(import.meta.url);
function ensureProfile(res, profile) {
    if (!res.meta) {
        res.meta = { profile: [profile] };
        return;
    }
    if (!res.meta.profile) {
        res.meta.profile = [profile];
        return;
    }
    if (!res.meta.profile.includes(profile)) {
        res.meta.profile = [...res.meta.profile, profile];
    }
}
// Internal helper (emitted per class file) to clone without resorting to 'any'.
function safeClone(value) {
    // Use native structuredClone if present; otherwise fallback to JSON round-trip.
    // We intentionally avoid casting through any to satisfy no-explicit-any lint rule.
    const g = globalThis;
    // Narrow globalThis to an object potentially containing structuredClone.
    if (typeof g.structuredClone === 'function') {
        return g.structuredClone(value);
    }
    return JSON.parse(JSON.stringify(value)); // best-effort deep clone
}
export class DTRStdQuestionnaireClass {
    constructor(resource) {
        this.resource = resource;
        ensureProfile(this.resource, 'http://hl7.org/fhir/us/davinci-dtr/StructureDefinition/dtr-std-questionnaire');
    }
    /** Validate current resource instance. */
    async validate(options) {
        return validateDTRStdQuestionnaire(this.resource, options);
    }
    getResource() {
        return this.resource;
    }
    setResource(resource) {
        this.resource = resource;
        ensureProfile(this.resource, 'http://hl7.org/fhir/us/davinci-dtr/StructureDefinition/dtr-std-questionnaire');
    }
    /**
     * Returns a plain JSON clone of the underlying resource ONLY if the last validation succeeded with zero errors.
     * Call validate() first; otherwise this method throws to prevent accidental use of invalid / unchecked data.
     */
    async toJSON() {
        return safeClone(this.resource);
    }
    /**
     * Create an empty instance for parity testing: for true FHIR resources, includes only resourceType; for datatypes, returns an empty object.
     * Note: meta.profile (when applicable) will be ensured by the constructor when wrapping this resource.
     */
    static empty(overrides = {}) {
        // For Resource profiles, include only resourceType. For Extension profiles, include url so the instance is minimally meaningful.
        const base = {
            resourceType: 'Questionnaire',
        };
        return { ...base, ...overrides };
    }
    /**
     * Create a minimal randomized instance of DTRStdQuestionnaire.
     * Populates id, resourceType (if applicable) and primitive required (min>0) top-level fields with placeholders.
     */
    static random(overrides = {}, opts) {
        if (opts?.seed !== undefined) {
            // Direct call (no dynamic require) to ensure deterministic seeding works under ESM.
            setRandomSeed(opts.seed);
        }
        // Start with a Partial to avoid unsafe casting errors; we'll assert at the end.
        const base = { resourceType: 'Questionnaire', id: randomId(), text: { status: "generated", div: "<div xmlns=\"http://www.w3.org/1999/xhtml\">Generated content</div>" }, url: 'https://babelfhir.dev/' + randomId(), status: "retired", subjectType: ["Patient"], };
        // Always include meta.profile with this profile's canonical URL if available & only for resource profiles
        ensureProfile(base, 'http://hl7.org/fhir/us/davinci-dtr/StructureDefinition/dtr-std-questionnaire');
        // Enrich the base resource with common fields using centralized enrichment logic
        enrichResource(base, 'Questionnaire', 'http://hl7.org/fhir/us/davinci-dtr/StructureDefinition/dtr-std-questionnaire', DTRStdQuestionnaireClass._fieldPatterns, DTRStdQuestionnaireClass._forbiddenFields, DTRStdQuestionnaireClass.valueSetBindings, DTRStdQuestionnaireClass._codeResolver, DTRStdQuestionnaireClass._fieldOrder);
        // Cast through unknown to acknowledge dynamic enrichment
        return { ...base, ...overrides };
    }
    /** Convenience: returns a class instance wrapping a randomized resource. */
    static randomClass(overrides = {}, opts) {
        return new DTRStdQuestionnaireClass(this.random(overrides, opts));
    }
}
/** Pattern constraints for profile fields (used by random() generator) */
DTRStdQuestionnaireClass._fieldPatterns = {
    "text.status": "generated",
    "styleSensitive.url": "http://hl7.org/fhir/StructureDefinition/rendering-styleSensitive",
    "cqf-library.url": "http://hl7.org/fhir/StructureDefinition/cqf-library",
    "subjectType": "Patient",
    "item.code": "11506-3",
    "item.type": "decimal",
    "item.enableWhen.operator": "exists",
    "item.enableWhen": "75367002",
    "item.enableBehavior": "any",
    "item.answerOption": "75367002",
    "item.initial": "75367002",
    "_refReq_text": {
        "status": true,
        "div": true
    },
    "_refReq_extension": {
        "url": true,
        "valueBoolean": true,
        "valueCanonical": true
    },
    "_refReq_item": {
        "linkId": true,
        "type": true,
        "enableWhen.question": true,
        "enableWhen.operator": true,
        "enableWhen.answerBoolean": true,
        "answerOption.valueInteger": true,
        "initial.valueBoolean": true
    }
};
/** Fields that are forbidden (max=0) in this profile - must not be generated */
DTRStdQuestionnaireClass._forbiddenFields = ["extension.extension"];
/** FHIR element ordering for this profile's base resource (used by enrichResource for correct JSON field order) */
DTRStdQuestionnaireClass._fieldOrder = ["id", "meta", "implicitRules", "language", "text", "contained", "extension", "modifierExtension", "url", "identifier", "version", "name", "title", "derivedFrom", "status", "experimental", "subjectType", "date", "publisher", "contact", "description", "useContext", "jurisdiction", "purpose", "copyright", "approvalDate", "lastReviewDate", "effectivePeriod", "code", "item"];
/** ValueSet bindings for coded fields - maps field name to ValueSet URL */
DTRStdQuestionnaireClass.valueSetBindings = {
    "language": "http://hl7.org/fhir/ValueSet/languages",
    "text.status": "http://hl7.org/fhir/ValueSet/narrative-status|4.0.1",
    "status": "http://hl7.org/fhir/ValueSet/publication-status|4.0.1",
    "subjectType": "http://hl7.org/fhir/ValueSet/resource-types|4.0.1",
    "jurisdiction": "http://hl7.org/fhir/ValueSet/jurisdiction",
    "code": "http://hl7.org/fhir/ValueSet/questionnaire-questions",
    "item.code": "http://hl7.org/fhir/ValueSet/questionnaire-questions",
    "item.type": "http://hl7.org/fhir/ValueSet/item-type|4.0.1",
    "item.enableWhen.operator": "http://hl7.org/fhir/ValueSet/questionnaire-enable-operator|4.0.1",
    "item.enableWhen.answer[x]": "http://hl7.org/fhir/ValueSet/questionnaire-answers",
    "item.enableBehavior": "http://hl7.org/fhir/ValueSet/questionnaire-enable-behavior|4.0.1",
    "item.answerOption.value[x]": "http://hl7.org/fhir/ValueSet/questionnaire-answers",
    "item.initial.value[x]": "http://hl7.org/fhir/ValueSet/questionnaire-answers"
};
/** Code resolver for ValueSet bindings - returns a random valid code from a ValueSet by URL */
DTRStdQuestionnaireClass._codeResolver = (() => {
    // Try to load the ValueSetRegistry - it may not exist if no ValueSets were generated
    try {
        const registry = __require('./valuesets/index.js');
        if (registry && typeof registry.getRandomConceptByUrl === 'function') {
            return registry.getRandomConceptByUrl;
        }
    }
    catch { /* ValueSetRegistry not available */ }
    return undefined;
})();
