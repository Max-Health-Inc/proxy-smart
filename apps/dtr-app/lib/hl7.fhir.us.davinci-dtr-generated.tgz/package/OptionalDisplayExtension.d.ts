import { Extension } from "fhir/r4";
export interface OptionalDisplayExtension extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-optionalDisplay";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateOptionalDisplayExtension(resource: OptionalDisplayExtension, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
