import { Extension } from "fhir/r4";
export interface OptionExclusive extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/StructureDefinition/questionnaire-optionExclusive";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateOptionExclusive(resource: OptionExclusive, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
