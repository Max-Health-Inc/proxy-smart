import { Extension } from "fhir/r4";
export interface MaxSize extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/StructureDefinition/maxSize";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateMaxSize(resource: MaxSize, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
