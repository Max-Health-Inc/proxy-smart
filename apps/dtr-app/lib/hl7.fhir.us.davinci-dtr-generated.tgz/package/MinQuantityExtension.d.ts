import { Extension } from "fhir/r4";
export interface MinQuantityExtension extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-minQuantity";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateMinQuantityExtension(resource: MinQuantityExtension, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
