import { Extension } from "fhir/r4";
export interface CoverageInformation extends Omit<Extension, 'extension' | 'url'> {
    extension: Extension[];
    url: "http://hl7.org/fhir/us/davinci-crd/StructureDefinition/ext-coverage-information";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateCoverageInformation(resource: CoverageInformation, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
