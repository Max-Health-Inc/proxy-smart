import { Extension } from "fhir/r4";
export interface MinOccurs extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/StructureDefinition/questionnaire-minOccurs";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateMinOccurs(resource: MinOccurs, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
