import { Extension } from "fhir/r4";
export interface ItemAnswerMedia extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-itemAnswerMedia";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateItemAnswerMedia(resource: ItemAnswerMedia, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
