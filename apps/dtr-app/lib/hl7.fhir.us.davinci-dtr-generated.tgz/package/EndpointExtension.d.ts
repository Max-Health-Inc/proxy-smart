import { Extension } from "fhir/r4";
export interface EndpointExtension extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-endpoint";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateEndpointExtension(resource: EndpointExtension, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
