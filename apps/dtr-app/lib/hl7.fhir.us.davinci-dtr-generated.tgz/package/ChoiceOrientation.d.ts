import { Extension } from "fhir/r4";
export interface ChoiceOrientation extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateChoiceOrientation(resource: ChoiceOrientation, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
