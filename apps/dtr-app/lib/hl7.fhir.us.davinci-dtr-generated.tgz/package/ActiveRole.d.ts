import { Extension } from "fhir/r4";
export interface ActiveRole extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/us/davinci-dtr/StructureDefinition/activeRole";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateActiveRole(resource: ActiveRole, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
