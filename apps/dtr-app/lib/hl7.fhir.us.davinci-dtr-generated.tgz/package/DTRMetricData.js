import fhirpath from "fhirpath";
import fhirpath_model from "fhirpath/fhir-context/r4/index.js";
import { isValidMetricSourceCode } from './valuesets/ValueSet-MetricSource.js';
import { isValidDocReasonCode } from './valuesets/ValueSet-DocReason.js';
import { isValidMetricLaunchModeCode } from './valuesets/ValueSet-MetricLaunchMode.js';
import { isValidMetricActionCode } from './valuesets/ValueSet-MetricAction.js';
import { isValidCoverageInfoCode } from './valuesets/ValueSet-CoverageInfo.js';
import { isValidCoveragePaDetailCode } from './valuesets/ValueSet-CoveragePaDetail.js';
import { isValidAdditionalDocumentationCode } from './valuesets/ValueSet-AdditionalDocumentation.js';
import { isValidInformationNeededCode } from './valuesets/ValueSet-InformationNeeded.js';
export async function validateDTRMetricData(resource, options) {
    const errors = [];
    const warnings = [];
    const fhirpathOptions = {
        preciseMath: true,
        traceFn: options?.traceFn ?? (() => { }),
        ...(options?.signal ? { signal: options.signal } : {}),
        ...(options?.httpHeaders ? { httpHeaders: options.httpHeaders } : {}),
        async: true,
        ...(options?.terminologyUrl ? { terminologyUrl: options.terminologyUrl } : {}),
        ...(options?.fhirServerUrl ? { fhirServerUrl: options.fhirServerUrl } : {}),
    };
    const result0 = await fhirpath.evaluate(resource, "providerId.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result0.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result1 = await fhirpath.evaluate(resource, "groupId.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result1.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result2 = await fhirpath.evaluate(resource, "payerId.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result2.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result3 = await fhirpath.evaluate(resource, "action.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result3.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result4 = await fhirpath.evaluate(resource, "resources.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result4.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result5 = await fhirpath.evaluate(resource, "questionnaire.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result5.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result6 = await fhirpath.evaluate(resource, "coverageInfo.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result6.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result7 = await fhirpath.evaluate(resource, "source.exists()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result7.every(Boolean)) {
        errors.push("Constraint violation: source must be present");
    }
    const result8 = await fhirpath.evaluate(resource, "providerId.exists()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result8.every(Boolean)) {
        errors.push("Constraint violation: providerId must be present");
    }
    const result9 = await fhirpath.evaluate(resource, "groupId.exists()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result9.every(Boolean)) {
        errors.push("Constraint violation: groupId must be present");
    }
    const result10 = await fhirpath.evaluate(resource, "payerId.exists()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result10.every(Boolean)) {
        errors.push("Constraint violation: payerId must be present");
    }
    const result11 = await fhirpath.evaluate(resource, "orderItem.count() >= 1", { resource }, fhirpath_model, fhirpathOptions);
    if (!result11.every(Boolean)) {
        errors.push("Constraint violation: orderItem must contain at least one element");
    }
    const result12 = await fhirpath.evaluate(resource, "action.count() >= 1", { resource }, fhirpath_model, fhirpathOptions);
    if (!result12.every(Boolean)) {
        errors.push("Constraint violation: action must contain at least one element");
    }
    if (options?.terminologyUrl) {
        const result13 = await fhirpath.evaluate(resource, "action.issue.code.all(memberOf('http://hl7.org/fhir/ValueSet/issue-type'))", { resource }, fhirpath_model, fhirpathOptions);
        if (!result13.every(Boolean)) {
            errors.push("Constraint violation: The value provided must be in the value set 'issue-type' (http://hl7.org/fhir/ValueSet/issue-type)");
        }
    }
    else {
        warnings.push("Constraint not evaluated (no terminologyUrl): The value provided must be in the value set 'issue-type' (http://hl7.org/fhir/ValueSet/issue-type)");
    }
    if (options?.terminologyUrl) {
        const result14 = await fhirpath.evaluate(resource, "resources.type.all(memberOf('http://hl7.org/fhir/ValueSet/resource-types'))", { resource }, fhirpath_model, fhirpathOptions);
        if (!result14.every(Boolean)) {
            errors.push("Constraint violation: The value provided must be in the value set 'resource-types' (http://hl7.org/fhir/ValueSet/resource-types)");
        }
    }
    else {
        warnings.push("Constraint not evaluated (no terminologyUrl): The value provided must be in the value set 'resource-types' (http://hl7.org/fhir/ValueSet/resource-types)");
    }
    // Nested required field: action.actionDetail (min=1)
    if (resource.action && Array.isArray(resource.action)) {
        for (const _el of resource.action) {
            if ((_el.actionDetail === undefined || _el.actionDetail === null) || Array.isArray(_el.actionDetail)) {
                errors.push("Missing required member: 'actionDetail'");
            }
        }
    }
    // Nested required field: action.requestTime (min=1)
    if (resource.action && Array.isArray(resource.action)) {
        for (const _el of resource.action) {
            if ((_el.requestTime === undefined || _el.requestTime === null) || Array.isArray(_el.requestTime)) {
                errors.push("Missing required member: 'requestTime'");
            }
        }
    }
    // Nested required field: action.issue.code (min=1)
    if (resource.action && Array.isArray(resource.action)) {
        for (const _nrEl0 of resource.action) {
            if (_nrEl0.issue && Array.isArray(_nrEl0.issue)) {
                for (const _nrEl1 of _nrEl0.issue) {
                    if ((_nrEl1.code === undefined || _nrEl1.code === null) || Array.isArray(_nrEl1.code)) {
                        errors.push("Missing required member: 'code'");
                    }
                }
            }
        }
    }
    // Nested required field: resources.type (min=1)
    if (resource.resources && Array.isArray(resource.resources)) {
        for (const _el of resource.resources) {
            if ((_el.type === undefined || _el.type === null) || Array.isArray(_el.type)) {
                errors.push("Missing required member: 'type'");
            }
        }
    }
    // Nested required field: resources.count (min=1)
    if (resource.resources && Array.isArray(resource.resources)) {
        for (const _el of resource.resources) {
            if ((_el.count === undefined || _el.count === null) || Array.isArray(_el.count)) {
                errors.push("Missing required member: 'count'");
            }
        }
    }
    // Nested required field: questionnaire.reference (min=1)
    if (resource.questionnaire && Array.isArray(resource.questionnaire)) {
        for (const _el of resource.questionnaire) {
            if ((_el.reference === undefined || _el.reference === null) || Array.isArray(_el.reference)) {
                errors.push("Missing required member: 'reference'");
            }
        }
    }
    // Nested required field: questionnaire.roleInteraction.role (min=1)
    if (resource.questionnaire && Array.isArray(resource.questionnaire)) {
        for (const _nrEl0 of resource.questionnaire) {
            if (_nrEl0.roleInteraction && Array.isArray(_nrEl0.roleInteraction)) {
                for (const _nrEl1 of _nrEl0.roleInteraction) {
                    if ((_nrEl1.role === undefined || _nrEl1.role === null) || Array.isArray(_nrEl1.role)) {
                        errors.push("Missing required member: 'role'");
                    }
                }
            }
        }
    }
    // Nested required field: questionnaire.roleInteraction.roleAction (min=1)
    if (resource.questionnaire && Array.isArray(resource.questionnaire)) {
        for (const _nrEl0 of resource.questionnaire) {
            if (_nrEl0.roleInteraction && Array.isArray(_nrEl0.roleInteraction)) {
                for (const _nrEl1 of _nrEl0.roleInteraction) {
                    if ((_nrEl1.roleAction === undefined || _nrEl1.roleAction === null) || Array.isArray(_nrEl1.roleAction)) {
                        errors.push("Missing required member: 'roleAction'");
                    }
                }
            }
        }
    }
    // Nested required field: questionnaire.roleInteraction.count (min=1)
    if (resource.questionnaire && Array.isArray(resource.questionnaire)) {
        for (const _nrEl0 of resource.questionnaire) {
            if (_nrEl0.roleInteraction && Array.isArray(_nrEl0.roleInteraction)) {
                for (const _nrEl1 of _nrEl0.roleInteraction) {
                    if ((_nrEl1.count === undefined || _nrEl1.count === null) || Array.isArray(_nrEl1.count)) {
                        errors.push("Missing required member: 'count'");
                    }
                }
            }
        }
    }
    // Nested required field: questionnaire.elapsedTime (min=1)
    if (resource.questionnaire && Array.isArray(resource.questionnaire)) {
        for (const _el of resource.questionnaire) {
            if ((_el.elapsedTime === undefined || _el.elapsedTime === null) || Array.isArray(_el.elapsedTime)) {
                errors.push("Missing required member: 'elapsedTime'");
            }
        }
    }
    // Nested required field: coverageInfo.questionnaire.reference (min=1)
    if (resource.coverageInfo && Array.isArray(resource.coverageInfo)) {
        for (const _nrEl0 of resource.coverageInfo) {
            if (_nrEl0.questionnaire && Array.isArray(_nrEl0.questionnaire)) {
                for (const _nrEl1 of _nrEl0.questionnaire) {
                    if ((_nrEl1.reference === undefined || _nrEl1.reference === null) || Array.isArray(_nrEl1.reference)) {
                        errors.push("Missing required member: 'reference'");
                    }
                }
            }
        }
    }
    // Nested required field: coverageInfo.questionnaire.adaptive (min=1)
    if (resource.coverageInfo && Array.isArray(resource.coverageInfo)) {
        for (const _nrEl0 of resource.coverageInfo) {
            if (_nrEl0.questionnaire && Array.isArray(_nrEl0.questionnaire)) {
                for (const _nrEl1 of _nrEl0.questionnaire) {
                    if ((_nrEl1.adaptive === undefined || _nrEl1.adaptive === null) || Array.isArray(_nrEl1.adaptive)) {
                        errors.push("Missing required member: 'adaptive'");
                    }
                }
            }
        }
    }
    // Nested required field: coverageInfo.questionnaire.response (min=1)
    if (resource.coverageInfo && Array.isArray(resource.coverageInfo)) {
        for (const _nrEl0 of resource.coverageInfo) {
            if (_nrEl0.questionnaire && Array.isArray(_nrEl0.questionnaire)) {
                for (const _nrEl1 of _nrEl0.questionnaire) {
                    if ((_nrEl1.response === undefined || _nrEl1.response === null) || Array.isArray(_nrEl1.response)) {
                        errors.push("Missing required member: 'response'");
                    }
                }
            }
        }
    }
    // Nested required field: coverageInfo.assertionId (min=1)
    if (resource.coverageInfo && Array.isArray(resource.coverageInfo)) {
        for (const _el of resource.coverageInfo) {
            if ((_el.assertionId === undefined || _el.assertionId === null) || Array.isArray(_el.assertionId)) {
                errors.push("Missing required member: 'assertionId'");
            }
        }
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const _bRes = resource;
    // Required ValueSet binding validation for source
    if (_bRes.source !== undefined && !isValidMetricSourceCode(_bRes.source)) {
        errors.push("Code '" + _bRes.source + "' does not exist in the value set 'metric-Source' (http://hl7.org/fhir/us/davinci-dtr/ValueSet/metric-Source), but the binding is of strength 'required'");
    }
    // Required ValueSet binding validation for docReason (array)
    if (_bRes.docReason && Array.isArray(_bRes.docReason)) {
        for (const _code of _bRes.docReason) {
            if (_code !== undefined && !isValidDocReasonCode(_code)) {
                errors.push("Code '" + _code + "' does not exist in the value set 'DocReason' (http://hl7.org/fhir/us/davinci-crd/ValueSet/DocReason), but the binding is of strength 'required'");
            }
        }
    }
    // Required ValueSet binding validation for launchMode
    if (_bRes.launchMode !== undefined && !isValidMetricLaunchModeCode(_bRes.launchMode)) {
        errors.push("Code '" + _bRes.launchMode + "' does not exist in the value set 'metric-launchmode' (http://hl7.org/fhir/us/davinci-dtr/ValueSet/metric-launchmode), but the binding is of strength 'required'");
    }
    // Required ValueSet binding validation for action.actionDetail (nested)
    if (resource.action && Array.isArray(resource.action)) {
        for (const _nb0 of resource.action) {
            if (_nb0.actionDetail !== undefined && !isValidMetricActionCode(_nb0.actionDetail)) {
                errors.push("Code '" + _nb0.actionDetail + "' does not exist in the value set 'metric-Action' (http://hl7.org/fhir/us/davinci-dtr/ValueSet/metric-Action), but the binding is of strength 'required'");
            }
        }
    }
    // Required binding system-presence fallback for questionnaire.failure (nested, ValueSet unresolved)
    if (resource.questionnaire && Array.isArray(resource.questionnaire)) {
        for (const _nb0 of resource.questionnaire) {
            if (_nb0.failure && Array.isArray(_nb0.failure)) {
                for (const _spCC of _nb0.failure) {
                    const _spCoding = _spCC?.coding;
                    if (_spCoding) {
                        for (const _c of _spCoding) {
                            if (_c.code !== undefined && (_c.system === undefined || _c.system === '')) {
                                errors.push("The System URI could not be determined for the code '" + _c.code + "' in the ValueSet 'issue-type' (http://hl7.org/fhir/ValueSet/issue-type)");
                            }
                        }
                    }
                }
            }
        }
    }
    // Required ValueSet binding validation for coverageInfo.covered (nested)
    if (resource.coverageInfo && Array.isArray(resource.coverageInfo)) {
        for (const _nb0 of resource.coverageInfo) {
            if (_nb0.covered !== undefined && !isValidCoverageInfoCode(_nb0.covered)) {
                errors.push("Code '" + _nb0.covered + "' does not exist in the value set 'coverageInfo' (http://hl7.org/fhir/us/davinci-crd/ValueSet/coverageInfo), but the binding is of strength 'required'");
            }
        }
    }
    // Required ValueSet binding validation for coverageInfo.paNeeded (nested)
    if (resource.coverageInfo && Array.isArray(resource.coverageInfo)) {
        for (const _nb0 of resource.coverageInfo) {
            if (_nb0.paNeeded !== undefined && !isValidCoveragePaDetailCode(_nb0.paNeeded)) {
                errors.push("Code '" + _nb0.paNeeded + "' does not exist in the value set 'coveragePaDetail' (http://hl7.org/fhir/us/davinci-crd/ValueSet/coveragePaDetail), but the binding is of strength 'required'");
            }
        }
    }
    // Required ValueSet binding validation for coverageInfo.docNeeded (nested)
    if (resource.coverageInfo && Array.isArray(resource.coverageInfo)) {
        for (const _nb0 of resource.coverageInfo) {
            if (_nb0.docNeeded !== undefined && !isValidAdditionalDocumentationCode(_nb0.docNeeded)) {
                errors.push("Code '" + _nb0.docNeeded + "' does not exist in the value set 'AdditionalDocumentation' (http://hl7.org/fhir/us/davinci-crd/ValueSet/AdditionalDocumentation), but the binding is of strength 'required'");
            }
        }
    }
    // Required ValueSet binding validation for coverageInfo.infoNeeded (nested)
    if (resource.coverageInfo && Array.isArray(resource.coverageInfo)) {
        for (const _nb0 of resource.coverageInfo) {
            if (_nb0.infoNeeded !== undefined && !isValidInformationNeededCode(_nb0.infoNeeded)) {
                errors.push("Code '" + _nb0.infoNeeded + "' does not exist in the value set 'informationNeeded' (http://hl7.org/fhir/us/davinci-crd/ValueSet/informationNeeded), but the binding is of strength 'required'");
            }
        }
    }
    // Base FHIR structural validation: extension.url required, ext-1 constraint, empty objects
    {
        const _checkExtensions = (obj, path, depth) => {
            if (!obj || typeof obj !== 'object')
                return;
            if (Array.isArray(obj)) {
                obj.forEach((item, i) => _checkExtensions(item, path + '[' + i + ']', depth + 1));
                return;
            }
            const rec = obj;
            // Empty object check — HL7 validates all FHIR elements must have content
            if (depth > 0 && Object.keys(rec).length === 0) {
                errors.push('Object must have some content');
            }
            // per-1: If present, start SHALL have a lower value than end (Period structural check)
            if (typeof rec.start === 'string' && typeof rec.end === 'string' && rec.start > rec.end) {
                errors.push('If present, start SHALL have a lower value than end');
            }
            // Validate extension arrays
            for (const extKey of ['extension', 'modifierExtension']) {
                const exts = rec[extKey];
                if (Array.isArray(exts)) {
                    for (const ext of exts) {
                        if (ext && typeof ext === 'object' && !Array.isArray(ext)) {
                            const e = ext;
                            if (typeof e.url !== 'string' || !e.url) {
                                errors.push('Extension.url is required in order to identify, use and validate the extension');
                            }
                            // ext-1: Must have either extensions or value[x], not both
                            const hasNestedExt = Array.isArray(e.extension) && e.extension.length > 0;
                            const hasValue = Object.keys(e).some(k => k.startsWith('value') && k !== 'value' && k.length > 5);
                            if (hasNestedExt && hasValue) {
                                errors.push('Must have either extensions or value[x], not both');
                            }
                        }
                    }
                }
            }
            // Recurse into child objects (skip primitive values)
            for (const [_key, _val] of Object.entries(rec)) {
                if (_val && typeof _val === 'object') {
                    _checkExtensions(_val, path + '.' + _key, depth + 1);
                }
            }
        };
        _checkExtensions(resource, '', 0);
    }
    // Standalone contained reference resolution: verify #id references resolve to contained[] entries
    {
        const _res = resource;
        const _containedIds = new Set();
        if (Array.isArray(_res.contained)) {
            for (const _c of _res.contained) {
                if (_c && typeof _c.id === 'string')
                    _containedIds.add(_c.id);
            }
        }
        const _checkContainedRef = (obj) => {
            if (!obj || typeof obj !== 'object')
                return;
            if (Array.isArray(obj)) {
                obj.forEach(_checkContainedRef);
                return;
            }
            const _rec = obj;
            if (typeof _rec.reference === 'string') {
                const _ref = _rec.reference;
                if (_ref.startsWith('#')) {
                    const _id = _ref.substring(1);
                    if (_id && !_containedIds.has(_id)) {
                        errors.push('Contained reference not found: ' + _ref);
                    }
                }
            }
            for (const [_k, _v] of Object.entries(_rec)) {
                if (_k !== 'contained')
                    _checkContainedRef(_v);
            }
        };
        _checkContainedRef(_res);
    }
    return { errors, warnings };
}
