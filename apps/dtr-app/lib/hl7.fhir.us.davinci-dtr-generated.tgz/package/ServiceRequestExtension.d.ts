import { ServiceRequestCodesCode } from "./valuesets/ValueSet-ServiceRequestCodes";
import { CoverageInformation } from "./CoverageInformation";
import { CodeableConcept, Extension, Identifier, Reference, ServiceRequest } from "fhir/r4";
export interface ServiceRequestExtension extends Omit<ServiceRequest, 'identifier' | 'basedOn' | 'status' | 'code' | 'subject' | 'requester' | 'performer' | 'reasonCode' | 'reasonReference' | 'extension'> {
    /** Must Support */
    identifier?: Identifier[];
    /** Must Support */
    basedOn?: Reference[];
    status: "draft";
    /** Must Support | @see {@link ./valuesets/ValueSet-ServiceRequestCodes.ts} for valid codes (31 codes) */
    code: CodeableConcept & {
        coding: Array<{
            code: ServiceRequestCodesCode;
            system: "http://loinc.org";
        }>;
    };
    /** Must Support */
    subject: Reference;
    /** Must Support */
    requester: Reference;
    /** Must Support */
    performer?: Reference[];
    /** Must Support | @see {@link ./valuesets/ValueSet-ProcedureReasonCodes.ts} for valid codes (100 codes) */
    reasonCode?: CodeableConcept[];
    /** Must Support */
    reasonReference?: Reference[];
    extension?: (Extension | CoverageInformation)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateServiceRequestExtension(resource: ServiceRequestExtension, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
