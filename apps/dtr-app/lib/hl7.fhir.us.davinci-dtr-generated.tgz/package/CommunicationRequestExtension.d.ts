import { CoverageInformation } from "./CoverageInformation";
import { ExtensionCommunicationRequestPayloadContentX } from "./ExtensionCommunicationRequestPayloadContentX";
import { CodeableConcept, CommunicationRequest, CommunicationRequestPayload, Extension, Identifier, Reference } from "fhir/r4";
export interface CommunicationRequestExtensionPayload extends Omit<CommunicationRequestPayload, 'url' | 'value' | 'extension'> {
    url: "http://hl7.org/fhir/5.0/StructureDefinition/extension-CommunicationRequest.payload.content[x]";
    value: CodeableConcept;
    extension?: (Extension | ExtensionCommunicationRequestPayloadContentX)[];
}
export interface CommunicationRequestExtension extends Omit<CommunicationRequest, 'identifier' | 'status' | 'subject' | 'payload' | 'requester' | 'recipient' | 'sender' | 'reasonCode' | 'reasonReference' | 'extension'> {
    resourceType: 'CommunicationRequest';
    /** Must Support */
    identifier?: Identifier[];
    status: "draft";
    /** Must Support */
    subject: Reference;
    /** Must Support */
    payload: CommunicationRequestExtensionPayload[];
    /** Must Support */
    requester: Reference;
    /** Must Support */
    recipient?: Reference[];
    /** Must Support */
    sender?: Reference;
    /** Must Support | @see {@link ./valuesets/ValueSet-V3ActReason.ts} for valid codes (280 codes) */
    reasonCode?: CodeableConcept[];
    /** Must Support */
    reasonReference?: Reference[];
    extension?: (Extension | CoverageInformation)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateCommunicationRequestExtension(resource: CommunicationRequestExtension, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
