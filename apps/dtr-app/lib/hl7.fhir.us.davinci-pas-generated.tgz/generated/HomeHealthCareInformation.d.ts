import { Extension } from "fhir/r4";
export interface HomeHealthCareInformation extends Extension {
    extension: Extension[];
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-homeHealthCareInformation";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateHomeHealthCareInformation(resource: HomeHealthCareInformation, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
