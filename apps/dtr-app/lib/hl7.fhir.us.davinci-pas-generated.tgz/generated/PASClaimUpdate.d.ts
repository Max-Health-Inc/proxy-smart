import { PASSupportingInfoTypeCode } from "./valuesets/ValueSet-PASSupportingInfoType";
import { X12278DiagnosisTypeCode } from "./valuesets/ValueSet-X12278DiagnosisType";
import { X12278RequestedServiceTypeCode } from "./valuesets/ValueSet-X12278RequestedServiceType";
import { AdministrationReferenceNumber } from "./AdministrationReferenceNumber";
import { AuthorizationNumber } from "./AuthorizationNumber";
import { CareTeamClaimScope } from "./CareTeamClaimScope";
import { CertificationType } from "./CertificationType";
import { ConditionCode } from "./ConditionCode";
import { DiagnosisRecordedDate } from "./DiagnosisRecordedDate";
import { EPSDTIndicator } from "./EPSDTIndicator";
import { ExtensionClaimEncounter } from "./ExtensionClaimEncounter";
import { HomeHealthCareInformation } from "./HomeHealthCareInformation";
import { Claim, ClaimCareTeam, ClaimDiagnosis, ClaimItem, ClaimSupportingInfo, CodeableConcept, Extension, Identifier, Money, Reference } from "fhir/r4";
import { InfoChanged } from "./InfoChanged";
import { ItemTraceNumber } from "./ItemTraceNumber";
import { LevelOfServiceCode } from "./LevelOfServiceCode";
import { NursingHomeLevelOfCare } from "./NursingHomeLevelOfCare";
import { NursingHomeResidentialStatus } from "./NursingHomeResidentialStatus";
import { ProductOrServiceCodeEnd } from "./ProductOrServiceCodeEnd";
import { RequestedService } from "./RequestedService";
import { RevenueUnitRateLimit } from "./RevenueUnitRateLimit";
import { ServiceItemRequestType } from "./ServiceItemRequestType";
import { SimpleQuantity } from "./SimpleQuantity";
export interface ExtensionRequestedService extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-requestedService';
}
export interface ExtensionRevenueUnitRateLimit extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-revenueUnitRateLimit';
}
export interface ExtensionNursingHomeLevelOfCare extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-nursingHomeLevelOfCare';
}
export interface ExtensionNursingHomeResidentialStatus extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-nursingHomeResidentialStatus';
}
export interface ExtensionEpsdtIndicator extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-epsdtIndicator';
}
export interface ExtensionProductOrServiceCodeEnd extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-productOrServiceCodeEnd';
}
export interface ExtensionCertificationType extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-certificationType';
}
export interface ExtensionServiceItemRequestType extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-serviceItemRequestType';
}
export interface ExtensionAdministrationReferenceNumber extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-administrationReferenceNumber';
}
export interface ExtensionAuthorizationNumber extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-authorizationNumber';
}
export interface ExtensionItemTraceNumber extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemTraceNumber';
}
export interface ExtensionDiagnosisRecordedDate extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-diagnosisRecordedDate';
}
export interface ExtensionInfoChanged extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-infoChanged';
}
export interface ExtensionCareTeamClaimScope extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-careTeamClaimScope';
}
export interface PASClaimUpdateCareTeam extends ClaimCareTeam {
    /** Must Support */
    provider: Reference;
    /** Must Support */
    role?: CodeableConcept;
    /** Must Support */
    qualification?: CodeableConcept;
    extension?: (Extension | CareTeamClaimScope | CareTeamClaimScope | CareTeamClaimScope)[];
}
export interface PASClaimUpdateSupportingInfo extends ClaimSupportingInfo {
    /** Must Support | @see {@link ./valuesets/ValueSet-PASSupportingInfoType.ts} for valid codes (6 codes) */
    category: CodeableConcept & {
        coding: Array<{
            code: PASSupportingInfoTypeCode;
            system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes";
        }>;
    };
    extension?: (Extension | InfoChanged)[];
}
export interface PASClaimUpdateDiagnosis extends ClaimDiagnosis {
    /** Must Support | @see {@link ./valuesets/ValueSet-X12278DiagnosisType.ts} for valid codes (3 codes) */
    type?: CodeableConcept & {
        coding: Array<{
            code: X12278DiagnosisTypeCode;
            system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes";
        }>;
    }[];
    extension?: (Extension | DiagnosisRecordedDate)[];
}
export interface PASClaimUpdateItem extends ClaimItem {
    /** Must Support */
    revenue?: CodeableConcept;
    /** Must Support */
    category: CodeableConcept;
    /** Must Support | @see {@link ./valuesets/ValueSet-X12278RequestedServiceType.ts} for valid codes (1 codes) */
    productOrService: CodeableConcept & {
        coding: Array<{
            code: X12278RequestedServiceTypeCode;
            system: "http://terminology.hl7.org/CodeSystem/data-absent-reason";
        }>;
    };
    /** Must Support */
    modifier?: CodeableConcept[];
    /** Must Support */
    quantity?: SimpleQuantity;
    /** Must Support */
    unitPrice?: Money;
    extension?: (Extension | ItemTraceNumber | AuthorizationNumber | AdministrationReferenceNumber | ServiceItemRequestType | CertificationType | ProductOrServiceCodeEnd | EPSDTIndicator | NursingHomeResidentialStatus | NursingHomeLevelOfCare | RevenueUnitRateLimit | RequestedService | InfoChanged)[];
}
export interface PASClaimUpdate extends Claim {
    /** Must Support */
    identifier: Identifier[];
    status: "active";
    use: "preauthorization";
    /** Must Support */
    careTeam?: PASClaimUpdateCareTeam[];
    /** Must Support */
    supportingInfo?: PASClaimUpdateSupportingInfo[];
    /** Must Support */
    diagnosis?: PASClaimUpdateDiagnosis[];
    /** Must Support */
    item: PASClaimUpdateItem[];
    extension?: (Extension | LevelOfServiceCode | ConditionCode | HomeHealthCareInformation | ExtensionClaimEncounter)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASClaimUpdate(resource: PASClaimUpdate, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
