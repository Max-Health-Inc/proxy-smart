import { PASCommunicationRequestMediumCode } from "./valuesets/ValueSet-PASCommunicationRequestMedium";
import { CommunicatedDiagnosis } from "./CommunicatedDiagnosis";
import { ContentModifier } from "./ContentModifier";
import { ServiceLineNumber } from "./ServiceLineNumber";
import { CodeableConcept, CommunicationRequest, CommunicationRequestPayload, Extension, Identifier, Reference } from "fhir/r4";
export interface PASCommunicationRequest extends CommunicationRequest {
    /** Must Support */
    identifier?: Identifier[];
    status: "active";
    /** Must Support */
    category?: CodeableConcept[];
    /** Must Support | @see {@link ./valuesets/ValueSet-PASCommunicationRequestMedium.ts} for valid codes (1 codes) */
    medium?: CodeableConcept & {
        coding: Array<{
            code: PASCommunicationRequestMediumCode;
            system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes";
        }>;
    }[];
    /** Must Support */
    requester?: Reference;
    /** Must Support */
    recipient?: Reference[];
    /** Must Support */
    sender?: Reference;
    payload?: PASCommunicationRequestPayload[];
}
export interface PASCommunicationRequestPayload extends CommunicationRequestPayload {
    extension?: (Extension | ServiceLineNumber | CommunicatedDiagnosis | ContentModifier)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASCommunicationRequest(resource: PASCommunicationRequest, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
