import { CodeableConcept, Coverage, Identifier, Reference } from "fhir/r4";
export interface PASCoverage extends Coverage {
    /** Must Support */
    identifier?: Identifier[];
    status: "active";
    /** Must Support */
    subscriber?: Reference;
    /** Must Support */
    relationship?: CodeableConcept;
    /** Must Support */
    payor: Reference[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASCoverage(resource: PASCoverage, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
