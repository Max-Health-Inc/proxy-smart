import { AdministrationReferenceNumber } from "./AdministrationReferenceNumber";
import { AuthorizationNumber } from "./AuthorizationNumber";
import { ErrorElement } from "./ErrorElement";
import { ErrorFollowupAction } from "./ErrorFollowupAction";
import { ErrorPath } from "./ErrorPath";
import { ItemAuthorizedDetail } from "./ItemAuthorizedDetail";
import { ItemAuthorizedProvider } from "./ItemAuthorizedProvider";
import { ItemPreAuthIssueDate } from "./ItemPreAuthIssueDate";
import { ItemPreAuthPeriod } from "./ItemPreAuthPeriod";
import { ItemRequestedServiceDate } from "./ItemRequestedServiceDate";
import { ItemTraceNumber } from "./ItemTraceNumber";
import { BackboneElement, ClaimResponse, ClaimResponseError, ClaimResponseItem, CodeableConcept, Coding, Extension, Identifier, Period, Reference } from "fhir/r4";
import { ReviewAction } from "./ReviewAction";
export interface ExtensionErrorPath extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-errorPath';
}
export interface ExtensionErrorElement extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-errorElement';
}
export interface ExtensionErrorFollowupAction extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-errorFollowupAction';
}
export interface ExtensionItemAuthorizedProvider extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemAuthorizedProvider';
}
export interface ExtensionItemAuthorizedDetail extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemAuthorizedDetail';
}
export interface ExtensionItemRequestedServiceDate extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemRequestedServiceDate';
}
export interface ExtensionAdministrationReferenceNumber extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-administrationReferenceNumber';
}
export interface ExtensionAuthorizationNumber extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-authorizationNumber';
}
export interface ExtensionItemPreAuthPeriod extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemPreAuthPeriod';
}
export interface ExtensionItemPreAuthIssueDate extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemPreAuthIssueDate';
}
export interface ExtensionItemTraceNumber extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemTraceNumber';
}
export interface ExtensionReviewAction extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-reviewAction';
}
export interface PASClaimResponseBaseItemAdjudicationCategoryCoding extends Coding {
    system: "http://terminology.hl7.org/CodeSystem/adjudication";
    code: "submitted";
}
export interface PASClaimResponseBaseItemAdjudication extends BackboneElement {
    category: {
        coding: PASClaimResponseBaseItemAdjudicationCategoryCoding[];
    };
    extension?: (Extension | ReviewAction)[];
}
export interface PASClaimResponseBaseItem extends ClaimResponseItem {
    /** Must Support */
    adjudication: PASClaimResponseBaseItemAdjudication[];
    extension?: (Extension | ItemTraceNumber | ItemPreAuthIssueDate | ItemPreAuthPeriod | AuthorizationNumber | AdministrationReferenceNumber | ItemRequestedServiceDate | ItemAuthorizedDetail | ItemAuthorizedProvider)[];
}
export interface PASClaimResponseBaseError extends ClaimResponseError {
    /** Must Support */
    code: CodeableConcept;
    extension?: (Extension | ErrorFollowupAction | ErrorElement | ErrorPath)[];
}
export interface PASClaimResponseBase extends ClaimResponse {
    /** Must Support */
    identifier?: Identifier[];
    status: "active";
    use: "preauthorization";
    /** Must Support */
    patient: Reference;
    /** Must Support */
    insurer: Reference;
    /** Must Support */
    requestor?: Reference;
    /** Must Support */
    request?: Reference;
    /** Must Support */
    preAuthPeriod?: Period;
    /** Must Support */
    item?: PASClaimResponseBaseItem[];
    /** Must Support */
    error?: PASClaimResponseBaseError[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASClaimResponseBase(resource: PASClaimResponseBase, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
