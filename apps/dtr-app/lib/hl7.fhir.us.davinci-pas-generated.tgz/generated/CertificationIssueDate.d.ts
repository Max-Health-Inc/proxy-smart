import { Extension } from "fhir/r4";
export interface CertificationIssueDate extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemCertificationIssueDate";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateCertificationIssueDate(resource: CertificationIssueDate, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
