import { EPSDTIndicator } from "./EPSDTIndicator";
import { NursingHomeLevelOfCare } from "./NursingHomeLevelOfCare";
import { ProductOrServiceCodeEnd } from "./ProductOrServiceCodeEnd";
import { RequestedService } from "./RequestedService";
import { RevenueUnitRateLimit } from "./RevenueUnitRateLimit";
import { Extension } from "fhir/r4";
export interface ItemAuthorizedDetail extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemAuthorizedDetail";
    extension?: (Extension | ProductOrServiceCodeEnd | EPSDTIndicator | NursingHomeLevelOfCare | RevenueUnitRateLimit | RequestedService)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateItemAuthorizedDetail(resource: ItemAuthorizedDetail, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
