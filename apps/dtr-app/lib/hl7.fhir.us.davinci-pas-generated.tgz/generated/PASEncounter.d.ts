import { NursingHomeResidentialStatus } from "./NursingHomeResidentialStatus";
import { PatientStatus } from "./PatientStatus";
import { CodeableConcept, Encounter, Extension, Reference } from "fhir/r4";
export interface PASEncounter extends Encounter {
    status: "planned";
    /** Must Support */
    type: CodeableConcept[];
    /** Must Support */
    subject: Reference;
    extension?: (Extension | PatientStatus | NursingHomeResidentialStatus)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASEncounter(resource: PASEncounter, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
