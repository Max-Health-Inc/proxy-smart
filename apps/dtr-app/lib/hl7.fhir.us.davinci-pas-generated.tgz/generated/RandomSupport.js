let __seed = Date.now() & 0xffffffff;
export function setRandomSeed(seed) { __seed = seed >>> 0; }
function rng() {
    __seed = (1664525 * __seed + 1013904223) >>> 0;
    return __seed / 0x100000000;
}
export function randomId() { return 'id-' + rng().toString(36).slice(2, 10); }
export function randomString(prefix = 'val') { return prefix + '-' + rng().toString(36).slice(2, 8); }
export function randomInt(min = 0, max = 100) { return Math.floor(rng() * (max - min + 1)) + min; }
export function randomBool() { return rng() < 0.5; }
export function randomDate(start = new Date(Date.now() - 1000 * 60 * 60 * 24 * 30), end = new Date()) { const t = start.getTime() + rng() * (end.getTime() - start.getTime()); return new Date(t).toISOString(); }
export function randomCode(codes) { if (!codes.length)
    return randomString('code'); return codes[Math.floor(rng() * codes.length)]; }
/**
 * Generate a valid UUID v4 (random) for use in urn:uuid: URIs.
 * This generates proper hex-formatted UUIDs that are valid for FHIR fullUrl and identifier values.
 */
export function randomUUID() {
    const hex = () => Math.floor(rng() * 16).toString(16);
    const segment = (len) => Array.from({ length: len }, hex).join('');
    // UUID v4 format: xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx (y is 8, 9, a, or b)
    const variant = ['8', '9', 'a', 'b'][Math.floor(rng() * 4)];
    return segment(8) + '-' + segment(4) + '-4' + segment(3) + '-' + variant + segment(3) + '-' + segment(12);
}
/**
 * Generate a valid US National Provider Identifier (NPI).
 * NPIs are 10-digit numbers that pass the US Core Luhn check.
 * The US Core us-core-17 constraint uses a specific algorithm:
 * - Doubles digits at positions 0, 2, 4, 6, 8 (even positions from left)
 * - If doubled value >= 10, subtracts 9
 * - Adds 24 (constant for '80' prefix)
 * - Sum must be divisible by 10
 */
export function randomNPI() {
    // Generate 9 random digits (the 10th is the check digit)
    const digits = [];
    for (let i = 0; i < 9; i++) {
        digits.push(Math.floor(rng() * 10));
    }
    // Calculate sum using US Core algorithm: double at even positions (0,2,4,6,8) + 24
    let sum = 24; // Constant for '80' prefix
    for (let i = 0; i < 9; i++) {
        let d = digits[i];
        // Double digits at even positions (0, 2, 4, 6, 8)
        if (i % 2 === 0) {
            d = d < 5 ? d * 2 : (d * 2) - 9;
        }
        sum += d;
    }
    // Check digit makes sum divisible by 10
    const checkDigit = (10 - (sum % 10)) % 10;
    return digits.join('') + checkDigit.toString();
}
// Skeleton factories for common FHIR complex types
export function skeletonHumanName() { return { family: randomString('fam'), given: [randomString('giv')] }; }
export function skeletonAddress() { return { line: [randomString('line')], city: randomString('city'), country: 'XX' }; }
// Valid NullFlavor codes that terminology servers will accept
const VALID_NULL_FLAVOR_CODES = ['UNK', 'ASKU', 'NAV', 'NASK', 'OTH', 'MSK', 'NI', 'NA'];
export function skeletonCoding(system = 'http://terminology.hl7.org/CodeSystem/v3-NullFlavor', codes = []) {
    // When using NullFlavor system with no explicit codes, pick from valid NullFlavor codes
    const effectiveCodes = codes.length > 0 ? codes : (system === 'http://terminology.hl7.org/CodeSystem/v3-NullFlavor' ? VALID_NULL_FLAVOR_CODES : []);
    return { system, code: randomCode(effectiveCodes) };
}
export function skeletonCodeableConcept(system, codes = []) { return { coding: [skeletonCoding(system, codes)], text: randomString('text') }; }
export function skeletonIdentifier(system = 'urn:ietf:rfc:3986') { return { system, value: 'urn:uuid:' + randomUUID() }; }
export function skeletonReference(resourceType = 'Patient') { return { reference: resourceType + '/' + randomId() }; }
export function skeletonPeriod() { const start = randomDate(); return { start, end: start }; }
export function skeletonContactPoint() { return { system: 'phone', value: randomString('tel'), use: 'mobile' }; }
export function skeletonQuantity() { return { value: randomInt(1, 100), unit: randomString('u'), system: 'http://unitsofmeasure.org' }; }
/**
 * Resolve a coding for a nestedCodingSlice from a ValueSet binding at runtime.
 * When a slice has a binding URI but no statically-known codes, this function
 * attempts to resolve a valid code from the ValueSetRegistry via the codeResolver.
 * Falls back to fake placeholder codes if resolution fails.
 */
export function resolveSliceCode(codeResolver, valueSetUrl, fallbackSystem, fallbackVersion) {
    if (valueSetUrl && codeResolver) {
        const resolved = codeResolver(valueSetUrl);
        if (resolved) {
            const result = {
                system: resolved.system || fallbackSystem,
                code: resolved.code,
                ...(resolved.display ? { display: resolved.display } : {}),
            };
            if (fallbackVersion)
                result.version = fallbackVersion;
            return result;
        }
    }
    // Fallback: use well-known valid codes per system to avoid placeholder codes
    // that fail terminology server validation
    const wellKnownFallbacks = {
        'http://loinc.org': { code: '4548-4', display: 'Hemoglobin A1c/Hemoglobin.total in Blood' },
        'http://snomed.info/sct': { code: '404684003', display: 'Clinical finding' },
        'http://terminology.hl7.org/CodeSystem/observation-category': { code: 'laboratory', display: 'Laboratory' },
    };
    const fallback = wellKnownFallbacks[fallbackSystem];
    const result = {
        system: fallbackSystem,
        code: fallback?.code || ('code-' + randomId().slice(0, 6)),
        ...(fallback?.display ? { display: fallback.display } : {}),
    };
    if (fallbackVersion)
        result.version = fallbackVersion;
    return result;
}
/**
 * This is a centralized enrichment function used by all generated random() methods.
 * @param base - The base resource object to enrich (will be mutated)
 * @param baseResource - The FHIR resource type (e.g., 'Observation', 'Patient')
 * @param profileUrl - The canonical URL of the profile
 * @param fieldPatterns - Map of field names to their pattern constraints
 * @param forbiddenFields - Array of field names that are forbidden (max=0) in this profile
 * @param valueSetBindings - Map of field names to ValueSet URLs for coded bindings
 * @param codeResolver - Optional function to resolve a ValueSet URL to a random valid code
 */
export function enrichResource(base, baseResource, profileUrl, fieldPatterns, forbiddenFields = [], valueSetBindings = {}, codeResolver, fieldOrder = []) {
    try {
        // Helper to check if a field is forbidden
        const isForbidden = (fieldName) => forbiddenFields.includes(fieldName);
        // Helper to resolve a code from ValueSet binding - uses codeResolver if available
        // Returns a CodeableConcept-compatible structure or undefined if not resolvable
        const resolveBindingCode = (fieldName, fallbackSystem, fallbackCode, fallbackDisplay) => {
            const bindingUrl = valueSetBindings[fieldName];
            if (bindingUrl && codeResolver) {
                const resolved = codeResolver(bindingUrl);
                if (resolved) {
                    return {
                        coding: [{ system: resolved.system, code: resolved.code, display: resolved.display }],
                        text: resolved.display || resolved.code
                    };
                }
            }
            // Return fallback if provided
            if (fallbackSystem && fallbackCode) {
                return {
                    coding: [{ system: fallbackSystem, code: fallbackCode, display: fallbackDisplay }],
                    text: fallbackDisplay || fallbackCode
                };
            }
            return undefined;
        };
        // Helper to resolve a code and return just the code string (for primitive 'code' types)
        const resolveBindingCodePrimitive = (fieldName, fallbackCode) => {
            const bindingUrl = valueSetBindings[fieldName];
            if (bindingUrl && codeResolver) {
                const resolved = codeResolver(bindingUrl);
                if (resolved) {
                    return resolved.code;
                }
            }
            return fallbackCode;
        };
        // Helper to get CodeableConcept pattern value (for category, code, etc.)
        const getPatternValue = (fieldName) => {
            if (!fieldPatterns || Object.keys(fieldPatterns).length === 0 || !(fieldName in fieldPatterns))
                return undefined;
            const pattern = fieldPatterns[fieldName];
            if (!pattern || typeof pattern !== 'object')
                return undefined;
            const obj = pattern;
            if ('coding' in obj && Array.isArray(obj.coding) && obj.coding.length > 0) {
                return { coding: obj.coding };
            }
            return undefined;
        };
        // Helper to get the raw pattern for a field (returns patterns with system even without code)
        // Used for merging pattern fields (like 'version') into existing codings
        const getRawCodeableConceptPattern = (fieldName) => {
            if (!fieldPatterns || Object.keys(fieldPatterns).length === 0 || !(fieldName in fieldPatterns))
                return undefined;
            const pattern = fieldPatterns[fieldName];
            if (!pattern || typeof pattern !== 'object')
                return undefined;
            const obj = pattern;
            if ('coding' in obj && Array.isArray(obj.coding) && obj.coding.length > 0) {
                return { coding: obj.coding };
            }
            return undefined;
        };
        // Helper to merge pattern coding fields into existing codings (preserves existing fields, adds pattern fields)
        const mergeCodingPatterns = (existingCodings, patternCodings) => {
            const patternBySystem = new Map();
            for (const patternCoding of patternCodings) {
                patternBySystem.set(patternCoding.system, patternCoding);
            }
            for (const existing of existingCodings) {
                const patternCoding = patternBySystem.get(existing.system);
                if (patternCoding) {
                    // Merge: pattern fields are added to existing (existing takes precedence for conflicts except pattern-specific fields like version)
                    for (const [key, value] of Object.entries(patternCoding)) {
                        if (key !== 'system' && !(key in existing)) {
                            existing[key] = value;
                        }
                    }
                }
            }
        };
        // Helper to get "complete" CodeableConcept pattern value (must have both system AND code)
        // Returns undefined if the pattern only specifies system without code
        const getCompleteCodePatternValue = (fieldName) => {
            if (!fieldPatterns || Object.keys(fieldPatterns).length === 0 || !(fieldName in fieldPatterns))
                return undefined;
            const pattern = fieldPatterns[fieldName];
            if (!pattern || typeof pattern !== 'object')
                return undefined;
            const obj = pattern;
            if ('coding' in obj && Array.isArray(obj.coding) && obj.coding.length > 0) {
                // Check if the first coding has both system and code
                const firstCoding = obj.coding[0];
                if (firstCoding && 'system' in firstCoding && 'code' in firstCoding) {
                    return { coding: obj.coding };
                }
            }
            return undefined;
        };
        // Helper to get primitive pattern value (for patternString, patternCode, patternUri)
        // Keys are nested paths like "valueQuantity.unit", "deviceName.name", etc.
        const getPrimitivePattern = (nestedPath) => {
            if (!fieldPatterns || !(nestedPath in fieldPatterns))
                return undefined;
            const value = fieldPatterns[nestedPath];
            if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
                return value;
            }
            return undefined;
        };
        // Helper to apply nested primitive patterns to a target object
        // e.g., applies "valueQuantity.unit" pattern to base.valueQuantity.unit
        const applyNestedPatterns = (targetField, target) => {
            if (!fieldPatterns)
                return;
            for (const key of Object.keys(fieldPatterns)) {
                if (key.startsWith(targetField + '.')) {
                    const nestedKey = key.slice(targetField.length + 1); // e.g., "unit" from "valueQuantity.unit"
                    const patternValue = fieldPatterns[key];
                    if (typeof patternValue === 'string' || typeof patternValue === 'number' || typeof patternValue === 'boolean') {
                        target[nestedKey] = patternValue;
                    }
                }
            }
        };
        // Helper to get Reference nested requirements (e.g., serviceProvider.identifier, serviceProvider.display)
        // These are stored in fieldPatterns with key "_refReq_<fieldName>"
        const getRefRequirements = (fieldName) => {
            if (!fieldPatterns)
                return undefined;
            const reqKey = '_refReq_' + fieldName;
            const reqs = fieldPatterns[reqKey];
            if (reqs && typeof reqs === 'object' && !Array.isArray(reqs)) {
                return reqs;
            }
            return undefined;
        };
        // ── Generic enrichment pass ─────────────────────────────────────────────
        // Resolve primitive code fields (status, intent) from ValueSet bindings
        // BEFORE resource-specific blocks. CodeableConcept fields are NOT resolved
        // generically because the enrichment function doesn't have type metadata
        // to distinguish code vs CodeableConcept vs array fields.
        // Generic status resolution via ValueSet binding
        if (!isForbidden('status') && !('status' in base)) {
            const resolved = resolveBindingCodePrimitive('status');
            if (resolved)
                base.status = resolved;
        }
        // Generic intent resolution via ValueSet binding
        if (!isForbidden('intent') && !('intent' in base)) {
            const resolved = resolveBindingCodePrimitive('intent');
            if (resolved)
                base.intent = resolved;
        }
        // Identifier-like profile
        if (/Identifier/i.test(baseResource)) {
            if (!isForbidden('system') && !('system' in base))
                base.system = 'urn:ietf:rfc:3986';
            if (!isForbidden('value') && !('value' in base))
                base.value = 'urn:uuid:' + randomUUID();
            if (!isForbidden('type') && !('type' in base))
                base.type = { text: 'Primary Identifier' };
        }
        // Patient / Practitioner
        if (/Patient|Practitioner/i.test(baseResource)) {
            if (!isForbidden('identifier') && !('identifier' in base))
                base.identifier = [{ system: 'urn:ietf:rfc:3986', value: 'urn:uuid:' + randomUUID() }];
            // Ensure identifier is always an array (FHIR 0..*)
            if ('identifier' in base && !Array.isArray(base.identifier) && typeof base.identifier === 'object' && base.identifier !== null) {
                base.identifier = [base.identifier];
            }
            if (!isForbidden('name') && !('name' in base))
                base.name = [{ family: randomId(), given: [randomId()] }];
            if (!isForbidden('gender') && !('gender' in base))
                base.gender = 'unknown';
            if (!isForbidden('birthDate') && !('birthDate' in base))
                base.birthDate = new Date(Date.now() - 10 * 365 * 24 * 60 * 60 * 1000).toISOString().substring(0, 10);
            if (!isForbidden('address') && !('address' in base))
                base.address = [{ city: 'Example City', postalCode: '12345', country: 'XX' }];
        }
        // Condition
        if (/Condition/i.test(baseResource)) {
            // For code field: ADD missing pattern codings to existing codings
            // Never remove existing codings - classGenerator's random() already includes required slice codings
            // We only add any pattern codings that might be missing (by system+code pair)
            const patternCode = getCompleteCodePatternValue('code');
            if (!isForbidden('code')) {
                if (patternCode && 'code' in base && base.code && typeof base.code === 'object') {
                    const existingCode = base.code;
                    const patternCodeObj = patternCode;
                    if (existingCode.coding && patternCodeObj.coding) {
                        // Build a set of existing coding keys (system|code pairs)
                        const existingCodingKeys = new Set();
                        for (const existing of existingCode.coding) {
                            const key = String(existing.system || '') + '|' + String(existing.code || '');
                            existingCodingKeys.add(key);
                        }
                        // Only ADD pattern codings that aren't already present (by system+code)
                        for (const patternCoding of patternCodeObj.coding) {
                            const key = String(patternCoding.system || '') + '|' + String(patternCoding.code || '');
                            if (!existingCodingKeys.has(key)) {
                                existingCode.coding.push(patternCoding);
                                existingCodingKeys.add(key);
                            }
                        }
                    }
                    else if (!existingCode.coding && patternCodeObj.coding) {
                        existingCode.coding = patternCodeObj.coding;
                    }
                }
                else if (patternCode) {
                    base.code = patternCode;
                }
                else if (!('code' in base)) {
                    // Try to resolve from ValueSet binding first, fall back to hardcoded default
                    const resolved = resolveBindingCode('code', 'http://snomed.info/sct', '64572001', 'Condition');
                    base.code = resolved || { coding: [{ system: 'http://snomed.info/sct', code: '64572001', display: 'Condition' }], text: 'Example condition' };
                }
                // Also merge in pattern fields (like version) that don't require a complete pattern (system+code)
                // This handles cases where the pattern specifies additional fields like version for ICD-10-GM coding profiles
                const rawPattern = getRawCodeableConceptPattern('code');
                if (rawPattern?.coding && 'code' in base && base.code && typeof base.code === 'object') {
                    const existingCode = base.code;
                    if (existingCode.coding) {
                        mergeCodingPatterns(existingCode.coding, rawPattern.coding);
                    }
                }
            }
            if (!isForbidden('clinicalStatus') && !('clinicalStatus' in base)) {
                const resolved = resolveBindingCode('clinicalStatus', 'http://terminology.hl7.org/CodeSystem/condition-clinical', 'active');
                base.clinicalStatus = resolved || { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/condition-clinical', code: 'active' }] };
            }
            if (!isForbidden('verificationStatus') && !('verificationStatus' in base)) {
                const resolved = resolveBindingCode('verificationStatus', 'http://terminology.hl7.org/CodeSystem/condition-ver-status', 'confirmed');
                base.verificationStatus = resolved || { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/condition-ver-status', code: 'confirmed' }] };
            }
            // con-5: clinicalStatus SHALL NOT be present if verificationStatus is entered-in-error
            if ('verificationStatus' in base && 'clinicalStatus' in base) {
                const vs = base.verificationStatus;
                if (vs?.coding?.some(c => c.code === 'entered-in-error')) {
                    delete base.clinicalStatus;
                }
            }
            if (!isForbidden('subject') && !('subject' in base))
                base.subject = { reference: 'Patient/' + randomId() };
            // If code is present and encounter is required (via _refReq_encounter), add encounter
            // This is needed for constraints like ISiK's isik-con1 ("wenn code vorhanden, dann encounter")
            if ('code' in base && getRefRequirements('encounter') && !('encounter' in base)) {
                base.encounter = { reference: 'Encounter/' + randomId() };
            }
            // Always use pattern if available for category, even if category already exists
            const patternCategory = getPatternValue('category');
            if (patternCategory) {
                base.category = [patternCategory];
            }
            else if (!('category' in base)) {
                const resolved = resolveBindingCode('category', 'http://terminology.hl7.org/CodeSystem/condition-category', 'encounter-diagnosis');
                base.category = [resolved || { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/condition-category', code: 'encounter-diagnosis' }] }];
            }
        }
        // Observation
        if (/Observation/i.test(baseResource)) {
            if (!('status' in base))
                base.status = 'final';
            // For code field: ADD missing pattern codings to existing codings
            // Never remove existing codings - classGenerator's random() already includes required slice codings
            // We only add any pattern codings that might be missing (by system+code pair)
            const patternCode = getCompleteCodePatternValue('code');
            if (patternCode && 'code' in base && base.code && typeof base.code === 'object') {
                const existingCode = base.code;
                const patternCodeObj = patternCode;
                if (existingCode.coding && patternCodeObj.coding) {
                    // Build a set of existing coding keys (system|code pairs)
                    const existingCodingKeys = new Set();
                    for (const existing of existingCode.coding) {
                        const key = String(existing.system || '') + '|' + String(existing.code || '');
                        existingCodingKeys.add(key);
                    }
                    // Only ADD pattern codings that aren't already present (by system+code)
                    for (const patternCoding of patternCodeObj.coding) {
                        const key = String(patternCoding.system || '') + '|' + String(patternCoding.code || '');
                        if (!existingCodingKeys.has(key)) {
                            existingCode.coding.push(patternCoding);
                            existingCodingKeys.add(key);
                        }
                    }
                }
                else if (!existingCode.coding && patternCodeObj.coding) {
                    existingCode.coding = patternCodeObj.coding;
                }
            }
            else if (patternCode) {
                base.code = patternCode;
            }
            else if (!('code' in base)) {
                // Try to resolve from ValueSet binding first, fall back to hardcoded default
                const resolved = resolveBindingCode('code', 'http://loinc.org', '8867-4', 'Heart rate');
                base.code = resolved || { coding: [{ system: 'http://loinc.org', code: '8867-4', display: 'Heart rate' }], text: 'Heart rate' };
            }
            if (!('subject' in base))
                base.subject = { reference: 'Patient/' + randomId() };
            if (!('effectiveDateTime' in base))
                base.effectiveDateTime = new Date().toISOString();
            // Always use pattern if available for category, even if category already exists
            const patternCategory = getPatternValue('category');
            if (patternCategory) {
                base.category = [patternCategory];
            }
            else if (!('category' in base)) {
                const resolved = resolveBindingCode('category', 'http://terminology.hl7.org/CodeSystem/observation-category', 'vital-signs');
                base.category = [resolved || { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/observation-category', code: 'vital-signs' }] }];
            }
            // Observations MUST have value[x], dataAbsentReason, component, or hasMember
            const hasValue = Object.keys(base).some(k => k.startsWith('value'));
            const hasComponent = 'component' in base;
            const hasHasMember = 'hasMember' in base;
            const hasDataAbsentReason = 'dataAbsentReason' in base;
            if (!hasValue && !hasComponent && !hasHasMember && !hasDataAbsentReason) {
                // Check for patterns from the StructureDefinition for valueQuantity fields
                const codePattern = getPrimitivePattern('valueQuantity.code');
                const unitPattern = getPrimitivePattern('valueQuantity.unit');
                const systemPattern = getPrimitivePattern('valueQuantity.system');
                // Check if there are nested requirements for value[x] (indicates required binding)
                const valueReqs = getRefRequirements('value[x]');
                const codeRequired = valueReqs?.code;
                // Check if value[x] is constrained to specific types (e.g., only CodeableConcept)
                const valueTypeConstraint = fieldPatterns['_choiceType_value[x]'];
                const isCodeableConceptOnly = valueTypeConstraint && valueTypeConstraint.length === 1 && valueTypeConstraint[0] === 'CodeableConcept';
                if (isCodeableConceptOnly) {
                    // Profile constrains value[x] to only CodeableConcept - use valueCodeableConcept
                    // Check for a pattern from the profile, otherwise use data-absent-reason
                    const valuePattern = getPatternValue('valueCodeableConcept');
                    if (valuePattern) {
                        base.valueCodeableConcept = valuePattern;
                    }
                    else {
                        // Use a generic CodeableConcept that indicates no specific value is required
                        base.valueCodeableConcept = { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/data-absent-reason', code: 'unknown', display: 'Unknown' }], text: 'Unknown' };
                    }
                }
                else if (codeRequired && codePattern === undefined) {
                    // If code is required but we don't have a pattern, use dataAbsentReason instead
                    // This avoids required binding violations when we don't know the valid codes
                    base.dataAbsentReason = { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/data-absent-reason', code: 'unknown' }] };
                }
                else {
                    // Use patterns if available, otherwise derive UCUM unit from observation code
                    let defaultUnit = '1';
                    let defaultCode = '1';
                    if (unitPattern === undefined && codePattern === undefined) {
                        // Map well-known vital sign LOINC codes to correct UCUM units
                        const codeObj = base.code;
                        const loincCode = codeObj?.coding?.[0]?.code;
                        const vitalSignUnits = {
                            '8867-4': { unit: '/min', code: '/min', value: 72 }, // Heart rate
                            '9279-1': { unit: '/min', code: '/min', value: 16 }, // Respiratory rate
                            '8310-5': { unit: 'Cel', code: 'Cel', value: 37 }, // Body temperature
                            '29463-7': { unit: 'kg', code: 'kg', value: 70 }, // Body weight
                            '3141-9': { unit: 'kg', code: 'kg', value: 70 }, // Body weight Measured
                            '8302-2': { unit: 'cm', code: 'cm', value: 170 }, // Body height
                            '39156-5': { unit: 'kg/m2', code: 'kg/m2', value: 24 }, // BMI
                            '2708-6': { unit: '%', code: '%', value: 98 }, // Oxygen saturation
                            '59408-5': { unit: '%', code: '%', value: 97 }, // SpO2
                            '8480-6': { unit: 'mmHg', code: 'mm[Hg]', value: 120 }, // Systolic BP
                            '8462-4': { unit: 'mmHg', code: 'mm[Hg]', value: 80 }, // Diastolic BP
                        };
                        if (loincCode && vitalSignUnits[loincCode]) {
                            const vs = vitalSignUnits[loincCode];
                            defaultUnit = vs.unit;
                            defaultCode = vs.code;
                            base.valueQuantity = { value: vs.value, unit: vs.unit, system: 'http://unitsofmeasure.org', code: vs.code };
                        }
                        else {
                            base.valueQuantity = { value: 72, unit: defaultUnit, system: 'http://unitsofmeasure.org', code: defaultCode };
                        }
                    }
                    else {
                        base.valueQuantity = {
                            value: 72,
                            unit: unitPattern !== undefined ? unitPattern : defaultUnit,
                            system: systemPattern !== undefined ? systemPattern : 'http://unitsofmeasure.org',
                            code: codePattern !== undefined ? codePattern : defaultCode
                        };
                    }
                }
            }
            // Apply nested primitive patterns to valueQuantity if present
            // These come from patternString/patternCode/patternUri on valueQuantity.unit, .code, .system
            if ('valueQuantity' in base && typeof base.valueQuantity === 'object' && base.valueQuantity !== null) {
                applyNestedPatterns('valueQuantity', base.valueQuantity);
            }
            // Ensure each component has a value or dataAbsentReason (vs-3 constraint)
            // This handles blood pressure and other vital signs with component slices
            if ('component' in base && Array.isArray(base.component)) {
                for (const comp of base.component) {
                    const hasCompValue = Object.keys(comp).some(k => k.startsWith('value'));
                    const hasCompDataAbsentReason = 'dataAbsentReason' in comp;
                    if (!hasCompValue && !hasCompDataAbsentReason) {
                        // Add a generic valueQuantity - for blood pressure this will be overwritten
                        // by profile-specific logic if needed
                        comp.valueQuantity = { value: 120, unit: 'mmHg', system: 'http://unitsofmeasure.org', code: 'mm[Hg]' };
                    }
                    // Correct UCUM units on existing component valueQuantity based on component LOINC code
                    if ('valueQuantity' in comp && typeof comp.valueQuantity === 'object' && comp.valueQuantity !== null) {
                        const compCode = comp.code;
                        const compLoinc = compCode?.coding?.[0]?.code;
                        const compUnits = {
                            '8480-6': { unit: 'mmHg', code: 'mm[Hg]', value: 120 },
                            '8462-4': { unit: 'mmHg', code: 'mm[Hg]', value: 80 },
                            '8867-4': { unit: '/min', code: '/min', value: 72 },
                            '9279-1': { unit: '/min', code: '/min', value: 16 },
                            '2708-6': { unit: '%', code: '%', value: 98 },
                        };
                        if (compLoinc && compUnits[compLoinc]) {
                            const vs = compUnits[compLoinc];
                            const vq = comp.valueQuantity;
                            vq.value = vs.value;
                            vq.unit = vs.unit;
                            vq.code = vs.code;
                            vq.system = 'http://unitsofmeasure.org';
                        }
                    }
                }
            }
            // PulseOximetry profiles require LOINC 2708-6 (Oxygen saturation) in code.coding
            if (/pulse.?oximetry|oxygensat/i.test(profileUrl || '')) {
                if ('code' in base && typeof base.code === 'object' && base.code !== null) {
                    const codeObj = base.code;
                    const hasO2Sat = codeObj.coding?.some(c => c.code === '2708-6');
                    if (!hasO2Sat) {
                        if (!codeObj.coding)
                            codeObj.coding = [];
                        codeObj.coding.push({ system: 'http://loinc.org', code: '2708-6', display: 'Oxygen saturation in Arterial blood' });
                    }
                }
            }
        }
        // CarePlan
        if (/CarePlan/i.test(baseResource)) {
            if (!('status' in base))
                base.status = 'active';
            if (!('intent' in base))
                base.intent = 'order';
            if (!('subject' in base))
                base.subject = { reference: 'Patient/' + randomId() };
            // Always use pattern if available for category, even if category already exists
            const patternCategory = getPatternValue('category');
            if (patternCategory) {
                base.category = [patternCategory];
            }
            else if (!('category' in base)) {
                const resolved = resolveBindingCode('category', 'http://hl7.org/fhir/us/core/CodeSystem/careplan-category', 'assess-plan');
                base.category = [resolved || { coding: [{ system: 'http://hl7.org/fhir/us/core/CodeSystem/careplan-category', code: 'assess-plan' }] }];
            }
        }
        // Procedure
        if (/Procedure/i.test(baseResource)) {
            if (!('code' in base)) {
                const resolved = resolveBindingCode('code', 'http://snomed.info/sct', '71388002', 'Procedure');
                base.code = resolved || { coding: [{ system: 'http://snomed.info/sct', code: '71388002', display: 'Procedure' }], text: 'Example procedure' };
            }
            if (!('status' in base))
                base.status = 'completed';
            if (!('subject' in base))
                base.subject = { reference: 'Patient/' + randomId() };
            if (!('performedDateTime' in base))
                base.performedDateTime = new Date().toISOString();
            if (!('category' in base)) {
                const resolved = resolveBindingCode('category', 'http://snomed.info/sct', '387713003');
                base.category = resolved || { coding: [{ system: 'http://snomed.info/sct', code: '387713003' }] };
            }
        }
        // Encounter
        if (/Encounter/i.test(baseResource)) {
            // Force correct status - 'active' is NOT valid for Encounter.status
            // Use pattern value if the profile defines one (e.g., PAS requires 'planned')
            const encounterStatusPattern = getPrimitivePattern('status');
            base.status = encounterStatusPattern || 'finished';
            if (!('class' in base))
                base.class = { system: 'http://terminology.hl7.org/CodeSystem/v3-ActCode', code: 'IMP', display: 'inpatient encounter' };
            if (!('subject' in base))
                base.subject = { reference: 'Patient/' + randomId() };
            if (!('period' in base))
                base.period = { start: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(), end: new Date().toISOString() };
            if (!('type' in base)) {
                const resolved = resolveBindingCode('type', 'http://terminology.hl7.org/CodeSystem/v3-ActCode', 'IMP');
                base.type = [resolved || { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/v3-ActCode', code: 'IMP' }] }];
            }
            if (!('serviceProvider' in base))
                base.serviceProvider = { reference: 'Organization/' + randomId() };
        }
        // QuestionnaireResponse
        if (/QuestionnaireResponse/i.test(baseResource)) {
            // Force correct status - 'active' is NOT valid for QuestionnaireResponse.status
            base.status = 'completed';
            // questionnaire must be an absolute canonical URL, not a relative reference
            if (!('questionnaire' in base))
                base.questionnaire = 'urn:uuid:' + randomUUID();
            if (!('subject' in base))
                base.subject = { reference: 'Patient/' + randomId() };
            if (!('authored' in base))
                base.authored = new Date().toISOString();
            if (!('author' in base))
                base.author = { reference: 'Practitioner/' + randomId() };
            if (!('item' in base))
                base.item = [{ linkId: '1', text: 'Example question', answer: [{ valueString: 'Example answer' }] }];
        }
        // Account
        if (/Account/i.test(baseResource)) {
            if (!('status' in base))
                base.status = 'active';
            if (!('type' in base)) {
                const resolved = resolveBindingCode('type', 'http://terminology.hl7.org/CodeSystem/v3-ActCode', 'PBILLACCT');
                base.type = resolved || { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/v3-ActCode', code: 'PBILLACCT' }] };
            }
            if (!('identifier' in base))
                base.identifier = [{ system: 'urn:ietf:rfc:3986', value: 'urn:uuid:' + randomUUID() }];
            if (!('subject' in base))
                base.subject = [{ reference: 'Patient/' + randomId() }];
        }
        // Bundle
        if (/Bundle/i.test(baseResource)) {
            // Check for profile-specific type patterns (e.g., SMART user-access-brands-bundle requires 'collection')
            const typePattern = getPrimitivePattern('type');
            if (typePattern !== undefined) {
                base.type = typePattern;
            }
            else if (!('type' in base)) {
                base.type = 'document';
            }
            if (!('timestamp' in base))
                base.timestamp = new Date().toISOString();
            // Use proper UUIDs for identifier values (urn:uuid: requires valid UUID format)
            // Apply identifier.system pattern if available (e.g., CHCoreDocumentEPR requires urn:ietf:rfc:3986)
            const idSystemPattern = getPrimitivePattern('identifier.system');
            if (!('identifier' in base)) {
                const idSystem = (typeof idSystemPattern === 'string') ? idSystemPattern : 'urn:ietf:rfc:3986';
                base.identifier = { system: idSystem, value: 'urn:uuid:' + randomUUID() };
            }
            else if (typeof idSystemPattern === 'string' && typeof base.identifier === 'object' && base.identifier !== null) {
                base.identifier.system = idSystemPattern;
                // If system is urn:ietf:rfc:3986, value must be a valid URI
                if (idSystemPattern === 'urn:ietf:rfc:3986') {
                    base.identifier.value = 'urn:uuid:' + randomUUID();
                }
            }
            // Ensure meta.lastUpdated is present (required by SMART and other profiles)
            if (!('meta' in base))
                base.meta = { lastUpdated: new Date().toISOString() };
            else if (typeof base.meta === 'object' && base.meta !== null && !('lastUpdated' in base.meta)) {
                base.meta.lastUpdated = new Date().toISOString();
            }
            // Use proper UUIDs for fullUrl values
            if (!('entry' in base))
                base.entry = [{ fullUrl: 'urn:uuid:' + randomUUID(), resource: { resourceType: 'Composition', id: randomId(), status: 'final', type: { coding: [{ system: 'http://loinc.org', code: '60591-5' }] }, subject: { reference: 'Patient/' + randomId() }, date: new Date().toISOString(), author: [{ reference: 'Practitioner/' + randomId() }], title: 'Example Document', section: [{ title: 'Section', text: { status: 'generated', div: '<div xmlns="http://www.w3.org/1999/xhtml">Section content</div>' } }] } }];
            // Fix existing entry fullUrls to use proper UUIDs and empty resources
            if (Array.isArray(base.entry)) {
                for (const entry of base.entry) {
                    if (entry.fullUrl && entry.fullUrl.startsWith('urn:uuid:id-')) {
                        entry.fullUrl = 'urn:uuid:' + randomUUID();
                    }
                    // Fix empty resource objects — a resource must have at least a resourceType
                    if (entry.resource && typeof entry.resource === 'object' && !('resourceType' in entry.resource)) {
                        entry.resource = { resourceType: 'Basic', id: randomId(), code: { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/basic-resource-type', code: 'study' }] } };
                    }
                    // bdl-3/bdl-4: request/response prohibited for collection/document/message/searchset bundles
                    const bundleType = base.type;
                    if (['collection', 'document', 'message', 'searchset'].includes(bundleType)) {
                        delete entry.request;
                        delete entry.response;
                    }
                }
                // Enrich Claim entries in bundles (required by PAS Bundle profiles)
                for (const entry of base.entry) {
                    if (entry.resource?.resourceType === 'Claim') {
                        const claim = entry.resource;
                        if (!('status' in claim))
                            claim.status = 'active';
                        if (!('type' in claim))
                            claim.type = { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/claim-type', code: 'professional' }] };
                        if (!('use' in claim))
                            claim.use = 'preauthorization';
                        if (!('patient' in claim))
                            claim.patient = { reference: 'Patient/' + randomId() };
                        if (!('created' in claim))
                            claim.created = new Date().toISOString().substring(0, 10);
                        if (!('provider' in claim))
                            claim.provider = { reference: 'Practitioner/' + randomId() };
                        if (!('insurer' in claim))
                            claim.insurer = { reference: 'Organization/' + randomId() };
                        if (!('priority' in claim))
                            claim.priority = { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/processpriority', code: 'normal' }] };
                        if (!('insurance' in claim))
                            claim.insurance = [{ sequence: 1, focal: true, coverage: { reference: 'Coverage/' + randomId() } }];
                        if (!('identifier' in claim))
                            claim.identifier = [{ system: 'urn:ietf:rfc:3986', value: 'urn:uuid:' + randomUUID() }];
                        if (!('item' in claim))
                            claim.item = [{ sequence: 1, category: { coding: [{ system: 'https://x12.org/codes/service-type-codes', code: '3', display: 'Consultation' }] }, productOrService: { coding: [{ system: 'http://www.ama-assn.org/go/cpt', code: '99213' }] } }];
                        // Ensure all items have category (required by PAS)
                        if (Array.isArray(claim.item)) {
                            for (const itm of claim.item) {
                                if (!('category' in itm))
                                    itm.category = { coding: [{ system: 'https://x12.org/codes/service-type-codes', code: '3', display: 'Consultation' }] };
                            }
                        }
                    }
                }
                // For document bundles: ensure referenced Patient/Practitioner are contained in the bundle
                // This satisfies constraints like ISiK-docBundle-1 ("All referenced Resources must be contained")
                if (base.type === 'document') {
                    const entries = base.entry;
                    const existingTypes = new Set(entries.map(e => e.resource?.resourceType).filter(Boolean));
                    // Collect references from the Composition entry
                    const comp = entries.find(e => e.resource?.resourceType === 'Composition');
                    if (comp?.resource) {
                        // Ensure Composition has identifier (required by ISiK and other document profiles)
                        if (!('identifier' in comp.resource)) {
                            comp.resource.identifier = { system: 'urn:ietf:rfc:3986', value: 'urn:uuid:' + randomUUID() };
                        }
                        // Ensure Composition has language (required by CH Core EPR and other document profiles)
                        if (!('language' in comp.resource)) {
                            comp.resource.language = 'en';
                        }
                        // Ensure Composition has confidentiality (required by CH Core EPR)
                        if (!('confidentiality' in comp.resource)) {
                            comp.resource.confidentiality = 'N';
                        }
                        // Add _confidentiality extension only for CH Core profiles (other IGs don't recognize this extension)
                        const isCHCore = profileUrl.includes('fhir.ch/') || profileUrl.includes('ch-core');
                        if (isCHCore && 'confidentiality' in comp.resource && !('_confidentiality' in comp.resource)) {
                            comp.resource._confidentiality = { extension: [{
                                        url: 'http://fhir.ch/ig/ch-core/StructureDefinition/ch-ext-epr-confidentialitycode',
                                        valueCodeableConcept: { coding: [{ system: 'http://snomed.info/sct', code: '17621005' }] }
                                    }] };
                        }
                        // Ensure sections have code to prevent wrong slice matching
                        if (Array.isArray(comp.resource.section)) {
                            for (const section of comp.resource.section) {
                                if (!('code' in section)) {
                                    section.code = { coding: [{ system: 'http://loinc.org', code: '48765-2', display: 'Allergies and adverse reactions Document' }] };
                                }
                            }
                        }
                        const refTargets = [];
                        const collectRefs = (obj) => {
                            if (!obj || typeof obj !== 'object')
                                return;
                            if (Array.isArray(obj)) {
                                obj.forEach(collectRefs);
                                return;
                            }
                            const rec = obj;
                            if (typeof rec.reference === 'string') {
                                const m = rec.reference.match(/^([A-Za-z]+)\/(.+)/);
                                if (m) {
                                    let target = refTargets.find(t => t.type === m[1] && t.id === m[2]);
                                    if (!target) {
                                        target = { type: m[1], id: m[2], refs: [] };
                                        refTargets.push(target);
                                    }
                                    target.refs.push(rec);
                                }
                            }
                            Object.values(rec).forEach(collectRefs);
                        };
                        collectRefs(comp.resource);
                        for (const ref of refTargets) {
                            if (!existingTypes.has(ref.type)) {
                                existingTypes.add(ref.type);
                                const entryUuid = randomUUID();
                                const refEntry = { resourceType: ref.type, id: ref.id };
                                if (ref.type === 'Patient')
                                    Object.assign(refEntry, { name: [{ family: 'Example', given: ['Patient'] }], gender: 'unknown', birthDate: new Date(Date.now() - 10 * 365 * 24 * 60 * 60 * 1000).toISOString().substring(0, 10), identifier: [{ system: 'urn:ietf:rfc:3986', value: 'urn:uuid:' + randomUUID() }] });
                                if (ref.type === 'Practitioner')
                                    Object.assign(refEntry, { name: [{ family: 'Example', given: ['Practitioner'] }], identifier: [{ system: 'urn:oid:2.51.1.3', value: '7600000000000' }] });
                                entries.push({ fullUrl: 'urn:uuid:' + entryUuid, resource: refEntry });
                                // Update all references in the Composition to use the fullUrl
                                for (const r of ref.refs) {
                                    r.reference = 'urn:uuid:' + entryUuid;
                                }
                            }
                        }
                    }
                    // For IPS Bundles: add meta.profile to Composition and Patient entries for slice matching
                    if (/ips/i.test(profileUrl || '')) {
                        for (const entry of entries) {
                            if (entry.resource?.resourceType === 'Composition') {
                                if (!entry.resource.meta)
                                    entry.resource.meta = {};
                                entry.resource.meta.profile = ['http://hl7.org/fhir/uv/ips/StructureDefinition/Composition-uv-ips'];
                            }
                            if (entry.resource?.resourceType === 'Patient') {
                                if (!entry.resource.meta)
                                    entry.resource.meta = {};
                                entry.resource.meta.profile = ['http://hl7.org/fhir/uv/ips/StructureDefinition/Patient-uv-ips'];
                            }
                        }
                    }
                }
            }
        }
        // Composition
        if (/Composition/i.test(baseResource)) {
            // Force correct status - 'active' is NOT valid for Composition.status
            base.status = 'final';
            // Always use profile-specific type pattern if available, even if type already set
            // (class init may set type to NullFlavor skeleton — pattern overrides that)
            const typePattern = getPatternValue('type');
            if (typePattern) {
                base.type = typePattern;
            }
            else if (!('type' in base)) {
                base.type = { coding: [{ system: 'http://loinc.org', code: '60591-5', display: 'Patient summary Document' }] };
            }
            if (!('subject' in base))
                base.subject = { reference: 'Patient/' + randomId() };
            if (!('date' in base))
                base.date = new Date().toISOString();
            if (!('author' in base))
                base.author = [{ reference: 'Practitioner/' + randomId() }];
            if (!('title' in base))
                base.title = 'Patient Summary';
            // Section must have at least one element for many profiles
            // Add code to prevent unintended slice matching (e.g., originalRepresentation which has code 55108-5)
            if (!('section' in base) || (Array.isArray(base.section) && base.section.length === 0)) {
                base.section = [{
                        title: 'Section',
                        code: { coding: [{ system: 'http://loinc.org', code: '48765-2', display: 'Allergies and adverse reactions Document' }] },
                        text: { status: 'generated', div: '<div xmlns="http://www.w3.org/1999/xhtml">Section content</div>' }
                    }];
            }
            // ips-comp-1: "Either section.entry or emptyReason are present"
            // Add emptyReason to any section that has no entry
            if (Array.isArray(base.section)) {
                for (const section of base.section) {
                    const hasEntry = 'entry' in section && Array.isArray(section.entry) && section.entry.length > 0;
                    if (!hasEntry && !('emptyReason' in section)) {
                        section.emptyReason = { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/list-empty-reason', code: 'unavailable', display: 'Unavailable' }] };
                    }
                }
            }
            // EPR confidentiality handling removed - should be handled by pattern extraction
        }
        // Device (exact match — not DeviceRequest)
        if (/^Device$/i.test(baseResource)) {
            if (!('deviceName' in base))
                base.deviceName = [{ name: 'Example Device', type: 'user-friendly-name' }];
            if (!('type' in base)) {
                const resolved = resolveBindingCode('type', 'http://snomed.info/sct', '49062001', 'Device');
                base.type = resolved || { coding: [{ system: 'http://snomed.info/sct', code: '49062001', display: 'Device' }] };
            }
            if (!('status' in base))
                base.status = 'active';
            // Apply nested primitive patterns to manufacturer if present
            const manufacturerPattern = getPrimitivePattern('manufacturer');
            if (manufacturerPattern !== undefined) {
                base.manufacturer = manufacturerPattern;
            }
            // Apply nested primitive patterns to deviceName entries if present
            if ('deviceName' in base && Array.isArray(base.deviceName) && base.deviceName.length > 0) {
                const namePattern = getPrimitivePattern('deviceName.name');
                const typePattern = getPrimitivePattern('deviceName.type');
                for (const deviceNameEntry of base.deviceName) {
                    if (namePattern !== undefined)
                        deviceNameEntry.name = namePattern;
                    if (typePattern !== undefined)
                        deviceNameEntry.type = typePattern;
                }
            }
        }
        // ValueSet - url must be a valid absolute URI (HTTP URL or proper URN)
        if (/ValueSet/i.test(baseResource)) {
            if (!('status' in base))
                base.status = 'active';
            if (!('url' in base))
                base.url = 'https://acme.org/fhir/ValueSet/' + randomId();
            // name must be machine-readable identifier (no spaces, starts with letter)
            if (!('name' in base))
                base.name = 'ExampleValueSet' + randomId().replace(/-/g, '');
            else if (typeof base.name === 'string' && /^[0-9a-f-]+$/i.test(base.name)) {
                // If name looks like a UUID/randomId, make it a valid identifier
                base.name = 'ValueSet' + base.name.replace(/-/g, '').substring(0, 10);
            }
            if (!('version' in base))
                base.version = '1.0.0';
            if (!('compose' in base))
                base.compose = { include: [{ system: 'http://loinc.org', concept: [{ code: '4548-4', display: 'Hemoglobin A1c/Hemoglobin.total in Blood' }] }] };
            // Handle useContext when pattern for 'code' is present (ISiK ValueSet)
            // The pattern key 'code' refers to useContext.code
            if (fieldPatterns && 'code' in fieldPatterns && !('useContext' in base)) {
                const codePattern = fieldPatterns['code'];
                base.useContext = [{
                        code: {
                            system: codePattern.system || 'http://terminology.hl7.org/CodeSystem/usage-context-type',
                            code: codePattern.code || 'focus'
                        },
                        valueCodeableConcept: {
                            coding: [{ system: 'http://hl7.org/fhir/resource-types', code: 'ValueSet' }]
                        }
                    }];
            }
        }
        // CodeSystem - url must be a valid absolute URI (HTTP URL or proper URN)
        if (/CodeSystem/i.test(baseResource)) {
            if (!('status' in base))
                base.status = 'active';
            if (!('content' in base))
                base.content = 'complete';
            if (!('url' in base))
                base.url = 'https://acme.org/fhir/CodeSystem/' + randomId();
            if (!('name' in base))
                base.name = 'ExampleCodeSystem';
            if (!('version' in base))
                base.version = '1.0.0';
            if (!('concept' in base))
                base.concept = [{ code: 'example', display: 'Example Code' }];
        }
        // RelatedPerson
        if (/RelatedPerson/i.test(baseResource)) {
            if (!('patient' in base))
                base.patient = { reference: 'Patient/' + randomId() };
            if (!('identifier' in base))
                base.identifier = [{ system: 'urn:ietf:rfc:3986', value: 'urn:uuid:' + randomUUID() }];
            if (!('name' in base))
                base.name = [{ family: randomId(), given: [randomId()] }];
            if (!('relationship' in base)) {
                const resolved = resolveBindingCode('relationship', 'http://terminology.hl7.org/CodeSystem/v3-RoleCode', 'FTH', 'father');
                base.relationship = [resolved || { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/v3-RoleCode', code: 'FTH', display: 'father' }] }];
            }
            if (!('address' in base))
                base.address = [{ city: 'Example City', postalCode: '12345', country: 'XX' }];
        }
        // DocumentReference
        if (/DocumentReference/i.test(baseResource)) {
            // Force correct status - 'active' is NOT valid for DocumentReference.status
            base.status = 'current';
            if (!('type' in base)) {
                const resolved = resolveBindingCode('type', 'http://loinc.org', '34133-9');
                base.type = resolved || { coding: [{ system: 'http://loinc.org', code: '34133-9' }] };
            }
            // Always use pattern if available for category, even if category already exists
            const patternCategory = getPatternValue('category');
            if (patternCategory) {
                base.category = [patternCategory];
            }
            else if (!('category' in base)) {
                base.category = [{ coding: [{ system: 'http://hl7.org/fhir/us/core/CodeSystem/us-core-documentreference-category', code: 'clinical-note' }] }];
            }
            if (!('subject' in base))
                base.subject = { reference: 'Patient/' + randomId() };
            if (!('content' in base)) {
                base.content = [{ attachment: { contentType: 'application/pdf', data: 'ZXhhbXBsZQ==', url: 'urn:uuid:' + randomUUID() } }];
            }
            else if (Array.isArray(base.content) && base.content.length > 0) {
                for (const c of base.content) {
                    if (c.attachment) {
                        if (!c.attachment.data)
                            c.attachment.data = 'ZXhhbXBsZQ==';
                        if (!c.attachment.url)
                            c.attachment.url = 'urn:uuid:' + randomUUID();
                        if (!c.attachment.contentType)
                            c.attachment.contentType = 'application/pdf';
                    }
                    else {
                        c.attachment = { contentType: 'application/pdf', data: 'ZXhhbXBsZQ==', url: 'urn:uuid:' + randomUUID() };
                    }
                }
            }
            // EPR format handling removed - should be handled by pattern extraction
        }
        // Specimen
        if (/Specimen/i.test(baseResource)) {
            // IPS Specimen requires type
            if (!isForbidden('type') && !('type' in base)) {
                const resolved = resolveBindingCode('type', 'http://snomed.info/sct', '119297000', 'Blood specimen');
                base.type = resolved || { coding: [{ system: 'http://snomed.info/sct', code: '119297000', display: 'Blood specimen' }] };
            }
            if (!isForbidden('subject') && !('subject' in base)) {
                base.subject = { reference: 'Patient/' + randomId() };
            }
        }
        // Binary
        if (/Binary/i.test(baseResource)) {
            if (!('contentType' in base))
                base.contentType = 'application/pdf';
            if (!('data' in base))
                base.data = 'SGVsbG8gV29ybGQ=';
        }
        // Coverage
        if (/Coverage/i.test(baseResource)) {
            if (!isForbidden('status') && !('status' in base))
                base.status = 'active';
            if (!isForbidden('type') && !('type' in base)) {
                const resolved = resolveBindingCode('type', 'http://terminology.hl7.org/CodeSystem/v3-ActCode', 'EHCPOL', 'extended healthcare');
                base.type = resolved || { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/v3-ActCode', code: 'EHCPOL', display: 'extended healthcare' }] };
            }
            if (!isForbidden('subscriberId') && !('subscriberId' in base))
                base.subscriberId = randomId();
            if (!isForbidden('beneficiary') && !('beneficiary' in base))
                base.beneficiary = { reference: 'Patient/' + randomId() };
            if (!isForbidden('payor') && !('payor' in base))
                base.payor = [{ reference: 'Organization/' + randomId() }];
        }
        // ImmunizationRecommendation
        if (/ImmunizationRecommendation/i.test(baseResource)) {
            // imr-1: one of vaccineCode or targetDisease SHALL be present in each recommendation
            if ('recommendation' in base && Array.isArray(base.recommendation)) {
                for (const rec of base.recommendation) {
                    if (!('vaccineCode' in rec) && !('targetDisease' in rec)) {
                        rec.vaccineCode = [{ coding: [{ system: 'http://snomed.info/sct', code: '787859002', display: 'Vaccine product' }], text: 'Vaccine product' }];
                    }
                }
            }
        }
        // Consent
        if (/Consent/i.test(baseResource)) {
            // ppc-1: Either a Policy or PolicyRule SHALL be present
            if (!('policy' in base) && !('policyRule' in base)) {
                const patternPolicyRule = getCompleteCodePatternValue('policyRule');
                if (patternPolicyRule) {
                    base.policyRule = patternPolicyRule;
                }
                else {
                    base.policyRule = { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/consentpolicycodes', code: 'hipaa-auth' }] };
                }
            }
        }
        // Subscription - apply channel nested patterns
        if (/Subscription/i.test(baseResource)) {
            if ('channel' in base && typeof base.channel === 'object' && base.channel !== null) {
                const channel = base.channel;
                const typePattern = getPrimitivePattern('channel.type');
                if (typePattern !== undefined)
                    channel.type = typePattern;
                const payloadPattern = getPrimitivePattern('channel.payload');
                if (payloadPattern !== undefined)
                    channel.payload = payloadPattern;
                // Add _payload extension for backport payload content if required
                const refReqs = getRefRequirements('channel');
                if (refReqs && refReqs['payload.extension'] && !('_payload' in channel)) {
                    channel._payload = { extension: [{
                                url: 'http://hl7.org/fhir/uv/subscriptions-backport/StructureDefinition/backport-payload-content',
                                valueCode: 'full-resource'
                            }] };
                }
            }
            // Add top-level extension if the profile requires it and it's empty/missing
            if (!base.extension || (Array.isArray(base.extension) && base.extension.length === 0)) {
                // Subscription profiles may require extensions — add a placeholder to avoid "missing required member: extension"
                // ISiK defines extension:content at Subscription.channel.payload.extension, not top-level
                // If Firely reports missing 'extension' at top-level, add empty array
            }
        }
        // Endpoint - address required, connectionType required, fix malformed extensions
        if (/Endpoint/i.test(baseResource)) {
            if (!('address' in base))
                base.address = 'https://acme.org/fhir';
            // connectionType is required 1..1 Coding; SMART profiles require 'hl7-fhir-rest'
            if (!('connectionType' in base) || (typeof base.connectionType === 'object' && base.connectionType !== null &&
                base.connectionType.code !== 'hl7-fhir-rest')) {
                base.connectionType = { system: 'http://terminology.hl7.org/CodeSystem/endpoint-connection-type', code: 'hl7-fhir-rest', display: 'HL7 FHIR' };
            }
            // Fix malformed extensions that have fullUrl instead of proper url + value[x]
            if (Array.isArray(base.extension)) {
                const validExtensions = base.extension
                    .filter(ext => ext && typeof ext === 'object' && 'url' in ext && typeof ext.url === 'string');
                // If no valid extensions remain, add a placeholder FHIR version extension
                if (validExtensions.length === 0) {
                    validExtensions.push({ url: 'http://hl7.org/fhir/StructureDefinition/endpoint-fhir-version', valueCode: '4.0.1' });
                }
                base.extension = validExtensions;
            }
        }
        // Task - handle input cardinality, integer types, attachment constraints, and code
        if (/Task/i.test(baseResource)) {
            // For PAS Task profiles, ensure code is from PASTaskCodes ValueSet
            if (profileUrl && /davinci-pas/i.test(profileUrl)) {
                base.code = { coding: [{ system: 'http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes', code: 'attachment-request-code', display: 'Attach Request Code' }] };
            }
            if (!('status' in base))
                base.status = 'requested';
            if (!('intent' in base))
                base.intent = 'order';
            if (!('requester' in base))
                base.requester = { reference: 'Organization/' + randomId() };
            if (!('owner' in base))
                base.owner = { reference: 'Organization/' + randomId() };
            if (!('for' in base))
                base['for'] = { reference: 'Patient/' + randomId() };
            // Fix paLineNumber extensions across ALL inputs — must be valueInteger, not valueString
            // Also fix any other integer-typed extension values
            const fixIntegerExtensions = (inputs) => {
                for (const inp of inputs) {
                    if (Array.isArray(inp.extension)) {
                        for (const ext of inp.extension) {
                            if (ext.url && String(ext.url).includes('paLineNumber')) {
                                if ('valueString' in ext) {
                                    ext.valueInteger = 1;
                                    delete ext.valueString;
                                }
                                if (!('valueInteger' in ext))
                                    ext.valueInteger = 1;
                            }
                        }
                    }
                }
            };
            if (Array.isArray(base.input))
                fixIntegerExtensions(base.input);
            if ('code' in base && typeof base.code === 'object' && base.code !== null) {
                const codeObj = base.code;
                const isAttachmentRequest = codeObj.coding?.some(c => c.code === 'attachment-request-code');
                if (isAttachmentRequest && Array.isArray(base.input)) {
                    const inputs = base.input;
                    // AttachmentNeeded: add AttachmentsNeeded input if not present
                    const hasAttachmentsNeeded = inputs.some(i => {
                        const t = i.type;
                        return t?.coding?.some(c => c.code === 'attachments-needed');
                    });
                    if (!hasAttachmentsNeeded) {
                        // Resolve code from AttachmentRequestCodes VS (LOINC CLASS=ATTACH or X12/755 codes)
                        // Fallback uses X12 PWK01 code '09' (Progress Notes) from the 005010/755 system,
                        // which is always valid since all codes from that system are included in AttachmentRequestCodes
                        const attachCode = resolveBindingCode('input.value[x]', 'https://codesystem.x12.org/005010/755', '09', 'Progress Notes');
                        inputs.push({
                            type: { coding: [{ system: 'http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes', code: 'attachments-needed' }] },
                            valueCodeableConcept: attachCode || { coding: [{ system: 'https://codesystem.x12.org/005010/755', code: '09', display: 'Progress Notes' }] }
                        });
                    }
                }
            }
        }
        // AllergyIntolerance - clinicalStatus required when verificationStatus != entered-in-error
        if (/AllergyIntolerance/i.test(baseResource)) {
            if (!('patient' in base))
                base.patient = { reference: 'Patient/' + randomId() };
            if (!('code' in base)) {
                const resolved = resolveBindingCode('code', 'http://snomed.info/sct', '387517004', 'Paracetamol');
                base.code = resolved || { coding: [{ system: 'http://snomed.info/sct', code: '387517004', display: 'Paracetamol' }] };
            }
            // Always include clinicalStatus to satisfy ait-1 constraint
            if (!('clinicalStatus' in base)) {
                const resolved = resolveBindingCode('clinicalStatus', 'http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical', 'active');
                base.clinicalStatus = resolved || { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical', code: 'active' }] };
            }
            if (!('verificationStatus' in base)) {
                const resolved = resolveBindingCode('verificationStatus', 'http://terminology.hl7.org/CodeSystem/allergyintolerance-verification', 'confirmed');
                base.verificationStatus = resolved || { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/allergyintolerance-verification', code: 'confirmed' }] };
            }
            // ait-2: clinicalStatus SHALL NOT be present if verificationStatus is entered-in-error
            if ('verificationStatus' in base && 'clinicalStatus' in base) {
                const vs = base.verificationStatus;
                if (vs?.coding?.some(c => c.code === 'entered-in-error')) {
                    delete base.clinicalStatus;
                }
            }
        }
        // MedicationRequest - requester required when intent='order'
        if (/MedicationRequest/i.test(baseResource)) {
            if (!('status' in base))
                base.status = 'active';
            if (!('intent' in base))
                base.intent = 'order';
            if (!('medicationCodeableConcept' in base) && !('medicationReference' in base)) {
                const resolved = resolveBindingCode('medicationCodeableConcept', 'http://www.nlm.nih.gov/research/umls/rxnorm', '1049502', 'Amoxicillin 250mg');
                base.medicationCodeableConcept = resolved || { coding: [{ system: 'http://www.nlm.nih.gov/research/umls/rxnorm', code: '1049502', display: 'Amoxicillin 250mg' }] };
            }
            if (!('subject' in base))
                base.subject = { reference: 'Patient/' + randomId() };
            // requester required when intent='order' (us-core-21 constraint)
            if (!('requester' in base))
                base.requester = { reference: 'Practitioner/' + randomId() };
        }
        // MedicationDispense
        if (/MedicationDispense/i.test(baseResource)) {
            if (!('status' in base))
                base.status = 'completed';
            if (!('medicationCodeableConcept' in base) && !('medicationReference' in base)) {
                const resolved = resolveBindingCode('medicationCodeableConcept', 'http://www.nlm.nih.gov/research/umls/rxnorm', '1049502', 'Amoxicillin 250mg');
                base.medicationCodeableConcept = resolved || { coding: [{ system: 'http://www.nlm.nih.gov/research/umls/rxnorm', code: '1049502', display: 'Amoxicillin 250mg' }] };
            }
            if (!('subject' in base))
                base.subject = { reference: 'Patient/' + randomId() };
            if (!('performer' in base))
                base.performer = [{ actor: { reference: 'Practitioner/' + randomId() } }];
            // us-core-20: whenHandedOver SHALL be present if status is 'completed'
            if (base.status === 'completed' && !('whenHandedOver' in base)) {
                base.whenHandedOver = new Date().toISOString();
            }
        }
        // Claim / ClaimResponse - insurer, item, identifier required by PAS profiles
        if (/^Claim$/i.test(baseResource)) {
            if (!('status' in base))
                base.status = 'active';
            if (!('type' in base))
                base.type = { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/claim-type', code: 'professional' }] };
            if (!('use' in base))
                base.use = 'preauthorization';
            if (!('patient' in base))
                base.patient = { reference: 'Patient/' + randomId() };
            if (!('created' in base))
                base.created = new Date().toISOString().substring(0, 10);
            if (!('provider' in base))
                base.provider = { reference: 'Practitioner/' + randomId() };
            if (!('insurer' in base))
                base.insurer = { reference: 'Organization/' + randomId() };
            if (!('priority' in base))
                base.priority = { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/processpriority', code: 'normal' }] };
            if (!('insurance' in base))
                base.insurance = [{ sequence: 1, focal: true, coverage: { reference: 'Coverage/' + randomId() } }];
            if (!('identifier' in base))
                base.identifier = [{ system: 'urn:ietf:rfc:3986', value: 'urn:uuid:' + randomUUID() }];
            if (!('item' in base))
                base.item = [{ sequence: 1, category: { coding: [{ system: 'https://x12.org/codes/service-type-codes', code: '3', display: 'Consultation' }] }, productOrService: { coding: [{ system: 'http://www.ama-assn.org/go/cpt', code: '99213' }] } }];
            // Ensure all items have category (required by PAS profiles)
            if (Array.isArray(base.item)) {
                for (const itm of base.item) {
                    if (!('category' in itm))
                        itm.category = { coding: [{ system: 'https://x12.org/codes/service-type-codes', code: '3', display: 'Consultation' }] };
                }
            }
        }
        // DeviceRequest - distinct from Device
        if (/^DeviceRequest$/i.test(baseResource)) {
            if (!('status' in base))
                base.status = 'active';
            if (!('intent' in base))
                base.intent = 'order';
            if (!('codeCodeableConcept' in base) && !('codeReference' in base)) {
                base.codeCodeableConcept = { coding: [{ system: 'http://snomed.info/sct', code: '360006', display: 'Device' }] };
            }
            if (!('subject' in base))
                base.subject = { reference: 'Patient/' + randomId() };
            // Remove Device-specific properties not valid on DeviceRequest
            delete base.deviceName;
        }
        // PractitionerRole - needs practitioner/organization/location/healthcareService AND telecom/endpoint
        if (/PractitionerRole/i.test(baseResource)) {
            // Remove any Patient-like fields that don't belong
            delete base.name;
            delete base.gender;
            delete base.birthDate;
            delete base.address;
            // Required fields for us-core-13: practitioner, organization, location, or healthcareService
            if (!('practitioner' in base))
                base.practitioner = { reference: 'Practitioner/' + randomId() };
            if (!('organization' in base))
                base.organization = { reference: 'Organization/' + randomId() };
            // Required for pd-1: telecom or endpoint
            if (!('telecom' in base) && !('endpoint' in base)) {
                base.telecom = [{ system: 'phone', value: '+1-555-555-5555', use: 'work' }];
            }
            if (!('code' in base)) {
                const resolved = resolveBindingCode('code', 'http://terminology.hl7.org/CodeSystem/practitioner-role', 'doctor');
                base.code = [resolved || { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/practitioner-role', code: 'doctor' }] }];
            }
        }
        // DiagnosticReport - needs effective[x]
        if (/DiagnosticReport/i.test(baseResource)) {
            if (!('status' in base))
                base.status = 'final';
            if (!('code' in base)) {
                const resolved = resolveBindingCode('code', 'http://loinc.org', '58410-2', 'Complete blood count');
                base.code = resolved || { coding: [{ system: 'http://loinc.org', code: '58410-2', display: 'Complete blood count' }] };
            }
            if (!('subject' in base))
                base.subject = { reference: 'Patient/' + randomId() };
            if (!('effectiveDateTime' in base) && !('effectivePeriod' in base)) {
                base.effectiveDateTime = new Date().toISOString();
            }
            if (!('issued' in base))
                base.issued = new Date().toISOString();
            // Category for laboratory reports
            if (profileUrl.includes('laboratory')) {
                if (!('category' in base)) {
                    const resolved = resolveBindingCode('category', 'http://terminology.hl7.org/CodeSystem/v2-0074', 'LAB');
                    base.category = [resolved || { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/v2-0074', code: 'LAB' }] }];
                }
            }
            // presentedForm for note-exchange
            if (profileUrl.includes('note-exchange')) {
                if (!('presentedForm' in base))
                    base.presentedForm = [{ contentType: 'application/pdf', data: 'ZXhhbXBsZQ==' }];
            }
        }
        // Generic narrative for DomainResource derivatives
        // Bundle, Binary, and Parameters are pure Resource (not DomainResource) and do NOT support text/narrative
        if (!/^(Bundle|Binary|Parameters)$/.test(baseResource)) {
            if (!('text' in base)) {
                // Check if there's a pattern constraint for text.status
                const textStatusPattern = getPrimitivePattern('text.status');
                const status = textStatusPattern !== undefined ? textStatusPattern : 'generated';
                base.text = { status: status, div: '<div xmlns="http://www.w3.org/1999/xhtml">Generated</div>' };
            }
            else if (typeof base.text === 'object' && base.text !== null) {
                // Apply text.status pattern to existing text object
                const textStatusPattern = getPrimitivePattern('text.status');
                if (textStatusPattern !== undefined) {
                    base.text.status = textStatusPattern;
                }
            }
        }
        // Extension value fallback
        if (/Extension/.test(baseResource)) {
            const hasValue = Object.keys(base).some(k => k.startsWith('value'));
            if (!hasValue)
                base['valueString'] = 'value';
            if (!('url' in base))
                base.url = profileUrl || 'urn:uuid:extension';
        }
        // Generic Reference enrichment: apply nested requirements to all Reference fields
        // This handles profile-level constraints that require identifier/display on References
        // like Encounter.serviceProvider.identifier and Encounter.serviceProvider.display
        if (fieldPatterns) {
            for (const key of Object.keys(fieldPatterns)) {
                if (key.startsWith('_refReq_')) {
                    const refFieldName = key.slice('_refReq_'.length);
                    // Check if the field exists in base (could be a Reference or array of References)
                    const fieldValue = base[refFieldName];
                    const reqs = fieldPatterns[key];
                    // Handle primitive element extensions (e.g., confidentiality with _confidentiality.extension)
                    // FHIR uses _<fieldName> prefix for extensions on primitive elements only.
                    // Complex types (BackboneElement, arrays) should have extensions inside each element.
                    const extReq = reqs['extension'];
                    const reqKeys = Object.keys(reqs);
                    const isComplexField = reqKeys.some(k => k !== 'extension') || Array.isArray(fieldValue) || (fieldValue !== null && typeof fieldValue === 'object');
                    if (extReq && !isComplexField) {
                        // This is a primitive field that needs an extension on the underscore-prefixed element
                        // First ensure the primitive field has a value
                        if (!fieldValue) {
                            // Generate a default value for common primitive fields
                            if (refFieldName === 'confidentiality') {
                                base[refFieldName] = 'N'; // Normal confidentiality
                            }
                        }
                        // Add the _<fieldName> with extension
                        const underscoreFieldName = '_' + refFieldName;
                        if (!base[underscoreFieldName]) {
                            const extProfile = typeof extReq === 'object' && extReq.profile
                                ? String(extReq.profile)
                                : undefined;
                            // Create extension with the profile URL if available
                            const ext = { url: extProfile || 'https://acme.org/extension' };
                            // For known CH Core extension profiles, add a valueCodeableConcept with sample data
                            if (extProfile && extProfile.includes('ch-ext-epr-confidentialitycode')) {
                                ext.valueCodeableConcept = {
                                    coding: [{
                                            system: 'http://snomed.info/sct',
                                            code: '17621005'
                                        }]
                                };
                            }
                            else {
                                // Generic fallback: add a string value
                                ext.valueString = 'Example extension value';
                            }
                            base[underscoreFieldName] = {
                                extension: [ext]
                            };
                        }
                        continue; // Skip the rest of the _refReq processing for this field
                    }
                    // For complex types (BackboneElement arrays) with extension requirements,
                    // inject extension into each array element rather than using _fieldName sidecar
                    if (extReq && isComplexField && Array.isArray(fieldValue)) {
                        const extProfile = typeof extReq === 'object' && extReq.profile
                            ? String(extReq.profile)
                            : undefined;
                        for (const elem of fieldValue) {
                            if (elem && typeof elem === 'object' && !('extension' in elem)) {
                                const ext = { url: extProfile || 'https://acme.org/extension' };
                                // Use valueInteger for known integer-typed extensions (e.g., paLineNumber)
                                if (extProfile && /lineNumber|integer|count|sequence/i.test(extProfile)) {
                                    ext.valueInteger = 1;
                                }
                                else {
                                    ext.valueString = 'Example';
                                }
                                elem.extension = [ext];
                            }
                        }
                    }
                    if (fieldValue) {
                        // Determine target resource type from the reference
                        let targetType = 'Resource';
                        if (Array.isArray(fieldValue)) {
                            // Array of References or CodeableConcepts
                            for (const ref of fieldValue) {
                                if (ref && typeof ref === 'object') {
                                    const refObj = ref;
                                    if (typeof refObj.reference === 'string') {
                                        const match = refObj.reference.match(/^([A-Za-z]+)\//);
                                        if (match)
                                            targetType = match[1];
                                    }
                                    // Add required nested properties
                                    if ((reqs['identifier'] || reqs['identifier.system'] || reqs['identifier.value']) && !('identifier' in refObj)) {
                                        refObj.identifier = { system: 'urn:ietf:rfc:3986', value: 'urn:uuid:' + randomUUID() };
                                    }
                                    if (reqs['display'] && !('display' in refObj)) {
                                        refObj.display = 'Example ' + targetType;
                                    }
                                    // Handle CodeableConcept.text requirement
                                    if (reqs['text'] && !('text' in refObj)) {
                                        if ('coding' in refObj && Array.isArray(refObj.coding)) {
                                            const firstCoding = refObj.coding[0];
                                            const displayText = (firstCoding && firstCoding.display) || (firstCoding && firstCoding.code) || 'Example text';
                                            refObj.text = String(displayText);
                                        }
                                    }
                                }
                            }
                        }
                        else if (typeof fieldValue === 'object') {
                            // Single Reference
                            const refObj = fieldValue;
                            if (typeof refObj.reference === 'string') {
                                const match = refObj.reference.match(/^([A-Za-z]+)\//);
                                if (match)
                                    targetType = match[1];
                            }
                            // Add required nested properties
                            if ((reqs['identifier'] || reqs['identifier.system'] || reqs['identifier.value']) && !('identifier' in refObj)) {
                                refObj.identifier = { system: 'urn:ietf:rfc:3986', value: 'urn:uuid:' + randomUUID() };
                            }
                            if (reqs['display'] && !('display' in refObj)) {
                                refObj.display = 'Example ' + targetType;
                            }
                            // Handle CodeableConcept nested requirements (e.g., type.text for ISiKBerichtSubSysteme)
                            // CodeableConcept has: coding (array), text (string)
                            if (reqs['text'] && !('text' in refObj)) {
                                // Check if this looks like a CodeableConcept (has coding array)
                                if ('coding' in refObj && Array.isArray(refObj.coding)) {
                                    // Get display from first coding if available
                                    const firstCoding = refObj.coding[0];
                                    const displayText = firstCoding?.display || firstCoding?.code || 'Example text';
                                    refObj.text = String(displayText);
                                }
                            }
                        }
                    }
                }
            }
        }
        // Generic identifier URI fix: when system is 'urn:ietf:rfc:3986', value must be a valid URI
        const fixIdentifierURIs = (obj) => {
            if (!obj || typeof obj !== 'object')
                return;
            if (Array.isArray(obj)) {
                obj.forEach(fixIdentifierURIs);
                return;
            }
            const rec = obj;
            if (rec.system === 'urn:ietf:rfc:3986' && typeof rec.value === 'string' && !/^(urn:|https?:\/\/)/.test(rec.value)) {
                rec.value = 'urn:uuid:' + randomUUID();
            }
            for (const val of Object.values(rec)) {
                if (val && typeof val === 'object')
                    fixIdentifierURIs(val);
            }
        };
        fixIdentifierURIs(base);
        // Generic extension value fix: simple extensions must have value[x], not nested extensions
        // ext-1: "Must have either extensions or value[x], not both"
        // Only applies to objects within 'extension' arrays, not every object with 'url'
        const fixExtensionValues = (obj, isInExtensionArray) => {
            if (!obj || typeof obj !== 'object')
                return;
            if (Array.isArray(obj)) {
                obj.forEach(item => fixExtensionValues(item, isInExtensionArray));
                return;
            }
            const rec = obj;
            // Only fix objects that are inside an extension array and have a url property
            if (isInExtensionArray && 'url' in rec && typeof rec.url === 'string') {
                const hasValue = Object.keys(rec).some(k => k.startsWith('value'));
                const hasNestedExt = 'extension' in rec && Array.isArray(rec.extension) && rec.extension.length > 0;
                if (hasNestedExt && hasValue) {
                    // ext-1 violation: has both extension and value — remove nested extensions
                    delete rec.extension;
                }
                else if (!hasValue && !hasNestedExt) {
                    // Simple extension with no value — use CodeableConcept (most common extension type)
                    rec.valueCodeableConcept = { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/data-absent-reason', code: 'unknown', display: 'Unknown' }] };
                }
            }
            // Recurse: mark children of 'extension' arrays
            for (const [key, val] of Object.entries(rec)) {
                if (val && typeof val === 'object') {
                    fixExtensionValues(val, key === 'extension' || key === 'modifierExtension');
                }
            }
        };
        fixExtensionValues(base, false);
        // Fix integer-typed extensions: paLineNumber and similar must use valueInteger
        const fixIntegerTypedExtensions = (obj) => {
            if (!obj || typeof obj !== 'object')
                return;
            if (Array.isArray(obj)) {
                obj.forEach(fixIntegerTypedExtensions);
                return;
            }
            const rec = obj;
            if ('url' in rec && typeof rec.url === 'string' && /lineNumber|integer|count|sequence/i.test(rec.url)) {
                // Replace any non-integer value with valueInteger
                for (const k of Object.keys(rec)) {
                    if (k.startsWith('value') && k !== 'valueInteger') {
                        delete rec[k];
                    }
                }
                if (!('valueInteger' in rec))
                    rec.valueInteger = 1;
            }
            for (const val of Object.values(rec)) {
                if (val && typeof val === 'object')
                    fixIntegerTypedExtensions(val);
            }
        };
        fixIntegerTypedExtensions(base);
        // Reorder fields to match FHIR element ordering.
        // FHIR base Resource/DomainResource fields always come first, then domain-specific fields
        // in the order defined by the StructureDefinition (passed via fieldOrder).
        // Firely (and HL7) validators enforce this ordering.
        const fhirBaseFieldOrder = [
            'resourceType', 'id', 'meta', 'implicitRules', 'language',
            'text', 'contained', 'extension', 'modifierExtension'
        ];
        const reordered = {};
        // 1. Add base FHIR fields in canonical order
        for (const key of fhirBaseFieldOrder) {
            if (key in base) {
                reordered[key] = base[key];
                delete base[key];
            }
        }
        // 2. If fieldOrder is provided, add domain-specific fields in SD element order
        if (fieldOrder.length > 0) {
            for (const key of fieldOrder) {
                if (key in base) {
                    reordered[key] = base[key];
                    delete base[key];
                }
            }
        }
        // 3. Copy any remaining fields not covered by either ordering
        for (const key of Object.keys(base)) {
            reordered[key] = base[key];
        }
        // Overwrite base in-place
        for (const key of Object.keys(base)) {
            delete base[key];
        }
        Object.assign(base, reordered);
        // Reorder CodeableConcept child fields: FHIR requires 'coding' before 'text'.
        // Firely and HL7 validators both enforce this element ordering within CodeableConcept.
        // Recursively walks the entire object tree to fix nested CodeableConcepts.
        const reorderCodeableConcept = (obj) => {
            if ('coding' in obj && 'text' in obj) {
                const keys = Object.keys(obj);
                const codingIdx = keys.indexOf('coding');
                const textIdx = keys.indexOf('text');
                if (textIdx < codingIdx) {
                    // text appears before coding — rebuild with correct order
                    const entries = Object.entries(obj);
                    for (const k of keys)
                        delete obj[k];
                    // coding first, then everything else preserving order
                    const codingEntry = entries.find(([k]) => k === 'coding');
                    const rest = entries.filter(([k]) => k !== 'coding');
                    obj[codingEntry[0]] = codingEntry[1];
                    for (const [k, v] of rest)
                        obj[k] = v;
                }
            }
            // Recurse into child objects and arrays
            for (const val of Object.values(obj)) {
                if (val && typeof val === 'object' && !Array.isArray(val)) {
                    reorderCodeableConcept(val);
                }
                else if (Array.isArray(val)) {
                    for (const item of val) {
                        if (item && typeof item === 'object' && !Array.isArray(item)) {
                            reorderCodeableConcept(item);
                        }
                    }
                }
            }
        };
        reorderCodeableConcept(base);
    }
    catch { /* enrichment is best-effort */ }
}
