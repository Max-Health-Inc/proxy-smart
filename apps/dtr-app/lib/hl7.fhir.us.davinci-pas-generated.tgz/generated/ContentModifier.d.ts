import { Extension } from "fhir/r4";
export interface ContentModifier extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-contentModifier";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateContentModifier(resource: ContentModifier, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
