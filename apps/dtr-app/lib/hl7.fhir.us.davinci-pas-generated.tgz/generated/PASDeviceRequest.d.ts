import { ExtCoverageInformation } from "./ExtCoverageInformation";
import { DeviceRequest, Extension, Reference } from "fhir/r4";
export interface PASDeviceRequest extends DeviceRequest {
    intent: "order";
    /** Must Support */
    subject: Reference;
    extension?: (Extension | ExtCoverageInformation)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASDeviceRequest(resource: PASDeviceRequest, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
