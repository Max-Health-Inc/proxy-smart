import { Extension } from "fhir/r4";
export interface InfoCancelledFlag extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/modifierextension-infoCancelled";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateInfoCancelledFlag(resource: InfoCancelledFlag, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
