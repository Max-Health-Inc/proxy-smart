import { X12278RequestedServiceTypeCode } from "./valuesets/ValueSet-X12278RequestedServiceType";
import { ExtCoverageInformation } from "./ExtCoverageInformation";
import { CodeableConcept, Extension, Reference, ServiceRequest } from "fhir/r4";
import { ProductOrServiceCodeEnd } from "./ProductOrServiceCodeEnd";
export interface PASServiceRequest extends ServiceRequest {
    intent: "order";
    /** Must Support | @see {@link ./valuesets/ValueSet-X12278RequestedServiceType.ts} for valid codes (1 codes) */
    code?: CodeableConcept & {
        coding: Array<{
            code: X12278RequestedServiceTypeCode;
            system: "http://terminology.hl7.org/CodeSystem/data-absent-reason";
        }>;
    };
    /** Must Support */
    subject: Reference;
    extension?: (Extension | ProductOrServiceCodeEnd | ExtCoverageInformation)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASServiceRequest(resource: PASServiceRequest, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
