import { Extension } from "fhir/r4";
export interface NursingHomeResidentialStatus extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-nursingHomeResidentialStatus";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateNursingHomeResidentialStatus(resource: NursingHomeResidentialStatus, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
