import { X12278DiagnosisTypeCode } from "./valuesets/ValueSet-X12278DiagnosisType";
import { X12278RequestedServiceTypeCode } from "./valuesets/ValueSet-X12278RequestedServiceType";
import { AdministrationReferenceNumber } from "./AdministrationReferenceNumber";
import { AuthorizationNumber } from "./AuthorizationNumber";
import { CareTeamClaimScope } from "./CareTeamClaimScope";
import { CertificationType } from "./CertificationType";
import { ConditionCode } from "./ConditionCode";
import { DiagnosisRecordedDate } from "./DiagnosisRecordedDate";
import { EPSDTIndicator } from "./EPSDTIndicator";
import { ExtensionClaimEncounter } from "./ExtensionClaimEncounter";
import { HomeHealthCareInformation } from "./HomeHealthCareInformation";
import { ItemTraceNumber } from "./ItemTraceNumber";
import { LevelOfServiceCode } from "./LevelOfServiceCode";
import { NursingHomeLevelOfCare } from "./NursingHomeLevelOfCare";
import { NursingHomeResidentialStatus } from "./NursingHomeResidentialStatus";
import { Claim, ClaimCareTeam, ClaimDiagnosis, ClaimItem, CodeableConcept, Extension, Identifier, Money, Reference } from "fhir/r4";
import { ProductOrServiceCodeEnd } from "./ProductOrServiceCodeEnd";
import { RequestedService } from "./RequestedService";
import { RevenueUnitRateLimit } from "./RevenueUnitRateLimit";
import { ServiceItemRequestType } from "./ServiceItemRequestType";
import { SimpleQuantity } from "./SimpleQuantity";
export interface ExtensionRequestedService extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-requestedService';
}
export interface ExtensionRevenueUnitRateLimit extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-revenueUnitRateLimit';
}
export interface ExtensionNursingHomeLevelOfCare extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-nursingHomeLevelOfCare';
}
export interface ExtensionNursingHomeResidentialStatus extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-nursingHomeResidentialStatus';
}
export interface ExtensionEpsdtIndicator extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-epsdtIndicator';
}
export interface ExtensionProductOrServiceCodeEnd extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-productOrServiceCodeEnd';
}
export interface ExtensionCertificationType extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-certificationType';
}
export interface ExtensionServiceItemRequestType extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-serviceItemRequestType';
}
export interface ExtensionAdministrationReferenceNumber extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-administrationReferenceNumber';
}
export interface ExtensionAuthorizationNumber extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-authorizationNumber';
}
export interface ExtensionItemTraceNumber extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemTraceNumber';
}
export interface ExtensionDiagnosisRecordedDate extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-diagnosisRecordedDate';
}
export interface ExtensionCareTeamClaimScope extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-careTeamClaimScope';
}
export interface PASClaimCareTeam extends ClaimCareTeam {
    /** Must Support */
    provider: Reference;
    /** Must Support */
    role?: CodeableConcept;
    /** Must Support */
    qualification?: CodeableConcept;
    extension?: (Extension | CareTeamClaimScope | CareTeamClaimScope | CareTeamClaimScope)[];
}
export interface PASClaimDiagnosis extends ClaimDiagnosis {
    /** Must Support | @see {@link ./valuesets/ValueSet-X12278DiagnosisType.ts} for valid codes (3 codes) */
    type?: CodeableConcept & {
        coding: Array<{
            code: X12278DiagnosisTypeCode;
            system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes";
        }>;
    }[];
    extension?: (Extension | DiagnosisRecordedDate)[];
}
export interface PASClaimItem extends ClaimItem {
    /** Must Support */
    revenue?: CodeableConcept;
    /** Must Support */
    category: CodeableConcept;
    /** Must Support | @see {@link ./valuesets/ValueSet-X12278RequestedServiceType.ts} for valid codes (1 codes) */
    productOrService: CodeableConcept & {
        coding: Array<{
            code: X12278RequestedServiceTypeCode;
            system: "http://terminology.hl7.org/CodeSystem/data-absent-reason";
        }>;
    };
    /** Must Support */
    modifier?: CodeableConcept[];
    /** Must Support */
    quantity?: SimpleQuantity;
    /** Must Support */
    unitPrice?: Money;
    extension?: (Extension | ItemTraceNumber | AuthorizationNumber | AdministrationReferenceNumber | ServiceItemRequestType | CertificationType | ProductOrServiceCodeEnd | EPSDTIndicator | NursingHomeResidentialStatus | NursingHomeLevelOfCare | RevenueUnitRateLimit | RequestedService)[];
}
export interface PASClaim extends Claim {
    /** Must Support */
    identifier: Identifier[];
    status: "active";
    use: "preauthorization";
    /** Must Support */
    careTeam?: PASClaimCareTeam[];
    /** Must Support */
    diagnosis?: PASClaimDiagnosis[];
    /** Must Support */
    item: PASClaimItem[];
    extension?: (Extension | LevelOfServiceCode | ConditionCode | HomeHealthCareInformation | ExtensionClaimEncounter)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASClaim(resource: PASClaim, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
