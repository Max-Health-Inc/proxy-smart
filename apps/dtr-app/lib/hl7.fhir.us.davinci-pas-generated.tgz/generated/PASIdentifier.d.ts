import { IdentifierJurisdiction } from "./IdentifierJurisdiction";
import { IdentifierSubDepartment } from "./IdentifierSubDepartment";
import { Extension, Identifier } from "fhir/r4";
export interface PASIdentifier extends Identifier {
    extension?: (Extension | IdentifierSubDepartment | IdentifierJurisdiction)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASIdentifier(resource: PASIdentifier, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
