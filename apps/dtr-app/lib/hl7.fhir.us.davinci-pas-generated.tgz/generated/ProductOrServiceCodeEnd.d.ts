import { Extension } from "fhir/r4";
export interface ProductOrServiceCodeEnd extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-productOrServiceCodeEnd";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateProductOrServiceCodeEnd(resource: ProductOrServiceCodeEnd, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
