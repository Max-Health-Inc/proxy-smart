import { Extension } from "fhir/r4";
export interface CertificationEffectiveDate extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemCertificationEffectiveDate";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateCertificationEffectiveDate(resource: CertificationEffectiveDate, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
