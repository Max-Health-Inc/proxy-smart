import { Extension } from "fhir/r4";
export interface CalendarPattern extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-timingcalendarpattern";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateCalendarPattern(resource: CalendarPattern, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
