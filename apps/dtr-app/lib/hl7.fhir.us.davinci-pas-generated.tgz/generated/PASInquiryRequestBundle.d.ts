import { Bundle, BundleEntry, FhirResource, Identifier } from "fhir/r4";
export interface PASInquiryRequestBundleEntry extends BundleEntry {
    /** Must Support */
    resource: FhirResource;
}
export interface PASInquiryRequestBundle extends Bundle {
    /** Must Support */
    identifier: Identifier;
    type: "collection";
    /** Must Support */
    entry: PASInquiryRequestBundleEntry[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASInquiryRequestBundle(resource: PASInquiryRequestBundle, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
