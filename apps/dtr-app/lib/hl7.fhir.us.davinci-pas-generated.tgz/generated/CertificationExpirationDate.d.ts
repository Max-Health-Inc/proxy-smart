import { Extension } from "fhir/r4";
export interface CertificationExpirationDate extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemCertificationExpirationDate";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateCertificationExpirationDate(resource: CertificationExpirationDate, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
