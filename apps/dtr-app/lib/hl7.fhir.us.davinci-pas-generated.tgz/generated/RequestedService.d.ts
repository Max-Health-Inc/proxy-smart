import { Extension } from "fhir/r4";
export interface RequestedService extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-requestedService";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateRequestedService(resource: RequestedService, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
