import { Extension } from "fhir/r4";
export interface InfoChanged extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-infoChanged";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateInfoChanged(resource: InfoChanged, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
