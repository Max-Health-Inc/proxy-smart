import { Extension, Identifier } from "fhir/r4";
export interface ItemTraceNumber extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemTraceNumber";
    value?: Identifier;
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateItemTraceNumber(resource: ItemTraceNumber, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
