import { Extension } from "fhir/r4";
export interface ItemPreAuthPeriod extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemPreAuthPeriod";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateItemPreAuthPeriod(resource: ItemPreAuthPeriod, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
