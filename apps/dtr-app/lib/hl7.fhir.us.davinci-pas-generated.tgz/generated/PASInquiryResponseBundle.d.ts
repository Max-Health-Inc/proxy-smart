import { Bundle, BundleEntry, FhirResource } from "fhir/r4";
export interface PASInquiryResponseBundleEntry extends BundleEntry {
    /** Must Support */
    resource: FhirResource;
}
export interface PASInquiryResponseBundle extends Bundle {
    type: "collection";
    /** Must Support */
    entry: PASInquiryResponseBundleEntry[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASInquiryResponseBundle(resource: PASInquiryResponseBundle, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
