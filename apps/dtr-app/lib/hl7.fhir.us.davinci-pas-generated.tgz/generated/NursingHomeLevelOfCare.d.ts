import { Extension } from "fhir/r4";
export interface NursingHomeLevelOfCare extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-nursingHomeLevelOfCare";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateNursingHomeLevelOfCare(resource: NursingHomeLevelOfCare, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
