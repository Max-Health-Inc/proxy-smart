import { Organization } from "fhir/r4";
export interface PASOrganization extends Organization {
    /** Must Support */
    active: boolean;
    /** Must Support */
    name: string;
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASOrganization(resource: PASOrganization, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
