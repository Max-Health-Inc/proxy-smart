import { ExtCoverageInformation } from "./ExtCoverageInformation";
import { PASTiming } from "./PASTiming";
import { SimpleQuantity } from "./SimpleQuantity";
import { Dosage, Extension, MedicationRequest, MedicationRequestDispenseRequest, Reference } from "fhir/r4";
export interface PASMedicationRequestDosageInstruction extends Dosage {
    /** Must Support */
    timing?: PASTiming;
    maxDosePerAdministration?: SimpleQuantity;
    maxDosePerLifetime?: SimpleQuantity;
}
export interface PASMedicationRequestDispenseRequest extends MedicationRequestDispenseRequest {
    /** Must Support */
    quantity?: SimpleQuantity;
}
export interface PASMedicationRequest extends MedicationRequest {
    intent: "order";
    /** Must Support */
    subject: Reference;
    /** Must Support */
    authoredOn: string;
    /** Must Support */
    requester: Reference;
    /** Must Support */
    dosageInstruction?: PASMedicationRequestDosageInstruction[];
    /** Must Support */
    dispenseRequest?: PASMedicationRequestDispenseRequest;
    extension?: (Extension | ExtCoverageInformation)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASMedicationRequest(resource: PASMedicationRequest, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
