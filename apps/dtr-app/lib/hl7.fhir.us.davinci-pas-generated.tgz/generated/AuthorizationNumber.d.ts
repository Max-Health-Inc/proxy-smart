import { Extension } from "fhir/r4";
export interface AuthorizationNumber extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-authorizationNumber";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateAuthorizationNumber(resource: AuthorizationNumber, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
