import fhirpath from "fhirpath";
import fhirpath_r4_model from "fhirpath/fhir-context/r4/index.js";
export async function validateInfoChanged(resource, options) {
    const errors = [];
    const warnings = [];
    const fhirpathOptions = {
        preciseMath: true,
        ...(options?.traceFn ? { traceFn: options.traceFn } : {}),
        ...(options?.signal ? { signal: options.signal } : {}),
        ...(options?.httpHeaders ? { httpHeaders: options.httpHeaders } : {}),
    };
    const result0 = await fhirpath.evaluate(resource, "Extension.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result0.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result1 = await fhirpath.evaluate(resource, "extension.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result1.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result2 = await fhirpath.evaluate(resource, "value.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result2.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result3 = await fhirpath.evaluate(resource, "Element.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result3.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result4 = await fhirpath.evaluate(resource, "url.exists()", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result4.every(Boolean)) {
        errors.push("Constraint violation: url must be present");
    }
    const result5 = await fhirpath.evaluate(resource, "extension.count() <= 0", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result5.every(Boolean)) {
        errors.push("Constraint violation: extension must contain at most 0 elements");
    }
    // Fixed value constraint for url
    if (resource.url !== undefined && resource.url !== "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-infoChanged") {
        errors.push("url must have the fixed value 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-infoChanged'");
    }
    return { errors, warnings };
}
