import { Extension } from "fhir/r4";
export interface DiagnosisRecordedDate extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-diagnosisRecordedDate";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateDiagnosisRecordedDate(resource: DiagnosisRecordedDate, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
