import { Extension } from "fhir/r4";
export interface AdministrationReferenceNumber extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-administrationReferenceNumber";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateAdministrationReferenceNumber(resource: AdministrationReferenceNumber, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
