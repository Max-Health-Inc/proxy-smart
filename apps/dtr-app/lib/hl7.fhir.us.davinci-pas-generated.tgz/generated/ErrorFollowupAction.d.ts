import { Extension } from "fhir/r4";
export interface ErrorFollowupAction extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-errorFollowupAction";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateErrorFollowupAction(resource: ErrorFollowupAction, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
