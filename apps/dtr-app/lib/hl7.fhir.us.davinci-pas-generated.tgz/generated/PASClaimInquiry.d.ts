import { X12278RequestedServiceTypeCode } from "./valuesets/ValueSet-X12278RequestedServiceType";
import { AdministrationReferenceNumber } from "./AdministrationReferenceNumber";
import { AuthorizationNumber } from "./AuthorizationNumber";
import { CareTeamClaimScope } from "./CareTeamClaimScope";
import { CertificationEffectiveDate } from "./CertificationEffectiveDate";
import { CertificationExpirationDate } from "./CertificationExpirationDate";
import { CertificationIssueDate } from "./CertificationIssueDate";
import { CertificationType } from "./CertificationType";
import { ConditionCode } from "./ConditionCode";
import { HomeHealthCareInformation } from "./HomeHealthCareInformation";
import { ItemTraceNumber } from "./ItemTraceNumber";
import { LevelOfServiceCode } from "./LevelOfServiceCode";
import { Claim, ClaimCareTeam, ClaimItem, CodeableConcept, Extension, Identifier, Period, Reference } from "fhir/r4";
import { ProductOrServiceCodeEnd } from "./ProductOrServiceCodeEnd";
import { ReviewActionCode } from "./ReviewActionCode";
import { ServiceItemRequestType } from "./ServiceItemRequestType";
import { SimpleQuantity } from "./SimpleQuantity";
export interface ExtensionReviewActionCode extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-reviewActionCode';
}
export interface ExtensionItemCertificationEffectiveDate extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemCertificationEffectiveDate';
}
export interface ExtensionItemCertificationExpirationDate extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemCertificationExpirationDate';
}
export interface ExtensionItemCertificationIssueDate extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemCertificationIssueDate';
}
export interface ExtensionProductOrServiceCodeEnd extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-productOrServiceCodeEnd';
}
export interface ExtensionCertificationType extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-certificationType';
}
export interface ExtensionServiceItemRequestType extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-serviceItemRequestType';
}
export interface ExtensionAdministrationReferenceNumber extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-administrationReferenceNumber';
}
export interface ExtensionAuthorizationNumber extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-authorizationNumber';
}
export interface ExtensionItemTraceNumber extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemTraceNumber';
}
export interface ExtensionCareTeamClaimScope extends Extension {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-careTeamClaimScope';
}
export interface PASClaimInquiryCareTeam extends ClaimCareTeam {
    /** Must Support */
    provider: Reference;
    /** Must Support */
    role?: CodeableConcept;
    /** Must Support */
    qualification?: CodeableConcept;
    extension?: (Extension | CareTeamClaimScope | CareTeamClaimScope | CareTeamClaimScope)[];
}
export interface PASClaimInquiryItem extends ClaimItem {
    /** Must Support */
    revenue?: CodeableConcept;
    /** Must Support | @see {@link ./valuesets/ValueSet-X12278RequestedServiceType.ts} for valid codes (1 codes) */
    productOrService: CodeableConcept & {
        coding: Array<{
            code: X12278RequestedServiceTypeCode;
            system: "http://terminology.hl7.org/CodeSystem/data-absent-reason";
        }>;
    };
    /** Must Support */
    modifier?: CodeableConcept[];
    /** Must Support */
    quantity?: SimpleQuantity;
    extension?: (Extension | ItemTraceNumber | AuthorizationNumber | AdministrationReferenceNumber | ServiceItemRequestType | CertificationType | ProductOrServiceCodeEnd | CertificationIssueDate | CertificationExpirationDate | CertificationEffectiveDate | ReviewActionCode)[];
}
export interface PASClaimInquiry extends Claim {
    /** Must Support */
    identifier?: Identifier[];
    status: "active";
    use: "preauthorization";
    /** Must Support */
    billablePeriod?: Period;
    /** Must Support */
    careTeam?: PASClaimInquiryCareTeam[];
    /** Must Support */
    item: PASClaimInquiryItem[];
    extension?: (Extension | LevelOfServiceCode | ConditionCode | HomeHealthCareInformation | CertificationType)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASClaimInquiry(resource: PASClaimInquiry, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
