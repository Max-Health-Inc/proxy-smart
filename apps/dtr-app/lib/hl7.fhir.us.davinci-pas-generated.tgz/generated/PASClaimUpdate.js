import fhirpath from "fhirpath";
import fhirpath_r4_model from "fhirpath/fhir-context/r4/index.js";
export async function validatePASClaimUpdate(resource, options) {
    const errors = [];
    const warnings = [];
    const fhirpathOptions = {
        preciseMath: true,
        ...(options?.traceFn ? { traceFn: options.traceFn } : {}),
        ...(options?.signal ? { signal: options.signal } : {}),
        ...(options?.httpHeaders ? { httpHeaders: options.httpHeaders } : {}),
    };
    const result0 = await fhirpath.evaluate(resource, "Claim.all(contained.contained.empty())", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result0.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL NOT contain nested Resources");
    }
    const result1 = await fhirpath.evaluate(resource, "Claim.all(contained.where((('#'+id in (%resource.descendants().reference | %resource.descendants().as(canonical) | %resource.descendants().as(uri) | %resource.descendants().as(url))) or descendants().where(reference = '#').exists() or descendants().where(as(canonical) = '#').exists() or descendants().where(as(canonical) = '#').exists()).not()).trace('unmatched', id).empty())", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result1.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL be referred to from elsewhere in the resource or SHALL refer to the containing resource");
    }
    const result2 = await fhirpath.evaluate(resource, "Claim.all(contained.meta.versionId.empty() and contained.meta.lastUpdated.empty())", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result2.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a meta.versionId or a meta.lastUpdated");
    }
    const result3 = await fhirpath.evaluate(resource, "Claim.all(contained.meta.security.empty())", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result3.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a security label");
    }
    const result4 = await fhirpath.evaluate(resource, "Claim.all(text.`div`.exists())", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result4.every(Boolean)) {
        warnings.push("Constraint violation: A resource should have narrative for robust management");
    }
    const result5 = await fhirpath.evaluate(resource, "meta.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result5.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result6 = await fhirpath.evaluate(resource, "implicitRules.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result6.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result7 = await fhirpath.evaluate(resource, "language.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result7.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result8 = await fhirpath.evaluate(resource, "text.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result8.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result9 = await fhirpath.evaluate(resource, "extension.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result9.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result10 = await fhirpath.evaluate(resource, "modifierExtension.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result10.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result11 = await fhirpath.evaluate(resource, "identifier.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result11.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result12 = await fhirpath.evaluate(resource, "status.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result12.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result13 = await fhirpath.evaluate(resource, "type.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result13.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result14 = await fhirpath.evaluate(resource, "subType.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result14.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result15 = await fhirpath.evaluate(resource, "use.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result15.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result16 = await fhirpath.evaluate(resource, "patient.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result16.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result17 = await fhirpath.evaluate(resource, "billablePeriod.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result17.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result18 = await fhirpath.evaluate(resource, "created.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result18.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result19 = await fhirpath.evaluate(resource, "enterer.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result19.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result20 = await fhirpath.evaluate(resource, "insurer.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result20.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result21 = await fhirpath.evaluate(resource, "provider.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result21.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result22 = await fhirpath.evaluate(resource, "priority.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result22.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result23 = await fhirpath.evaluate(resource, "fundsReserve.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result23.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result24 = await fhirpath.evaluate(resource, "related.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result24.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result25 = await fhirpath.evaluate(resource, "prescription.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result25.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result26 = await fhirpath.evaluate(resource, "originalPrescription.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result26.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result27 = await fhirpath.evaluate(resource, "payee.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result27.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result28 = await fhirpath.evaluate(resource, "referral.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result28.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result29 = await fhirpath.evaluate(resource, "facility.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result29.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result30 = await fhirpath.evaluate(resource, "careTeam.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result30.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result31 = await fhirpath.evaluate(resource, "supportingInfo.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result31.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result32 = await fhirpath.evaluate(resource, "diagnosis.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result32.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result33 = await fhirpath.evaluate(resource, "procedure.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result33.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result34 = await fhirpath.evaluate(resource, "insurance.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result34.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result35 = await fhirpath.evaluate(resource, "accident.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result35.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result36 = await fhirpath.evaluate(resource, "item.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result36.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result37 = await fhirpath.evaluate(resource, "total.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result37.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result38 = await fhirpath.evaluate(resource, "DomainResource.all(contained.contained.empty())", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result38.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL NOT contain nested Resources");
    }
    const result39 = await fhirpath.evaluate(resource, "DomainResource.all(contained.where((('#'+id in (%resource.descendants().reference | %resource.descendants().as(canonical) | %resource.descendants().as(uri) | %resource.descendants().as(url))) or descendants().where(reference = '#').exists() or descendants().where(as(canonical) = '#').exists() or descendants().where(as(canonical) = '#').exists()).not()).trace('unmatched', id).empty())", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result39.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL be referred to from elsewhere in the resource or SHALL refer to the containing resource");
    }
    const result40 = await fhirpath.evaluate(resource, "DomainResource.all(contained.meta.versionId.empty() and contained.meta.lastUpdated.empty())", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result40.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a meta.versionId or a meta.lastUpdated");
    }
    const result41 = await fhirpath.evaluate(resource, "DomainResource.all(contained.meta.security.empty())", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result41.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a security label");
    }
    const result42 = await fhirpath.evaluate(resource, "DomainResource.all(text.`div`.exists())", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result42.every(Boolean)) {
        warnings.push("Constraint violation: A resource should have narrative for robust management");
    }
    const result43 = await fhirpath.evaluate(resource, "identifier.count() >= 1", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result43.every(Boolean)) {
        errors.push("Constraint violation: identifier must contain at least one element");
    }
    const result44 = await fhirpath.evaluate(resource, "status.exists()", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result44.every(Boolean)) {
        errors.push("Constraint violation: status must be present");
    }
    const result45 = await fhirpath.evaluate(resource, "type.exists()", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result45.every(Boolean)) {
        errors.push("Constraint violation: type must be present");
    }
    const result46 = await fhirpath.evaluate(resource, "use.exists()", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result46.every(Boolean)) {
        errors.push("Constraint violation: use must be present");
    }
    const result47 = await fhirpath.evaluate(resource, "patient.exists()", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result47.every(Boolean)) {
        errors.push("Constraint violation: patient must be present");
    }
    const result48 = await fhirpath.evaluate(resource, "created.exists()", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result48.every(Boolean)) {
        errors.push("Constraint violation: created must be present");
    }
    const result49 = await fhirpath.evaluate(resource, "insurer.exists()", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result49.every(Boolean)) {
        errors.push("Constraint violation: insurer must be present");
    }
    const result50 = await fhirpath.evaluate(resource, "provider.exists()", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result50.every(Boolean)) {
        errors.push("Constraint violation: provider must be present");
    }
    const result51 = await fhirpath.evaluate(resource, "priority.exists()", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result51.every(Boolean)) {
        errors.push("Constraint violation: priority must be present");
    }
    const result52 = await fhirpath.evaluate(resource, "insurance.count() >= 1", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result52.every(Boolean)) {
        errors.push("Constraint violation: insurance must contain at least one element");
    }
    const result53 = await fhirpath.evaluate(resource, "item.count() >= 1", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result53.every(Boolean)) {
        errors.push("Constraint violation: item must contain at least one element");
    }
    const result54 = await fhirpath.evaluate(resource, "extension.count() <= 1", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result54.every(Boolean)) {
        errors.push("Constraint violation: extension must contain at most one element");
    }
    const result55 = await fhirpath.evaluate(resource, "identifier.count() <= 1", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result55.every(Boolean)) {
        errors.push("Constraint violation: identifier must contain at most one element");
    }
    const result56 = await fhirpath.evaluate(resource, "careTeam.extension.count() <= 1", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result56.every(Boolean)) {
        errors.push("Constraint violation: careTeam.extension must contain at most one element");
    }
    const result57 = await fhirpath.evaluate(resource, "supportingInfo.count() <= 1", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result57.every(Boolean)) {
        errors.push("Constraint violation: supportingInfo must contain at most one element");
    }
    const result58 = await fhirpath.evaluate(resource, "diagnosis.extension.count() <= 1", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result58.every(Boolean)) {
        errors.push("Constraint violation: diagnosis.extension must contain at most one element");
    }
    const result59 = await fhirpath.evaluate(resource, "diagnosis.type.count() <= 1", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result59.every(Boolean)) {
        errors.push("Constraint violation: diagnosis.type must contain at most one element");
    }
    const result60 = await fhirpath.evaluate(resource, "item.extension.count() <= 1", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result60.every(Boolean)) {
        errors.push("Constraint violation: item.extension must contain at most one element");
    }
    const result61 = await fhirpath.evaluate(resource, "supportingInfo.extension.count() <= 1", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result61.every(Boolean)) {
        errors.push("Constraint violation: supportingInfo.extension must contain at most one element");
    }
    const result62 = await fhirpath.evaluate(resource, "supportingInfo.modifierExtension.count() <= 1", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result62.every(Boolean)) {
        errors.push("Constraint violation: supportingInfo.modifierExtension must contain at most one element");
    }
    const result63 = await fhirpath.evaluate(resource, "item.modifierExtension.count() <= 1", { resource }, fhirpath_r4_model, fhirpathOptions);
    if (!result63.every(Boolean)) {
        errors.push("Constraint violation: item.modifierExtension must contain at most one element");
    }
    // Fixed value constraint for status
    if (resource.status !== undefined && resource.status !== "active") {
        errors.push("status must have the fixed value 'active'");
    }
    // Fixed value constraint for use
    if (resource.use !== undefined && resource.use !== "preauthorization") {
        errors.push("use must have the fixed value 'preauthorization'");
    }
    // Slice validation for careTeam.extension:careTeamClaimScope skipped: no pattern/value discriminator found
    // Discriminator types 'type', 'profile', 'exists', 'position' are not yet supported
    // Slice validation for careTeam.extension:careTeamClaimScope skipped: no pattern/value discriminator found
    // Discriminator types 'type', 'profile', 'exists', 'position' are not yet supported
    // Slice validation for careTeam.extension:careTeamClaimScope skipped: no pattern/value discriminator found
    // Discriminator types 'type', 'profile', 'exists', 'position' are not yet supported
    return { errors, warnings };
}
