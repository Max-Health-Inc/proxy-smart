import { UsCoreBirthsex } from "./UsCoreBirthsex";
import { UsCoreEthnicity } from "./UsCoreEthnicity";
import { UsCoreRace } from "./UsCoreRace";
import { Extension, HumanName, Patient } from "fhir/r4";
export interface PASBeneficiary extends Patient {
    /** Must Support */
    name: HumanName[];
    extension?: (Extension | UsCoreRace | UsCoreEthnicity | UsCoreBirthsex)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASBeneficiary(resource: PASBeneficiary, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
