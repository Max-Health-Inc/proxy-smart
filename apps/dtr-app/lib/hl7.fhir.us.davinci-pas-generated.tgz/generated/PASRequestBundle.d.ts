import { Bundle, BundleEntry, FhirResource, Identifier } from "fhir/r4";
export interface PASRequestBundleEntry extends BundleEntry {
    /** Must Support */
    resource: FhirResource;
}
export interface PASRequestBundle extends Bundle {
    /** Must Support */
    identifier: Identifier;
    type: "collection";
    /** Must Support */
    entry: PASRequestBundleEntry[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASRequestBundle(resource: PASRequestBundle, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
