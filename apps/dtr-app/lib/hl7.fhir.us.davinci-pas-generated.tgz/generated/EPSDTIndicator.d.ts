import { Extension } from "fhir/r4";
export interface EPSDTIndicator extends Extension {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-epsdtIndicator";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateEPSDTIndicator(resource: EPSDTIndicator, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
