import { CodeableConcept, Organization, OrganizationContact } from "fhir/r4";
export interface PASRequestor extends Organization {
    /** Must Support */
    type?: CodeableConcept[];
    /** Must Support */
    contact?: OrganizationContact[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASRequestor(resource: PASRequestor, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
