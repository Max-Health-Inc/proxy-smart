import { HumanName, Practitioner } from "fhir/r4";
export interface PASPractitioner extends Practitioner {
    /** Must Support */
    name: HumanName[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASPractitioner(resource: PASPractitioner, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
