import { Quantity } from "fhir/r4";
export type SimpleQuantity = Quantity;
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateSimpleQuantity(resource: SimpleQuantity, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
