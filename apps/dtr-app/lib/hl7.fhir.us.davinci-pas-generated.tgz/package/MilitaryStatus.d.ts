import { Extension } from "fhir/r4";
export interface MilitaryStatus extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-militaryStatus";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateMilitaryStatus(resource: MilitaryStatus, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
