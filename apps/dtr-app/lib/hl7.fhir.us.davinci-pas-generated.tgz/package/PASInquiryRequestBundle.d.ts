import { Bundle, BundleEntry, FhirResource, Identifier } from "fhir/r4";
export interface PASInquiryRequestBundleEntry extends Omit<BundleEntry, 'resource'> {
    /** Must Support */
    resource: FhirResource;
}
export interface PASInquiryRequestBundle extends Omit<Bundle, 'identifier' | 'type' | 'entry'> {
    resourceType: 'Bundle';
    /** Must Support */
    identifier: Identifier;
    type: "collection";
    /** Must Support */
    entry: PASInquiryRequestBundleEntry[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASInquiryRequestBundle(resource: PASInquiryRequestBundle, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
