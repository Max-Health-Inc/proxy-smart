import fhirpath from "fhirpath";
import fhirpath_model from "fhirpath/fhir-context/r4/index.js";
import { isValidFmStatusCode } from './valuesets/ValueSet-FmStatus.js';
import { isValidX12278DiagnosisTypeCode } from './valuesets/ValueSet-X12278DiagnosisType.js';
import { isValidX12278RequestedServiceTypeCode } from './valuesets/ValueSet-X12278RequestedServiceType.js';
import { validatePASIdentifier } from './PASIdentifier.js';
export async function validatePASClaim(resource, options) {
    const errors = [];
    const warnings = [];
    const fhirpathOptions = {
        preciseMath: true,
        traceFn: options?.traceFn ?? (() => { }),
        ...(options?.signal ? { signal: options.signal } : {}),
        ...(options?.httpHeaders ? { httpHeaders: options.httpHeaders } : {}),
        async: true,
        ...(options?.terminologyUrl ? { terminologyUrl: options.terminologyUrl } : {}),
        ...(options?.fhirServerUrl ? { fhirServerUrl: options.fhirServerUrl } : {}),
    };
    const result0 = await fhirpath.evaluate(resource, "Claim.all(contained.contained.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result0.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL NOT contain nested Resources");
    }
    const result1 = await fhirpath.evaluate(resource, "Claim.all(contained.where((('#'+id in (%resource.descendants().reference | %resource.descendants().as(canonical) | %resource.descendants().as(uri) | %resource.descendants().as(url))) or descendants().where(reference = '#').exists() or descendants().where(as(canonical) = '#').exists() or descendants().where(as(canonical) = '#').exists()).not()).trace('unmatched', id).empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result1.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL be referred to from elsewhere in the resource or SHALL refer to the containing resource");
    }
    const result2 = await fhirpath.evaluate(resource, "Claim.all(contained.meta.versionId.empty() and contained.meta.lastUpdated.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result2.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a meta.versionId or a meta.lastUpdated");
    }
    const result3 = await fhirpath.evaluate(resource, "Claim.all(contained.meta.security.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result3.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a security label");
    }
    const result4 = await fhirpath.evaluate(resource, "Claim.all(text.`div`.exists())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result4.every(Boolean)) {
        warnings.push("Constraint violation: A resource should have narrative for robust management");
    }
    const result5 = await fhirpath.evaluate(resource, "meta.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result5.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result6 = await fhirpath.evaluate(resource, "implicitRules.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result6.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result7 = await fhirpath.evaluate(resource, "language.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result7.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result8 = await fhirpath.evaluate(resource, "text.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result8.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result9 = await fhirpath.evaluate(resource, "extension.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result9.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result10 = await fhirpath.evaluate(resource, "modifierExtension.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result10.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result11 = await fhirpath.evaluate(resource, "identifier.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result11.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result12 = await fhirpath.evaluate(resource, "status.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result12.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result13 = await fhirpath.evaluate(resource, "type.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result13.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result14 = await fhirpath.evaluate(resource, "subType.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result14.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result15 = await fhirpath.evaluate(resource, "use.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result15.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result16 = await fhirpath.evaluate(resource, "patient.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result16.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result17 = await fhirpath.evaluate(resource, "billablePeriod.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result17.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result18 = await fhirpath.evaluate(resource, "created.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result18.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result19 = await fhirpath.evaluate(resource, "enterer.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result19.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result20 = await fhirpath.evaluate(resource, "insurer.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result20.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result21 = await fhirpath.evaluate(resource, "provider.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result21.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result22 = await fhirpath.evaluate(resource, "priority.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result22.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result23 = await fhirpath.evaluate(resource, "fundsReserve.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result23.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result24 = await fhirpath.evaluate(resource, "related.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result24.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result25 = await fhirpath.evaluate(resource, "prescription.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result25.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result26 = await fhirpath.evaluate(resource, "originalPrescription.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result26.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result27 = await fhirpath.evaluate(resource, "payee.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result27.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result28 = await fhirpath.evaluate(resource, "referral.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result28.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result29 = await fhirpath.evaluate(resource, "facility.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result29.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result30 = await fhirpath.evaluate(resource, "careTeam.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result30.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result31 = await fhirpath.evaluate(resource, "supportingInfo.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result31.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result32 = await fhirpath.evaluate(resource, "supportingInfo.timingDate.all($this.toString().length() = 10)", { resource }, fhirpath_model, fhirpathOptions);
    if (!result32.every(Boolean)) {
        errors.push("Constraint violation: Dates need to be a full date - YYYY-MM-DD");
    }
    const result33 = await fhirpath.evaluate(resource, "supportingInfo.timingDateTime.start.all($this.toString().length() = 10)", { resource }, fhirpath_model, fhirpathOptions);
    if (!result33.every(Boolean)) {
        errors.push("Constraint violation: Dates need to be a full date - YYYY-MM-DD");
    }
    const result34 = await fhirpath.evaluate(resource, "supportingInfo.timingDateTime.end.all($this.toString().length() = 10)", { resource }, fhirpath_model, fhirpathOptions);
    if (!result34.every(Boolean)) {
        errors.push("Constraint violation: Dates need to be a full date - YYYY-MM-DD");
    }
    const result35 = await fhirpath.evaluate(resource, "diagnosis.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result35.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result36 = await fhirpath.evaluate(resource, "procedure.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result36.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result37 = await fhirpath.evaluate(resource, "insurance.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result37.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result38 = await fhirpath.evaluate(resource, "accident.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result38.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result39 = await fhirpath.evaluate(resource, "item.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result39.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result40 = await fhirpath.evaluate(resource, "total.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result40.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result41 = await fhirpath.evaluate(resource, "DomainResource.all(contained.contained.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result41.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL NOT contain nested Resources");
    }
    const result42 = await fhirpath.evaluate(resource, "DomainResource.all(contained.where((('#'+id in (%resource.descendants().reference | %resource.descendants().as(canonical) | %resource.descendants().as(uri) | %resource.descendants().as(url))) or descendants().where(reference = '#').exists() or descendants().where(as(canonical) = '#').exists() or descendants().where(as(canonical) = '#').exists()).not()).trace('unmatched', id).empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result42.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL be referred to from elsewhere in the resource or SHALL refer to the containing resource");
    }
    const result43 = await fhirpath.evaluate(resource, "DomainResource.all(contained.meta.versionId.empty() and contained.meta.lastUpdated.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result43.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a meta.versionId or a meta.lastUpdated");
    }
    const result44 = await fhirpath.evaluate(resource, "DomainResource.all(contained.meta.security.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result44.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a security label");
    }
    const result45 = await fhirpath.evaluate(resource, "DomainResource.all(text.`div`.exists())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result45.every(Boolean)) {
        warnings.push("Constraint violation: A resource should have narrative for robust management");
    }
    const result46 = await fhirpath.evaluate(resource, "identifier.count() >= 1", { resource }, fhirpath_model, fhirpathOptions);
    if (!result46.every(Boolean)) {
        errors.push("Constraint violation: identifier must contain at least one element");
    }
    const result47 = await fhirpath.evaluate(resource, "status.exists()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result47.every(Boolean)) {
        errors.push("Constraint violation: status must be present");
    }
    const result48 = await fhirpath.evaluate(resource, "type.exists()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result48.every(Boolean)) {
        errors.push("Constraint violation: type must be present");
    }
    const result49 = await fhirpath.evaluate(resource, "use.exists()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result49.every(Boolean)) {
        errors.push("Constraint violation: use must be present");
    }
    const result50 = await fhirpath.evaluate(resource, "patient.exists()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result50.every(Boolean)) {
        errors.push("Constraint violation: patient must be present");
    }
    const result51 = await fhirpath.evaluate(resource, "created.exists()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result51.every(Boolean)) {
        errors.push("Constraint violation: created must be present");
    }
    const result52 = await fhirpath.evaluate(resource, "insurer.exists()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result52.every(Boolean)) {
        errors.push("Constraint violation: insurer must be present");
    }
    const result53 = await fhirpath.evaluate(resource, "provider.exists()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result53.every(Boolean)) {
        errors.push("Constraint violation: provider must be present");
    }
    const result54 = await fhirpath.evaluate(resource, "priority.exists()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result54.every(Boolean)) {
        errors.push("Constraint violation: priority must be present");
    }
    const result55 = await fhirpath.evaluate(resource, "insurance.count() >= 1", { resource }, fhirpath_model, fhirpathOptions);
    if (!result55.every(Boolean)) {
        errors.push("Constraint violation: insurance must contain at least one element");
    }
    const result56 = await fhirpath.evaluate(resource, "item.count() >= 1", { resource }, fhirpath_model, fhirpathOptions);
    if (!result56.every(Boolean)) {
        errors.push("Constraint violation: item must contain at least one element");
    }
    const result57 = await fhirpath.evaluate(resource, "identifier.count() <= 1", { resource }, fhirpath_model, fhirpathOptions);
    if (!result57.every(Boolean)) {
        errors.push("Constraint violation: identifier must contain at most one element");
    }
    if (options?.terminologyUrl) {
        const result58 = await fhirpath.evaluate(resource, "use.all(memberOf('http://hl7.org/fhir/ValueSet/claim-use'))", { resource }, fhirpath_model, fhirpathOptions);
        if (!result58.every(Boolean)) {
            errors.push("Constraint violation: The value provided must be in the value set 'claim-use' (http://hl7.org/fhir/ValueSet/claim-use)");
        }
    }
    else {
        warnings.push("Constraint not evaluated (no terminologyUrl): The value provided must be in the value set 'claim-use' (http://hl7.org/fhir/ValueSet/claim-use)");
    }
    // Nested required field: careTeam.extension (min=1)
    if (resource.careTeam && Array.isArray(resource.careTeam)) {
        for (const _el of resource.careTeam) {
            if (!_el.extension || _el.extension.length === 0) {
                errors.push("Missing required member: 'extension'");
            }
        }
    }
    // Nested required field: careTeam.sequence (min=1)
    if (resource.careTeam && Array.isArray(resource.careTeam)) {
        for (const _el of resource.careTeam) {
            if ((_el.sequence === undefined || _el.sequence === null) || Array.isArray(_el.sequence)) {
                errors.push("Missing required member: 'sequence'");
            }
        }
    }
    // Nested required field: careTeam.provider (min=1)
    if (resource.careTeam && Array.isArray(resource.careTeam)) {
        for (const _el of resource.careTeam) {
            if ((_el.provider === undefined || _el.provider === null) || Array.isArray(_el.provider)) {
                errors.push("Missing required member: 'provider'");
            }
        }
    }
    // Nested required field: supportingInfo.sequence (min=1)
    if (resource.supportingInfo && Array.isArray(resource.supportingInfo)) {
        for (const _el of resource.supportingInfo) {
            if ((_el.sequence === undefined || _el.sequence === null) || Array.isArray(_el.sequence)) {
                errors.push("Missing required member: 'sequence'");
            }
        }
    }
    // Nested required field: supportingInfo.category (min=1)
    if (resource.supportingInfo && Array.isArray(resource.supportingInfo)) {
        for (const _el of resource.supportingInfo) {
            if ((_el.category === undefined || _el.category === null) || Array.isArray(_el.category)) {
                errors.push("Missing required member: 'category'");
            }
        }
    }
    // Nested required field: diagnosis.sequence (min=1)
    if (resource.diagnosis && Array.isArray(resource.diagnosis)) {
        for (const _el of resource.diagnosis) {
            if ((_el.sequence === undefined || _el.sequence === null) || Array.isArray(_el.sequence)) {
                errors.push("Missing required member: 'sequence'");
            }
        }
    }
    // Nested required field: procedure.sequence (min=1)
    if (resource.procedure && Array.isArray(resource.procedure)) {
        for (const _el of resource.procedure) {
            if ((_el.sequence === undefined || _el.sequence === null) || Array.isArray(_el.sequence)) {
                errors.push("Missing required member: 'sequence'");
            }
        }
    }
    // Nested required field: insurance.sequence (min=1)
    if (resource.insurance && Array.isArray(resource.insurance)) {
        for (const _el of resource.insurance) {
            if ((_el.sequence === undefined || _el.sequence === null) || Array.isArray(_el.sequence)) {
                errors.push("Missing required member: 'sequence'");
            }
        }
    }
    // Nested required field: insurance.focal (min=1)
    if (resource.insurance && Array.isArray(resource.insurance)) {
        for (const _el of resource.insurance) {
            if ((_el.focal === undefined || _el.focal === null) || Array.isArray(_el.focal)) {
                errors.push("Missing required member: 'focal'");
            }
        }
    }
    // Nested required field: insurance.coverage (min=1)
    if (resource.insurance && Array.isArray(resource.insurance)) {
        for (const _el of resource.insurance) {
            if ((_el.coverage === undefined || _el.coverage === null) || Array.isArray(_el.coverage)) {
                errors.push("Missing required member: 'coverage'");
            }
        }
    }
    // Nested required field: item.sequence (min=1)
    if (resource.item && Array.isArray(resource.item)) {
        for (const _el of resource.item) {
            if ((_el.sequence === undefined || _el.sequence === null) || Array.isArray(_el.sequence)) {
                errors.push("Missing required member: 'sequence'");
            }
        }
    }
    // Nested required field: item.category (min=1)
    if (resource.item && Array.isArray(resource.item)) {
        for (const _el of resource.item) {
            if ((_el.category === undefined || _el.category === null) || Array.isArray(_el.category)) {
                errors.push("Missing required member: 'category'");
            }
        }
    }
    // Nested required field: item.productOrService (min=1)
    if (resource.item && Array.isArray(resource.item)) {
        for (const _el of resource.item) {
            if ((_el.productOrService === undefined || _el.productOrService === null) || Array.isArray(_el.productOrService)) {
                errors.push("Missing required member: 'productOrService'");
            }
        }
    }
    // Nested required field: item.detail.sequence (min=1)
    if (resource.item && Array.isArray(resource.item)) {
        for (const _nrEl0 of resource.item) {
            if (_nrEl0.detail && Array.isArray(_nrEl0.detail)) {
                for (const _nrEl1 of _nrEl0.detail) {
                    if ((_nrEl1.sequence === undefined || _nrEl1.sequence === null) || Array.isArray(_nrEl1.sequence)) {
                        errors.push("Missing required member: 'sequence'");
                    }
                }
            }
        }
    }
    // Nested required field: item.detail.productOrService (min=1)
    if (resource.item && Array.isArray(resource.item)) {
        for (const _nrEl0 of resource.item) {
            if (_nrEl0.detail && Array.isArray(_nrEl0.detail)) {
                for (const _nrEl1 of _nrEl0.detail) {
                    if ((_nrEl1.productOrService === undefined || _nrEl1.productOrService === null) || Array.isArray(_nrEl1.productOrService)) {
                        errors.push("Missing required member: 'productOrService'");
                    }
                }
            }
        }
    }
    // Nested required field: item.detail.subDetail.sequence (min=1)
    if (resource.item && Array.isArray(resource.item)) {
        for (const _nrEl0 of resource.item) {
            if (_nrEl0.detail && Array.isArray(_nrEl0.detail)) {
                for (const _nrEl1 of _nrEl0.detail) {
                    if (_nrEl1.subDetail && Array.isArray(_nrEl1.subDetail)) {
                        for (const _nrEl2 of _nrEl1.subDetail) {
                            if ((_nrEl2.sequence === undefined || _nrEl2.sequence === null) || Array.isArray(_nrEl2.sequence)) {
                                errors.push("Missing required member: 'sequence'");
                            }
                        }
                    }
                }
            }
        }
    }
    // Nested required field: item.detail.subDetail.productOrService (min=1)
    if (resource.item && Array.isArray(resource.item)) {
        for (const _nrEl0 of resource.item) {
            if (_nrEl0.detail && Array.isArray(_nrEl0.detail)) {
                for (const _nrEl1 of _nrEl0.detail) {
                    if (_nrEl1.subDetail && Array.isArray(_nrEl1.subDetail)) {
                        for (const _nrEl2 of _nrEl1.subDetail) {
                            if ((_nrEl2.productOrService === undefined || _nrEl2.productOrService === null) || Array.isArray(_nrEl2.productOrService)) {
                                errors.push("Missing required member: 'productOrService'");
                            }
                        }
                    }
                }
            }
        }
    }
    // Fixed value constraint for status
    if (resource.status !== undefined && resource.status !== "active") {
        errors.push("status must have the fixed value 'active'");
    }
    // Fixed value constraint for use
    if (resource.use !== undefined && resource.use !== "preauthorization") {
        errors.push("use must have the fixed value 'preauthorization'");
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const _bRes = resource;
    // Required ValueSet binding validation for status
    if (_bRes.status !== undefined && !isValidFmStatusCode(_bRes.status)) {
        errors.push("Code '" + _bRes.status + "' does not exist in the value set 'fm-status' (http://hl7.org/fhir/ValueSet/fm-status), but the binding is of strength 'required'");
    }
    // Required binding system-presence fallback for careTeam.role (nested, ValueSet unresolved)
    if (resource.careTeam && Array.isArray(resource.careTeam)) {
        for (const _nb0 of resource.careTeam) {
            if (_nb0.role !== undefined) {
                const _spCC = _nb0.role;
                const _spCoding = _spCC?.coding;
                if (_spCoding) {
                    for (const _c of _spCoding) {
                        if (_c.code !== undefined && (_c.system === undefined || _c.system === '')) {
                            errors.push("The System URI could not be determined for the code '" + _c.code + "' in the ValueSet '98' (https://valueset.x12.org/x217/005010/request/2010EA/NM1/1/01/00/98)");
                        }
                    }
                }
            }
        }
    }
    // Required binding system-presence fallback for careTeam.qualification (nested, ValueSet unresolved)
    if (resource.careTeam && Array.isArray(resource.careTeam)) {
        for (const _nb0 of resource.careTeam) {
            if (_nb0.qualification !== undefined) {
                const _spCC = _nb0.qualification;
                const _spCoding = _spCC?.coding;
                if (_spCoding) {
                    for (const _c of _spCoding) {
                        if (_c.code !== undefined && (_c.system === undefined || _c.system === '')) {
                            errors.push("The System URI could not be determined for the code '" + _c.code + "' in the ValueSet '127' (https://valueset.x12.org/x217/005010/request/2010EA/PRV/1/03/00/127)");
                        }
                    }
                }
            }
        }
    }
    // Required binding system-presence fallback for careTeam.role (nested, ValueSet unresolved)
    if (resource.careTeam && Array.isArray(resource.careTeam)) {
        for (const _nb0 of resource.careTeam) {
            if (_nb0.role !== undefined) {
                const _spCC = _nb0.role;
                const _spCoding = _spCC?.coding;
                if (_spCoding) {
                    for (const _c of _spCoding) {
                        if (_c.code !== undefined && (_c.system === undefined || _c.system === '')) {
                            errors.push("The System URI could not be determined for the code '" + _c.code + "' in the ValueSet '98' (https://valueset.x12.org/x217/005010/request/2010F/NM1/1/01/00/98)");
                        }
                    }
                }
            }
        }
    }
    // Required binding system-presence fallback for careTeam.qualification (nested, ValueSet unresolved)
    if (resource.careTeam && Array.isArray(resource.careTeam)) {
        for (const _nb0 of resource.careTeam) {
            if (_nb0.qualification !== undefined) {
                const _spCC = _nb0.qualification;
                const _spCoding = _spCC?.coding;
                if (_spCoding) {
                    for (const _c of _spCoding) {
                        if (_c.code !== undefined && (_c.system === undefined || _c.system === '')) {
                            errors.push("The System URI could not be determined for the code '" + _c.code + "' in the ValueSet '127' (https://valueset.x12.org/x217/005010/request/2010F/PRV/1/03/00/127)");
                        }
                    }
                }
            }
        }
    }
    // Required ValueSet system-level binding validation for diagnosis.diagnosisCodeableConcept (nested)
    if (resource.diagnosis && Array.isArray(resource.diagnosis)) {
        for (const _nb0 of resource.diagnosis) {
            {
                const _sccCoding = _nb0.diagnosisCodeableConcept?.coding;
                if (_sccCoding && _sccCoding.some((_c) => _c.code !== undefined)) {
                    const _allowedSystems = ["http://terminology.hl7.org/CodeSystem/icd9cm", "http://hl7.org/fhir/sid/icd-10-cm", "https://www.cms.gov/Medicare/Medicare-Fee-for-Service-Payment/AcuteInpatientPPS/MS-DRG-Classifications-and-Software", "http://uri.hddaccess.com/cs/apdrg", "http://uri.hddaccess.com/cs/aprdrg"];
                    if (!_sccCoding.some((_c) => _c.system !== undefined && _allowedSystems.includes(_c.system))) {
                        const _codes = _sccCoding.filter((_c) => _c.code !== undefined).map((_c) => (_c.system || "") + "#" + _c.code).join(", ");
                        errors.push("None of the codings provided are in the value set 'X12278DiagnosisCodes' (http://hl7.org/fhir/us/davinci-pas/ValueSet/X12278DiagnosisCodes), and a coding from this value set is required) (codes = " + _codes + ")");
                    }
                }
            }
        }
    }
    // Required ValueSet binding validation for diagnosis.type (nested)
    if (resource.diagnosis && Array.isArray(resource.diagnosis)) {
        for (const _nb0 of resource.diagnosis) {
            if (_nb0.type && Array.isArray(_nb0.type)) {
                for (const _item of _nb0.type) {
                    const _cc = _item;
                    if (_cc.coding && _cc.coding.some((_c) => _c.code !== undefined)) {
                        if (!_cc.coding.some((_c) => _c.code !== undefined && isValidX12278DiagnosisTypeCode(_c.code))) {
                            const _codes = _cc.coding.filter((_c) => _c.code !== undefined).map((_c) => (_c.system || "") + "#" + _c.code).join(", ");
                            errors.push("None of the codings provided are in the value set 'X12278DiagnosisType' (http://hl7.org/fhir/us/davinci-pas/ValueSet/X12278DiagnosisType), and a coding from this value set is required) (codes = " + _codes + ")");
                        }
                    }
                }
            }
        }
    }
    // Required ValueSet system-level binding validation for item.revenue (nested)
    if (resource.item && Array.isArray(resource.item)) {
        for (const _nb0 of resource.item) {
            {
                const _sccCoding = _nb0.revenue?.coding;
                if (_sccCoding && _sccCoding.some((_c) => _c.code !== undefined)) {
                    const _allowedSystems = ["https://www.nubc.org/revenue-code"];
                    if (!_sccCoding.some((_c) => _c.system !== undefined && _allowedSystems.includes(_c.system))) {
                        const _codes = _sccCoding.filter((_c) => _c.code !== undefined).map((_c) => (_c.system || "") + "#" + _c.code).join(", ");
                        errors.push("None of the codings provided are in the value set 'AHANUBCRevenueCodes' (http://hl7.org/fhir/us/davinci-pas/ValueSet/AHANUBCRevenueCodes), and a coding from this value set is required) (codes = " + _codes + ")");
                    }
                }
            }
        }
    }
    // Required binding system-presence fallback for item.category (nested, ValueSet unresolved)
    if (resource.item && Array.isArray(resource.item)) {
        for (const _nb0 of resource.item) {
            if (_nb0.category !== undefined) {
                const _spCC = _nb0.category;
                const _spCoding = _spCC?.coding;
                if (_spCoding) {
                    for (const _c of _spCoding) {
                        if (_c.code !== undefined && (_c.system === undefined || _c.system === '')) {
                            errors.push("The System URI could not be determined for the code '" + _c.code + "' in the ValueSet '1365' (https://valueset.x12.org/x217/005010/request/2000F/UM/1/03/00/1365)");
                        }
                    }
                }
            }
        }
    }
    // Required ValueSet binding validation for item.productOrService (nested)
    if (resource.item && Array.isArray(resource.item)) {
        for (const _nb0 of resource.item) {
            {
                const _ccCoding = _nb0.productOrService?.coding;
                if (_ccCoding && _ccCoding.some((_c) => _c.code !== undefined)) {
                    if (!_ccCoding.some((_c) => _c.code !== undefined && isValidX12278RequestedServiceTypeCode(_c.code))) {
                        const _codes = _ccCoding.filter((_c) => _c.code !== undefined).map((_c) => (_c.system || "") + "#" + _c.code).join(", ");
                        errors.push("None of the codings provided are in the value set 'X12278RequestedServiceType' (http://hl7.org/fhir/us/davinci-pas/ValueSet/X12278RequestedServiceType), and a coding from this value set is required) (codes = " + _codes + ")");
                    }
                }
            }
        }
    }
    // Required ValueSet system-level binding validation for item.modifier (nested)
    if (resource.item && Array.isArray(resource.item)) {
        for (const _nb0 of resource.item) {
            if (_nb0.modifier && Array.isArray(_nb0.modifier)) {
                for (const _sysItem of _nb0.modifier) {
                    const _scc = _sysItem;
                    if (_scc.coding && _scc.coding.some((_c) => _c.code !== undefined)) {
                        const _allowedSystems = ["http://www.ama-assn.org/go/cpt", "http://www.cms.gov/Medicare/Coding/HCPCSReleaseCodeSets"];
                        if (!_scc.coding.some((_c) => _c.system !== undefined && _allowedSystems.includes(_c.system))) {
                            const _codes = _scc.coding.filter((_c) => _c.code !== undefined).map((_c) => (_c.system || "") + "#" + _c.code).join(", ");
                            errors.push("None of the codings provided are in the value set 'X12278RequestedServiceModifierType' (http://hl7.org/fhir/us/davinci-pas/ValueSet/X12278RequestedServiceModifierType), and a coding from this value set is required) (codes = " + _codes + ")");
                        }
                    }
                }
            }
        }
    }
    // Required ValueSet system-level binding validation for item.locationCodeableConcept (nested)
    if (resource.item && Array.isArray(resource.item)) {
        for (const _nb0 of resource.item) {
            {
                const _sccCoding = _nb0.locationCodeableConcept?.coding;
                if (_sccCoding && _sccCoding.some((_c) => _c.code !== undefined)) {
                    const _allowedSystems = ["https://www.nubc.org/CodeSystem/TypeOfBill", "https://www.cms.gov/Medicare/Coding/place-of-service-codes/Place_of_Service_Code_Set"];
                    if (!_sccCoding.some((_c) => _c.system !== undefined && _allowedSystems.includes(_c.system))) {
                        const _codes = _sccCoding.filter((_c) => _c.code !== undefined).map((_c) => (_c.system || "") + "#" + _c.code).join(", ");
                        errors.push("None of the codings provided are in the value set 'X12278LocationType' (http://hl7.org/fhir/us/davinci-pas/ValueSet/X12278LocationType), and a coding from this value set is required) (codes = " + _codes + ")");
                    }
                }
            }
        }
    }
    // Required binding system-presence fallback for item.extension.valueCodeableConcept (nested, ValueSet unresolved)
    if (resource.item && Array.isArray(resource.item)) {
        for (const _nb0 of resource.item) {
            if (_nb0.extension && Array.isArray(_nb0.extension)) {
                for (const _nb1 of _nb0.extension) {
                    if (_nb1.valueCodeableConcept !== undefined) {
                        const _spCC = _nb1.valueCodeableConcept;
                        const _spCoding = _spCC?.coding;
                        if (_spCoding) {
                            for (const _c of _spCoding) {
                                if (_c.code !== undefined && (_c.system === undefined || _c.system === '')) {
                                    errors.push("The System URI could not be determined for the code '" + _c.code + "' in the ValueSet '1345' (https://valueset.x12.org/x217/005010/request/2000F/SV2/1/09/00/1345)");
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    // dateTime format validation for created
    if (typeof _bRes.created === 'string' && !/^\d{4}(-\d{2}(-\d{2}(T\d{2}:\d{2}(:\d{2}(\.\d+)?)?(Z|[+-]\d{2}:\d{2})?)?)?)?$/.test(_bRes.created)) {
        errors.push("Not a valid date/time format: '" + _bRes.created + "'");
    }
    // Required extension slice validation for careTeam.extension:careTeamClaimScope (url discriminator, nested in array)
    if (resource.careTeam && Array.isArray(resource.careTeam)) {
        for (const _el of resource.careTeam) {
            const _extArr = _el?.extension;
            if (Array.isArray(_extArr)) {
                const careTeamClaimScopeMatches = _extArr.filter((item) => item.url === "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-careTeamClaimScope");
                if (careTeamClaimScopeMatches.length < 1) {
                    errors.push("Slice 'careTeam.extension:careTeamClaimScope': a matching slice is required, but not found");
                }
                // Extension value type + binding validation
                for (const _ext of careTeamClaimScopeMatches) {
                    const _valEntry = Object.entries(_ext).find(([k]) => k.startsWith("value"));
                    if (_valEntry && !["valueBoolean"].includes(_valEntry[0])) {
                        const _found = _valEntry[0].replace("value", "").toLowerCase();
                        errors.push("The Profile 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-claim' definition allows for the type boolean but found type " + _found);
                    }
                }
            }
        }
    }
    // Required fixedValue slice validation for careTeam.extension:careTeamClaimScope (discriminated by url === "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-careTeamClaimScope", nested in array: careTeam)
    // Only check when parent array exists — parent absence is reported by separate required-field checks
    if (resource.careTeam && Array.isArray(resource.careTeam)) {
        const careTeamClaimScopeElements = [];
        for (const parentItem of resource.careTeam) {
            const _pi = parentItem;
            const nestedArray = _pi?.extension;
            if (Array.isArray(nestedArray)) {
                for (const item of nestedArray) {
                    if (item.url === "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-careTeamClaimScope")
                        careTeamClaimScopeElements.push(item);
                }
            }
            else if (nestedArray && nestedArray.url === "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-careTeamClaimScope") {
                careTeamClaimScopeElements.push(nestedArray);
            }
        }
        if (careTeamClaimScopeElements.length < 1) {
            errors.push("No elements matched required slice: 'careTeam:OverallClaimMember.extension:careTeamClaimScope'");
        }
        for (const _matched of careTeamClaimScopeElements) {
            const _m = _matched;
            if (_m.value !== undefined && _m.value !== true) {
                errors.push("Value is '" + _m.value + "' but is fixed to 'true' in the profile Claim#Claim.careTeam:OverallClaimMember.extension:careTeamClaimScope.value[x]");
            }
        }
    }
    // Required extension slice validation for careTeam.extension:careTeamClaimScope (url discriminator, nested in array)
    if (resource.careTeam && Array.isArray(resource.careTeam)) {
        for (const _el of resource.careTeam) {
            const _extArr = _el?.extension;
            if (Array.isArray(_extArr)) {
                const careTeamClaimScopeMatches = _extArr.filter((item) => item.url === "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-careTeamClaimScope");
                if (careTeamClaimScopeMatches.length < 1) {
                    errors.push("Slice 'careTeam:ItemClaimMember.extension:careTeamClaimScope': a matching slice is required, but not found");
                }
                // Extension value type + binding validation
                for (const _ext of careTeamClaimScopeMatches) {
                    const _valEntry = Object.entries(_ext).find(([k]) => k.startsWith("value"));
                    if (_valEntry && !["valueBoolean"].includes(_valEntry[0])) {
                        const _found = _valEntry[0].replace("value", "").toLowerCase();
                        errors.push("The Profile 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-claim' definition allows for the type boolean but found type " + _found);
                    }
                }
            }
        }
    }
    // Profiled datatype delegation: identifier → PASIdentifier
    if (resource.identifier && Array.isArray(resource.identifier)) {
        for (const _dtEl of resource.identifier) {
            const _sub = await validatePASIdentifier(_dtEl, options);
            errors.push(..._sub.errors);
            warnings.push(..._sub.warnings);
        }
    }
    // Base FHIR structural validation: extension.url required, ext-1 constraint, empty objects
    {
        const _checkExtensions = (obj, path, depth) => {
            if (!obj || typeof obj !== 'object')
                return;
            if (Array.isArray(obj)) {
                obj.forEach((item, i) => _checkExtensions(item, path + '[' + i + ']', depth + 1));
                return;
            }
            const rec = obj;
            // Empty object check — HL7 validates all FHIR elements must have content
            if (depth > 0 && Object.keys(rec).length === 0) {
                errors.push('Object must have some content');
            }
            // per-1: If present, start SHALL have a lower value than end (Period structural check)
            if (typeof rec.start === 'string' && typeof rec.end === 'string' && rec.start > rec.end) {
                errors.push('If present, start SHALL have a lower value than end');
            }
            // Validate extension arrays
            for (const extKey of ['extension', 'modifierExtension']) {
                const exts = rec[extKey];
                if (Array.isArray(exts)) {
                    for (const ext of exts) {
                        if (ext && typeof ext === 'object' && !Array.isArray(ext)) {
                            const e = ext;
                            if (typeof e.url !== 'string' || !e.url) {
                                errors.push('Extension.url is required in order to identify, use and validate the extension');
                            }
                            // ext-1: Must have either extensions or value[x], not both
                            const hasNestedExt = Array.isArray(e.extension) && e.extension.length > 0;
                            const hasValue = Object.keys(e).some(k => k.startsWith('value') && k !== 'value' && k.length > 5);
                            if (hasNestedExt && hasValue) {
                                errors.push('Must have either extensions or value[x], not both');
                            }
                        }
                    }
                }
            }
            // Recurse into child objects (skip primitive values)
            for (const [_key, _val] of Object.entries(rec)) {
                if (_val && typeof _val === 'object') {
                    _checkExtensions(_val, path + '.' + _key, depth + 1);
                }
            }
        };
        _checkExtensions(resource, '', 0);
    }
    // Standalone contained reference resolution: verify #id references resolve to contained[] entries
    {
        const _res = resource;
        const _containedIds = new Set();
        if (Array.isArray(_res.contained)) {
            for (const _c of _res.contained) {
                if (_c && typeof _c.id === 'string')
                    _containedIds.add(_c.id);
            }
        }
        const _checkContainedRef = (obj) => {
            if (!obj || typeof obj !== 'object')
                return;
            if (Array.isArray(obj)) {
                obj.forEach(_checkContainedRef);
                return;
            }
            const _rec = obj;
            if (typeof _rec.reference === 'string') {
                const _ref = _rec.reference;
                if (_ref.startsWith('#')) {
                    const _id = _ref.substring(1);
                    if (_id && !_containedIds.has(_id)) {
                        errors.push('Contained reference not found: ' + _ref);
                    }
                }
            }
            for (const [_k, _v] of Object.entries(_rec)) {
                if (_k !== 'contained')
                    _checkContainedRef(_v);
            }
        };
        _checkContainedRef(_res);
    }
    return { errors, warnings };
}
