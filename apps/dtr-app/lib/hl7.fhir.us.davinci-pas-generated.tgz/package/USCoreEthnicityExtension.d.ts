import { Extension } from "fhir/r4";
export interface USCoreEthnicityExtension extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/us/core/StructureDefinition/us-core-ethnicity";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateUSCoreEthnicityExtension(resource: USCoreEthnicityExtension, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
