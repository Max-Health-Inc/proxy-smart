import { validatePASLocation } from "./PASLocation.js";
// Only import helpers actually referenced below (dynamic based on required fields)
import { randomId, setRandomSeed, enrichResource, skeletonAddress } from "./random/index.js";
import { createRequire } from 'module';
const __require = createRequire(import.meta.url);
function ensureProfile(res, profile) {
    if (!res.meta) {
        res.meta = { profile: [profile] };
        return;
    }
    if (!res.meta.profile) {
        res.meta.profile = [profile];
        return;
    }
    if (!res.meta.profile.includes(profile)) {
        res.meta.profile = [...res.meta.profile, profile];
    }
}
// Internal helper (emitted per class file) to clone without resorting to 'any'.
function safeClone(value) {
    // Use native structuredClone if present; otherwise fallback to JSON round-trip.
    // We intentionally avoid casting through any to satisfy no-explicit-any lint rule.
    const g = globalThis;
    // Narrow globalThis to an object potentially containing structuredClone.
    if (typeof g.structuredClone === 'function') {
        return g.structuredClone(value);
    }
    return JSON.parse(JSON.stringify(value)); // best-effort deep clone
}
export class PASLocationClass {
    constructor(resource) {
        this.resource = resource;
        ensureProfile(this.resource, 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-location');
    }
    /** Validate current resource instance. */
    async validate(options) {
        return validatePASLocation(this.resource, options);
    }
    getResource() {
        return this.resource;
    }
    setResource(resource) {
        this.resource = resource;
        ensureProfile(this.resource, 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-location');
    }
    /**
     * Returns a plain JSON clone of the underlying resource ONLY if the last validation succeeded with zero errors.
     * Call validate() first; otherwise this method throws to prevent accidental use of invalid / unchecked data.
     */
    async toJSON() {
        return safeClone(this.resource);
    }
    /**
     * Create an empty instance for parity testing: for true FHIR resources, includes only resourceType; for datatypes, returns an empty object.
     * Note: meta.profile (when applicable) will be ensured by the constructor when wrapping this resource.
     */
    static empty(overrides = {}) {
        // For Resource profiles, include only resourceType. For Extension profiles, include url so the instance is minimally meaningful.
        const base = {
            resourceType: 'Location',
        };
        return { ...base, ...overrides };
    }
    /**
     * Create a minimal randomized instance of PASLocation.
     * Populates id, resourceType (if applicable) and primitive required (min>0) top-level fields with placeholders.
     */
    static random(overrides = {}, opts) {
        if (opts?.seed !== undefined) {
            // Direct call (no dynamic require) to ensure deterministic seeding works under ESM.
            setRandomSeed(opts.seed);
        }
        // Start with a Partial to avoid unsafe casting errors; we'll assert at the end.
        const base = { resourceType: 'Location', id: randomId(), name: randomId(), address: skeletonAddress(), };
        // Always include meta.profile with this profile's canonical URL if available & only for resource profiles
        ensureProfile(base, 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-location');
        // Enrich the base resource with common fields using centralized enrichment logic
        enrichResource(base, 'Location', 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-location', PASLocationClass._fieldPatterns, PASLocationClass._forbiddenFields, PASLocationClass.valueSetBindings, PASLocationClass._codeResolver, PASLocationClass._fieldOrder);
        // Cast through unknown to acknowledge dynamic enrichment
        return { ...base, ...overrides };
    }
    /** Convenience: returns a class instance wrapping a randomized resource. */
    static randomClass(overrides = {}, opts) {
        return new PASLocationClass(this.random(overrides, opts));
    }
}
/** Pattern constraints for profile fields (used by random() generator) */
PASLocationClass._fieldPatterns = {
    "address.use": "temp",
    "address.type": "postal",
    "address.state": "NE",
    "hoursOfOperation.daysOfWeek": "fri",
    "_refReq_position": {
        "longitude": true,
        "latitude": true
    },
    "_refReq_type": {
        "coding": true,
        "coding.system": true,
        "coding.code": true
    }
};
/** Fields that are forbidden (max=0) in this profile - must not be generated */
PASLocationClass._forbiddenFields = [];
/** FHIR element ordering for this profile's base resource (used by enrichResource for correct JSON field order) */
PASLocationClass._fieldOrder = ["id", "meta", "implicitRules", "language", "text", "contained", "extension", "modifierExtension", "identifier", "status", "operationalStatus", "name", "alias", "description", "mode", "type", "telecom", "address", "physicalType", "position", "managingOrganization", "partOf", "hoursOfOperation", "availabilityExceptions", "endpoint"];
/** ValueSet bindings for coded fields - maps field name to ValueSet URL */
PASLocationClass.valueSetBindings = {
    "language": "http://hl7.org/fhir/ValueSet/languages",
    "status": "http://hl7.org/fhir/ValueSet/location-status|4.0.1",
    "operationalStatus": "http://terminology.hl7.org/ValueSet/v2-0116",
    "mode": "http://hl7.org/fhir/ValueSet/location-mode|4.0.1",
    "type": "http://terminology.hl7.org/ValueSet/v3-ServiceDeliveryLocationRoleType",
    "address.use": "http://hl7.org/fhir/ValueSet/address-use|4.0.1",
    "address.type": "http://hl7.org/fhir/ValueSet/address-type|4.0.1",
    "address.state": "http://hl7.org/fhir/us/core/ValueSet/us-core-usps-state",
    "physicalType": "http://hl7.org/fhir/ValueSet/location-physical-type",
    "hoursOfOperation.daysOfWeek": "http://hl7.org/fhir/ValueSet/days-of-week|4.0.1"
};
/** Code resolver for ValueSet bindings - returns a random valid code from a ValueSet by URL */
PASLocationClass._codeResolver = (() => {
    // Try to load the ValueSetRegistry - it may not exist if no ValueSets were generated
    try {
        const registry = __require('./valuesets/index.js');
        if (registry && typeof registry.getRandomConceptByUrl === 'function') {
            return registry.getRandomConceptByUrl;
        }
    }
    catch { /* ValueSetRegistry not available */ }
    return undefined;
})();
