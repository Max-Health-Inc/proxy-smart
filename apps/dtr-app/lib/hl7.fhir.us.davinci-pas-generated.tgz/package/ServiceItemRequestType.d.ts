import { Extension } from "fhir/r4";
export interface ServiceItemRequestType extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-serviceItemRequestType";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateServiceItemRequestType(resource: ServiceItemRequestType, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
