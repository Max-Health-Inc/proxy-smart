import { Extension } from "fhir/r4";
export interface IdentifierSubDepartment extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-identifierSubDepartment";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateIdentifierSubDepartment(resource: IdentifierSubDepartment, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
