import { Extension } from "fhir/r4";
export interface ReviewActionCode extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-reviewActionCode";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateReviewActionCode(resource: ReviewActionCode, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
