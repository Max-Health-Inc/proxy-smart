/**
 * ValueSet: entformula-additive
 * URL: http://hl7.org/fhir/ValueSet/entformula-additive
 * Size: 5 concepts
 */
export const EntformulaAdditiveConcepts = [
    { code: "lipid", system: "http://terminology.hl7.org/CodeSystem/entformula-additive" },
    { code: "protein", system: "http://terminology.hl7.org/CodeSystem/entformula-additive" },
    { code: "carbohydrate", system: "http://terminology.hl7.org/CodeSystem/entformula-additive" },
    { code: "fiber", system: "http://terminology.hl7.org/CodeSystem/entformula-additive" },
    { code: "water", system: "http://terminology.hl7.org/CodeSystem/entformula-additive" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidEntformulaAdditiveCode(code) {
    return EntformulaAdditiveConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getEntformulaAdditiveConcept(code) {
    return EntformulaAdditiveConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const EntformulaAdditiveCodes = EntformulaAdditiveConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomEntformulaAdditiveCode() {
    return EntformulaAdditiveCodes[Math.floor(Math.random() * EntformulaAdditiveCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomEntformulaAdditiveConcept() {
    return EntformulaAdditiveConcepts[Math.floor(Math.random() * EntformulaAdditiveConcepts.length)];
}
