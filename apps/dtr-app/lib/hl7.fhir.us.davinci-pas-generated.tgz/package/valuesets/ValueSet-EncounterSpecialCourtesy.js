/**
 * ValueSet: encounter-special-courtesy
 * URL: http://hl7.org/fhir/ValueSet/encounter-special-courtesy
 * Size: 6 concepts
 */
export const EncounterSpecialCourtesyConcepts = [
    { code: "EXT", system: "http://terminology.hl7.org/CodeSystem/v3-EncounterSpecialCourtesy" },
    { code: "NRM", system: "http://terminology.hl7.org/CodeSystem/v3-EncounterSpecialCourtesy" },
    { code: "PRF", system: "http://terminology.hl7.org/CodeSystem/v3-EncounterSpecialCourtesy" },
    { code: "STF", system: "http://terminology.hl7.org/CodeSystem/v3-EncounterSpecialCourtesy" },
    { code: "VIP", system: "http://terminology.hl7.org/CodeSystem/v3-EncounterSpecialCourtesy" },
    { code: "UNK", system: "http://terminology.hl7.org/CodeSystem/v3-NullFlavor" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidEncounterSpecialCourtesyCode(code) {
    return EncounterSpecialCourtesyConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getEncounterSpecialCourtesyConcept(code) {
    return EncounterSpecialCourtesyConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const EncounterSpecialCourtesyCodes = EncounterSpecialCourtesyConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomEncounterSpecialCourtesyCode() {
    return EncounterSpecialCourtesyCodes[Math.floor(Math.random() * EncounterSpecialCourtesyCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomEncounterSpecialCourtesyConcept() {
    return EncounterSpecialCourtesyConcepts[Math.floor(Math.random() * EncounterSpecialCourtesyConcepts.length)];
}
