/**
 * ValueSet: entformula-additive
 * URL: http://hl7.org/fhir/ValueSet/entformula-additive
 * Size: 5 concepts
 */
export declare const EntformulaAdditiveConcepts: readonly [{
    readonly code: "lipid";
    readonly system: "http://terminology.hl7.org/CodeSystem/entformula-additive";
}, {
    readonly code: "protein";
    readonly system: "http://terminology.hl7.org/CodeSystem/entformula-additive";
}, {
    readonly code: "carbohydrate";
    readonly system: "http://terminology.hl7.org/CodeSystem/entformula-additive";
}, {
    readonly code: "fiber";
    readonly system: "http://terminology.hl7.org/CodeSystem/entformula-additive";
}, {
    readonly code: "water";
    readonly system: "http://terminology.hl7.org/CodeSystem/entformula-additive";
}];
/** Union type of all valid codes in this ValueSet */
export type EntformulaAdditiveCode = "lipid" | "protein" | "carbohydrate" | "fiber" | "water";
/** Type representing a concept from this ValueSet */
export type EntformulaAdditiveConcept = typeof EntformulaAdditiveConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidEntformulaAdditiveCode(code: string): code is EntformulaAdditiveCode;
/**
 * Get concept details by code
 */
export declare function getEntformulaAdditiveConcept(code: string): EntformulaAdditiveConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const EntformulaAdditiveCodes: ("lipid" | "protein" | "carbohydrate" | "fiber" | "water")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomEntformulaAdditiveCode(): EntformulaAdditiveCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomEntformulaAdditiveConcept(): EntformulaAdditiveConcept;
