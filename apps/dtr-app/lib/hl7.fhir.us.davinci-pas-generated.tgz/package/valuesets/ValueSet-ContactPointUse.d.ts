/**
 * ValueSet: contact-point-use
 * URL: http://hl7.org/fhir/ValueSet/contact-point-use
 * Size: 5 concepts
 */
export declare const ContactPointUseConcepts: readonly [{
    readonly code: "home";
    readonly system: "http://hl7.org/fhir/contact-point-use";
}, {
    readonly code: "work";
    readonly system: "http://hl7.org/fhir/contact-point-use";
}, {
    readonly code: "temp";
    readonly system: "http://hl7.org/fhir/contact-point-use";
}, {
    readonly code: "old";
    readonly system: "http://hl7.org/fhir/contact-point-use";
}, {
    readonly code: "mobile";
    readonly system: "http://hl7.org/fhir/contact-point-use";
}];
/** Union type of all valid codes in this ValueSet */
export type ContactPointUseCode = "home" | "work" | "temp" | "old" | "mobile";
/** Type representing a concept from this ValueSet */
export type ContactPointUseConcept = typeof ContactPointUseConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidContactPointUseCode(code: string): code is ContactPointUseCode;
/**
 * Get concept details by code
 */
export declare function getContactPointUseConcept(code: string): ContactPointUseConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ContactPointUseCodes: ("mobile" | "work" | "temp" | "old" | "home")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomContactPointUseCode(): ContactPointUseCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomContactPointUseConcept(): ContactPointUseConcept;
