/**
 * ValueSet: FoodTypeCodes
 * URL: http://hl7.org/fhir/ValueSet/food-type
 * Size: 100 concepts
 */
export declare const FoodTypeCodesConcepts: readonly [{
    readonly code: "255620007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Foods";
}, {
    readonly code: "3718001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Cow's milk";
}, {
    readonly code: "4289006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Keyhole-limpet hemocyanin";
}, {
    readonly code: "4882006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Ichthyoallyeinotoxin";
}, {
    readonly code: "5163009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Scombrotoxin";
}, {
    readonly code: "7661006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Fish bone";
}, {
    readonly code: "7791007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Soy protein";
}, {
    readonly code: "10827009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Milk protein";
}, {
    readonly code: "12448007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Whelk poison";
}, {
    readonly code: "13577000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Nut";
}, {
    readonly code: "14263006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Prepared fish";
}, {
    readonly code: "16641007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Bonellinin";
}, {
    readonly code: "19950006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Brevetoxin";
}, {
    readonly code: "20459005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Abalone viscera poison";
}, {
    readonly code: "22836000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Vegetable";
}, {
    readonly code: "23182003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Cereal";
}, {
    readonly code: "23317009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Saxitoxin";
}, {
    readonly code: "24515005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Spice";
}, {
    readonly code: "25743006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Skim milk";
}, {
    readonly code: "26426004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Ciguatoxin";
}, {
    readonly code: "28230009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Poultry";
}, {
    readonly code: "28647000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Meat";
}, {
    readonly code: "28942008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Coconut oil";
}, {
    readonly code: "29516008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Venerupin shellfish toxin";
}, {
    readonly code: "32500002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Shellfish toxin";
}, {
    readonly code: "32627005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Eburnetoxin";
}, {
    readonly code: "35124009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Clupeotoxin";
}, {
    readonly code: "37784002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Striatoxin";
}, {
    readonly code: "39102003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Food particle";
}, {
    readonly code: "40112002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Ichthyootoxin";
}, {
    readonly code: "41317008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Asterosaponin";
}, {
    readonly code: "41834005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Olive oil";
}, {
    readonly code: "42244003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Debromoaplysiatoxin";
}, {
    readonly code: "43708003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Animal feed additive";
}, {
    readonly code: "44027008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Seafood";
}, {
    readonly code: "44590006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Callistin toxin";
}, {
    readonly code: "46321002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Asterotoxin";
}, {
    readonly code: "46329000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Chocolate milk";
}, {
    readonly code: "50479000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Soy protein-iron complex";
}, {
    readonly code: "50593009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Casein";
}, {
    readonly code: "51905005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Mustard";
}, {
    readonly code: "51934004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Hemocyanin";
}, {
    readonly code: "52800001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Marine toxin";
}, {
    readonly code: "53875002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Colostrum";
}, {
    readonly code: "54041009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Safflower oil";
}, {
    readonly code: "56773009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Ichthyocrinotoxin";
}, {
    readonly code: "59119009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Ichthyosarcotoxin";
}, {
    readonly code: "59149006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Tetrodotoxin";
}, {
    readonly code: "61044003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Acipenserin";
}, {
    readonly code: "63045006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Berry";
}, {
    readonly code: "63766005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Flour";
}, {
    readonly code: "64869000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Conotoxin";
}, {
    readonly code: "66228001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Actinocongestin";
}, {
    readonly code: "67324005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Rice";
}, {
    readonly code: "67938008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Amnesic shellfish poison";
}, {
    readonly code: "70813002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Milk";
}, {
    readonly code: "71561006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Chelonitoxin";
}, {
    readonly code: "72340002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Plotolysin toxin";
}, {
    readonly code: "72359000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Gonyautoxin";
}, {
    readonly code: "72511004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Fruit";
}, {
    readonly code: "73892005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Carmine";
}, {
    readonly code: "74242007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Food starch";
}, {
    readonly code: "77722008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Poultry bone";
}, {
    readonly code: "80743002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Mustard black";
}, {
    readonly code: "80903004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Haplotoxin";
}, {
    readonly code: "82450006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Cottonseed oil";
}, {
    readonly code: "82566005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Animal feed";
}, {
    readonly code: "83595008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Goat's milk";
}, {
    readonly code: "83897009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Paralytic shellfish toxin";
}, {
    readonly code: "84802001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Equinatoxin";
}, {
    readonly code: "85668006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Starch powder";
}, {
    readonly code: "86600008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Fish toxin";
}, {
    readonly code: "89707004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Sesame oil";
}, {
    readonly code: "89811004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Gluten";
}, {
    readonly code: "89866003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Plotospasmin toxin";
}, {
    readonly code: "90677004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Mustard white";
}, {
    readonly code: "90696000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Neosaxitonin";
}, {
    readonly code: "91353009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Cephalotoxin";
}, {
    readonly code: "91677007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Aplysiatoxin";
}, {
    readonly code: "102259006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Citrus fruit";
}, {
    readonly code: "102260001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Peanut butter";
}, {
    readonly code: "102261002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Strawberry";
}, {
    readonly code: "102262009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Chocolate";
}, {
    readonly code: "102263004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Eggs (edible)";
}, {
    readonly code: "102264005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Cheese";
}, {
    readonly code: "102270004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Growth stimulant";
}, {
    readonly code: "102271000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Efrotomycin";
}, {
    readonly code: "102697003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Lactalbumin";
}, {
    readonly code: "102698008";
    readonly system: "http://snomed.info/sct";
    readonly display: "alpha-Lactalbumin";
}, {
    readonly code: "102699000";
    readonly system: "http://snomed.info/sct";
    readonly display: "beta-Lactalbumin";
}, {
    readonly code: "126076005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Fish liver oil";
}, {
    readonly code: "126077001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Burbot liver oil";
}, {
    readonly code: "126078006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Percomorph liver oil";
}, {
    readonly code: "126079003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Percoid liver oil";
}, {
    readonly code: "126080000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Shark liver oil";
}, {
    readonly code: "126081001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Halibut liver oil";
}, {
    readonly code: "126082008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Cod liver oil";
}, {
    readonly code: "127384006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Salmon calcitonin";
}, {
    readonly code: "226017009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Bombay mix";
}, {
    readonly code: "226021002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Cauliflower cheese";
}];
/** String type (ValueSet too large for union type) */
export type FoodTypeCodesCode = string;
/** Type representing a concept from this ValueSet */
export type FoodTypeCodesConcept = typeof FoodTypeCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidFoodTypeCodesCode(code: string): code is FoodTypeCodesCode;
/**
 * Get concept details by code
 */
export declare function getFoodTypeCodesConcept(code: string): FoodTypeCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const FoodTypeCodesCodes: ("255620007" | "3718001" | "4289006" | "4882006" | "5163009" | "7661006" | "7791007" | "10827009" | "12448007" | "13577000" | "14263006" | "16641007" | "19950006" | "20459005" | "22836000" | "23182003" | "23317009" | "24515005" | "25743006" | "26426004" | "28230009" | "28647000" | "28942008" | "29516008" | "32500002" | "32627005" | "35124009" | "37784002" | "39102003" | "40112002" | "41317008" | "41834005" | "42244003" | "43708003" | "44027008" | "44590006" | "46321002" | "46329000" | "50479000" | "50593009" | "51905005" | "51934004" | "52800001" | "53875002" | "54041009" | "56773009" | "59119009" | "59149006" | "61044003" | "63045006" | "63766005" | "64869000" | "66228001" | "67324005" | "67938008" | "70813002" | "71561006" | "72340002" | "72359000" | "72511004" | "73892005" | "74242007" | "77722008" | "80743002" | "80903004" | "82450006" | "82566005" | "83595008" | "83897009" | "84802001" | "85668006" | "86600008" | "89707004" | "89811004" | "89866003" | "90677004" | "90696000" | "91353009" | "91677007" | "102259006" | "102260001" | "102261002" | "102262009" | "102263004" | "102264005" | "102270004" | "102271000" | "102697003" | "102698008" | "102699000" | "126076005" | "126077001" | "126078006" | "126079003" | "126080000" | "126081001" | "126082008" | "127384006" | "226017009" | "226021002")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomFoodTypeCodesCode(): FoodTypeCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomFoodTypeCodesConcept(): FoodTypeCodesConcept;
