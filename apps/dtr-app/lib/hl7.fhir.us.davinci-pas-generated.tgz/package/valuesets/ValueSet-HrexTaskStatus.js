/**
 * ValueSet: hrex-task-status
 * URL: http://hl7.org/fhir/us/davinci-hrex/ValueSet/hrex-task-status
 * Size: 7 concepts
 */
export const HrexTaskStatusConcepts = [
    { code: "requested", system: "http://hl7.org/fhir/task-status" },
    { code: "accepted", system: "http://hl7.org/fhir/task-status" },
    { code: "rejected", system: "http://hl7.org/fhir/task-status" },
    { code: "in-progress", system: "http://hl7.org/fhir/task-status" },
    { code: "failed", system: "http://hl7.org/fhir/task-status" },
    { code: "completed", system: "http://hl7.org/fhir/task-status" },
    { code: "on-hold", system: "http://hl7.org/fhir/task-status" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidHrexTaskStatusCode(code) {
    return HrexTaskStatusConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getHrexTaskStatusConcept(code) {
    return HrexTaskStatusConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const HrexTaskStatusCodes = HrexTaskStatusConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomHrexTaskStatusCode() {
    return HrexTaskStatusCodes[Math.floor(Math.random() * HrexTaskStatusCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomHrexTaskStatusConcept() {
    return HrexTaskStatusConcepts[Math.floor(Math.random() * HrexTaskStatusConcepts.length)];
}
