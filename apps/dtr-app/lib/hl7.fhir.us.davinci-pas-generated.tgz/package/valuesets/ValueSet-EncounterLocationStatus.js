/**
 * ValueSet: EncounterLocationStatus
 * URL: http://hl7.org/fhir/ValueSet/encounter-location-status
 * Size: 4 concepts
 */
export const EncounterLocationStatusConcepts = [
    { code: "planned", system: "http://hl7.org/fhir/encounter-location-status", display: "Planned" },
    { code: "active", system: "http://hl7.org/fhir/encounter-location-status", display: "Active" },
    { code: "reserved", system: "http://hl7.org/fhir/encounter-location-status", display: "Reserved" },
    { code: "completed", system: "http://hl7.org/fhir/encounter-location-status", display: "Completed" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidEncounterLocationStatusCode(code) {
    return EncounterLocationStatusConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getEncounterLocationStatusConcept(code) {
    return EncounterLocationStatusConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const EncounterLocationStatusCodes = EncounterLocationStatusConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomEncounterLocationStatusCode() {
    return EncounterLocationStatusCodes[Math.floor(Math.random() * EncounterLocationStatusCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomEncounterLocationStatusConcept() {
    return EncounterLocationStatusConcepts[Math.floor(Math.random() * EncounterLocationStatusConcepts.length)];
}
