/**
 * ValueSet: fundsreserve
 * URL: http://hl7.org/fhir/ValueSet/fundsreserve
 * Size: 3 concepts
 */
export const FundsreserveConcepts = [
    { code: "patient", system: "http://terminology.hl7.org/CodeSystem/fundsreserve" },
    { code: "provider", system: "http://terminology.hl7.org/CodeSystem/fundsreserve" },
    { code: "none", system: "http://terminology.hl7.org/CodeSystem/fundsreserve" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidFundsreserveCode(code) {
    return FundsreserveConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getFundsreserveConcept(code) {
    return FundsreserveConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const FundsreserveCodes = FundsreserveConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomFundsreserveCode() {
    return FundsreserveCodes[Math.floor(Math.random() * FundsreserveCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomFundsreserveConcept() {
    return FundsreserveConcepts[Math.floor(Math.random() * FundsreserveConcepts.length)];
}
