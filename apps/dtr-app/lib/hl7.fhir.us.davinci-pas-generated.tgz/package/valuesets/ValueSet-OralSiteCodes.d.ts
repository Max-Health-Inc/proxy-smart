/**
 * ValueSet: OralSiteCodes
 * URL: http://hl7.org/fhir/ValueSet/tooth
 * Size: 41 concepts
 */
export declare const OralSiteCodesConcepts: readonly [{
    readonly code: "0";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "Oral cavity";
}, {
    readonly code: "1";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "1";
}, {
    readonly code: "2";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "2";
}, {
    readonly code: "3";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "3";
}, {
    readonly code: "4";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "4";
}, {
    readonly code: "5";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "5";
}, {
    readonly code: "6";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "6";
}, {
    readonly code: "7";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "7";
}, {
    readonly code: "8";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "8";
}, {
    readonly code: "11";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "11";
}, {
    readonly code: "12";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "12";
}, {
    readonly code: "13";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "13";
}, {
    readonly code: "14";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "14";
}, {
    readonly code: "15";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "15";
}, {
    readonly code: "16";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "16";
}, {
    readonly code: "17";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "17";
}, {
    readonly code: "18";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "18";
}, {
    readonly code: "21";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "21";
}, {
    readonly code: "22";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "22";
}, {
    readonly code: "23";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "23";
}, {
    readonly code: "24";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "24";
}, {
    readonly code: "25";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "25";
}, {
    readonly code: "26";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "26";
}, {
    readonly code: "27";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "27";
}, {
    readonly code: "28";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "28";
}, {
    readonly code: "31";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "31";
}, {
    readonly code: "32";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "32";
}, {
    readonly code: "33";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "33";
}, {
    readonly code: "34";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "34";
}, {
    readonly code: "35";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "35";
}, {
    readonly code: "36";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "36";
}, {
    readonly code: "37";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "37";
}, {
    readonly code: "38";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "38";
}, {
    readonly code: "41";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "41";
}, {
    readonly code: "42";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "42";
}, {
    readonly code: "43";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "43";
}, {
    readonly code: "44";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "44";
}, {
    readonly code: "45";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "45";
}, {
    readonly code: "46";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "46";
}, {
    readonly code: "47";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "47";
}, {
    readonly code: "48";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-tooth";
    readonly display: "48";
}];
/** String type (ValueSet too large for union type) */
export type OralSiteCodesCode = string;
/** Type representing a concept from this ValueSet */
export type OralSiteCodesConcept = typeof OralSiteCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidOralSiteCodesCode(code: string): code is OralSiteCodesCode;
/**
 * Get concept details by code
 */
export declare function getOralSiteCodesConcept(code: string): OralSiteCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const OralSiteCodesCodes: ("8" | "1" | "0" | "3" | "2" | "4" | "5" | "6" | "7" | "11" | "12" | "13" | "14" | "15" | "16" | "17" | "18" | "21" | "22" | "23" | "47" | "26" | "24" | "25" | "27" | "28" | "31" | "32" | "33" | "34" | "35" | "36" | "37" | "38" | "41" | "42" | "43" | "44" | "45" | "46" | "48")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomOralSiteCodesCode(): OralSiteCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomOralSiteCodesConcept(): OralSiteCodesConcept;
