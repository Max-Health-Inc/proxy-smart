/**
 * ValueSet: issue-type
 * URL: http://hl7.org/fhir/ValueSet/issue-type
 * Size: 31 concepts
 */
export declare const IssueTypeConcepts: readonly [{
    readonly code: "invalid";
    readonly system: "http://hl7.org/fhir/issue-type";
}, {
    readonly code: "structure";
    readonly system: "http://hl7.org/fhir/issue-type";
}, {
    readonly code: "required";
    readonly system: "http://hl7.org/fhir/issue-type";
}, {
    readonly code: "value";
    readonly system: "http://hl7.org/fhir/issue-type";
}, {
    readonly code: "invariant";
    readonly system: "http://hl7.org/fhir/issue-type";
}, {
    readonly code: "security";
    readonly system: "http://hl7.org/fhir/issue-type";
}, {
    readonly code: "login";
    readonly system: "http://hl7.org/fhir/issue-type";
}, {
    readonly code: "unknown";
    readonly system: "http://hl7.org/fhir/issue-type";
}, {
    readonly code: "expired";
    readonly system: "http://hl7.org/fhir/issue-type";
}, {
    readonly code: "forbidden";
    readonly system: "http://hl7.org/fhir/issue-type";
}, {
    readonly code: "suppressed";
    readonly system: "http://hl7.org/fhir/issue-type";
}, {
    readonly code: "processing";
    readonly system: "http://hl7.org/fhir/issue-type";
}, {
    readonly code: "not-supported";
    readonly system: "http://hl7.org/fhir/issue-type";
}, {
    readonly code: "duplicate";
    readonly system: "http://hl7.org/fhir/issue-type";
}, {
    readonly code: "multiple-matches";
    readonly system: "http://hl7.org/fhir/issue-type";
}, {
    readonly code: "not-found";
    readonly system: "http://hl7.org/fhir/issue-type";
}, {
    readonly code: "deleted";
    readonly system: "http://hl7.org/fhir/issue-type";
}, {
    readonly code: "too-long";
    readonly system: "http://hl7.org/fhir/issue-type";
}, {
    readonly code: "code-invalid";
    readonly system: "http://hl7.org/fhir/issue-type";
}, {
    readonly code: "extension";
    readonly system: "http://hl7.org/fhir/issue-type";
}, {
    readonly code: "too-costly";
    readonly system: "http://hl7.org/fhir/issue-type";
}, {
    readonly code: "business-rule";
    readonly system: "http://hl7.org/fhir/issue-type";
}, {
    readonly code: "conflict";
    readonly system: "http://hl7.org/fhir/issue-type";
}, {
    readonly code: "transient";
    readonly system: "http://hl7.org/fhir/issue-type";
}, {
    readonly code: "lock-error";
    readonly system: "http://hl7.org/fhir/issue-type";
}, {
    readonly code: "no-store";
    readonly system: "http://hl7.org/fhir/issue-type";
}, {
    readonly code: "exception";
    readonly system: "http://hl7.org/fhir/issue-type";
}, {
    readonly code: "timeout";
    readonly system: "http://hl7.org/fhir/issue-type";
}, {
    readonly code: "incomplete";
    readonly system: "http://hl7.org/fhir/issue-type";
}, {
    readonly code: "throttled";
    readonly system: "http://hl7.org/fhir/issue-type";
}, {
    readonly code: "informational";
    readonly system: "http://hl7.org/fhir/issue-type";
}];
/** String type (ValueSet too large for union type) */
export type IssueTypeCode = string;
/** Type representing a concept from this ValueSet */
export type IssueTypeConcept = typeof IssueTypeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidIssueTypeCode(code: string): code is IssueTypeCode;
/**
 * Get concept details by code
 */
export declare function getIssueTypeConcept(code: string): IssueTypeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const IssueTypeCodes: ("extension" | "value" | "unknown" | "invalid" | "structure" | "required" | "invariant" | "security" | "login" | "expired" | "forbidden" | "suppressed" | "processing" | "not-supported" | "duplicate" | "multiple-matches" | "not-found" | "deleted" | "too-long" | "code-invalid" | "too-costly" | "business-rule" | "conflict" | "transient" | "lock-error" | "no-store" | "exception" | "timeout" | "incomplete" | "throttled" | "informational")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomIssueTypeCode(): IssueTypeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomIssueTypeConcept(): IssueTypeConcept;
