/**
 * ValueSet: IssueType
 * URL: http://hl7.org/fhir/ValueSet/issue-type
 * Size: 5 concepts
 */
export declare const IssueTypeConcepts: readonly [{
    readonly code: "invalid";
    readonly system: "http://hl7.org/fhir/issue-type";
    readonly display: "Invalid Content";
}, {
    readonly code: "security";
    readonly system: "http://hl7.org/fhir/issue-type";
    readonly display: "Security Problem";
}, {
    readonly code: "processing";
    readonly system: "http://hl7.org/fhir/issue-type";
    readonly display: "Processing Failure";
}, {
    readonly code: "transient";
    readonly system: "http://hl7.org/fhir/issue-type";
    readonly display: "Transient Issue";
}, {
    readonly code: "informational";
    readonly system: "http://hl7.org/fhir/issue-type";
    readonly display: "Informational Note";
}];
/** Union type of all valid codes in this ValueSet */
export type IssueTypeCode = "invalid" | "security" | "processing" | "transient" | "informational";
/** Type representing a concept from this ValueSet */
export type IssueTypeConcept = typeof IssueTypeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidIssueTypeCode(code: string): code is IssueTypeCode;
/**
 * Get concept details by code
 */
export declare function getIssueTypeConcept(code: string): IssueTypeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const IssueTypeCodes: ("invalid" | "security" | "processing" | "transient" | "informational")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomIssueTypeCode(): IssueTypeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomIssueTypeConcept(): IssueTypeConcept;
