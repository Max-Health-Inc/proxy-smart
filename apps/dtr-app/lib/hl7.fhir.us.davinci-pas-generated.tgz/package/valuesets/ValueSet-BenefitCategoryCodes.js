/**
 * ValueSet: BenefitCategoryCodes
 * URL: http://hl7.org/fhir/ValueSet/ex-benefitcategory
 * Size: 28 concepts
 */
export const BenefitCategoryCodesConcepts = [
    { code: "1", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory", display: "Medical Care" },
    { code: "2", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory", display: "Surgical" },
    { code: "3", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory", display: "Consultation" },
    { code: "4", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory", display: "Diagnostic XRay" },
    { code: "5", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory", display: "Diagnostic Lab" },
    { code: "14", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory", display: "Renal Supplies" },
    { code: "23", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory", display: "Diagnostic Dental" },
    { code: "24", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory", display: "Periodontics" },
    { code: "25", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory", display: "Restorative" },
    { code: "26", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory", display: "Endodontics" },
    { code: "27", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory", display: "Maxillofacial Prosthetics" },
    { code: "28", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory", display: "Adjunctive Dental Services" },
    { code: "30", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory", display: "Health Benefit Plan Coverage" },
    { code: "35", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory", display: "Dental Care" },
    { code: "36", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory", display: "Dental Crowns" },
    { code: "37", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory", display: "Dental Accident" },
    { code: "49", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory", display: "Hospital Room and Board" },
    { code: "55", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory", display: "Major Medical" },
    { code: "56", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory", display: "Medically Related Transportation" },
    { code: "61", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory", display: "In-vitro Fertilization" },
    { code: "62", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory", display: "MRI Scan" },
    { code: "63", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory", display: "Donor Procedures" },
    { code: "69", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory", display: "Maternity" },
    { code: "76", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory", display: "Renal Dialysis" },
    { code: "F1", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory", display: "Medical Coverage" },
    { code: "F3", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory", display: "Dental Coverage" },
    { code: "F4", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory", display: "Hearing Coverage" },
    { code: "F6", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory", display: "Vision Coverage" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidBenefitCategoryCodesCode(code) {
    return BenefitCategoryCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getBenefitCategoryCodesConcept(code) {
    return BenefitCategoryCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const BenefitCategoryCodesCodes = BenefitCategoryCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomBenefitCategoryCodesCode() {
    return BenefitCategoryCodesCodes[Math.floor(Math.random() * BenefitCategoryCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomBenefitCategoryCodesConcept() {
    return BenefitCategoryCodesConcepts[Math.floor(Math.random() * BenefitCategoryCodesConcepts.length)];
}
