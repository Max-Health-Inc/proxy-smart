/**
 * ValueSet: claim-exception
 * URL: http://hl7.org/fhir/ValueSet/claim-exception
 * Size: 2 concepts
 */
export declare const ClaimExceptionConcepts: readonly [{
    readonly code: "student";
    readonly system: "http://terminology.hl7.org/CodeSystem/claim-exception";
}, {
    readonly code: "disabled";
    readonly system: "http://terminology.hl7.org/CodeSystem/claim-exception";
}];
/** Union type of all valid codes in this ValueSet */
export type ClaimExceptionCode = "student" | "disabled";
/** Type representing a concept from this ValueSet */
export type ClaimExceptionConcept = typeof ClaimExceptionConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidClaimExceptionCode(code: string): code is ClaimExceptionCode;
/**
 * Get concept details by code
 */
export declare function getClaimExceptionConcept(code: string): ClaimExceptionConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ClaimExceptionCodes: ("student" | "disabled")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomClaimExceptionCode(): ClaimExceptionCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomClaimExceptionConcept(): ClaimExceptionConcept;
