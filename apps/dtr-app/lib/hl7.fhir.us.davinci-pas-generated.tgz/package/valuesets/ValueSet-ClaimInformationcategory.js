/**
 * ValueSet: claim-informationcategory
 * URL: http://hl7.org/fhir/ValueSet/claim-informationcategory
 * Size: 14 concepts
 */
export const ClaimInformationcategoryConcepts = [
    { code: "info", system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory" },
    { code: "discharge", system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory" },
    { code: "onset", system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory" },
    { code: "related", system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory" },
    { code: "exception", system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory" },
    { code: "material", system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory" },
    { code: "attachment", system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory" },
    { code: "missingtooth", system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory" },
    { code: "prosthesis", system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory" },
    { code: "other", system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory" },
    { code: "hospitalized", system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory" },
    { code: "employmentimpacted", system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory" },
    { code: "externalcause", system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory" },
    { code: "patientreasonforvisit", system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidClaimInformationcategoryCode(code) {
    return ClaimInformationcategoryConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getClaimInformationcategoryConcept(code) {
    return ClaimInformationcategoryConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ClaimInformationcategoryCodes = ClaimInformationcategoryConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomClaimInformationcategoryCode() {
    return ClaimInformationcategoryCodes[Math.floor(Math.random() * ClaimInformationcategoryCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomClaimInformationcategoryConcept() {
    return ClaimInformationcategoryConcepts[Math.floor(Math.random() * ClaimInformationcategoryConcepts.length)];
}
