/**
 * ValueSet: address-use
 * URL: http://hl7.org/fhir/ValueSet/address-use
 * Size: 5 concepts
 */
export declare const AddressUseConcepts: readonly [{
    readonly code: "home";
    readonly system: "http://hl7.org/fhir/address-use";
}, {
    readonly code: "work";
    readonly system: "http://hl7.org/fhir/address-use";
}, {
    readonly code: "temp";
    readonly system: "http://hl7.org/fhir/address-use";
}, {
    readonly code: "old";
    readonly system: "http://hl7.org/fhir/address-use";
}, {
    readonly code: "billing";
    readonly system: "http://hl7.org/fhir/address-use";
}];
/** Union type of all valid codes in this ValueSet */
export type AddressUseCode = "home" | "work" | "temp" | "old" | "billing";
/** Type representing a concept from this ValueSet */
export type AddressUseConcept = typeof AddressUseConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidAddressUseCode(code: string): code is AddressUseCode;
/**
 * Get concept details by code
 */
export declare function getAddressUseConcept(code: string): AddressUseConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const AddressUseCodes: ("work" | "temp" | "old" | "home" | "billing")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomAddressUseCode(): AddressUseCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomAddressUseConcept(): AddressUseConcept;
