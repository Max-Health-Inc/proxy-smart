/**
 * ValueSet: payment-adjustment-reason
 * URL: http://hl7.org/fhir/ValueSet/payment-adjustment-reason
 * Size: 2 concepts
 */
export declare const PaymentAdjustmentReasonConcepts: readonly [{
    readonly code: "a001";
    readonly system: "http://terminology.hl7.org/CodeSystem/payment-adjustment-reason";
}, {
    readonly code: "a002";
    readonly system: "http://terminology.hl7.org/CodeSystem/payment-adjustment-reason";
}];
/** Union type of all valid codes in this ValueSet */
export type PaymentAdjustmentReasonCode = "a001" | "a002";
/** Type representing a concept from this ValueSet */
export type PaymentAdjustmentReasonConcept = typeof PaymentAdjustmentReasonConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidPaymentAdjustmentReasonCode(code: string): code is PaymentAdjustmentReasonCode;
/**
 * Get concept details by code
 */
export declare function getPaymentAdjustmentReasonConcept(code: string): PaymentAdjustmentReasonConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const PaymentAdjustmentReasonCodes: ("a002" | "a001")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomPaymentAdjustmentReasonCode(): PaymentAdjustmentReasonCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomPaymentAdjustmentReasonConcept(): PaymentAdjustmentReasonConcept;
