/**
 * ValueSet: contact-point-system
 * URL: http://hl7.org/fhir/ValueSet/contact-point-system
 * Size: 7 concepts
 */
export declare const ContactPointSystemConcepts: readonly [{
    readonly code: "phone";
    readonly system: "http://hl7.org/fhir/contact-point-system";
}, {
    readonly code: "fax";
    readonly system: "http://hl7.org/fhir/contact-point-system";
}, {
    readonly code: "email";
    readonly system: "http://hl7.org/fhir/contact-point-system";
}, {
    readonly code: "pager";
    readonly system: "http://hl7.org/fhir/contact-point-system";
}, {
    readonly code: "url";
    readonly system: "http://hl7.org/fhir/contact-point-system";
}, {
    readonly code: "sms";
    readonly system: "http://hl7.org/fhir/contact-point-system";
}, {
    readonly code: "other";
    readonly system: "http://hl7.org/fhir/contact-point-system";
}];
/** Union type of all valid codes in this ValueSet */
export type ContactPointSystemCode = "phone" | "fax" | "email" | "pager" | "url" | "sms" | "other";
/** Type representing a concept from this ValueSet */
export type ContactPointSystemConcept = typeof ContactPointSystemConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidContactPointSystemCode(code: string): code is ContactPointSystemCode;
/**
 * Get concept details by code
 */
export declare function getContactPointSystemConcept(code: string): ContactPointSystemConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ContactPointSystemCodes: ("url" | "phone" | "fax" | "email" | "pager" | "sms" | "other")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomContactPointSystemCode(): ContactPointSystemCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomContactPointSystemConcept(): ContactPointSystemConcept;
