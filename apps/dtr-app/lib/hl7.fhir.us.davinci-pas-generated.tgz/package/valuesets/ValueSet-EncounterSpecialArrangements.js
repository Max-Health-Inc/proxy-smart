/**
 * ValueSet: encounter-special-arrangements
 * URL: http://hl7.org/fhir/ValueSet/encounter-special-arrangements
 * Size: 5 concepts
 */
export const EncounterSpecialArrangementsConcepts = [
    { code: "wheel", system: "http://terminology.hl7.org/CodeSystem/encounter-special-arrangements" },
    { code: "add-bed", system: "http://terminology.hl7.org/CodeSystem/encounter-special-arrangements" },
    { code: "int", system: "http://terminology.hl7.org/CodeSystem/encounter-special-arrangements" },
    { code: "att", system: "http://terminology.hl7.org/CodeSystem/encounter-special-arrangements" },
    { code: "dog", system: "http://terminology.hl7.org/CodeSystem/encounter-special-arrangements" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidEncounterSpecialArrangementsCode(code) {
    return EncounterSpecialArrangementsConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getEncounterSpecialArrangementsConcept(code) {
    return EncounterSpecialArrangementsConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const EncounterSpecialArrangementsCodes = EncounterSpecialArrangementsConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomEncounterSpecialArrangementsCode() {
    return EncounterSpecialArrangementsCodes[Math.floor(Math.random() * EncounterSpecialArrangementsCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomEncounterSpecialArrangementsConcept() {
    return EncounterSpecialArrangementsConcepts[Math.floor(Math.random() * EncounterSpecialArrangementsConcepts.length)];
}
