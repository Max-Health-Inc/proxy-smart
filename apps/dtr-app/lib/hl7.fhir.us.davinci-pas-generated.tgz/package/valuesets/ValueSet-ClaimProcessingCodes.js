/**
 * ValueSet: ClaimProcessingCodes
 * URL: http://hl7.org/fhir/ValueSet/remittance-outcome
 * Size: 4 concepts
 */
export const ClaimProcessingCodesConcepts = [
    { code: "queued", system: "http://hl7.org/fhir/remittance-outcome", display: "Queued" },
    { code: "complete", system: "http://hl7.org/fhir/remittance-outcome", display: "Processing Complete" },
    { code: "error", system: "http://hl7.org/fhir/remittance-outcome", display: "Error" },
    { code: "partial", system: "http://hl7.org/fhir/remittance-outcome", display: "Partial Processing" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidClaimProcessingCodesCode(code) {
    return ClaimProcessingCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getClaimProcessingCodesConcept(code) {
    return ClaimProcessingCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ClaimProcessingCodesCodes = ClaimProcessingCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomClaimProcessingCodesCode() {
    return ClaimProcessingCodesCodes[Math.floor(Math.random() * ClaimProcessingCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomClaimProcessingCodesConcept() {
    return ClaimProcessingCodesConcepts[Math.floor(Math.random() * ClaimProcessingCodesConcepts.length)];
}
