/**
 * ValueSet: v2-0116
 * URL: http://terminology.hl7.org/ValueSet/v2-0116
 * Size: 6 concepts
 */
export declare const V20116Concepts: readonly [{
    readonly code: "C";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0116";
}, {
    readonly code: "H";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0116";
}, {
    readonly code: "O";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0116";
}, {
    readonly code: "U";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0116";
}, {
    readonly code: "K";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0116";
}, {
    readonly code: "I";
    readonly system: "http://terminology.hl7.org/CodeSystem/v2-0116";
}];
/** Union type of all valid codes in this ValueSet */
export type V20116Code = "C" | "H" | "O" | "U" | "K" | "I";
/** Type representing a concept from this ValueSet */
export type V20116Concept = typeof V20116Concepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidV20116Code(code: string): code is V20116Code;
/**
 * Get concept details by code
 */
export declare function getV20116Concept(code: string): V20116Concept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const V20116Codes: ("C" | "H" | "O" | "U" | "K" | "I")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomV20116Code(): V20116Code;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomV20116Concept(): V20116Concept;
