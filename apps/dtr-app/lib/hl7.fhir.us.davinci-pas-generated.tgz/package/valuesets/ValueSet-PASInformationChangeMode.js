/**
 * ValueSet: PASInformationChangeMode
 * URL: http://hl7.org/fhir/us/davinci-pas/ValueSet/PASInformationChangeMode
 * Size: 2 concepts
 */
export const PASInformationChangeModeConcepts = [
    { code: "changed", system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes" },
    { code: "added", system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidPASInformationChangeModeCode(code) {
    return PASInformationChangeModeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getPASInformationChangeModeConcept(code) {
    return PASInformationChangeModeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const PASInformationChangeModeCodes = PASInformationChangeModeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomPASInformationChangeModeCode() {
    return PASInformationChangeModeCodes[Math.floor(Math.random() * PASInformationChangeModeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomPASInformationChangeModeConcept() {
    return PASInformationChangeModeConcepts[Math.floor(Math.random() * PASInformationChangeModeConcepts.length)];
}
