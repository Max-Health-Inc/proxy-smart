/**
 * ValueSet: PASInformationChangeMode
 * URL: http://hl7.org/fhir/us/davinci-pas/ValueSet/PASInformationChangeMode
 * Size: 2 concepts
 */
export declare const PASInformationChangeModeConcepts: readonly [{
    readonly code: "changed";
    readonly system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes";
}, {
    readonly code: "added";
    readonly system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes";
}];
/** Union type of all valid codes in this ValueSet */
export type PASInformationChangeModeCode = "changed" | "added";
/** Type representing a concept from this ValueSet */
export type PASInformationChangeModeConcept = typeof PASInformationChangeModeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidPASInformationChangeModeCode(code: string): code is PASInformationChangeModeCode;
/**
 * Get concept details by code
 */
export declare function getPASInformationChangeModeConcept(code: string): PASInformationChangeModeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const PASInformationChangeModeCodes: ("changed" | "added")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomPASInformationChangeModeCode(): PASInformationChangeModeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomPASInformationChangeModeConcept(): PASInformationChangeModeConcept;
