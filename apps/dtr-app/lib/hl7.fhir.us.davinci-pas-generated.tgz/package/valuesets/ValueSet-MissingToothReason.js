/**
 * ValueSet: missing-tooth-reason
 * URL: http://hl7.org/fhir/ValueSet/missing-tooth-reason
 * Size: 4 concepts
 */
export const MissingToothReasonConcepts = [
    { code: "e", system: "http://terminology.hl7.org/CodeSystem/missingtoothreason" },
    { code: "c", system: "http://terminology.hl7.org/CodeSystem/missingtoothreason" },
    { code: "u", system: "http://terminology.hl7.org/CodeSystem/missingtoothreason" },
    { code: "o", system: "http://terminology.hl7.org/CodeSystem/missingtoothreason" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidMissingToothReasonCode(code) {
    return MissingToothReasonConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getMissingToothReasonConcept(code) {
    return MissingToothReasonConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const MissingToothReasonCodes = MissingToothReasonConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomMissingToothReasonCode() {
    return MissingToothReasonCodes[Math.floor(Math.random() * MissingToothReasonCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomMissingToothReasonConcept() {
    return MissingToothReasonConcepts[Math.floor(Math.random() * MissingToothReasonConcepts.length)];
}
