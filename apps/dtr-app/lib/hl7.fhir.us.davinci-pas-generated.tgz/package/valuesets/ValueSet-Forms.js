/**
 * ValueSet: forms
 * URL: http://hl7.org/fhir/ValueSet/forms
 * Size: 2 concepts
 */
export const FormsConcepts = [
    { code: "1", system: "http://terminology.hl7.org/CodeSystem/forms-codes" },
    { code: "2", system: "http://terminology.hl7.org/CodeSystem/forms-codes" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidFormsCode(code) {
    return FormsConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getFormsConcept(code) {
    return FormsConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const FormsCodes = FormsConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomFormsCode() {
    return FormsCodes[Math.floor(Math.random() * FormsCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomFormsConcept() {
    return FormsConcepts[Math.floor(Math.random() * FormsConcepts.length)];
}
