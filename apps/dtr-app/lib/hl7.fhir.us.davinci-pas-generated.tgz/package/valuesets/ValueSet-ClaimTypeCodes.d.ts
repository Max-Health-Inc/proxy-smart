/**
 * ValueSet: ClaimTypeCodes
 * URL: http://hl7.org/fhir/ValueSet/claim-type
 * Size: 5 concepts
 */
export declare const ClaimTypeCodesConcepts: readonly [{
    readonly code: "institutional";
    readonly system: "http://terminology.hl7.org/CodeSystem/claim-type";
    readonly display: "Institutional";
}, {
    readonly code: "oral";
    readonly system: "http://terminology.hl7.org/CodeSystem/claim-type";
    readonly display: "Oral";
}, {
    readonly code: "pharmacy";
    readonly system: "http://terminology.hl7.org/CodeSystem/claim-type";
    readonly display: "Pharmacy";
}, {
    readonly code: "professional";
    readonly system: "http://terminology.hl7.org/CodeSystem/claim-type";
    readonly display: "Professional";
}, {
    readonly code: "vision";
    readonly system: "http://terminology.hl7.org/CodeSystem/claim-type";
    readonly display: "Vision";
}];
/** Union type of all valid codes in this ValueSet */
export type ClaimTypeCodesCode = "institutional" | "oral" | "pharmacy" | "professional" | "vision";
/** Type representing a concept from this ValueSet */
export type ClaimTypeCodesConcept = typeof ClaimTypeCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidClaimTypeCodesCode(code: string): code is ClaimTypeCodesCode;
/**
 * Get concept details by code
 */
export declare function getClaimTypeCodesConcept(code: string): ClaimTypeCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ClaimTypeCodesCodes: ("professional" | "pharmacy" | "institutional" | "oral" | "vision")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomClaimTypeCodesCode(): ClaimTypeCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomClaimTypeCodesConcept(): ClaimTypeCodesConcept;
