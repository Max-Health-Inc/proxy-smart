/**
 * ValueSet: EventTiming
 * URL: http://hl7.org/fhir/ValueSet/event-timing
 * Size: 14 concepts
 */
export const EventTimingConcepts = [
    { code: "HS", system: "http://terminology.hl7.org/CodeSystem/v3-TimingEvent" },
    { code: "WAKE", system: "http://terminology.hl7.org/CodeSystem/v3-TimingEvent" },
    { code: "C", system: "http://terminology.hl7.org/CodeSystem/v3-TimingEvent" },
    { code: "CM", system: "http://terminology.hl7.org/CodeSystem/v3-TimingEvent" },
    { code: "CD", system: "http://terminology.hl7.org/CodeSystem/v3-TimingEvent" },
    { code: "CV", system: "http://terminology.hl7.org/CodeSystem/v3-TimingEvent" },
    { code: "AC", system: "http://terminology.hl7.org/CodeSystem/v3-TimingEvent" },
    { code: "ACM", system: "http://terminology.hl7.org/CodeSystem/v3-TimingEvent" },
    { code: "ACD", system: "http://terminology.hl7.org/CodeSystem/v3-TimingEvent" },
    { code: "ACV", system: "http://terminology.hl7.org/CodeSystem/v3-TimingEvent" },
    { code: "PC", system: "http://terminology.hl7.org/CodeSystem/v3-TimingEvent" },
    { code: "PCM", system: "http://terminology.hl7.org/CodeSystem/v3-TimingEvent" },
    { code: "PCD", system: "http://terminology.hl7.org/CodeSystem/v3-TimingEvent" },
    { code: "PCV", system: "http://terminology.hl7.org/CodeSystem/v3-TimingEvent" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidEventTimingCode(code) {
    return EventTimingConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getEventTimingConcept(code) {
    return EventTimingConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const EventTimingCodes = EventTimingConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomEventTimingCode() {
    return EventTimingCodes[Math.floor(Math.random() * EventTimingCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomEventTimingConcept() {
    return EventTimingConcepts[Math.floor(Math.random() * EventTimingConcepts.length)];
}
