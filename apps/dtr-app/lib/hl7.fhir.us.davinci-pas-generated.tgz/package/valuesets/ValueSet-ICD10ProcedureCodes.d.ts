/**
 * ValueSet: ICD-10ProcedureCodes
 * URL: http://hl7.org/fhir/ValueSet/icd-10-procedures
 * Size: 3 concepts
 */
export declare const ICD10ProcedureCodesConcepts: readonly [{
    readonly code: "123001";
    readonly system: "http://hl7.org/fhir/sid/ex-icd-10-procedures";
    readonly display: "PROC-1";
}, {
    readonly code: "123002";
    readonly system: "http://hl7.org/fhir/sid/ex-icd-10-procedures";
    readonly display: "PROC-2";
}, {
    readonly code: "123003";
    readonly system: "http://hl7.org/fhir/sid/ex-icd-10-procedures";
    readonly display: "PROC-3";
}];
/** Union type of all valid codes in this ValueSet */
export type ICD10ProcedureCodesCode = "123001" | "123002" | "123003";
/** Type representing a concept from this ValueSet */
export type ICD10ProcedureCodesConcept = typeof ICD10ProcedureCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidICD10ProcedureCodesCode(code: string): code is ICD10ProcedureCodesCode;
/**
 * Get concept details by code
 */
export declare function getICD10ProcedureCodesConcept(code: string): ICD10ProcedureCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ICD10ProcedureCodesCodes: ("123001" | "123002" | "123003")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomICD10ProcedureCodesCode(): ICD10ProcedureCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomICD10ProcedureCodesConcept(): ICD10ProcedureCodesConcept;
