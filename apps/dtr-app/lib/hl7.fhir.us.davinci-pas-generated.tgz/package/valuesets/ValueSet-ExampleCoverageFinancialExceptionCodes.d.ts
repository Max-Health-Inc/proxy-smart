/**
 * ValueSet: ExampleCoverageFinancialExceptionCodes
 * URL: http://hl7.org/fhir/ValueSet/coverage-financial-exception
 * Size: 2 concepts
 */
export declare const ExampleCoverageFinancialExceptionCodesConcepts: readonly [{
    readonly code: "retired";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-coverage-financial-exception";
    readonly display: "Retired";
}, {
    readonly code: "foster";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-coverage-financial-exception";
    readonly display: "Foster child";
}];
/** Union type of all valid codes in this ValueSet */
export type ExampleCoverageFinancialExceptionCodesCode = "retired" | "foster";
/** Type representing a concept from this ValueSet */
export type ExampleCoverageFinancialExceptionCodesConcept = typeof ExampleCoverageFinancialExceptionCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidExampleCoverageFinancialExceptionCodesCode(code: string): code is ExampleCoverageFinancialExceptionCodesCode;
/**
 * Get concept details by code
 */
export declare function getExampleCoverageFinancialExceptionCodesConcept(code: string): ExampleCoverageFinancialExceptionCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ExampleCoverageFinancialExceptionCodesCodes: ("retired" | "foster")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomExampleCoverageFinancialExceptionCodesCode(): ExampleCoverageFinancialExceptionCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomExampleCoverageFinancialExceptionCodesConcept(): ExampleCoverageFinancialExceptionCodesConcept;
