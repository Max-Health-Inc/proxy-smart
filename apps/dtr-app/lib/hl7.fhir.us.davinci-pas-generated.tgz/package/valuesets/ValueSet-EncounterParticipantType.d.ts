/**
 * ValueSet: encounter-participant-type
 * URL: http://hl7.org/fhir/ValueSet/encounter-participant-type
 * Size: 5 concepts
 */
export declare const EncounterParticipantTypeConcepts: readonly [{
    readonly code: "SPRF";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ParticipationType";
}, {
    readonly code: "PPRF";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ParticipationType";
}, {
    readonly code: "PART";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ParticipationType";
}, {
    readonly code: "translator";
    readonly system: "http://terminology.hl7.org/CodeSystem/participant-type";
}, {
    readonly code: "emergency";
    readonly system: "http://terminology.hl7.org/CodeSystem/participant-type";
}];
/** Union type of all valid codes in this ValueSet */
export type EncounterParticipantTypeCode = "SPRF" | "PPRF" | "PART" | "translator" | "emergency";
/** Type representing a concept from this ValueSet */
export type EncounterParticipantTypeConcept = typeof EncounterParticipantTypeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidEncounterParticipantTypeCode(code: string): code is EncounterParticipantTypeCode;
/**
 * Get concept details by code
 */
export declare function getEncounterParticipantTypeConcept(code: string): EncounterParticipantTypeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const EncounterParticipantTypeCodes: ("translator" | "emergency" | "SPRF" | "PPRF" | "PART")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomEncounterParticipantTypeCode(): EncounterParticipantTypeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomEncounterParticipantTypeConcept(): EncounterParticipantTypeConcept;
