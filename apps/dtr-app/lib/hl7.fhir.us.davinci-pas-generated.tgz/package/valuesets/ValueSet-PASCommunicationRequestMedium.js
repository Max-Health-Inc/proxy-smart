/**
 * ValueSet: PASCommunicationRequestMedium
 * URL: http://hl7.org/fhir/us/davinci-pas/ValueSet/PASCommunicationRequestMedium
 * Size: 1 concepts
 */
export const PASCommunicationRequestMediumConcepts = [
    { code: "CDEX", system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidPASCommunicationRequestMediumCode(code) {
    return PASCommunicationRequestMediumConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getPASCommunicationRequestMediumConcept(code) {
    return PASCommunicationRequestMediumConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const PASCommunicationRequestMediumCodes = PASCommunicationRequestMediumConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomPASCommunicationRequestMediumCode() {
    return PASCommunicationRequestMediumCodes[Math.floor(Math.random() * PASCommunicationRequestMediumCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomPASCommunicationRequestMediumConcept() {
    return PASCommunicationRequestMediumConcepts[Math.floor(Math.random() * PASCommunicationRequestMediumConcepts.length)];
}
