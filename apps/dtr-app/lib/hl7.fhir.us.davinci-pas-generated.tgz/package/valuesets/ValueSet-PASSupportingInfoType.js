/**
 * ValueSet: PASSupportingInfoType
 * URL: http://hl7.org/fhir/us/davinci-pas/ValueSet/PASSupportingInfoType
 * Size: 6 concepts
 */
export const PASSupportingInfoTypeConcepts = [
    { code: "patientEvent", system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes" },
    { code: "admissionDates", system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes" },
    { code: "dischargeDates", system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes" },
    { code: "additionalInformation", system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes" },
    { code: "freeFormMessage", system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes" },
    { code: "institutionalEncounter", system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidPASSupportingInfoTypeCode(code) {
    return PASSupportingInfoTypeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getPASSupportingInfoTypeConcept(code) {
    return PASSupportingInfoTypeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const PASSupportingInfoTypeCodes = PASSupportingInfoTypeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomPASSupportingInfoTypeCode() {
    return PASSupportingInfoTypeCodes[Math.floor(Math.random() * PASSupportingInfoTypeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomPASSupportingInfoTypeConcept() {
    return PASSupportingInfoTypeConcepts[Math.floor(Math.random() * PASSupportingInfoTypeConcepts.length)];
}
