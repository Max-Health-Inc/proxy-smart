/**
 * ValueSet: claim-type
 * URL: http://hl7.org/fhir/ValueSet/claim-type
 * Size: 5 concepts
 */
export const ClaimTypeConcepts = [
    { code: "institutional", system: "http://terminology.hl7.org/CodeSystem/claim-type" },
    { code: "oral", system: "http://terminology.hl7.org/CodeSystem/claim-type" },
    { code: "pharmacy", system: "http://terminology.hl7.org/CodeSystem/claim-type" },
    { code: "professional", system: "http://terminology.hl7.org/CodeSystem/claim-type" },
    { code: "vision", system: "http://terminology.hl7.org/CodeSystem/claim-type" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidClaimTypeCode(code) {
    return ClaimTypeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getClaimTypeConcept(code) {
    return ClaimTypeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ClaimTypeCodes = ClaimTypeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomClaimTypeCode() {
    return ClaimTypeCodes[Math.floor(Math.random() * ClaimTypeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomClaimTypeConcept() {
    return ClaimTypeConcepts[Math.floor(Math.random() * ClaimTypeConcepts.length)];
}
