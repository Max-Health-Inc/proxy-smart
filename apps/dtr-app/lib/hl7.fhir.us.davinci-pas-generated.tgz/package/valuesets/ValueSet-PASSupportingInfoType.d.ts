/**
 * ValueSet: PASSupportingInfoType
 * URL: http://hl7.org/fhir/us/davinci-pas/ValueSet/PASSupportingInfoType
 * Size: 6 concepts
 */
export declare const PASSupportingInfoTypeConcepts: readonly [{
    readonly code: "patientEvent";
    readonly system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes";
}, {
    readonly code: "admissionDates";
    readonly system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes";
}, {
    readonly code: "dischargeDates";
    readonly system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes";
}, {
    readonly code: "additionalInformation";
    readonly system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes";
}, {
    readonly code: "freeFormMessage";
    readonly system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes";
}, {
    readonly code: "institutionalEncounter";
    readonly system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes";
}];
/** Union type of all valid codes in this ValueSet */
export type PASSupportingInfoTypeCode = "patientEvent" | "admissionDates" | "dischargeDates" | "additionalInformation" | "freeFormMessage" | "institutionalEncounter";
/** Type representing a concept from this ValueSet */
export type PASSupportingInfoTypeConcept = typeof PASSupportingInfoTypeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidPASSupportingInfoTypeCode(code: string): code is PASSupportingInfoTypeCode;
/**
 * Get concept details by code
 */
export declare function getPASSupportingInfoTypeConcept(code: string): PASSupportingInfoTypeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const PASSupportingInfoTypeCodes: ("dischargeDates" | "patientEvent" | "admissionDates" | "additionalInformation" | "freeFormMessage" | "institutionalEncounter")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomPASSupportingInfoTypeCode(): PASSupportingInfoTypeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomPASSupportingInfoTypeConcept(): PASSupportingInfoTypeConcept;
