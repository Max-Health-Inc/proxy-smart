/**
 * ValueSet: ExampleRevenueCenterCodes
 * URL: http://hl7.org/fhir/ValueSet/ex-revenue-center
 * Size: 9 concepts
 */
export const ExampleRevenueCenterCodesConcepts = [
    { code: "0370", system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center", display: "Anaesthesia" },
    { code: "0420", system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center", display: "Physical Therapy" },
    { code: "0421", system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center", display: "Physical Therapy - " },
    { code: "0440", system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center", display: "Speech-Language Pathology" },
    { code: "0441", system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center", display: "Speech-Language Pathology - Visit" },
    { code: "0450", system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center", display: "Emergency Room" },
    { code: "0451", system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center", display: "Emergency Room - EM/EMTALA" },
    { code: "0452", system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center", display: "Emergency Room - beyond EMTALA" },
    { code: "0010", system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center", display: "Vision Clinic" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidExampleRevenueCenterCodesCode(code) {
    return ExampleRevenueCenterCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getExampleRevenueCenterCodesConcept(code) {
    return ExampleRevenueCenterCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ExampleRevenueCenterCodesCodes = ExampleRevenueCenterCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomExampleRevenueCenterCodesCode() {
    return ExampleRevenueCenterCodesCodes[Math.floor(Math.random() * ExampleRevenueCenterCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomExampleRevenueCenterCodesConcept() {
    return ExampleRevenueCenterCodesConcepts[Math.floor(Math.random() * ExampleRevenueCenterCodesConcepts.length)];
}
