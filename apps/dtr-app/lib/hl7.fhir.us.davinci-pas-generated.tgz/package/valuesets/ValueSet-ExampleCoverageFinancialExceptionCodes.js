/**
 * ValueSet: ExampleCoverageFinancialExceptionCodes
 * URL: http://hl7.org/fhir/ValueSet/coverage-financial-exception
 * Size: 2 concepts
 */
export const ExampleCoverageFinancialExceptionCodesConcepts = [
    { code: "retired", system: "http://terminology.hl7.org/CodeSystem/ex-coverage-financial-exception", display: "Retired" },
    { code: "foster", system: "http://terminology.hl7.org/CodeSystem/ex-coverage-financial-exception", display: "Foster child" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidExampleCoverageFinancialExceptionCodesCode(code) {
    return ExampleCoverageFinancialExceptionCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getExampleCoverageFinancialExceptionCodesConcept(code) {
    return ExampleCoverageFinancialExceptionCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ExampleCoverageFinancialExceptionCodesCodes = ExampleCoverageFinancialExceptionCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomExampleCoverageFinancialExceptionCodesCode() {
    return ExampleCoverageFinancialExceptionCodesCodes[Math.floor(Math.random() * ExampleCoverageFinancialExceptionCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomExampleCoverageFinancialExceptionCodesConcept() {
    return ExampleCoverageFinancialExceptionCodesConcepts[Math.floor(Math.random() * ExampleCoverageFinancialExceptionCodesConcepts.length)];
}
