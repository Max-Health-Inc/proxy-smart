/**
 * ValueSet: address-type
 * URL: http://hl7.org/fhir/ValueSet/address-type
 * Size: 3 concepts
 */
export declare const AddressTypeConcepts: readonly [{
    readonly code: "postal";
    readonly system: "http://hl7.org/fhir/address-type";
}, {
    readonly code: "physical";
    readonly system: "http://hl7.org/fhir/address-type";
}, {
    readonly code: "both";
    readonly system: "http://hl7.org/fhir/address-type";
}];
/** Union type of all valid codes in this ValueSet */
export type AddressTypeCode = "postal" | "physical" | "both";
/** Type representing a concept from this ValueSet */
export type AddressTypeConcept = typeof AddressTypeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidAddressTypeCode(code: string): code is AddressTypeCode;
/**
 * Get concept details by code
 */
export declare function getAddressTypeConcept(code: string): AddressTypeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const AddressTypeCodes: ("postal" | "physical" | "both")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomAddressTypeCode(): AddressTypeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomAddressTypeConcept(): AddressTypeConcept;
