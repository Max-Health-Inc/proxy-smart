/**
 * ValueSet: ex-revenue-center
 * URL: http://hl7.org/fhir/ValueSet/ex-revenue-center
 * Size: 9 concepts
 */
export const ExRevenueCenterConcepts = [
    { code: "0370", system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center" },
    { code: "0420", system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center" },
    { code: "0421", system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center" },
    { code: "0440", system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center" },
    { code: "0441", system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center" },
    { code: "0450", system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center" },
    { code: "0451", system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center" },
    { code: "0452", system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center" },
    { code: "0010", system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidExRevenueCenterCode(code) {
    return ExRevenueCenterConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getExRevenueCenterConcept(code) {
    return ExRevenueCenterConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ExRevenueCenterCodes = ExRevenueCenterConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomExRevenueCenterCode() {
    return ExRevenueCenterCodes[Math.floor(Math.random() * ExRevenueCenterCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomExRevenueCenterConcept() {
    return ExRevenueCenterConcepts[Math.floor(Math.random() * ExRevenueCenterConcepts.length)];
}
