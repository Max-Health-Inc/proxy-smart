/**
 * ValueSet: ExampleDiagnosisOnAdmissionCodes
 * URL: http://hl7.org/fhir/ValueSet/ex-diagnosis-on-admission
 * Size: 4 concepts
 */
export declare const ExampleDiagnosisOnAdmissionCodesConcepts: readonly [{
    readonly code: "y";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-diagnosis-on-admission";
    readonly display: "Yes";
}, {
    readonly code: "n";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-diagnosis-on-admission";
    readonly display: "No";
}, {
    readonly code: "u";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-diagnosis-on-admission";
    readonly display: "Unknown";
}, {
    readonly code: "w";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-diagnosis-on-admission";
    readonly display: "Undetermined";
}];
/** Union type of all valid codes in this ValueSet */
export type ExampleDiagnosisOnAdmissionCodesCode = "y" | "n" | "u" | "w";
/** Type representing a concept from this ValueSet */
export type ExampleDiagnosisOnAdmissionCodesConcept = typeof ExampleDiagnosisOnAdmissionCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidExampleDiagnosisOnAdmissionCodesCode(code: string): code is ExampleDiagnosisOnAdmissionCodesCode;
/**
 * Get concept details by code
 */
export declare function getExampleDiagnosisOnAdmissionCodesConcept(code: string): ExampleDiagnosisOnAdmissionCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ExampleDiagnosisOnAdmissionCodesCodes: ("u" | "w" | "y" | "n")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomExampleDiagnosisOnAdmissionCodesCode(): ExampleDiagnosisOnAdmissionCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomExampleDiagnosisOnAdmissionCodesConcept(): ExampleDiagnosisOnAdmissionCodesConcept;
