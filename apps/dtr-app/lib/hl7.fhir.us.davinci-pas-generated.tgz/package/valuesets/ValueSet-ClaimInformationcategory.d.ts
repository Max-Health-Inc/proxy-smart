/**
 * ValueSet: claim-informationcategory
 * URL: http://hl7.org/fhir/ValueSet/claim-informationcategory
 * Size: 14 concepts
 */
export declare const ClaimInformationcategoryConcepts: readonly [{
    readonly code: "info";
    readonly system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory";
}, {
    readonly code: "discharge";
    readonly system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory";
}, {
    readonly code: "onset";
    readonly system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory";
}, {
    readonly code: "related";
    readonly system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory";
}, {
    readonly code: "exception";
    readonly system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory";
}, {
    readonly code: "material";
    readonly system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory";
}, {
    readonly code: "attachment";
    readonly system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory";
}, {
    readonly code: "missingtooth";
    readonly system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory";
}, {
    readonly code: "prosthesis";
    readonly system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory";
}, {
    readonly code: "other";
    readonly system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory";
}, {
    readonly code: "hospitalized";
    readonly system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory";
}, {
    readonly code: "employmentimpacted";
    readonly system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory";
}, {
    readonly code: "externalcause";
    readonly system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory";
}, {
    readonly code: "patientreasonforvisit";
    readonly system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory";
}];
/** Union type of all valid codes in this ValueSet */
export type ClaimInformationcategoryCode = "info" | "discharge" | "onset" | "related" | "exception" | "material" | "attachment" | "missingtooth" | "prosthesis" | "other" | "hospitalized" | "employmentimpacted" | "externalcause" | "patientreasonforvisit";
/** Type representing a concept from this ValueSet */
export type ClaimInformationcategoryConcept = typeof ClaimInformationcategoryConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidClaimInformationcategoryCode(code: string): code is ClaimInformationcategoryCode;
/**
 * Get concept details by code
 */
export declare function getClaimInformationcategoryConcept(code: string): ClaimInformationcategoryConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ClaimInformationcategoryCodes: ("other" | "patientreasonforvisit" | "related" | "exception" | "info" | "discharge" | "onset" | "material" | "attachment" | "missingtooth" | "prosthesis" | "hospitalized" | "employmentimpacted" | "externalcause")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomClaimInformationcategoryCode(): ClaimInformationcategoryCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomClaimInformationcategoryConcept(): ClaimInformationcategoryConcept;
