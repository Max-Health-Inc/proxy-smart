/**
 * ValueSet: LocationType
 * URL: http://hl7.org/fhir/ValueSet/location-physical-type
 * Size: 14 concepts
 */
export const LocationTypeConcepts = [
    { code: "si", system: "http://terminology.hl7.org/CodeSystem/location-physical-type", display: "Site" },
    { code: "bu", system: "http://terminology.hl7.org/CodeSystem/location-physical-type", display: "Building" },
    { code: "wi", system: "http://terminology.hl7.org/CodeSystem/location-physical-type", display: "Wing" },
    { code: "wa", system: "http://terminology.hl7.org/CodeSystem/location-physical-type", display: "Ward" },
    { code: "lvl", system: "http://terminology.hl7.org/CodeSystem/location-physical-type", display: "Level" },
    { code: "co", system: "http://terminology.hl7.org/CodeSystem/location-physical-type", display: "Corridor" },
    { code: "ro", system: "http://terminology.hl7.org/CodeSystem/location-physical-type", display: "Room" },
    { code: "bd", system: "http://terminology.hl7.org/CodeSystem/location-physical-type", display: "Bed" },
    { code: "ve", system: "http://terminology.hl7.org/CodeSystem/location-physical-type", display: "Vehicle" },
    { code: "ho", system: "http://terminology.hl7.org/CodeSystem/location-physical-type", display: "House" },
    { code: "ca", system: "http://terminology.hl7.org/CodeSystem/location-physical-type", display: "Cabinet" },
    { code: "rd", system: "http://terminology.hl7.org/CodeSystem/location-physical-type", display: "Road" },
    { code: "area", system: "http://terminology.hl7.org/CodeSystem/location-physical-type", display: "Area" },
    { code: "jdn", system: "http://terminology.hl7.org/CodeSystem/location-physical-type", display: "Jurisdiction" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidLocationTypeCode(code) {
    return LocationTypeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getLocationTypeConcept(code) {
    return LocationTypeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const LocationTypeCodes = LocationTypeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomLocationTypeCode() {
    return LocationTypeCodes[Math.floor(Math.random() * LocationTypeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomLocationTypeConcept() {
    return LocationTypeConcepts[Math.floor(Math.random() * LocationTypeConcepts.length)];
}
