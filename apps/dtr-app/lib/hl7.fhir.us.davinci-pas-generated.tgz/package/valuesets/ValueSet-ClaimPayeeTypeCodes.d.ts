/**
 * ValueSet: Claim Payee Type Codes
 * URL: http://hl7.org/fhir/ValueSet/payeetype
 * Size: 3 concepts
 */
export declare const ClaimPayeeTypeCodesConcepts: readonly [{
    readonly code: "subscriber";
    readonly system: "http://terminology.hl7.org/CodeSystem/payeetype";
    readonly display: "Subscriber";
}, {
    readonly code: "provider";
    readonly system: "http://terminology.hl7.org/CodeSystem/payeetype";
    readonly display: "Provider";
}, {
    readonly code: "other";
    readonly system: "http://terminology.hl7.org/CodeSystem/payeetype";
    readonly display: "Provider";
}];
/** Union type of all valid codes in this ValueSet */
export type ClaimPayeeTypeCodesCode = "subscriber" | "provider" | "other";
/** Type representing a concept from this ValueSet */
export type ClaimPayeeTypeCodesConcept = typeof ClaimPayeeTypeCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidClaimPayeeTypeCodesCode(code: string): code is ClaimPayeeTypeCodesCode;
/**
 * Get concept details by code
 */
export declare function getClaimPayeeTypeCodesConcept(code: string): ClaimPayeeTypeCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ClaimPayeeTypeCodesCodes: ("provider" | "other" | "subscriber")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomClaimPayeeTypeCodesCode(): ClaimPayeeTypeCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomClaimPayeeTypeCodesConcept(): ClaimPayeeTypeCodesConcept;
