/**
 * ValueSet: AdjudicationReasonCodes
 * URL: http://hl7.org/fhir/ValueSet/adjudication-reason
 * Size: 2 concepts
 */
export declare const AdjudicationReasonCodesConcepts: readonly [{
    readonly code: "ar001";
    readonly system: "http://terminology.hl7.org/CodeSystem/adjudication-reason";
    readonly display: "Not covered";
}, {
    readonly code: "ar002";
    readonly system: "http://terminology.hl7.org/CodeSystem/adjudication-reason";
    readonly display: "Plan Limit Reached";
}];
/** Union type of all valid codes in this ValueSet */
export type AdjudicationReasonCodesCode = "ar001" | "ar002";
/** Type representing a concept from this ValueSet */
export type AdjudicationReasonCodesConcept = typeof AdjudicationReasonCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidAdjudicationReasonCodesCode(code: string): code is AdjudicationReasonCodesCode;
/**
 * Get concept details by code
 */
export declare function getAdjudicationReasonCodesConcept(code: string): AdjudicationReasonCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const AdjudicationReasonCodesCodes: ("ar001" | "ar002")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomAdjudicationReasonCodesCode(): AdjudicationReasonCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomAdjudicationReasonCodesConcept(): AdjudicationReasonCodesConcept;
