/**
 * ValueSet: PASTaskCodes
 * URL: http://hl7.org/fhir/us/davinci-pas/ValueSet/PASTaskCodes
 * Size: 2 concepts
 */
export const PASTaskCodesConcepts = [
    { code: "attachment-request-code", system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes" },
    { code: "attachment-request-questionnaire", system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidPASTaskCodesCode(code) {
    return PASTaskCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getPASTaskCodesConcept(code) {
    return PASTaskCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const PASTaskCodesCodes = PASTaskCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomPASTaskCodesCode() {
    return PASTaskCodesCodes[Math.floor(Math.random() * PASTaskCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomPASTaskCodesConcept() {
    return PASTaskCodesConcepts[Math.floor(Math.random() * PASTaskCodesConcepts.length)];
}
