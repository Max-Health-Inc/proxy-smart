/**
 * ValueSet: nutrient-code
 * URL: http://hl7.org/fhir/ValueSet/nutrient-code
 * Size: 3 concepts
 */
export const NutrientCodeConcepts = [
    { code: "33463005", system: "http://snomed.info/sct" },
    { code: "39972003", system: "http://snomed.info/sct" },
    { code: "88480006", system: "http://snomed.info/sct" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidNutrientCodeCode(code) {
    return NutrientCodeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getNutrientCodeConcept(code) {
    return NutrientCodeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const NutrientCodeCodes = NutrientCodeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomNutrientCodeCode() {
    return NutrientCodeCodes[Math.floor(Math.random() * NutrientCodeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomNutrientCodeConcept() {
    return NutrientCodeConcepts[Math.floor(Math.random() * NutrientCodeConcepts.length)];
}
