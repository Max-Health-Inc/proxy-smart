/**
 * ValueSet: NoteType
 * URL: http://hl7.org/fhir/ValueSet/note-type
 * Size: 3 concepts
 */
export const NoteTypeConcepts = [
    { code: "display", system: "http://hl7.org/fhir/note-type", display: "Display" },
    { code: "print", system: "http://hl7.org/fhir/note-type", display: "Print (Form)" },
    { code: "printoper", system: "http://hl7.org/fhir/note-type", display: "Print (Operator)" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidNoteTypeCode(code) {
    return NoteTypeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getNoteTypeConcept(code) {
    return NoteTypeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const NoteTypeCodes = NoteTypeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomNoteTypeCode() {
    return NoteTypeCodes[Math.floor(Math.random() * NoteTypeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomNoteTypeConcept() {
    return NoteTypeConcepts[Math.floor(Math.random() * NoteTypeConcepts.length)];
}
