/**
 * ValueSet: location-status
 * URL: http://hl7.org/fhir/ValueSet/location-status
 * Size: 3 concepts
 */
export const LocationStatusConcepts = [
    { code: "active", system: "http://hl7.org/fhir/location-status" },
    { code: "suspended", system: "http://hl7.org/fhir/location-status" },
    { code: "inactive", system: "http://hl7.org/fhir/location-status" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidLocationStatusCode(code) {
    return LocationStatusConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getLocationStatusConcept(code) {
    return LocationStatusConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const LocationStatusCodes = LocationStatusConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomLocationStatusCode() {
    return LocationStatusCodes[Math.floor(Math.random() * LocationStatusCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomLocationStatusConcept() {
    return LocationStatusConcepts[Math.floor(Math.random() * LocationStatusConcepts.length)];
}
