/**
 * ValueSet: BenefitCategoryCodes
 * URL: http://hl7.org/fhir/ValueSet/ex-benefitcategory
 * Size: 28 concepts
 */
export declare const BenefitCategoryCodesConcepts: readonly [{
    readonly code: "1";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
    readonly display: "Medical Care";
}, {
    readonly code: "2";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
    readonly display: "Surgical";
}, {
    readonly code: "3";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
    readonly display: "Consultation";
}, {
    readonly code: "4";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
    readonly display: "Diagnostic XRay";
}, {
    readonly code: "5";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
    readonly display: "Diagnostic Lab";
}, {
    readonly code: "14";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
    readonly display: "Renal Supplies";
}, {
    readonly code: "23";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
    readonly display: "Diagnostic Dental";
}, {
    readonly code: "24";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
    readonly display: "Periodontics";
}, {
    readonly code: "25";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
    readonly display: "Restorative";
}, {
    readonly code: "26";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
    readonly display: "Endodontics";
}, {
    readonly code: "27";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
    readonly display: "Maxillofacial Prosthetics";
}, {
    readonly code: "28";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
    readonly display: "Adjunctive Dental Services";
}, {
    readonly code: "30";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
    readonly display: "Health Benefit Plan Coverage";
}, {
    readonly code: "35";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
    readonly display: "Dental Care";
}, {
    readonly code: "36";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
    readonly display: "Dental Crowns";
}, {
    readonly code: "37";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
    readonly display: "Dental Accident";
}, {
    readonly code: "49";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
    readonly display: "Hospital Room and Board";
}, {
    readonly code: "55";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
    readonly display: "Major Medical";
}, {
    readonly code: "56";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
    readonly display: "Medically Related Transportation";
}, {
    readonly code: "61";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
    readonly display: "In-vitro Fertilization";
}, {
    readonly code: "62";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
    readonly display: "MRI Scan";
}, {
    readonly code: "63";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
    readonly display: "Donor Procedures";
}, {
    readonly code: "69";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
    readonly display: "Maternity";
}, {
    readonly code: "76";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
    readonly display: "Renal Dialysis";
}, {
    readonly code: "F1";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
    readonly display: "Medical Coverage";
}, {
    readonly code: "F3";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
    readonly display: "Dental Coverage";
}, {
    readonly code: "F4";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
    readonly display: "Hearing Coverage";
}, {
    readonly code: "F6";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
    readonly display: "Vision Coverage";
}];
/** String type (ValueSet too large for union type) */
export type BenefitCategoryCodesCode = string;
/** Type representing a concept from this ValueSet */
export type BenefitCategoryCodesConcept = typeof BenefitCategoryCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidBenefitCategoryCodesCode(code: string): code is BenefitCategoryCodesCode;
/**
 * Get concept details by code
 */
export declare function getBenefitCategoryCodesConcept(code: string): BenefitCategoryCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const BenefitCategoryCodesCodes: ("1" | "3" | "2" | "4" | "5" | "14" | "23" | "26" | "24" | "25" | "27" | "28" | "30" | "35" | "36" | "37" | "49" | "55" | "56" | "61" | "62" | "63" | "69" | "76" | "F1" | "F3" | "F4" | "F6")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomBenefitCategoryCodesCode(): BenefitCategoryCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomBenefitCategoryCodesConcept(): BenefitCategoryCodesConcept;
