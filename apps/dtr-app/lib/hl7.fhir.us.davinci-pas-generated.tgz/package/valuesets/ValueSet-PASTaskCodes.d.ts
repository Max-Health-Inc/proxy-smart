/**
 * ValueSet: PASTaskCodes
 * URL: http://hl7.org/fhir/us/davinci-pas/ValueSet/PASTaskCodes
 * Size: 2 concepts
 */
export declare const PASTaskCodesConcepts: readonly [{
    readonly code: "attachment-request-code";
    readonly system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes";
}, {
    readonly code: "attachment-request-questionnaire";
    readonly system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes";
}];
/** Union type of all valid codes in this ValueSet */
export type PASTaskCodesCode = "attachment-request-code" | "attachment-request-questionnaire";
/** Type representing a concept from this ValueSet */
export type PASTaskCodesConcept = typeof PASTaskCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidPASTaskCodesCode(code: string): code is PASTaskCodesCode;
/**
 * Get concept details by code
 */
export declare function getPASTaskCodesConcept(code: string): PASTaskCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const PASTaskCodesCodes: ("attachment-request-code" | "attachment-request-questionnaire")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomPASTaskCodesCode(): PASTaskCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomPASTaskCodesConcept(): PASTaskCodesConcept;
