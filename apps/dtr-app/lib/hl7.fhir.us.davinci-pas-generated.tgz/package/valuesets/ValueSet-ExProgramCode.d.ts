/**
 * ValueSet: ex-program-code
 * URL: http://hl7.org/fhir/ValueSet/ex-program-code
 * Size: 4 concepts
 */
export declare const ExProgramCodeConcepts: readonly [{
    readonly code: "as";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-programcode";
}, {
    readonly code: "hd";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-programcode";
}, {
    readonly code: "auscr";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-programcode";
}, {
    readonly code: "none";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-programcode";
}];
/** Union type of all valid codes in this ValueSet */
export type ExProgramCodeCode = "as" | "hd" | "auscr" | "none";
/** Type representing a concept from this ValueSet */
export type ExProgramCodeConcept = typeof ExProgramCodeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidExProgramCodeCode(code: string): code is ExProgramCodeCode;
/**
 * Get concept details by code
 */
export declare function getExProgramCodeConcept(code: string): ExProgramCodeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ExProgramCodeCodes: ("auscr" | "as" | "hd" | "none")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomExProgramCodeCode(): ExProgramCodeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomExProgramCodeConcept(): ExProgramCodeConcept;
