/**
 * ValueSet: MetricDataSource
 * URL: http://hl7.org/fhir/us/davinci-pas/ValueSet/MetricDataSource
 * Size: 3 concepts
 */
export const MetricDataSourceConcepts = [
    { code: "payer-src", system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes" },
    { code: "provider-src", system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes" },
    { code: "intermediary-src", system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidMetricDataSourceCode(code) {
    return MetricDataSourceConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getMetricDataSourceConcept(code) {
    return MetricDataSourceConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const MetricDataSourceCodes = MetricDataSourceConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomMetricDataSourceCode() {
    return MetricDataSourceCodes[Math.floor(Math.random() * MetricDataSourceCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomMetricDataSourceConcept() {
    return MetricDataSourceConcepts[Math.floor(Math.random() * MetricDataSourceConcepts.length)];
}
