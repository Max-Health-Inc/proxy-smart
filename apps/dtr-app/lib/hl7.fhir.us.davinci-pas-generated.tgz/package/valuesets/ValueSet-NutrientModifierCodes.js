/**
 * ValueSet: NutrientModifierCodes
 * URL: http://hl7.org/fhir/ValueSet/nutrient-code
 * Size: Infinity concepts
 */
export const NutrientModifierCodesConcepts = [
    { code: "33463005", system: "http://snomed.info/sct", display: "Fluid" },
    { code: "39972003", system: "http://snomed.info/sct", display: "Sodium" },
    { code: "88480006", system: "http://snomed.info/sct", display: "Potassium" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidNutrientModifierCodesCode(code) {
    return NutrientModifierCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getNutrientModifierCodesConcept(code) {
    return NutrientModifierCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const NutrientModifierCodesCodes = NutrientModifierCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomNutrientModifierCodesCode() {
    return NutrientModifierCodesCodes[Math.floor(Math.random() * NutrientModifierCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomNutrientModifierCodesConcept() {
    return NutrientModifierCodesConcepts[Math.floor(Math.random() * NutrientModifierCodesConcepts.length)];
}
