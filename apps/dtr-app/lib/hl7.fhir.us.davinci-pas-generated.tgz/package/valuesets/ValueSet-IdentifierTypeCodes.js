/**
 * ValueSet: Identifier Type Codes
 * URL: http://hl7.org/fhir/ValueSet/identifier-type
 * Size: 18 concepts
 */
export const IdentifierTypeCodesConcepts = [
    { code: "DL", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
    { code: "PPN", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
    { code: "BRN", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
    { code: "MR", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
    { code: "MCN", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
    { code: "EN", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
    { code: "TAX", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
    { code: "NIIP", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
    { code: "PRN", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
    { code: "MD", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
    { code: "DR", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
    { code: "ACSN", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
    { code: "UDI", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
    { code: "SNO", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
    { code: "SB", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
    { code: "PLAC", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
    { code: "FILL", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
    { code: "JHN", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidIdentifierTypeCodesCode(code) {
    return IdentifierTypeCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getIdentifierTypeCodesConcept(code) {
    return IdentifierTypeCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const IdentifierTypeCodesCodes = IdentifierTypeCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomIdentifierTypeCodesCode() {
    return IdentifierTypeCodesCodes[Math.floor(Math.random() * IdentifierTypeCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomIdentifierTypeCodesConcept() {
    return IdentifierTypeCodesConcepts[Math.floor(Math.random() * IdentifierTypeCodesConcepts.length)];
}
