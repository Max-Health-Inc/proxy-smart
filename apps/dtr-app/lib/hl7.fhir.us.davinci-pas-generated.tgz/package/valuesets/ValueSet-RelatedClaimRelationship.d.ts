/**
 * ValueSet: related-claim-relationship
 * URL: http://hl7.org/fhir/ValueSet/related-claim-relationship
 * Size: 2 concepts
 */
export declare const RelatedClaimRelationshipConcepts: readonly [{
    readonly code: "prior";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-relatedclaimrelationship";
}, {
    readonly code: "associated";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-relatedclaimrelationship";
}];
/** Union type of all valid codes in this ValueSet */
export type RelatedClaimRelationshipCode = "prior" | "associated";
/** Type representing a concept from this ValueSet */
export type RelatedClaimRelationshipConcept = typeof RelatedClaimRelationshipConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidRelatedClaimRelationshipCode(code: string): code is RelatedClaimRelationshipCode;
/**
 * Get concept details by code
 */
export declare function getRelatedClaimRelationshipConcept(code: string): RelatedClaimRelationshipConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const RelatedClaimRelationshipCodes: ("associated" | "prior")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomRelatedClaimRelationshipCode(): RelatedClaimRelationshipCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomRelatedClaimRelationshipConcept(): RelatedClaimRelationshipConcept;
