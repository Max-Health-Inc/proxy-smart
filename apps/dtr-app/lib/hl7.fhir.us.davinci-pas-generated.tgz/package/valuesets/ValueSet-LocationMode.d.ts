/**
 * ValueSet: location-mode
 * URL: http://hl7.org/fhir/ValueSet/location-mode
 * Size: 2 concepts
 */
export declare const LocationModeConcepts: readonly [{
    readonly code: "instance";
    readonly system: "http://hl7.org/fhir/location-mode";
}, {
    readonly code: "kind";
    readonly system: "http://hl7.org/fhir/location-mode";
}];
/** Union type of all valid codes in this ValueSet */
export type LocationModeCode = "instance" | "kind";
/** Type representing a concept from this ValueSet */
export type LocationModeConcept = typeof LocationModeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidLocationModeCode(code: string): code is LocationModeCode;
/**
 * Get concept details by code
 */
export declare function getLocationModeConcept(code: string): LocationModeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const LocationModeCodes: ("instance" | "kind")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomLocationModeCode(): LocationModeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomLocationModeConcept(): LocationModeConcept;
