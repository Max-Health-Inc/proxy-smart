/**
 * ValueSet: ExampleRelatedClaimRelationshipCodes
 * URL: http://hl7.org/fhir/ValueSet/related-claim-relationship
 * Size: 2 concepts
 */
export declare const ExampleRelatedClaimRelationshipCodesConcepts: readonly [{
    readonly code: "prior";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-relatedclaimrelationship";
    readonly display: "Prior Claim";
}, {
    readonly code: "associated";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-relatedclaimrelationship";
    readonly display: "Associated Claim";
}];
/** Union type of all valid codes in this ValueSet */
export type ExampleRelatedClaimRelationshipCodesCode = "prior" | "associated";
/** Type representing a concept from this ValueSet */
export type ExampleRelatedClaimRelationshipCodesConcept = typeof ExampleRelatedClaimRelationshipCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidExampleRelatedClaimRelationshipCodesCode(code: string): code is ExampleRelatedClaimRelationshipCodesCode;
/**
 * Get concept details by code
 */
export declare function getExampleRelatedClaimRelationshipCodesConcept(code: string): ExampleRelatedClaimRelationshipCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ExampleRelatedClaimRelationshipCodesCodes: ("associated" | "prior")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomExampleRelatedClaimRelationshipCodesCode(): ExampleRelatedClaimRelationshipCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomExampleRelatedClaimRelationshipCodesConcept(): ExampleRelatedClaimRelationshipCodesConcept;
