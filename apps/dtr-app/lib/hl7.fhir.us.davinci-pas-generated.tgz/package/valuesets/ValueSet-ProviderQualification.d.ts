/**
 * ValueSet: provider-qualification
 * URL: http://hl7.org/fhir/ValueSet/provider-qualification
 * Size: 3 concepts
 */
export declare const ProviderQualificationConcepts: readonly [{
    readonly code: "311405";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-providerqualification";
}, {
    readonly code: "604215";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-providerqualification";
}, {
    readonly code: "604210";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-providerqualification";
}];
/** Union type of all valid codes in this ValueSet */
export type ProviderQualificationCode = "311405" | "604215" | "604210";
/** Type representing a concept from this ValueSet */
export type ProviderQualificationConcept = typeof ProviderQualificationConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidProviderQualificationCode(code: string): code is ProviderQualificationCode;
/**
 * Get concept details by code
 */
export declare function getProviderQualificationConcept(code: string): ProviderQualificationConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ProviderQualificationCodes: ("311405" | "604215" | "604210")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomProviderQualificationCode(): ProviderQualificationCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomProviderQualificationConcept(): ProviderQualificationConcept;
