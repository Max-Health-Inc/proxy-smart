/**
 * ValueSet: coverage-copay-type
 * URL: http://hl7.org/fhir/ValueSet/coverage-copay-type
 * Size: 10 concepts
 */
export const CoverageCopayTypeConcepts = [
    { code: "gpvisit", system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type" },
    { code: "spvisit", system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type" },
    { code: "emergency", system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type" },
    { code: "inpthosp", system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type" },
    { code: "televisit", system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type" },
    { code: "urgentcare", system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type" },
    { code: "copaypct", system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type" },
    { code: "copay", system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type" },
    { code: "deductible", system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type" },
    { code: "maxoutofpocket", system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidCoverageCopayTypeCode(code) {
    return CoverageCopayTypeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getCoverageCopayTypeConcept(code) {
    return CoverageCopayTypeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const CoverageCopayTypeCodes = CoverageCopayTypeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomCoverageCopayTypeCode() {
    return CoverageCopayTypeCodes[Math.floor(Math.random() * CoverageCopayTypeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomCoverageCopayTypeConcept() {
    return CoverageCopayTypeConcepts[Math.floor(Math.random() * CoverageCopayTypeConcepts.length)];
}
