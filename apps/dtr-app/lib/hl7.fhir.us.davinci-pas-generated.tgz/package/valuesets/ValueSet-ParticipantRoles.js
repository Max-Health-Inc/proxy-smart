/**
 * ValueSet: ParticipantRoles
 * URL: http://hl7.org/fhir/ValueSet/participant-role
 * Size: 100 concepts
 */
export const ParticipantRolesConcepts = [
    { code: "125676002", system: "http://snomed.info/sct", display: "Person" },
    { code: "270002", system: "http://snomed.info/sct", display: "Female first cousin" },
    { code: "375005", system: "http://snomed.info/sct", display: "Sibling" },
    { code: "444000", system: "http://snomed.info/sct", display: "Legal sibling" },
    { code: "609005", system: "http://snomed.info/sct", display: "Adoptive father" },
    { code: "1354005", system: "http://snomed.info/sct", display: "Orphan female" },
    { code: "2272004", system: "http://snomed.info/sct", display: "Half-sister" },
    { code: "2368000", system: "http://snomed.info/sct", display: "Great-great grand-mother" },
    { code: "2481008", system: "http://snomed.info/sct", display: "Working mother" },
    { code: "2959006", system: "http://snomed.info/sct", display: "Female cousin" },
    { code: "3425009", system: "http://snomed.info/sct", display: "Oldest daughter" },
    { code: "3851003", system: "http://snomed.info/sct", display: "Surrogate daughter" },
    { code: "4577005", system: "http://snomed.info/sct", display: "First cousin" },
    { code: "6676009", system: "http://snomed.info/sct", display: "Youngest daughter" },
    { code: "8458002", system: "http://snomed.info/sct", display: "Foster father" },
    { code: "8674003", system: "http://snomed.info/sct", display: "Step son" },
    { code: "9306000", system: "http://snomed.info/sct", display: "Legal parent" },
    { code: "9947008", system: "http://snomed.info/sct", display: "Natural father" },
    { code: "10896006", system: "http://snomed.info/sct", display: "Identical twin sibling" },
    { code: "10960006", system: "http://snomed.info/sct", display: "Working father" },
    { code: "11286003", system: "http://snomed.info/sct", display: "Twin sibling" },
    { code: "11393001", system: "http://snomed.info/sct", display: "Great-great grand child" },
    { code: "11434005", system: "http://snomed.info/sct", display: "Male second cousin" },
    { code: "11773006", system: "http://snomed.info/sct", display: "Legal brother" },
    { code: "11993008", system: "http://snomed.info/sct", display: "Male first cousin" },
    { code: "12241003", system: "http://snomed.info/sct", display: "Foster son" },
    { code: "12629003", system: "http://snomed.info/sct", display: "Single mother" },
    { code: "13038009", system: "http://snomed.info/sct", display: "Older brother" },
    { code: "13157002", system: "http://snomed.info/sct", display: "Older sibling" },
    { code: "13443008", system: "http://snomed.info/sct", display: "Second cousin" },
    { code: "13646006", system: "http://snomed.info/sct", display: "Natural parent" },
    { code: "14469008", system: "http://snomed.info/sct", display: "Legal child" },
    { code: "15130002", system: "http://snomed.info/sct", display: "Surrogate parent" },
    { code: "17219007", system: "http://snomed.info/sct", display: "Male fiance" },
    { code: "17925003", system: "http://snomed.info/sct", display: "Adoptive brother" },
    { code: "17945006", system: "http://snomed.info/sct", display: "Natural grand-mother" },
    { code: "18205005", system: "http://snomed.info/sct", display: "Wesleyan Methodist Church" },
    { code: "18906004", system: "http://snomed.info/sct", display: "Foster sibling" },
    { code: "19343003", system: "http://snomed.info/sct", display: "Twin sister" },
    { code: "19686009", system: "http://snomed.info/sct", display: "Younger sister" },
    { code: "21093007", system: "http://snomed.info/sct", display: "Half-sibling" },
    { code: "21464003", system: "http://snomed.info/sct", display: "Adoptive mother" },
    { code: "21506002", system: "http://snomed.info/sct", display: "Female second cousin" },
    { code: "22387007", system: "http://snomed.info/sct", display: "Surrogate child" },
    { code: "22573006", system: "http://snomed.info/sct", display: "Step daughter" },
    { code: "22609000", system: "http://snomed.info/sct", display: "Adoptive grand-parent" },
    { code: "22963000", system: "http://snomed.info/sct", display: "Legal sister" },
    { code: "25211005", system: "http://snomed.info/sct", display: "Aunt" },
    { code: "27508009", system: "http://snomed.info/sct", display: "Surrogate mother" },
    { code: "27733009", system: "http://snomed.info/sct", display: "Sister" },
    { code: "28010004", system: "http://snomed.info/sct", display: "Shiite muslim" },
    { code: "29539002", system: "http://snomed.info/sct", display: "Younger sibling" },
    { code: "29644004", system: "http://snomed.info/sct", display: "Fraternal twin sister" },
    { code: "29787005", system: "http://snomed.info/sct", display: "Foster brother" },
    { code: "30578000", system: "http://snomed.info/sct", display: "Step-father" },
    { code: "31656007", system: "http://snomed.info/sct", display: "Adoptive grand-mother" },
    { code: "31831004", system: "http://snomed.info/sct", display: "Foster daughter" },
    { code: "33969000", system: "http://snomed.info/sct", display: "Great grand-parent" },
    { code: "34581001", system: "http://snomed.info/sct", display: "Niece" },
    { code: "34871008", system: "http://snomed.info/sct", display: "Grand-father" },
    { code: "34972000", system: "http://snomed.info/sct", display: "Only daughter" },
    { code: "38048003", system: "http://snomed.info/sct", display: "Uncle" },
    { code: "38248007", system: "http://snomed.info/sct", display: "Oldest son" },
    { code: "38265003", system: "http://snomed.info/sct", display: "Foster mother" },
    { code: "38312007", system: "http://snomed.info/sct", display: "Grand-parent" },
    { code: "39062003", system: "http://snomed.info/sct", display: "Foster child" },
    { code: "40683002", system: "http://snomed.info/sct", display: "Parent" },
    { code: "41057000", system: "http://snomed.info/sct", display: "Surrogate son" },
    { code: "41795004", system: "http://snomed.info/sct", display: "Legal son" },
    { code: "41953004", system: "http://snomed.info/sct", display: "Adoptive parent" },
    { code: "44181008", system: "http://snomed.info/sct", display: "Grand daughter" },
    { code: "45929001", system: "http://snomed.info/sct", display: "Half-brother" },
    { code: "46363003", system: "http://snomed.info/sct", display: "Step sister" },
    { code: "47801002", system: "http://snomed.info/sct", display: "Male cousin" },
    { code: "48385004", system: "http://snomed.info/sct", display: "Acquaintance" },
    { code: "50058005", system: "http://snomed.info/sct", display: "Identical twin sister" },
    { code: "50261002", system: "http://snomed.info/sct", display: "Great grand-father" },
    { code: "51616000", system: "http://snomed.info/sct", display: "Sephardic Jew" },
    { code: "53201003", system: "http://snomed.info/sct", display: "Older sister" },
    { code: "54056000", system: "http://snomed.info/sct", display: "Trustee" },
    { code: "55538000", system: "http://snomed.info/sct", display: "Cousin" },
    { code: "58293006", system: "http://snomed.info/sct", display: "Foster sister" },
    { code: "58626002", system: "http://snomed.info/sct", display: "Legal guardian" },
    { code: "60614009", system: "http://snomed.info/sct", display: "Natural brother" },
    { code: "62090008", system: "http://snomed.info/sct", display: "Legal mother" },
    { code: "62296006", system: "http://snomed.info/sct", display: "Natural grand-father" },
    { code: "64988008", system: "http://snomed.info/sct", display: "Sunnite muslim" },
    { code: "65412001", system: "http://snomed.info/sct", display: "Step-mother" },
    { code: "65616008", system: "http://snomed.info/sct", display: "Son" },
    { code: "65656005", system: "http://snomed.info/sct", display: "Natural mother" },
    { code: "66089001", system: "http://snomed.info/sct", display: "Daughter" },
    { code: "66839005", system: "http://snomed.info/sct", display: "Father" },
    { code: "67147004", system: "http://snomed.info/sct", display: "Legal father" },
    { code: "67822003", system: "http://snomed.info/sct", display: "Child" },
    { code: "68021009", system: "http://snomed.info/sct", display: "Great-great grand-parent" },
    { code: "70578009", system: "http://snomed.info/sct", display: "Grand son" },
    { code: "70862002", system: "http://snomed.info/sct", display: "Contact person" },
    { code: "70924004", system: "http://snomed.info/sct", display: "Brother" },
    { code: "72012000", system: "http://snomed.info/sct", display: "Great grand child" },
    { code: "72705000", system: "http://snomed.info/sct", display: "Mother" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidParticipantRolesCode(code) {
    return ParticipantRolesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getParticipantRolesConcept(code) {
    return ParticipantRolesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ParticipantRolesCodes = ParticipantRolesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomParticipantRolesCode() {
    return ParticipantRolesCodes[Math.floor(Math.random() * ParticipantRolesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomParticipantRolesConcept() {
    return ParticipantRolesConcepts[Math.floor(Math.random() * ParticipantRolesConcepts.length)];
}
