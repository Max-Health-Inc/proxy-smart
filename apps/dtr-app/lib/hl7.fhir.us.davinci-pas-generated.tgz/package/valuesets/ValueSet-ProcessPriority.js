/**
 * ValueSet: process-priority
 * URL: http://hl7.org/fhir/ValueSet/process-priority
 * Size: 3 concepts
 */
export const ProcessPriorityConcepts = [
    { code: "stat", system: "http://terminology.hl7.org/CodeSystem/processpriority" },
    { code: "normal", system: "http://terminology.hl7.org/CodeSystem/processpriority" },
    { code: "deferred", system: "http://terminology.hl7.org/CodeSystem/processpriority" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidProcessPriorityCode(code) {
    return ProcessPriorityConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getProcessPriorityConcept(code) {
    return ProcessPriorityConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ProcessPriorityCodes = ProcessPriorityConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomProcessPriorityCode() {
    return ProcessPriorityCodes[Math.floor(Math.random() * ProcessPriorityCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomProcessPriorityConcept() {
    return ProcessPriorityConcepts[Math.floor(Math.random() * ProcessPriorityConcepts.length)];
}
