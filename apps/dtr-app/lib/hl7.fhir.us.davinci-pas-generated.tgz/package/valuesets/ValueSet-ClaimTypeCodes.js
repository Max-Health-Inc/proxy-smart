/**
 * ValueSet: ClaimTypeCodes
 * URL: http://hl7.org/fhir/ValueSet/claim-type
 * Size: 5 concepts
 */
export const ClaimTypeCodesConcepts = [
    { code: "institutional", system: "http://terminology.hl7.org/CodeSystem/claim-type", display: "Institutional" },
    { code: "oral", system: "http://terminology.hl7.org/CodeSystem/claim-type", display: "Oral" },
    { code: "pharmacy", system: "http://terminology.hl7.org/CodeSystem/claim-type", display: "Pharmacy" },
    { code: "professional", system: "http://terminology.hl7.org/CodeSystem/claim-type", display: "Professional" },
    { code: "vision", system: "http://terminology.hl7.org/CodeSystem/claim-type", display: "Vision" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidClaimTypeCodesCode(code) {
    return ClaimTypeCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getClaimTypeCodesConcept(code) {
    return ClaimTypeCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ClaimTypeCodesCodes = ClaimTypeCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomClaimTypeCodesCode() {
    return ClaimTypeCodesCodes[Math.floor(Math.random() * ClaimTypeCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomClaimTypeCodesConcept() {
    return ClaimTypeCodesConcepts[Math.floor(Math.random() * ClaimTypeCodesConcepts.length)];
}
