/**
 * ValueSet: ClaimInformationCategoryCodes
 * URL: http://hl7.org/fhir/ValueSet/claim-informationcategory
 * Size: 14 concepts
 */
export declare const ClaimInformationCategoryCodesConcepts: readonly [{
    readonly code: "info";
    readonly system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory";
    readonly display: "Information";
}, {
    readonly code: "discharge";
    readonly system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory";
    readonly display: "Discharge";
}, {
    readonly code: "onset";
    readonly system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory";
    readonly display: "Onset";
}, {
    readonly code: "related";
    readonly system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory";
    readonly display: "Related Services";
}, {
    readonly code: "exception";
    readonly system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory";
    readonly display: "Exception";
}, {
    readonly code: "material";
    readonly system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory";
    readonly display: "Materials Forwarded";
}, {
    readonly code: "attachment";
    readonly system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory";
    readonly display: "Attachment";
}, {
    readonly code: "missingtooth";
    readonly system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory";
    readonly display: "Missing Tooth";
}, {
    readonly code: "prosthesis";
    readonly system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory";
    readonly display: "Prosthesis";
}, {
    readonly code: "other";
    readonly system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory";
    readonly display: "Other";
}, {
    readonly code: "hospitalized";
    readonly system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory";
    readonly display: "Hospitalized";
}, {
    readonly code: "employmentimpacted";
    readonly system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory";
    readonly display: "EmploymentImpacted";
}, {
    readonly code: "externalcause";
    readonly system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory";
    readonly display: "External Caause";
}, {
    readonly code: "patientreasonforvisit";
    readonly system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory";
    readonly display: "Patient Reason for Visit";
}];
/** Union type of all valid codes in this ValueSet */
export type ClaimInformationCategoryCodesCode = "info" | "discharge" | "onset" | "related" | "exception" | "material" | "attachment" | "missingtooth" | "prosthesis" | "other" | "hospitalized" | "employmentimpacted" | "externalcause" | "patientreasonforvisit";
/** Type representing a concept from this ValueSet */
export type ClaimInformationCategoryCodesConcept = typeof ClaimInformationCategoryCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidClaimInformationCategoryCodesCode(code: string): code is ClaimInformationCategoryCodesCode;
/**
 * Get concept details by code
 */
export declare function getClaimInformationCategoryCodesConcept(code: string): ClaimInformationCategoryCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ClaimInformationCategoryCodesCodes: ("other" | "patientreasonforvisit" | "related" | "info" | "discharge" | "onset" | "exception" | "material" | "attachment" | "missingtooth" | "prosthesis" | "hospitalized" | "employmentimpacted" | "externalcause")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomClaimInformationCategoryCodesCode(): ClaimInformationCategoryCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomClaimInformationCategoryCodesConcept(): ClaimInformationCategoryCodesConcept;
