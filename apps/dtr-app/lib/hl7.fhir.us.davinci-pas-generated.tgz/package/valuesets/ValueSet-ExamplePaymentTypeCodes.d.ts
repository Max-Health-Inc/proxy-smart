/**
 * ValueSet: ExamplePaymentTypeCodes
 * URL: http://hl7.org/fhir/ValueSet/ex-paymenttype
 * Size: 2 concepts
 */
export declare const ExamplePaymentTypeCodesConcepts: readonly [{
    readonly code: "complete";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-paymenttype";
    readonly display: "Complete";
}, {
    readonly code: "partial";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-paymenttype";
    readonly display: "Partial";
}];
/** Union type of all valid codes in this ValueSet */
export type ExamplePaymentTypeCodesCode = "complete" | "partial";
/** Type representing a concept from this ValueSet */
export type ExamplePaymentTypeCodesConcept = typeof ExamplePaymentTypeCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidExamplePaymentTypeCodesCode(code: string): code is ExamplePaymentTypeCodesCode;
/**
 * Get concept details by code
 */
export declare function getExamplePaymentTypeCodesConcept(code: string): ExamplePaymentTypeCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ExamplePaymentTypeCodesCodes: ("complete" | "partial")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomExamplePaymentTypeCodesCode(): ExamplePaymentTypeCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomExamplePaymentTypeCodesConcept(): ExamplePaymentTypeCodesConcept;
