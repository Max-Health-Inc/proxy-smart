/**
 * ValueSet: operation-outcome
 * URL: http://hl7.org/fhir/ValueSet/operation-outcome
 * Size: 50 concepts
 */
export const OperationOutcomeConcepts = [
    { code: "DELETE_MULTIPLE_MATCHES", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_AUTH_REQUIRED", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_BAD_FORMAT", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_BAD_SYNTAX", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_CANT_PARSE_CONTENT", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_CANT_PARSE_ROOT", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_CREATED", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_DATE_FORMAT", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_DELETED", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_DELETED_DONE", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_DELETED_ID", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_DUPLICATE_ID", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_ERROR_PARSING", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_ID_INVALID", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_ID_TOO_LONG", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_INVALID_ID", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_JSON_OBJECT", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_LOCAL_FAIL", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_NO_EXIST", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_NO_MATCH", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_NO_MODULE", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_NO_SUMMARY", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_OP_NOT_ALLOWED", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_PARAM_CHAINED", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_PARAM_INVALID", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_PARAM_MODIFIER_INVALID", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_PARAM_NO_REPEAT", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_PARAM_UNKNOWN", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_RESOURCE_EXAMPLE_PROTECTED", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_RESOURCE_ID_FAIL", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_RESOURCE_ID_MISMATCH", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_RESOURCE_ID_MISSING", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_RESOURCE_NOT_ALLOWED", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_RESOURCE_REQUIRED", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_RESOURCE_TYPE_MISMATCH", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_SORT_UNKNOWN", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_TRANSACTION_DUPLICATE_ID", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_TRANSACTION_MISSING_ID", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_UNHANDLED_NODE_TYPE", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_UNKNOWN_CONTENT", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_UNKNOWN_OPERATION", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_UNKNOWN_TYPE", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_UPDATED", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_VERSION_AWARE", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_VERSION_AWARE_CONFLICT", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_VERSION_AWARE_URL", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "MSG_WRONG_NS", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "SEARCH_MULTIPLE", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "SEARCH_NONE", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
    { code: "UPDATE_MULTIPLE_MATCHES", system: "http://terminology.hl7.org/CodeSystem/operation-outcome" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidOperationOutcomeCode(code) {
    return OperationOutcomeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getOperationOutcomeConcept(code) {
    return OperationOutcomeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const OperationOutcomeCodes = OperationOutcomeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomOperationOutcomeCode() {
    return OperationOutcomeCodes[Math.floor(Math.random() * OperationOutcomeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomOperationOutcomeConcept() {
    return OperationOutcomeConcepts[Math.floor(Math.random() * OperationOutcomeConcepts.length)];
}
