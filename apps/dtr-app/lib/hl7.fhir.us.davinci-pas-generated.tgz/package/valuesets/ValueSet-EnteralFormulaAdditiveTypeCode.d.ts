/**
 * ValueSet: EnteralFormulaAdditiveTypeCode
 * URL: http://hl7.org/fhir/ValueSet/entformula-additive
 * Size: 5 concepts
 */
export declare const EnteralFormulaAdditiveTypeCodeConcepts: readonly [{
    readonly code: "lipid";
    readonly system: "http://terminology.hl7.org/CodeSystem/entformula-additive";
    readonly display: "Lipid";
}, {
    readonly code: "protein";
    readonly system: "http://terminology.hl7.org/CodeSystem/entformula-additive";
    readonly display: "Protein";
}, {
    readonly code: "carbohydrate";
    readonly system: "http://terminology.hl7.org/CodeSystem/entformula-additive";
    readonly display: "Carbohydrate";
}, {
    readonly code: "fiber";
    readonly system: "http://terminology.hl7.org/CodeSystem/entformula-additive";
    readonly display: "Fiber";
}, {
    readonly code: "water";
    readonly system: "http://terminology.hl7.org/CodeSystem/entformula-additive";
    readonly display: "Water";
}];
/** Union type of all valid codes in this ValueSet */
export type EnteralFormulaAdditiveTypeCodeCode = "lipid" | "protein" | "carbohydrate" | "fiber" | "water";
/** Type representing a concept from this ValueSet */
export type EnteralFormulaAdditiveTypeCodeConcept = typeof EnteralFormulaAdditiveTypeCodeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidEnteralFormulaAdditiveTypeCodeCode(code: string): code is EnteralFormulaAdditiveTypeCodeCode;
/**
 * Get concept details by code
 */
export declare function getEnteralFormulaAdditiveTypeCodeConcept(code: string): EnteralFormulaAdditiveTypeCodeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const EnteralFormulaAdditiveTypeCodeCodes: ("lipid" | "protein" | "carbohydrate" | "fiber" | "water")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomEnteralFormulaAdditiveTypeCodeCode(): EnteralFormulaAdditiveTypeCodeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomEnteralFormulaAdditiveTypeCodeConcept(): EnteralFormulaAdditiveTypeCodeConcept;
