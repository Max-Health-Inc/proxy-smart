/**
 * ValueSet: ex-diagnosis-on-admission
 * URL: http://hl7.org/fhir/ValueSet/ex-diagnosis-on-admission
 * Size: 4 concepts
 */
export declare const ExDiagnosisOnAdmissionConcepts: readonly [{
    readonly code: "y";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-diagnosis-on-admission";
}, {
    readonly code: "n";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-diagnosis-on-admission";
}, {
    readonly code: "u";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-diagnosis-on-admission";
}, {
    readonly code: "w";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-diagnosis-on-admission";
}];
/** Union type of all valid codes in this ValueSet */
export type ExDiagnosisOnAdmissionCode = "y" | "n" | "u" | "w";
/** Type representing a concept from this ValueSet */
export type ExDiagnosisOnAdmissionConcept = typeof ExDiagnosisOnAdmissionConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidExDiagnosisOnAdmissionCode(code: string): code is ExDiagnosisOnAdmissionCode;
/**
 * Get concept details by code
 */
export declare function getExDiagnosisOnAdmissionConcept(code: string): ExDiagnosisOnAdmissionConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ExDiagnosisOnAdmissionCodes: ("u" | "w" | "y" | "n")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomExDiagnosisOnAdmissionCode(): ExDiagnosisOnAdmissionCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomExDiagnosisOnAdmissionConcept(): ExDiagnosisOnAdmissionConcept;
