/**
 * ValueSet: ex-program-code
 * URL: http://hl7.org/fhir/ValueSet/ex-program-code
 * Size: 4 concepts
 */
export const ExProgramCodeConcepts = [
    { code: "as", system: "http://terminology.hl7.org/CodeSystem/ex-programcode" },
    { code: "hd", system: "http://terminology.hl7.org/CodeSystem/ex-programcode" },
    { code: "auscr", system: "http://terminology.hl7.org/CodeSystem/ex-programcode" },
    { code: "none", system: "http://terminology.hl7.org/CodeSystem/ex-programcode" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidExProgramCodeCode(code) {
    return ExProgramCodeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getExProgramCodeConcept(code) {
    return ExProgramCodeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ExProgramCodeCodes = ExProgramCodeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomExProgramCodeCode() {
    return ExProgramCodeCodes[Math.floor(Math.random() * ExProgramCodeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomExProgramCodeConcept() {
    return ExProgramCodeConcepts[Math.floor(Math.random() * ExProgramCodeConcepts.length)];
}
