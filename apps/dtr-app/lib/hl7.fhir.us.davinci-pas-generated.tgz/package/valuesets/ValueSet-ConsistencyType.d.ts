/**
 * ValueSet: consistency-type
 * URL: http://hl7.org/fhir/ValueSet/consistency-type
 * Size: 4 concepts
 */
export declare const ConsistencyTypeConcepts: readonly [{
    readonly code: "439031000124108";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "439021000124105";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "439041000124103";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "439081000124109";
    readonly system: "http://snomed.info/sct";
}];
/** Union type of all valid codes in this ValueSet */
export type ConsistencyTypeCode = "439031000124108" | "439021000124105" | "439041000124103" | "439081000124109";
/** Type representing a concept from this ValueSet */
export type ConsistencyTypeConcept = typeof ConsistencyTypeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidConsistencyTypeCode(code: string): code is ConsistencyTypeCode;
/**
 * Get concept details by code
 */
export declare function getConsistencyTypeConcept(code: string): ConsistencyTypeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ConsistencyTypeCodes: ("439021000124105" | "439031000124108" | "439041000124103" | "439081000124109")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomConsistencyTypeCode(): ConsistencyTypeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomConsistencyTypeConcept(): ConsistencyTypeConcept;
