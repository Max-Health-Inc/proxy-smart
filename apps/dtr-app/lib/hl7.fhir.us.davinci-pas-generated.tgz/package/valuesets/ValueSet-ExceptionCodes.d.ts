/**
 * ValueSet: ExceptionCodes
 * URL: http://hl7.org/fhir/ValueSet/claim-exception
 * Size: 2 concepts
 */
export declare const ExceptionCodesConcepts: readonly [{
    readonly code: "student";
    readonly system: "http://terminology.hl7.org/CodeSystem/claim-exception";
    readonly display: "Student (Fulltime)";
}, {
    readonly code: "disabled";
    readonly system: "http://terminology.hl7.org/CodeSystem/claim-exception";
    readonly display: "Disabled";
}];
/** Union type of all valid codes in this ValueSet */
export type ExceptionCodesCode = "student" | "disabled";
/** Type representing a concept from this ValueSet */
export type ExceptionCodesConcept = typeof ExceptionCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidExceptionCodesCode(code: string): code is ExceptionCodesCode;
/**
 * Get concept details by code
 */
export declare function getExceptionCodesConcept(code: string): ExceptionCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ExceptionCodesCodes: ("student" | "disabled")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomExceptionCodesCode(): ExceptionCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomExceptionCodesConcept(): ExceptionCodesConcept;
