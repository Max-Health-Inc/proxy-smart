/**
 * ValueSet: claim-modifiers
 * URL: http://hl7.org/fhir/ValueSet/claim-modifiers
 * Size: 6 concepts
 */
export const ClaimModifiersConcepts = [
    { code: "a", system: "http://terminology.hl7.org/CodeSystem/modifiers" },
    { code: "b", system: "http://terminology.hl7.org/CodeSystem/modifiers" },
    { code: "c", system: "http://terminology.hl7.org/CodeSystem/modifiers" },
    { code: "e", system: "http://terminology.hl7.org/CodeSystem/modifiers" },
    { code: "rooh", system: "http://terminology.hl7.org/CodeSystem/modifiers" },
    { code: "x", system: "http://terminology.hl7.org/CodeSystem/modifiers" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidClaimModifiersCode(code) {
    return ClaimModifiersConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getClaimModifiersConcept(code) {
    return ClaimModifiersConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ClaimModifiersCodes = ClaimModifiersConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomClaimModifiersCode() {
    return ClaimModifiersCodes[Math.floor(Math.random() * ClaimModifiersCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomClaimModifiersConcept() {
    return ClaimModifiersConcepts[Math.floor(Math.random() * ClaimModifiersConcepts.length)];
}
