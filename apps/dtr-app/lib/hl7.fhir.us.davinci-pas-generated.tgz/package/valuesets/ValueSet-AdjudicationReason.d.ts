/**
 * ValueSet: adjudication-reason
 * URL: http://hl7.org/fhir/ValueSet/adjudication-reason
 * Size: 2 concepts
 */
export declare const AdjudicationReasonConcepts: readonly [{
    readonly code: "ar001";
    readonly system: "http://terminology.hl7.org/CodeSystem/adjudication-reason";
}, {
    readonly code: "ar002";
    readonly system: "http://terminology.hl7.org/CodeSystem/adjudication-reason";
}];
/** Union type of all valid codes in this ValueSet */
export type AdjudicationReasonCode = "ar001" | "ar002";
/** Type representing a concept from this ValueSet */
export type AdjudicationReasonConcept = typeof AdjudicationReasonConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidAdjudicationReasonCode(code: string): code is AdjudicationReasonCode;
/**
 * Get concept details by code
 */
export declare function getAdjudicationReasonConcept(code: string): AdjudicationReasonConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const AdjudicationReasonCodes: ("ar001" | "ar002")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomAdjudicationReasonCode(): AdjudicationReasonCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomAdjudicationReasonConcept(): AdjudicationReasonConcept;
