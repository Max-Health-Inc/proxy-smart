/**
 * ValueSet: CoverageClassCodes
 * URL: http://hl7.org/fhir/ValueSet/coverage-class
 * Size: 11 concepts
 */
export const CoverageClassCodesConcepts = [
    { code: "group", system: "http://terminology.hl7.org/CodeSystem/coverage-class", display: "Group" },
    { code: "subgroup", system: "http://terminology.hl7.org/CodeSystem/coverage-class", display: "SubGroup" },
    { code: "plan", system: "http://terminology.hl7.org/CodeSystem/coverage-class", display: "Plan" },
    { code: "subplan", system: "http://terminology.hl7.org/CodeSystem/coverage-class", display: "SubPlan" },
    { code: "class", system: "http://terminology.hl7.org/CodeSystem/coverage-class", display: "Class" },
    { code: "subclass", system: "http://terminology.hl7.org/CodeSystem/coverage-class", display: "SubClass" },
    { code: "sequence", system: "http://terminology.hl7.org/CodeSystem/coverage-class", display: "Sequence" },
    { code: "rxbin", system: "http://terminology.hl7.org/CodeSystem/coverage-class", display: "RX BIN" },
    { code: "rxpcn", system: "http://terminology.hl7.org/CodeSystem/coverage-class", display: "RX PCN" },
    { code: "rxid", system: "http://terminology.hl7.org/CodeSystem/coverage-class", display: "RX Id" },
    { code: "rxgroup", system: "http://terminology.hl7.org/CodeSystem/coverage-class", display: "RX Group" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidCoverageClassCodesCode(code) {
    return CoverageClassCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getCoverageClassCodesConcept(code) {
    return CoverageClassCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const CoverageClassCodesCodes = CoverageClassCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomCoverageClassCodesCode() {
    return CoverageClassCodesCodes[Math.floor(Math.random() * CoverageClassCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomCoverageClassCodesConcept() {
    return CoverageClassCodesConcepts[Math.floor(Math.random() * CoverageClassCodesConcepts.length)];
}
