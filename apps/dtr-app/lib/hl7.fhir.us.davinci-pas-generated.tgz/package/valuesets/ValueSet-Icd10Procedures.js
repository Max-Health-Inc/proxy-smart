/**
 * ValueSet: icd-10-procedures
 * URL: http://hl7.org/fhir/ValueSet/icd-10-procedures
 * Size: 3 concepts
 */
export const Icd10ProceduresConcepts = [
    { code: "123001", system: "http://hl7.org/fhir/sid/ex-icd-10-procedures" },
    { code: "123002", system: "http://hl7.org/fhir/sid/ex-icd-10-procedures" },
    { code: "123003", system: "http://hl7.org/fhir/sid/ex-icd-10-procedures" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidIcd10ProceduresCode(code) {
    return Icd10ProceduresConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getIcd10ProceduresConcept(code) {
    return Icd10ProceduresConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const Icd10ProceduresCodes = Icd10ProceduresConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomIcd10ProceduresCode() {
    return Icd10ProceduresCodes[Math.floor(Math.random() * Icd10ProceduresCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomIcd10ProceduresConcept() {
    return Icd10ProceduresConcepts[Math.floor(Math.random() * Icd10ProceduresConcepts.length)];
}
