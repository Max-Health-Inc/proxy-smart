/**
 * ValueSet: identifier-use
 * URL: http://hl7.org/fhir/ValueSet/identifier-use
 * Size: 5 concepts
 */
export declare const IdentifierUseConcepts: readonly [{
    readonly code: "usual";
    readonly system: "http://hl7.org/fhir/identifier-use";
}, {
    readonly code: "official";
    readonly system: "http://hl7.org/fhir/identifier-use";
}, {
    readonly code: "temp";
    readonly system: "http://hl7.org/fhir/identifier-use";
}, {
    readonly code: "secondary";
    readonly system: "http://hl7.org/fhir/identifier-use";
}, {
    readonly code: "old";
    readonly system: "http://hl7.org/fhir/identifier-use";
}];
/** Union type of all valid codes in this ValueSet */
export type IdentifierUseCode = "usual" | "official" | "temp" | "secondary" | "old";
/** Type representing a concept from this ValueSet */
export type IdentifierUseConcept = typeof IdentifierUseConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidIdentifierUseCode(code: string): code is IdentifierUseCode;
/**
 * Get concept details by code
 */
export declare function getIdentifierUseConcept(code: string): IdentifierUseConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const IdentifierUseCodes: ("temp" | "old" | "usual" | "official" | "secondary")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomIdentifierUseCode(): IdentifierUseCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomIdentifierUseConcept(): IdentifierUseConcept;
