/**
 * ValueSet: PASCommunicationRequestMedium
 * URL: http://hl7.org/fhir/us/davinci-pas/ValueSet/PASCommunicationRequestMedium
 * Size: 1 concepts
 */
export declare const PASCommunicationRequestMediumConcepts: readonly [{
    readonly code: "CDEX";
    readonly system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes";
}];
/** Union type of all valid codes in this ValueSet */
export type PASCommunicationRequestMediumCode = "CDEX";
/** Type representing a concept from this ValueSet */
export type PASCommunicationRequestMediumConcept = typeof PASCommunicationRequestMediumConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidPASCommunicationRequestMediumCode(code: string): code is PASCommunicationRequestMediumCode;
/**
 * Get concept details by code
 */
export declare function getPASCommunicationRequestMediumConcept(code: string): PASCommunicationRequestMediumConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const PASCommunicationRequestMediumCodes: "CDEX"[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomPASCommunicationRequestMediumCode(): PASCommunicationRequestMediumCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomPASCommunicationRequestMediumConcept(): PASCommunicationRequestMediumConcept;
