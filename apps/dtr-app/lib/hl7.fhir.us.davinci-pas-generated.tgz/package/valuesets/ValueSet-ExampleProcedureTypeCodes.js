/**
 * ValueSet: ExampleProcedureTypeCodes
 * URL: http://hl7.org/fhir/ValueSet/ex-procedure-type
 * Size: 2 concepts
 */
export const ExampleProcedureTypeCodesConcepts = [
    { code: "primary", system: "http://terminology.hl7.org/CodeSystem/ex-procedure-type", display: "Primary procedure" },
    { code: "secondary", system: "http://terminology.hl7.org/CodeSystem/ex-procedure-type", display: "Secondary procedure" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidExampleProcedureTypeCodesCode(code) {
    return ExampleProcedureTypeCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getExampleProcedureTypeCodesConcept(code) {
    return ExampleProcedureTypeCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ExampleProcedureTypeCodesCodes = ExampleProcedureTypeCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomExampleProcedureTypeCodesCode() {
    return ExampleProcedureTypeCodesCodes[Math.floor(Math.random() * ExampleProcedureTypeCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomExampleProcedureTypeCodesConcept() {
    return ExampleProcedureTypeCodesConcepts[Math.floor(Math.random() * ExampleProcedureTypeCodesConcepts.length)];
}
