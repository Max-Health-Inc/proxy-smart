/**
 * ValueSet: coverage-class
 * URL: http://hl7.org/fhir/ValueSet/coverage-class
 * Size: 11 concepts
 */
export const CoverageClassConcepts = [
    { code: "group", system: "http://terminology.hl7.org/CodeSystem/coverage-class" },
    { code: "subgroup", system: "http://terminology.hl7.org/CodeSystem/coverage-class" },
    { code: "plan", system: "http://terminology.hl7.org/CodeSystem/coverage-class" },
    { code: "subplan", system: "http://terminology.hl7.org/CodeSystem/coverage-class" },
    { code: "class", system: "http://terminology.hl7.org/CodeSystem/coverage-class" },
    { code: "subclass", system: "http://terminology.hl7.org/CodeSystem/coverage-class" },
    { code: "sequence", system: "http://terminology.hl7.org/CodeSystem/coverage-class" },
    { code: "rxbin", system: "http://terminology.hl7.org/CodeSystem/coverage-class" },
    { code: "rxpcn", system: "http://terminology.hl7.org/CodeSystem/coverage-class" },
    { code: "rxid", system: "http://terminology.hl7.org/CodeSystem/coverage-class" },
    { code: "rxgroup", system: "http://terminology.hl7.org/CodeSystem/coverage-class" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidCoverageClassCode(code) {
    return CoverageClassConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getCoverageClassConcept(code) {
    return CoverageClassConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const CoverageClassCodes = CoverageClassConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomCoverageClassCode() {
    return CoverageClassCodes[Math.floor(Math.random() * CoverageClassCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomCoverageClassConcept() {
    return CoverageClassConcepts[Math.floor(Math.random() * CoverageClassConcepts.length)];
}
