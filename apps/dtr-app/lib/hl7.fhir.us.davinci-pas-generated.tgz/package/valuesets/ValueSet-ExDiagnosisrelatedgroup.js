/**
 * ValueSet: ex-diagnosisrelatedgroup
 * URL: http://hl7.org/fhir/ValueSet/ex-diagnosisrelatedgroup
 * Size: 4 concepts
 */
export const ExDiagnosisrelatedgroupConcepts = [
    { code: "100", system: "http://terminology.hl7.org/CodeSystem/ex-diagnosisrelatedgroup" },
    { code: "101", system: "http://terminology.hl7.org/CodeSystem/ex-diagnosisrelatedgroup" },
    { code: "300", system: "http://terminology.hl7.org/CodeSystem/ex-diagnosisrelatedgroup" },
    { code: "400", system: "http://terminology.hl7.org/CodeSystem/ex-diagnosisrelatedgroup" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidExDiagnosisrelatedgroupCode(code) {
    return ExDiagnosisrelatedgroupConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getExDiagnosisrelatedgroupConcept(code) {
    return ExDiagnosisrelatedgroupConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ExDiagnosisrelatedgroupCodes = ExDiagnosisrelatedgroupConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomExDiagnosisrelatedgroupCode() {
    return ExDiagnosisrelatedgroupCodes[Math.floor(Math.random() * ExDiagnosisrelatedgroupCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomExDiagnosisrelatedgroupConcept() {
    return ExDiagnosisrelatedgroupConcepts[Math.floor(Math.random() * ExDiagnosisrelatedgroupConcepts.length)];
}
