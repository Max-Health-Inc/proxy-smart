/**
 * ValueSet Registry
 * Central registry of all loaded ValueSets with explicit codes
 */
import * as AddressType from './ValueSet-AddressType.js';
import * as AddressUse from './ValueSet-AddressUse.js';
import * as AdministrativeGender from './ValueSet-AdministrativeGender.js';
import * as BodySite from './ValueSet-BodySite.js';
import * as BundleType from './ValueSet-BundleType.js';
import * as ConditionCode from './ValueSet-ConditionCode.js';
import * as ContactPointSystem from './ValueSet-ContactPointSystem.js';
import * as ContactPointUse from './ValueSet-ContactPointUse.js';
import * as DaysOfWeek from './ValueSet-DaysOfWeek.js';
import * as EncounterStatus from './ValueSet-EncounterStatus.js';
import * as FmStatus from './ValueSet-FmStatus.js';
import * as HrexTaskStatus from './ValueSet-HrexTaskStatus.js';
import * as HttpVerb from './ValueSet-HttpVerb.js';
import * as IdentifierUse from './ValueSet-IdentifierUse.js';
import * as LinkType from './ValueSet-LinkType.js';
import * as MedicationrequestStatus from './ValueSet-MedicationrequestStatus.js';
import * as MetricDataSource from './ValueSet-MetricDataSource.js';
import * as NameUse from './ValueSet-NameUse.js';
import * as PASCommunicationRequestMedium from './ValueSet-PASCommunicationRequestMedium.js';
import * as PASInformationChangeMode from './ValueSet-PASInformationChangeMode.js';
import * as PASSupportingInfoType from './ValueSet-PASSupportingInfoType.js';
import * as PASTaskCodes from './ValueSet-PASTaskCodes.js';
import * as RequestIntent from './ValueSet-RequestIntent.js';
import * as RequestPriority from './ValueSet-RequestPriority.js';
import * as RequestStatus from './ValueSet-RequestStatus.js';
import * as UsCoreUspsState from './ValueSet-UsCoreUspsState.js';
import * as V20092 from './ValueSet-V20092.js';
import * as V20116 from './ValueSet-V20116.js';
import * as V3ActPriority from './ValueSet-V3ActPriority.js';
import * as V3ActReason from './ValueSet-V3ActReason.js';
import * as X12278DiagnosisType from './ValueSet-X12278DiagnosisType.js';
import * as X12278RequestedServiceType from './ValueSet-X12278RequestedServiceType.js';
export const ValueSetRegistry = {
    AddressType,
    AddressUse,
    AdministrativeGender,
    BodySite,
    BundleType,
    ConditionCode,
    ContactPointSystem,
    ContactPointUse,
    DaysOfWeek,
    EncounterStatus,
    FmStatus,
    HrexTaskStatus,
    HttpVerb,
    IdentifierUse,
    LinkType,
    MedicationrequestStatus,
    MetricDataSource,
    NameUse,
    PASCommunicationRequestMedium,
    PASInformationChangeMode,
    PASSupportingInfoType,
    PASTaskCodes,
    RequestIntent,
    RequestPriority,
    RequestStatus,
    UsCoreUspsState,
    V20092,
    V20116,
    V3ActPriority,
    V3ActReason,
    X12278DiagnosisType,
    X12278RequestedServiceType,
};
export function getValueSet(name) {
    return ValueSetRegistry[name];
}
/** Map from ValueSet URL to registry name */
export const ValueSetUrlMap = {
    'http://hl7.org/fhir/ValueSet/address-type': 'AddressType',
    'http://hl7.org/fhir/ValueSet/address-use': 'AddressUse',
    'http://hl7.org/fhir/ValueSet/administrative-gender': 'AdministrativeGender',
    'http://hl7.org/fhir/ValueSet/body-site': 'BodySite',
    'http://hl7.org/fhir/ValueSet/bundle-type': 'BundleType',
    'http://hl7.org/fhir/ValueSet/condition-code': 'ConditionCode',
    'http://hl7.org/fhir/ValueSet/contact-point-system': 'ContactPointSystem',
    'http://hl7.org/fhir/ValueSet/contact-point-use': 'ContactPointUse',
    'http://hl7.org/fhir/ValueSet/days-of-week': 'DaysOfWeek',
    'http://hl7.org/fhir/ValueSet/encounter-status': 'EncounterStatus',
    'http://hl7.org/fhir/ValueSet/fm-status': 'FmStatus',
    'http://hl7.org/fhir/us/davinci-hrex/ValueSet/hrex-task-status': 'HrexTaskStatus',
    'http://hl7.org/fhir/ValueSet/http-verb': 'HttpVerb',
    'http://hl7.org/fhir/ValueSet/identifier-use': 'IdentifierUse',
    'http://hl7.org/fhir/ValueSet/link-type': 'LinkType',
    'http://hl7.org/fhir/ValueSet/medicationrequest-status': 'MedicationrequestStatus',
    'http://hl7.org/fhir/us/davinci-pas/ValueSet/MetricDataSource': 'MetricDataSource',
    'http://hl7.org/fhir/ValueSet/name-use': 'NameUse',
    'http://hl7.org/fhir/us/davinci-pas/ValueSet/PASCommunicationRequestMedium': 'PASCommunicationRequestMedium',
    'http://hl7.org/fhir/us/davinci-pas/ValueSet/PASInformationChangeMode': 'PASInformationChangeMode',
    'http://hl7.org/fhir/us/davinci-pas/ValueSet/PASSupportingInfoType': 'PASSupportingInfoType',
    'http://hl7.org/fhir/us/davinci-pas/ValueSet/PASTaskCodes': 'PASTaskCodes',
    'http://hl7.org/fhir/ValueSet/request-intent': 'RequestIntent',
    'http://hl7.org/fhir/ValueSet/request-priority': 'RequestPriority',
    'http://hl7.org/fhir/ValueSet/request-status': 'RequestStatus',
    'http://hl7.org/fhir/us/core/ValueSet/us-core-usps-state': 'UsCoreUspsState',
    'http://terminology.hl7.org/ValueSet/v2-0092': 'V20092',
    'http://terminology.hl7.org/ValueSet/v2-0116': 'V20116',
    'http://terminology.hl7.org/ValueSet/v3-ActPriority': 'V3ActPriority',
    'http://terminology.hl7.org/ValueSet/v3-ActReason': 'V3ActReason',
    'http://hl7.org/fhir/us/davinci-pas/ValueSet/X12278DiagnosisType': 'X12278DiagnosisType',
    'http://hl7.org/fhir/us/davinci-pas/ValueSet/X12278RequestedServiceType': 'X12278RequestedServiceType',
};
function stripVersionFromUrl(url) {
    const pipeIndex = url.indexOf('|');
    return pipeIndex >= 0 ? url.substring(0, pipeIndex) : url;
}
/**
 * Get a random code from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A random code string, or undefined if ValueSet not found
 */
export function getRandomCodeByUrl(url) {
    const cleanUrl = stripVersionFromUrl(url);
    const name = ValueSetUrlMap[cleanUrl];
    if (!name)
        return undefined;
    const vs = ValueSetRegistry[name];
    // Each ValueSet exports random<Name>Code() function
    const randomFn = vs['random' + name + 'Code'];
    return randomFn?.();
}
/**
 * Get a random concept (code, system, display) from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A concept object with code, system, and optional display, or undefined if ValueSet not found
 */
export function getRandomConceptByUrl(url) {
    const cleanUrl = stripVersionFromUrl(url);
    const name = ValueSetUrlMap[cleanUrl];
    if (!name)
        return undefined;
    const vs = ValueSetRegistry[name];
    // Each ValueSet exports random<Name>Concept() function
    const randomFn = vs['random' + name + 'Concept'];
    return randomFn?.();
}
