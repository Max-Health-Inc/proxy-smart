/**
 * ValueSet Registry
 * Central registry of all loaded ValueSets with explicit codes
 */
import * as AddressType from './ValueSet-AddressType.js';
import * as AddressUse from './ValueSet-AddressUse.js';
import * as AdjudicationReasonCodes from './ValueSet-AdjudicationReasonCodes.js';
import * as AdjudicationValueCodes from './ValueSet-AdjudicationValueCodes.js';
import * as AdministrativeGender from './ValueSet-AdministrativeGender.js';
import * as BenefitCategoryCodes from './ValueSet-BenefitCategoryCodes.js';
import * as BodySite from './ValueSet-BodySite.js';
import * as BundleType from './ValueSet-BundleType.js';
import * as ClaimCareTeamRoleCodes from './ValueSet-ClaimCareTeamRoleCodes.js';
import * as ClaimInformationCategoryCodes from './ValueSet-ClaimInformationCategoryCodes.js';
import * as ClaimPayeeTypeCodes from './ValueSet-ClaimPayeeTypeCodes.js';
import * as ClaimProcessingCodes from './ValueSet-ClaimProcessingCodes.js';
import * as ClaimTypeCodes from './ValueSet-ClaimTypeCodes.js';
import * as CommonLanguages from './ValueSet-CommonLanguages.js';
import * as ConditionCode from './ValueSet-ConditionCode.js';
import * as ContactEntityType from './ValueSet-ContactEntityType.js';
import * as ContactPointSystem from './ValueSet-ContactPointSystem.js';
import * as ContactPointUse from './ValueSet-ContactPointUse.js';
import * as CoverageClassCodes from './ValueSet-CoverageClassCodes.js';
import * as CoverageCopayTypeCodes from './ValueSet-CoverageCopayTypeCodes.js';
import * as CoverageTypeAndSelfPayCodes from './ValueSet-CoverageTypeAndSelfPayCodes.js';
import * as DaysOfWeek from './ValueSet-DaysOfWeek.js';
import * as DiagnosisRole from './ValueSet-DiagnosisRole.js';
import * as Diet from './ValueSet-Diet.js';
import * as DischargeDisposition from './ValueSet-DischargeDisposition.js';
import * as DoseAndRateType from './ValueSet-DoseAndRateType.js';
import * as EncounterLocationStatus from './ValueSet-EncounterLocationStatus.js';
import * as EncounterReasonCodes from './ValueSet-EncounterReasonCodes.js';
import * as EncounterStatus from './ValueSet-EncounterStatus.js';
import * as EnteralFormulaAdditiveTypeCode from './ValueSet-EnteralFormulaAdditiveTypeCode.js';
import * as EnteralRouteCodes from './ValueSet-EnteralRouteCodes.js';
import * as EventTiming from './ValueSet-EventTiming.js';
import * as ExampleClaimSubTypeCodes from './ValueSet-ExampleClaimSubTypeCodes.js';
import * as ExampleCoverageFinancialExceptionCodes from './ValueSet-ExampleCoverageFinancialExceptionCodes.js';
import * as ExampleDiagnosisOnAdmissionCodes from './ValueSet-ExampleDiagnosisOnAdmissionCodes.js';
import * as ExampleDiagnosisRelatedGroupCodes from './ValueSet-ExampleDiagnosisRelatedGroupCodes.js';
import * as ExamplePaymentTypeCodes from './ValueSet-ExamplePaymentTypeCodes.js';
import * as ExampleProcedureTypeCodes from './ValueSet-ExampleProcedureTypeCodes.js';
import * as ExampleProgramReasonCodes from './ValueSet-ExampleProgramReasonCodes.js';
import * as ExampleProviderQualificationCodes from './ValueSet-ExampleProviderQualificationCodes.js';
import * as ExampleRelatedClaimRelationshipCodes from './ValueSet-ExampleRelatedClaimRelationshipCodes.js';
import * as ExampleRevenueCenterCodes from './ValueSet-ExampleRevenueCenterCodes.js';
import * as ExampleServicePlaceCodes from './ValueSet-ExampleServicePlaceCodes.js';
import * as ExceptionCodes from './ValueSet-ExceptionCodes.js';
import * as FluidConsistencyTypeCodes from './ValueSet-FluidConsistencyTypeCodes.js';
import * as FmStatus from './ValueSet-FmStatus.js';
import * as FoodTypeCodes from './ValueSet-FoodTypeCodes.js';
import * as FormCodes from './ValueSet-FormCodes.js';
import * as FundsReservationCodes from './ValueSet-FundsReservationCodes.js';
import * as HrexTaskStatus from './ValueSet-HrexTaskStatus.js';
import * as HttpVerb from './ValueSet-HttpVerb.js';
import * as ICD10ProcedureCodes from './ValueSet-ICD10ProcedureCodes.js';
import * as IdentifierTypeCodes from './ValueSet-IdentifierTypeCodes.js';
import * as IdentifierUse from './ValueSet-IdentifierUse.js';
import * as IssueType from './ValueSet-IssueType.js';
import * as LinkType from './ValueSet-LinkType.js';
import * as LocationMode from './ValueSet-LocationMode.js';
import * as LocationStatus from './ValueSet-LocationStatus.js';
import * as LocationType from './ValueSet-LocationType.js';
import * as MaritalStatusCodes from './ValueSet-MaritalStatusCodes.js';
import * as MedicationRequestCategoryCodes from './ValueSet-MedicationRequestCategoryCodes.js';
import * as MedicationRequestCourseOfTherapyCodes from './ValueSet-MedicationRequestCourseOfTherapyCodes.js';
import * as MedicationRequestIntent from './ValueSet-MedicationRequestIntent.js';
import * as MedicationrequestStatus from './ValueSet-MedicationrequestStatus.js';
import * as MedicationRequestStatusReasonCodes from './ValueSet-MedicationRequestStatusReasonCodes.js';
import * as MetricDataSource from './ValueSet-MetricDataSource.js';
import * as MissingToothReasonCodes from './ValueSet-MissingToothReasonCodes.js';
import * as ModifierTypeCodes from './ValueSet-ModifierTypeCodes.js';
import * as NameUse from './ValueSet-NameUse.js';
import * as NoteType from './ValueSet-NoteType.js';
import * as NutrientModifierCodes from './ValueSet-NutrientModifierCodes.js';
import * as OperationOutcomeCodes from './ValueSet-OperationOutcomeCodes.js';
import * as OralSiteCodes from './ValueSet-OralSiteCodes.js';
import * as OrganizationType from './ValueSet-OrganizationType.js';
import * as ParticipantRoles from './ValueSet-ParticipantRoles.js';
import * as ParticipantType from './ValueSet-ParticipantType.js';
import * as PASCommunicationRequestMedium from './ValueSet-PASCommunicationRequestMedium.js';
import * as PASInformationChangeMode from './ValueSet-PASInformationChangeMode.js';
import * as PASSupportingInfoType from './ValueSet-PASSupportingInfoType.js';
import * as PASTaskCodes from './ValueSet-PASTaskCodes.js';
import * as PatientContactRelationship from './ValueSet-PatientContactRelationship.js';
import * as PaymentAdjustmentReasonCodes from './ValueSet-PaymentAdjustmentReasonCodes.js';
import * as PracticeSettingCodeValueSet from './ValueSet-PracticeSettingCodeValueSet.js';
import * as PractitionerRole from './ValueSet-PractitionerRole.js';
import * as ProcedurePerformerRoleCodes from './ValueSet-ProcedurePerformerRoleCodes.js';
import * as ProcedureReasonCodes from './ValueSet-ProcedureReasonCodes.js';
import * as ProcessPriorityCodes from './ValueSet-ProcessPriorityCodes.js';
import * as RequestIntent from './ValueSet-RequestIntent.js';
import * as RequestPriority from './ValueSet-RequestPriority.js';
import * as RequestStatus from './ValueSet-RequestStatus.js';
import * as ResourceType from './ValueSet-ResourceType.js';
import * as SearchEntryMode from './ValueSet-SearchEntryMode.js';
import * as ServiceRequestCategoryCodes from './ValueSet-ServiceRequestCategoryCodes.js';
import * as ServiceRequestOrderDetailsCodes from './ValueSet-ServiceRequestOrderDetailsCodes.js';
import * as ServiceType from './ValueSet-ServiceType.js';
import * as SNOMEDCTAdditionalDosageInstructions from './ValueSet-SNOMEDCTAdditionalDosageInstructions.js';
import * as SNOMEDCTAdministrationMethodCodes from './ValueSet-SNOMEDCTAdministrationMethodCodes.js';
import * as SNOMEDCTAnatomicalStructureForAdministrationSiteCodes from './ValueSet-SNOMEDCTAnatomicalStructureForAdministrationSiteCodes.js';
import * as SNOMEDCTMedicationAsNeededReasonCodes from './ValueSet-SNOMEDCTMedicationAsNeededReasonCodes.js';
import * as SNOMEDCTRouteCodes from './ValueSet-SNOMEDCTRouteCodes.js';
import * as SpecialArrangements from './ValueSet-SpecialArrangements.js';
import * as SpecialCourtesy from './ValueSet-SpecialCourtesy.js';
import * as SubscriberRelationshipCodes from './ValueSet-SubscriberRelationshipCodes.js';
import * as SupplementTypeCodes from './ValueSet-SupplementTypeCodes.js';
import * as SurfaceCodes from './ValueSet-SurfaceCodes.js';
import * as TaskIntent from './ValueSet-TaskIntent.js';
import * as TextureModifiedFoodTypeCodes from './ValueSet-TextureModifiedFoodTypeCodes.js';
import * as TextureModifierCodes from './ValueSet-TextureModifierCodes.js';
import * as TimingAbbreviation from './ValueSet-TimingAbbreviation.js';
import * as UnitsOfTime from './ValueSet-UnitsOfTime.js';
import * as USCLSCodes from './ValueSet-USCLSCodes.js';
import * as UsCoreUspsState from './ValueSet-UsCoreUspsState.js';
import * as Use from './ValueSet-Use.js';
import * as V20092 from './ValueSet-V20092.js';
import * as V20116 from './ValueSet-V20116.js';
import * as V3ActEncounterCode from './ValueSet-V3ActEncounterCode.js';
import * as V3ActPriority from './ValueSet-V3ActPriority.js';
import * as V3ActReason from './ValueSet-V3ActReason.js';
import * as V3ActSubstanceAdminSubstitutionCode from './ValueSet-V3ActSubstanceAdminSubstitutionCode.js';
import * as V3ServiceDeliveryLocationRoleType from './ValueSet-V3ServiceDeliveryLocationRoleType.js';
import * as V3SubstanceAdminSubstitutionReason from './ValueSet-V3SubstanceAdminSubstitutionReason.js';
import * as X12278DiagnosisType from './ValueSet-X12278DiagnosisType.js';
import * as X12278RequestedServiceType from './ValueSet-X12278RequestedServiceType.js';
export const ValueSetRegistry = {
    AddressType,
    AddressUse,
    AdjudicationReasonCodes,
    AdjudicationValueCodes,
    AdministrativeGender,
    BenefitCategoryCodes,
    BodySite,
    BundleType,
    ClaimCareTeamRoleCodes,
    ClaimInformationCategoryCodes,
    ClaimPayeeTypeCodes,
    ClaimProcessingCodes,
    ClaimTypeCodes,
    CommonLanguages,
    ConditionCode,
    ContactEntityType,
    ContactPointSystem,
    ContactPointUse,
    CoverageClassCodes,
    CoverageCopayTypeCodes,
    CoverageTypeAndSelfPayCodes,
    DaysOfWeek,
    DiagnosisRole,
    Diet,
    DischargeDisposition,
    DoseAndRateType,
    EncounterLocationStatus,
    EncounterReasonCodes,
    EncounterStatus,
    EnteralFormulaAdditiveTypeCode,
    EnteralRouteCodes,
    EventTiming,
    ExampleClaimSubTypeCodes,
    ExampleCoverageFinancialExceptionCodes,
    ExampleDiagnosisOnAdmissionCodes,
    ExampleDiagnosisRelatedGroupCodes,
    ExamplePaymentTypeCodes,
    ExampleProcedureTypeCodes,
    ExampleProgramReasonCodes,
    ExampleProviderQualificationCodes,
    ExampleRelatedClaimRelationshipCodes,
    ExampleRevenueCenterCodes,
    ExampleServicePlaceCodes,
    ExceptionCodes,
    FluidConsistencyTypeCodes,
    FmStatus,
    FoodTypeCodes,
    FormCodes,
    FundsReservationCodes,
    HrexTaskStatus,
    HttpVerb,
    ICD10ProcedureCodes,
    IdentifierTypeCodes,
    IdentifierUse,
    IssueType,
    LinkType,
    LocationMode,
    LocationStatus,
    LocationType,
    MaritalStatusCodes,
    MedicationRequestCategoryCodes,
    MedicationRequestCourseOfTherapyCodes,
    MedicationRequestIntent,
    MedicationrequestStatus,
    MedicationRequestStatusReasonCodes,
    MetricDataSource,
    MissingToothReasonCodes,
    ModifierTypeCodes,
    NameUse,
    NoteType,
    NutrientModifierCodes,
    OperationOutcomeCodes,
    OralSiteCodes,
    OrganizationType,
    ParticipantRoles,
    ParticipantType,
    PASCommunicationRequestMedium,
    PASInformationChangeMode,
    PASSupportingInfoType,
    PASTaskCodes,
    PatientContactRelationship,
    PaymentAdjustmentReasonCodes,
    PracticeSettingCodeValueSet,
    PractitionerRole,
    ProcedurePerformerRoleCodes,
    ProcedureReasonCodes,
    ProcessPriorityCodes,
    RequestIntent,
    RequestPriority,
    RequestStatus,
    ResourceType,
    SearchEntryMode,
    ServiceRequestCategoryCodes,
    ServiceRequestOrderDetailsCodes,
    ServiceType,
    SNOMEDCTAdditionalDosageInstructions,
    SNOMEDCTAdministrationMethodCodes,
    SNOMEDCTAnatomicalStructureForAdministrationSiteCodes,
    SNOMEDCTMedicationAsNeededReasonCodes,
    SNOMEDCTRouteCodes,
    SpecialArrangements,
    SpecialCourtesy,
    SubscriberRelationshipCodes,
    SupplementTypeCodes,
    SurfaceCodes,
    TaskIntent,
    TextureModifiedFoodTypeCodes,
    TextureModifierCodes,
    TimingAbbreviation,
    UnitsOfTime,
    USCLSCodes,
    UsCoreUspsState,
    Use,
    V20092,
    V20116,
    V3ActEncounterCode,
    V3ActPriority,
    V3ActReason,
    V3ActSubstanceAdminSubstitutionCode,
    V3ServiceDeliveryLocationRoleType,
    V3SubstanceAdminSubstitutionReason,
    X12278DiagnosisType,
    X12278RequestedServiceType,
};
export function getValueSet(name) {
    return ValueSetRegistry[name];
}
/** Map from ValueSet URL to registry name */
export const ValueSetUrlMap = {
    'http://hl7.org/fhir/ValueSet/address-type': 'AddressType',
    'http://hl7.org/fhir/ValueSet/address-use': 'AddressUse',
    'http://hl7.org/fhir/ValueSet/adjudication-reason': 'AdjudicationReasonCodes',
    'http://hl7.org/fhir/ValueSet/adjudication': 'AdjudicationValueCodes',
    'http://hl7.org/fhir/ValueSet/administrative-gender': 'AdministrativeGender',
    'http://hl7.org/fhir/ValueSet/ex-benefitcategory': 'BenefitCategoryCodes',
    'http://hl7.org/fhir/ValueSet/body-site': 'BodySite',
    'http://hl7.org/fhir/ValueSet/bundle-type': 'BundleType',
    'http://hl7.org/fhir/ValueSet/claim-careteamrole': 'ClaimCareTeamRoleCodes',
    'http://hl7.org/fhir/ValueSet/claim-informationcategory': 'ClaimInformationCategoryCodes',
    'http://hl7.org/fhir/ValueSet/payeetype': 'ClaimPayeeTypeCodes',
    'http://hl7.org/fhir/ValueSet/remittance-outcome': 'ClaimProcessingCodes',
    'http://hl7.org/fhir/ValueSet/claim-type': 'ClaimTypeCodes',
    'http://hl7.org/fhir/ValueSet/languages': 'CommonLanguages',
    'http://hl7.org/fhir/ValueSet/condition-code': 'ConditionCode',
    'http://hl7.org/fhir/ValueSet/contactentity-type': 'ContactEntityType',
    'http://hl7.org/fhir/ValueSet/contact-point-system': 'ContactPointSystem',
    'http://hl7.org/fhir/ValueSet/contact-point-use': 'ContactPointUse',
    'http://hl7.org/fhir/ValueSet/coverage-class': 'CoverageClassCodes',
    'http://hl7.org/fhir/ValueSet/coverage-copay-type': 'CoverageCopayTypeCodes',
    'http://hl7.org/fhir/ValueSet/coverage-type': 'CoverageTypeAndSelfPayCodes',
    'http://hl7.org/fhir/ValueSet/days-of-week': 'DaysOfWeek',
    'http://hl7.org/fhir/ValueSet/diagnosis-role': 'DiagnosisRole',
    'http://hl7.org/fhir/ValueSet/encounter-diet': 'Diet',
    'http://hl7.org/fhir/ValueSet/encounter-discharge-disposition': 'DischargeDisposition',
    'http://hl7.org/fhir/ValueSet/dose-rate-type': 'DoseAndRateType',
    'http://hl7.org/fhir/ValueSet/encounter-location-status': 'EncounterLocationStatus',
    'http://hl7.org/fhir/ValueSet/encounter-reason': 'EncounterReasonCodes',
    'http://hl7.org/fhir/ValueSet/encounter-status': 'EncounterStatus',
    'http://hl7.org/fhir/ValueSet/entformula-additive': 'EnteralFormulaAdditiveTypeCode',
    'http://hl7.org/fhir/ValueSet/enteral-route': 'EnteralRouteCodes',
    'http://hl7.org/fhir/ValueSet/event-timing': 'EventTiming',
    'http://hl7.org/fhir/ValueSet/claim-subtype': 'ExampleClaimSubTypeCodes',
    'http://hl7.org/fhir/ValueSet/coverage-financial-exception': 'ExampleCoverageFinancialExceptionCodes',
    'http://hl7.org/fhir/ValueSet/ex-diagnosis-on-admission': 'ExampleDiagnosisOnAdmissionCodes',
    'http://hl7.org/fhir/ValueSet/ex-diagnosisrelatedgroup': 'ExampleDiagnosisRelatedGroupCodes',
    'http://hl7.org/fhir/ValueSet/ex-paymenttype': 'ExamplePaymentTypeCodes',
    'http://hl7.org/fhir/ValueSet/ex-procedure-type': 'ExampleProcedureTypeCodes',
    'http://hl7.org/fhir/ValueSet/ex-program-code': 'ExampleProgramReasonCodes',
    'http://hl7.org/fhir/ValueSet/provider-qualification': 'ExampleProviderQualificationCodes',
    'http://hl7.org/fhir/ValueSet/related-claim-relationship': 'ExampleRelatedClaimRelationshipCodes',
    'http://hl7.org/fhir/ValueSet/ex-revenue-center': 'ExampleRevenueCenterCodes',
    'http://hl7.org/fhir/ValueSet/service-place': 'ExampleServicePlaceCodes',
    'http://hl7.org/fhir/ValueSet/claim-exception': 'ExceptionCodes',
    'http://hl7.org/fhir/ValueSet/consistency-type': 'FluidConsistencyTypeCodes',
    'http://hl7.org/fhir/ValueSet/fm-status': 'FmStatus',
    'http://hl7.org/fhir/ValueSet/food-type': 'FoodTypeCodes',
    'http://hl7.org/fhir/ValueSet/forms': 'FormCodes',
    'http://hl7.org/fhir/ValueSet/fundsreserve': 'FundsReservationCodes',
    'http://hl7.org/fhir/us/davinci-hrex/ValueSet/hrex-task-status': 'HrexTaskStatus',
    'http://hl7.org/fhir/ValueSet/http-verb': 'HttpVerb',
    'http://hl7.org/fhir/ValueSet/icd-10-procedures': 'ICD10ProcedureCodes',
    'http://hl7.org/fhir/ValueSet/identifier-type': 'IdentifierTypeCodes',
    'http://hl7.org/fhir/ValueSet/identifier-use': 'IdentifierUse',
    'http://hl7.org/fhir/ValueSet/issue-type': 'IssueType',
    'http://hl7.org/fhir/ValueSet/link-type': 'LinkType',
    'http://hl7.org/fhir/ValueSet/location-mode': 'LocationMode',
    'http://hl7.org/fhir/ValueSet/location-status': 'LocationStatus',
    'http://hl7.org/fhir/ValueSet/location-physical-type': 'LocationType',
    'http://hl7.org/fhir/ValueSet/marital-status': 'MaritalStatusCodes',
    'http://hl7.org/fhir/ValueSet/medicationrequest-category': 'MedicationRequestCategoryCodes',
    'http://hl7.org/fhir/ValueSet/medicationrequest-course-of-therapy': 'MedicationRequestCourseOfTherapyCodes',
    'http://hl7.org/fhir/ValueSet/medicationrequest-intent': 'MedicationRequestIntent',
    'http://hl7.org/fhir/ValueSet/medicationrequest-status': 'MedicationrequestStatus',
    'http://hl7.org/fhir/ValueSet/medicationrequest-status-reason': 'MedicationRequestStatusReasonCodes',
    'http://hl7.org/fhir/us/davinci-pas/ValueSet/MetricDataSource': 'MetricDataSource',
    'http://hl7.org/fhir/ValueSet/missing-tooth-reason': 'MissingToothReasonCodes',
    'http://hl7.org/fhir/ValueSet/claim-modifiers': 'ModifierTypeCodes',
    'http://hl7.org/fhir/ValueSet/name-use': 'NameUse',
    'http://hl7.org/fhir/ValueSet/note-type': 'NoteType',
    'http://hl7.org/fhir/ValueSet/nutrient-code': 'NutrientModifierCodes',
    'http://hl7.org/fhir/ValueSet/operation-outcome': 'OperationOutcomeCodes',
    'http://hl7.org/fhir/ValueSet/tooth': 'OralSiteCodes',
    'http://hl7.org/fhir/ValueSet/organization-type': 'OrganizationType',
    'http://hl7.org/fhir/ValueSet/participant-role': 'ParticipantRoles',
    'http://hl7.org/fhir/ValueSet/encounter-participant-type': 'ParticipantType',
    'http://hl7.org/fhir/us/davinci-pas/ValueSet/PASCommunicationRequestMedium': 'PASCommunicationRequestMedium',
    'http://hl7.org/fhir/us/davinci-pas/ValueSet/PASInformationChangeMode': 'PASInformationChangeMode',
    'http://hl7.org/fhir/us/davinci-pas/ValueSet/PASSupportingInfoType': 'PASSupportingInfoType',
    'http://hl7.org/fhir/us/davinci-pas/ValueSet/PASTaskCodes': 'PASTaskCodes',
    'http://hl7.org/fhir/ValueSet/patient-contactrelationship': 'PatientContactRelationship',
    'http://hl7.org/fhir/ValueSet/payment-adjustment-reason': 'PaymentAdjustmentReasonCodes',
    'http://hl7.org/fhir/ValueSet/c80-practice-codes': 'PracticeSettingCodeValueSet',
    'http://hl7.org/fhir/ValueSet/practitioner-role': 'PractitionerRole',
    'http://hl7.org/fhir/ValueSet/performer-role': 'ProcedurePerformerRoleCodes',
    'http://hl7.org/fhir/ValueSet/procedure-reason': 'ProcedureReasonCodes',
    'http://hl7.org/fhir/ValueSet/process-priority': 'ProcessPriorityCodes',
    'http://hl7.org/fhir/ValueSet/request-intent': 'RequestIntent',
    'http://hl7.org/fhir/ValueSet/request-priority': 'RequestPriority',
    'http://hl7.org/fhir/ValueSet/request-status': 'RequestStatus',
    'http://hl7.org/fhir/ValueSet/resource-types': 'ResourceType',
    'http://hl7.org/fhir/ValueSet/search-entry-mode': 'SearchEntryMode',
    'http://hl7.org/fhir/ValueSet/servicerequest-category': 'ServiceRequestCategoryCodes',
    'http://hl7.org/fhir/ValueSet/servicerequest-orderdetail': 'ServiceRequestOrderDetailsCodes',
    'http://hl7.org/fhir/ValueSet/service-type': 'ServiceType',
    'http://hl7.org/fhir/ValueSet/additional-instruction-codes': 'SNOMEDCTAdditionalDosageInstructions',
    'http://hl7.org/fhir/ValueSet/administration-method-codes': 'SNOMEDCTAdministrationMethodCodes',
    'http://hl7.org/fhir/ValueSet/approach-site-codes': 'SNOMEDCTAnatomicalStructureForAdministrationSiteCodes',
    'http://hl7.org/fhir/ValueSet/medication-as-needed-reason': 'SNOMEDCTMedicationAsNeededReasonCodes',
    'http://hl7.org/fhir/ValueSet/route-codes': 'SNOMEDCTRouteCodes',
    'http://hl7.org/fhir/ValueSet/encounter-special-arrangements': 'SpecialArrangements',
    'http://hl7.org/fhir/ValueSet/encounter-special-courtesy': 'SpecialCourtesy',
    'http://hl7.org/fhir/ValueSet/subscriber-relationship': 'SubscriberRelationshipCodes',
    'http://hl7.org/fhir/ValueSet/supplement-type': 'SupplementTypeCodes',
    'http://hl7.org/fhir/ValueSet/surface': 'SurfaceCodes',
    'http://hl7.org/fhir/ValueSet/task-intent': 'TaskIntent',
    'http://hl7.org/fhir/ValueSet/modified-foodtype': 'TextureModifiedFoodTypeCodes',
    'http://hl7.org/fhir/ValueSet/texture-code': 'TextureModifierCodes',
    'http://hl7.org/fhir/ValueSet/timing-abbreviation': 'TimingAbbreviation',
    'http://hl7.org/fhir/ValueSet/units-of-time': 'UnitsOfTime',
    'http://hl7.org/fhir/ValueSet/service-uscls': 'USCLSCodes',
    'http://hl7.org/fhir/us/core/ValueSet/us-core-usps-state': 'UsCoreUspsState',
    'http://hl7.org/fhir/ValueSet/claim-use': 'Use',
    'http://terminology.hl7.org/ValueSet/v2-0092': 'V20092',
    'http://terminology.hl7.org/ValueSet/v2-0116': 'V20116',
    'http://terminology.hl7.org/ValueSet/v3-ActEncounterCode': 'V3ActEncounterCode',
    'http://terminology.hl7.org/ValueSet/v3-ActPriority': 'V3ActPriority',
    'http://terminology.hl7.org/ValueSet/v3-ActReason': 'V3ActReason',
    'http://terminology.hl7.org/ValueSet/v3-ActSubstanceAdminSubstitutionCode': 'V3ActSubstanceAdminSubstitutionCode',
    'http://terminology.hl7.org/ValueSet/v3-ServiceDeliveryLocationRoleType': 'V3ServiceDeliveryLocationRoleType',
    'http://terminology.hl7.org/ValueSet/v3-SubstanceAdminSubstitutionReason': 'V3SubstanceAdminSubstitutionReason',
    'http://hl7.org/fhir/us/davinci-pas/ValueSet/X12278DiagnosisType': 'X12278DiagnosisType',
    'http://hl7.org/fhir/us/davinci-pas/ValueSet/X12278RequestedServiceType': 'X12278RequestedServiceType',
};
function stripVersionFromUrl(url) {
    const pipeIndex = url.indexOf('|');
    return pipeIndex >= 0 ? url.substring(0, pipeIndex) : url;
}
/**
 * Get a random code from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A random code string, or undefined if ValueSet not found
 */
export function getRandomCodeByUrl(url) {
    const cleanUrl = stripVersionFromUrl(url);
    const name = ValueSetUrlMap[cleanUrl];
    if (!name)
        return undefined;
    const vs = ValueSetRegistry[name];
    // Each ValueSet exports random<Name>Code() function
    const randomFn = vs['random' + name + 'Code'];
    return randomFn?.();
}
/**
 * Get a random concept (code, system, display) from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A concept object with code, system, and optional display, or undefined if ValueSet not found
 */
export function getRandomConceptByUrl(url) {
    const cleanUrl = stripVersionFromUrl(url);
    const name = ValueSetUrlMap[cleanUrl];
    if (!name)
        return undefined;
    const vs = ValueSetRegistry[name];
    // Each ValueSet exports random<Name>Concept() function
    const randomFn = vs['random' + name + 'Concept'];
    return randomFn?.();
}
