/**
 * ValueSet Registry
 * Central registry of all loaded ValueSets with explicit codes
 */
import * as AddressType from './ValueSet-AddressType.js';
import * as AddressUse from './ValueSet-AddressUse.js';
import * as Adjudication from './ValueSet-Adjudication.js';
import * as AdjudicationReason from './ValueSet-AdjudicationReason.js';
import * as AdministrativeGender from './ValueSet-AdministrativeGender.js';
import * as BodySite from './ValueSet-BodySite.js';
import * as BundleType from './ValueSet-BundleType.js';
import * as C80PracticeCodes from './ValueSet-C80PracticeCodes.js';
import * as ClaimCareteamrole from './ValueSet-ClaimCareteamrole.js';
import * as ClaimException from './ValueSet-ClaimException.js';
import * as ClaimInformationcategory from './ValueSet-ClaimInformationcategory.js';
import * as ClaimModifiers from './ValueSet-ClaimModifiers.js';
import * as ClaimSubtype from './ValueSet-ClaimSubtype.js';
import * as ClaimType from './ValueSet-ClaimType.js';
import * as ClaimUse from './ValueSet-ClaimUse.js';
import * as ConditionCode from './ValueSet-ConditionCode.js';
import * as ConsistencyType from './ValueSet-ConsistencyType.js';
import * as ContactentityType from './ValueSet-ContactentityType.js';
import * as ContactPointSystem from './ValueSet-ContactPointSystem.js';
import * as ContactPointUse from './ValueSet-ContactPointUse.js';
import * as CoverageClass from './ValueSet-CoverageClass.js';
import * as CoverageCopayType from './ValueSet-CoverageCopayType.js';
import * as CoverageFinancialException from './ValueSet-CoverageFinancialException.js';
import * as CoverageType from './ValueSet-CoverageType.js';
import * as DaysOfWeek from './ValueSet-DaysOfWeek.js';
import * as DiagnosisRole from './ValueSet-DiagnosisRole.js';
import * as DoseRateType from './ValueSet-DoseRateType.js';
import * as EncounterDiet from './ValueSet-EncounterDiet.js';
import * as EncounterDischargeDisposition from './ValueSet-EncounterDischargeDisposition.js';
import * as EncounterLocationStatus from './ValueSet-EncounterLocationStatus.js';
import * as EncounterParticipantType from './ValueSet-EncounterParticipantType.js';
import * as EncounterSpecialArrangements from './ValueSet-EncounterSpecialArrangements.js';
import * as EncounterSpecialCourtesy from './ValueSet-EncounterSpecialCourtesy.js';
import * as EncounterStatus from './ValueSet-EncounterStatus.js';
import * as EnteralRoute from './ValueSet-EnteralRoute.js';
import * as EntformulaAdditive from './ValueSet-EntformulaAdditive.js';
import * as EventTiming from './ValueSet-EventTiming.js';
import * as ExBenefitcategory from './ValueSet-ExBenefitcategory.js';
import * as ExDiagnosisOnAdmission from './ValueSet-ExDiagnosisOnAdmission.js';
import * as ExDiagnosisrelatedgroup from './ValueSet-ExDiagnosisrelatedgroup.js';
import * as ExPaymenttype from './ValueSet-ExPaymenttype.js';
import * as ExProcedureType from './ValueSet-ExProcedureType.js';
import * as ExProgramCode from './ValueSet-ExProgramCode.js';
import * as ExRevenueCenter from './ValueSet-ExRevenueCenter.js';
import * as FmStatus from './ValueSet-FmStatus.js';
import * as Forms from './ValueSet-Forms.js';
import * as Fundsreserve from './ValueSet-Fundsreserve.js';
import * as HrexTaskStatus from './ValueSet-HrexTaskStatus.js';
import * as HttpVerb from './ValueSet-HttpVerb.js';
import * as Icd10Procedures from './ValueSet-Icd10Procedures.js';
import * as IdentifierType from './ValueSet-IdentifierType.js';
import * as IdentifierUse from './ValueSet-IdentifierUse.js';
import * as IssueType from './ValueSet-IssueType.js';
import * as Languages from './ValueSet-Languages.js';
import * as LinkType from './ValueSet-LinkType.js';
import * as LocationMode from './ValueSet-LocationMode.js';
import * as LocationPhysicalType from './ValueSet-LocationPhysicalType.js';
import * as LocationStatus from './ValueSet-LocationStatus.js';
import * as MaritalStatus from './ValueSet-MaritalStatus.js';
import * as MedicationrequestCategory from './ValueSet-MedicationrequestCategory.js';
import * as MedicationrequestCourseOfTherapy from './ValueSet-MedicationrequestCourseOfTherapy.js';
import * as MedicationrequestIntent from './ValueSet-MedicationrequestIntent.js';
import * as MedicationrequestStatus from './ValueSet-MedicationrequestStatus.js';
import * as MedicationrequestStatusReason from './ValueSet-MedicationrequestStatusReason.js';
import * as MetricDataSource from './ValueSet-MetricDataSource.js';
import * as MissingToothReason from './ValueSet-MissingToothReason.js';
import * as ModifiedFoodtype from './ValueSet-ModifiedFoodtype.js';
import * as NameUse from './ValueSet-NameUse.js';
import * as NoteType from './ValueSet-NoteType.js';
import * as NutrientCode from './ValueSet-NutrientCode.js';
import * as OperationOutcome from './ValueSet-OperationOutcome.js';
import * as OrganizationType from './ValueSet-OrganizationType.js';
import * as PASCommunicationRequestMedium from './ValueSet-PASCommunicationRequestMedium.js';
import * as PASInformationChangeMode from './ValueSet-PASInformationChangeMode.js';
import * as PASSupportingInfoType from './ValueSet-PASSupportingInfoType.js';
import * as PASTaskCodes from './ValueSet-PASTaskCodes.js';
import * as Payeetype from './ValueSet-Payeetype.js';
import * as PaymentAdjustmentReason from './ValueSet-PaymentAdjustmentReason.js';
import * as PractitionerRole from './ValueSet-PractitionerRole.js';
import * as ProcessPriority from './ValueSet-ProcessPriority.js';
import * as ProviderQualification from './ValueSet-ProviderQualification.js';
import * as RelatedClaimRelationship from './ValueSet-RelatedClaimRelationship.js';
import * as RemittanceOutcome from './ValueSet-RemittanceOutcome.js';
import * as RequestIntent from './ValueSet-RequestIntent.js';
import * as RequestPriority from './ValueSet-RequestPriority.js';
import * as RequestStatus from './ValueSet-RequestStatus.js';
import * as ResourceTypes from './ValueSet-ResourceTypes.js';
import * as SearchEntryMode from './ValueSet-SearchEntryMode.js';
import * as ServicePlace from './ValueSet-ServicePlace.js';
import * as ServicerequestCategory from './ValueSet-ServicerequestCategory.js';
import * as ServicerequestOrderdetail from './ValueSet-ServicerequestOrderdetail.js';
import * as ServiceUscls from './ValueSet-ServiceUscls.js';
import * as SubscriberRelationship from './ValueSet-SubscriberRelationship.js';
import * as SupplementType from './ValueSet-SupplementType.js';
import * as Surface from './ValueSet-Surface.js';
import * as TaskIntent from './ValueSet-TaskIntent.js';
import * as TextureCode from './ValueSet-TextureCode.js';
import * as TimingAbbreviation from './ValueSet-TimingAbbreviation.js';
import * as Tooth from './ValueSet-Tooth.js';
import * as UnitsOfTime from './ValueSet-UnitsOfTime.js';
import * as UsCoreUspsState from './ValueSet-UsCoreUspsState.js';
import * as V20092 from './ValueSet-V20092.js';
import * as V20116 from './ValueSet-V20116.js';
import * as V2270360 from './ValueSet-V2270360.js';
import * as V3ActPriority from './ValueSet-V3ActPriority.js';
import * as V3ActReason from './ValueSet-V3ActReason.js';
import * as X12278DiagnosisType from './ValueSet-X12278DiagnosisType.js';
import * as X12278RequestedServiceType from './ValueSet-X12278RequestedServiceType.js';
export const ValueSetRegistry = {
    AddressType,
    AddressUse,
    Adjudication,
    AdjudicationReason,
    AdministrativeGender,
    BodySite,
    BundleType,
    C80PracticeCodes,
    ClaimCareteamrole,
    ClaimException,
    ClaimInformationcategory,
    ClaimModifiers,
    ClaimSubtype,
    ClaimType,
    ClaimUse,
    ConditionCode,
    ConsistencyType,
    ContactentityType,
    ContactPointSystem,
    ContactPointUse,
    CoverageClass,
    CoverageCopayType,
    CoverageFinancialException,
    CoverageType,
    DaysOfWeek,
    DiagnosisRole,
    DoseRateType,
    EncounterDiet,
    EncounterDischargeDisposition,
    EncounterLocationStatus,
    EncounterParticipantType,
    EncounterSpecialArrangements,
    EncounterSpecialCourtesy,
    EncounterStatus,
    EnteralRoute,
    EntformulaAdditive,
    EventTiming,
    ExBenefitcategory,
    ExDiagnosisOnAdmission,
    ExDiagnosisrelatedgroup,
    ExPaymenttype,
    ExProcedureType,
    ExProgramCode,
    ExRevenueCenter,
    FmStatus,
    Forms,
    Fundsreserve,
    HrexTaskStatus,
    HttpVerb,
    Icd10Procedures,
    IdentifierType,
    IdentifierUse,
    IssueType,
    Languages,
    LinkType,
    LocationMode,
    LocationPhysicalType,
    LocationStatus,
    MaritalStatus,
    MedicationrequestCategory,
    MedicationrequestCourseOfTherapy,
    MedicationrequestIntent,
    MedicationrequestStatus,
    MedicationrequestStatusReason,
    MetricDataSource,
    MissingToothReason,
    ModifiedFoodtype,
    NameUse,
    NoteType,
    NutrientCode,
    OperationOutcome,
    OrganizationType,
    PASCommunicationRequestMedium,
    PASInformationChangeMode,
    PASSupportingInfoType,
    PASTaskCodes,
    Payeetype,
    PaymentAdjustmentReason,
    PractitionerRole,
    ProcessPriority,
    ProviderQualification,
    RelatedClaimRelationship,
    RemittanceOutcome,
    RequestIntent,
    RequestPriority,
    RequestStatus,
    ResourceTypes,
    SearchEntryMode,
    ServicePlace,
    ServicerequestCategory,
    ServicerequestOrderdetail,
    ServiceUscls,
    SubscriberRelationship,
    SupplementType,
    Surface,
    TaskIntent,
    TextureCode,
    TimingAbbreviation,
    Tooth,
    UnitsOfTime,
    UsCoreUspsState,
    V20092,
    V20116,
    V2270360,
    V3ActPriority,
    V3ActReason,
    X12278DiagnosisType,
    X12278RequestedServiceType,
};
export function getValueSet(name) {
    return ValueSetRegistry[name];
}
/** Map from ValueSet URL to registry name */
export const ValueSetUrlMap = {
    'http://hl7.org/fhir/ValueSet/address-type': 'AddressType',
    'http://hl7.org/fhir/ValueSet/address-use': 'AddressUse',
    'http://hl7.org/fhir/ValueSet/adjudication': 'Adjudication',
    'http://hl7.org/fhir/ValueSet/adjudication-reason': 'AdjudicationReason',
    'http://hl7.org/fhir/ValueSet/administrative-gender': 'AdministrativeGender',
    'http://hl7.org/fhir/ValueSet/body-site': 'BodySite',
    'http://hl7.org/fhir/ValueSet/bundle-type': 'BundleType',
    'http://hl7.org/fhir/ValueSet/c80-practice-codes': 'C80PracticeCodes',
    'http://hl7.org/fhir/ValueSet/claim-careteamrole': 'ClaimCareteamrole',
    'http://hl7.org/fhir/ValueSet/claim-exception': 'ClaimException',
    'http://hl7.org/fhir/ValueSet/claim-informationcategory': 'ClaimInformationcategory',
    'http://hl7.org/fhir/ValueSet/claim-modifiers': 'ClaimModifiers',
    'http://hl7.org/fhir/ValueSet/claim-subtype': 'ClaimSubtype',
    'http://hl7.org/fhir/ValueSet/claim-type': 'ClaimType',
    'http://hl7.org/fhir/ValueSet/claim-use': 'ClaimUse',
    'http://hl7.org/fhir/ValueSet/condition-code': 'ConditionCode',
    'http://hl7.org/fhir/ValueSet/consistency-type': 'ConsistencyType',
    'http://hl7.org/fhir/ValueSet/contactentity-type': 'ContactentityType',
    'http://hl7.org/fhir/ValueSet/contact-point-system': 'ContactPointSystem',
    'http://hl7.org/fhir/ValueSet/contact-point-use': 'ContactPointUse',
    'http://hl7.org/fhir/ValueSet/coverage-class': 'CoverageClass',
    'http://hl7.org/fhir/ValueSet/coverage-copay-type': 'CoverageCopayType',
    'http://hl7.org/fhir/ValueSet/coverage-financial-exception': 'CoverageFinancialException',
    'http://hl7.org/fhir/ValueSet/coverage-type': 'CoverageType',
    'http://hl7.org/fhir/ValueSet/days-of-week': 'DaysOfWeek',
    'http://hl7.org/fhir/ValueSet/diagnosis-role': 'DiagnosisRole',
    'http://hl7.org/fhir/ValueSet/dose-rate-type': 'DoseRateType',
    'http://hl7.org/fhir/ValueSet/encounter-diet': 'EncounterDiet',
    'http://hl7.org/fhir/ValueSet/encounter-discharge-disposition': 'EncounterDischargeDisposition',
    'http://hl7.org/fhir/ValueSet/encounter-location-status': 'EncounterLocationStatus',
    'http://hl7.org/fhir/ValueSet/encounter-participant-type': 'EncounterParticipantType',
    'http://hl7.org/fhir/ValueSet/encounter-special-arrangements': 'EncounterSpecialArrangements',
    'http://hl7.org/fhir/ValueSet/encounter-special-courtesy': 'EncounterSpecialCourtesy',
    'http://hl7.org/fhir/ValueSet/encounter-status': 'EncounterStatus',
    'http://hl7.org/fhir/ValueSet/enteral-route': 'EnteralRoute',
    'http://hl7.org/fhir/ValueSet/entformula-additive': 'EntformulaAdditive',
    'http://hl7.org/fhir/ValueSet/event-timing': 'EventTiming',
    'http://hl7.org/fhir/ValueSet/ex-benefitcategory': 'ExBenefitcategory',
    'http://hl7.org/fhir/ValueSet/ex-diagnosis-on-admission': 'ExDiagnosisOnAdmission',
    'http://hl7.org/fhir/ValueSet/ex-diagnosisrelatedgroup': 'ExDiagnosisrelatedgroup',
    'http://hl7.org/fhir/ValueSet/ex-paymenttype': 'ExPaymenttype',
    'http://hl7.org/fhir/ValueSet/ex-procedure-type': 'ExProcedureType',
    'http://hl7.org/fhir/ValueSet/ex-program-code': 'ExProgramCode',
    'http://hl7.org/fhir/ValueSet/ex-revenue-center': 'ExRevenueCenter',
    'http://hl7.org/fhir/ValueSet/fm-status': 'FmStatus',
    'http://hl7.org/fhir/ValueSet/forms': 'Forms',
    'http://hl7.org/fhir/ValueSet/fundsreserve': 'Fundsreserve',
    'http://hl7.org/fhir/us/davinci-hrex/ValueSet/hrex-task-status': 'HrexTaskStatus',
    'http://hl7.org/fhir/ValueSet/http-verb': 'HttpVerb',
    'http://hl7.org/fhir/ValueSet/icd-10-procedures': 'Icd10Procedures',
    'http://hl7.org/fhir/ValueSet/identifier-type': 'IdentifierType',
    'http://hl7.org/fhir/ValueSet/identifier-use': 'IdentifierUse',
    'http://hl7.org/fhir/ValueSet/issue-type': 'IssueType',
    'http://hl7.org/fhir/ValueSet/languages': 'Languages',
    'http://hl7.org/fhir/ValueSet/link-type': 'LinkType',
    'http://hl7.org/fhir/ValueSet/location-mode': 'LocationMode',
    'http://hl7.org/fhir/ValueSet/location-physical-type': 'LocationPhysicalType',
    'http://hl7.org/fhir/ValueSet/location-status': 'LocationStatus',
    'http://hl7.org/fhir/ValueSet/marital-status': 'MaritalStatus',
    'http://hl7.org/fhir/ValueSet/medicationrequest-category': 'MedicationrequestCategory',
    'http://hl7.org/fhir/ValueSet/medicationrequest-course-of-therapy': 'MedicationrequestCourseOfTherapy',
    'http://hl7.org/fhir/ValueSet/medicationrequest-intent': 'MedicationrequestIntent',
    'http://hl7.org/fhir/ValueSet/medicationrequest-status': 'MedicationrequestStatus',
    'http://hl7.org/fhir/ValueSet/medicationrequest-status-reason': 'MedicationrequestStatusReason',
    'http://hl7.org/fhir/us/davinci-pas/ValueSet/MetricDataSource': 'MetricDataSource',
    'http://hl7.org/fhir/ValueSet/missing-tooth-reason': 'MissingToothReason',
    'http://hl7.org/fhir/ValueSet/modified-foodtype': 'ModifiedFoodtype',
    'http://hl7.org/fhir/ValueSet/name-use': 'NameUse',
    'http://hl7.org/fhir/ValueSet/note-type': 'NoteType',
    'http://hl7.org/fhir/ValueSet/nutrient-code': 'NutrientCode',
    'http://hl7.org/fhir/ValueSet/operation-outcome': 'OperationOutcome',
    'http://hl7.org/fhir/ValueSet/organization-type': 'OrganizationType',
    'http://hl7.org/fhir/us/davinci-pas/ValueSet/PASCommunicationRequestMedium': 'PASCommunicationRequestMedium',
    'http://hl7.org/fhir/us/davinci-pas/ValueSet/PASInformationChangeMode': 'PASInformationChangeMode',
    'http://hl7.org/fhir/us/davinci-pas/ValueSet/PASSupportingInfoType': 'PASSupportingInfoType',
    'http://hl7.org/fhir/us/davinci-pas/ValueSet/PASTaskCodes': 'PASTaskCodes',
    'http://hl7.org/fhir/ValueSet/payeetype': 'Payeetype',
    'http://hl7.org/fhir/ValueSet/payment-adjustment-reason': 'PaymentAdjustmentReason',
    'http://hl7.org/fhir/ValueSet/practitioner-role': 'PractitionerRole',
    'http://hl7.org/fhir/ValueSet/process-priority': 'ProcessPriority',
    'http://hl7.org/fhir/ValueSet/provider-qualification': 'ProviderQualification',
    'http://hl7.org/fhir/ValueSet/related-claim-relationship': 'RelatedClaimRelationship',
    'http://hl7.org/fhir/ValueSet/remittance-outcome': 'RemittanceOutcome',
    'http://hl7.org/fhir/ValueSet/request-intent': 'RequestIntent',
    'http://hl7.org/fhir/ValueSet/request-priority': 'RequestPriority',
    'http://hl7.org/fhir/ValueSet/request-status': 'RequestStatus',
    'http://hl7.org/fhir/ValueSet/resource-types': 'ResourceTypes',
    'http://hl7.org/fhir/ValueSet/search-entry-mode': 'SearchEntryMode',
    'http://hl7.org/fhir/ValueSet/service-place': 'ServicePlace',
    'http://hl7.org/fhir/ValueSet/servicerequest-category': 'ServicerequestCategory',
    'http://hl7.org/fhir/ValueSet/servicerequest-orderdetail': 'ServicerequestOrderdetail',
    'http://hl7.org/fhir/ValueSet/service-uscls': 'ServiceUscls',
    'http://hl7.org/fhir/ValueSet/subscriber-relationship': 'SubscriberRelationship',
    'http://hl7.org/fhir/ValueSet/supplement-type': 'SupplementType',
    'http://hl7.org/fhir/ValueSet/surface': 'Surface',
    'http://hl7.org/fhir/ValueSet/task-intent': 'TaskIntent',
    'http://hl7.org/fhir/ValueSet/texture-code': 'TextureCode',
    'http://hl7.org/fhir/ValueSet/timing-abbreviation': 'TimingAbbreviation',
    'http://hl7.org/fhir/ValueSet/tooth': 'Tooth',
    'http://hl7.org/fhir/ValueSet/units-of-time': 'UnitsOfTime',
    'http://hl7.org/fhir/us/core/ValueSet/us-core-usps-state': 'UsCoreUspsState',
    'http://terminology.hl7.org/ValueSet/v2-0092': 'V20092',
    'http://terminology.hl7.org/ValueSet/v2-0116': 'V20116',
    'http://terminology.hl7.org/ValueSet/v2-2.7-0360': 'V2270360',
    'http://terminology.hl7.org/ValueSet/v3-ActPriority': 'V3ActPriority',
    'http://terminology.hl7.org/ValueSet/v3-ActReason': 'V3ActReason',
    'http://hl7.org/fhir/us/davinci-pas/ValueSet/X12278DiagnosisType': 'X12278DiagnosisType',
    'http://hl7.org/fhir/us/davinci-pas/ValueSet/X12278RequestedServiceType': 'X12278RequestedServiceType',
};
function stripVersionFromUrl(url) {
    const pipeIndex = url.indexOf('|');
    return pipeIndex >= 0 ? url.substring(0, pipeIndex) : url;
}
/**
 * Get a random code from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A random code string, or undefined if ValueSet not found
 */
export function getRandomCodeByUrl(url) {
    const cleanUrl = stripVersionFromUrl(url);
    const name = ValueSetUrlMap[cleanUrl];
    if (!name)
        return undefined;
    const vs = ValueSetRegistry[name];
    // Each ValueSet exports random<Name>Code() function
    const randomFn = vs['random' + name + 'Code'];
    return randomFn?.();
}
/**
 * Get a random concept (code, system, display) from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A concept object with code, system, and optional display, or undefined if ValueSet not found
 */
export function getRandomConceptByUrl(url) {
    const cleanUrl = stripVersionFromUrl(url);
    const name = ValueSetUrlMap[cleanUrl];
    if (!name)
        return undefined;
    const vs = ValueSetRegistry[name];
    // Each ValueSet exports random<Name>Concept() function
    const randomFn = vs['random' + name + 'Concept'];
    return randomFn?.();
}
