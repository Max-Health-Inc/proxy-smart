/**
 * ValueSet: ExampleClaimSubTypeCodes
 * URL: http://hl7.org/fhir/ValueSet/claim-subtype
 * Size: 2 concepts
 */
export const ExampleClaimSubTypeCodesConcepts = [
    { code: "ortho", system: "http://terminology.hl7.org/CodeSystem/ex-claimsubtype", display: "Orthodontic Claim" },
    { code: "emergency", system: "http://terminology.hl7.org/CodeSystem/ex-claimsubtype", display: "Emergency Claim" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidExampleClaimSubTypeCodesCode(code) {
    return ExampleClaimSubTypeCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getExampleClaimSubTypeCodesConcept(code) {
    return ExampleClaimSubTypeCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ExampleClaimSubTypeCodesCodes = ExampleClaimSubTypeCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomExampleClaimSubTypeCodesCode() {
    return ExampleClaimSubTypeCodesCodes[Math.floor(Math.random() * ExampleClaimSubTypeCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomExampleClaimSubTypeCodesConcept() {
    return ExampleClaimSubTypeCodesConcepts[Math.floor(Math.random() * ExampleClaimSubTypeCodesConcepts.length)];
}
