/**
 * ValueSet: ex-paymenttype
 * URL: http://hl7.org/fhir/ValueSet/ex-paymenttype
 * Size: 2 concepts
 */
export const ExPaymenttypeConcepts = [
    { code: "complete", system: "http://terminology.hl7.org/CodeSystem/ex-paymenttype" },
    { code: "partial", system: "http://terminology.hl7.org/CodeSystem/ex-paymenttype" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidExPaymenttypeCode(code) {
    return ExPaymenttypeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getExPaymenttypeConcept(code) {
    return ExPaymenttypeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ExPaymenttypeCodes = ExPaymenttypeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomExPaymenttypeCode() {
    return ExPaymenttypeCodes[Math.floor(Math.random() * ExPaymenttypeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomExPaymenttypeConcept() {
    return ExPaymenttypeConcepts[Math.floor(Math.random() * ExPaymenttypeConcepts.length)];
}
