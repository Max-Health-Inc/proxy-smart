/**
 * ValueSet: FluidConsistencyTypeCodes
 * URL: http://hl7.org/fhir/ValueSet/consistency-type
 * Size: 4 concepts
 */
export declare const FluidConsistencyTypeCodesConcepts: readonly [{
    readonly code: "439031000124108";
    readonly system: "http://snomed.info/sct";
    readonly display: "honey thick liquid";
}, {
    readonly code: "439021000124105";
    readonly system: "http://snomed.info/sct";
    readonly display: "nectar thick liquid";
}, {
    readonly code: "439041000124103";
    readonly system: "http://snomed.info/sct";
    readonly display: "spoon thick liquid";
}, {
    readonly code: "439081000124109";
    readonly system: "http://snomed.info/sct";
    readonly display: "thin liquid";
}];
/** Union type of all valid codes in this ValueSet */
export type FluidConsistencyTypeCodesCode = "439031000124108" | "439021000124105" | "439041000124103" | "439081000124109";
/** Type representing a concept from this ValueSet */
export type FluidConsistencyTypeCodesConcept = typeof FluidConsistencyTypeCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidFluidConsistencyTypeCodesCode(code: string): code is FluidConsistencyTypeCodesCode;
/**
 * Get concept details by code
 */
export declare function getFluidConsistencyTypeCodesConcept(code: string): FluidConsistencyTypeCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const FluidConsistencyTypeCodesCodes: ("439021000124105" | "439031000124108" | "439041000124103" | "439081000124109")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomFluidConsistencyTypeCodesCode(): FluidConsistencyTypeCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomFluidConsistencyTypeCodesConcept(): FluidConsistencyTypeCodesConcept;
