/**
 * ValueSet: diagnosis-role
 * URL: http://hl7.org/fhir/ValueSet/diagnosis-role
 * Size: 7 concepts
 */
export declare const DiagnosisRoleConcepts: readonly [{
    readonly code: "AD";
    readonly system: "http://terminology.hl7.org/CodeSystem/diagnosis-role";
}, {
    readonly code: "DD";
    readonly system: "http://terminology.hl7.org/CodeSystem/diagnosis-role";
}, {
    readonly code: "CC";
    readonly system: "http://terminology.hl7.org/CodeSystem/diagnosis-role";
}, {
    readonly code: "CM";
    readonly system: "http://terminology.hl7.org/CodeSystem/diagnosis-role";
}, {
    readonly code: "pre-op";
    readonly system: "http://terminology.hl7.org/CodeSystem/diagnosis-role";
}, {
    readonly code: "post-op";
    readonly system: "http://terminology.hl7.org/CodeSystem/diagnosis-role";
}, {
    readonly code: "billing";
    readonly system: "http://terminology.hl7.org/CodeSystem/diagnosis-role";
}];
/** Union type of all valid codes in this ValueSet */
export type DiagnosisRoleCode = "AD" | "DD" | "CC" | "CM" | "pre-op" | "post-op" | "billing";
/** Type representing a concept from this ValueSet */
export type DiagnosisRoleConcept = typeof DiagnosisRoleConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidDiagnosisRoleCode(code: string): code is DiagnosisRoleCode;
/**
 * Get concept details by code
 */
export declare function getDiagnosisRoleConcept(code: string): DiagnosisRoleConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const DiagnosisRoleCodes: ("billing" | "CM" | "AD" | "DD" | "CC" | "pre-op" | "post-op")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomDiagnosisRoleCode(): DiagnosisRoleCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomDiagnosisRoleConcept(): DiagnosisRoleConcept;
