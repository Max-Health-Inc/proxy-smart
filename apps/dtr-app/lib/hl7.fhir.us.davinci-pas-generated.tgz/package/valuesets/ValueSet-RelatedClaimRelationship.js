/**
 * ValueSet: related-claim-relationship
 * URL: http://hl7.org/fhir/ValueSet/related-claim-relationship
 * Size: 2 concepts
 */
export const RelatedClaimRelationshipConcepts = [
    { code: "prior", system: "http://terminology.hl7.org/CodeSystem/ex-relatedclaimrelationship" },
    { code: "associated", system: "http://terminology.hl7.org/CodeSystem/ex-relatedclaimrelationship" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidRelatedClaimRelationshipCode(code) {
    return RelatedClaimRelationshipConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getRelatedClaimRelationshipConcept(code) {
    return RelatedClaimRelationshipConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const RelatedClaimRelationshipCodes = RelatedClaimRelationshipConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomRelatedClaimRelationshipCode() {
    return RelatedClaimRelationshipCodes[Math.floor(Math.random() * RelatedClaimRelationshipCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomRelatedClaimRelationshipConcept() {
    return RelatedClaimRelationshipConcepts[Math.floor(Math.random() * RelatedClaimRelationshipConcepts.length)];
}
