/**
 * ValueSet: missing-tooth-reason
 * URL: http://hl7.org/fhir/ValueSet/missing-tooth-reason
 * Size: 4 concepts
 */
export declare const MissingToothReasonConcepts: readonly [{
    readonly code: "e";
    readonly system: "http://terminology.hl7.org/CodeSystem/missingtoothreason";
}, {
    readonly code: "c";
    readonly system: "http://terminology.hl7.org/CodeSystem/missingtoothreason";
}, {
    readonly code: "u";
    readonly system: "http://terminology.hl7.org/CodeSystem/missingtoothreason";
}, {
    readonly code: "o";
    readonly system: "http://terminology.hl7.org/CodeSystem/missingtoothreason";
}];
/** Union type of all valid codes in this ValueSet */
export type MissingToothReasonCode = "e" | "c" | "u" | "o";
/** Type representing a concept from this ValueSet */
export type MissingToothReasonConcept = typeof MissingToothReasonConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidMissingToothReasonCode(code: string): code is MissingToothReasonCode;
/**
 * Get concept details by code
 */
export declare function getMissingToothReasonConcept(code: string): MissingToothReasonConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const MissingToothReasonCodes: ("u" | "c" | "e" | "o")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomMissingToothReasonCode(): MissingToothReasonCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomMissingToothReasonConcept(): MissingToothReasonConcept;
