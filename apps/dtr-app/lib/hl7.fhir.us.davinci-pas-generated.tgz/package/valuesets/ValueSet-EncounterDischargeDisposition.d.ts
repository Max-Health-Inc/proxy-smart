/**
 * ValueSet: encounter-discharge-disposition
 * URL: http://hl7.org/fhir/ValueSet/encounter-discharge-disposition
 * Size: 11 concepts
 */
export declare const EncounterDischargeDispositionConcepts: readonly [{
    readonly code: "home";
    readonly system: "http://terminology.hl7.org/CodeSystem/discharge-disposition";
}, {
    readonly code: "alt-home";
    readonly system: "http://terminology.hl7.org/CodeSystem/discharge-disposition";
}, {
    readonly code: "other-hcf";
    readonly system: "http://terminology.hl7.org/CodeSystem/discharge-disposition";
}, {
    readonly code: "hosp";
    readonly system: "http://terminology.hl7.org/CodeSystem/discharge-disposition";
}, {
    readonly code: "long";
    readonly system: "http://terminology.hl7.org/CodeSystem/discharge-disposition";
}, {
    readonly code: "aadvice";
    readonly system: "http://terminology.hl7.org/CodeSystem/discharge-disposition";
}, {
    readonly code: "exp";
    readonly system: "http://terminology.hl7.org/CodeSystem/discharge-disposition";
}, {
    readonly code: "psy";
    readonly system: "http://terminology.hl7.org/CodeSystem/discharge-disposition";
}, {
    readonly code: "rehab";
    readonly system: "http://terminology.hl7.org/CodeSystem/discharge-disposition";
}, {
    readonly code: "snf";
    readonly system: "http://terminology.hl7.org/CodeSystem/discharge-disposition";
}, {
    readonly code: "oth";
    readonly system: "http://terminology.hl7.org/CodeSystem/discharge-disposition";
}];
/** Union type of all valid codes in this ValueSet */
export type EncounterDischargeDispositionCode = "home" | "alt-home" | "other-hcf" | "hosp" | "long" | "aadvice" | "exp" | "psy" | "rehab" | "snf" | "oth";
/** Type representing a concept from this ValueSet */
export type EncounterDischargeDispositionConcept = typeof EncounterDischargeDispositionConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidEncounterDischargeDispositionCode(code: string): code is EncounterDischargeDispositionCode;
/**
 * Get concept details by code
 */
export declare function getEncounterDischargeDispositionConcept(code: string): EncounterDischargeDispositionConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const EncounterDischargeDispositionCodes: ("home" | "alt-home" | "other-hcf" | "hosp" | "long" | "aadvice" | "exp" | "psy" | "rehab" | "snf" | "oth")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomEncounterDischargeDispositionCode(): EncounterDischargeDispositionCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomEncounterDischargeDispositionConcept(): EncounterDischargeDispositionConcept;
