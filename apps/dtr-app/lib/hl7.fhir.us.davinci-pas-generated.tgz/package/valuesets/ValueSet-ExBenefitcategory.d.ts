/**
 * ValueSet: ex-benefitcategory
 * URL: http://hl7.org/fhir/ValueSet/ex-benefitcategory
 * Size: 28 concepts
 */
export declare const ExBenefitcategoryConcepts: readonly [{
    readonly code: "1";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
}, {
    readonly code: "2";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
}, {
    readonly code: "3";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
}, {
    readonly code: "4";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
}, {
    readonly code: "5";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
}, {
    readonly code: "14";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
}, {
    readonly code: "23";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
}, {
    readonly code: "24";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
}, {
    readonly code: "25";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
}, {
    readonly code: "26";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
}, {
    readonly code: "27";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
}, {
    readonly code: "28";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
}, {
    readonly code: "30";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
}, {
    readonly code: "35";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
}, {
    readonly code: "36";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
}, {
    readonly code: "37";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
}, {
    readonly code: "49";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
}, {
    readonly code: "55";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
}, {
    readonly code: "56";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
}, {
    readonly code: "61";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
}, {
    readonly code: "62";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
}, {
    readonly code: "63";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
}, {
    readonly code: "69";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
}, {
    readonly code: "76";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
}, {
    readonly code: "F1";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
}, {
    readonly code: "F3";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
}, {
    readonly code: "F4";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
}, {
    readonly code: "F6";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory";
}];
/** String type (ValueSet too large for union type) */
export type ExBenefitcategoryCode = string;
/** Type representing a concept from this ValueSet */
export type ExBenefitcategoryConcept = typeof ExBenefitcategoryConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidExBenefitcategoryCode(code: string): code is ExBenefitcategoryCode;
/**
 * Get concept details by code
 */
export declare function getExBenefitcategoryConcept(code: string): ExBenefitcategoryConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ExBenefitcategoryCodes: ("1" | "3" | "2" | "4" | "5" | "14" | "23" | "26" | "24" | "25" | "27" | "28" | "30" | "35" | "36" | "37" | "49" | "55" | "56" | "61" | "62" | "63" | "69" | "76" | "F1" | "F3" | "F4" | "F6")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomExBenefitcategoryCode(): ExBenefitcategoryCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomExBenefitcategoryConcept(): ExBenefitcategoryConcept;
