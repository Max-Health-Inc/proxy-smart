/**
 * ValueSet: adjudication
 * URL: http://hl7.org/fhir/ValueSet/adjudication
 * Size: 8 concepts
 */
export declare const AdjudicationConcepts: readonly [{
    readonly code: "submitted";
    readonly system: "http://terminology.hl7.org/CodeSystem/adjudication";
}, {
    readonly code: "copay";
    readonly system: "http://terminology.hl7.org/CodeSystem/adjudication";
}, {
    readonly code: "eligible";
    readonly system: "http://terminology.hl7.org/CodeSystem/adjudication";
}, {
    readonly code: "deductible";
    readonly system: "http://terminology.hl7.org/CodeSystem/adjudication";
}, {
    readonly code: "unallocdeduct";
    readonly system: "http://terminology.hl7.org/CodeSystem/adjudication";
}, {
    readonly code: "eligpercent";
    readonly system: "http://terminology.hl7.org/CodeSystem/adjudication";
}, {
    readonly code: "tax";
    readonly system: "http://terminology.hl7.org/CodeSystem/adjudication";
}, {
    readonly code: "benefit";
    readonly system: "http://terminology.hl7.org/CodeSystem/adjudication";
}];
/** Union type of all valid codes in this ValueSet */
export type AdjudicationCode = "submitted" | "copay" | "eligible" | "deductible" | "unallocdeduct" | "eligpercent" | "tax" | "benefit";
/** Type representing a concept from this ValueSet */
export type AdjudicationConcept = typeof AdjudicationConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidAdjudicationCode(code: string): code is AdjudicationCode;
/**
 * Get concept details by code
 */
export declare function getAdjudicationConcept(code: string): AdjudicationConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const AdjudicationCodes: ("submitted" | "benefit" | "copay" | "eligible" | "deductible" | "unallocdeduct" | "eligpercent" | "tax")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomAdjudicationCode(): AdjudicationCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomAdjudicationConcept(): AdjudicationConcept;
