/**
 * ValueSet: ExampleProgramReasonCodes
 * URL: http://hl7.org/fhir/ValueSet/ex-program-code
 * Size: 4 concepts
 */
export declare const ExampleProgramReasonCodesConcepts: readonly [{
    readonly code: "as";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-programcode";
    readonly display: "Child Asthma";
}, {
    readonly code: "hd";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-programcode";
    readonly display: "Hemodialysis";
}, {
    readonly code: "auscr";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-programcode";
    readonly display: "Autism Screening";
}, {
    readonly code: "none";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-programcode";
    readonly display: "None";
}];
/** Union type of all valid codes in this ValueSet */
export type ExampleProgramReasonCodesCode = "as" | "hd" | "auscr" | "none";
/** Type representing a concept from this ValueSet */
export type ExampleProgramReasonCodesConcept = typeof ExampleProgramReasonCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidExampleProgramReasonCodesCode(code: string): code is ExampleProgramReasonCodesCode;
/**
 * Get concept details by code
 */
export declare function getExampleProgramReasonCodesConcept(code: string): ExampleProgramReasonCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ExampleProgramReasonCodesCodes: ("auscr" | "as" | "hd" | "none")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomExampleProgramReasonCodesCode(): ExampleProgramReasonCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomExampleProgramReasonCodesConcept(): ExampleProgramReasonCodesConcept;
