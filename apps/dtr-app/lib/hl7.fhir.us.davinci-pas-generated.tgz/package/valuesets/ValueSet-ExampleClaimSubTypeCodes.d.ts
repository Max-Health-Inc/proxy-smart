/**
 * ValueSet: ExampleClaimSubTypeCodes
 * URL: http://hl7.org/fhir/ValueSet/claim-subtype
 * Size: 2 concepts
 */
export declare const ExampleClaimSubTypeCodesConcepts: readonly [{
    readonly code: "ortho";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-claimsubtype";
    readonly display: "Orthodontic Claim";
}, {
    readonly code: "emergency";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-claimsubtype";
    readonly display: "Emergency Claim";
}];
/** Union type of all valid codes in this ValueSet */
export type ExampleClaimSubTypeCodesCode = "ortho" | "emergency";
/** Type representing a concept from this ValueSet */
export type ExampleClaimSubTypeCodesConcept = typeof ExampleClaimSubTypeCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidExampleClaimSubTypeCodesCode(code: string): code is ExampleClaimSubTypeCodesCode;
/**
 * Get concept details by code
 */
export declare function getExampleClaimSubTypeCodesConcept(code: string): ExampleClaimSubTypeCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ExampleClaimSubTypeCodesCodes: ("emergency" | "ortho")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomExampleClaimSubTypeCodesCode(): ExampleClaimSubTypeCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomExampleClaimSubTypeCodesConcept(): ExampleClaimSubTypeCodesConcept;
