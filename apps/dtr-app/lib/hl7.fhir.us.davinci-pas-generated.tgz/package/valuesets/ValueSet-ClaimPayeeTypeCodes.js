/**
 * ValueSet: Claim Payee Type Codes
 * URL: http://hl7.org/fhir/ValueSet/payeetype
 * Size: 3 concepts
 */
export const ClaimPayeeTypeCodesConcepts = [
    { code: "subscriber", system: "http://terminology.hl7.org/CodeSystem/payeetype", display: "Subscriber" },
    { code: "provider", system: "http://terminology.hl7.org/CodeSystem/payeetype", display: "Provider" },
    { code: "other", system: "http://terminology.hl7.org/CodeSystem/payeetype", display: "Provider" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidClaimPayeeTypeCodesCode(code) {
    return ClaimPayeeTypeCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getClaimPayeeTypeCodesConcept(code) {
    return ClaimPayeeTypeCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ClaimPayeeTypeCodesCodes = ClaimPayeeTypeCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomClaimPayeeTypeCodesCode() {
    return ClaimPayeeTypeCodesCodes[Math.floor(Math.random() * ClaimPayeeTypeCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomClaimPayeeTypeCodesConcept() {
    return ClaimPayeeTypeCodesConcepts[Math.floor(Math.random() * ClaimPayeeTypeCodesConcepts.length)];
}
