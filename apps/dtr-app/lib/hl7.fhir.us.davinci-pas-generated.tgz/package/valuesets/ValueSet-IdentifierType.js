/**
 * ValueSet: identifier-type
 * URL: http://hl7.org/fhir/ValueSet/identifier-type
 * Size: 18 concepts
 */
export const IdentifierTypeConcepts = [
    { code: "DL", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
    { code: "PPN", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
    { code: "BRN", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
    { code: "MR", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
    { code: "MCN", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
    { code: "EN", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
    { code: "TAX", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
    { code: "NIIP", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
    { code: "PRN", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
    { code: "MD", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
    { code: "DR", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
    { code: "ACSN", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
    { code: "UDI", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
    { code: "SNO", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
    { code: "SB", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
    { code: "PLAC", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
    { code: "FILL", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
    { code: "JHN", system: "http://terminology.hl7.org/CodeSystem/v2-0203" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidIdentifierTypeCode(code) {
    return IdentifierTypeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getIdentifierTypeConcept(code) {
    return IdentifierTypeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const IdentifierTypeCodes = IdentifierTypeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomIdentifierTypeCode() {
    return IdentifierTypeCodes[Math.floor(Math.random() * IdentifierTypeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomIdentifierTypeConcept() {
    return IdentifierTypeConcepts[Math.floor(Math.random() * IdentifierTypeConcepts.length)];
}
