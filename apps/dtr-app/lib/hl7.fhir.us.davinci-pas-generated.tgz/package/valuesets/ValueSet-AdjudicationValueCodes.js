/**
 * ValueSet: AdjudicationValueCodes
 * URL: http://hl7.org/fhir/ValueSet/adjudication
 * Size: 8 concepts
 */
export const AdjudicationValueCodesConcepts = [
    { code: "submitted", system: "http://terminology.hl7.org/CodeSystem/adjudication", display: "Submitted Amount" },
    { code: "copay", system: "http://terminology.hl7.org/CodeSystem/adjudication", display: "CoPay" },
    { code: "eligible", system: "http://terminology.hl7.org/CodeSystem/adjudication", display: "Eligible Amount" },
    { code: "deductible", system: "http://terminology.hl7.org/CodeSystem/adjudication", display: "Deductible" },
    { code: "unallocdeduct", system: "http://terminology.hl7.org/CodeSystem/adjudication", display: "Unallocated Deductible" },
    { code: "eligpercent", system: "http://terminology.hl7.org/CodeSystem/adjudication", display: "Eligible %" },
    { code: "tax", system: "http://terminology.hl7.org/CodeSystem/adjudication", display: "Tax" },
    { code: "benefit", system: "http://terminology.hl7.org/CodeSystem/adjudication", display: "Benefit Amount" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidAdjudicationValueCodesCode(code) {
    return AdjudicationValueCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getAdjudicationValueCodesConcept(code) {
    return AdjudicationValueCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const AdjudicationValueCodesCodes = AdjudicationValueCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomAdjudicationValueCodesCode() {
    return AdjudicationValueCodesCodes[Math.floor(Math.random() * AdjudicationValueCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomAdjudicationValueCodesConcept() {
    return AdjudicationValueCodesConcepts[Math.floor(Math.random() * AdjudicationValueCodesConcepts.length)];
}
