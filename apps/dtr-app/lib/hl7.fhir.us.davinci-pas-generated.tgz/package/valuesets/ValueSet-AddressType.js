/**
 * ValueSet: address-type
 * URL: http://hl7.org/fhir/ValueSet/address-type
 * Size: 3 concepts
 */
export const AddressTypeConcepts = [
    { code: "postal", system: "http://hl7.org/fhir/address-type" },
    { code: "physical", system: "http://hl7.org/fhir/address-type" },
    { code: "both", system: "http://hl7.org/fhir/address-type" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidAddressTypeCode(code) {
    return AddressTypeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getAddressTypeConcept(code) {
    return AddressTypeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const AddressTypeCodes = AddressTypeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomAddressTypeCode() {
    return AddressTypeCodes[Math.floor(Math.random() * AddressTypeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomAddressTypeConcept() {
    return AddressTypeConcepts[Math.floor(Math.random() * AddressTypeConcepts.length)];
}
