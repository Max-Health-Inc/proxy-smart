/**
 * ValueSet: ExampleDiagnosisOnAdmissionCodes
 * URL: http://hl7.org/fhir/ValueSet/ex-diagnosis-on-admission
 * Size: 4 concepts
 */
export const ExampleDiagnosisOnAdmissionCodesConcepts = [
    { code: "y", system: "http://terminology.hl7.org/CodeSystem/ex-diagnosis-on-admission", display: "Yes" },
    { code: "n", system: "http://terminology.hl7.org/CodeSystem/ex-diagnosis-on-admission", display: "No" },
    { code: "u", system: "http://terminology.hl7.org/CodeSystem/ex-diagnosis-on-admission", display: "Unknown" },
    { code: "w", system: "http://terminology.hl7.org/CodeSystem/ex-diagnosis-on-admission", display: "Undetermined" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidExampleDiagnosisOnAdmissionCodesCode(code) {
    return ExampleDiagnosisOnAdmissionCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getExampleDiagnosisOnAdmissionCodesConcept(code) {
    return ExampleDiagnosisOnAdmissionCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ExampleDiagnosisOnAdmissionCodesCodes = ExampleDiagnosisOnAdmissionCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomExampleDiagnosisOnAdmissionCodesCode() {
    return ExampleDiagnosisOnAdmissionCodesCodes[Math.floor(Math.random() * ExampleDiagnosisOnAdmissionCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomExampleDiagnosisOnAdmissionCodesConcept() {
    return ExampleDiagnosisOnAdmissionCodesConcepts[Math.floor(Math.random() * ExampleDiagnosisOnAdmissionCodesConcepts.length)];
}
