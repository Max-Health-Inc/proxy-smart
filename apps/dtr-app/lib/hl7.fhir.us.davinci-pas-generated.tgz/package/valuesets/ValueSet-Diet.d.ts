/**
 * ValueSet: Diet
 * URL: http://hl7.org/fhir/ValueSet/encounter-diet
 * Size: 7 concepts
 */
export declare const DietConcepts: readonly [{
    readonly code: "vegetarian";
    readonly system: "http://terminology.hl7.org/CodeSystem/diet";
    readonly display: "Vegetarian";
}, {
    readonly code: "dairy-free";
    readonly system: "http://terminology.hl7.org/CodeSystem/diet";
    readonly display: "Dairy Free";
}, {
    readonly code: "nut-free";
    readonly system: "http://terminology.hl7.org/CodeSystem/diet";
    readonly display: "Nut Free";
}, {
    readonly code: "gluten-free";
    readonly system: "http://terminology.hl7.org/CodeSystem/diet";
    readonly display: "Gluten Free";
}, {
    readonly code: "vegan";
    readonly system: "http://terminology.hl7.org/CodeSystem/diet";
    readonly display: "Vegan";
}, {
    readonly code: "halal";
    readonly system: "http://terminology.hl7.org/CodeSystem/diet";
    readonly display: "Halal";
}, {
    readonly code: "kosher";
    readonly system: "http://terminology.hl7.org/CodeSystem/diet";
    readonly display: "Kosher";
}];
/** Union type of all valid codes in this ValueSet */
export type DietCode = "vegetarian" | "dairy-free" | "nut-free" | "gluten-free" | "vegan" | "halal" | "kosher";
/** Type representing a concept from this ValueSet */
export type DietConcept = typeof DietConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidDietCode(code: string): code is DietCode;
/**
 * Get concept details by code
 */
export declare function getDietConcept(code: string): DietConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const DietCodes: ("vegetarian" | "dairy-free" | "nut-free" | "gluten-free" | "vegan" | "halal" | "kosher")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomDietCode(): DietCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomDietConcept(): DietConcept;
