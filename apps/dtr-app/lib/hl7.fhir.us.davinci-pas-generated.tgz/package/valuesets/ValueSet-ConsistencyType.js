/**
 * ValueSet: consistency-type
 * URL: http://hl7.org/fhir/ValueSet/consistency-type
 * Size: 4 concepts
 */
export const ConsistencyTypeConcepts = [
    { code: "439031000124108", system: "http://snomed.info/sct" },
    { code: "439021000124105", system: "http://snomed.info/sct" },
    { code: "439041000124103", system: "http://snomed.info/sct" },
    { code: "439081000124109", system: "http://snomed.info/sct" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidConsistencyTypeCode(code) {
    return ConsistencyTypeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getConsistencyTypeConcept(code) {
    return ConsistencyTypeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ConsistencyTypeCodes = ConsistencyTypeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomConsistencyTypeCode() {
    return ConsistencyTypeCodes[Math.floor(Math.random() * ConsistencyTypeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomConsistencyTypeConcept() {
    return ConsistencyTypeConcepts[Math.floor(Math.random() * ConsistencyTypeConcepts.length)];
}
