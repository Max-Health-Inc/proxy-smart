/**
 * ValueSet: ExampleProviderQualificationCodes
 * URL: http://hl7.org/fhir/ValueSet/provider-qualification
 * Size: 3 concepts
 */
export declare const ExampleProviderQualificationCodesConcepts: readonly [{
    readonly code: "311405";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-providerqualification";
    readonly display: "Dentist";
}, {
    readonly code: "604215";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-providerqualification";
    readonly display: "Ophthalmologist";
}, {
    readonly code: "604210";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-providerqualification";
    readonly display: "Optometrist";
}];
/** Union type of all valid codes in this ValueSet */
export type ExampleProviderQualificationCodesCode = "311405" | "604215" | "604210";
/** Type representing a concept from this ValueSet */
export type ExampleProviderQualificationCodesConcept = typeof ExampleProviderQualificationCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidExampleProviderQualificationCodesCode(code: string): code is ExampleProviderQualificationCodesCode;
/**
 * Get concept details by code
 */
export declare function getExampleProviderQualificationCodesConcept(code: string): ExampleProviderQualificationCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ExampleProviderQualificationCodesCodes: ("311405" | "604215" | "604210")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomExampleProviderQualificationCodesCode(): ExampleProviderQualificationCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomExampleProviderQualificationCodesConcept(): ExampleProviderQualificationCodesConcept;
