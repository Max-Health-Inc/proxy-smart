/**
 * ValueSet: ExampleRevenueCenterCodes
 * URL: http://hl7.org/fhir/ValueSet/ex-revenue-center
 * Size: 9 concepts
 */
export declare const ExampleRevenueCenterCodesConcepts: readonly [{
    readonly code: "0370";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center";
    readonly display: "Anaesthesia";
}, {
    readonly code: "0420";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center";
    readonly display: "Physical Therapy";
}, {
    readonly code: "0421";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center";
    readonly display: "Physical Therapy - ";
}, {
    readonly code: "0440";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center";
    readonly display: "Speech-Language Pathology";
}, {
    readonly code: "0441";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center";
    readonly display: "Speech-Language Pathology - Visit";
}, {
    readonly code: "0450";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center";
    readonly display: "Emergency Room";
}, {
    readonly code: "0451";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center";
    readonly display: "Emergency Room - EM/EMTALA";
}, {
    readonly code: "0452";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center";
    readonly display: "Emergency Room - beyond EMTALA";
}, {
    readonly code: "0010";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center";
    readonly display: "Vision Clinic";
}];
/** Union type of all valid codes in this ValueSet */
export type ExampleRevenueCenterCodesCode = "0370" | "0420" | "0421" | "0440" | "0441" | "0450" | "0451" | "0452" | "0010";
/** Type representing a concept from this ValueSet */
export type ExampleRevenueCenterCodesConcept = typeof ExampleRevenueCenterCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidExampleRevenueCenterCodesCode(code: string): code is ExampleRevenueCenterCodesCode;
/**
 * Get concept details by code
 */
export declare function getExampleRevenueCenterCodesConcept(code: string): ExampleRevenueCenterCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ExampleRevenueCenterCodesCodes: ("0451" | "0370" | "0420" | "0421" | "0440" | "0441" | "0450" | "0452" | "0010")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomExampleRevenueCenterCodesCode(): ExampleRevenueCenterCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomExampleRevenueCenterCodesConcept(): ExampleRevenueCenterCodesConcept;
