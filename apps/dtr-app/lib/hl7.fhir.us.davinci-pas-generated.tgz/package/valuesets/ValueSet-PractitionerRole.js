/**
 * ValueSet: practitioner-role
 * URL: http://hl7.org/fhir/ValueSet/practitioner-role
 * Size: 6 concepts
 */
export const PractitionerRoleConcepts = [
    { code: "doctor", system: "http://terminology.hl7.org/CodeSystem/practitioner-role" },
    { code: "nurse", system: "http://terminology.hl7.org/CodeSystem/practitioner-role" },
    { code: "pharmacist", system: "http://terminology.hl7.org/CodeSystem/practitioner-role" },
    { code: "researcher", system: "http://terminology.hl7.org/CodeSystem/practitioner-role" },
    { code: "teacher", system: "http://terminology.hl7.org/CodeSystem/practitioner-role" },
    { code: "ict", system: "http://terminology.hl7.org/CodeSystem/practitioner-role" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidPractitionerRoleCode(code) {
    return PractitionerRoleConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getPractitionerRoleConcept(code) {
    return PractitionerRoleConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const PractitionerRoleCodes = PractitionerRoleConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomPractitionerRoleCode() {
    return PractitionerRoleCodes[Math.floor(Math.random() * PractitionerRoleCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomPractitionerRoleConcept() {
    return PractitionerRoleConcepts[Math.floor(Math.random() * PractitionerRoleConcepts.length)];
}
