/**
 * ValueSet: ParticipantType
 * URL: http://hl7.org/fhir/ValueSet/encounter-participant-type
 * Size: Infinity concepts
 */
export const ParticipantTypeConcepts = [
    { code: "SPRF", system: "http://terminology.hl7.org/CodeSystem/v3-ParticipationType" },
    { code: "PPRF", system: "http://terminology.hl7.org/CodeSystem/v3-ParticipationType" },
    { code: "PART", system: "http://terminology.hl7.org/CodeSystem/v3-ParticipationType" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidParticipantTypeCode(code) {
    return ParticipantTypeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getParticipantTypeConcept(code) {
    return ParticipantTypeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ParticipantTypeCodes = ParticipantTypeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomParticipantTypeCode() {
    return ParticipantTypeCodes[Math.floor(Math.random() * ParticipantTypeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomParticipantTypeConcept() {
    return ParticipantTypeConcepts[Math.floor(Math.random() * ParticipantTypeConcepts.length)];
}
