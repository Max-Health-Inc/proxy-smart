/**
 * ValueSet: claim-type
 * URL: http://hl7.org/fhir/ValueSet/claim-type
 * Size: 5 concepts
 */
export declare const ClaimTypeConcepts: readonly [{
    readonly code: "institutional";
    readonly system: "http://terminology.hl7.org/CodeSystem/claim-type";
}, {
    readonly code: "oral";
    readonly system: "http://terminology.hl7.org/CodeSystem/claim-type";
}, {
    readonly code: "pharmacy";
    readonly system: "http://terminology.hl7.org/CodeSystem/claim-type";
}, {
    readonly code: "professional";
    readonly system: "http://terminology.hl7.org/CodeSystem/claim-type";
}, {
    readonly code: "vision";
    readonly system: "http://terminology.hl7.org/CodeSystem/claim-type";
}];
/** Union type of all valid codes in this ValueSet */
export type ClaimTypeCode = "institutional" | "oral" | "pharmacy" | "professional" | "vision";
/** Type representing a concept from this ValueSet */
export type ClaimTypeConcept = typeof ClaimTypeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidClaimTypeCode(code: string): code is ClaimTypeCode;
/**
 * Get concept details by code
 */
export declare function getClaimTypeConcept(code: string): ClaimTypeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ClaimTypeCodes: ("professional" | "pharmacy" | "institutional" | "oral" | "vision")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomClaimTypeCode(): ClaimTypeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomClaimTypeConcept(): ClaimTypeConcept;
