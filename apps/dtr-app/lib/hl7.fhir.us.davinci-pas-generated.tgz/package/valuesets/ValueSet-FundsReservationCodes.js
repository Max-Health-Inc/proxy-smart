/**
 * ValueSet: Funds Reservation Codes
 * URL: http://hl7.org/fhir/ValueSet/fundsreserve
 * Size: 3 concepts
 */
export const FundsReservationCodesConcepts = [
    { code: "patient", system: "http://terminology.hl7.org/CodeSystem/fundsreserve", display: "Patient" },
    { code: "provider", system: "http://terminology.hl7.org/CodeSystem/fundsreserve", display: "Provider" },
    { code: "none", system: "http://terminology.hl7.org/CodeSystem/fundsreserve", display: "None" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidFundsReservationCodesCode(code) {
    return FundsReservationCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getFundsReservationCodesConcept(code) {
    return FundsReservationCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const FundsReservationCodesCodes = FundsReservationCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomFundsReservationCodesCode() {
    return FundsReservationCodesCodes[Math.floor(Math.random() * FundsReservationCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomFundsReservationCodesConcept() {
    return FundsReservationCodesConcepts[Math.floor(Math.random() * FundsReservationCodesConcepts.length)];
}
