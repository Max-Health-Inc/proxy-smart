/**
 * ValueSet: v3-ActPriority
 * URL: http://terminology.hl7.org/ValueSet/v3-ActPriority
 * Size: 12 concepts
 */
export declare const V3ActPriorityConcepts: readonly [{
    readonly code: "A";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActPriority";
}, {
    readonly code: "CR";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActPriority";
}, {
    readonly code: "EL";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActPriority";
}, {
    readonly code: "EM";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActPriority";
}, {
    readonly code: "P";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActPriority";
}, {
    readonly code: "PRN";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActPriority";
}, {
    readonly code: "R";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActPriority";
}, {
    readonly code: "RR";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActPriority";
}, {
    readonly code: "S";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActPriority";
}, {
    readonly code: "T";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActPriority";
}, {
    readonly code: "UD";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActPriority";
}, {
    readonly code: "UR";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActPriority";
}];
/** Union type of all valid codes in this ValueSet */
export type V3ActPriorityCode = "A" | "CR" | "EL" | "EM" | "P" | "PRN" | "R" | "RR" | "S" | "T" | "UD" | "UR";
/** Type representing a concept from this ValueSet */
export type V3ActPriorityConcept = typeof V3ActPriorityConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidV3ActPriorityCode(code: string): code is V3ActPriorityCode;
/**
 * Get concept details by code
 */
export declare function getV3ActPriorityConcept(code: string): V3ActPriorityConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const V3ActPriorityCodes: ("R" | "T" | "A" | "CR" | "EL" | "EM" | "P" | "PRN" | "RR" | "S" | "UD" | "UR")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomV3ActPriorityCode(): V3ActPriorityCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomV3ActPriorityConcept(): V3ActPriorityConcept;
