/**
 * ValueSet: encounter-diet
 * URL: http://hl7.org/fhir/ValueSet/encounter-diet
 * Size: 7 concepts
 */
export declare const EncounterDietConcepts: readonly [{
    readonly code: "vegetarian";
    readonly system: "http://terminology.hl7.org/CodeSystem/diet";
}, {
    readonly code: "dairy-free";
    readonly system: "http://terminology.hl7.org/CodeSystem/diet";
}, {
    readonly code: "nut-free";
    readonly system: "http://terminology.hl7.org/CodeSystem/diet";
}, {
    readonly code: "gluten-free";
    readonly system: "http://terminology.hl7.org/CodeSystem/diet";
}, {
    readonly code: "vegan";
    readonly system: "http://terminology.hl7.org/CodeSystem/diet";
}, {
    readonly code: "halal";
    readonly system: "http://terminology.hl7.org/CodeSystem/diet";
}, {
    readonly code: "kosher";
    readonly system: "http://terminology.hl7.org/CodeSystem/diet";
}];
/** Union type of all valid codes in this ValueSet */
export type EncounterDietCode = "vegetarian" | "dairy-free" | "nut-free" | "gluten-free" | "vegan" | "halal" | "kosher";
/** Type representing a concept from this ValueSet */
export type EncounterDietConcept = typeof EncounterDietConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidEncounterDietCode(code: string): code is EncounterDietCode;
/**
 * Get concept details by code
 */
export declare function getEncounterDietConcept(code: string): EncounterDietConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const EncounterDietCodes: ("vegetarian" | "dairy-free" | "nut-free" | "gluten-free" | "vegan" | "halal" | "kosher")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomEncounterDietCode(): EncounterDietCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomEncounterDietConcept(): EncounterDietConcept;
