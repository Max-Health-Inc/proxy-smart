/**
 * ValueSet: coverage-financial-exception
 * URL: http://hl7.org/fhir/ValueSet/coverage-financial-exception
 * Size: 2 concepts
 */
export const CoverageFinancialExceptionConcepts = [
    { code: "retired", system: "http://terminology.hl7.org/CodeSystem/ex-coverage-financial-exception" },
    { code: "foster", system: "http://terminology.hl7.org/CodeSystem/ex-coverage-financial-exception" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidCoverageFinancialExceptionCode(code) {
    return CoverageFinancialExceptionConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getCoverageFinancialExceptionConcept(code) {
    return CoverageFinancialExceptionConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const CoverageFinancialExceptionCodes = CoverageFinancialExceptionConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomCoverageFinancialExceptionCode() {
    return CoverageFinancialExceptionCodes[Math.floor(Math.random() * CoverageFinancialExceptionCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomCoverageFinancialExceptionConcept() {
    return CoverageFinancialExceptionConcepts[Math.floor(Math.random() * CoverageFinancialExceptionConcepts.length)];
}
