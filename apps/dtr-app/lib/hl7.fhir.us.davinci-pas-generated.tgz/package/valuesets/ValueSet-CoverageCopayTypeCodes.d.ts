/**
 * ValueSet: CoverageCopayTypeCodes
 * URL: http://hl7.org/fhir/ValueSet/coverage-copay-type
 * Size: 10 concepts
 */
export declare const CoverageCopayTypeCodesConcepts: readonly [{
    readonly code: "gpvisit";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type";
    readonly display: "GP Office Visit";
}, {
    readonly code: "spvisit";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type";
    readonly display: "Specialist Office Visit";
}, {
    readonly code: "emergency";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type";
    readonly display: "Emergency";
}, {
    readonly code: "inpthosp";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type";
    readonly display: "Inpatient Hospital";
}, {
    readonly code: "televisit";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type";
    readonly display: "Tele-visit";
}, {
    readonly code: "urgentcare";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type";
    readonly display: "Urgent Care";
}, {
    readonly code: "copaypct";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type";
    readonly display: "Copay Percentage";
}, {
    readonly code: "copay";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type";
    readonly display: "Copay Amount";
}, {
    readonly code: "deductible";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type";
    readonly display: "Deductible";
}, {
    readonly code: "maxoutofpocket";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type";
    readonly display: "Maximum out of pocket";
}];
/** Union type of all valid codes in this ValueSet */
export type CoverageCopayTypeCodesCode = "gpvisit" | "spvisit" | "emergency" | "inpthosp" | "televisit" | "urgentcare" | "copaypct" | "copay" | "deductible" | "maxoutofpocket";
/** Type representing a concept from this ValueSet */
export type CoverageCopayTypeCodesConcept = typeof CoverageCopayTypeCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidCoverageCopayTypeCodesCode(code: string): code is CoverageCopayTypeCodesCode;
/**
 * Get concept details by code
 */
export declare function getCoverageCopayTypeCodesConcept(code: string): CoverageCopayTypeCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const CoverageCopayTypeCodesCodes: ("televisit" | "copay" | "deductible" | "gpvisit" | "spvisit" | "emergency" | "inpthosp" | "urgentcare" | "copaypct" | "maxoutofpocket")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomCoverageCopayTypeCodesCode(): CoverageCopayTypeCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomCoverageCopayTypeCodesConcept(): CoverageCopayTypeCodesConcept;
