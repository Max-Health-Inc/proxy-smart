/**
 * ValueSet: OperationOutcomeCodes
 * URL: http://hl7.org/fhir/ValueSet/operation-outcome
 * Size: 50 concepts
 */
export const OperationOutcomeCodesConcepts = [
    { code: "DELETE_MULTIPLE_MATCHES", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Error: Multiple matches exist for the conditional delete" },
    { code: "MSG_AUTH_REQUIRED", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "You must authenticate before you can use this service" },
    { code: "MSG_BAD_FORMAT", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Bad Syntax: \"%s\" must be a %s'" },
    { code: "MSG_BAD_SYNTAX", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Bad Syntax in %s" },
    { code: "MSG_CANT_PARSE_CONTENT", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Unable to parse feed (entry content type = \"%s\")" },
    { code: "MSG_CANT_PARSE_ROOT", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Unable to parse feed (root element name = \"%s\")" },
    { code: "MSG_CREATED", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "New resource created" },
    { code: "MSG_DATE_FORMAT", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "The Date value %s is not in the correct format (Xml Date Format required)" },
    { code: "MSG_DELETED", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "This resource has been deleted" },
    { code: "MSG_DELETED_DONE", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Resource deleted" },
    { code: "MSG_DELETED_ID", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "The resource \"%s\" has been deleted" },
    { code: "MSG_DUPLICATE_ID", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Duplicate Id %s for resource type %s" },
    { code: "MSG_ERROR_PARSING", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Error parsing resource Xml (%s)" },
    { code: "MSG_ID_INVALID", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Id \"%s\" has an invalid character \"%s\"" },
    { code: "MSG_ID_TOO_LONG", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Id \"%s\" too long (length limit 36)" },
    { code: "MSG_INVALID_ID", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Id not accepted" },
    { code: "MSG_JSON_OBJECT", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Json Source for a resource should start with an object" },
    { code: "MSG_LOCAL_FAIL", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Unable to resolve local reference to resource %s" },
    { code: "MSG_NO_EXIST", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Resource Id \"%s\" does not exist" },
    { code: "MSG_NO_MATCH", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "No Resource found matching the query \"%s\"" },
    { code: "MSG_NO_MODULE", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "No module could be found to handle the request \"%s\"" },
    { code: "MSG_NO_SUMMARY", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "No Summary for this resource" },
    { code: "MSG_OP_NOT_ALLOWED", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Operation %s not allowed for resource %s (due to local configuration)" },
    { code: "MSG_PARAM_CHAINED", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Unknown chained parameter name \"%s\"" },
    { code: "MSG_PARAM_INVALID", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Parameter \"%s\" content is invalid" },
    { code: "MSG_PARAM_MODIFIER_INVALID", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Parameter \"%s\" modifier is invalid" },
    { code: "MSG_PARAM_NO_REPEAT", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Parameter \"%s\" is not allowed to repeat" },
    { code: "MSG_PARAM_UNKNOWN", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Parameter \"%s\" not understood" },
    { code: "MSG_RESOURCE_EXAMPLE_PROTECTED", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Resources with identity \"example\" cannot be deleted (for testing/training purposes)" },
    { code: "MSG_RESOURCE_ID_FAIL", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "unable to allocate resource id" },
    { code: "MSG_RESOURCE_ID_MISMATCH", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Resource Id Mismatch" },
    { code: "MSG_RESOURCE_ID_MISSING", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Resource Id Missing" },
    { code: "MSG_RESOURCE_NOT_ALLOWED", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Not allowed to submit a resource for this operation" },
    { code: "MSG_RESOURCE_REQUIRED", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "A resource is required" },
    { code: "MSG_RESOURCE_TYPE_MISMATCH", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Resource Type Mismatch" },
    { code: "MSG_SORT_UNKNOWN", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Unknown sort parameter name \"%s\"" },
    { code: "MSG_TRANSACTION_DUPLICATE_ID", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Duplicate Identifier in transaction: %s" },
    { code: "MSG_TRANSACTION_MISSING_ID", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Missing Identifier in transaction - an entry.id must be provided" },
    { code: "MSG_UNHANDLED_NODE_TYPE", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Unhandled xml node type \"%s\"" },
    { code: "MSG_UNKNOWN_CONTENT", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Unknown Content (%s) at %s" },
    { code: "MSG_UNKNOWN_OPERATION", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "unknown FHIR http operation" },
    { code: "MSG_UNKNOWN_TYPE", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Resource Type \"%s\" not recognised" },
    { code: "MSG_UPDATED", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "existing resource updated" },
    { code: "MSG_VERSION_AWARE", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Version aware updates are required for this resource" },
    { code: "MSG_VERSION_AWARE_CONFLICT", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Update Conflict (server current version = \"%s\", client version referenced = \"%s\")" },
    { code: "MSG_VERSION_AWARE_URL", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Version specific URL not recognised" },
    { code: "MSG_WRONG_NS", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "This does not appear to be a FHIR element or resource (wrong namespace \"%s\")" },
    { code: "SEARCH_MULTIPLE", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Error: Multiple matches exist for %s search parameters \"%s\"" },
    { code: "SEARCH_NONE", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Error: no processable search found for %s search parameters \"%s\"" },
    { code: "UPDATE_MULTIPLE_MATCHES", system: "http://terminology.hl7.org/CodeSystem/operation-outcome", display: "Error: Multiple matches exist for the conditional update" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidOperationOutcomeCodesCode(code) {
    return OperationOutcomeCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getOperationOutcomeCodesConcept(code) {
    return OperationOutcomeCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const OperationOutcomeCodesCodes = OperationOutcomeCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomOperationOutcomeCodesCode() {
    return OperationOutcomeCodesCodes[Math.floor(Math.random() * OperationOutcomeCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomOperationOutcomeCodesConcept() {
    return OperationOutcomeCodesConcepts[Math.floor(Math.random() * OperationOutcomeCodesConcepts.length)];
}
