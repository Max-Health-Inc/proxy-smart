/**
 * ValueSet: remittance-outcome
 * URL: http://hl7.org/fhir/ValueSet/remittance-outcome
 * Size: 4 concepts
 */
export declare const RemittanceOutcomeConcepts: readonly [{
    readonly code: "queued";
    readonly system: "http://hl7.org/fhir/remittance-outcome";
}, {
    readonly code: "complete";
    readonly system: "http://hl7.org/fhir/remittance-outcome";
}, {
    readonly code: "error";
    readonly system: "http://hl7.org/fhir/remittance-outcome";
}, {
    readonly code: "partial";
    readonly system: "http://hl7.org/fhir/remittance-outcome";
}];
/** Union type of all valid codes in this ValueSet */
export type RemittanceOutcomeCode = "queued" | "complete" | "error" | "partial";
/** Type representing a concept from this ValueSet */
export type RemittanceOutcomeConcept = typeof RemittanceOutcomeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidRemittanceOutcomeCode(code: string): code is RemittanceOutcomeCode;
/**
 * Get concept details by code
 */
export declare function getRemittanceOutcomeConcept(code: string): RemittanceOutcomeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const RemittanceOutcomeCodes: ("complete" | "queued" | "error" | "partial")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomRemittanceOutcomeCode(): RemittanceOutcomeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomRemittanceOutcomeConcept(): RemittanceOutcomeConcept;
