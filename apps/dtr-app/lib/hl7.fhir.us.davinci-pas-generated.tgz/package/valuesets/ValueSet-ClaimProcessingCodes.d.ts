/**
 * ValueSet: ClaimProcessingCodes
 * URL: http://hl7.org/fhir/ValueSet/remittance-outcome
 * Size: 4 concepts
 */
export declare const ClaimProcessingCodesConcepts: readonly [{
    readonly code: "queued";
    readonly system: "http://hl7.org/fhir/remittance-outcome";
    readonly display: "Queued";
}, {
    readonly code: "complete";
    readonly system: "http://hl7.org/fhir/remittance-outcome";
    readonly display: "Processing Complete";
}, {
    readonly code: "error";
    readonly system: "http://hl7.org/fhir/remittance-outcome";
    readonly display: "Error";
}, {
    readonly code: "partial";
    readonly system: "http://hl7.org/fhir/remittance-outcome";
    readonly display: "Partial Processing";
}];
/** Union type of all valid codes in this ValueSet */
export type ClaimProcessingCodesCode = "queued" | "complete" | "error" | "partial";
/** Type representing a concept from this ValueSet */
export type ClaimProcessingCodesConcept = typeof ClaimProcessingCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidClaimProcessingCodesCode(code: string): code is ClaimProcessingCodesCode;
/**
 * Get concept details by code
 */
export declare function getClaimProcessingCodesConcept(code: string): ClaimProcessingCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ClaimProcessingCodesCodes: ("complete" | "queued" | "error" | "partial")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomClaimProcessingCodesCode(): ClaimProcessingCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomClaimProcessingCodesConcept(): ClaimProcessingCodesConcept;
