/**
 * ValueSet: ClaimInformationCategoryCodes
 * URL: http://hl7.org/fhir/ValueSet/claim-informationcategory
 * Size: 14 concepts
 */
export const ClaimInformationCategoryCodesConcepts = [
    { code: "info", system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory", display: "Information" },
    { code: "discharge", system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory", display: "Discharge" },
    { code: "onset", system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory", display: "Onset" },
    { code: "related", system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory", display: "Related Services" },
    { code: "exception", system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory", display: "Exception" },
    { code: "material", system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory", display: "Materials Forwarded" },
    { code: "attachment", system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory", display: "Attachment" },
    { code: "missingtooth", system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory", display: "Missing Tooth" },
    { code: "prosthesis", system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory", display: "Prosthesis" },
    { code: "other", system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory", display: "Other" },
    { code: "hospitalized", system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory", display: "Hospitalized" },
    { code: "employmentimpacted", system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory", display: "EmploymentImpacted" },
    { code: "externalcause", system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory", display: "External Caause" },
    { code: "patientreasonforvisit", system: "http://terminology.hl7.org/CodeSystem/claiminformationcategory", display: "Patient Reason for Visit" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidClaimInformationCategoryCodesCode(code) {
    return ClaimInformationCategoryCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getClaimInformationCategoryCodesConcept(code) {
    return ClaimInformationCategoryCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ClaimInformationCategoryCodesCodes = ClaimInformationCategoryCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomClaimInformationCategoryCodesCode() {
    return ClaimInformationCategoryCodesCodes[Math.floor(Math.random() * ClaimInformationCategoryCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomClaimInformationCategoryCodesConcept() {
    return ClaimInformationCategoryCodesConcepts[Math.floor(Math.random() * ClaimInformationCategoryCodesConcepts.length)];
}
