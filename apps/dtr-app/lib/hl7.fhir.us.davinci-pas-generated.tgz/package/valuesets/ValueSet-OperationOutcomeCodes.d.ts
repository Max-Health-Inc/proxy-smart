/**
 * ValueSet: OperationOutcomeCodes
 * URL: http://hl7.org/fhir/ValueSet/operation-outcome
 * Size: 50 concepts
 */
export declare const OperationOutcomeCodesConcepts: readonly [{
    readonly code: "DELETE_MULTIPLE_MATCHES";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Error: Multiple matches exist for the conditional delete";
}, {
    readonly code: "MSG_AUTH_REQUIRED";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "You must authenticate before you can use this service";
}, {
    readonly code: "MSG_BAD_FORMAT";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Bad Syntax: \"%s\" must be a %s'";
}, {
    readonly code: "MSG_BAD_SYNTAX";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Bad Syntax in %s";
}, {
    readonly code: "MSG_CANT_PARSE_CONTENT";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Unable to parse feed (entry content type = \"%s\")";
}, {
    readonly code: "MSG_CANT_PARSE_ROOT";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Unable to parse feed (root element name = \"%s\")";
}, {
    readonly code: "MSG_CREATED";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "New resource created";
}, {
    readonly code: "MSG_DATE_FORMAT";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "The Date value %s is not in the correct format (Xml Date Format required)";
}, {
    readonly code: "MSG_DELETED";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "This resource has been deleted";
}, {
    readonly code: "MSG_DELETED_DONE";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Resource deleted";
}, {
    readonly code: "MSG_DELETED_ID";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "The resource \"%s\" has been deleted";
}, {
    readonly code: "MSG_DUPLICATE_ID";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Duplicate Id %s for resource type %s";
}, {
    readonly code: "MSG_ERROR_PARSING";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Error parsing resource Xml (%s)";
}, {
    readonly code: "MSG_ID_INVALID";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Id \"%s\" has an invalid character \"%s\"";
}, {
    readonly code: "MSG_ID_TOO_LONG";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Id \"%s\" too long (length limit 36)";
}, {
    readonly code: "MSG_INVALID_ID";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Id not accepted";
}, {
    readonly code: "MSG_JSON_OBJECT";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Json Source for a resource should start with an object";
}, {
    readonly code: "MSG_LOCAL_FAIL";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Unable to resolve local reference to resource %s";
}, {
    readonly code: "MSG_NO_EXIST";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Resource Id \"%s\" does not exist";
}, {
    readonly code: "MSG_NO_MATCH";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "No Resource found matching the query \"%s\"";
}, {
    readonly code: "MSG_NO_MODULE";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "No module could be found to handle the request \"%s\"";
}, {
    readonly code: "MSG_NO_SUMMARY";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "No Summary for this resource";
}, {
    readonly code: "MSG_OP_NOT_ALLOWED";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Operation %s not allowed for resource %s (due to local configuration)";
}, {
    readonly code: "MSG_PARAM_CHAINED";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Unknown chained parameter name \"%s\"";
}, {
    readonly code: "MSG_PARAM_INVALID";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Parameter \"%s\" content is invalid";
}, {
    readonly code: "MSG_PARAM_MODIFIER_INVALID";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Parameter \"%s\" modifier is invalid";
}, {
    readonly code: "MSG_PARAM_NO_REPEAT";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Parameter \"%s\" is not allowed to repeat";
}, {
    readonly code: "MSG_PARAM_UNKNOWN";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Parameter \"%s\" not understood";
}, {
    readonly code: "MSG_RESOURCE_EXAMPLE_PROTECTED";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Resources with identity \"example\" cannot be deleted (for testing/training purposes)";
}, {
    readonly code: "MSG_RESOURCE_ID_FAIL";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "unable to allocate resource id";
}, {
    readonly code: "MSG_RESOURCE_ID_MISMATCH";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Resource Id Mismatch";
}, {
    readonly code: "MSG_RESOURCE_ID_MISSING";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Resource Id Missing";
}, {
    readonly code: "MSG_RESOURCE_NOT_ALLOWED";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Not allowed to submit a resource for this operation";
}, {
    readonly code: "MSG_RESOURCE_REQUIRED";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "A resource is required";
}, {
    readonly code: "MSG_RESOURCE_TYPE_MISMATCH";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Resource Type Mismatch";
}, {
    readonly code: "MSG_SORT_UNKNOWN";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Unknown sort parameter name \"%s\"";
}, {
    readonly code: "MSG_TRANSACTION_DUPLICATE_ID";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Duplicate Identifier in transaction: %s";
}, {
    readonly code: "MSG_TRANSACTION_MISSING_ID";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Missing Identifier in transaction - an entry.id must be provided";
}, {
    readonly code: "MSG_UNHANDLED_NODE_TYPE";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Unhandled xml node type \"%s\"";
}, {
    readonly code: "MSG_UNKNOWN_CONTENT";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Unknown Content (%s) at %s";
}, {
    readonly code: "MSG_UNKNOWN_OPERATION";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "unknown FHIR http operation";
}, {
    readonly code: "MSG_UNKNOWN_TYPE";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Resource Type \"%s\" not recognised";
}, {
    readonly code: "MSG_UPDATED";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "existing resource updated";
}, {
    readonly code: "MSG_VERSION_AWARE";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Version aware updates are required for this resource";
}, {
    readonly code: "MSG_VERSION_AWARE_CONFLICT";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Update Conflict (server current version = \"%s\", client version referenced = \"%s\")";
}, {
    readonly code: "MSG_VERSION_AWARE_URL";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Version specific URL not recognised";
}, {
    readonly code: "MSG_WRONG_NS";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "This does not appear to be a FHIR element or resource (wrong namespace \"%s\")";
}, {
    readonly code: "SEARCH_MULTIPLE";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Error: Multiple matches exist for %s search parameters \"%s\"";
}, {
    readonly code: "SEARCH_NONE";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Error: no processable search found for %s search parameters \"%s\"";
}, {
    readonly code: "UPDATE_MULTIPLE_MATCHES";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
    readonly display: "Error: Multiple matches exist for the conditional update";
}];
/** String type (ValueSet too large for union type) */
export type OperationOutcomeCodesCode = string;
/** Type representing a concept from this ValueSet */
export type OperationOutcomeCodesConcept = typeof OperationOutcomeCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidOperationOutcomeCodesCode(code: string): code is OperationOutcomeCodesCode;
/**
 * Get concept details by code
 */
export declare function getOperationOutcomeCodesConcept(code: string): OperationOutcomeCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const OperationOutcomeCodesCodes: ("DELETE_MULTIPLE_MATCHES" | "MSG_AUTH_REQUIRED" | "MSG_BAD_FORMAT" | "MSG_BAD_SYNTAX" | "MSG_CANT_PARSE_CONTENT" | "MSG_CANT_PARSE_ROOT" | "MSG_CREATED" | "MSG_DATE_FORMAT" | "MSG_DELETED" | "MSG_DELETED_DONE" | "MSG_DELETED_ID" | "MSG_DUPLICATE_ID" | "MSG_ERROR_PARSING" | "MSG_ID_INVALID" | "MSG_ID_TOO_LONG" | "MSG_INVALID_ID" | "MSG_JSON_OBJECT" | "MSG_LOCAL_FAIL" | "MSG_NO_EXIST" | "MSG_NO_MATCH" | "MSG_NO_MODULE" | "MSG_NO_SUMMARY" | "MSG_OP_NOT_ALLOWED" | "MSG_PARAM_CHAINED" | "MSG_PARAM_INVALID" | "MSG_PARAM_MODIFIER_INVALID" | "MSG_PARAM_NO_REPEAT" | "MSG_PARAM_UNKNOWN" | "MSG_RESOURCE_EXAMPLE_PROTECTED" | "MSG_RESOURCE_ID_FAIL" | "MSG_RESOURCE_ID_MISMATCH" | "MSG_RESOURCE_ID_MISSING" | "MSG_RESOURCE_NOT_ALLOWED" | "MSG_RESOURCE_REQUIRED" | "MSG_RESOURCE_TYPE_MISMATCH" | "MSG_SORT_UNKNOWN" | "MSG_TRANSACTION_DUPLICATE_ID" | "MSG_TRANSACTION_MISSING_ID" | "MSG_UNHANDLED_NODE_TYPE" | "MSG_UNKNOWN_CONTENT" | "MSG_UNKNOWN_OPERATION" | "MSG_UNKNOWN_TYPE" | "MSG_UPDATED" | "MSG_VERSION_AWARE" | "MSG_VERSION_AWARE_CONFLICT" | "MSG_VERSION_AWARE_URL" | "MSG_WRONG_NS" | "SEARCH_MULTIPLE" | "SEARCH_NONE" | "UPDATE_MULTIPLE_MATCHES")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomOperationOutcomeCodesCode(): OperationOutcomeCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomOperationOutcomeCodesConcept(): OperationOutcomeCodesConcept;
