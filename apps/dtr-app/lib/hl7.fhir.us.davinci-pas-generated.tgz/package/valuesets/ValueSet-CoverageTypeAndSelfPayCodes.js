/**
 * ValueSet: CoverageTypeAndSelf-PayCodes
 * URL: http://hl7.org/fhir/ValueSet/coverage-type
 * Size: 58 concepts
 */
export const CoverageTypeAndSelfPayCodesConcepts = [
    { code: "pay", system: "http://terminology.hl7.org/CodeSystem/coverage-selfpay", display: "Pay" },
    { code: "_ActCoverageTypeCode", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "ActCoverageTypeCode" },
    { code: "_ActInsurancePolicyCode", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "ActInsurancePolicyCode" },
    { code: "_ActInsuranceTypeCode", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "ActInsuranceTypeCode" },
    { code: "_ActHealthInsuranceTypeCode", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "ActHealthInsuranceTypeCode" },
    { code: "POS", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "point of service policy" },
    { code: "DENTAL", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "dental care policy" },
    { code: "DISEASE", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "disease specific policy" },
    { code: "DRUGPOL", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "drug policy" },
    { code: "HIP", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "health insurance plan policy" },
    { code: "LTC", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "long term care policy" },
    { code: "MCPOL", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "managed care policy" },
    { code: "HMO", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "health maintenance organization policy" },
    { code: "PPO", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "preferred provider organization policy" },
    { code: "MENTPOL", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "mental health policy" },
    { code: "SUBPOL", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "substance use policy" },
    { code: "VISPOL", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "vision care policy" },
    { code: "DIS", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "disability insurance policy" },
    { code: "EWB", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "employee welfare benefit plan policy" },
    { code: "FLEXP", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "flexible benefit plan policy" },
    { code: "LIFE", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "life insurance policy" },
    { code: "ANNU", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "annuity policy" },
    { code: "TLIFE", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "term life insurance policy" },
    { code: "ULIFE", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "universal life insurance policy" },
    { code: "PNC", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "property and casualty insurance policy" },
    { code: "REI", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "reinsurance policy" },
    { code: "SURPL", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "surplus line insurance policy" },
    { code: "UMBRL", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "umbrella liability insurance policy" },
    { code: "_ActProgramTypeCode", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "ActProgramTypeCode" },
    { code: "CHAR", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "charity program" },
    { code: "CRIME", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "crime victim program" },
    { code: "EAP", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "employee assistance program" },
    { code: "GOVEMP", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "government employee health program" },
    { code: "HIRISK", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "high risk pool program" },
    { code: "IND", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "indigenous peoples health program" },
    { code: "MILITARY", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "military health program" },
    { code: "RETIRE", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "retiree health program" },
    { code: "SOCIAL", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "social service program" },
    { code: "VET", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "veteran health program" },
    { code: "EHCPOL", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "extended healthcare" },
    { code: "HSAPOL", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "health spending account" },
    { code: "AUTOPOL", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "automobile" },
    { code: "COL", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "collision coverage policy" },
    { code: "UNINSMOT", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "uninsured motorist policy" },
    { code: "PUBLICPOL", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "public healthcare" },
    { code: "DENTPRG", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "dental program" },
    { code: "DISEASEPRG", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "public health program" },
    { code: "CANPRG", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "women's cancer detection program" },
    { code: "ENDRENAL", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "end renal program" },
    { code: "HIVAIDS", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "HIV-AIDS program" },
    { code: "MANDPOL", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "mandatory health program" },
    { code: "MENTPRG", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "mental health program" },
    { code: "SAFNET", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "safety net clinic program" },
    { code: "SUBPRG", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "substance use program" },
    { code: "SUBSIDIZ", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "subsidized health program" },
    { code: "SUBSIDMC", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "subsidized managed care program" },
    { code: "SUBSUPP", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "subsidized supplemental health program" },
    { code: "WCBPOL", system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", display: "worker's compensation" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidCoverageTypeAndSelfPayCodesCode(code) {
    return CoverageTypeAndSelfPayCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getCoverageTypeAndSelfPayCodesConcept(code) {
    return CoverageTypeAndSelfPayCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const CoverageTypeAndSelfPayCodesCodes = CoverageTypeAndSelfPayCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomCoverageTypeAndSelfPayCodesCode() {
    return CoverageTypeAndSelfPayCodesCodes[Math.floor(Math.random() * CoverageTypeAndSelfPayCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomCoverageTypeAndSelfPayCodesConcept() {
    return CoverageTypeAndSelfPayCodesConcepts[Math.floor(Math.random() * CoverageTypeAndSelfPayCodesConcepts.length)];
}
