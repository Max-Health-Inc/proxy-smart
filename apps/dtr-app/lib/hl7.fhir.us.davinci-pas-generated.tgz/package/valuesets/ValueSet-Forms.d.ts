/**
 * ValueSet: forms
 * URL: http://hl7.org/fhir/ValueSet/forms
 * Size: 2 concepts
 */
export declare const FormsConcepts: readonly [{
    readonly code: "1";
    readonly system: "http://terminology.hl7.org/CodeSystem/forms-codes";
}, {
    readonly code: "2";
    readonly system: "http://terminology.hl7.org/CodeSystem/forms-codes";
}];
/** Union type of all valid codes in this ValueSet */
export type FormsCode = "1" | "2";
/** Type representing a concept from this ValueSet */
export type FormsConcept = typeof FormsConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidFormsCode(code: string): code is FormsCode;
/**
 * Get concept details by code
 */
export declare function getFormsConcept(code: string): FormsConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const FormsCodes: ("1" | "2")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomFormsCode(): FormsCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomFormsConcept(): FormsConcept;
