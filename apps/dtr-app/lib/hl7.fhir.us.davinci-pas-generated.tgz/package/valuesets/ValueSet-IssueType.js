/**
 * ValueSet: issue-type
 * URL: http://hl7.org/fhir/ValueSet/issue-type
 * Size: 31 concepts
 */
export const IssueTypeConcepts = [
    { code: "invalid", system: "http://hl7.org/fhir/issue-type" },
    { code: "structure", system: "http://hl7.org/fhir/issue-type" },
    { code: "required", system: "http://hl7.org/fhir/issue-type" },
    { code: "value", system: "http://hl7.org/fhir/issue-type" },
    { code: "invariant", system: "http://hl7.org/fhir/issue-type" },
    { code: "security", system: "http://hl7.org/fhir/issue-type" },
    { code: "login", system: "http://hl7.org/fhir/issue-type" },
    { code: "unknown", system: "http://hl7.org/fhir/issue-type" },
    { code: "expired", system: "http://hl7.org/fhir/issue-type" },
    { code: "forbidden", system: "http://hl7.org/fhir/issue-type" },
    { code: "suppressed", system: "http://hl7.org/fhir/issue-type" },
    { code: "processing", system: "http://hl7.org/fhir/issue-type" },
    { code: "not-supported", system: "http://hl7.org/fhir/issue-type" },
    { code: "duplicate", system: "http://hl7.org/fhir/issue-type" },
    { code: "multiple-matches", system: "http://hl7.org/fhir/issue-type" },
    { code: "not-found", system: "http://hl7.org/fhir/issue-type" },
    { code: "deleted", system: "http://hl7.org/fhir/issue-type" },
    { code: "too-long", system: "http://hl7.org/fhir/issue-type" },
    { code: "code-invalid", system: "http://hl7.org/fhir/issue-type" },
    { code: "extension", system: "http://hl7.org/fhir/issue-type" },
    { code: "too-costly", system: "http://hl7.org/fhir/issue-type" },
    { code: "business-rule", system: "http://hl7.org/fhir/issue-type" },
    { code: "conflict", system: "http://hl7.org/fhir/issue-type" },
    { code: "transient", system: "http://hl7.org/fhir/issue-type" },
    { code: "lock-error", system: "http://hl7.org/fhir/issue-type" },
    { code: "no-store", system: "http://hl7.org/fhir/issue-type" },
    { code: "exception", system: "http://hl7.org/fhir/issue-type" },
    { code: "timeout", system: "http://hl7.org/fhir/issue-type" },
    { code: "incomplete", system: "http://hl7.org/fhir/issue-type" },
    { code: "throttled", system: "http://hl7.org/fhir/issue-type" },
    { code: "informational", system: "http://hl7.org/fhir/issue-type" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidIssueTypeCode(code) {
    return IssueTypeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getIssueTypeConcept(code) {
    return IssueTypeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const IssueTypeCodes = IssueTypeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomIssueTypeCode() {
    return IssueTypeCodes[Math.floor(Math.random() * IssueTypeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomIssueTypeConcept() {
    return IssueTypeConcepts[Math.floor(Math.random() * IssueTypeConcepts.length)];
}
