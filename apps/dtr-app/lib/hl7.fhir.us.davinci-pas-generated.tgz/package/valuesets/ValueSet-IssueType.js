/**
 * ValueSet: IssueType
 * URL: http://hl7.org/fhir/ValueSet/issue-type
 * Size: 5 concepts
 */
export const IssueTypeConcepts = [
    { code: "invalid", system: "http://hl7.org/fhir/issue-type", display: "Invalid Content" },
    { code: "security", system: "http://hl7.org/fhir/issue-type", display: "Security Problem" },
    { code: "processing", system: "http://hl7.org/fhir/issue-type", display: "Processing Failure" },
    { code: "transient", system: "http://hl7.org/fhir/issue-type", display: "Transient Issue" },
    { code: "informational", system: "http://hl7.org/fhir/issue-type", display: "Informational Note" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidIssueTypeCode(code) {
    return IssueTypeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getIssueTypeConcept(code) {
    return IssueTypeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const IssueTypeCodes = IssueTypeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomIssueTypeCode() {
    return IssueTypeCodes[Math.floor(Math.random() * IssueTypeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomIssueTypeConcept() {
    return IssueTypeConcepts[Math.floor(Math.random() * IssueTypeConcepts.length)];
}
