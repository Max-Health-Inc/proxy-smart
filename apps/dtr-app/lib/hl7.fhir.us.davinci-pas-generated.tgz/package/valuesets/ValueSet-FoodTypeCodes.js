/**
 * ValueSet: FoodTypeCodes
 * URL: http://hl7.org/fhir/ValueSet/food-type
 * Size: 100 concepts
 */
export const FoodTypeCodesConcepts = [
    { code: "255620007", system: "http://snomed.info/sct", display: "Foods" },
    { code: "3718001", system: "http://snomed.info/sct", display: "Cow's milk" },
    { code: "4289006", system: "http://snomed.info/sct", display: "Keyhole-limpet hemocyanin" },
    { code: "4882006", system: "http://snomed.info/sct", display: "Ichthyoallyeinotoxin" },
    { code: "5163009", system: "http://snomed.info/sct", display: "Scombrotoxin" },
    { code: "7661006", system: "http://snomed.info/sct", display: "Fish bone" },
    { code: "7791007", system: "http://snomed.info/sct", display: "Soy protein" },
    { code: "10827009", system: "http://snomed.info/sct", display: "Milk protein" },
    { code: "12448007", system: "http://snomed.info/sct", display: "Whelk poison" },
    { code: "13577000", system: "http://snomed.info/sct", display: "Nut" },
    { code: "14263006", system: "http://snomed.info/sct", display: "Prepared fish" },
    { code: "16641007", system: "http://snomed.info/sct", display: "Bonellinin" },
    { code: "19950006", system: "http://snomed.info/sct", display: "Brevetoxin" },
    { code: "20459005", system: "http://snomed.info/sct", display: "Abalone viscera poison" },
    { code: "22836000", system: "http://snomed.info/sct", display: "Vegetable" },
    { code: "23182003", system: "http://snomed.info/sct", display: "Cereal" },
    { code: "23317009", system: "http://snomed.info/sct", display: "Saxitoxin" },
    { code: "24515005", system: "http://snomed.info/sct", display: "Spice" },
    { code: "25743006", system: "http://snomed.info/sct", display: "Skim milk" },
    { code: "26426004", system: "http://snomed.info/sct", display: "Ciguatoxin" },
    { code: "28230009", system: "http://snomed.info/sct", display: "Poultry" },
    { code: "28647000", system: "http://snomed.info/sct", display: "Meat" },
    { code: "28942008", system: "http://snomed.info/sct", display: "Coconut oil" },
    { code: "29516008", system: "http://snomed.info/sct", display: "Venerupin shellfish toxin" },
    { code: "32500002", system: "http://snomed.info/sct", display: "Shellfish toxin" },
    { code: "32627005", system: "http://snomed.info/sct", display: "Eburnetoxin" },
    { code: "35124009", system: "http://snomed.info/sct", display: "Clupeotoxin" },
    { code: "37784002", system: "http://snomed.info/sct", display: "Striatoxin" },
    { code: "39102003", system: "http://snomed.info/sct", display: "Food particle" },
    { code: "40112002", system: "http://snomed.info/sct", display: "Ichthyootoxin" },
    { code: "41317008", system: "http://snomed.info/sct", display: "Asterosaponin" },
    { code: "41834005", system: "http://snomed.info/sct", display: "Olive oil" },
    { code: "42244003", system: "http://snomed.info/sct", display: "Debromoaplysiatoxin" },
    { code: "43708003", system: "http://snomed.info/sct", display: "Animal feed additive" },
    { code: "44027008", system: "http://snomed.info/sct", display: "Seafood" },
    { code: "44590006", system: "http://snomed.info/sct", display: "Callistin toxin" },
    { code: "46321002", system: "http://snomed.info/sct", display: "Asterotoxin" },
    { code: "46329000", system: "http://snomed.info/sct", display: "Chocolate milk" },
    { code: "50479000", system: "http://snomed.info/sct", display: "Soy protein-iron complex" },
    { code: "50593009", system: "http://snomed.info/sct", display: "Casein" },
    { code: "51905005", system: "http://snomed.info/sct", display: "Mustard" },
    { code: "51934004", system: "http://snomed.info/sct", display: "Hemocyanin" },
    { code: "52800001", system: "http://snomed.info/sct", display: "Marine toxin" },
    { code: "53875002", system: "http://snomed.info/sct", display: "Colostrum" },
    { code: "54041009", system: "http://snomed.info/sct", display: "Safflower oil" },
    { code: "56773009", system: "http://snomed.info/sct", display: "Ichthyocrinotoxin" },
    { code: "59119009", system: "http://snomed.info/sct", display: "Ichthyosarcotoxin" },
    { code: "59149006", system: "http://snomed.info/sct", display: "Tetrodotoxin" },
    { code: "61044003", system: "http://snomed.info/sct", display: "Acipenserin" },
    { code: "63045006", system: "http://snomed.info/sct", display: "Berry" },
    { code: "63766005", system: "http://snomed.info/sct", display: "Flour" },
    { code: "64869000", system: "http://snomed.info/sct", display: "Conotoxin" },
    { code: "66228001", system: "http://snomed.info/sct", display: "Actinocongestin" },
    { code: "67324005", system: "http://snomed.info/sct", display: "Rice" },
    { code: "67938008", system: "http://snomed.info/sct", display: "Amnesic shellfish poison" },
    { code: "70813002", system: "http://snomed.info/sct", display: "Milk" },
    { code: "71561006", system: "http://snomed.info/sct", display: "Chelonitoxin" },
    { code: "72340002", system: "http://snomed.info/sct", display: "Plotolysin toxin" },
    { code: "72359000", system: "http://snomed.info/sct", display: "Gonyautoxin" },
    { code: "72511004", system: "http://snomed.info/sct", display: "Fruit" },
    { code: "73892005", system: "http://snomed.info/sct", display: "Carmine" },
    { code: "74242007", system: "http://snomed.info/sct", display: "Food starch" },
    { code: "77722008", system: "http://snomed.info/sct", display: "Poultry bone" },
    { code: "80743002", system: "http://snomed.info/sct", display: "Mustard black" },
    { code: "80903004", system: "http://snomed.info/sct", display: "Haplotoxin" },
    { code: "82450006", system: "http://snomed.info/sct", display: "Cottonseed oil" },
    { code: "82566005", system: "http://snomed.info/sct", display: "Animal feed" },
    { code: "83595008", system: "http://snomed.info/sct", display: "Goat's milk" },
    { code: "83897009", system: "http://snomed.info/sct", display: "Paralytic shellfish toxin" },
    { code: "84802001", system: "http://snomed.info/sct", display: "Equinatoxin" },
    { code: "85668006", system: "http://snomed.info/sct", display: "Starch powder" },
    { code: "86600008", system: "http://snomed.info/sct", display: "Fish toxin" },
    { code: "89707004", system: "http://snomed.info/sct", display: "Sesame oil" },
    { code: "89811004", system: "http://snomed.info/sct", display: "Gluten" },
    { code: "89866003", system: "http://snomed.info/sct", display: "Plotospasmin toxin" },
    { code: "90677004", system: "http://snomed.info/sct", display: "Mustard white" },
    { code: "90696000", system: "http://snomed.info/sct", display: "Neosaxitonin" },
    { code: "91353009", system: "http://snomed.info/sct", display: "Cephalotoxin" },
    { code: "91677007", system: "http://snomed.info/sct", display: "Aplysiatoxin" },
    { code: "102259006", system: "http://snomed.info/sct", display: "Citrus fruit" },
    { code: "102260001", system: "http://snomed.info/sct", display: "Peanut butter" },
    { code: "102261002", system: "http://snomed.info/sct", display: "Strawberry" },
    { code: "102262009", system: "http://snomed.info/sct", display: "Chocolate" },
    { code: "102263004", system: "http://snomed.info/sct", display: "Eggs (edible)" },
    { code: "102264005", system: "http://snomed.info/sct", display: "Cheese" },
    { code: "102270004", system: "http://snomed.info/sct", display: "Growth stimulant" },
    { code: "102271000", system: "http://snomed.info/sct", display: "Efrotomycin" },
    { code: "102697003", system: "http://snomed.info/sct", display: "Lactalbumin" },
    { code: "102698008", system: "http://snomed.info/sct", display: "alpha-Lactalbumin" },
    { code: "102699000", system: "http://snomed.info/sct", display: "beta-Lactalbumin" },
    { code: "126076005", system: "http://snomed.info/sct", display: "Fish liver oil" },
    { code: "126077001", system: "http://snomed.info/sct", display: "Burbot liver oil" },
    { code: "126078006", system: "http://snomed.info/sct", display: "Percomorph liver oil" },
    { code: "126079003", system: "http://snomed.info/sct", display: "Percoid liver oil" },
    { code: "126080000", system: "http://snomed.info/sct", display: "Shark liver oil" },
    { code: "126081001", system: "http://snomed.info/sct", display: "Halibut liver oil" },
    { code: "126082008", system: "http://snomed.info/sct", display: "Cod liver oil" },
    { code: "127384006", system: "http://snomed.info/sct", display: "Salmon calcitonin" },
    { code: "226017009", system: "http://snomed.info/sct", display: "Bombay mix" },
    { code: "226021002", system: "http://snomed.info/sct", display: "Cauliflower cheese" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidFoodTypeCodesCode(code) {
    return FoodTypeCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getFoodTypeCodesConcept(code) {
    return FoodTypeCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const FoodTypeCodesCodes = FoodTypeCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomFoodTypeCodesCode() {
    return FoodTypeCodesCodes[Math.floor(Math.random() * FoodTypeCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomFoodTypeCodesConcept() {
    return FoodTypeCodesConcepts[Math.floor(Math.random() * FoodTypeCodesConcepts.length)];
}
