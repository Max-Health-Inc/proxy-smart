/**
 * ValueSet: contact-point-system
 * URL: http://hl7.org/fhir/ValueSet/contact-point-system
 * Size: 7 concepts
 */
export const ContactPointSystemConcepts = [
    { code: "phone", system: "http://hl7.org/fhir/contact-point-system" },
    { code: "fax", system: "http://hl7.org/fhir/contact-point-system" },
    { code: "email", system: "http://hl7.org/fhir/contact-point-system" },
    { code: "pager", system: "http://hl7.org/fhir/contact-point-system" },
    { code: "url", system: "http://hl7.org/fhir/contact-point-system" },
    { code: "sms", system: "http://hl7.org/fhir/contact-point-system" },
    { code: "other", system: "http://hl7.org/fhir/contact-point-system" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidContactPointSystemCode(code) {
    return ContactPointSystemConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getContactPointSystemConcept(code) {
    return ContactPointSystemConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ContactPointSystemCodes = ContactPointSystemConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomContactPointSystemCode() {
    return ContactPointSystemCodes[Math.floor(Math.random() * ContactPointSystemCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomContactPointSystemConcept() {
    return ContactPointSystemConcepts[Math.floor(Math.random() * ContactPointSystemConcepts.length)];
}
