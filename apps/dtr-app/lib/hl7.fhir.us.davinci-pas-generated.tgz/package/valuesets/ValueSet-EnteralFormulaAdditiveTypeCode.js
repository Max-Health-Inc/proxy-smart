/**
 * ValueSet: EnteralFormulaAdditiveTypeCode
 * URL: http://hl7.org/fhir/ValueSet/entformula-additive
 * Size: 5 concepts
 */
export const EnteralFormulaAdditiveTypeCodeConcepts = [
    { code: "lipid", system: "http://terminology.hl7.org/CodeSystem/entformula-additive", display: "Lipid" },
    { code: "protein", system: "http://terminology.hl7.org/CodeSystem/entformula-additive", display: "Protein" },
    { code: "carbohydrate", system: "http://terminology.hl7.org/CodeSystem/entformula-additive", display: "Carbohydrate" },
    { code: "fiber", system: "http://terminology.hl7.org/CodeSystem/entformula-additive", display: "Fiber" },
    { code: "water", system: "http://terminology.hl7.org/CodeSystem/entformula-additive", display: "Water" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidEnteralFormulaAdditiveTypeCodeCode(code) {
    return EnteralFormulaAdditiveTypeCodeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getEnteralFormulaAdditiveTypeCodeConcept(code) {
    return EnteralFormulaAdditiveTypeCodeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const EnteralFormulaAdditiveTypeCodeCodes = EnteralFormulaAdditiveTypeCodeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomEnteralFormulaAdditiveTypeCodeCode() {
    return EnteralFormulaAdditiveTypeCodeCodes[Math.floor(Math.random() * EnteralFormulaAdditiveTypeCodeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomEnteralFormulaAdditiveTypeCodeConcept() {
    return EnteralFormulaAdditiveTypeCodeConcepts[Math.floor(Math.random() * EnteralFormulaAdditiveTypeCodeConcepts.length)];
}
