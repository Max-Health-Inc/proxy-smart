/**
 * ValueSet: fundsreserve
 * URL: http://hl7.org/fhir/ValueSet/fundsreserve
 * Size: 3 concepts
 */
export declare const FundsreserveConcepts: readonly [{
    readonly code: "patient";
    readonly system: "http://terminology.hl7.org/CodeSystem/fundsreserve";
}, {
    readonly code: "provider";
    readonly system: "http://terminology.hl7.org/CodeSystem/fundsreserve";
}, {
    readonly code: "none";
    readonly system: "http://terminology.hl7.org/CodeSystem/fundsreserve";
}];
/** Union type of all valid codes in this ValueSet */
export type FundsreserveCode = "patient" | "provider" | "none";
/** Type representing a concept from this ValueSet */
export type FundsreserveConcept = typeof FundsreserveConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidFundsreserveCode(code: string): code is FundsreserveCode;
/**
 * Get concept details by code
 */
export declare function getFundsreserveConcept(code: string): FundsreserveConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const FundsreserveCodes: ("patient" | "provider" | "none")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomFundsreserveCode(): FundsreserveCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomFundsreserveConcept(): FundsreserveConcept;
