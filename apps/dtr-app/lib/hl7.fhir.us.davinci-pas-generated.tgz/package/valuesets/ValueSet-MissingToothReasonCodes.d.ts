/**
 * ValueSet: MissingToothReasonCodes
 * URL: http://hl7.org/fhir/ValueSet/missing-tooth-reason
 * Size: 4 concepts
 */
export declare const MissingToothReasonCodesConcepts: readonly [{
    readonly code: "e";
    readonly system: "http://terminology.hl7.org/CodeSystem/missingtoothreason";
    readonly display: "E";
}, {
    readonly code: "c";
    readonly system: "http://terminology.hl7.org/CodeSystem/missingtoothreason";
    readonly display: "C";
}, {
    readonly code: "u";
    readonly system: "http://terminology.hl7.org/CodeSystem/missingtoothreason";
    readonly display: "U";
}, {
    readonly code: "o";
    readonly system: "http://terminology.hl7.org/CodeSystem/missingtoothreason";
    readonly display: "O";
}];
/** Union type of all valid codes in this ValueSet */
export type MissingToothReasonCodesCode = "e" | "c" | "u" | "o";
/** Type representing a concept from this ValueSet */
export type MissingToothReasonCodesConcept = typeof MissingToothReasonCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidMissingToothReasonCodesCode(code: string): code is MissingToothReasonCodesCode;
/**
 * Get concept details by code
 */
export declare function getMissingToothReasonCodesConcept(code: string): MissingToothReasonCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const MissingToothReasonCodesCodes: ("u" | "e" | "c" | "o")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomMissingToothReasonCodesCode(): MissingToothReasonCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomMissingToothReasonCodesConcept(): MissingToothReasonCodesConcept;
