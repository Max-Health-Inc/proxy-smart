/**
 * ValueSet: encounter-participant-type
 * URL: http://hl7.org/fhir/ValueSet/encounter-participant-type
 * Size: 5 concepts
 */
export const EncounterParticipantTypeConcepts = [
    { code: "SPRF", system: "http://terminology.hl7.org/CodeSystem/v3-ParticipationType" },
    { code: "PPRF", system: "http://terminology.hl7.org/CodeSystem/v3-ParticipationType" },
    { code: "PART", system: "http://terminology.hl7.org/CodeSystem/v3-ParticipationType" },
    { code: "translator", system: "http://terminology.hl7.org/CodeSystem/participant-type" },
    { code: "emergency", system: "http://terminology.hl7.org/CodeSystem/participant-type" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidEncounterParticipantTypeCode(code) {
    return EncounterParticipantTypeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getEncounterParticipantTypeConcept(code) {
    return EncounterParticipantTypeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const EncounterParticipantTypeCodes = EncounterParticipantTypeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomEncounterParticipantTypeCode() {
    return EncounterParticipantTypeCodes[Math.floor(Math.random() * EncounterParticipantTypeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomEncounterParticipantTypeConcept() {
    return EncounterParticipantTypeConcepts[Math.floor(Math.random() * EncounterParticipantTypeConcepts.length)];
}
