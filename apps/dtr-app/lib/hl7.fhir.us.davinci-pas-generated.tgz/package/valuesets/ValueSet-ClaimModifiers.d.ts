/**
 * ValueSet: claim-modifiers
 * URL: http://hl7.org/fhir/ValueSet/claim-modifiers
 * Size: 6 concepts
 */
export declare const ClaimModifiersConcepts: readonly [{
    readonly code: "a";
    readonly system: "http://terminology.hl7.org/CodeSystem/modifiers";
}, {
    readonly code: "b";
    readonly system: "http://terminology.hl7.org/CodeSystem/modifiers";
}, {
    readonly code: "c";
    readonly system: "http://terminology.hl7.org/CodeSystem/modifiers";
}, {
    readonly code: "e";
    readonly system: "http://terminology.hl7.org/CodeSystem/modifiers";
}, {
    readonly code: "rooh";
    readonly system: "http://terminology.hl7.org/CodeSystem/modifiers";
}, {
    readonly code: "x";
    readonly system: "http://terminology.hl7.org/CodeSystem/modifiers";
}];
/** Union type of all valid codes in this ValueSet */
export type ClaimModifiersCode = "a" | "b" | "c" | "e" | "rooh" | "x";
/** Type representing a concept from this ValueSet */
export type ClaimModifiersConcept = typeof ClaimModifiersConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidClaimModifiersCode(code: string): code is ClaimModifiersCode;
/**
 * Get concept details by code
 */
export declare function getClaimModifiersConcept(code: string): ClaimModifiersConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ClaimModifiersCodes: ("a" | "b" | "c" | "e" | "rooh" | "x")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomClaimModifiersCode(): ClaimModifiersCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomClaimModifiersConcept(): ClaimModifiersConcept;
