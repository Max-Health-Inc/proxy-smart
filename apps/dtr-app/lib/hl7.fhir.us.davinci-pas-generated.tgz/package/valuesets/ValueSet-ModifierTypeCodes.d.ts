/**
 * ValueSet: ModifierTypeCodes
 * URL: http://hl7.org/fhir/ValueSet/claim-modifiers
 * Size: 6 concepts
 */
export declare const ModifierTypeCodesConcepts: readonly [{
    readonly code: "a";
    readonly system: "http://terminology.hl7.org/CodeSystem/modifiers";
    readonly display: "Repair of prior service or installation";
}, {
    readonly code: "b";
    readonly system: "http://terminology.hl7.org/CodeSystem/modifiers";
    readonly display: "Temporary service or installation";
}, {
    readonly code: "c";
    readonly system: "http://terminology.hl7.org/CodeSystem/modifiers";
    readonly display: "TMJ treatment";
}, {
    readonly code: "e";
    readonly system: "http://terminology.hl7.org/CodeSystem/modifiers";
    readonly display: "Implant or associated with an implant";
}, {
    readonly code: "rooh";
    readonly system: "http://terminology.hl7.org/CodeSystem/modifiers";
    readonly display: "Rush or Outside of office hours";
}, {
    readonly code: "x";
    readonly system: "http://terminology.hl7.org/CodeSystem/modifiers";
    readonly display: "None";
}];
/** Union type of all valid codes in this ValueSet */
export type ModifierTypeCodesCode = "a" | "b" | "c" | "e" | "rooh" | "x";
/** Type representing a concept from this ValueSet */
export type ModifierTypeCodesConcept = typeof ModifierTypeCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidModifierTypeCodesCode(code: string): code is ModifierTypeCodesCode;
/**
 * Get concept details by code
 */
export declare function getModifierTypeCodesConcept(code: string): ModifierTypeCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ModifierTypeCodesCodes: ("a" | "b" | "e" | "c" | "rooh" | "x")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomModifierTypeCodesCode(): ModifierTypeCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomModifierTypeCodesConcept(): ModifierTypeCodesConcept;
