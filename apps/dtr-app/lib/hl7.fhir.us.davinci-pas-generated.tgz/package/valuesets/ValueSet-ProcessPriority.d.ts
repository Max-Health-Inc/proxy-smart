/**
 * ValueSet: process-priority
 * URL: http://hl7.org/fhir/ValueSet/process-priority
 * Size: 3 concepts
 */
export declare const ProcessPriorityConcepts: readonly [{
    readonly code: "stat";
    readonly system: "http://terminology.hl7.org/CodeSystem/processpriority";
}, {
    readonly code: "normal";
    readonly system: "http://terminology.hl7.org/CodeSystem/processpriority";
}, {
    readonly code: "deferred";
    readonly system: "http://terminology.hl7.org/CodeSystem/processpriority";
}];
/** Union type of all valid codes in this ValueSet */
export type ProcessPriorityCode = "stat" | "normal" | "deferred";
/** Type representing a concept from this ValueSet */
export type ProcessPriorityConcept = typeof ProcessPriorityConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidProcessPriorityCode(code: string): code is ProcessPriorityCode;
/**
 * Get concept details by code
 */
export declare function getProcessPriorityConcept(code: string): ProcessPriorityConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ProcessPriorityCodes: ("normal" | "stat" | "deferred")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomProcessPriorityCode(): ProcessPriorityCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomProcessPriorityConcept(): ProcessPriorityConcept;
