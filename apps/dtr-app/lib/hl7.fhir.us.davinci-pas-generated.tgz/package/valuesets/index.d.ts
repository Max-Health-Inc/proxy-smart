/**
 * ValueSet Registry
 * Central registry of all loaded ValueSets with explicit codes
 */
import * as AddressType from './ValueSet-AddressType.js';
import * as AddressUse from './ValueSet-AddressUse.js';
import * as AdministrativeGender from './ValueSet-AdministrativeGender.js';
import * as BodySite from './ValueSet-BodySite.js';
import * as BundleType from './ValueSet-BundleType.js';
import * as ConditionCode from './ValueSet-ConditionCode.js';
import * as ContactPointSystem from './ValueSet-ContactPointSystem.js';
import * as ContactPointUse from './ValueSet-ContactPointUse.js';
import * as DaysOfWeek from './ValueSet-DaysOfWeek.js';
import * as EncounterStatus from './ValueSet-EncounterStatus.js';
import * as FmStatus from './ValueSet-FmStatus.js';
import * as HrexTaskStatus from './ValueSet-HrexTaskStatus.js';
import * as HttpVerb from './ValueSet-HttpVerb.js';
import * as IdentifierUse from './ValueSet-IdentifierUse.js';
import * as LinkType from './ValueSet-LinkType.js';
import * as MedicationrequestStatus from './ValueSet-MedicationrequestStatus.js';
import * as MetricDataSource from './ValueSet-MetricDataSource.js';
import * as NameUse from './ValueSet-NameUse.js';
import * as PASCommunicationRequestMedium from './ValueSet-PASCommunicationRequestMedium.js';
import * as PASInformationChangeMode from './ValueSet-PASInformationChangeMode.js';
import * as PASSupportingInfoType from './ValueSet-PASSupportingInfoType.js';
import * as PASTaskCodes from './ValueSet-PASTaskCodes.js';
import * as RequestIntent from './ValueSet-RequestIntent.js';
import * as RequestPriority from './ValueSet-RequestPriority.js';
import * as RequestStatus from './ValueSet-RequestStatus.js';
import * as UsCoreUspsState from './ValueSet-UsCoreUspsState.js';
import * as V20092 from './ValueSet-V20092.js';
import * as V20116 from './ValueSet-V20116.js';
import * as V3ActPriority from './ValueSet-V3ActPriority.js';
import * as V3ActReason from './ValueSet-V3ActReason.js';
import * as X12278DiagnosisType from './ValueSet-X12278DiagnosisType.js';
import * as X12278RequestedServiceType from './ValueSet-X12278RequestedServiceType.js';
export declare const ValueSetRegistry: {
    readonly AddressType: typeof AddressType;
    readonly AddressUse: typeof AddressUse;
    readonly AdministrativeGender: typeof AdministrativeGender;
    readonly BodySite: typeof BodySite;
    readonly BundleType: typeof BundleType;
    readonly ConditionCode: typeof ConditionCode;
    readonly ContactPointSystem: typeof ContactPointSystem;
    readonly ContactPointUse: typeof ContactPointUse;
    readonly DaysOfWeek: typeof DaysOfWeek;
    readonly EncounterStatus: typeof EncounterStatus;
    readonly FmStatus: typeof FmStatus;
    readonly HrexTaskStatus: typeof HrexTaskStatus;
    readonly HttpVerb: typeof HttpVerb;
    readonly IdentifierUse: typeof IdentifierUse;
    readonly LinkType: typeof LinkType;
    readonly MedicationrequestStatus: typeof MedicationrequestStatus;
    readonly MetricDataSource: typeof MetricDataSource;
    readonly NameUse: typeof NameUse;
    readonly PASCommunicationRequestMedium: typeof PASCommunicationRequestMedium;
    readonly PASInformationChangeMode: typeof PASInformationChangeMode;
    readonly PASSupportingInfoType: typeof PASSupportingInfoType;
    readonly PASTaskCodes: typeof PASTaskCodes;
    readonly RequestIntent: typeof RequestIntent;
    readonly RequestPriority: typeof RequestPriority;
    readonly RequestStatus: typeof RequestStatus;
    readonly UsCoreUspsState: typeof UsCoreUspsState;
    readonly V20092: typeof V20092;
    readonly V20116: typeof V20116;
    readonly V3ActPriority: typeof V3ActPriority;
    readonly V3ActReason: typeof V3ActReason;
    readonly X12278DiagnosisType: typeof X12278DiagnosisType;
    readonly X12278RequestedServiceType: typeof X12278RequestedServiceType;
};
export type ValueSetName = keyof typeof ValueSetRegistry;
export declare function getValueSet(name: ValueSetName): typeof AddressType | typeof AddressUse | typeof AdministrativeGender | typeof BodySite | typeof BundleType | typeof ConditionCode | typeof ContactPointSystem | typeof ContactPointUse | typeof DaysOfWeek | typeof EncounterStatus | typeof FmStatus | typeof HrexTaskStatus | typeof HttpVerb | typeof IdentifierUse | typeof LinkType | typeof MedicationrequestStatus | typeof MetricDataSource | typeof NameUse | typeof PASCommunicationRequestMedium | typeof PASInformationChangeMode | typeof PASSupportingInfoType | typeof PASTaskCodes | typeof RequestIntent | typeof RequestPriority | typeof RequestStatus | typeof UsCoreUspsState | typeof V20092 | typeof V20116 | typeof V3ActPriority | typeof V3ActReason | typeof X12278DiagnosisType | typeof X12278RequestedServiceType;
/** Map from ValueSet URL to registry name */
export declare const ValueSetUrlMap: Record<string, ValueSetName>;
/**
 * Get a random code from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A random code string, or undefined if ValueSet not found
 */
export declare function getRandomCodeByUrl(url: string): string | undefined;
/**
 * Get a random concept (code, system, display) from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A concept object with code, system, and optional display, or undefined if ValueSet not found
 */
export declare function getRandomConceptByUrl(url: string): {
    code: string;
    system: string;
    display?: string;
} | undefined;
