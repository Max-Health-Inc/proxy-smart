/**
 * ValueSet: CoverageTypeAndSelf-PayCodes
 * URL: http://hl7.org/fhir/ValueSet/coverage-type
 * Size: 58 concepts
 */
export declare const CoverageTypeAndSelfPayCodesConcepts: readonly [{
    readonly code: "pay";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-selfpay";
    readonly display: "Pay";
}, {
    readonly code: "_ActCoverageTypeCode";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "ActCoverageTypeCode";
}, {
    readonly code: "_ActInsurancePolicyCode";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "ActInsurancePolicyCode";
}, {
    readonly code: "_ActInsuranceTypeCode";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "ActInsuranceTypeCode";
}, {
    readonly code: "_ActHealthInsuranceTypeCode";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "ActHealthInsuranceTypeCode";
}, {
    readonly code: "POS";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "point of service policy";
}, {
    readonly code: "DENTAL";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "dental care policy";
}, {
    readonly code: "DISEASE";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "disease specific policy";
}, {
    readonly code: "DRUGPOL";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "drug policy";
}, {
    readonly code: "HIP";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "health insurance plan policy";
}, {
    readonly code: "LTC";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "long term care policy";
}, {
    readonly code: "MCPOL";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "managed care policy";
}, {
    readonly code: "HMO";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "health maintenance organization policy";
}, {
    readonly code: "PPO";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "preferred provider organization policy";
}, {
    readonly code: "MENTPOL";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "mental health policy";
}, {
    readonly code: "SUBPOL";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "substance use policy";
}, {
    readonly code: "VISPOL";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "vision care policy";
}, {
    readonly code: "DIS";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "disability insurance policy";
}, {
    readonly code: "EWB";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "employee welfare benefit plan policy";
}, {
    readonly code: "FLEXP";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "flexible benefit plan policy";
}, {
    readonly code: "LIFE";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "life insurance policy";
}, {
    readonly code: "ANNU";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "annuity policy";
}, {
    readonly code: "TLIFE";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "term life insurance policy";
}, {
    readonly code: "ULIFE";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "universal life insurance policy";
}, {
    readonly code: "PNC";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "property and casualty insurance policy";
}, {
    readonly code: "REI";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "reinsurance policy";
}, {
    readonly code: "SURPL";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "surplus line insurance policy";
}, {
    readonly code: "UMBRL";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "umbrella liability insurance policy";
}, {
    readonly code: "_ActProgramTypeCode";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "ActProgramTypeCode";
}, {
    readonly code: "CHAR";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "charity program";
}, {
    readonly code: "CRIME";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "crime victim program";
}, {
    readonly code: "EAP";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "employee assistance program";
}, {
    readonly code: "GOVEMP";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "government employee health program";
}, {
    readonly code: "HIRISK";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "high risk pool program";
}, {
    readonly code: "IND";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "indigenous peoples health program";
}, {
    readonly code: "MILITARY";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "military health program";
}, {
    readonly code: "RETIRE";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "retiree health program";
}, {
    readonly code: "SOCIAL";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "social service program";
}, {
    readonly code: "VET";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "veteran health program";
}, {
    readonly code: "EHCPOL";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "extended healthcare";
}, {
    readonly code: "HSAPOL";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "health spending account";
}, {
    readonly code: "AUTOPOL";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "automobile";
}, {
    readonly code: "COL";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "collision coverage policy";
}, {
    readonly code: "UNINSMOT";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "uninsured motorist policy";
}, {
    readonly code: "PUBLICPOL";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "public healthcare";
}, {
    readonly code: "DENTPRG";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "dental program";
}, {
    readonly code: "DISEASEPRG";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "public health program";
}, {
    readonly code: "CANPRG";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "women's cancer detection program";
}, {
    readonly code: "ENDRENAL";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "end renal program";
}, {
    readonly code: "HIVAIDS";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "HIV-AIDS program";
}, {
    readonly code: "MANDPOL";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "mandatory health program";
}, {
    readonly code: "MENTPRG";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "mental health program";
}, {
    readonly code: "SAFNET";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "safety net clinic program";
}, {
    readonly code: "SUBPRG";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "substance use program";
}, {
    readonly code: "SUBSIDIZ";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "subsidized health program";
}, {
    readonly code: "SUBSIDMC";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "subsidized managed care program";
}, {
    readonly code: "SUBSUPP";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "subsidized supplemental health program";
}, {
    readonly code: "WCBPOL";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActCode";
    readonly display: "worker's compensation";
}];
/** String type (ValueSet too large for union type) */
export type CoverageTypeAndSelfPayCodesCode = string;
/** Type representing a concept from this ValueSet */
export type CoverageTypeAndSelfPayCodesConcept = typeof CoverageTypeAndSelfPayCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidCoverageTypeAndSelfPayCodesCode(code: string): code is CoverageTypeAndSelfPayCodesCode;
/**
 * Get concept details by code
 */
export declare function getCoverageTypeAndSelfPayCodesConcept(code: string): CoverageTypeAndSelfPayCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const CoverageTypeAndSelfPayCodesCodes: ("EHCPOL" | "pay" | "_ActCoverageTypeCode" | "_ActInsurancePolicyCode" | "_ActInsuranceTypeCode" | "_ActHealthInsuranceTypeCode" | "POS" | "DENTAL" | "DISEASE" | "DRUGPOL" | "HIP" | "LTC" | "MCPOL" | "HMO" | "PPO" | "MENTPOL" | "SUBPOL" | "VISPOL" | "DIS" | "EWB" | "FLEXP" | "LIFE" | "ANNU" | "TLIFE" | "ULIFE" | "PNC" | "REI" | "SURPL" | "UMBRL" | "_ActProgramTypeCode" | "CHAR" | "CRIME" | "EAP" | "GOVEMP" | "HIRISK" | "IND" | "MILITARY" | "RETIRE" | "SOCIAL" | "VET" | "HSAPOL" | "AUTOPOL" | "COL" | "UNINSMOT" | "PUBLICPOL" | "DENTPRG" | "DISEASEPRG" | "CANPRG" | "ENDRENAL" | "HIVAIDS" | "MANDPOL" | "MENTPRG" | "SAFNET" | "SUBPRG" | "SUBSIDIZ" | "SUBSIDMC" | "SUBSUPP" | "WCBPOL")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomCoverageTypeAndSelfPayCodesCode(): CoverageTypeAndSelfPayCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomCoverageTypeAndSelfPayCodesConcept(): CoverageTypeAndSelfPayCodesConcept;
