/**
 * ValueSet: ExampleRelatedClaimRelationshipCodes
 * URL: http://hl7.org/fhir/ValueSet/related-claim-relationship
 * Size: 2 concepts
 */
export const ExampleRelatedClaimRelationshipCodesConcepts = [
    { code: "prior", system: "http://terminology.hl7.org/CodeSystem/ex-relatedclaimrelationship", display: "Prior Claim" },
    { code: "associated", system: "http://terminology.hl7.org/CodeSystem/ex-relatedclaimrelationship", display: "Associated Claim" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidExampleRelatedClaimRelationshipCodesCode(code) {
    return ExampleRelatedClaimRelationshipCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getExampleRelatedClaimRelationshipCodesConcept(code) {
    return ExampleRelatedClaimRelationshipCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ExampleRelatedClaimRelationshipCodesCodes = ExampleRelatedClaimRelationshipCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomExampleRelatedClaimRelationshipCodesCode() {
    return ExampleRelatedClaimRelationshipCodesCodes[Math.floor(Math.random() * ExampleRelatedClaimRelationshipCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomExampleRelatedClaimRelationshipCodesConcept() {
    return ExampleRelatedClaimRelationshipCodesConcepts[Math.floor(Math.random() * ExampleRelatedClaimRelationshipCodesConcepts.length)];
}
