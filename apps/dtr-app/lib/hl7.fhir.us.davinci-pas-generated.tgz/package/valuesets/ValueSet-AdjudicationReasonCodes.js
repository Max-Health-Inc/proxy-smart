/**
 * ValueSet: AdjudicationReasonCodes
 * URL: http://hl7.org/fhir/ValueSet/adjudication-reason
 * Size: 2 concepts
 */
export const AdjudicationReasonCodesConcepts = [
    { code: "ar001", system: "http://terminology.hl7.org/CodeSystem/adjudication-reason", display: "Not covered" },
    { code: "ar002", system: "http://terminology.hl7.org/CodeSystem/adjudication-reason", display: "Plan Limit Reached" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidAdjudicationReasonCodesCode(code) {
    return AdjudicationReasonCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getAdjudicationReasonCodesConcept(code) {
    return AdjudicationReasonCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const AdjudicationReasonCodesCodes = AdjudicationReasonCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomAdjudicationReasonCodesCode() {
    return AdjudicationReasonCodesCodes[Math.floor(Math.random() * AdjudicationReasonCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomAdjudicationReasonCodesConcept() {
    return AdjudicationReasonCodesConcepts[Math.floor(Math.random() * AdjudicationReasonCodesConcepts.length)];
}
