/**
 * ValueSet: Form Codes
 * URL: http://hl7.org/fhir/ValueSet/forms
 * Size: 2 concepts
 */
export const FormCodesConcepts = [
    { code: "1", system: "http://terminology.hl7.org/CodeSystem/forms-codes", display: "Form #1" },
    { code: "2", system: "http://terminology.hl7.org/CodeSystem/forms-codes", display: "Form #1" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidFormCodesCode(code) {
    return FormCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getFormCodesConcept(code) {
    return FormCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const FormCodesCodes = FormCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomFormCodesCode() {
    return FormCodesCodes[Math.floor(Math.random() * FormCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomFormCodesConcept() {
    return FormCodesConcepts[Math.floor(Math.random() * FormCodesConcepts.length)];
}
