/**
 * ValueSet: ExampleDiagnosisRelatedGroupCodes
 * URL: http://hl7.org/fhir/ValueSet/ex-diagnosisrelatedgroup
 * Size: 4 concepts
 */
export declare const ExampleDiagnosisRelatedGroupCodesConcepts: readonly [{
    readonly code: "100";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-diagnosisrelatedgroup";
    readonly display: "Normal Vaginal Delivery";
}, {
    readonly code: "101";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-diagnosisrelatedgroup";
    readonly display: "Appendectomy - uncomplicated";
}, {
    readonly code: "300";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-diagnosisrelatedgroup";
    readonly display: "Tooth abscess";
}, {
    readonly code: "400";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-diagnosisrelatedgroup";
    readonly display: "Head trauma - concussion";
}];
/** Union type of all valid codes in this ValueSet */
export type ExampleDiagnosisRelatedGroupCodesCode = "100" | "101" | "300" | "400";
/** Type representing a concept from this ValueSet */
export type ExampleDiagnosisRelatedGroupCodesConcept = typeof ExampleDiagnosisRelatedGroupCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidExampleDiagnosisRelatedGroupCodesCode(code: string): code is ExampleDiagnosisRelatedGroupCodesCode;
/**
 * Get concept details by code
 */
export declare function getExampleDiagnosisRelatedGroupCodesConcept(code: string): ExampleDiagnosisRelatedGroupCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ExampleDiagnosisRelatedGroupCodesCodes: ("101" | "100" | "300" | "400")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomExampleDiagnosisRelatedGroupCodesCode(): ExampleDiagnosisRelatedGroupCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomExampleDiagnosisRelatedGroupCodesConcept(): ExampleDiagnosisRelatedGroupCodesConcept;
