/**
 * ValueSet: medicationRequest Category Codes
 * URL: http://hl7.org/fhir/ValueSet/medicationrequest-category
 * Size: 4 concepts
 */
export declare const MedicationRequestCategoryCodesConcepts: readonly [{
    readonly code: "inpatient";
    readonly system: "http://terminology.hl7.org/CodeSystem/medicationrequest-category";
    readonly display: "Inpatient";
}, {
    readonly code: "outpatient";
    readonly system: "http://terminology.hl7.org/CodeSystem/medicationrequest-category";
    readonly display: "Outpatient";
}, {
    readonly code: "community";
    readonly system: "http://terminology.hl7.org/CodeSystem/medicationrequest-category";
    readonly display: "Community";
}, {
    readonly code: "discharge";
    readonly system: "http://terminology.hl7.org/CodeSystem/medicationrequest-category";
    readonly display: "Discharge";
}];
/** Union type of all valid codes in this ValueSet */
export type MedicationRequestCategoryCodesCode = "inpatient" | "outpatient" | "community" | "discharge";
/** Type representing a concept from this ValueSet */
export type MedicationRequestCategoryCodesConcept = typeof MedicationRequestCategoryCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidMedicationRequestCategoryCodesCode(code: string): code is MedicationRequestCategoryCodesCode;
/**
 * Get concept details by code
 */
export declare function getMedicationRequestCategoryCodesConcept(code: string): MedicationRequestCategoryCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const MedicationRequestCategoryCodesCodes: ("discharge" | "inpatient" | "outpatient" | "community")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomMedicationRequestCategoryCodesCode(): MedicationRequestCategoryCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomMedicationRequestCategoryCodesConcept(): MedicationRequestCategoryCodesConcept;
