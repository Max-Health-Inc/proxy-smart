/**
 * ValueSet: ExampleServicePlaceCodes
 * URL: http://hl7.org/fhir/ValueSet/service-place
 * Size: 17 concepts
 */
export const ExampleServicePlaceCodesConcepts = [
    { code: "01", system: "http://terminology.hl7.org/CodeSystem/ex-serviceplace", display: "Pharmacy" },
    { code: "03", system: "http://terminology.hl7.org/CodeSystem/ex-serviceplace", display: "School" },
    { code: "04", system: "http://terminology.hl7.org/CodeSystem/ex-serviceplace", display: "Homeless Shelter" },
    { code: "05", system: "http://terminology.hl7.org/CodeSystem/ex-serviceplace", display: "Indian Health Service Free-standing Facility" },
    { code: "06", system: "http://terminology.hl7.org/CodeSystem/ex-serviceplace", display: "Indian Health Service Provider-based Facility" },
    { code: "07", system: "http://terminology.hl7.org/CodeSystem/ex-serviceplace", display: "Tribal 638 Free-Standing Facility" },
    { code: "08", system: "http://terminology.hl7.org/CodeSystem/ex-serviceplace", display: "Tribal 638 Provider-Based Facility" },
    { code: "09", system: "http://terminology.hl7.org/CodeSystem/ex-serviceplace", display: "Prison/Correctional Facility" },
    { code: "11", system: "http://terminology.hl7.org/CodeSystem/ex-serviceplace", display: "Office" },
    { code: "12", system: "http://terminology.hl7.org/CodeSystem/ex-serviceplace", display: "Home" },
    { code: "13", system: "http://terminology.hl7.org/CodeSystem/ex-serviceplace", display: "Assisted Living Fa" },
    { code: "14", system: "http://terminology.hl7.org/CodeSystem/ex-serviceplace", display: "Group Home" },
    { code: "15", system: "http://terminology.hl7.org/CodeSystem/ex-serviceplace", display: "Mobile Unit" },
    { code: "19", system: "http://terminology.hl7.org/CodeSystem/ex-serviceplace", display: "Off Campus-Outpatient Hospital" },
    { code: "20", system: "http://terminology.hl7.org/CodeSystem/ex-serviceplace", display: "Urgent Care Facility" },
    { code: "21", system: "http://terminology.hl7.org/CodeSystem/ex-serviceplace", display: "Inpatient Hospital" },
    { code: "41", system: "http://terminology.hl7.org/CodeSystem/ex-serviceplace", display: "Ambulance—Land" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidExampleServicePlaceCodesCode(code) {
    return ExampleServicePlaceCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getExampleServicePlaceCodesConcept(code) {
    return ExampleServicePlaceCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ExampleServicePlaceCodesCodes = ExampleServicePlaceCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomExampleServicePlaceCodesCode() {
    return ExampleServicePlaceCodesCodes[Math.floor(Math.random() * ExampleServicePlaceCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomExampleServicePlaceCodesConcept() {
    return ExampleServicePlaceCodesConcepts[Math.floor(Math.random() * ExampleServicePlaceCodesConcepts.length)];
}
