/**
 * ValueSet: Funds Reservation Codes
 * URL: http://hl7.org/fhir/ValueSet/fundsreserve
 * Size: 3 concepts
 */
export declare const FundsReservationCodesConcepts: readonly [{
    readonly code: "patient";
    readonly system: "http://terminology.hl7.org/CodeSystem/fundsreserve";
    readonly display: "Patient";
}, {
    readonly code: "provider";
    readonly system: "http://terminology.hl7.org/CodeSystem/fundsreserve";
    readonly display: "Provider";
}, {
    readonly code: "none";
    readonly system: "http://terminology.hl7.org/CodeSystem/fundsreserve";
    readonly display: "None";
}];
/** Union type of all valid codes in this ValueSet */
export type FundsReservationCodesCode = "patient" | "provider" | "none";
/** Type representing a concept from this ValueSet */
export type FundsReservationCodesConcept = typeof FundsReservationCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidFundsReservationCodesCode(code: string): code is FundsReservationCodesCode;
/**
 * Get concept details by code
 */
export declare function getFundsReservationCodesConcept(code: string): FundsReservationCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const FundsReservationCodesCodes: ("patient" | "provider" | "none")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomFundsReservationCodesCode(): FundsReservationCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomFundsReservationCodesConcept(): FundsReservationCodesConcept;
