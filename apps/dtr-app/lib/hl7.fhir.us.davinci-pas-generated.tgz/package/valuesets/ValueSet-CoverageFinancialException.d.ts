/**
 * ValueSet: coverage-financial-exception
 * URL: http://hl7.org/fhir/ValueSet/coverage-financial-exception
 * Size: 2 concepts
 */
export declare const CoverageFinancialExceptionConcepts: readonly [{
    readonly code: "retired";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-coverage-financial-exception";
}, {
    readonly code: "foster";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-coverage-financial-exception";
}];
/** Union type of all valid codes in this ValueSet */
export type CoverageFinancialExceptionCode = "retired" | "foster";
/** Type representing a concept from this ValueSet */
export type CoverageFinancialExceptionConcept = typeof CoverageFinancialExceptionConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidCoverageFinancialExceptionCode(code: string): code is CoverageFinancialExceptionCode;
/**
 * Get concept details by code
 */
export declare function getCoverageFinancialExceptionConcept(code: string): CoverageFinancialExceptionConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const CoverageFinancialExceptionCodes: ("retired" | "foster")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomCoverageFinancialExceptionCode(): CoverageFinancialExceptionCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomCoverageFinancialExceptionConcept(): CoverageFinancialExceptionConcept;
