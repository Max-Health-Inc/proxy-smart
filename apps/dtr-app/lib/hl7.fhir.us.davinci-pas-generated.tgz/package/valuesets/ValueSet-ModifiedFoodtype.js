/**
 * ValueSet: modified-foodtype
 * URL: http://hl7.org/fhir/ValueSet/modified-foodtype
 * Size: 14 concepts
 */
export const ModifiedFoodtypeConcepts = [
    { code: "255620007", system: "http://snomed.info/sct" },
    { code: "28647000", system: "http://snomed.info/sct" },
    { code: "22836000", system: "http://snomed.info/sct" },
    { code: "72511004", system: "http://snomed.info/sct" },
    { code: "226760005", system: "http://snomed.info/sct" },
    { code: "226887002", system: "http://snomed.info/sct" },
    { code: "102263004", system: "http://snomed.info/sct" },
    { code: "74242007", system: "http://snomed.info/sct" },
    { code: "227415002", system: "http://snomed.info/sct" },
    { code: "264331002", system: "http://snomed.info/sct" },
    { code: "227518002", system: "http://snomed.info/sct" },
    { code: "44027008", system: "http://snomed.info/sct" },
    { code: "226529007", system: "http://snomed.info/sct" },
    { code: "227210005", system: "http://snomed.info/sct" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidModifiedFoodtypeCode(code) {
    return ModifiedFoodtypeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getModifiedFoodtypeConcept(code) {
    return ModifiedFoodtypeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ModifiedFoodtypeCodes = ModifiedFoodtypeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomModifiedFoodtypeCode() {
    return ModifiedFoodtypeCodes[Math.floor(Math.random() * ModifiedFoodtypeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomModifiedFoodtypeConcept() {
    return ModifiedFoodtypeConcepts[Math.floor(Math.random() * ModifiedFoodtypeConcepts.length)];
}
