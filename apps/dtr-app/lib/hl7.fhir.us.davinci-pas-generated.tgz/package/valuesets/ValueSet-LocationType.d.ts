/**
 * ValueSet: LocationType
 * URL: http://hl7.org/fhir/ValueSet/location-physical-type
 * Size: 14 concepts
 */
export declare const LocationTypeConcepts: readonly [{
    readonly code: "si";
    readonly system: "http://terminology.hl7.org/CodeSystem/location-physical-type";
    readonly display: "Site";
}, {
    readonly code: "bu";
    readonly system: "http://terminology.hl7.org/CodeSystem/location-physical-type";
    readonly display: "Building";
}, {
    readonly code: "wi";
    readonly system: "http://terminology.hl7.org/CodeSystem/location-physical-type";
    readonly display: "Wing";
}, {
    readonly code: "wa";
    readonly system: "http://terminology.hl7.org/CodeSystem/location-physical-type";
    readonly display: "Ward";
}, {
    readonly code: "lvl";
    readonly system: "http://terminology.hl7.org/CodeSystem/location-physical-type";
    readonly display: "Level";
}, {
    readonly code: "co";
    readonly system: "http://terminology.hl7.org/CodeSystem/location-physical-type";
    readonly display: "Corridor";
}, {
    readonly code: "ro";
    readonly system: "http://terminology.hl7.org/CodeSystem/location-physical-type";
    readonly display: "Room";
}, {
    readonly code: "bd";
    readonly system: "http://terminology.hl7.org/CodeSystem/location-physical-type";
    readonly display: "Bed";
}, {
    readonly code: "ve";
    readonly system: "http://terminology.hl7.org/CodeSystem/location-physical-type";
    readonly display: "Vehicle";
}, {
    readonly code: "ho";
    readonly system: "http://terminology.hl7.org/CodeSystem/location-physical-type";
    readonly display: "House";
}, {
    readonly code: "ca";
    readonly system: "http://terminology.hl7.org/CodeSystem/location-physical-type";
    readonly display: "Cabinet";
}, {
    readonly code: "rd";
    readonly system: "http://terminology.hl7.org/CodeSystem/location-physical-type";
    readonly display: "Road";
}, {
    readonly code: "area";
    readonly system: "http://terminology.hl7.org/CodeSystem/location-physical-type";
    readonly display: "Area";
}, {
    readonly code: "jdn";
    readonly system: "http://terminology.hl7.org/CodeSystem/location-physical-type";
    readonly display: "Jurisdiction";
}];
/** Union type of all valid codes in this ValueSet */
export type LocationTypeCode = "si" | "bu" | "wi" | "wa" | "lvl" | "co" | "ro" | "bd" | "ve" | "ho" | "ca" | "rd" | "area" | "jdn";
/** Type representing a concept from this ValueSet */
export type LocationTypeConcept = typeof LocationTypeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidLocationTypeCode(code: string): code is LocationTypeCode;
/**
 * Get concept details by code
 */
export declare function getLocationTypeConcept(code: string): LocationTypeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const LocationTypeCodes: ("ca" | "si" | "bu" | "wi" | "wa" | "lvl" | "co" | "ro" | "bd" | "ve" | "ho" | "rd" | "area" | "jdn")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomLocationTypeCode(): LocationTypeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomLocationTypeConcept(): LocationTypeConcept;
