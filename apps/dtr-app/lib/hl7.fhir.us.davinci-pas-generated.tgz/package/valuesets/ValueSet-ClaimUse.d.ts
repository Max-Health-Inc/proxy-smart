/**
 * ValueSet: claim-use
 * URL: http://hl7.org/fhir/ValueSet/claim-use
 * Size: 3 concepts
 */
export declare const ClaimUseConcepts: readonly [{
    readonly code: "claim";
    readonly system: "http://hl7.org/fhir/claim-use";
}, {
    readonly code: "preauthorization";
    readonly system: "http://hl7.org/fhir/claim-use";
}, {
    readonly code: "predetermination";
    readonly system: "http://hl7.org/fhir/claim-use";
}];
/** Union type of all valid codes in this ValueSet */
export type ClaimUseCode = "claim" | "preauthorization" | "predetermination";
/** Type representing a concept from this ValueSet */
export type ClaimUseConcept = typeof ClaimUseConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidClaimUseCode(code: string): code is ClaimUseCode;
/**
 * Get concept details by code
 */
export declare function getClaimUseConcept(code: string): ClaimUseConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ClaimUseCodes: ("preauthorization" | "claim" | "predetermination")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomClaimUseCode(): ClaimUseCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomClaimUseConcept(): ClaimUseConcept;
