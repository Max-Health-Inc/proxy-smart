/**
 * ValueSet: encounter-discharge-disposition
 * URL: http://hl7.org/fhir/ValueSet/encounter-discharge-disposition
 * Size: 11 concepts
 */
export const EncounterDischargeDispositionConcepts = [
    { code: "home", system: "http://terminology.hl7.org/CodeSystem/discharge-disposition" },
    { code: "alt-home", system: "http://terminology.hl7.org/CodeSystem/discharge-disposition" },
    { code: "other-hcf", system: "http://terminology.hl7.org/CodeSystem/discharge-disposition" },
    { code: "hosp", system: "http://terminology.hl7.org/CodeSystem/discharge-disposition" },
    { code: "long", system: "http://terminology.hl7.org/CodeSystem/discharge-disposition" },
    { code: "aadvice", system: "http://terminology.hl7.org/CodeSystem/discharge-disposition" },
    { code: "exp", system: "http://terminology.hl7.org/CodeSystem/discharge-disposition" },
    { code: "psy", system: "http://terminology.hl7.org/CodeSystem/discharge-disposition" },
    { code: "rehab", system: "http://terminology.hl7.org/CodeSystem/discharge-disposition" },
    { code: "snf", system: "http://terminology.hl7.org/CodeSystem/discharge-disposition" },
    { code: "oth", system: "http://terminology.hl7.org/CodeSystem/discharge-disposition" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidEncounterDischargeDispositionCode(code) {
    return EncounterDischargeDispositionConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getEncounterDischargeDispositionConcept(code) {
    return EncounterDischargeDispositionConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const EncounterDischargeDispositionCodes = EncounterDischargeDispositionConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomEncounterDischargeDispositionCode() {
    return EncounterDischargeDispositionCodes[Math.floor(Math.random() * EncounterDischargeDispositionCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomEncounterDischargeDispositionConcept() {
    return EncounterDischargeDispositionConcepts[Math.floor(Math.random() * EncounterDischargeDispositionConcepts.length)];
}
