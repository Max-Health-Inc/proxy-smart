/**
 * ValueSet: ExampleServicePlaceCodes
 * URL: http://hl7.org/fhir/ValueSet/service-place
 * Size: 17 concepts
 */
export declare const ExampleServicePlaceCodesConcepts: readonly [{
    readonly code: "01";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-serviceplace";
    readonly display: "Pharmacy";
}, {
    readonly code: "03";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-serviceplace";
    readonly display: "School";
}, {
    readonly code: "04";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-serviceplace";
    readonly display: "Homeless Shelter";
}, {
    readonly code: "05";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-serviceplace";
    readonly display: "Indian Health Service Free-standing Facility";
}, {
    readonly code: "06";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-serviceplace";
    readonly display: "Indian Health Service Provider-based Facility";
}, {
    readonly code: "07";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-serviceplace";
    readonly display: "Tribal 638 Free-Standing Facility";
}, {
    readonly code: "08";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-serviceplace";
    readonly display: "Tribal 638 Provider-Based Facility";
}, {
    readonly code: "09";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-serviceplace";
    readonly display: "Prison/Correctional Facility";
}, {
    readonly code: "11";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-serviceplace";
    readonly display: "Office";
}, {
    readonly code: "12";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-serviceplace";
    readonly display: "Home";
}, {
    readonly code: "13";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-serviceplace";
    readonly display: "Assisted Living Fa";
}, {
    readonly code: "14";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-serviceplace";
    readonly display: "Group Home";
}, {
    readonly code: "15";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-serviceplace";
    readonly display: "Mobile Unit";
}, {
    readonly code: "19";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-serviceplace";
    readonly display: "Off Campus-Outpatient Hospital";
}, {
    readonly code: "20";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-serviceplace";
    readonly display: "Urgent Care Facility";
}, {
    readonly code: "21";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-serviceplace";
    readonly display: "Inpatient Hospital";
}, {
    readonly code: "41";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-serviceplace";
    readonly display: "Ambulance—Land";
}];
/** Union type of all valid codes in this ValueSet */
export type ExampleServicePlaceCodesCode = "01" | "03" | "04" | "05" | "06" | "07" | "08" | "09" | "11" | "12" | "13" | "14" | "15" | "19" | "20" | "21" | "41";
/** Type representing a concept from this ValueSet */
export type ExampleServicePlaceCodesConcept = typeof ExampleServicePlaceCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidExampleServicePlaceCodesCode(code: string): code is ExampleServicePlaceCodesCode;
/**
 * Get concept details by code
 */
export declare function getExampleServicePlaceCodesConcept(code: string): ExampleServicePlaceCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ExampleServicePlaceCodesCodes: ("09" | "11" | "12" | "13" | "14" | "15" | "19" | "20" | "21" | "01" | "03" | "04" | "05" | "06" | "07" | "08" | "41")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomExampleServicePlaceCodesCode(): ExampleServicePlaceCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomExampleServicePlaceCodesConcept(): ExampleServicePlaceCodesConcept;
