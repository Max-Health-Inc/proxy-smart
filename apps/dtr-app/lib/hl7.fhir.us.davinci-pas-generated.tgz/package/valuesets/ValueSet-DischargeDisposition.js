/**
 * ValueSet: DischargeDisposition
 * URL: http://hl7.org/fhir/ValueSet/encounter-discharge-disposition
 * Size: 11 concepts
 */
export const DischargeDispositionConcepts = [
    { code: "home", system: "http://terminology.hl7.org/CodeSystem/discharge-disposition", display: "Home" },
    { code: "alt-home", system: "http://terminology.hl7.org/CodeSystem/discharge-disposition", display: "Alternative home" },
    { code: "other-hcf", system: "http://terminology.hl7.org/CodeSystem/discharge-disposition", display: "Other healthcare facility" },
    { code: "hosp", system: "http://terminology.hl7.org/CodeSystem/discharge-disposition", display: "Hospice" },
    { code: "long", system: "http://terminology.hl7.org/CodeSystem/discharge-disposition", display: "Long-term care" },
    { code: "aadvice", system: "http://terminology.hl7.org/CodeSystem/discharge-disposition", display: "Left against advice" },
    { code: "exp", system: "http://terminology.hl7.org/CodeSystem/discharge-disposition", display: "Expired" },
    { code: "psy", system: "http://terminology.hl7.org/CodeSystem/discharge-disposition", display: "Psychiatric hospital" },
    { code: "rehab", system: "http://terminology.hl7.org/CodeSystem/discharge-disposition", display: "Rehabilitation" },
    { code: "snf", system: "http://terminology.hl7.org/CodeSystem/discharge-disposition", display: "Skilled nursing facility" },
    { code: "oth", system: "http://terminology.hl7.org/CodeSystem/discharge-disposition", display: "Other" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidDischargeDispositionCode(code) {
    return DischargeDispositionConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getDischargeDispositionConcept(code) {
    return DischargeDispositionConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const DischargeDispositionCodes = DischargeDispositionConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomDischargeDispositionCode() {
    return DischargeDispositionCodes[Math.floor(Math.random() * DischargeDispositionCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomDischargeDispositionConcept() {
    return DischargeDispositionConcepts[Math.floor(Math.random() * DischargeDispositionConcepts.length)];
}
