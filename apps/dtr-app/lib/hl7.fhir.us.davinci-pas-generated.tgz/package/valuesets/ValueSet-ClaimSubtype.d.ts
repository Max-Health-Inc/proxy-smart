/**
 * ValueSet: claim-subtype
 * URL: http://hl7.org/fhir/ValueSet/claim-subtype
 * Size: 2 concepts
 */
export declare const ClaimSubtypeConcepts: readonly [{
    readonly code: "ortho";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-claimsubtype";
}, {
    readonly code: "emergency";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-claimsubtype";
}];
/** Union type of all valid codes in this ValueSet */
export type ClaimSubtypeCode = "ortho" | "emergency";
/** Type representing a concept from this ValueSet */
export type ClaimSubtypeConcept = typeof ClaimSubtypeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidClaimSubtypeCode(code: string): code is ClaimSubtypeCode;
/**
 * Get concept details by code
 */
export declare function getClaimSubtypeConcept(code: string): ClaimSubtypeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ClaimSubtypeCodes: ("ortho" | "emergency")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomClaimSubtypeCode(): ClaimSubtypeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomClaimSubtypeConcept(): ClaimSubtypeConcept;
