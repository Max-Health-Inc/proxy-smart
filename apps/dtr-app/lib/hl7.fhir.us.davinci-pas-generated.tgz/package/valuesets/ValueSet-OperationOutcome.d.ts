/**
 * ValueSet: operation-outcome
 * URL: http://hl7.org/fhir/ValueSet/operation-outcome
 * Size: 50 concepts
 */
export declare const OperationOutcomeConcepts: readonly [{
    readonly code: "DELETE_MULTIPLE_MATCHES";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_AUTH_REQUIRED";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_BAD_FORMAT";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_BAD_SYNTAX";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_CANT_PARSE_CONTENT";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_CANT_PARSE_ROOT";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_CREATED";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_DATE_FORMAT";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_DELETED";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_DELETED_DONE";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_DELETED_ID";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_DUPLICATE_ID";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_ERROR_PARSING";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_ID_INVALID";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_ID_TOO_LONG";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_INVALID_ID";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_JSON_OBJECT";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_LOCAL_FAIL";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_NO_EXIST";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_NO_MATCH";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_NO_MODULE";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_NO_SUMMARY";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_OP_NOT_ALLOWED";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_PARAM_CHAINED";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_PARAM_INVALID";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_PARAM_MODIFIER_INVALID";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_PARAM_NO_REPEAT";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_PARAM_UNKNOWN";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_RESOURCE_EXAMPLE_PROTECTED";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_RESOURCE_ID_FAIL";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_RESOURCE_ID_MISMATCH";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_RESOURCE_ID_MISSING";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_RESOURCE_NOT_ALLOWED";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_RESOURCE_REQUIRED";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_RESOURCE_TYPE_MISMATCH";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_SORT_UNKNOWN";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_TRANSACTION_DUPLICATE_ID";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_TRANSACTION_MISSING_ID";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_UNHANDLED_NODE_TYPE";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_UNKNOWN_CONTENT";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_UNKNOWN_OPERATION";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_UNKNOWN_TYPE";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_UPDATED";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_VERSION_AWARE";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_VERSION_AWARE_CONFLICT";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_VERSION_AWARE_URL";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "MSG_WRONG_NS";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "SEARCH_MULTIPLE";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "SEARCH_NONE";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}, {
    readonly code: "UPDATE_MULTIPLE_MATCHES";
    readonly system: "http://terminology.hl7.org/CodeSystem/operation-outcome";
}];
/** String type (ValueSet too large for union type) */
export type OperationOutcomeCode = string;
/** Type representing a concept from this ValueSet */
export type OperationOutcomeConcept = typeof OperationOutcomeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidOperationOutcomeCode(code: string): code is OperationOutcomeCode;
/**
 * Get concept details by code
 */
export declare function getOperationOutcomeConcept(code: string): OperationOutcomeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const OperationOutcomeCodes: ("DELETE_MULTIPLE_MATCHES" | "MSG_AUTH_REQUIRED" | "MSG_BAD_FORMAT" | "MSG_BAD_SYNTAX" | "MSG_CANT_PARSE_CONTENT" | "MSG_CANT_PARSE_ROOT" | "MSG_CREATED" | "MSG_DATE_FORMAT" | "MSG_DELETED" | "MSG_DELETED_DONE" | "MSG_DELETED_ID" | "MSG_DUPLICATE_ID" | "MSG_ERROR_PARSING" | "MSG_ID_INVALID" | "MSG_ID_TOO_LONG" | "MSG_INVALID_ID" | "MSG_JSON_OBJECT" | "MSG_LOCAL_FAIL" | "MSG_NO_EXIST" | "MSG_NO_MATCH" | "MSG_NO_MODULE" | "MSG_NO_SUMMARY" | "MSG_OP_NOT_ALLOWED" | "MSG_PARAM_CHAINED" | "MSG_PARAM_INVALID" | "MSG_PARAM_MODIFIER_INVALID" | "MSG_PARAM_NO_REPEAT" | "MSG_PARAM_UNKNOWN" | "MSG_RESOURCE_EXAMPLE_PROTECTED" | "MSG_RESOURCE_ID_FAIL" | "MSG_RESOURCE_ID_MISMATCH" | "MSG_RESOURCE_ID_MISSING" | "MSG_RESOURCE_NOT_ALLOWED" | "MSG_RESOURCE_REQUIRED" | "MSG_RESOURCE_TYPE_MISMATCH" | "MSG_SORT_UNKNOWN" | "MSG_TRANSACTION_DUPLICATE_ID" | "MSG_TRANSACTION_MISSING_ID" | "MSG_UNHANDLED_NODE_TYPE" | "MSG_UNKNOWN_CONTENT" | "MSG_UNKNOWN_OPERATION" | "MSG_UNKNOWN_TYPE" | "MSG_UPDATED" | "MSG_VERSION_AWARE" | "MSG_VERSION_AWARE_CONFLICT" | "MSG_VERSION_AWARE_URL" | "MSG_WRONG_NS" | "SEARCH_MULTIPLE" | "SEARCH_NONE" | "UPDATE_MULTIPLE_MATCHES")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomOperationOutcomeCode(): OperationOutcomeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomOperationOutcomeConcept(): OperationOutcomeConcept;
