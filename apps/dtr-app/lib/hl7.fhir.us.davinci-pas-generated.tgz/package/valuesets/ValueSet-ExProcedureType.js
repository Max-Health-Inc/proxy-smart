/**
 * ValueSet: ex-procedure-type
 * URL: http://hl7.org/fhir/ValueSet/ex-procedure-type
 * Size: 2 concepts
 */
export const ExProcedureTypeConcepts = [
    { code: "primary", system: "http://terminology.hl7.org/CodeSystem/ex-procedure-type" },
    { code: "secondary", system: "http://terminology.hl7.org/CodeSystem/ex-procedure-type" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidExProcedureTypeCode(code) {
    return ExProcedureTypeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getExProcedureTypeConcept(code) {
    return ExProcedureTypeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ExProcedureTypeCodes = ExProcedureTypeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomExProcedureTypeCode() {
    return ExProcedureTypeCodes[Math.floor(Math.random() * ExProcedureTypeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomExProcedureTypeConcept() {
    return ExProcedureTypeConcepts[Math.floor(Math.random() * ExProcedureTypeConcepts.length)];
}
