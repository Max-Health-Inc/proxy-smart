/**
 * ValueSet: NoteType
 * URL: http://hl7.org/fhir/ValueSet/note-type
 * Size: 3 concepts
 */
export declare const NoteTypeConcepts: readonly [{
    readonly code: "display";
    readonly system: "http://hl7.org/fhir/note-type";
    readonly display: "Display";
}, {
    readonly code: "print";
    readonly system: "http://hl7.org/fhir/note-type";
    readonly display: "Print (Form)";
}, {
    readonly code: "printoper";
    readonly system: "http://hl7.org/fhir/note-type";
    readonly display: "Print (Operator)";
}];
/** Union type of all valid codes in this ValueSet */
export type NoteTypeCode = "display" | "print" | "printoper";
/** Type representing a concept from this ValueSet */
export type NoteTypeConcept = typeof NoteTypeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidNoteTypeCode(code: string): code is NoteTypeCode;
/**
 * Get concept details by code
 */
export declare function getNoteTypeConcept(code: string): NoteTypeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const NoteTypeCodes: ("display" | "print" | "printoper")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomNoteTypeCode(): NoteTypeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomNoteTypeConcept(): NoteTypeConcept;
