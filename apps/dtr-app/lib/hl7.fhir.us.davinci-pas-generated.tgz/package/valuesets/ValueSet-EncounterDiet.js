/**
 * ValueSet: encounter-diet
 * URL: http://hl7.org/fhir/ValueSet/encounter-diet
 * Size: 7 concepts
 */
export const EncounterDietConcepts = [
    { code: "vegetarian", system: "http://terminology.hl7.org/CodeSystem/diet" },
    { code: "dairy-free", system: "http://terminology.hl7.org/CodeSystem/diet" },
    { code: "nut-free", system: "http://terminology.hl7.org/CodeSystem/diet" },
    { code: "gluten-free", system: "http://terminology.hl7.org/CodeSystem/diet" },
    { code: "vegan", system: "http://terminology.hl7.org/CodeSystem/diet" },
    { code: "halal", system: "http://terminology.hl7.org/CodeSystem/diet" },
    { code: "kosher", system: "http://terminology.hl7.org/CodeSystem/diet" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidEncounterDietCode(code) {
    return EncounterDietConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getEncounterDietConcept(code) {
    return EncounterDietConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const EncounterDietCodes = EncounterDietConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomEncounterDietCode() {
    return EncounterDietCodes[Math.floor(Math.random() * EncounterDietCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomEncounterDietConcept() {
    return EncounterDietConcepts[Math.floor(Math.random() * EncounterDietConcepts.length)];
}
