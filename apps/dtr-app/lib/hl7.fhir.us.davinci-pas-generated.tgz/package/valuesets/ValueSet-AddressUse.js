/**
 * ValueSet: address-use
 * URL: http://hl7.org/fhir/ValueSet/address-use
 * Size: 5 concepts
 */
export const AddressUseConcepts = [
    { code: "home", system: "http://hl7.org/fhir/address-use" },
    { code: "work", system: "http://hl7.org/fhir/address-use" },
    { code: "temp", system: "http://hl7.org/fhir/address-use" },
    { code: "old", system: "http://hl7.org/fhir/address-use" },
    { code: "billing", system: "http://hl7.org/fhir/address-use" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidAddressUseCode(code) {
    return AddressUseConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getAddressUseConcept(code) {
    return AddressUseConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const AddressUseCodes = AddressUseConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomAddressUseCode() {
    return AddressUseCodes[Math.floor(Math.random() * AddressUseCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomAddressUseConcept() {
    return AddressUseConcepts[Math.floor(Math.random() * AddressUseConcepts.length)];
}
