/**
 * ValueSet: adjudication-reason
 * URL: http://hl7.org/fhir/ValueSet/adjudication-reason
 * Size: 2 concepts
 */
export const AdjudicationReasonConcepts = [
    { code: "ar001", system: "http://terminology.hl7.org/CodeSystem/adjudication-reason" },
    { code: "ar002", system: "http://terminology.hl7.org/CodeSystem/adjudication-reason" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidAdjudicationReasonCode(code) {
    return AdjudicationReasonConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getAdjudicationReasonConcept(code) {
    return AdjudicationReasonConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const AdjudicationReasonCodes = AdjudicationReasonConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomAdjudicationReasonCode() {
    return AdjudicationReasonCodes[Math.floor(Math.random() * AdjudicationReasonCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomAdjudicationReasonConcept() {
    return AdjudicationReasonConcepts[Math.floor(Math.random() * AdjudicationReasonConcepts.length)];
}
