/**
 * ValueSet: OralSiteCodes
 * URL: http://hl7.org/fhir/ValueSet/tooth
 * Size: 41 concepts
 */
export const OralSiteCodesConcepts = [
    { code: "0", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "Oral cavity" },
    { code: "1", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "1" },
    { code: "2", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "2" },
    { code: "3", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "3" },
    { code: "4", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "4" },
    { code: "5", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "5" },
    { code: "6", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "6" },
    { code: "7", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "7" },
    { code: "8", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "8" },
    { code: "11", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "11" },
    { code: "12", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "12" },
    { code: "13", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "13" },
    { code: "14", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "14" },
    { code: "15", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "15" },
    { code: "16", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "16" },
    { code: "17", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "17" },
    { code: "18", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "18" },
    { code: "21", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "21" },
    { code: "22", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "22" },
    { code: "23", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "23" },
    { code: "24", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "24" },
    { code: "25", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "25" },
    { code: "26", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "26" },
    { code: "27", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "27" },
    { code: "28", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "28" },
    { code: "31", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "31" },
    { code: "32", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "32" },
    { code: "33", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "33" },
    { code: "34", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "34" },
    { code: "35", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "35" },
    { code: "36", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "36" },
    { code: "37", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "37" },
    { code: "38", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "38" },
    { code: "41", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "41" },
    { code: "42", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "42" },
    { code: "43", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "43" },
    { code: "44", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "44" },
    { code: "45", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "45" },
    { code: "46", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "46" },
    { code: "47", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "47" },
    { code: "48", system: "http://terminology.hl7.org/CodeSystem/ex-tooth", display: "48" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidOralSiteCodesCode(code) {
    return OralSiteCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getOralSiteCodesConcept(code) {
    return OralSiteCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const OralSiteCodesCodes = OralSiteCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomOralSiteCodesCode() {
    return OralSiteCodesCodes[Math.floor(Math.random() * OralSiteCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomOralSiteCodesConcept() {
    return OralSiteCodesConcepts[Math.floor(Math.random() * OralSiteCodesConcepts.length)];
}
