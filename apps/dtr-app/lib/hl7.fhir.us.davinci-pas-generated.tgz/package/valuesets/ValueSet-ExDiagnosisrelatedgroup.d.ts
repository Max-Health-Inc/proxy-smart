/**
 * ValueSet: ex-diagnosisrelatedgroup
 * URL: http://hl7.org/fhir/ValueSet/ex-diagnosisrelatedgroup
 * Size: 4 concepts
 */
export declare const ExDiagnosisrelatedgroupConcepts: readonly [{
    readonly code: "100";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-diagnosisrelatedgroup";
}, {
    readonly code: "101";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-diagnosisrelatedgroup";
}, {
    readonly code: "300";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-diagnosisrelatedgroup";
}, {
    readonly code: "400";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-diagnosisrelatedgroup";
}];
/** Union type of all valid codes in this ValueSet */
export type ExDiagnosisrelatedgroupCode = "100" | "101" | "300" | "400";
/** Type representing a concept from this ValueSet */
export type ExDiagnosisrelatedgroupConcept = typeof ExDiagnosisrelatedgroupConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidExDiagnosisrelatedgroupCode(code: string): code is ExDiagnosisrelatedgroupCode;
/**
 * Get concept details by code
 */
export declare function getExDiagnosisrelatedgroupConcept(code: string): ExDiagnosisrelatedgroupConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ExDiagnosisrelatedgroupCodes: ("101" | "100" | "300" | "400")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomExDiagnosisrelatedgroupCode(): ExDiagnosisrelatedgroupCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomExDiagnosisrelatedgroupConcept(): ExDiagnosisrelatedgroupConcept;
