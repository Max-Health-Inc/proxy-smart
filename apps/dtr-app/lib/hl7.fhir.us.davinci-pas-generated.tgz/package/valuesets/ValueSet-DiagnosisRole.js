/**
 * ValueSet: DiagnosisRole
 * URL: http://hl7.org/fhir/ValueSet/diagnosis-role
 * Size: 7 concepts
 */
export const DiagnosisRoleConcepts = [
    { code: "AD", system: "http://terminology.hl7.org/CodeSystem/diagnosis-role", display: "Admission diagnosis" },
    { code: "DD", system: "http://terminology.hl7.org/CodeSystem/diagnosis-role", display: "Discharge diagnosis" },
    { code: "CC", system: "http://terminology.hl7.org/CodeSystem/diagnosis-role", display: "Chief complaint" },
    { code: "CM", system: "http://terminology.hl7.org/CodeSystem/diagnosis-role", display: "Comorbidity diagnosis" },
    { code: "pre-op", system: "http://terminology.hl7.org/CodeSystem/diagnosis-role", display: "pre-op diagnosis" },
    { code: "post-op", system: "http://terminology.hl7.org/CodeSystem/diagnosis-role", display: "post-op diagnosis" },
    { code: "billing", system: "http://terminology.hl7.org/CodeSystem/diagnosis-role", display: "Billing" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidDiagnosisRoleCode(code) {
    return DiagnosisRoleConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getDiagnosisRoleConcept(code) {
    return DiagnosisRoleConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const DiagnosisRoleCodes = DiagnosisRoleConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomDiagnosisRoleCode() {
    return DiagnosisRoleCodes[Math.floor(Math.random() * DiagnosisRoleCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomDiagnosisRoleConcept() {
    return DiagnosisRoleConcepts[Math.floor(Math.random() * DiagnosisRoleConcepts.length)];
}
