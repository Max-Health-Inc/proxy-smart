/**
 * ValueSet: EventTiming
 * URL: http://hl7.org/fhir/ValueSet/event-timing
 * Size: 14 concepts
 */
export declare const EventTimingConcepts: readonly [{
    readonly code: "HS";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-TimingEvent";
}, {
    readonly code: "WAKE";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-TimingEvent";
}, {
    readonly code: "C";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-TimingEvent";
}, {
    readonly code: "CM";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-TimingEvent";
}, {
    readonly code: "CD";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-TimingEvent";
}, {
    readonly code: "CV";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-TimingEvent";
}, {
    readonly code: "AC";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-TimingEvent";
}, {
    readonly code: "ACM";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-TimingEvent";
}, {
    readonly code: "ACD";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-TimingEvent";
}, {
    readonly code: "ACV";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-TimingEvent";
}, {
    readonly code: "PC";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-TimingEvent";
}, {
    readonly code: "PCM";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-TimingEvent";
}, {
    readonly code: "PCD";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-TimingEvent";
}, {
    readonly code: "PCV";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-TimingEvent";
}];
/** Union type of all valid codes in this ValueSet */
export type EventTimingCode = "HS" | "WAKE" | "C" | "CM" | "CD" | "CV" | "AC" | "ACM" | "ACD" | "ACV" | "PC" | "PCM" | "PCD" | "PCV";
/** Type representing a concept from this ValueSet */
export type EventTimingConcept = typeof EventTimingConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidEventTimingCode(code: string): code is EventTimingCode;
/**
 * Get concept details by code
 */
export declare function getEventTimingConcept(code: string): EventTimingConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const EventTimingCodes: ("CM" | "HS" | "WAKE" | "C" | "CD" | "CV" | "AC" | "ACM" | "ACD" | "ACV" | "PC" | "PCM" | "PCD" | "PCV")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomEventTimingCode(): EventTimingCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomEventTimingConcept(): EventTimingConcept;
