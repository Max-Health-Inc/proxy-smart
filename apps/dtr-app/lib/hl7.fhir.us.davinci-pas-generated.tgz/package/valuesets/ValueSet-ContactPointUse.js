/**
 * ValueSet: contact-point-use
 * URL: http://hl7.org/fhir/ValueSet/contact-point-use
 * Size: 5 concepts
 */
export const ContactPointUseConcepts = [
    { code: "home", system: "http://hl7.org/fhir/contact-point-use" },
    { code: "work", system: "http://hl7.org/fhir/contact-point-use" },
    { code: "temp", system: "http://hl7.org/fhir/contact-point-use" },
    { code: "old", system: "http://hl7.org/fhir/contact-point-use" },
    { code: "mobile", system: "http://hl7.org/fhir/contact-point-use" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidContactPointUseCode(code) {
    return ContactPointUseConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getContactPointUseConcept(code) {
    return ContactPointUseConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ContactPointUseCodes = ContactPointUseConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomContactPointUseCode() {
    return ContactPointUseCodes[Math.floor(Math.random() * ContactPointUseCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomContactPointUseConcept() {
    return ContactPointUseConcepts[Math.floor(Math.random() * ContactPointUseConcepts.length)];
}
