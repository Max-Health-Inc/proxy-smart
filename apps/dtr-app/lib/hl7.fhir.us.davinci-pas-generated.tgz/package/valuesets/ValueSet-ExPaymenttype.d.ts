/**
 * ValueSet: ex-paymenttype
 * URL: http://hl7.org/fhir/ValueSet/ex-paymenttype
 * Size: 2 concepts
 */
export declare const ExPaymenttypeConcepts: readonly [{
    readonly code: "complete";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-paymenttype";
}, {
    readonly code: "partial";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-paymenttype";
}];
/** Union type of all valid codes in this ValueSet */
export type ExPaymenttypeCode = "complete" | "partial";
/** Type representing a concept from this ValueSet */
export type ExPaymenttypeConcept = typeof ExPaymenttypeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidExPaymenttypeCode(code: string): code is ExPaymenttypeCode;
/**
 * Get concept details by code
 */
export declare function getExPaymenttypeConcept(code: string): ExPaymenttypeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ExPaymenttypeCodes: ("complete" | "partial")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomExPaymenttypeCode(): ExPaymenttypeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomExPaymenttypeConcept(): ExPaymenttypeConcept;
