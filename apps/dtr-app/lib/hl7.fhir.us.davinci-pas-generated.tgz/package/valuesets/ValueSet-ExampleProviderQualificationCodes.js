/**
 * ValueSet: ExampleProviderQualificationCodes
 * URL: http://hl7.org/fhir/ValueSet/provider-qualification
 * Size: 3 concepts
 */
export const ExampleProviderQualificationCodesConcepts = [
    { code: "311405", system: "http://terminology.hl7.org/CodeSystem/ex-providerqualification", display: "Dentist" },
    { code: "604215", system: "http://terminology.hl7.org/CodeSystem/ex-providerqualification", display: "Ophthalmologist" },
    { code: "604210", system: "http://terminology.hl7.org/CodeSystem/ex-providerqualification", display: "Optometrist" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidExampleProviderQualificationCodesCode(code) {
    return ExampleProviderQualificationCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getExampleProviderQualificationCodesConcept(code) {
    return ExampleProviderQualificationCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ExampleProviderQualificationCodesCodes = ExampleProviderQualificationCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomExampleProviderQualificationCodesCode() {
    return ExampleProviderQualificationCodesCodes[Math.floor(Math.random() * ExampleProviderQualificationCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomExampleProviderQualificationCodesConcept() {
    return ExampleProviderQualificationCodesConcepts[Math.floor(Math.random() * ExampleProviderQualificationCodesConcepts.length)];
}
