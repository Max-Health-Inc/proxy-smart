/**
 * ValueSet: adjudication
 * URL: http://hl7.org/fhir/ValueSet/adjudication
 * Size: 8 concepts
 */
export const AdjudicationConcepts = [
    { code: "submitted", system: "http://terminology.hl7.org/CodeSystem/adjudication" },
    { code: "copay", system: "http://terminology.hl7.org/CodeSystem/adjudication" },
    { code: "eligible", system: "http://terminology.hl7.org/CodeSystem/adjudication" },
    { code: "deductible", system: "http://terminology.hl7.org/CodeSystem/adjudication" },
    { code: "unallocdeduct", system: "http://terminology.hl7.org/CodeSystem/adjudication" },
    { code: "eligpercent", system: "http://terminology.hl7.org/CodeSystem/adjudication" },
    { code: "tax", system: "http://terminology.hl7.org/CodeSystem/adjudication" },
    { code: "benefit", system: "http://terminology.hl7.org/CodeSystem/adjudication" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidAdjudicationCode(code) {
    return AdjudicationConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getAdjudicationConcept(code) {
    return AdjudicationConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const AdjudicationCodes = AdjudicationConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomAdjudicationCode() {
    return AdjudicationCodes[Math.floor(Math.random() * AdjudicationCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomAdjudicationConcept() {
    return AdjudicationConcepts[Math.floor(Math.random() * AdjudicationConcepts.length)];
}
