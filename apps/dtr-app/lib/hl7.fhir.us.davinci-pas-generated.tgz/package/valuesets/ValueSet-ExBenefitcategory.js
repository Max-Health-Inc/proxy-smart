/**
 * ValueSet: ex-benefitcategory
 * URL: http://hl7.org/fhir/ValueSet/ex-benefitcategory
 * Size: 28 concepts
 */
export const ExBenefitcategoryConcepts = [
    { code: "1", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory" },
    { code: "2", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory" },
    { code: "3", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory" },
    { code: "4", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory" },
    { code: "5", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory" },
    { code: "14", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory" },
    { code: "23", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory" },
    { code: "24", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory" },
    { code: "25", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory" },
    { code: "26", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory" },
    { code: "27", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory" },
    { code: "28", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory" },
    { code: "30", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory" },
    { code: "35", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory" },
    { code: "36", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory" },
    { code: "37", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory" },
    { code: "49", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory" },
    { code: "55", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory" },
    { code: "56", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory" },
    { code: "61", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory" },
    { code: "62", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory" },
    { code: "63", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory" },
    { code: "69", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory" },
    { code: "76", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory" },
    { code: "F1", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory" },
    { code: "F3", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory" },
    { code: "F4", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory" },
    { code: "F6", system: "http://terminology.hl7.org/CodeSystem/ex-benefitcategory" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidExBenefitcategoryCode(code) {
    return ExBenefitcategoryConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getExBenefitcategoryConcept(code) {
    return ExBenefitcategoryConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ExBenefitcategoryCodes = ExBenefitcategoryConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomExBenefitcategoryCode() {
    return ExBenefitcategoryCodes[Math.floor(Math.random() * ExBenefitcategoryCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomExBenefitcategoryConcept() {
    return ExBenefitcategoryConcepts[Math.floor(Math.random() * ExBenefitcategoryConcepts.length)];
}
