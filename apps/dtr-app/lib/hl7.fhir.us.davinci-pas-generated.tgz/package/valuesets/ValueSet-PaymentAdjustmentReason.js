/**
 * ValueSet: payment-adjustment-reason
 * URL: http://hl7.org/fhir/ValueSet/payment-adjustment-reason
 * Size: 2 concepts
 */
export const PaymentAdjustmentReasonConcepts = [
    { code: "a001", system: "http://terminology.hl7.org/CodeSystem/payment-adjustment-reason" },
    { code: "a002", system: "http://terminology.hl7.org/CodeSystem/payment-adjustment-reason" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidPaymentAdjustmentReasonCode(code) {
    return PaymentAdjustmentReasonConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getPaymentAdjustmentReasonConcept(code) {
    return PaymentAdjustmentReasonConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const PaymentAdjustmentReasonCodes = PaymentAdjustmentReasonConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomPaymentAdjustmentReasonCode() {
    return PaymentAdjustmentReasonCodes[Math.floor(Math.random() * PaymentAdjustmentReasonCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomPaymentAdjustmentReasonConcept() {
    return PaymentAdjustmentReasonConcepts[Math.floor(Math.random() * PaymentAdjustmentReasonConcepts.length)];
}
