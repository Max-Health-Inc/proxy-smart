/**
 * ValueSet: Form Codes
 * URL: http://hl7.org/fhir/ValueSet/forms
 * Size: 2 concepts
 */
export declare const FormCodesConcepts: readonly [{
    readonly code: "1";
    readonly system: "http://terminology.hl7.org/CodeSystem/forms-codes";
    readonly display: "Form #1";
}, {
    readonly code: "2";
    readonly system: "http://terminology.hl7.org/CodeSystem/forms-codes";
    readonly display: "Form #1";
}];
/** Union type of all valid codes in this ValueSet */
export type FormCodesCode = "1" | "2";
/** Type representing a concept from this ValueSet */
export type FormCodesConcept = typeof FormCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidFormCodesCode(code: string): code is FormCodesCode;
/**
 * Get concept details by code
 */
export declare function getFormCodesConcept(code: string): FormCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const FormCodesCodes: ("1" | "2")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomFormCodesCode(): FormCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomFormCodesConcept(): FormCodesConcept;
