/**
 * ValueSet: claim-subtype
 * URL: http://hl7.org/fhir/ValueSet/claim-subtype
 * Size: 2 concepts
 */
export const ClaimSubtypeConcepts = [
    { code: "ortho", system: "http://terminology.hl7.org/CodeSystem/ex-claimsubtype" },
    { code: "emergency", system: "http://terminology.hl7.org/CodeSystem/ex-claimsubtype" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidClaimSubtypeCode(code) {
    return ClaimSubtypeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getClaimSubtypeConcept(code) {
    return ClaimSubtypeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ClaimSubtypeCodes = ClaimSubtypeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomClaimSubtypeCode() {
    return ClaimSubtypeCodes[Math.floor(Math.random() * ClaimSubtypeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomClaimSubtypeConcept() {
    return ClaimSubtypeConcepts[Math.floor(Math.random() * ClaimSubtypeConcepts.length)];
}
