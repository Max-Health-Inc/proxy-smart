/**
 * ValueSet: payeetype
 * URL: http://hl7.org/fhir/ValueSet/payeetype
 * Size: 3 concepts
 */
export const PayeetypeConcepts = [
    { code: "subscriber", system: "http://terminology.hl7.org/CodeSystem/payeetype" },
    { code: "provider", system: "http://terminology.hl7.org/CodeSystem/payeetype" },
    { code: "other", system: "http://terminology.hl7.org/CodeSystem/payeetype" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidPayeetypeCode(code) {
    return PayeetypeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getPayeetypeConcept(code) {
    return PayeetypeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const PayeetypeCodes = PayeetypeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomPayeetypeCode() {
    return PayeetypeCodes[Math.floor(Math.random() * PayeetypeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomPayeetypeConcept() {
    return PayeetypeConcepts[Math.floor(Math.random() * PayeetypeConcepts.length)];
}
