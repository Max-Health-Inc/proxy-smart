/**
 * ValueSet: encounter-location-status
 * URL: http://hl7.org/fhir/ValueSet/encounter-location-status
 * Size: 4 concepts
 */
export declare const EncounterLocationStatusConcepts: readonly [{
    readonly code: "planned";
    readonly system: "http://hl7.org/fhir/encounter-location-status";
}, {
    readonly code: "active";
    readonly system: "http://hl7.org/fhir/encounter-location-status";
}, {
    readonly code: "reserved";
    readonly system: "http://hl7.org/fhir/encounter-location-status";
}, {
    readonly code: "completed";
    readonly system: "http://hl7.org/fhir/encounter-location-status";
}];
/** Union type of all valid codes in this ValueSet */
export type EncounterLocationStatusCode = "planned" | "active" | "reserved" | "completed";
/** Type representing a concept from this ValueSet */
export type EncounterLocationStatusConcept = typeof EncounterLocationStatusConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidEncounterLocationStatusCode(code: string): code is EncounterLocationStatusCode;
/**
 * Get concept details by code
 */
export declare function getEncounterLocationStatusConcept(code: string): EncounterLocationStatusConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const EncounterLocationStatusCodes: ("active" | "completed" | "planned" | "reserved")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomEncounterLocationStatusCode(): EncounterLocationStatusCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomEncounterLocationStatusConcept(): EncounterLocationStatusConcept;
