/**
 * ValueSet: CoverageClassCodes
 * URL: http://hl7.org/fhir/ValueSet/coverage-class
 * Size: 11 concepts
 */
export declare const CoverageClassCodesConcepts: readonly [{
    readonly code: "group";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-class";
    readonly display: "Group";
}, {
    readonly code: "subgroup";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-class";
    readonly display: "SubGroup";
}, {
    readonly code: "plan";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-class";
    readonly display: "Plan";
}, {
    readonly code: "subplan";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-class";
    readonly display: "SubPlan";
}, {
    readonly code: "class";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-class";
    readonly display: "Class";
}, {
    readonly code: "subclass";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-class";
    readonly display: "SubClass";
}, {
    readonly code: "sequence";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-class";
    readonly display: "Sequence";
}, {
    readonly code: "rxbin";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-class";
    readonly display: "RX BIN";
}, {
    readonly code: "rxpcn";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-class";
    readonly display: "RX PCN";
}, {
    readonly code: "rxid";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-class";
    readonly display: "RX Id";
}, {
    readonly code: "rxgroup";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-class";
    readonly display: "RX Group";
}];
/** Union type of all valid codes in this ValueSet */
export type CoverageClassCodesCode = "group" | "subgroup" | "plan" | "subplan" | "class" | "subclass" | "sequence" | "rxbin" | "rxpcn" | "rxid" | "rxgroup";
/** Type representing a concept from this ValueSet */
export type CoverageClassCodesConcept = typeof CoverageClassCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidCoverageClassCodesCode(code: string): code is CoverageClassCodesCode;
/**
 * Get concept details by code
 */
export declare function getCoverageClassCodesConcept(code: string): CoverageClassCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const CoverageClassCodesCodes: ("class" | "rxid" | "plan" | "group" | "subgroup" | "subplan" | "subclass" | "sequence" | "rxbin" | "rxpcn" | "rxgroup")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomCoverageClassCodesCode(): CoverageClassCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomCoverageClassCodesConcept(): CoverageClassCodesConcept;
