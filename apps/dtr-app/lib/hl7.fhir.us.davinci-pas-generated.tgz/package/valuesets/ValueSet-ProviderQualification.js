/**
 * ValueSet: provider-qualification
 * URL: http://hl7.org/fhir/ValueSet/provider-qualification
 * Size: 3 concepts
 */
export const ProviderQualificationConcepts = [
    { code: "311405", system: "http://terminology.hl7.org/CodeSystem/ex-providerqualification" },
    { code: "604215", system: "http://terminology.hl7.org/CodeSystem/ex-providerqualification" },
    { code: "604210", system: "http://terminology.hl7.org/CodeSystem/ex-providerqualification" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidProviderQualificationCode(code) {
    return ProviderQualificationConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getProviderQualificationConcept(code) {
    return ProviderQualificationConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ProviderQualificationCodes = ProviderQualificationConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomProviderQualificationCode() {
    return ProviderQualificationCodes[Math.floor(Math.random() * ProviderQualificationCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomProviderQualificationConcept() {
    return ProviderQualificationConcepts[Math.floor(Math.random() * ProviderQualificationConcepts.length)];
}
