/**
 * ValueSet: hrex-task-status
 * URL: http://hl7.org/fhir/us/davinci-hrex/ValueSet/hrex-task-status
 * Size: 7 concepts
 */
export declare const HrexTaskStatusConcepts: readonly [{
    readonly code: "requested";
    readonly system: "http://hl7.org/fhir/task-status";
}, {
    readonly code: "accepted";
    readonly system: "http://hl7.org/fhir/task-status";
}, {
    readonly code: "rejected";
    readonly system: "http://hl7.org/fhir/task-status";
}, {
    readonly code: "in-progress";
    readonly system: "http://hl7.org/fhir/task-status";
}, {
    readonly code: "failed";
    readonly system: "http://hl7.org/fhir/task-status";
}, {
    readonly code: "completed";
    readonly system: "http://hl7.org/fhir/task-status";
}, {
    readonly code: "on-hold";
    readonly system: "http://hl7.org/fhir/task-status";
}];
/** Union type of all valid codes in this ValueSet */
export type HrexTaskStatusCode = "requested" | "accepted" | "rejected" | "in-progress" | "failed" | "completed" | "on-hold";
/** Type representing a concept from this ValueSet */
export type HrexTaskStatusConcept = typeof HrexTaskStatusConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidHrexTaskStatusCode(code: string): code is HrexTaskStatusCode;
/**
 * Get concept details by code
 */
export declare function getHrexTaskStatusConcept(code: string): HrexTaskStatusConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const HrexTaskStatusCodes: ("completed" | "requested" | "on-hold" | "in-progress" | "accepted" | "rejected" | "failed")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomHrexTaskStatusCode(): HrexTaskStatusCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomHrexTaskStatusConcept(): HrexTaskStatusConcept;
