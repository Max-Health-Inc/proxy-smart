/**
 * ValueSet: ICD-10ProcedureCodes
 * URL: http://hl7.org/fhir/ValueSet/icd-10-procedures
 * Size: 3 concepts
 */
export const ICD10ProcedureCodesConcepts = [
    { code: "123001", system: "http://hl7.org/fhir/sid/ex-icd-10-procedures", display: "PROC-1" },
    { code: "123002", system: "http://hl7.org/fhir/sid/ex-icd-10-procedures", display: "PROC-2" },
    { code: "123003", system: "http://hl7.org/fhir/sid/ex-icd-10-procedures", display: "PROC-3" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidICD10ProcedureCodesCode(code) {
    return ICD10ProcedureCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getICD10ProcedureCodesConcept(code) {
    return ICD10ProcedureCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ICD10ProcedureCodesCodes = ICD10ProcedureCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomICD10ProcedureCodesCode() {
    return ICD10ProcedureCodesCodes[Math.floor(Math.random() * ICD10ProcedureCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomICD10ProcedureCodesConcept() {
    return ICD10ProcedureCodesConcepts[Math.floor(Math.random() * ICD10ProcedureCodesConcepts.length)];
}
