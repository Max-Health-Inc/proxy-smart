/**
 * ValueSet: coverage-copay-type
 * URL: http://hl7.org/fhir/ValueSet/coverage-copay-type
 * Size: 10 concepts
 */
export declare const CoverageCopayTypeConcepts: readonly [{
    readonly code: "gpvisit";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type";
}, {
    readonly code: "spvisit";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type";
}, {
    readonly code: "emergency";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type";
}, {
    readonly code: "inpthosp";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type";
}, {
    readonly code: "televisit";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type";
}, {
    readonly code: "urgentcare";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type";
}, {
    readonly code: "copaypct";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type";
}, {
    readonly code: "copay";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type";
}, {
    readonly code: "deductible";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type";
}, {
    readonly code: "maxoutofpocket";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type";
}];
/** Union type of all valid codes in this ValueSet */
export type CoverageCopayTypeCode = "gpvisit" | "spvisit" | "emergency" | "inpthosp" | "televisit" | "urgentcare" | "copaypct" | "copay" | "deductible" | "maxoutofpocket";
/** Type representing a concept from this ValueSet */
export type CoverageCopayTypeConcept = typeof CoverageCopayTypeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidCoverageCopayTypeCode(code: string): code is CoverageCopayTypeCode;
/**
 * Get concept details by code
 */
export declare function getCoverageCopayTypeConcept(code: string): CoverageCopayTypeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const CoverageCopayTypeCodes: ("televisit" | "copay" | "deductible" | "emergency" | "gpvisit" | "spvisit" | "inpthosp" | "urgentcare" | "copaypct" | "maxoutofpocket")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomCoverageCopayTypeCode(): CoverageCopayTypeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomCoverageCopayTypeConcept(): CoverageCopayTypeConcept;
