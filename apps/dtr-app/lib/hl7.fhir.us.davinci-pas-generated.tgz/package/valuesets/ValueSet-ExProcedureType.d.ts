/**
 * ValueSet: ex-procedure-type
 * URL: http://hl7.org/fhir/ValueSet/ex-procedure-type
 * Size: 2 concepts
 */
export declare const ExProcedureTypeConcepts: readonly [{
    readonly code: "primary";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-procedure-type";
}, {
    readonly code: "secondary";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-procedure-type";
}];
/** Union type of all valid codes in this ValueSet */
export type ExProcedureTypeCode = "primary" | "secondary";
/** Type representing a concept from this ValueSet */
export type ExProcedureTypeConcept = typeof ExProcedureTypeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidExProcedureTypeCode(code: string): code is ExProcedureTypeCode;
/**
 * Get concept details by code
 */
export declare function getExProcedureTypeConcept(code: string): ExProcedureTypeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ExProcedureTypeCodes: ("secondary" | "primary")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomExProcedureTypeCode(): ExProcedureTypeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomExProcedureTypeConcept(): ExProcedureTypeConcept;
