/**
 * ValueSet: ExampleProcedureTypeCodes
 * URL: http://hl7.org/fhir/ValueSet/ex-procedure-type
 * Size: 2 concepts
 */
export declare const ExampleProcedureTypeCodesConcepts: readonly [{
    readonly code: "primary";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-procedure-type";
    readonly display: "Primary procedure";
}, {
    readonly code: "secondary";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-procedure-type";
    readonly display: "Secondary procedure";
}];
/** Union type of all valid codes in this ValueSet */
export type ExampleProcedureTypeCodesCode = "primary" | "secondary";
/** Type representing a concept from this ValueSet */
export type ExampleProcedureTypeCodesConcept = typeof ExampleProcedureTypeCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidExampleProcedureTypeCodesCode(code: string): code is ExampleProcedureTypeCodesCode;
/**
 * Get concept details by code
 */
export declare function getExampleProcedureTypeCodesConcept(code: string): ExampleProcedureTypeCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ExampleProcedureTypeCodesCodes: ("secondary" | "primary")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomExampleProcedureTypeCodesCode(): ExampleProcedureTypeCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomExampleProcedureTypeCodesConcept(): ExampleProcedureTypeCodesConcept;
