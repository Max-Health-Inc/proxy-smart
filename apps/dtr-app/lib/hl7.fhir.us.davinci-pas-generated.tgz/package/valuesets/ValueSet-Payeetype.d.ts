/**
 * ValueSet: payeetype
 * URL: http://hl7.org/fhir/ValueSet/payeetype
 * Size: 3 concepts
 */
export declare const PayeetypeConcepts: readonly [{
    readonly code: "subscriber";
    readonly system: "http://terminology.hl7.org/CodeSystem/payeetype";
}, {
    readonly code: "provider";
    readonly system: "http://terminology.hl7.org/CodeSystem/payeetype";
}, {
    readonly code: "other";
    readonly system: "http://terminology.hl7.org/CodeSystem/payeetype";
}];
/** Union type of all valid codes in this ValueSet */
export type PayeetypeCode = "subscriber" | "provider" | "other";
/** Type representing a concept from this ValueSet */
export type PayeetypeConcept = typeof PayeetypeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidPayeetypeCode(code: string): code is PayeetypeCode;
/**
 * Get concept details by code
 */
export declare function getPayeetypeConcept(code: string): PayeetypeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const PayeetypeCodes: ("provider" | "other" | "subscriber")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomPayeetypeCode(): PayeetypeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomPayeetypeConcept(): PayeetypeConcept;
