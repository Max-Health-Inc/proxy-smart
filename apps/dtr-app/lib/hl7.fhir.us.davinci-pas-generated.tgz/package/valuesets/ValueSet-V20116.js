/**
 * ValueSet: v2-0116
 * URL: http://terminology.hl7.org/ValueSet/v2-0116
 * Size: 6 concepts
 */
export const V20116Concepts = [
    { code: "C", system: "http://terminology.hl7.org/CodeSystem/v2-0116" },
    { code: "H", system: "http://terminology.hl7.org/CodeSystem/v2-0116" },
    { code: "O", system: "http://terminology.hl7.org/CodeSystem/v2-0116" },
    { code: "U", system: "http://terminology.hl7.org/CodeSystem/v2-0116" },
    { code: "K", system: "http://terminology.hl7.org/CodeSystem/v2-0116" },
    { code: "I", system: "http://terminology.hl7.org/CodeSystem/v2-0116" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidV20116Code(code) {
    return V20116Concepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getV20116Concept(code) {
    return V20116Concepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const V20116Codes = V20116Concepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomV20116Code() {
    return V20116Codes[Math.floor(Math.random() * V20116Codes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomV20116Concept() {
    return V20116Concepts[Math.floor(Math.random() * V20116Concepts.length)];
}
