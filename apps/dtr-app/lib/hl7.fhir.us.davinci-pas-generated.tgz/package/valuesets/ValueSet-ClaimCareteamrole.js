/**
 * ValueSet: claim-careteamrole
 * URL: http://hl7.org/fhir/ValueSet/claim-careteamrole
 * Size: 4 concepts
 */
export const ClaimCareteamroleConcepts = [
    { code: "primary", system: "http://terminology.hl7.org/CodeSystem/claimcareteamrole" },
    { code: "assist", system: "http://terminology.hl7.org/CodeSystem/claimcareteamrole" },
    { code: "supervisor", system: "http://terminology.hl7.org/CodeSystem/claimcareteamrole" },
    { code: "other", system: "http://terminology.hl7.org/CodeSystem/claimcareteamrole" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidClaimCareteamroleCode(code) {
    return ClaimCareteamroleConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getClaimCareteamroleConcept(code) {
    return ClaimCareteamroleConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ClaimCareteamroleCodes = ClaimCareteamroleConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomClaimCareteamroleCode() {
    return ClaimCareteamroleCodes[Math.floor(Math.random() * ClaimCareteamroleCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomClaimCareteamroleConcept() {
    return ClaimCareteamroleConcepts[Math.floor(Math.random() * ClaimCareteamroleConcepts.length)];
}
