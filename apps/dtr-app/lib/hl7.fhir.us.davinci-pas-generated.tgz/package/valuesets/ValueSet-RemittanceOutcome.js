/**
 * ValueSet: remittance-outcome
 * URL: http://hl7.org/fhir/ValueSet/remittance-outcome
 * Size: 4 concepts
 */
export const RemittanceOutcomeConcepts = [
    { code: "queued", system: "http://hl7.org/fhir/remittance-outcome" },
    { code: "complete", system: "http://hl7.org/fhir/remittance-outcome" },
    { code: "error", system: "http://hl7.org/fhir/remittance-outcome" },
    { code: "partial", system: "http://hl7.org/fhir/remittance-outcome" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidRemittanceOutcomeCode(code) {
    return RemittanceOutcomeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getRemittanceOutcomeConcept(code) {
    return RemittanceOutcomeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const RemittanceOutcomeCodes = RemittanceOutcomeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomRemittanceOutcomeCode() {
    return RemittanceOutcomeCodes[Math.floor(Math.random() * RemittanceOutcomeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomRemittanceOutcomeConcept() {
    return RemittanceOutcomeConcepts[Math.floor(Math.random() * RemittanceOutcomeConcepts.length)];
}
