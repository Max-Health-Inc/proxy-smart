/**
 * ValueSet: practitioner-role
 * URL: http://hl7.org/fhir/ValueSet/practitioner-role
 * Size: 6 concepts
 */
export declare const PractitionerRoleConcepts: readonly [{
    readonly code: "doctor";
    readonly system: "http://terminology.hl7.org/CodeSystem/practitioner-role";
}, {
    readonly code: "nurse";
    readonly system: "http://terminology.hl7.org/CodeSystem/practitioner-role";
}, {
    readonly code: "pharmacist";
    readonly system: "http://terminology.hl7.org/CodeSystem/practitioner-role";
}, {
    readonly code: "researcher";
    readonly system: "http://terminology.hl7.org/CodeSystem/practitioner-role";
}, {
    readonly code: "teacher";
    readonly system: "http://terminology.hl7.org/CodeSystem/practitioner-role";
}, {
    readonly code: "ict";
    readonly system: "http://terminology.hl7.org/CodeSystem/practitioner-role";
}];
/** Union type of all valid codes in this ValueSet */
export type PractitionerRoleCode = "doctor" | "nurse" | "pharmacist" | "researcher" | "teacher" | "ict";
/** Type representing a concept from this ValueSet */
export type PractitionerRoleConcept = typeof PractitionerRoleConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidPractitionerRoleCode(code: string): code is PractitionerRoleCode;
/**
 * Get concept details by code
 */
export declare function getPractitionerRoleConcept(code: string): PractitionerRoleConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const PractitionerRoleCodes: ("doctor" | "nurse" | "pharmacist" | "researcher" | "teacher" | "ict")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomPractitionerRoleCode(): PractitionerRoleCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomPractitionerRoleConcept(): PractitionerRoleConcept;
