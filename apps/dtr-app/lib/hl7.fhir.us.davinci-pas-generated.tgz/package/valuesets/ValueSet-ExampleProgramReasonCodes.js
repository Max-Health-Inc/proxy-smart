/**
 * ValueSet: ExampleProgramReasonCodes
 * URL: http://hl7.org/fhir/ValueSet/ex-program-code
 * Size: 4 concepts
 */
export const ExampleProgramReasonCodesConcepts = [
    { code: "as", system: "http://terminology.hl7.org/CodeSystem/ex-programcode", display: "Child Asthma" },
    { code: "hd", system: "http://terminology.hl7.org/CodeSystem/ex-programcode", display: "Hemodialysis" },
    { code: "auscr", system: "http://terminology.hl7.org/CodeSystem/ex-programcode", display: "Autism Screening" },
    { code: "none", system: "http://terminology.hl7.org/CodeSystem/ex-programcode", display: "None" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidExampleProgramReasonCodesCode(code) {
    return ExampleProgramReasonCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getExampleProgramReasonCodesConcept(code) {
    return ExampleProgramReasonCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ExampleProgramReasonCodesCodes = ExampleProgramReasonCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomExampleProgramReasonCodesCode() {
    return ExampleProgramReasonCodesCodes[Math.floor(Math.random() * ExampleProgramReasonCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomExampleProgramReasonCodesConcept() {
    return ExampleProgramReasonCodesConcepts[Math.floor(Math.random() * ExampleProgramReasonCodesConcepts.length)];
}
