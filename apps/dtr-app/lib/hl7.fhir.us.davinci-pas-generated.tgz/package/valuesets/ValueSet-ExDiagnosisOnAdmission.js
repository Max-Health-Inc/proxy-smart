/**
 * ValueSet: ex-diagnosis-on-admission
 * URL: http://hl7.org/fhir/ValueSet/ex-diagnosis-on-admission
 * Size: 4 concepts
 */
export const ExDiagnosisOnAdmissionConcepts = [
    { code: "y", system: "http://terminology.hl7.org/CodeSystem/ex-diagnosis-on-admission" },
    { code: "n", system: "http://terminology.hl7.org/CodeSystem/ex-diagnosis-on-admission" },
    { code: "u", system: "http://terminology.hl7.org/CodeSystem/ex-diagnosis-on-admission" },
    { code: "w", system: "http://terminology.hl7.org/CodeSystem/ex-diagnosis-on-admission" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidExDiagnosisOnAdmissionCode(code) {
    return ExDiagnosisOnAdmissionConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getExDiagnosisOnAdmissionConcept(code) {
    return ExDiagnosisOnAdmissionConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ExDiagnosisOnAdmissionCodes = ExDiagnosisOnAdmissionConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomExDiagnosisOnAdmissionCode() {
    return ExDiagnosisOnAdmissionCodes[Math.floor(Math.random() * ExDiagnosisOnAdmissionCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomExDiagnosisOnAdmissionConcept() {
    return ExDiagnosisOnAdmissionConcepts[Math.floor(Math.random() * ExDiagnosisOnAdmissionConcepts.length)];
}
