/**
 * ValueSet: MissingToothReasonCodes
 * URL: http://hl7.org/fhir/ValueSet/missing-tooth-reason
 * Size: 4 concepts
 */
export const MissingToothReasonCodesConcepts = [
    { code: "e", system: "http://terminology.hl7.org/CodeSystem/missingtoothreason", display: "E" },
    { code: "c", system: "http://terminology.hl7.org/CodeSystem/missingtoothreason", display: "C" },
    { code: "u", system: "http://terminology.hl7.org/CodeSystem/missingtoothreason", display: "U" },
    { code: "o", system: "http://terminology.hl7.org/CodeSystem/missingtoothreason", display: "O" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidMissingToothReasonCodesCode(code) {
    return MissingToothReasonCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getMissingToothReasonCodesConcept(code) {
    return MissingToothReasonCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const MissingToothReasonCodesCodes = MissingToothReasonCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomMissingToothReasonCodesCode() {
    return MissingToothReasonCodesCodes[Math.floor(Math.random() * MissingToothReasonCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomMissingToothReasonCodesConcept() {
    return MissingToothReasonCodesConcepts[Math.floor(Math.random() * MissingToothReasonCodesConcepts.length)];
}
