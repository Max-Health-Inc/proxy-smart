/**
 * ValueSet: Diet
 * URL: http://hl7.org/fhir/ValueSet/encounter-diet
 * Size: 7 concepts
 */
export const DietConcepts = [
    { code: "vegetarian", system: "http://terminology.hl7.org/CodeSystem/diet", display: "Vegetarian" },
    { code: "dairy-free", system: "http://terminology.hl7.org/CodeSystem/diet", display: "Dairy Free" },
    { code: "nut-free", system: "http://terminology.hl7.org/CodeSystem/diet", display: "Nut Free" },
    { code: "gluten-free", system: "http://terminology.hl7.org/CodeSystem/diet", display: "Gluten Free" },
    { code: "vegan", system: "http://terminology.hl7.org/CodeSystem/diet", display: "Vegan" },
    { code: "halal", system: "http://terminology.hl7.org/CodeSystem/diet", display: "Halal" },
    { code: "kosher", system: "http://terminology.hl7.org/CodeSystem/diet", display: "Kosher" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidDietCode(code) {
    return DietConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getDietConcept(code) {
    return DietConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const DietCodes = DietConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomDietCode() {
    return DietCodes[Math.floor(Math.random() * DietCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomDietConcept() {
    return DietConcepts[Math.floor(Math.random() * DietConcepts.length)];
}
