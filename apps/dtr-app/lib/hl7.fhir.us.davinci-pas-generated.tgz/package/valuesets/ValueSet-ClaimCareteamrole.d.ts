/**
 * ValueSet: claim-careteamrole
 * URL: http://hl7.org/fhir/ValueSet/claim-careteamrole
 * Size: 4 concepts
 */
export declare const ClaimCareteamroleConcepts: readonly [{
    readonly code: "primary";
    readonly system: "http://terminology.hl7.org/CodeSystem/claimcareteamrole";
}, {
    readonly code: "assist";
    readonly system: "http://terminology.hl7.org/CodeSystem/claimcareteamrole";
}, {
    readonly code: "supervisor";
    readonly system: "http://terminology.hl7.org/CodeSystem/claimcareteamrole";
}, {
    readonly code: "other";
    readonly system: "http://terminology.hl7.org/CodeSystem/claimcareteamrole";
}];
/** Union type of all valid codes in this ValueSet */
export type ClaimCareteamroleCode = "primary" | "assist" | "supervisor" | "other";
/** Type representing a concept from this ValueSet */
export type ClaimCareteamroleConcept = typeof ClaimCareteamroleConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidClaimCareteamroleCode(code: string): code is ClaimCareteamroleCode;
/**
 * Get concept details by code
 */
export declare function getClaimCareteamroleConcept(code: string): ClaimCareteamroleConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ClaimCareteamroleCodes: ("other" | "primary" | "assist" | "supervisor")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomClaimCareteamroleCode(): ClaimCareteamroleCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomClaimCareteamroleConcept(): ClaimCareteamroleConcept;
