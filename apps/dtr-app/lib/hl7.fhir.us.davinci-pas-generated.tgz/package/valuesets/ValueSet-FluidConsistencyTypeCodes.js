/**
 * ValueSet: FluidConsistencyTypeCodes
 * URL: http://hl7.org/fhir/ValueSet/consistency-type
 * Size: 4 concepts
 */
export const FluidConsistencyTypeCodesConcepts = [
    { code: "439031000124108", system: "http://snomed.info/sct", display: "honey thick liquid" },
    { code: "439021000124105", system: "http://snomed.info/sct", display: "nectar thick liquid" },
    { code: "439041000124103", system: "http://snomed.info/sct", display: "spoon thick liquid" },
    { code: "439081000124109", system: "http://snomed.info/sct", display: "thin liquid" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidFluidConsistencyTypeCodesCode(code) {
    return FluidConsistencyTypeCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getFluidConsistencyTypeCodesConcept(code) {
    return FluidConsistencyTypeCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const FluidConsistencyTypeCodesCodes = FluidConsistencyTypeCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomFluidConsistencyTypeCodesCode() {
    return FluidConsistencyTypeCodesCodes[Math.floor(Math.random() * FluidConsistencyTypeCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomFluidConsistencyTypeCodesConcept() {
    return FluidConsistencyTypeCodesConcepts[Math.floor(Math.random() * FluidConsistencyTypeCodesConcepts.length)];
}
