/**
 * ValueSet: LocationStatus
 * URL: http://hl7.org/fhir/ValueSet/location-status
 * Size: 3 concepts
 */
export declare const LocationStatusConcepts: readonly [{
    readonly code: "active";
    readonly system: "http://hl7.org/fhir/location-status";
    readonly display: "Active";
}, {
    readonly code: "suspended";
    readonly system: "http://hl7.org/fhir/location-status";
    readonly display: "Suspended";
}, {
    readonly code: "inactive";
    readonly system: "http://hl7.org/fhir/location-status";
    readonly display: "Inactive";
}];
/** Union type of all valid codes in this ValueSet */
export type LocationStatusCode = "active" | "suspended" | "inactive";
/** Type representing a concept from this ValueSet */
export type LocationStatusConcept = typeof LocationStatusConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidLocationStatusCode(code: string): code is LocationStatusCode;
/**
 * Get concept details by code
 */
export declare function getLocationStatusConcept(code: string): LocationStatusConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const LocationStatusCodes: ("active" | "suspended" | "inactive")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomLocationStatusCode(): LocationStatusCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomLocationStatusConcept(): LocationStatusConcept;
