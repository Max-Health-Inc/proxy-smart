/**
 * ValueSet: ClaimCareTeamRoleCodes
 * URL: http://hl7.org/fhir/ValueSet/claim-careteamrole
 * Size: 4 concepts
 */
export declare const ClaimCareTeamRoleCodesConcepts: readonly [{
    readonly code: "primary";
    readonly system: "http://terminology.hl7.org/CodeSystem/claimcareteamrole";
    readonly display: "Primary provider";
}, {
    readonly code: "assist";
    readonly system: "http://terminology.hl7.org/CodeSystem/claimcareteamrole";
    readonly display: "Assisting Provider";
}, {
    readonly code: "supervisor";
    readonly system: "http://terminology.hl7.org/CodeSystem/claimcareteamrole";
    readonly display: "Supervising Provider";
}, {
    readonly code: "other";
    readonly system: "http://terminology.hl7.org/CodeSystem/claimcareteamrole";
    readonly display: "Other";
}];
/** Union type of all valid codes in this ValueSet */
export type ClaimCareTeamRoleCodesCode = "primary" | "assist" | "supervisor" | "other";
/** Type representing a concept from this ValueSet */
export type ClaimCareTeamRoleCodesConcept = typeof ClaimCareTeamRoleCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidClaimCareTeamRoleCodesCode(code: string): code is ClaimCareTeamRoleCodesCode;
/**
 * Get concept details by code
 */
export declare function getClaimCareTeamRoleCodesConcept(code: string): ClaimCareTeamRoleCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ClaimCareTeamRoleCodesCodes: ("other" | "primary" | "assist" | "supervisor")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomClaimCareTeamRoleCodesCode(): ClaimCareTeamRoleCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomClaimCareTeamRoleCodesConcept(): ClaimCareTeamRoleCodesConcept;
