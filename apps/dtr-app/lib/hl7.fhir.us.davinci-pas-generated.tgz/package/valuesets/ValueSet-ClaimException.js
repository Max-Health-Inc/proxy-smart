/**
 * ValueSet: claim-exception
 * URL: http://hl7.org/fhir/ValueSet/claim-exception
 * Size: 2 concepts
 */
export const ClaimExceptionConcepts = [
    { code: "student", system: "http://terminology.hl7.org/CodeSystem/claim-exception" },
    { code: "disabled", system: "http://terminology.hl7.org/CodeSystem/claim-exception" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidClaimExceptionCode(code) {
    return ClaimExceptionConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getClaimExceptionConcept(code) {
    return ClaimExceptionConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ClaimExceptionCodes = ClaimExceptionConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomClaimExceptionCode() {
    return ClaimExceptionCodes[Math.floor(Math.random() * ClaimExceptionCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomClaimExceptionConcept() {
    return ClaimExceptionConcepts[Math.floor(Math.random() * ClaimExceptionConcepts.length)];
}
