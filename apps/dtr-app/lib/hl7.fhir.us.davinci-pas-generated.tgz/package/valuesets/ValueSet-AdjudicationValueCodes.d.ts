/**
 * ValueSet: AdjudicationValueCodes
 * URL: http://hl7.org/fhir/ValueSet/adjudication
 * Size: 8 concepts
 */
export declare const AdjudicationValueCodesConcepts: readonly [{
    readonly code: "submitted";
    readonly system: "http://terminology.hl7.org/CodeSystem/adjudication";
    readonly display: "Submitted Amount";
}, {
    readonly code: "copay";
    readonly system: "http://terminology.hl7.org/CodeSystem/adjudication";
    readonly display: "CoPay";
}, {
    readonly code: "eligible";
    readonly system: "http://terminology.hl7.org/CodeSystem/adjudication";
    readonly display: "Eligible Amount";
}, {
    readonly code: "deductible";
    readonly system: "http://terminology.hl7.org/CodeSystem/adjudication";
    readonly display: "Deductible";
}, {
    readonly code: "unallocdeduct";
    readonly system: "http://terminology.hl7.org/CodeSystem/adjudication";
    readonly display: "Unallocated Deductible";
}, {
    readonly code: "eligpercent";
    readonly system: "http://terminology.hl7.org/CodeSystem/adjudication";
    readonly display: "Eligible %";
}, {
    readonly code: "tax";
    readonly system: "http://terminology.hl7.org/CodeSystem/adjudication";
    readonly display: "Tax";
}, {
    readonly code: "benefit";
    readonly system: "http://terminology.hl7.org/CodeSystem/adjudication";
    readonly display: "Benefit Amount";
}];
/** Union type of all valid codes in this ValueSet */
export type AdjudicationValueCodesCode = "submitted" | "copay" | "eligible" | "deductible" | "unallocdeduct" | "eligpercent" | "tax" | "benefit";
/** Type representing a concept from this ValueSet */
export type AdjudicationValueCodesConcept = typeof AdjudicationValueCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidAdjudicationValueCodesCode(code: string): code is AdjudicationValueCodesCode;
/**
 * Get concept details by code
 */
export declare function getAdjudicationValueCodesConcept(code: string): AdjudicationValueCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const AdjudicationValueCodesCodes: ("submitted" | "benefit" | "copay" | "eligible" | "deductible" | "unallocdeduct" | "eligpercent" | "tax")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomAdjudicationValueCodesCode(): AdjudicationValueCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomAdjudicationValueCodesConcept(): AdjudicationValueCodesConcept;
