/**
 * ValueSet: ModifierTypeCodes
 * URL: http://hl7.org/fhir/ValueSet/claim-modifiers
 * Size: 6 concepts
 */
export const ModifierTypeCodesConcepts = [
    { code: "a", system: "http://terminology.hl7.org/CodeSystem/modifiers", display: "Repair of prior service or installation" },
    { code: "b", system: "http://terminology.hl7.org/CodeSystem/modifiers", display: "Temporary service or installation" },
    { code: "c", system: "http://terminology.hl7.org/CodeSystem/modifiers", display: "TMJ treatment" },
    { code: "e", system: "http://terminology.hl7.org/CodeSystem/modifiers", display: "Implant or associated with an implant" },
    { code: "rooh", system: "http://terminology.hl7.org/CodeSystem/modifiers", display: "Rush or Outside of office hours" },
    { code: "x", system: "http://terminology.hl7.org/CodeSystem/modifiers", display: "None" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidModifierTypeCodesCode(code) {
    return ModifierTypeCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getModifierTypeCodesConcept(code) {
    return ModifierTypeCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ModifierTypeCodesCodes = ModifierTypeCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomModifierTypeCodesCode() {
    return ModifierTypeCodesCodes[Math.floor(Math.random() * ModifierTypeCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomModifierTypeCodesConcept() {
    return ModifierTypeCodesConcepts[Math.floor(Math.random() * ModifierTypeCodesConcepts.length)];
}
