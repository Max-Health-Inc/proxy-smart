/**
 * ValueSet: coverage-type
 * URL: http://hl7.org/fhir/ValueSet/coverage-type
 * Size: 1 concepts
 */
export const CoverageTypeConcepts = [
    { code: "pay", system: "http://terminology.hl7.org/CodeSystem/coverage-selfpay" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidCoverageTypeCode(code) {
    return CoverageTypeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getCoverageTypeConcept(code) {
    return CoverageTypeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const CoverageTypeCodes = CoverageTypeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomCoverageTypeCode() {
    return CoverageTypeCodes[Math.floor(Math.random() * CoverageTypeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomCoverageTypeConcept() {
    return CoverageTypeConcepts[Math.floor(Math.random() * CoverageTypeConcepts.length)];
}
