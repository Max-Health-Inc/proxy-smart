/**
 * ValueSet: ParticipantRoles
 * URL: http://hl7.org/fhir/ValueSet/participant-role
 * Size: 100 concepts
 */
export declare const ParticipantRolesConcepts: readonly [{
    readonly code: "125676002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Person";
}, {
    readonly code: "270002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Female first cousin";
}, {
    readonly code: "375005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Sibling";
}, {
    readonly code: "444000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Legal sibling";
}, {
    readonly code: "609005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Adoptive father";
}, {
    readonly code: "1354005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Orphan female";
}, {
    readonly code: "2272004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Half-sister";
}, {
    readonly code: "2368000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Great-great grand-mother";
}, {
    readonly code: "2481008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Working mother";
}, {
    readonly code: "2959006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Female cousin";
}, {
    readonly code: "3425009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Oldest daughter";
}, {
    readonly code: "3851003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Surrogate daughter";
}, {
    readonly code: "4577005";
    readonly system: "http://snomed.info/sct";
    readonly display: "First cousin";
}, {
    readonly code: "6676009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Youngest daughter";
}, {
    readonly code: "8458002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Foster father";
}, {
    readonly code: "8674003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Step son";
}, {
    readonly code: "9306000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Legal parent";
}, {
    readonly code: "9947008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Natural father";
}, {
    readonly code: "10896006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Identical twin sibling";
}, {
    readonly code: "10960006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Working father";
}, {
    readonly code: "11286003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Twin sibling";
}, {
    readonly code: "11393001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Great-great grand child";
}, {
    readonly code: "11434005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Male second cousin";
}, {
    readonly code: "11773006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Legal brother";
}, {
    readonly code: "11993008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Male first cousin";
}, {
    readonly code: "12241003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Foster son";
}, {
    readonly code: "12629003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Single mother";
}, {
    readonly code: "13038009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Older brother";
}, {
    readonly code: "13157002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Older sibling";
}, {
    readonly code: "13443008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Second cousin";
}, {
    readonly code: "13646006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Natural parent";
}, {
    readonly code: "14469008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Legal child";
}, {
    readonly code: "15130002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Surrogate parent";
}, {
    readonly code: "17219007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Male fiance";
}, {
    readonly code: "17925003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Adoptive brother";
}, {
    readonly code: "17945006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Natural grand-mother";
}, {
    readonly code: "18205005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Wesleyan Methodist Church";
}, {
    readonly code: "18906004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Foster sibling";
}, {
    readonly code: "19343003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Twin sister";
}, {
    readonly code: "19686009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Younger sister";
}, {
    readonly code: "21093007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Half-sibling";
}, {
    readonly code: "21464003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Adoptive mother";
}, {
    readonly code: "21506002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Female second cousin";
}, {
    readonly code: "22387007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Surrogate child";
}, {
    readonly code: "22573006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Step daughter";
}, {
    readonly code: "22609000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Adoptive grand-parent";
}, {
    readonly code: "22963000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Legal sister";
}, {
    readonly code: "25211005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Aunt";
}, {
    readonly code: "27508009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Surrogate mother";
}, {
    readonly code: "27733009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Sister";
}, {
    readonly code: "28010004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Shiite muslim";
}, {
    readonly code: "29539002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Younger sibling";
}, {
    readonly code: "29644004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Fraternal twin sister";
}, {
    readonly code: "29787005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Foster brother";
}, {
    readonly code: "30578000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Step-father";
}, {
    readonly code: "31656007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Adoptive grand-mother";
}, {
    readonly code: "31831004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Foster daughter";
}, {
    readonly code: "33969000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Great grand-parent";
}, {
    readonly code: "34581001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Niece";
}, {
    readonly code: "34871008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Grand-father";
}, {
    readonly code: "34972000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Only daughter";
}, {
    readonly code: "38048003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Uncle";
}, {
    readonly code: "38248007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Oldest son";
}, {
    readonly code: "38265003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Foster mother";
}, {
    readonly code: "38312007";
    readonly system: "http://snomed.info/sct";
    readonly display: "Grand-parent";
}, {
    readonly code: "39062003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Foster child";
}, {
    readonly code: "40683002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Parent";
}, {
    readonly code: "41057000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Surrogate son";
}, {
    readonly code: "41795004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Legal son";
}, {
    readonly code: "41953004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Adoptive parent";
}, {
    readonly code: "44181008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Grand daughter";
}, {
    readonly code: "45929001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Half-brother";
}, {
    readonly code: "46363003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Step sister";
}, {
    readonly code: "47801002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Male cousin";
}, {
    readonly code: "48385004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Acquaintance";
}, {
    readonly code: "50058005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Identical twin sister";
}, {
    readonly code: "50261002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Great grand-father";
}, {
    readonly code: "51616000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Sephardic Jew";
}, {
    readonly code: "53201003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Older sister";
}, {
    readonly code: "54056000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Trustee";
}, {
    readonly code: "55538000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Cousin";
}, {
    readonly code: "58293006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Foster sister";
}, {
    readonly code: "58626002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Legal guardian";
}, {
    readonly code: "60614009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Natural brother";
}, {
    readonly code: "62090008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Legal mother";
}, {
    readonly code: "62296006";
    readonly system: "http://snomed.info/sct";
    readonly display: "Natural grand-father";
}, {
    readonly code: "64988008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Sunnite muslim";
}, {
    readonly code: "65412001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Step-mother";
}, {
    readonly code: "65616008";
    readonly system: "http://snomed.info/sct";
    readonly display: "Son";
}, {
    readonly code: "65656005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Natural mother";
}, {
    readonly code: "66089001";
    readonly system: "http://snomed.info/sct";
    readonly display: "Daughter";
}, {
    readonly code: "66839005";
    readonly system: "http://snomed.info/sct";
    readonly display: "Father";
}, {
    readonly code: "67147004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Legal father";
}, {
    readonly code: "67822003";
    readonly system: "http://snomed.info/sct";
    readonly display: "Child";
}, {
    readonly code: "68021009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Great-great grand-parent";
}, {
    readonly code: "70578009";
    readonly system: "http://snomed.info/sct";
    readonly display: "Grand son";
}, {
    readonly code: "70862002";
    readonly system: "http://snomed.info/sct";
    readonly display: "Contact person";
}, {
    readonly code: "70924004";
    readonly system: "http://snomed.info/sct";
    readonly display: "Brother";
}, {
    readonly code: "72012000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Great grand child";
}, {
    readonly code: "72705000";
    readonly system: "http://snomed.info/sct";
    readonly display: "Mother";
}];
/** String type (ValueSet too large for union type) */
export type ParticipantRolesCode = string;
/** Type representing a concept from this ValueSet */
export type ParticipantRolesConcept = typeof ParticipantRolesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidParticipantRolesCode(code: string): code is ParticipantRolesCode;
/**
 * Get concept details by code
 */
export declare function getParticipantRolesConcept(code: string): ParticipantRolesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ParticipantRolesCodes: ("125676002" | "270002" | "375005" | "444000" | "609005" | "1354005" | "2272004" | "2368000" | "2481008" | "2959006" | "3425009" | "3851003" | "4577005" | "6676009" | "8458002" | "8674003" | "9306000" | "9947008" | "10896006" | "10960006" | "11286003" | "11393001" | "11434005" | "11773006" | "11993008" | "12241003" | "12629003" | "13038009" | "13157002" | "13443008" | "13646006" | "14469008" | "15130002" | "17219007" | "17925003" | "17945006" | "18205005" | "18906004" | "19343003" | "19686009" | "21093007" | "21464003" | "21506002" | "22387007" | "22573006" | "22609000" | "22963000" | "25211005" | "27508009" | "27733009" | "28010004" | "29539002" | "29644004" | "29787005" | "30578000" | "31656007" | "31831004" | "33969000" | "34581001" | "34871008" | "34972000" | "38048003" | "38248007" | "38265003" | "38312007" | "39062003" | "40683002" | "41057000" | "41795004" | "41953004" | "44181008" | "45929001" | "46363003" | "47801002" | "48385004" | "50058005" | "50261002" | "51616000" | "53201003" | "54056000" | "55538000" | "58293006" | "58626002" | "60614009" | "62090008" | "62296006" | "64988008" | "65412001" | "65616008" | "65656005" | "66089001" | "66839005" | "67147004" | "67822003" | "68021009" | "70578009" | "70862002" | "70924004" | "72012000" | "72705000")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomParticipantRolesCode(): ParticipantRolesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomParticipantRolesConcept(): ParticipantRolesConcept;
