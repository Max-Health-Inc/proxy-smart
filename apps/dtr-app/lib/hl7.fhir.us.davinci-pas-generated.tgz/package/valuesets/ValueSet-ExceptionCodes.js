/**
 * ValueSet: ExceptionCodes
 * URL: http://hl7.org/fhir/ValueSet/claim-exception
 * Size: 2 concepts
 */
export const ExceptionCodesConcepts = [
    { code: "student", system: "http://terminology.hl7.org/CodeSystem/claim-exception", display: "Student (Fulltime)" },
    { code: "disabled", system: "http://terminology.hl7.org/CodeSystem/claim-exception", display: "Disabled" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidExceptionCodesCode(code) {
    return ExceptionCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getExceptionCodesConcept(code) {
    return ExceptionCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ExceptionCodesCodes = ExceptionCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomExceptionCodesCode() {
    return ExceptionCodesCodes[Math.floor(Math.random() * ExceptionCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomExceptionCodesConcept() {
    return ExceptionCodesConcepts[Math.floor(Math.random() * ExceptionCodesConcepts.length)];
}
