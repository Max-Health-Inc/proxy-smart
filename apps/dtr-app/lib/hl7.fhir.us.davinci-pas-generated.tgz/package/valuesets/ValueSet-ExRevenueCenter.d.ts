/**
 * ValueSet: ex-revenue-center
 * URL: http://hl7.org/fhir/ValueSet/ex-revenue-center
 * Size: 9 concepts
 */
export declare const ExRevenueCenterConcepts: readonly [{
    readonly code: "0370";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center";
}, {
    readonly code: "0420";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center";
}, {
    readonly code: "0421";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center";
}, {
    readonly code: "0440";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center";
}, {
    readonly code: "0441";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center";
}, {
    readonly code: "0450";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center";
}, {
    readonly code: "0451";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center";
}, {
    readonly code: "0452";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center";
}, {
    readonly code: "0010";
    readonly system: "http://terminology.hl7.org/CodeSystem/ex-revenue-center";
}];
/** Union type of all valid codes in this ValueSet */
export type ExRevenueCenterCode = "0370" | "0420" | "0421" | "0440" | "0441" | "0450" | "0451" | "0452" | "0010";
/** Type representing a concept from this ValueSet */
export type ExRevenueCenterConcept = typeof ExRevenueCenterConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidExRevenueCenterCode(code: string): code is ExRevenueCenterCode;
/**
 * Get concept details by code
 */
export declare function getExRevenueCenterConcept(code: string): ExRevenueCenterConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ExRevenueCenterCodes: ("0451" | "0370" | "0420" | "0421" | "0440" | "0441" | "0450" | "0452" | "0010")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomExRevenueCenterCode(): ExRevenueCenterCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomExRevenueCenterConcept(): ExRevenueCenterConcept;
