/**
 * ValueSet: ExampleDiagnosisRelatedGroupCodes
 * URL: http://hl7.org/fhir/ValueSet/ex-diagnosisrelatedgroup
 * Size: 4 concepts
 */
export const ExampleDiagnosisRelatedGroupCodesConcepts = [
    { code: "100", system: "http://terminology.hl7.org/CodeSystem/ex-diagnosisrelatedgroup", display: "Normal Vaginal Delivery" },
    { code: "101", system: "http://terminology.hl7.org/CodeSystem/ex-diagnosisrelatedgroup", display: "Appendectomy - uncomplicated" },
    { code: "300", system: "http://terminology.hl7.org/CodeSystem/ex-diagnosisrelatedgroup", display: "Tooth abscess" },
    { code: "400", system: "http://terminology.hl7.org/CodeSystem/ex-diagnosisrelatedgroup", display: "Head trauma - concussion" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidExampleDiagnosisRelatedGroupCodesCode(code) {
    return ExampleDiagnosisRelatedGroupCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getExampleDiagnosisRelatedGroupCodesConcept(code) {
    return ExampleDiagnosisRelatedGroupCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ExampleDiagnosisRelatedGroupCodesCodes = ExampleDiagnosisRelatedGroupCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomExampleDiagnosisRelatedGroupCodesCode() {
    return ExampleDiagnosisRelatedGroupCodesCodes[Math.floor(Math.random() * ExampleDiagnosisRelatedGroupCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomExampleDiagnosisRelatedGroupCodesConcept() {
    return ExampleDiagnosisRelatedGroupCodesConcepts[Math.floor(Math.random() * ExampleDiagnosisRelatedGroupCodesConcepts.length)];
}
