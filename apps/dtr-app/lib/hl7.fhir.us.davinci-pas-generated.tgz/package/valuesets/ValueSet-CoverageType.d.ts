/**
 * ValueSet: coverage-type
 * URL: http://hl7.org/fhir/ValueSet/coverage-type
 * Size: 1 concepts
 */
export declare const CoverageTypeConcepts: readonly [{
    readonly code: "pay";
    readonly system: "http://terminology.hl7.org/CodeSystem/coverage-selfpay";
}];
/** Union type of all valid codes in this ValueSet */
export type CoverageTypeCode = "pay";
/** Type representing a concept from this ValueSet */
export type CoverageTypeConcept = typeof CoverageTypeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidCoverageTypeCode(code: string): code is CoverageTypeCode;
/**
 * Get concept details by code
 */
export declare function getCoverageTypeConcept(code: string): CoverageTypeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const CoverageTypeCodes: "pay"[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomCoverageTypeCode(): CoverageTypeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomCoverageTypeConcept(): CoverageTypeConcept;
