/**
 * ValueSet: us-core-usps-state
 * URL: http://hl7.org/fhir/us/core/ValueSet/us-core-usps-state
 * Size: 59 concepts
 */
export const UsCoreUspsStateConcepts = [
    { code: "AK", system: "https://www.usps.com/" },
    { code: "AL", system: "https://www.usps.com/" },
    { code: "AR", system: "https://www.usps.com/" },
    { code: "AS", system: "https://www.usps.com/" },
    { code: "AZ", system: "https://www.usps.com/" },
    { code: "CA", system: "https://www.usps.com/" },
    { code: "CO", system: "https://www.usps.com/" },
    { code: "CT", system: "https://www.usps.com/" },
    { code: "DC", system: "https://www.usps.com/" },
    { code: "DE", system: "https://www.usps.com/" },
    { code: "FL", system: "https://www.usps.com/" },
    { code: "FM", system: "https://www.usps.com/" },
    { code: "GA", system: "https://www.usps.com/" },
    { code: "GU", system: "https://www.usps.com/" },
    { code: "HI", system: "https://www.usps.com/" },
    { code: "IA", system: "https://www.usps.com/" },
    { code: "ID", system: "https://www.usps.com/" },
    { code: "IL", system: "https://www.usps.com/" },
    { code: "IN", system: "https://www.usps.com/" },
    { code: "KS", system: "https://www.usps.com/" },
    { code: "KY", system: "https://www.usps.com/" },
    { code: "LA", system: "https://www.usps.com/" },
    { code: "MA", system: "https://www.usps.com/" },
    { code: "MD", system: "https://www.usps.com/" },
    { code: "ME", system: "https://www.usps.com/" },
    { code: "MH", system: "https://www.usps.com/" },
    { code: "MI", system: "https://www.usps.com/" },
    { code: "MN", system: "https://www.usps.com/" },
    { code: "MO", system: "https://www.usps.com/" },
    { code: "MP", system: "https://www.usps.com/" },
    { code: "MS", system: "https://www.usps.com/" },
    { code: "MT", system: "https://www.usps.com/" },
    { code: "NC", system: "https://www.usps.com/" },
    { code: "ND", system: "https://www.usps.com/" },
    { code: "NE", system: "https://www.usps.com/" },
    { code: "NH", system: "https://www.usps.com/" },
    { code: "NJ", system: "https://www.usps.com/" },
    { code: "NM", system: "https://www.usps.com/" },
    { code: "NV", system: "https://www.usps.com/" },
    { code: "NY", system: "https://www.usps.com/" },
    { code: "OH", system: "https://www.usps.com/" },
    { code: "OK", system: "https://www.usps.com/" },
    { code: "OR", system: "https://www.usps.com/" },
    { code: "PA", system: "https://www.usps.com/" },
    { code: "PR", system: "https://www.usps.com/" },
    { code: "PW", system: "https://www.usps.com/" },
    { code: "RI", system: "https://www.usps.com/" },
    { code: "SC", system: "https://www.usps.com/" },
    { code: "SD", system: "https://www.usps.com/" },
    { code: "TN", system: "https://www.usps.com/" },
    { code: "TX", system: "https://www.usps.com/" },
    { code: "UT", system: "https://www.usps.com/" },
    { code: "VA", system: "https://www.usps.com/" },
    { code: "VI", system: "https://www.usps.com/" },
    { code: "VT", system: "https://www.usps.com/" },
    { code: "WA", system: "https://www.usps.com/" },
    { code: "WI", system: "https://www.usps.com/" },
    { code: "WV", system: "https://www.usps.com/" },
    { code: "WY", system: "https://www.usps.com/" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidUsCoreUspsStateCode(code) {
    return UsCoreUspsStateConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getUsCoreUspsStateConcept(code) {
    return UsCoreUspsStateConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const UsCoreUspsStateCodes = UsCoreUspsStateConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomUsCoreUspsStateCode() {
    return UsCoreUspsStateCodes[Math.floor(Math.random() * UsCoreUspsStateCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomUsCoreUspsStateConcept() {
    return UsCoreUspsStateConcepts[Math.floor(Math.random() * UsCoreUspsStateConcepts.length)];
}
