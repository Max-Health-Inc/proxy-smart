/**
 * ValueSet: ClaimCareTeamRoleCodes
 * URL: http://hl7.org/fhir/ValueSet/claim-careteamrole
 * Size: 4 concepts
 */
export const ClaimCareTeamRoleCodesConcepts = [
    { code: "primary", system: "http://terminology.hl7.org/CodeSystem/claimcareteamrole", display: "Primary provider" },
    { code: "assist", system: "http://terminology.hl7.org/CodeSystem/claimcareteamrole", display: "Assisting Provider" },
    { code: "supervisor", system: "http://terminology.hl7.org/CodeSystem/claimcareteamrole", display: "Supervising Provider" },
    { code: "other", system: "http://terminology.hl7.org/CodeSystem/claimcareteamrole", display: "Other" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidClaimCareTeamRoleCodesCode(code) {
    return ClaimCareTeamRoleCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getClaimCareTeamRoleCodesConcept(code) {
    return ClaimCareTeamRoleCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ClaimCareTeamRoleCodesCodes = ClaimCareTeamRoleCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomClaimCareTeamRoleCodesCode() {
    return ClaimCareTeamRoleCodesCodes[Math.floor(Math.random() * ClaimCareTeamRoleCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomClaimCareTeamRoleCodesConcept() {
    return ClaimCareTeamRoleCodesConcepts[Math.floor(Math.random() * ClaimCareTeamRoleCodesConcepts.length)];
}
