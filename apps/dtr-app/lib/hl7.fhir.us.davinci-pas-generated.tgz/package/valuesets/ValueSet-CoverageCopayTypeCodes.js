/**
 * ValueSet: CoverageCopayTypeCodes
 * URL: http://hl7.org/fhir/ValueSet/coverage-copay-type
 * Size: 10 concepts
 */
export const CoverageCopayTypeCodesConcepts = [
    { code: "gpvisit", system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type", display: "GP Office Visit" },
    { code: "spvisit", system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type", display: "Specialist Office Visit" },
    { code: "emergency", system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type", display: "Emergency" },
    { code: "inpthosp", system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type", display: "Inpatient Hospital" },
    { code: "televisit", system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type", display: "Tele-visit" },
    { code: "urgentcare", system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type", display: "Urgent Care" },
    { code: "copaypct", system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type", display: "Copay Percentage" },
    { code: "copay", system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type", display: "Copay Amount" },
    { code: "deductible", system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type", display: "Deductible" },
    { code: "maxoutofpocket", system: "http://terminology.hl7.org/CodeSystem/coverage-copay-type", display: "Maximum out of pocket" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidCoverageCopayTypeCodesCode(code) {
    return CoverageCopayTypeCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getCoverageCopayTypeCodesConcept(code) {
    return CoverageCopayTypeCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const CoverageCopayTypeCodesCodes = CoverageCopayTypeCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomCoverageCopayTypeCodesCode() {
    return CoverageCopayTypeCodesCodes[Math.floor(Math.random() * CoverageCopayTypeCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomCoverageCopayTypeCodesConcept() {
    return CoverageCopayTypeCodesConcepts[Math.floor(Math.random() * CoverageCopayTypeCodesConcepts.length)];
}
