/**
 * ValueSet: enteral-route
 * URL: http://hl7.org/fhir/ValueSet/enteral-route
 * Size: 9 concepts
 */
export const EnteralRouteConcepts = [
    { code: "PO", system: "http://terminology.hl7.org/CodeSystem/v3-RouteOfAdministration" },
    { code: "EFT", system: "http://terminology.hl7.org/CodeSystem/v3-RouteOfAdministration" },
    { code: "ENTINSTL", system: "http://terminology.hl7.org/CodeSystem/v3-RouteOfAdministration" },
    { code: "GT", system: "http://terminology.hl7.org/CodeSystem/v3-RouteOfAdministration" },
    { code: "NGT", system: "http://terminology.hl7.org/CodeSystem/v3-RouteOfAdministration" },
    { code: "OGT", system: "http://terminology.hl7.org/CodeSystem/v3-RouteOfAdministration" },
    { code: "GJT", system: "http://terminology.hl7.org/CodeSystem/v3-RouteOfAdministration" },
    { code: "JJTINSTL", system: "http://terminology.hl7.org/CodeSystem/v3-RouteOfAdministration" },
    { code: "OJJ", system: "http://terminology.hl7.org/CodeSystem/v3-RouteOfAdministration" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidEnteralRouteCode(code) {
    return EnteralRouteConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getEnteralRouteConcept(code) {
    return EnteralRouteConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const EnteralRouteCodes = EnteralRouteConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomEnteralRouteCode() {
    return EnteralRouteCodes[Math.floor(Math.random() * EnteralRouteCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomEnteralRouteConcept() {
    return EnteralRouteConcepts[Math.floor(Math.random() * EnteralRouteConcepts.length)];
}
