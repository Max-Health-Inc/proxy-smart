/**
 * ValueSet: icd-10-procedures
 * URL: http://hl7.org/fhir/ValueSet/icd-10-procedures
 * Size: 3 concepts
 */
export declare const Icd10ProceduresConcepts: readonly [{
    readonly code: "123001";
    readonly system: "http://hl7.org/fhir/sid/ex-icd-10-procedures";
}, {
    readonly code: "123002";
    readonly system: "http://hl7.org/fhir/sid/ex-icd-10-procedures";
}, {
    readonly code: "123003";
    readonly system: "http://hl7.org/fhir/sid/ex-icd-10-procedures";
}];
/** Union type of all valid codes in this ValueSet */
export type Icd10ProceduresCode = "123001" | "123002" | "123003";
/** Type representing a concept from this ValueSet */
export type Icd10ProceduresConcept = typeof Icd10ProceduresConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidIcd10ProceduresCode(code: string): code is Icd10ProceduresCode;
/**
 * Get concept details by code
 */
export declare function getIcd10ProceduresConcept(code: string): Icd10ProceduresConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const Icd10ProceduresCodes: ("123001" | "123002" | "123003")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomIcd10ProceduresCode(): Icd10ProceduresCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomIcd10ProceduresConcept(): Icd10ProceduresConcept;
