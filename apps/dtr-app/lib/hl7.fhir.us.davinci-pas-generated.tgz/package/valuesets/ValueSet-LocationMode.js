/**
 * ValueSet: LocationMode
 * URL: http://hl7.org/fhir/ValueSet/location-mode
 * Size: 2 concepts
 */
export const LocationModeConcepts = [
    { code: "instance", system: "http://hl7.org/fhir/location-mode", display: "Instance" },
    { code: "kind", system: "http://hl7.org/fhir/location-mode", display: "Kind" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidLocationModeCode(code) {
    return LocationModeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getLocationModeConcept(code) {
    return LocationModeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const LocationModeCodes = LocationModeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomLocationModeCode() {
    return LocationModeCodes[Math.floor(Math.random() * LocationModeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomLocationModeConcept() {
    return LocationModeConcepts[Math.floor(Math.random() * LocationModeConcepts.length)];
}
