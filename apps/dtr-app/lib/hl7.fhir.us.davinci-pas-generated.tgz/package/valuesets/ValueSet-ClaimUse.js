/**
 * ValueSet: claim-use
 * URL: http://hl7.org/fhir/ValueSet/claim-use
 * Size: 3 concepts
 */
export const ClaimUseConcepts = [
    { code: "claim", system: "http://hl7.org/fhir/claim-use" },
    { code: "preauthorization", system: "http://hl7.org/fhir/claim-use" },
    { code: "predetermination", system: "http://hl7.org/fhir/claim-use" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidClaimUseCode(code) {
    return ClaimUseConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getClaimUseConcept(code) {
    return ClaimUseConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ClaimUseCodes = ClaimUseConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomClaimUseCode() {
    return ClaimUseCodes[Math.floor(Math.random() * ClaimUseCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomClaimUseConcept() {
    return ClaimUseConcepts[Math.floor(Math.random() * ClaimUseConcepts.length)];
}
