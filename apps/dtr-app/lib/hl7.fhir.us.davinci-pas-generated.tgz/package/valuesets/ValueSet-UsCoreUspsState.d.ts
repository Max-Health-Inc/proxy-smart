/**
 * ValueSet: us-core-usps-state
 * URL: http://hl7.org/fhir/us/core/ValueSet/us-core-usps-state
 * Size: 59 concepts
 */
export declare const UsCoreUspsStateConcepts: readonly [{
    readonly code: "AK";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "AL";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "AR";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "AS";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "AZ";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "CA";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "CO";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "CT";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "DC";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "DE";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "FL";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "FM";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "GA";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "GU";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "HI";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "IA";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "ID";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "IL";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "IN";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "KS";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "KY";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "LA";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "MA";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "MD";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "ME";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "MH";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "MI";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "MN";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "MO";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "MP";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "MS";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "MT";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "NC";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "ND";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "NE";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "NH";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "NJ";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "NM";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "NV";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "NY";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "OH";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "OK";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "OR";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "PA";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "PR";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "PW";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "RI";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "SC";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "SD";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "TN";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "TX";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "UT";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "VA";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "VI";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "VT";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "WA";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "WI";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "WV";
    readonly system: "https://www.usps.com/";
}, {
    readonly code: "WY";
    readonly system: "https://www.usps.com/";
}];
/** String type (ValueSet too large for union type) */
export type UsCoreUspsStateCode = string;
/** Type representing a concept from this ValueSet */
export type UsCoreUspsStateConcept = typeof UsCoreUspsStateConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidUsCoreUspsStateCode(code: string): code is UsCoreUspsStateCode;
/**
 * Get concept details by code
 */
export declare function getUsCoreUspsStateConcept(code: string): UsCoreUspsStateConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const UsCoreUspsStateCodes: ("AK" | "AL" | "AR" | "AS" | "AZ" | "CA" | "CO" | "CT" | "DC" | "DE" | "FL" | "FM" | "GA" | "GU" | "HI" | "IA" | "ID" | "IL" | "IN" | "KS" | "KY" | "LA" | "MA" | "MD" | "ME" | "MH" | "MI" | "MN" | "MO" | "MP" | "MS" | "MT" | "NC" | "ND" | "NE" | "NH" | "NJ" | "NM" | "NV" | "NY" | "OH" | "OK" | "OR" | "PA" | "PR" | "PW" | "RI" | "SC" | "SD" | "TN" | "TX" | "UT" | "VA" | "VI" | "VT" | "WA" | "WI" | "WV" | "WY")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomUsCoreUspsStateCode(): UsCoreUspsStateCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomUsCoreUspsStateConcept(): UsCoreUspsStateConcept;
