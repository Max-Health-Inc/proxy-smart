/**
 * ValueSet: location-physical-type
 * URL: http://hl7.org/fhir/ValueSet/location-physical-type
 * Size: 14 concepts
 */
export const LocationPhysicalTypeConcepts = [
    { code: "si", system: "http://terminology.hl7.org/CodeSystem/location-physical-type" },
    { code: "bu", system: "http://terminology.hl7.org/CodeSystem/location-physical-type" },
    { code: "wi", system: "http://terminology.hl7.org/CodeSystem/location-physical-type" },
    { code: "wa", system: "http://terminology.hl7.org/CodeSystem/location-physical-type" },
    { code: "lvl", system: "http://terminology.hl7.org/CodeSystem/location-physical-type" },
    { code: "co", system: "http://terminology.hl7.org/CodeSystem/location-physical-type" },
    { code: "ro", system: "http://terminology.hl7.org/CodeSystem/location-physical-type" },
    { code: "bd", system: "http://terminology.hl7.org/CodeSystem/location-physical-type" },
    { code: "ve", system: "http://terminology.hl7.org/CodeSystem/location-physical-type" },
    { code: "ho", system: "http://terminology.hl7.org/CodeSystem/location-physical-type" },
    { code: "ca", system: "http://terminology.hl7.org/CodeSystem/location-physical-type" },
    { code: "rd", system: "http://terminology.hl7.org/CodeSystem/location-physical-type" },
    { code: "area", system: "http://terminology.hl7.org/CodeSystem/location-physical-type" },
    { code: "jdn", system: "http://terminology.hl7.org/CodeSystem/location-physical-type" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidLocationPhysicalTypeCode(code) {
    return LocationPhysicalTypeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getLocationPhysicalTypeConcept(code) {
    return LocationPhysicalTypeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const LocationPhysicalTypeCodes = LocationPhysicalTypeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomLocationPhysicalTypeCode() {
    return LocationPhysicalTypeCodes[Math.floor(Math.random() * LocationPhysicalTypeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomLocationPhysicalTypeConcept() {
    return LocationPhysicalTypeConcepts[Math.floor(Math.random() * LocationPhysicalTypeConcepts.length)];
}
