/**
 * ValueSet: ExamplePaymentTypeCodes
 * URL: http://hl7.org/fhir/ValueSet/ex-paymenttype
 * Size: 2 concepts
 */
export const ExamplePaymentTypeCodesConcepts = [
    { code: "complete", system: "http://terminology.hl7.org/CodeSystem/ex-paymenttype", display: "Complete" },
    { code: "partial", system: "http://terminology.hl7.org/CodeSystem/ex-paymenttype", display: "Partial" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidExamplePaymentTypeCodesCode(code) {
    return ExamplePaymentTypeCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getExamplePaymentTypeCodesConcept(code) {
    return ExamplePaymentTypeCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ExamplePaymentTypeCodesCodes = ExamplePaymentTypeCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomExamplePaymentTypeCodesCode() {
    return ExamplePaymentTypeCodesCodes[Math.floor(Math.random() * ExamplePaymentTypeCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomExamplePaymentTypeCodesConcept() {
    return ExamplePaymentTypeCodesConcepts[Math.floor(Math.random() * ExamplePaymentTypeCodesConcepts.length)];
}
