import { NursingHomeResidentialStatus } from "./NursingHomeResidentialStatus";
import { PatientStatus } from "./PatientStatus";
import { Encounter, Extension } from "fhir/r4";
export interface PASEncounter extends Omit<Encounter, 'status' | 'extension'> {
    resourceType: 'Encounter';
    status: "planned";
    extension?: (Extension | PatientStatus | NursingHomeResidentialStatus)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASEncounter(resource: PASEncounter, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
