import { Bundle, BundleEntry, FhirResource, Identifier } from "fhir/r4";
export interface PASRequestBundleEntry extends Omit<BundleEntry, 'resource'> {
    /** Must Support */
    resource: FhirResource;
}
export interface PASRequestBundle extends Omit<Bundle, 'identifier' | 'type' | 'entry'> {
    resourceType: 'Bundle';
    /** Must Support */
    identifier: Identifier;
    type: "collection";
    /** Must Support */
    entry: PASRequestBundleEntry[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASRequestBundle(resource: PASRequestBundle, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
