import { X12278RequestedServiceTypeCode } from "./valuesets/ValueSet-X12278RequestedServiceType";
import { AdministrationReferenceNumber } from "./AdministrationReferenceNumber";
import { AuthorizationNumber } from "./AuthorizationNumber";
import { CareTeamClaimScope } from "./CareTeamClaimScope";
import { CertificationType } from "./CertificationType";
import { ConditionCode } from "./ConditionCode";
import { HomeHealthCareInformation } from "./HomeHealthCareInformation";
import { ItemTraceNumber } from "./ItemTraceNumber";
import { LevelOfServiceCode } from "./LevelOfServiceCode";
import { Claim, ClaimAccident, ClaimCareTeam, ClaimDiagnosis, ClaimInsurance, ClaimItem, ClaimSupportingInfo, CodeableConcept, Extension, Identifier, Reference, SimpleQuantity } from "fhir/r4";
import { ProductOrServiceCodeEnd } from "./ProductOrServiceCodeEnd";
import { ServiceItemRequestType } from "./ServiceItemRequestType";
export interface ExtensionProductOrServiceCodeEnd extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-productOrServiceCodeEnd';
}
export interface ExtensionCertificationType extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-certificationType';
}
export interface ExtensionServiceItemRequestType extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-serviceItemRequestType';
}
export interface ExtensionAdministrationReferenceNumber extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-administrationReferenceNumber';
}
export interface ExtensionAuthorizationNumber extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-authorizationNumber';
}
export interface ExtensionItemTraceNumber extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemTraceNumber';
}
export interface ExtensionCareTeamClaimScope extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-careTeamClaimScope';
}
export interface PASClaimBaseCareTeam extends Omit<ClaimCareTeam, 'provider' | 'role' | 'qualification' | 'extension'> {
    /** Must Support */
    provider: Reference;
    /** Must Support */
    role?: CodeableConcept;
    /** Must Support */
    qualification?: CodeableConcept;
    extension?: (Extension | CareTeamClaimScope | CareTeamClaimScope | CareTeamClaimScope)[];
}
export interface PASClaimBaseItem extends Omit<ClaimItem, 'revenue' | 'productOrService' | 'modifier' | 'quantity' | 'extension'> {
    /** Must Support */
    revenue?: CodeableConcept;
    /** Must Support | @see {@link ./valuesets/ValueSet-X12278RequestedServiceType.ts} for valid codes (1 codes) */
    productOrService: CodeableConcept & {
        coding: Array<{
            code: X12278RequestedServiceTypeCode;
            system: "http://terminology.hl7.org/CodeSystem/data-absent-reason";
        }>;
    };
    /** Must Support */
    modifier?: CodeableConcept[];
    /** Must Support */
    quantity?: SimpleQuantity;
    extension?: (Extension | ItemTraceNumber | AuthorizationNumber | AdministrationReferenceNumber | ServiceItemRequestType | CertificationType | ProductOrServiceCodeEnd)[];
}
export interface PASClaimBase extends Omit<Claim, 'identifier' | 'status' | 'use' | 'insurer' | 'provider' | 'careTeam' | 'supportingInfo' | 'diagnosis' | 'insurance' | 'accident' | 'item' | 'extension'> {
    /** Must Support */
    identifier?: Identifier[];
    status: "active";
    use: "preauthorization";
    /** Must Support */
    insurer: Reference;
    /** Must Support */
    provider: Reference;
    /** Must Support */
    careTeam?: PASClaimBaseCareTeam[];
    /** Must Support */
    supportingInfo?: ClaimSupportingInfo[];
    /** Must Support */
    diagnosis?: ClaimDiagnosis[];
    /** Must Support */
    insurance: ClaimInsurance[];
    /** Must Support */
    accident?: ClaimAccident;
    /** Must Support */
    item: PASClaimBaseItem[];
    extension?: (Extension | LevelOfServiceCode | ConditionCode | HomeHealthCareInformation)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASClaimBase(resource: PASClaimBase, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
