import { Extension } from "fhir/r4";
export interface CRDCoverageInformation extends Omit<Extension, 'extension' | 'url'> {
    extension: Extension[];
    url: "http://hl7.org/fhir/us/davinci-crd/StructureDefinition/ext-coverage-information";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateCRDCoverageInformation(resource: CRDCoverageInformation, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
