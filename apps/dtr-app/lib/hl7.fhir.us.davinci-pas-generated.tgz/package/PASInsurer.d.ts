import { CodeableConcept, Organization } from "fhir/r4";
export interface PASInsurer extends Omit<Organization, 'type'> {
    resourceType: 'Organization';
    /** Must Support */
    type?: CodeableConcept[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASInsurer(resource: PASInsurer, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
