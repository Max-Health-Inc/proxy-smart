import { PASClaimInquiry } from "./PASClaimInquiry.js";
import type { ValidatorOptions } from "./ValidatorOptions.js";
export declare class PASClaimInquiryClass {
    private resource;
    /** Pattern constraints for profile fields (used by random() generator) */
    protected static readonly _fieldPatterns: {
        status: string;
        use: string;
        "OverallClaimMember.careTeamClaimScope.url": string;
        "OverallClaimMember.careTeamClaimScope": boolean;
        "ItemClaimMember.careTeamClaimScope.url": string;
        "supportingInfo.category": string;
        "PatientEvent.category": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "AdmissionDates.category": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "DischargeDates.category": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "diagnosis.type": string;
        "insurance.focal": boolean;
        "item.productOrService": string;
        _refReq_payee: {
            type: boolean;
        };
        _refReq_careTeam: {
            extension: {
                profile: string;
            };
            sequence: boolean;
            provider: boolean;
            "extension.url": boolean;
        };
        _refReq_supportingInfo: {
            sequence: boolean;
            category: boolean;
            timingDate: boolean;
        };
        _refReq_diagnosis: {
            sequence: boolean;
            diagnosisCodeableConcept: boolean;
        };
        _refReq_procedure: {
            sequence: boolean;
            procedureCodeableConcept: boolean;
        };
        _refReq_insurance: {
            sequence: boolean;
            focal: boolean;
            coverage: boolean;
        };
        _refReq_accident: {
            date: boolean;
        };
        _refReq_item: {
            sequence: boolean;
            productOrService: boolean;
            "detail.sequence": boolean;
            "detail.productOrService": boolean;
            "detail.subDetail.sequence": boolean;
            "detail.subDetail.productOrService": boolean;
        };
    };
    /** Fields that are forbidden (max=0) in this profile - must not be generated */
    protected static readonly _forbiddenFields: string[];
    /** FHIR element ordering for this profile's base resource (used by enrichResource for correct JSON field order) */
    protected static readonly _fieldOrder: string[];
    /** ValueSet bindings for coded fields - maps field name to ValueSet URL */
    static readonly valueSetBindings: Record<string, string>;
    /** Code resolver for ValueSet bindings - returns a random valid code from a ValueSet by URL */
    protected static readonly _codeResolver: ((url: string) => {
        code: string;
        system: string;
        display?: string;
    } | undefined) | undefined;
    constructor(resource: PASClaimInquiry);
    /** Validate current resource instance. */
    validate(options?: ValidatorOptions): Promise<{
        errors: string[];
        warnings: string[];
    }>;
    getResource(): PASClaimInquiry;
    setResource(resource: PASClaimInquiry): void;
    /**
     * Returns a plain JSON clone of the underlying resource ONLY if the last validation succeeded with zero errors.
     * Call validate() first; otherwise this method throws to prevent accidental use of invalid / unchecked data.
     */
    toJSON(): Promise<PASClaimInquiry>;
    /**
     * Create an empty instance for parity testing: for true FHIR resources, includes only resourceType; for datatypes, returns an empty object.
     * Note: meta.profile (when applicable) will be ensured by the constructor when wrapping this resource.
     */
    static empty(overrides?: Partial<PASClaimInquiry>): PASClaimInquiry;
    /**
     * Create a minimal randomized instance of PASClaimInquiry.
     * Populates id, resourceType (if applicable) and primitive required (min>0) top-level fields with placeholders.
     */
    static random(overrides?: Partial<PASClaimInquiry>, opts?: {
        seed?: number;
    }): PASClaimInquiry;
    /** Convenience: returns a class instance wrapping a randomized resource. */
    static randomClass(overrides?: Partial<PASClaimInquiry>, opts?: {
        seed?: number;
    }): PASClaimInquiryClass;
}
