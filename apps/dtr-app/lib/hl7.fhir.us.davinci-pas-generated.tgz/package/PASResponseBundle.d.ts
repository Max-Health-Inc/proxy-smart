import { Bundle, BundleEntry, FhirResource } from "fhir/r4";
export interface PASResponseBundleEntry extends Omit<BundleEntry, 'resource'> {
    /** Must Support */
    resource: FhirResource;
}
export interface PASResponseBundle extends Omit<Bundle, 'type' | 'entry'> {
    resourceType: 'Bundle';
    type: "collection";
    /** Must Support */
    entry: PASResponseBundleEntry[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASResponseBundle(resource: PASResponseBundle, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
