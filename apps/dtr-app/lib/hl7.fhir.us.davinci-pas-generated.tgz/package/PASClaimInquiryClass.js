import { validatePASClaimInquiry } from "./PASClaimInquiry.js";
// Only import helpers actually referenced below (dynamic based on required fields)
import { randomId, setRandomSeed, enrichResource, randomDate, skeletonCodeableConcept, skeletonReference } from "./random/index.js";
import { createRequire } from 'module';
const __require = createRequire(import.meta.url);
function ensureProfile(res, profile) {
    if (!res.meta) {
        res.meta = { profile: [profile] };
        return;
    }
    if (!res.meta.profile) {
        res.meta.profile = [profile];
        return;
    }
    if (!res.meta.profile.includes(profile)) {
        res.meta.profile = [...res.meta.profile, profile];
    }
}
// Internal helper (emitted per class file) to clone without resorting to 'any'.
function safeClone(value) {
    // Use native structuredClone if present; otherwise fallback to JSON round-trip.
    // We intentionally avoid casting through any to satisfy no-explicit-any lint rule.
    const g = globalThis;
    // Narrow globalThis to an object potentially containing structuredClone.
    if (typeof g.structuredClone === 'function') {
        return g.structuredClone(value);
    }
    return JSON.parse(JSON.stringify(value)); // best-effort deep clone
}
export class PASClaimInquiryClass {
    constructor(resource) {
        this.resource = resource;
        ensureProfile(this.resource, 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-claim-inquiry');
    }
    /** Validate current resource instance. */
    async validate(options) {
        return validatePASClaimInquiry(this.resource, options);
    }
    getResource() {
        return this.resource;
    }
    setResource(resource) {
        this.resource = resource;
        ensureProfile(this.resource, 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-claim-inquiry');
    }
    /**
     * Returns a plain JSON clone of the underlying resource ONLY if the last validation succeeded with zero errors.
     * Call validate() first; otherwise this method throws to prevent accidental use of invalid / unchecked data.
     */
    async toJSON() {
        return safeClone(this.resource);
    }
    /**
     * Create an empty instance for parity testing: for true FHIR resources, includes only resourceType; for datatypes, returns an empty object.
     * Note: meta.profile (when applicable) will be ensured by the constructor when wrapping this resource.
     */
    static empty(overrides = {}) {
        // For Resource profiles, include only resourceType. For Extension profiles, include url so the instance is minimally meaningful.
        const base = {
            resourceType: 'Claim',
        };
        return { ...base, ...overrides };
    }
    /**
     * Create a minimal randomized instance of PASClaimInquiry.
     * Populates id, resourceType (if applicable) and primitive required (min>0) top-level fields with placeholders.
     */
    static random(overrides = {}, opts) {
        if (opts?.seed !== undefined) {
            // Direct call (no dynamic require) to ensure deterministic seeding works under ESM.
            setRandomSeed(opts.seed);
        }
        // Start with a Partial to avoid unsafe casting errors; we'll assert at the end.
        const base = { resourceType: 'Claim', id: randomId(), status: "active", type: { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/claim-type', code: 'institutional' }] }, use: "preauthorization", patient: skeletonReference(), created: randomDate(), insurer: skeletonReference(), provider: skeletonReference(), priority: skeletonCodeableConcept('http://terminology.hl7.org/CodeSystem/v3-NullFlavor', ['normal']), insurance: [({ sequence: 1, coverage: { reference: 'Resource/' + randomId() }, focal: true })], item: [({ sequence: 1, productOrService: { coding: [{ code: "not-applicable", system: "http://terminology.hl7.org/CodeSystem/data-absent-reason" }] }, detail: [{ sequence: 1, productOrService: { coding: [{ code: "unknown", system: "http://terminology.hl7.org/CodeSystem/data-absent-reason" }] }, subDetail: [{ sequence: 1, productOrService: { coding: [{ code: "unknown", system: "http://terminology.hl7.org/CodeSystem/data-absent-reason" }] } }] }] })], };
        // Always include meta.profile with this profile's canonical URL if available & only for resource profiles
        ensureProfile(base, 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-claim-inquiry');
        // Enrich the base resource with common fields using centralized enrichment logic
        enrichResource(base, 'Claim', 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-claim-inquiry', PASClaimInquiryClass._fieldPatterns, PASClaimInquiryClass._forbiddenFields, PASClaimInquiryClass.valueSetBindings, PASClaimInquiryClass._codeResolver, PASClaimInquiryClass._fieldOrder);
        // Cast through unknown to acknowledge dynamic enrichment
        return { ...base, ...overrides };
    }
    /** Convenience: returns a class instance wrapping a randomized resource. */
    static randomClass(overrides = {}, opts) {
        return new PASClaimInquiryClass(this.random(overrides, opts));
    }
}
/** Pattern constraints for profile fields (used by random() generator) */
PASClaimInquiryClass._fieldPatterns = {
    "status": "active",
    "use": "preauthorization",
    "OverallClaimMember.careTeamClaimScope.url": "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-careTeamClaimScope",
    "OverallClaimMember.careTeamClaimScope": true,
    "ItemClaimMember.careTeamClaimScope.url": "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-careTeamClaimScope",
    "supportingInfo.category": "dischargeDates",
    "PatientEvent.category": {
        "coding": [
            {
                "system": "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes",
                "code": "patientEvent"
            }
        ]
    },
    "AdmissionDates.category": {
        "coding": [
            {
                "system": "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes",
                "code": "admissionDates"
            }
        ]
    },
    "DischargeDates.category": {
        "coding": [
            {
                "system": "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes",
                "code": "dischargeDates"
            }
        ]
    },
    "diagnosis.type": "patientreasonforvisit",
    "insurance.focal": true,
    "item.productOrService": "not-applicable",
    "_refReq_payee": {
        "type": true
    },
    "_refReq_careTeam": {
        "extension": {
            "profile": "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-careTeamClaimScope"
        },
        "sequence": true,
        "provider": true,
        "extension.url": true
    },
    "_refReq_supportingInfo": {
        "sequence": true,
        "category": true,
        "timingDate": true
    },
    "_refReq_diagnosis": {
        "sequence": true,
        "diagnosisCodeableConcept": true
    },
    "_refReq_procedure": {
        "sequence": true,
        "procedureCodeableConcept": true
    },
    "_refReq_insurance": {
        "sequence": true,
        "focal": true,
        "coverage": true
    },
    "_refReq_accident": {
        "date": true
    },
    "_refReq_item": {
        "sequence": true,
        "productOrService": true,
        "detail.sequence": true,
        "detail.productOrService": true,
        "detail.subDetail.sequence": true,
        "detail.subDetail.productOrService": true
    }
};
/** Fields that are forbidden (max=0) in this profile - must not be generated */
PASClaimInquiryClass._forbiddenFields = ["supportingInfo.value[x]"];
/** FHIR element ordering for this profile's base resource (used by enrichResource for correct JSON field order) */
PASClaimInquiryClass._fieldOrder = ["id", "meta", "implicitRules", "language", "text", "contained", "extension", "modifierExtension", "identifier", "status", "type", "subType", "use", "patient", "billablePeriod", "created", "enterer", "insurer", "provider", "priority", "fundsReserve", "related", "prescription", "originalPrescription", "payee", "referral", "facility", "careTeam", "supportingInfo", "diagnosis", "procedure", "insurance", "accident", "item", "total"];
/** ValueSet bindings for coded fields - maps field name to ValueSet URL */
PASClaimInquiryClass.valueSetBindings = {
    "language": "http://hl7.org/fhir/ValueSet/languages",
    "status": "http://hl7.org/fhir/ValueSet/fm-status|4.0.1",
    "type": "http://hl7.org/fhir/ValueSet/claim-type",
    "subType": "http://hl7.org/fhir/ValueSet/claim-subtype",
    "use": "http://hl7.org/fhir/ValueSet/claim-use|4.0.1",
    "priority": "http://hl7.org/fhir/ValueSet/process-priority",
    "fundsReserve": "http://hl7.org/fhir/ValueSet/fundsreserve",
    "related.relationship": "http://hl7.org/fhir/ValueSet/related-claim-relationship",
    "payee.type": "http://hl7.org/fhir/ValueSet/payeetype",
    "careTeam.role": "http://hl7.org/fhir/ValueSet/claim-careteamrole",
    "careTeam.qualification": "http://hl7.org/fhir/ValueSet/provider-qualification",
    "supportingInfo.category": "http://hl7.org/fhir/us/davinci-pas/ValueSet/PASSupportingInfoType",
    "supportingInfo.code": "http://hl7.org/fhir/ValueSet/claim-exception",
    "supportingInfo.reason": "http://hl7.org/fhir/ValueSet/missing-tooth-reason",
    "diagnosis.diagnosis[x]": "http://hl7.org/fhir/us/davinci-pas/ValueSet/X12278DiagnosisCodes",
    "diagnosis.type": "http://hl7.org/fhir/us/davinci-pas/ValueSet/X12278DiagnosisType",
    "diagnosis.onAdmission": "http://hl7.org/fhir/ValueSet/ex-diagnosis-on-admission",
    "diagnosis.packageCode": "http://hl7.org/fhir/ValueSet/ex-diagnosisrelatedgroup",
    "procedure.type": "http://hl7.org/fhir/ValueSet/ex-procedure-type",
    "procedure.procedure[x]": "http://hl7.org/fhir/ValueSet/icd-10-procedures",
    "accident.type": "https://valueset.x12.org/x217/005010/request/2000E/UM/1/05/01/1362",
    "item.revenue": "http://hl7.org/fhir/us/davinci-pas/ValueSet/AHANUBCRevenueCodes",
    "item.category": "https://valueset.x12.org/x217/005010/request/2000F/UM/1/03/00/1365",
    "item.productOrService": "http://hl7.org/fhir/us/davinci-pas/ValueSet/X12278RequestedServiceType",
    "item.modifier": "http://hl7.org/fhir/us/davinci-pas/ValueSet/X12278RequestedServiceModifierType",
    "item.programCode": "http://hl7.org/fhir/ValueSet/ex-program-code",
    "item.location[x]": "http://hl7.org/fhir/us/davinci-pas/ValueSet/X12278LocationType",
    "item.bodySite": "http://hl7.org/fhir/ValueSet/tooth",
    "item.subSite": "http://hl7.org/fhir/ValueSet/surface",
    "item.detail.revenue": "http://hl7.org/fhir/ValueSet/ex-revenue-center",
    "item.detail.category": "http://hl7.org/fhir/ValueSet/ex-benefitcategory",
    "item.detail.productOrService": "http://hl7.org/fhir/ValueSet/service-uscls",
    "item.detail.modifier": "http://hl7.org/fhir/ValueSet/claim-modifiers",
    "item.detail.programCode": "http://hl7.org/fhir/ValueSet/ex-program-code",
    "item.detail.subDetail.revenue": "http://hl7.org/fhir/ValueSet/ex-revenue-center",
    "item.detail.subDetail.category": "http://hl7.org/fhir/ValueSet/ex-benefitcategory",
    "item.detail.subDetail.productOrService": "http://hl7.org/fhir/ValueSet/service-uscls",
    "item.detail.subDetail.modifier": "http://hl7.org/fhir/ValueSet/claim-modifiers",
    "item.detail.subDetail.programCode": "http://hl7.org/fhir/ValueSet/ex-program-code"
};
/** Code resolver for ValueSet bindings - returns a random valid code from a ValueSet by URL */
PASClaimInquiryClass._codeResolver = (() => {
    // Try to load the ValueSetRegistry - it may not exist if no ValueSets were generated
    try {
        const registry = __require('./valuesets/index.js');
        if (registry && typeof registry.getRandomConceptByUrl === 'function') {
            return registry.getRandomConceptByUrl;
        }
    }
    catch { /* ValueSetRegistry not available */ }
    return undefined;
})();
