import { CoverageInformation } from "./CoverageInformation";
import { DeviceRequest, Extension, Reference } from "fhir/r4";
export interface PASDeviceRequest extends Omit<DeviceRequest, 'intent' | 'subject' | 'extension'> {
    intent: "order";
    /** Must Support */
    subject: Reference;
    extension?: (Extension | CoverageInformation)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASDeviceRequest(resource: PASDeviceRequest, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
