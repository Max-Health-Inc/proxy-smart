import { CRDCoverageInformation } from "./CRDCoverageInformation";
import { DeviceRequest, Extension, Reference } from "fhir/r4";
export interface PASDeviceRequest extends Omit<DeviceRequest, 'intent' | 'subject' | 'extension'> {
    resourceType: 'DeviceRequest';
    intent: "order";
    /** Must Support */
    subject: Reference;
    extension?: (Extension | CRDCoverageInformation)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASDeviceRequest(resource: PASDeviceRequest, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
