import { PASTaskCodesCode } from "./valuesets/ValueSet-PASTaskCodes";
import { PALineNumber } from "./PALineNumber";
import { CodeableConcept, Coding, Extension, Identifier, Reference, Task, TaskInput } from "fhir/r4";
export interface ExtensionPaLineNumber extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-paLineNumber';
}
export interface PASTaskReasonCodeCoding extends Omit<Coding, 'system' | 'code'> {
    system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes";
    code: "priorAuthorization";
}
export interface PASTaskInput extends Omit<TaskInput, 'type' | 'extension'> {
    type: CodeableConcept;
    extension?: (Extension | PALineNumber | PALineNumber)[];
}
export interface PASTask extends Omit<Task, 'identifier' | 'statusReason' | 'intent' | 'code' | 'for' | 'requester' | 'owner' | 'reasonCode' | 'reasonReference' | 'input'> {
    /** Must Support */
    identifier: Identifier[];
    /** Must Support */
    statusReason?: CodeableConcept;
    intent: "order";
    /** Must Support | @see {@link ./valuesets/ValueSet-PASTaskCodes.ts} for valid codes (2 codes) */
    code: CodeableConcept & {
        coding: Array<{
            code: PASTaskCodesCode;
            system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes";
        }>;
    };
    /** Must Support */
    for: Reference;
    /** Must Support */
    requester: Reference;
    /** Must Support */
    owner: Reference;
    reasonCode: {
        coding: PASTaskReasonCodeCoding[];
    };
    /** Must Support */
    reasonReference: Reference;
    /** Must Support */
    input: PASTaskInput[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASTask(resource: PASTask, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
