import { SubscriberRelationshipCode } from "./valuesets/ValueSet-SubscriberRelationship";
import { CodeableConcept, Coverage, Identifier, Reference } from "fhir/r4";
export interface PASCoverage extends Omit<Coverage, 'identifier' | 'status' | 'subscriber' | 'relationship' | 'payor'> {
    /** Must Support */
    identifier?: Identifier[];
    status: "active";
    /** Must Support */
    subscriber?: Reference;
    /** Must Support | @see {@link ./valuesets/ValueSet-SubscriberRelationship.ts} for valid codes (7 codes) */
    relationship?: CodeableConcept & {
        coding: Array<{
            code: SubscriberRelationshipCode;
            system: "http://terminology.hl7.org/CodeSystem/subscriber-relationship";
        }>;
    };
    /** Must Support */
    payor: Reference[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASCoverage(resource: PASCoverage, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
