import { CRDCoverageInformation } from "./CRDCoverageInformation";
import { CodeableConcept, Extension, NutritionOrder, NutritionOrderEnteralFormula, NutritionOrderOralDiet, Reference, SimpleQuantity } from "fhir/r4";
export interface PASNutritionOrderOralDiet extends Omit<NutritionOrderOralDiet, 'type'> {
    /** Must Support */
    type?: CodeableConcept[];
}
export interface PASNutritionOrderEnteralFormula extends Omit<NutritionOrderEnteralFormula, 'baseFormulaType' | 'caloricDensity' | 'maxVolumeToDeliver'> {
    /** Must Support */
    baseFormulaType?: CodeableConcept;
    caloricDensity?: SimpleQuantity;
    maxVolumeToDeliver?: SimpleQuantity;
}
export interface PASNutritionOrder extends Omit<NutritionOrder, 'intent' | 'patient' | 'oralDiet' | 'enteralFormula' | 'extension'> {
    intent: "order";
    /** Must Support */
    patient: Reference;
    /** Must Support */
    oralDiet?: PASNutritionOrderOralDiet;
    /** Must Support */
    enteralFormula?: PASNutritionOrderEnteralFormula;
    extension?: (Extension | CRDCoverageInformation)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASNutritionOrder(resource: PASNutritionOrder, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
