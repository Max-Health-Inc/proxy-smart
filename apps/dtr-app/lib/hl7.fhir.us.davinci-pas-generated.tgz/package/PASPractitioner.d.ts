import { PASIdentifier } from "./PASIdentifier";
import { Address, ContactPoint, Identifier, Practitioner } from "fhir/r4";
export interface PASPractitioner extends Omit<Practitioner, 'identifier' | 'telecom' | 'address'> {
    /** Must Support */
    identifier: (Identifier | PASIdentifier)[];
    /** Must Support */
    telecom?: ContactPoint[];
    /** Must Support */
    address?: Address[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASPractitioner(resource: PASPractitioner, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
