import { PASIdentifier } from "./PASIdentifier";
import { Identifier, Practitioner } from "fhir/r4";
export interface PASPractitioner extends Omit<Practitioner, 'identifier'> {
    resourceType: 'Practitioner';
    /** Must Support */
    identifier: (Identifier | PASIdentifier)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASPractitioner(resource: PASPractitioner, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
