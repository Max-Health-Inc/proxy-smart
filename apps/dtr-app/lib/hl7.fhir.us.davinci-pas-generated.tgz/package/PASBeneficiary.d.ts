import { USCoreBirthSexExtension } from "./USCoreBirthSexExtension";
import { USCoreEthnicityExtension } from "./USCoreEthnicityExtension";
import { USCoreRaceExtension } from "./USCoreRaceExtension";
import { Extension, Patient } from "fhir/r4";
export interface PASBeneficiary extends Omit<Patient, 'extension'> {
    extension?: (Extension | USCoreRaceExtension | USCoreEthnicityExtension | USCoreBirthSexExtension)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASBeneficiary(resource: PASBeneficiary, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
