import { USCoreBirthSexExtension } from "./USCoreBirthSexExtension";
import { USCoreEthnicityExtension } from "./USCoreEthnicityExtension";
import { USCoreRaceExtension } from "./USCoreRaceExtension";
import { ContactPoint, Extension, Patient, PatientCommunication } from "fhir/r4";
export interface PASBeneficiary extends Omit<Patient, 'telecom' | 'communication' | 'extension'> {
    /** Must Support */
    telecom?: ContactPoint[];
    /** Must Support */
    communication?: PatientCommunication[];
    extension?: (Extension | USCoreRaceExtension | USCoreEthnicityExtension | USCoreBirthSexExtension)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASBeneficiary(resource: PASBeneficiary, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
