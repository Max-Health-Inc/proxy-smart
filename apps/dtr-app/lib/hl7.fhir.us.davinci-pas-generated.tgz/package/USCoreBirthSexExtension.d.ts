import { Extension } from "fhir/r4";
export interface USCoreBirthSexExtension extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/us/core/StructureDefinition/us-core-birthsex";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateUSCoreBirthSexExtension(resource: USCoreBirthSexExtension, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
