import { Address, Location } from "fhir/r4";
export interface PASLocation extends Omit<Location, 'address'> {
    resourceType: 'Location';
    /** Must Support */
    address: Address;
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASLocation(resource: PASLocation, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
