import { PASIdentifier } from "./PASIdentifier";
import { Identifier, Organization } from "fhir/r4";
export interface PASOrganization extends Omit<Organization, 'identifier'> {
    /** Must Support */
    identifier?: (Identifier | PASIdentifier | PASIdentifier)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASOrganization(resource: PASOrganization, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
