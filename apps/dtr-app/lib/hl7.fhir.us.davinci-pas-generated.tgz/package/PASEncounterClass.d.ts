import { PASEncounter } from "./PASEncounter.js";
import type { ValidatorOptions } from "./ValidatorOptions.js";
export declare class PASEncounterClass {
    private resource;
    /** Pattern constraints for profile fields (used by random() generator) */
    protected static readonly _fieldPatterns: {
        "nursingHomeResidentialStatus.url": string;
        "identifier.use": string;
        "identifier.type": string;
        status: string;
        "statusHistory.status": string;
        "classHistory.class": string;
        "participant.type": string;
        "diagnosis.use": string;
        "hospitalization.reAdmission": string;
        "hospitalization.dietPreference": string;
        "hospitalization.specialCourtesy": string;
        "hospitalization.specialArrangement": string;
        "hospitalization.dischargeDisposition": string;
        "location.status": string;
        "location.physicalType": string;
        _refReq_extension: {
            url: boolean;
        };
        _refReq_identifier: {
            system: boolean;
            value: boolean;
        };
        _refReq_statusHistory: {
            status: boolean;
            period: boolean;
        };
        _refReq_classHistory: {
            class: boolean;
            period: boolean;
        };
        _refReq_diagnosis: {
            condition: boolean;
        };
        _refReq_location: {
            location: boolean;
        };
    };
    /** Fields that are forbidden (max=0) in this profile - must not be generated */
    protected static readonly _forbiddenFields: string[];
    /** FHIR element ordering for this profile's base resource (used by enrichResource for correct JSON field order) */
    protected static readonly _fieldOrder: string[];
    /** ValueSet bindings for coded fields - maps field name to ValueSet URL */
    static readonly valueSetBindings: Record<string, string>;
    /** Code resolver for ValueSet bindings - returns a random valid code from a ValueSet by URL */
    protected static readonly _codeResolver: ((url: string) => {
        code: string;
        system: string;
        display?: string;
    } | undefined) | undefined;
    constructor(resource: PASEncounter);
    /** Validate current resource instance. */
    validate(options?: ValidatorOptions): Promise<{
        errors: string[];
        warnings: string[];
    }>;
    getResource(): PASEncounter;
    setResource(resource: PASEncounter): void;
    /**
     * Returns a plain JSON clone of the underlying resource ONLY if the last validation succeeded with zero errors.
     * Call validate() first; otherwise this method throws to prevent accidental use of invalid / unchecked data.
     */
    toJSON(): Promise<PASEncounter>;
    /**
     * Create an empty instance for parity testing: for true FHIR resources, includes only resourceType; for datatypes, returns an empty object.
     * Note: meta.profile (when applicable) will be ensured by the constructor when wrapping this resource.
     */
    static empty(overrides?: Partial<PASEncounter>): PASEncounter;
    /**
     * Create a minimal randomized instance of PASEncounter.
     * Populates id, resourceType (if applicable) and primitive required (min>0) top-level fields with placeholders.
     */
    static random(overrides?: Partial<PASEncounter>, opts?: {
        seed?: number;
    }): PASEncounter;
    /** Convenience: returns a class instance wrapping a randomized resource. */
    static randomClass(overrides?: Partial<PASEncounter>, opts?: {
        seed?: number;
    }): PASEncounterClass;
}
