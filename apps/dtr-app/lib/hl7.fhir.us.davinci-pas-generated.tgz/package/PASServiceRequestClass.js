import { validatePASServiceRequest } from "./PASServiceRequest.js";
// Only import helpers actually referenced below (dynamic based on required fields)
import { randomId, setRandomSeed, enrichResource, skeletonReference } from "./random/index.js";
import { createRequire } from 'module';
const __require = createRequire(import.meta.url);
function ensureProfile(res, profile) {
    if (!res.meta) {
        res.meta = { profile: [profile] };
        return;
    }
    if (!res.meta.profile) {
        res.meta.profile = [profile];
        return;
    }
    if (!res.meta.profile.includes(profile)) {
        res.meta.profile = [...res.meta.profile, profile];
    }
}
// Internal helper (emitted per class file) to clone without resorting to 'any'.
function safeClone(value) {
    // Use native structuredClone if present; otherwise fallback to JSON round-trip.
    // We intentionally avoid casting through any to satisfy no-explicit-any lint rule.
    const g = globalThis;
    // Narrow globalThis to an object potentially containing structuredClone.
    if (typeof g.structuredClone === 'function') {
        return g.structuredClone(value);
    }
    return JSON.parse(JSON.stringify(value)); // best-effort deep clone
}
export class PASServiceRequestClass {
    constructor(resource) {
        this.resource = resource;
        ensureProfile(this.resource, 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-servicerequest');
    }
    /** Validate current resource instance. */
    async validate(options) {
        return validatePASServiceRequest(this.resource, options);
    }
    getResource() {
        return this.resource;
    }
    setResource(resource) {
        this.resource = resource;
        ensureProfile(this.resource, 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-servicerequest');
    }
    /**
     * Returns a plain JSON clone of the underlying resource ONLY if the last validation succeeded with zero errors.
     * Call validate() first; otherwise this method throws to prevent accidental use of invalid / unchecked data.
     */
    async toJSON() {
        return safeClone(this.resource);
    }
    /**
     * Create an empty instance for parity testing: for true FHIR resources, includes only resourceType; for datatypes, returns an empty object.
     * Note: meta.profile (when applicable) will be ensured by the constructor when wrapping this resource.
     */
    static empty(overrides = {}) {
        // For Resource profiles, include only resourceType. For Extension profiles, include url so the instance is minimally meaningful.
        const base = {
            resourceType: 'ServiceRequest',
        };
        return { ...base, ...overrides };
    }
    /**
     * Create a minimal randomized instance of PASServiceRequest.
     * Populates id, resourceType (if applicable) and primitive required (min>0) top-level fields with placeholders.
     */
    static random(overrides = {}, opts) {
        if (opts?.seed !== undefined) {
            // Direct call (no dynamic require) to ensure deterministic seeding works under ESM.
            setRandomSeed(opts.seed);
        }
        // Start with a Partial to avoid unsafe casting errors; we'll assert at the end.
        const base = { resourceType: 'ServiceRequest', id: randomId(), status: "on-hold", intent: "order", subject: skeletonReference(), };
        // Always include meta.profile with this profile's canonical URL if available & only for resource profiles
        ensureProfile(base, 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-servicerequest');
        // Enrich the base resource with common fields using centralized enrichment logic
        enrichResource(base, 'ServiceRequest', 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-servicerequest', PASServiceRequestClass._fieldPatterns, PASServiceRequestClass._forbiddenFields, PASServiceRequestClass.valueSetBindings, PASServiceRequestClass._codeResolver, PASServiceRequestClass._fieldOrder);
        // Cast through unknown to acknowledge dynamic enrichment
        return { ...base, ...overrides };
    }
    /** Convenience: returns a class instance wrapping a randomized resource. */
    static randomClass(overrides = {}, opts) {
        return new PASServiceRequestClass(this.random(overrides, opts));
    }
}
/** Pattern constraints for profile fields (used by random() generator) */
PASServiceRequestClass._fieldPatterns = {
    "intent": "order",
    "_choiceType_quantity[x]": [
        "Quantity"
    ],
    "_choiceType_occurrence[x]": [
        "Timing"
    ],
    "_choiceType_asNeeded[x]": [
        "boolean",
        "CodeableConcept"
    ]
};
/** Fields that are forbidden (max=0) in this profile - must not be generated */
PASServiceRequestClass._forbiddenFields = [];
/** FHIR element ordering for this profile's base resource (used by enrichResource for correct JSON field order) */
PASServiceRequestClass._fieldOrder = ["id", "meta", "implicitRules", "language", "text", "contained", "extension", "modifierExtension", "identifier", "instantiatesCanonical", "instantiatesUri", "basedOn", "replaces", "requisition", "status", "intent", "category", "priority", "doNotPerform", "code", "orderDetail", "quantity[x]", "subject", "encounter", "occurrence[x]", "asNeeded[x]", "authoredOn", "requester", "performerType", "performer", "locationCode", "locationReference", "reasonCode", "reasonReference", "insurance", "supportingInfo", "specimen", "bodySite", "note", "patientInstruction", "relevantHistory"];
/** ValueSet bindings for coded fields - maps field name to ValueSet URL */
PASServiceRequestClass.valueSetBindings = {
    "language": "http://hl7.org/fhir/ValueSet/languages",
    "status": "http://hl7.org/fhir/ValueSet/request-status|4.0.1",
    "intent": "http://hl7.org/fhir/ValueSet/request-intent|4.0.1",
    "category": "http://hl7.org/fhir/ValueSet/servicerequest-category",
    "priority": "http://hl7.org/fhir/ValueSet/request-priority|4.0.1",
    "code": "http://hl7.org/fhir/us/davinci-pas/ValueSet/X12278RequestedServiceType",
    "orderDetail": "http://hl7.org/fhir/ValueSet/servicerequest-orderdetail",
    "asNeeded[x]": "http://hl7.org/fhir/ValueSet/medication-as-needed-reason",
    "performerType": "http://hl7.org/fhir/ValueSet/participant-role",
    "locationCode": "http://terminology.hl7.org/ValueSet/v3-ServiceDeliveryLocationRoleType",
    "reasonCode": "http://hl7.org/fhir/ValueSet/procedure-reason",
    "bodySite": "http://hl7.org/fhir/ValueSet/body-site"
};
/** Code resolver for ValueSet bindings - returns a random valid code from a ValueSet by URL */
PASServiceRequestClass._codeResolver = (() => {
    // Try to load the ValueSetRegistry - it may not exist if no ValueSets were generated
    try {
        const registry = __require('./valuesets/index.js');
        if (registry && typeof registry.getRandomConceptByUrl === 'function') {
            return registry.getRandomConceptByUrl;
        }
    }
    catch { /* ValueSetRegistry not available */ }
    return undefined;
})();
