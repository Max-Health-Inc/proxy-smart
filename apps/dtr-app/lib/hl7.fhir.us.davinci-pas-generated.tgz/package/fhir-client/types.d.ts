import type * as GeneratedTypes from "../index.js";
/**
 * A FHIR resource with an ID
 */
export type WithId<T> = {
    id: string;
} & T;
/**
 * Search parameters for FHIR resources
 */
export type SearchParams = Record<string, boolean | number | string | string[] | undefined>;
/**
 * Bundle of FHIR resources
 */
export interface Bundle<T> {
    resourceType: "Bundle";
    type: "collection" | "searchset" | "transaction-response" | "transaction";
    total?: number;
    link?: {
        relation: string;
        url: string;
    }[];
    entry?: {
        resource: T;
        fullUrl?: string;
    }[];
}
/**
 * Type-safe FHIR resource types
 */
export type FhirResource = GeneratedTypes.PASBeneficiary | GeneratedTypes.PASClaim | GeneratedTypes.PASClaimBase | GeneratedTypes.PASClaimInquiry | GeneratedTypes.PASClaimInquiryResponse | GeneratedTypes.PASClaimResponse | GeneratedTypes.PASClaimResponseBase | GeneratedTypes.PASClaimUpdate | GeneratedTypes.PASCommunicationRequest | GeneratedTypes.PASCoverage | GeneratedTypes.PASDeviceRequest | GeneratedTypes.PASEncounter | GeneratedTypes.PASInquiryRequestBundle | GeneratedTypes.PASInquiryResponseBundle | GeneratedTypes.PASInsurer | GeneratedTypes.PASLocation | GeneratedTypes.PASMedicationRequest | GeneratedTypes.PASNutritionOrder | GeneratedTypes.PASOrganization | GeneratedTypes.PASPractitioner | GeneratedTypes.PASPractitionerRole | GeneratedTypes.PASRequestBundle | GeneratedTypes.PASRequestor | GeneratedTypes.PASResponseBundle | GeneratedTypes.PASServiceRequest | GeneratedTypes.PASSubscriber | GeneratedTypes.PASTask;
