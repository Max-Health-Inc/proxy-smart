import type * as GeneratedTypes from "../index.js";
/**
 * A FHIR resource with an ID
 */
export type WithId<T> = {
    id: string;
} & T;
/**
 * Search parameter value type — all values are serialized to query strings.
 */
export type SearchParamValue = boolean | number | string | string[] | undefined;
/**
 * Search parameters for FHIR resources (generic untyped version).
 */
export type SearchParams = Record<string, SearchParamValue>;
/**
 * Common search parameters supported by all FHIR resources.
 * Includes an index signature to allow search parameter modifiers (e.g. name:exact).
 */
export interface CommonSearchParams {
    _id?: SearchParamValue;
    _lastUpdated?: SearchParamValue;
    _tag?: SearchParamValue;
    _profile?: SearchParamValue;
    _security?: SearchParamValue;
    _count?: SearchParamValue;
    _sort?: SearchParamValue;
    _include?: SearchParamValue;
    _revinclude?: SearchParamValue;
    _summary?: SearchParamValue;
    _elements?: SearchParamValue;
    _total?: SearchParamValue;
    [key: string]: SearchParamValue;
}
/**
 * Bundle of FHIR resources
 */
export interface Bundle<T> {
    resourceType: "Bundle";
    type: "collection" | "searchset" | "transaction-response" | "transaction";
    total?: number;
    link?: {
        relation: string;
        url: string;
    }[];
    entry?: {
        resource: T;
        fullUrl?: string;
    }[];
}
/**
 * Type-safe FHIR resource types
 */
export type FhirResource = GeneratedTypes.PASBeneficiary | GeneratedTypes.PASClaim | GeneratedTypes.PASClaimBase | GeneratedTypes.PASClaimInquiry | GeneratedTypes.PASClaimInquiryResponse | GeneratedTypes.PASClaimResponse | GeneratedTypes.PASClaimResponseBase | GeneratedTypes.PASClaimUpdate | GeneratedTypes.PASCommunicationRequest | GeneratedTypes.PASCoverage | GeneratedTypes.PASDeviceRequest | GeneratedTypes.PASEncounter | GeneratedTypes.PASInquiryRequestBundle | GeneratedTypes.PASInquiryResponseBundle | GeneratedTypes.PASInsurer | GeneratedTypes.PASLocation | GeneratedTypes.PASMedicationRequest | GeneratedTypes.PASNutritionOrder | GeneratedTypes.PASOrganization | GeneratedTypes.PASPractitioner | GeneratedTypes.PASPractitionerRole | GeneratedTypes.PASRequestBundle | GeneratedTypes.PASRequestor | GeneratedTypes.PASResponseBundle | GeneratedTypes.PASServiceRequest | GeneratedTypes.PASSubscriber | GeneratedTypes.PASTask;
/**
 * Typed search parameters for Patient resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface PatientSearchParams extends CommonSearchParams {
    "active"?: SearchParamValue;
    "address"?: SearchParamValue;
    "address-city"?: SearchParamValue;
    "address-country"?: SearchParamValue;
    "address-postalcode"?: SearchParamValue;
    "address-state"?: SearchParamValue;
    "address-use"?: SearchParamValue;
    "age"?: SearchParamValue;
    "birthdate"?: SearchParamValue;
    "birthOrderBoolean"?: SearchParamValue;
    "death-date"?: SearchParamValue;
    "deceased"?: SearchParamValue;
    "email"?: SearchParamValue;
    "family"?: SearchParamValue;
    "gender"?: SearchParamValue;
    "general-practitioner"?: SearchParamValue;
    "given"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "language"?: SearchParamValue;
    "link"?: SearchParamValue;
    "mothersMaidenName"?: SearchParamValue;
    "name"?: SearchParamValue;
    "organization"?: SearchParamValue;
    "part-agree"?: SearchParamValue;
    "phone"?: SearchParamValue;
    "phonetic"?: SearchParamValue;
    "telecom"?: SearchParamValue;
}
/**
 * Typed search parameters for Claim resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface ClaimSearchParams extends CommonSearchParams {
    "care-team"?: SearchParamValue;
    "created"?: SearchParamValue;
    "detail-udi"?: SearchParamValue;
    "encounter"?: SearchParamValue;
    "enterer"?: SearchParamValue;
    "facility"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "insurer"?: SearchParamValue;
    "item-udi"?: SearchParamValue;
    "patient"?: SearchParamValue;
    "payee"?: SearchParamValue;
    "priority"?: SearchParamValue;
    "procedure-udi"?: SearchParamValue;
    "provider"?: SearchParamValue;
    "status"?: SearchParamValue;
    "subdetail-udi"?: SearchParamValue;
    "use"?: SearchParamValue;
}
/**
 * Typed search parameters for ClaimResponse resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface ClaimResponseSearchParams extends CommonSearchParams {
    "created"?: SearchParamValue;
    "disposition"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "insurer"?: SearchParamValue;
    "outcome"?: SearchParamValue;
    "patient"?: SearchParamValue;
    "payment-date"?: SearchParamValue;
    "request"?: SearchParamValue;
    "requestor"?: SearchParamValue;
    "status"?: SearchParamValue;
    "use"?: SearchParamValue;
}
/**
 * Typed search parameters for CommunicationRequest resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface CommunicationRequestSearchParams extends CommonSearchParams {
    "authored"?: SearchParamValue;
    "based-on"?: SearchParamValue;
    "category"?: SearchParamValue;
    "encounter"?: SearchParamValue;
    "group-identifier"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "medium"?: SearchParamValue;
    "occurrence"?: SearchParamValue;
    "patient"?: SearchParamValue;
    "priority"?: SearchParamValue;
    "recipient"?: SearchParamValue;
    "replaces"?: SearchParamValue;
    "requester"?: SearchParamValue;
    "sender"?: SearchParamValue;
    "status"?: SearchParamValue;
    "subject"?: SearchParamValue;
}
/**
 * Typed search parameters for Coverage resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface CoverageSearchParams extends CommonSearchParams {
    "beneficiary"?: SearchParamValue;
    "class-type"?: SearchParamValue;
    "class-value"?: SearchParamValue;
    "dependent"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "patient"?: SearchParamValue;
    "payor"?: SearchParamValue;
    "policy-holder"?: SearchParamValue;
    "status"?: SearchParamValue;
    "subscriber"?: SearchParamValue;
    "type"?: SearchParamValue;
}
/**
 * Typed search parameters for DeviceRequest resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface DeviceRequestSearchParams extends CommonSearchParams {
    "authored-on"?: SearchParamValue;
    "based-on"?: SearchParamValue;
    "code"?: SearchParamValue;
    "device"?: SearchParamValue;
    "encounter"?: SearchParamValue;
    "event-date"?: SearchParamValue;
    "group-identifier"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "instantiates-canonical"?: SearchParamValue;
    "instantiates-uri"?: SearchParamValue;
    "insurance"?: SearchParamValue;
    "intent"?: SearchParamValue;
    "patient"?: SearchParamValue;
    "performer"?: SearchParamValue;
    "prior-request"?: SearchParamValue;
    "requester"?: SearchParamValue;
    "status"?: SearchParamValue;
    "subject"?: SearchParamValue;
}
/**
 * Typed search parameters for Encounter resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface EncounterSearchParams extends CommonSearchParams {
    "account"?: SearchParamValue;
    "appointment"?: SearchParamValue;
    "based-on"?: SearchParamValue;
    "class"?: SearchParamValue;
    "date"?: SearchParamValue;
    "diagnosis"?: SearchParamValue;
    "episode-of-care"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "length"?: SearchParamValue;
    "location"?: SearchParamValue;
    "location-period"?: SearchParamValue;
    "part-of"?: SearchParamValue;
    "participant"?: SearchParamValue;
    "participant-type"?: SearchParamValue;
    "patient"?: SearchParamValue;
    "practitioner"?: SearchParamValue;
    "reason-code"?: SearchParamValue;
    "reason-reference"?: SearchParamValue;
    "service-provider"?: SearchParamValue;
    "special-arrangement"?: SearchParamValue;
    "status"?: SearchParamValue;
    "subject"?: SearchParamValue;
    "type"?: SearchParamValue;
}
/**
 * Typed search parameters for Bundle resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface BundleSearchParams extends CommonSearchParams {
    "composition"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "message"?: SearchParamValue;
    "timestamp"?: SearchParamValue;
    "type"?: SearchParamValue;
}
/**
 * Typed search parameters for Organization resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface OrganizationSearchParams extends CommonSearchParams {
    "active"?: SearchParamValue;
    "address"?: SearchParamValue;
    "address-city"?: SearchParamValue;
    "address-country"?: SearchParamValue;
    "address-postalcode"?: SearchParamValue;
    "address-state"?: SearchParamValue;
    "address-use"?: SearchParamValue;
    "endpoint"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "name"?: SearchParamValue;
    "partof"?: SearchParamValue;
    "phonetic"?: SearchParamValue;
    "type"?: SearchParamValue;
}
/**
 * Typed search parameters for Location resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface LocationSearchParams extends CommonSearchParams {
    "address"?: SearchParamValue;
    "address-city"?: SearchParamValue;
    "address-country"?: SearchParamValue;
    "address-postalcode"?: SearchParamValue;
    "address-state"?: SearchParamValue;
    "address-use"?: SearchParamValue;
    "endpoint"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "name"?: SearchParamValue;
    "near"?: SearchParamValue;
    "operational-status"?: SearchParamValue;
    "organization"?: SearchParamValue;
    "partof"?: SearchParamValue;
    "status"?: SearchParamValue;
    "type"?: SearchParamValue;
}
/**
 * Typed search parameters for MedicationRequest resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface MedicationRequestSearchParams extends CommonSearchParams {
    "authoredon"?: SearchParamValue;
    "category"?: SearchParamValue;
    "code"?: SearchParamValue;
    "date"?: SearchParamValue;
    "encounter"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "intended-dispenser"?: SearchParamValue;
    "intended-performer"?: SearchParamValue;
    "intended-performertype"?: SearchParamValue;
    "intent"?: SearchParamValue;
    "medication"?: SearchParamValue;
    "patient"?: SearchParamValue;
    "priority"?: SearchParamValue;
    "requester"?: SearchParamValue;
    "status"?: SearchParamValue;
    "subject"?: SearchParamValue;
}
/**
 * Typed search parameters for NutritionOrder resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface NutritionOrderSearchParams extends CommonSearchParams {
    "additive"?: SearchParamValue;
    "datetime"?: SearchParamValue;
    "encounter"?: SearchParamValue;
    "formula"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "instantiates-canonical"?: SearchParamValue;
    "instantiates-uri"?: SearchParamValue;
    "oraldiet"?: SearchParamValue;
    "patient"?: SearchParamValue;
    "provider"?: SearchParamValue;
    "status"?: SearchParamValue;
    "supplement"?: SearchParamValue;
}
/**
 * Typed search parameters for Practitioner resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface PractitionerSearchParams extends CommonSearchParams {
    "active"?: SearchParamValue;
    "address"?: SearchParamValue;
    "address-city"?: SearchParamValue;
    "address-country"?: SearchParamValue;
    "address-postalcode"?: SearchParamValue;
    "address-state"?: SearchParamValue;
    "address-use"?: SearchParamValue;
    "communication"?: SearchParamValue;
    "email"?: SearchParamValue;
    "family"?: SearchParamValue;
    "gender"?: SearchParamValue;
    "given"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "name"?: SearchParamValue;
    "phone"?: SearchParamValue;
    "phonetic"?: SearchParamValue;
    "telecom"?: SearchParamValue;
}
/**
 * Typed search parameters for PractitionerRole resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface PractitionerRoleSearchParams extends CommonSearchParams {
    "active"?: SearchParamValue;
    "date"?: SearchParamValue;
    "email"?: SearchParamValue;
    "endpoint"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "location"?: SearchParamValue;
    "organization"?: SearchParamValue;
    "phone"?: SearchParamValue;
    "practitioner"?: SearchParamValue;
    "role"?: SearchParamValue;
    "service"?: SearchParamValue;
    "specialty"?: SearchParamValue;
    "telecom"?: SearchParamValue;
}
/**
 * Typed search parameters for ServiceRequest resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface ServiceRequestSearchParams extends CommonSearchParams {
    "authored"?: SearchParamValue;
    "based-on"?: SearchParamValue;
    "body-site"?: SearchParamValue;
    "category"?: SearchParamValue;
    "code"?: SearchParamValue;
    "encounter"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "instantiates-canonical"?: SearchParamValue;
    "instantiates-uri"?: SearchParamValue;
    "intent"?: SearchParamValue;
    "occurrence"?: SearchParamValue;
    "patient"?: SearchParamValue;
    "performer"?: SearchParamValue;
    "performer-type"?: SearchParamValue;
    "priority"?: SearchParamValue;
    "replaces"?: SearchParamValue;
    "requester"?: SearchParamValue;
    "requisition"?: SearchParamValue;
    "specimen"?: SearchParamValue;
    "status"?: SearchParamValue;
    "subject"?: SearchParamValue;
}
/**
 * Typed search parameters for Task resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface TaskSearchParams extends CommonSearchParams {
    "authored-on"?: SearchParamValue;
    "based-on"?: SearchParamValue;
    "business-status"?: SearchParamValue;
    "code"?: SearchParamValue;
    "encounter"?: SearchParamValue;
    "focus"?: SearchParamValue;
    "group-identifier"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "intent"?: SearchParamValue;
    "modified"?: SearchParamValue;
    "owner"?: SearchParamValue;
    "part-of"?: SearchParamValue;
    "patient"?: SearchParamValue;
    "performer"?: SearchParamValue;
    "period"?: SearchParamValue;
    "priority"?: SearchParamValue;
    "requester"?: SearchParamValue;
    "status"?: SearchParamValue;
    "subject"?: SearchParamValue;
}
