import { FhirReadClient as BaseFhirReadClient, FhirWriteClient as BaseFhirWriteClient, } from "@babelfhir-ts/client-r4";
/**
 * Profile-specific FHIR Read Client.
 * Extends the base R4 read client with typed profile accessors.
 * Inherits all base R4 resource methods from @babelfhir-ts/client-r4.
 */
export class FhirReadClient extends BaseFhirReadClient {
    pASBeneficiary() {
        return this.forType("Patient");
    }
    pASClaim() {
        return this.forType("Claim");
    }
    pASClaimBase() {
        return this.forType("Claim");
    }
    pASClaimInquiry() {
        return this.forType("Claim");
    }
    pASClaimInquiryResponse() {
        return this.forType("ClaimResponse");
    }
    pASClaimResponse() {
        return this.forType("ClaimResponse");
    }
    pASClaimResponseBase() {
        return this.forType("ClaimResponse");
    }
    pASClaimUpdate() {
        return this.forType("Claim");
    }
    pASCommunicationRequest() {
        return this.forType("CommunicationRequest");
    }
    pASCoverage() {
        return this.forType("Coverage");
    }
    pASDeviceRequest() {
        return this.forType("DeviceRequest");
    }
    pASEncounter() {
        return this.forType("Encounter");
    }
    pASInquiryRequestBundle() {
        return this.forType("Bundle");
    }
    pASInquiryResponseBundle() {
        return this.forType("Bundle");
    }
    pASInsurer() {
        return this.forType("Organization");
    }
    pASLocation() {
        return this.forType("Location");
    }
    pASMedicationRequest() {
        return this.forType("MedicationRequest");
    }
    pASNutritionOrder() {
        return this.forType("NutritionOrder");
    }
    pASOrganization() {
        return this.forType("Organization");
    }
    pASPractitioner() {
        return this.forType("Practitioner");
    }
    pASPractitionerRole() {
        return this.forType("PractitionerRole");
    }
    pASRequestBundle() {
        return this.forType("Bundle");
    }
    pASRequestor() {
        return this.forType("Organization");
    }
    pASResponseBundle() {
        return this.forType("Bundle");
    }
    pASServiceRequest() {
        return this.forType("ServiceRequest");
    }
    pASSubscriber() {
        return this.forType("Patient");
    }
    pASTask() {
        return this.forType("Task");
    }
}
/**
 * Profile-specific FHIR Write Client.
 * Extends the base R4 write client with typed profile accessors.
 * Inherits all base R4 resource methods from @babelfhir-ts/client-r4.
 */
export class FhirWriteClient extends BaseFhirWriteClient {
    pASBeneficiary() {
        return this.forType("Patient");
    }
    pASClaim() {
        return this.forType("Claim");
    }
    pASClaimBase() {
        return this.forType("Claim");
    }
    pASClaimInquiry() {
        return this.forType("Claim");
    }
    pASClaimInquiryResponse() {
        return this.forType("ClaimResponse");
    }
    pASClaimResponse() {
        return this.forType("ClaimResponse");
    }
    pASClaimResponseBase() {
        return this.forType("ClaimResponse");
    }
    pASClaimUpdate() {
        return this.forType("Claim");
    }
    pASCommunicationRequest() {
        return this.forType("CommunicationRequest");
    }
    pASCoverage() {
        return this.forType("Coverage");
    }
    pASDeviceRequest() {
        return this.forType("DeviceRequest");
    }
    pASEncounter() {
        return this.forType("Encounter");
    }
    pASInquiryRequestBundle() {
        return this.forType("Bundle");
    }
    pASInquiryResponseBundle() {
        return this.forType("Bundle");
    }
    pASInsurer() {
        return this.forType("Organization");
    }
    pASLocation() {
        return this.forType("Location");
    }
    pASMedicationRequest() {
        return this.forType("MedicationRequest");
    }
    pASNutritionOrder() {
        return this.forType("NutritionOrder");
    }
    pASOrganization() {
        return this.forType("Organization");
    }
    pASPractitioner() {
        return this.forType("Practitioner");
    }
    pASPractitionerRole() {
        return this.forType("PractitionerRole");
    }
    pASRequestBundle() {
        return this.forType("Bundle");
    }
    pASRequestor() {
        return this.forType("Organization");
    }
    pASResponseBundle() {
        return this.forType("Bundle");
    }
    pASServiceRequest() {
        return this.forType("ServiceRequest");
    }
    pASSubscriber() {
        return this.forType("Patient");
    }
    pASTask() {
        return this.forType("Task");
    }
}
/**
 * Main FHIR Client — works with plain fetch or an authenticated fetch wrapper.
 * Provides both base R4 accessors (inherited) and profile-specific accessors.
 *
 * @example
 * // Unauthenticated
 * const client = new FhirClient("https://fhir.example.com");
 *
 * // With custom fetch (e.g. from SmartFhirClient)
 * const client = new FhirClient("https://fhir.example.com", authenticatedFetch);
 *
 * // Base R4 methods (inherited from @babelfhir-ts/client-r4)
 * const pt = await client.read().patient().read("123");
 *
 * // Profile-specific methods (generated)
 * const claim = await client.read().pASClaim().search({ status: "active" });
 */
export class FhirClient {
    constructor(baseUrl, fetchFn) {
        this.baseUrl = baseUrl;
        this.readClient = new FhirReadClient(baseUrl, fetchFn);
        this.writeClient = new FhirWriteClient(baseUrl, fetchFn);
    }
    /**
     * Get a read client for querying resources
     */
    read() {
        return this.readClient;
    }
    /**
     * Get a write client for creating/updating resources
     */
    write() {
        return this.writeClient;
    }
}
