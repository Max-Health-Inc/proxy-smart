import type * as GeneratedTypes from "../index.js";
import type { WithId } from "./types.js";
/**
 * Generic FHIR resource writer
 */
export interface FhirResourceWriter<T> {
    readonly baseUrl: string;
    readonly resourceType: string;
    /**
     * Create a new resource
     */
    create(resource: T): Promise<WithId<T>>;
    /**
     * Update an existing resource
     */
    update(resource: WithId<T>): Promise<WithId<T>>;
    /**
     * Delete a resource
     */
    delete(id: string): Promise<void>;
    /**
     * Create or update (upsert)
     */
    createOrUpdate(resource: T | WithId<T>): Promise<WithId<T>>;
}
/**
 * Specific writer types for type safety
 */
export type PASBeneficiaryWriter = FhirResourceWriter<GeneratedTypes.PASBeneficiary>;
export type PASClaimWriter = FhirResourceWriter<GeneratedTypes.PASClaim>;
export type PASClaimBaseWriter = FhirResourceWriter<GeneratedTypes.PASClaimBase>;
export type PASClaimInquiryWriter = FhirResourceWriter<GeneratedTypes.PASClaimInquiry>;
export type PASClaimInquiryResponseWriter = FhirResourceWriter<GeneratedTypes.PASClaimInquiryResponse>;
export type PASClaimResponseWriter = FhirResourceWriter<GeneratedTypes.PASClaimResponse>;
export type PASClaimResponseBaseWriter = FhirResourceWriter<GeneratedTypes.PASClaimResponseBase>;
export type PASClaimUpdateWriter = FhirResourceWriter<GeneratedTypes.PASClaimUpdate>;
export type PASCommunicationRequestWriter = FhirResourceWriter<GeneratedTypes.PASCommunicationRequest>;
export type PASCoverageWriter = FhirResourceWriter<GeneratedTypes.PASCoverage>;
export type PASDeviceRequestWriter = FhirResourceWriter<GeneratedTypes.PASDeviceRequest>;
export type PASEncounterWriter = FhirResourceWriter<GeneratedTypes.PASEncounter>;
export type PASInquiryRequestBundleWriter = FhirResourceWriter<GeneratedTypes.PASInquiryRequestBundle>;
export type PASInquiryResponseBundleWriter = FhirResourceWriter<GeneratedTypes.PASInquiryResponseBundle>;
export type PASInsurerWriter = FhirResourceWriter<GeneratedTypes.PASInsurer>;
export type PASLocationWriter = FhirResourceWriter<GeneratedTypes.PASLocation>;
export type PASMedicationRequestWriter = FhirResourceWriter<GeneratedTypes.PASMedicationRequest>;
export type PASNutritionOrderWriter = FhirResourceWriter<GeneratedTypes.PASNutritionOrder>;
export type PASOrganizationWriter = FhirResourceWriter<GeneratedTypes.PASOrganization>;
export type PASPractitionerWriter = FhirResourceWriter<GeneratedTypes.PASPractitioner>;
export type PASPractitionerRoleWriter = FhirResourceWriter<GeneratedTypes.PASPractitionerRole>;
export type PASRequestBundleWriter = FhirResourceWriter<GeneratedTypes.PASRequestBundle>;
export type PASRequestorWriter = FhirResourceWriter<GeneratedTypes.PASRequestor>;
export type PASResponseBundleWriter = FhirResourceWriter<GeneratedTypes.PASResponseBundle>;
export type PASServiceRequestWriter = FhirResourceWriter<GeneratedTypes.PASServiceRequest>;
export type PASSubscriberWriter = FhirResourceWriter<GeneratedTypes.PASSubscriber>;
export type PASTaskWriter = FhirResourceWriter<GeneratedTypes.PASTask>;
import type { FetchFn } from "./resource-reader.js";
/**
 * Implementation of FHIR resource writer
 */
export declare class FhirResourceWriterImpl<T> implements FhirResourceWriter<T> {
    readonly baseUrl: string;
    readonly resourceType: string;
    private readonly fetchFn;
    constructor(baseUrl: string, resourceType: string, fetchFn?: FetchFn);
    create(resource: T): Promise<WithId<T>>;
    update(resource: WithId<T>): Promise<WithId<T>>;
    delete(id: string): Promise<void>;
    createOrUpdate(resource: T | WithId<T>): Promise<WithId<T>>;
}
