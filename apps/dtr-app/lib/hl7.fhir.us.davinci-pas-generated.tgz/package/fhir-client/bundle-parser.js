import { BundleParser as BaseBundleParser } from "@babelfhir-ts/client-r4";
/**
 * FHIR Bundle Parser - provides type-safe parsing and filtering of FHIR Bundles
 */
export class BundleParser {
    constructor(bundle) {
        this.bundle = bundle;
    }
    /**
     * Get all resources from the bundle
     */
    getAllResources() {
        return this.bundle.entry?.map(e => e.resource).filter((r) => r !== undefined) || [];
    }
    /**
     * Get resources of a specific type
     */
    getResourcesByType(resourceType) {
        const entries = this.getAllEntries();
        switch (resourceType) {
            case 'Patient':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Patient')
                    .map(e => e.resource);
            case 'Claim':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Claim')
                    .map(e => e.resource);
            case 'ClaimResponse':
                return entries
                    .filter((e) => e.resource?.resourceType === 'ClaimResponse')
                    .map(e => e.resource);
            case 'CommunicationRequest':
                return entries
                    .filter((e) => e.resource?.resourceType === 'CommunicationRequest')
                    .map(e => e.resource);
            case 'Coverage':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Coverage')
                    .map(e => e.resource);
            case 'DeviceRequest':
                return entries
                    .filter((e) => e.resource?.resourceType === 'DeviceRequest')
                    .map(e => e.resource);
            case 'Encounter':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Encounter')
                    .map(e => e.resource);
            case 'Bundle':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Bundle')
                    .map(e => e.resource);
            case 'Organization':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Organization')
                    .map(e => e.resource);
            case 'Location':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Location')
                    .map(e => e.resource);
            case 'MedicationRequest':
                return entries
                    .filter((e) => e.resource?.resourceType === 'MedicationRequest')
                    .map(e => e.resource);
            case 'NutritionOrder':
                return entries
                    .filter((e) => e.resource?.resourceType === 'NutritionOrder')
                    .map(e => e.resource);
            case 'Practitioner':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Practitioner')
                    .map(e => e.resource);
            case 'PractitionerRole':
                return entries
                    .filter((e) => e.resource?.resourceType === 'PractitionerRole')
                    .map(e => e.resource);
            case 'ServiceRequest':
                return entries
                    .filter((e) => e.resource?.resourceType === 'ServiceRequest')
                    .map(e => e.resource);
            case 'Task':
                return entries
                    .filter((e) => e.resource?.resourceType === 'Task')
                    .map(e => e.resource);
            default:
                return [];
        }
    }
    /**
     * Get the first resource of a specific type
     */
    getFirstResourceByType(resourceType) {
        return this.getResourcesByType(resourceType)[0];
    }
    filterResources(predicate) {
        return this.getAllResources().filter(predicate);
    }
    /**
     * Get all entries (including metadata like fullUrl, search scores, etc.)
     */
    getAllEntries() {
        return (this.bundle.entry || []);
    }
    /**
     * Get entries of a specific resource type
     */
    getEntriesByType(resourceType) {
        return this.getAllEntries().filter((e) => e.resource?.resourceType === resourceType);
    }
    /**
     * Get total count from bundle (if available)
     */
    getTotal() {
        return this.bundle.total;
    }
    /**
     * Get next page URL from bundle links
     */
    getNextUrl() {
        return this.bundle.link?.find(l => l.relation === 'next')?.url;
    }
    /**
     * Get previous page URL from bundle links
     */
    getPreviousUrl() {
        return this.bundle.link?.find(l => l.relation === 'previous')?.url;
    }
    /**
     * Check if bundle has more pages
     */
    hasNextPage() {
        return this.getNextUrl() !== undefined;
    }
    /**
     * Group resources by type
     */
    groupByResourceType() {
        const grouped = new Map();
        for (const resource of this.getAllResources()) {
            const type = resource.resourceType;
            if (!grouped.has(type)) {
                grouped.set(type, []);
            }
            grouped.get(type).push(resource);
        }
        return grouped;
    }
    /**
     * Get bundle type
     */
    getBundleType() {
        return this.bundle.type;
    }
    /**
     * Resolve a FHIR reference within this Bundle.
     * Supports "ResourceType/id" relative references and full-URL references
     * matched against entry.fullUrl.
     */
    resolveReference(ref) {
        return BaseBundleParser.resolveReference(ref, this.bundle);
    }
}
/**
 * Parse a FHIR Bundle into a BundleParser instance
 */
export function parseBundle(bundle) {
    return new BundleParser(bundle);
}
