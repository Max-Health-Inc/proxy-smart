import type * as GeneratedTypes from "../index.js";
import type { Bundle, BundleSearchParams, ClaimResponseSearchParams, ClaimSearchParams, CommunicationRequestSearchParams, CoverageSearchParams, DeviceRequestSearchParams, EncounterSearchParams, LocationSearchParams, MedicationRequestSearchParams, NutritionOrderSearchParams, OrganizationSearchParams, PatientSearchParams, PractitionerRoleSearchParams, PractitionerSearchParams, SearchParams, ServiceRequestSearchParams, TaskSearchParams, WithId } from "./types.js";
/**
 * Generic FHIR resource searcher/reader
 */
export interface FhirResourceSearcher<T, S extends SearchParams = SearchParams> {
    readonly baseUrl: string;
    readonly resourceType: string;
    /**
     * Read a resource by ID
     */
    read(id: string): Promise<WithId<T>>;
    /**
     * Search for resources
     */
    search(params?: S): Promise<Bundle<WithId<T>>>;
    /**
     * Search and return first result or undefined
     */
    searchOne(params?: S): Promise<undefined | WithId<T>>;
    /**
     * Search and return all results (handles pagination)
     */
    searchAll(params?: S): Promise<WithId<T>[]>;
}
/**
 * Specific reader types for type safety
 */
export type PASBeneficiaryReader = FhirResourceSearcher<GeneratedTypes.PASBeneficiary, PatientSearchParams>;
export type PASClaimReader = FhirResourceSearcher<GeneratedTypes.PASClaim, ClaimSearchParams>;
export type PASClaimBaseReader = FhirResourceSearcher<GeneratedTypes.PASClaimBase, ClaimSearchParams>;
export type PASClaimInquiryReader = FhirResourceSearcher<GeneratedTypes.PASClaimInquiry, ClaimSearchParams>;
export type PASClaimInquiryResponseReader = FhirResourceSearcher<GeneratedTypes.PASClaimInquiryResponse, ClaimResponseSearchParams>;
export type PASClaimResponseReader = FhirResourceSearcher<GeneratedTypes.PASClaimResponse, ClaimResponseSearchParams>;
export type PASClaimResponseBaseReader = FhirResourceSearcher<GeneratedTypes.PASClaimResponseBase, ClaimResponseSearchParams>;
export type PASClaimUpdateReader = FhirResourceSearcher<GeneratedTypes.PASClaimUpdate, ClaimSearchParams>;
export type PASCommunicationRequestReader = FhirResourceSearcher<GeneratedTypes.PASCommunicationRequest, CommunicationRequestSearchParams>;
export type PASCoverageReader = FhirResourceSearcher<GeneratedTypes.PASCoverage, CoverageSearchParams>;
export type PASDeviceRequestReader = FhirResourceSearcher<GeneratedTypes.PASDeviceRequest, DeviceRequestSearchParams>;
export type PASEncounterReader = FhirResourceSearcher<GeneratedTypes.PASEncounter, EncounterSearchParams>;
export type PASInquiryRequestBundleReader = FhirResourceSearcher<GeneratedTypes.PASInquiryRequestBundle, BundleSearchParams>;
export type PASInquiryResponseBundleReader = FhirResourceSearcher<GeneratedTypes.PASInquiryResponseBundle, BundleSearchParams>;
export type PASInsurerReader = FhirResourceSearcher<GeneratedTypes.PASInsurer, OrganizationSearchParams>;
export type PASLocationReader = FhirResourceSearcher<GeneratedTypes.PASLocation, LocationSearchParams>;
export type PASMedicationRequestReader = FhirResourceSearcher<GeneratedTypes.PASMedicationRequest, MedicationRequestSearchParams>;
export type PASNutritionOrderReader = FhirResourceSearcher<GeneratedTypes.PASNutritionOrder, NutritionOrderSearchParams>;
export type PASOrganizationReader = FhirResourceSearcher<GeneratedTypes.PASOrganization, OrganizationSearchParams>;
export type PASPractitionerReader = FhirResourceSearcher<GeneratedTypes.PASPractitioner, PractitionerSearchParams>;
export type PASPractitionerRoleReader = FhirResourceSearcher<GeneratedTypes.PASPractitionerRole, PractitionerRoleSearchParams>;
export type PASRequestBundleReader = FhirResourceSearcher<GeneratedTypes.PASRequestBundle, BundleSearchParams>;
export type PASRequestorReader = FhirResourceSearcher<GeneratedTypes.PASRequestor, OrganizationSearchParams>;
export type PASResponseBundleReader = FhirResourceSearcher<GeneratedTypes.PASResponseBundle, BundleSearchParams>;
export type PASServiceRequestReader = FhirResourceSearcher<GeneratedTypes.PASServiceRequest, ServiceRequestSearchParams>;
export type PASSubscriberReader = FhirResourceSearcher<GeneratedTypes.PASSubscriber, PatientSearchParams>;
export type PASTaskReader = FhirResourceSearcher<GeneratedTypes.PASTask, TaskSearchParams>;
/**
 * Custom fetch function type for injecting auth headers
 */
export type FetchFn = typeof globalThis.fetch;
/**
 * Implementation of FHIR resource reader
 */
export declare class FhirResourceReader<T, S extends SearchParams = SearchParams> implements FhirResourceSearcher<T, S> {
    readonly baseUrl: string;
    readonly resourceType: string;
    private readonly fetchFn;
    constructor(baseUrl: string, resourceType: string, fetchFn?: FetchFn);
    read(id: string): Promise<WithId<T>>;
    search(params?: S): Promise<Bundle<WithId<T>>>;
    searchOne(params?: S): Promise<undefined | WithId<T>>;
    searchAll(params?: S): Promise<WithId<T>[]>;
}
