import type * as GeneratedTypes from "../index.js";
import type { Bundle, SearchParams, WithId } from "./types.js";
/**
 * Generic FHIR resource searcher/reader
 */
export interface FhirResourceSearcher<T> {
    readonly baseUrl: string;
    readonly resourceType: string;
    /**
     * Read a resource by ID
     */
    read(id: string): Promise<WithId<T>>;
    /**
     * Search for resources
     */
    search(params?: SearchParams): Promise<Bundle<WithId<T>>>;
    /**
     * Search and return first result or undefined
     */
    searchOne(params?: SearchParams): Promise<undefined | WithId<T>>;
    /**
     * Search and return all results (handles pagination)
     */
    searchAll(params?: SearchParams): Promise<WithId<T>[]>;
}
/**
 * Specific reader types for type safety
 */
export type PASBeneficiaryReader = FhirResourceSearcher<GeneratedTypes.PASBeneficiary>;
export type PASClaimReader = FhirResourceSearcher<GeneratedTypes.PASClaim>;
export type PASClaimBaseReader = FhirResourceSearcher<GeneratedTypes.PASClaimBase>;
export type PASClaimInquiryReader = FhirResourceSearcher<GeneratedTypes.PASClaimInquiry>;
export type PASClaimInquiryResponseReader = FhirResourceSearcher<GeneratedTypes.PASClaimInquiryResponse>;
export type PASClaimResponseReader = FhirResourceSearcher<GeneratedTypes.PASClaimResponse>;
export type PASClaimResponseBaseReader = FhirResourceSearcher<GeneratedTypes.PASClaimResponseBase>;
export type PASClaimUpdateReader = FhirResourceSearcher<GeneratedTypes.PASClaimUpdate>;
export type PASCommunicationRequestReader = FhirResourceSearcher<GeneratedTypes.PASCommunicationRequest>;
export type PASCoverageReader = FhirResourceSearcher<GeneratedTypes.PASCoverage>;
export type PASDeviceRequestReader = FhirResourceSearcher<GeneratedTypes.PASDeviceRequest>;
export type PASEncounterReader = FhirResourceSearcher<GeneratedTypes.PASEncounter>;
export type PASInquiryRequestBundleReader = FhirResourceSearcher<GeneratedTypes.PASInquiryRequestBundle>;
export type PASInquiryResponseBundleReader = FhirResourceSearcher<GeneratedTypes.PASInquiryResponseBundle>;
export type PASInsurerReader = FhirResourceSearcher<GeneratedTypes.PASInsurer>;
export type PASLocationReader = FhirResourceSearcher<GeneratedTypes.PASLocation>;
export type PASMedicationRequestReader = FhirResourceSearcher<GeneratedTypes.PASMedicationRequest>;
export type PASNutritionOrderReader = FhirResourceSearcher<GeneratedTypes.PASNutritionOrder>;
export type PASOrganizationReader = FhirResourceSearcher<GeneratedTypes.PASOrganization>;
export type PASPractitionerReader = FhirResourceSearcher<GeneratedTypes.PASPractitioner>;
export type PASPractitionerRoleReader = FhirResourceSearcher<GeneratedTypes.PASPractitionerRole>;
export type PASRequestBundleReader = FhirResourceSearcher<GeneratedTypes.PASRequestBundle>;
export type PASRequestorReader = FhirResourceSearcher<GeneratedTypes.PASRequestor>;
export type PASResponseBundleReader = FhirResourceSearcher<GeneratedTypes.PASResponseBundle>;
export type PASServiceRequestReader = FhirResourceSearcher<GeneratedTypes.PASServiceRequest>;
export type PASSubscriberReader = FhirResourceSearcher<GeneratedTypes.PASSubscriber>;
export type PASTaskReader = FhirResourceSearcher<GeneratedTypes.PASTask>;
/**
 * Custom fetch function type for injecting auth headers
 */
export type FetchFn = typeof globalThis.fetch;
/**
 * Implementation of FHIR resource reader
 */
export declare class FhirResourceReader<T> implements FhirResourceSearcher<T> {
    readonly baseUrl: string;
    readonly resourceType: string;
    private readonly fetchFn;
    constructor(baseUrl: string, resourceType: string, fetchFn?: FetchFn);
    read(id: string): Promise<WithId<T>>;
    search(params?: SearchParams): Promise<Bundle<WithId<T>>>;
    searchOne(params?: SearchParams): Promise<undefined | WithId<T>>;
    searchAll(params?: SearchParams): Promise<WithId<T>[]>;
}
