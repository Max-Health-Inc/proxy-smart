import { FhirReadClient as BaseFhirReadClient, FhirWriteClient as BaseFhirWriteClient, type FetchFn } from "@babelfhir-ts/client-r4";
import type * as GeneratedTypes from "../index.js";
/**
 * Profile-specific FHIR Read Client.
 * Extends the base R4 read client with typed profile accessors.
 * Inherits all base R4 resource methods from @babelfhir-ts/client-r4.
 */
export declare class FhirReadClient extends BaseFhirReadClient {
    pASBeneficiary(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASBeneficiary>;
    pASClaim(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASClaim>;
    pASClaimBase(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASClaimBase>;
    pASClaimInquiry(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASClaimInquiry>;
    pASClaimInquiryResponse(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASClaimInquiryResponse>;
    pASClaimResponse(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASClaimResponse>;
    pASClaimResponseBase(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASClaimResponseBase>;
    pASClaimUpdate(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASClaimUpdate>;
    pASCommunicationRequest(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASCommunicationRequest>;
    pASCoverage(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASCoverage>;
    pASDeviceRequest(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASDeviceRequest>;
    pASEncounter(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASEncounter>;
    pASInquiryRequestBundle(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASInquiryRequestBundle>;
    pASInquiryResponseBundle(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASInquiryResponseBundle>;
    pASInsurer(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASInsurer>;
    pASLocation(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASLocation>;
    pASMedicationRequest(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASMedicationRequest>;
    pASNutritionOrder(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASNutritionOrder>;
    pASOrganization(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASOrganization>;
    pASPractitioner(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASPractitioner>;
    pASPractitionerRole(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASPractitionerRole>;
    pASRequestBundle(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASRequestBundle>;
    pASRequestor(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASRequestor>;
    pASResponseBundle(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASResponseBundle>;
    pASServiceRequest(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASServiceRequest>;
    pASSubscriber(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASSubscriber>;
    pASTask(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.PASTask>;
}
/**
 * Profile-specific FHIR Write Client.
 * Extends the base R4 write client with typed profile accessors.
 * Inherits all base R4 resource methods from @babelfhir-ts/client-r4.
 */
export declare class FhirWriteClient extends BaseFhirWriteClient {
    pASBeneficiary(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASBeneficiary>;
    pASClaim(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASClaim>;
    pASClaimBase(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASClaimBase>;
    pASClaimInquiry(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASClaimInquiry>;
    pASClaimInquiryResponse(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASClaimInquiryResponse>;
    pASClaimResponse(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASClaimResponse>;
    pASClaimResponseBase(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASClaimResponseBase>;
    pASClaimUpdate(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASClaimUpdate>;
    pASCommunicationRequest(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASCommunicationRequest>;
    pASCoverage(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASCoverage>;
    pASDeviceRequest(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASDeviceRequest>;
    pASEncounter(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASEncounter>;
    pASInquiryRequestBundle(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASInquiryRequestBundle>;
    pASInquiryResponseBundle(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASInquiryResponseBundle>;
    pASInsurer(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASInsurer>;
    pASLocation(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASLocation>;
    pASMedicationRequest(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASMedicationRequest>;
    pASNutritionOrder(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASNutritionOrder>;
    pASOrganization(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASOrganization>;
    pASPractitioner(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASPractitioner>;
    pASPractitionerRole(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASPractitionerRole>;
    pASRequestBundle(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASRequestBundle>;
    pASRequestor(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASRequestor>;
    pASResponseBundle(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASResponseBundle>;
    pASServiceRequest(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASServiceRequest>;
    pASSubscriber(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASSubscriber>;
    pASTask(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.PASTask>;
}
/**
 * Main FHIR Client — works with plain fetch or an authenticated fetch wrapper.
 * Provides both base R4 accessors (inherited) and profile-specific accessors.
 *
 * @example
 * // Unauthenticated
 * const client = new FhirClient("https://fhir.example.com");
 *
 * // With custom fetch (e.g. from SmartFhirClient)
 * const client = new FhirClient("https://fhir.example.com", authenticatedFetch);
 *
 * // Base R4 methods (inherited from @babelfhir-ts/client-r4)
 * const pt = await client.read().patient().read("123");
 *
 * // Profile-specific methods (generated)
 * const claim = await client.read().pASClaim().search({ status: "active" });
 */
export declare class FhirClient {
    readonly baseUrl: string;
    private readonly readClient;
    private readonly writeClient;
    constructor(baseUrl: string, fetchFn?: FetchFn);
    /**
     * Get a read client for querying resources
     */
    read(): FhirReadClient;
    /**
     * Get a write client for creating/updating resources
     */
    write(): FhirWriteClient;
}
