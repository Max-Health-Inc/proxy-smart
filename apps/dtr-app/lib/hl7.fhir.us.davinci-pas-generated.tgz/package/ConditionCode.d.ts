import { Extension } from "fhir/r4";
export interface ConditionCode extends Omit<Extension, 'extension' | 'url'> {
    extension: Extension[];
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-conditionCode";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateConditionCode(resource: ConditionCode, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
