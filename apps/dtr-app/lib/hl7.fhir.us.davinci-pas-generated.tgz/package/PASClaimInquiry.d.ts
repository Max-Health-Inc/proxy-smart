import { ClaimCareteamroleCode } from "./valuesets/ValueSet-ClaimCareteamrole";
import { ProviderQualificationCode } from "./valuesets/ValueSet-ProviderQualification";
import { X12278RequestedServiceTypeCode } from "./valuesets/ValueSet-X12278RequestedServiceType";
import { AdministrationReferenceNumber } from "./AdministrationReferenceNumber";
import { AuthorizationNumber } from "./AuthorizationNumber";
import { CareTeamClaimScope } from "./CareTeamClaimScope";
import { CertificationEffectiveDate } from "./CertificationEffectiveDate";
import { CertificationExpirationDate } from "./CertificationExpirationDate";
import { CertificationIssueDate } from "./CertificationIssueDate";
import { CertificationType } from "./CertificationType";
import { ConditionCode } from "./ConditionCode";
import { HomeHealthCareInformation } from "./HomeHealthCareInformation";
import { ItemTraceNumber } from "./ItemTraceNumber";
import { LevelOfServiceCode } from "./LevelOfServiceCode";
import { Claim, ClaimCareTeam, ClaimItem, CodeableConcept, Extension, Period, Reference, SimpleQuantity } from "fhir/r4";
import { ProductOrServiceCodeEnd } from "./ProductOrServiceCodeEnd";
import { ReviewActionCode } from "./ReviewActionCode";
import { ServiceItemRequestType } from "./ServiceItemRequestType";
export interface ExtensionReviewActionCode extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-reviewActionCode';
}
export interface ExtensionItemCertificationEffectiveDate extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemCertificationEffectiveDate';
}
export interface ExtensionItemCertificationExpirationDate extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemCertificationExpirationDate';
}
export interface ExtensionItemCertificationIssueDate extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemCertificationIssueDate';
}
export interface ExtensionProductOrServiceCodeEnd extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-productOrServiceCodeEnd';
}
export interface ExtensionCertificationType extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-certificationType';
}
export interface ExtensionServiceItemRequestType extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-serviceItemRequestType';
}
export interface ExtensionAdministrationReferenceNumber extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-administrationReferenceNumber';
}
export interface ExtensionAuthorizationNumber extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-authorizationNumber';
}
export interface ExtensionItemTraceNumber extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemTraceNumber';
}
export interface ExtensionCareTeamClaimScope extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-careTeamClaimScope';
}
export interface PASClaimInquiryCareTeam extends Omit<ClaimCareTeam, 'provider' | 'role' | 'qualification' | 'extension'> {
    /** Must Support */
    provider: Reference;
    /** Must Support | @see {@link ./valuesets/ValueSet-ClaimCareteamrole.ts} for valid codes (4 codes) */
    role?: CodeableConcept & {
        coding: Array<{
            code: ClaimCareteamroleCode;
            system: "http://terminology.hl7.org/CodeSystem/claimcareteamrole";
        }>;
    };
    /** Must Support | @see {@link ./valuesets/ValueSet-ProviderQualification.ts} for valid codes (3 codes) */
    qualification?: CodeableConcept & {
        coding: Array<{
            code: ProviderQualificationCode;
            system: "http://terminology.hl7.org/CodeSystem/ex-providerqualification";
        }>;
    };
    extension?: (Extension | CareTeamClaimScope | CareTeamClaimScope | CareTeamClaimScope)[];
}
export interface PASClaimInquiryItem extends Omit<ClaimItem, 'revenue' | 'productOrService' | 'modifier' | 'quantity' | 'extension'> {
    /** Must Support */
    revenue?: CodeableConcept;
    /** Must Support | @see {@link ./valuesets/ValueSet-X12278RequestedServiceType.ts} for valid codes (1 codes) */
    productOrService: CodeableConcept & {
        coding: Array<{
            code: X12278RequestedServiceTypeCode;
            system: "http://terminology.hl7.org/CodeSystem/data-absent-reason";
        }>;
    };
    /** Must Support */
    modifier?: CodeableConcept[];
    /** Must Support */
    quantity?: SimpleQuantity;
    extension?: (Extension | ItemTraceNumber | AuthorizationNumber | AdministrationReferenceNumber | ServiceItemRequestType | CertificationType | ProductOrServiceCodeEnd | CertificationIssueDate | CertificationExpirationDate | CertificationEffectiveDate | ReviewActionCode)[];
}
export interface PASClaimInquiry extends Omit<Claim, 'status' | 'use' | 'billablePeriod' | 'careTeam' | 'item' | 'extension'> {
    resourceType: 'Claim';
    status: "active";
    use: "preauthorization";
    /** Must Support */
    billablePeriod?: Period;
    /** Must Support */
    careTeam?: PASClaimInquiryCareTeam[];
    /** Must Support */
    item: PASClaimInquiryItem[];
    extension?: (Extension | LevelOfServiceCode | ConditionCode | HomeHealthCareInformation | CertificationType)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASClaimInquiry(resource: PASClaimInquiry, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
