import { Extension } from "fhir/r4";
export interface LevelOfServiceCode extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-levelOfServiceCode";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateLevelOfServiceCode(resource: LevelOfServiceCode, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
