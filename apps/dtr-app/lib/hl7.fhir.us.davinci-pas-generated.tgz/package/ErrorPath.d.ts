import { Extension } from "fhir/r4";
export interface ErrorPath extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-errorPath";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateErrorPath(resource: ErrorPath, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
