import { MilitaryStatus } from "./MilitaryStatus";
import { USCoreBirthSexExtension } from "./USCoreBirthSexExtension";
import { USCoreEthnicityExtension } from "./USCoreEthnicityExtension";
import { USCoreRaceExtension } from "./USCoreRaceExtension";
import { ContactPoint, Extension, Patient, PatientCommunication } from "fhir/r4";
export interface PASSubscriber extends Omit<Patient, 'telecom' | 'communication' | 'extension'> {
    resourceType: 'Patient';
    /** Must Support */
    telecom?: ContactPoint[];
    /** Must Support */
    communication?: PatientCommunication[];
    extension?: (Extension | USCoreRaceExtension | USCoreEthnicityExtension | USCoreBirthSexExtension | MilitaryStatus)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASSubscriber(resource: PASSubscriber, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
