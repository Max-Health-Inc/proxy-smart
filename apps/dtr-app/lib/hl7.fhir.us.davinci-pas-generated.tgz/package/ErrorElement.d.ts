import { Extension } from "fhir/r4";
export interface ErrorElement extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-errorElement";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateErrorElement(resource: ErrorElement, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
