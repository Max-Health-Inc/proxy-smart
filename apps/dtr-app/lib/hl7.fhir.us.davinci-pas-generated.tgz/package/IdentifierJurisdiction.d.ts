import { Extension } from "fhir/r4";
export interface IdentifierJurisdiction extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-identifierJurisdiction";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateIdentifierJurisdiction(resource: IdentifierJurisdiction, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
