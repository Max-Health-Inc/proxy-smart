import { Extension } from "fhir/r4";
export interface RevenueUnitRateLimit extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-revenueUnitRateLimit";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateRevenueUnitRateLimit(resource: RevenueUnitRateLimit, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
