import { Extension } from "fhir/r4";
export interface CareTeamClaimScope extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-careTeamClaimScope";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateCareTeamClaimScope(resource: CareTeamClaimScope, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
