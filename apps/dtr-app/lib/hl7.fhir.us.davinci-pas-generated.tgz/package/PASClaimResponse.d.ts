import { AdministrationReferenceNumber } from "./AdministrationReferenceNumber";
import { AuthorizationNumber } from "./AuthorizationNumber";
import { CommunicatedDiagnosis } from "./CommunicatedDiagnosis";
import { ErrorElement } from "./ErrorElement";
import { ErrorFollowupAction } from "./ErrorFollowupAction";
import { ErrorPath } from "./ErrorPath";
import { ItemAuthorizedDetail } from "./ItemAuthorizedDetail";
import { ItemAuthorizedProvider } from "./ItemAuthorizedProvider";
import { ItemPreAuthIssueDate } from "./ItemPreAuthIssueDate";
import { ItemPreAuthPeriod } from "./ItemPreAuthPeriod";
import { ItemRequestedServiceDate } from "./ItemRequestedServiceDate";
import { ItemTraceNumber } from "./ItemTraceNumber";
import { ClaimResponse, ClaimResponseError, ClaimResponseItem, ClaimResponseItemAdjudication, CodeableConcept, Coding, Extension, Reference } from "fhir/r4";
import { ReviewAction } from "./ReviewAction";
export interface ExtensionErrorPath extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-errorPath';
}
export interface ExtensionErrorElement extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-errorElement';
}
export interface ExtensionErrorFollowupAction extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-errorFollowupAction';
}
export interface ExtensionCommunicatedDiagnosis extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-communicatedDiagnosis';
}
export interface ExtensionItemAuthorizedProvider extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemAuthorizedProvider';
}
export interface ExtensionItemAuthorizedDetail extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemAuthorizedDetail';
}
export interface ExtensionItemRequestedServiceDate extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemRequestedServiceDate';
}
export interface ExtensionAdministrationReferenceNumber extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-administrationReferenceNumber';
}
export interface ExtensionAuthorizationNumber extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-authorizationNumber';
}
export interface ExtensionItemPreAuthPeriod extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemPreAuthPeriod';
}
export interface ExtensionItemPreAuthIssueDate extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemPreAuthIssueDate';
}
export interface ExtensionItemTraceNumber extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemTraceNumber';
}
export interface ExtensionReviewAction extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-reviewAction';
}
export interface PASClaimResponseItemAdjudicationCategoryCoding extends Omit<Coding, 'system' | 'code'> {
    system: "http://terminology.hl7.org/CodeSystem/adjudication";
    code: "submitted";
}
export interface PASClaimResponseItemAdjudication extends Omit<ClaimResponseItemAdjudication, 'category' | 'extension'> {
    category: {
        coding: PASClaimResponseItemAdjudicationCategoryCoding[];
    };
    extension?: (Extension | ReviewAction)[];
}
export interface PASClaimResponseItem extends Omit<ClaimResponseItem, 'adjudication' | 'extension'> {
    /** Must Support */
    adjudication: PASClaimResponseItemAdjudication[];
    extension?: (Extension | ItemTraceNumber | ItemPreAuthIssueDate | ItemPreAuthPeriod | AuthorizationNumber | AdministrationReferenceNumber | ItemRequestedServiceDate | ItemAuthorizedDetail | ItemAuthorizedProvider | CommunicatedDiagnosis)[];
}
export interface PASClaimResponseError extends Omit<ClaimResponseError, 'code' | 'extension'> {
    /** Must Support */
    code: CodeableConcept;
    extension?: (Extension | ErrorFollowupAction | ErrorElement | ErrorPath)[];
}
export interface PASClaimResponse extends Omit<ClaimResponse, 'status' | 'use' | 'item' | 'communicationRequest' | 'error'> {
    status: "active";
    use: "preauthorization";
    /** Must Support */
    item?: PASClaimResponseItem[];
    /** Must Support */
    communicationRequest?: Reference[];
    /** Must Support */
    error?: PASClaimResponseError[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASClaimResponse(resource: PASClaimResponse, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
