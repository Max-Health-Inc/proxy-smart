import { Extension } from "fhir/r4";
export interface ItemPreAuthIssueDate extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemPreAuthIssueDate";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateItemPreAuthIssueDate(resource: ItemPreAuthIssueDate, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
