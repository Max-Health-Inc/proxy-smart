import { Extension } from "fhir/r4";
export interface PatientStatus extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-patientStatus";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePatientStatus(resource: PatientStatus, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
