import { Extension } from "fhir/r4";
export interface ItemRequestedServiceDate extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemRequestedServiceDate";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateItemRequestedServiceDate(resource: ItemRequestedServiceDate, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
