import fhirpath from "fhirpath";
import fhirpath_model from "fhirpath/fhir-context/r4/index.js";
import { isValidMetricDataSourceCode } from './valuesets/ValueSet-MetricDataSource.js';
import { isValidIssueTypeCode } from './valuesets/ValueSet-IssueType.js';
export async function validatePASMetricData(resource, options) {
    const errors = [];
    const warnings = [];
    const fhirpathOptions = {
        preciseMath: true,
        traceFn: options?.traceFn ?? (() => { }),
        ...(options?.signal ? { signal: options.signal } : {}),
        ...(options?.httpHeaders ? { httpHeaders: options.httpHeaders } : {}),
    };
    const result0 = await fhirpath.evaluate(resource, "providerId.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result0.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result1 = await fhirpath.evaluate(resource, "groupId.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result1.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result2 = await fhirpath.evaluate(resource, "payerId.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result2.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result3 = await fhirpath.evaluate(resource, "exchange.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result3.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result4 = await fhirpath.evaluate(resource, "issue.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result4.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result5 = await fhirpath.evaluate(resource, "aaaCodes.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result5.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result6 = await fhirpath.evaluate(resource, "itemDetail.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result6.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result7 = await fhirpath.evaluate(resource, "requestedDoc.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result7.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result8 = await fhirpath.evaluate(resource, "source.exists()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result8.every(Boolean)) {
        errors.push("Constraint violation: source must be present");
    }
    const result9 = await fhirpath.evaluate(resource, "providerId.exists()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result9.every(Boolean)) {
        errors.push("Constraint violation: providerId must be present");
    }
    const result10 = await fhirpath.evaluate(resource, "groupId.exists()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result10.every(Boolean)) {
        errors.push("Constraint violation: groupId must be present");
    }
    const result11 = await fhirpath.evaluate(resource, "payerId.exists()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result11.every(Boolean)) {
        errors.push("Constraint violation: payerId must be present");
    }
    const result12 = await fhirpath.evaluate(resource, "exchange.count() >= 1", { resource }, fhirpath_model, fhirpathOptions);
    if (!result12.every(Boolean)) {
        errors.push("Constraint violation: exchange must contain at least one element");
    }
    // Nested required field: exchange.type (min=1)
    if (resource.exchange && Array.isArray(resource.exchange)) {
        for (const _el of resource.exchange) {
            if ((_el.type === undefined || _el.type === null) || Array.isArray(_el.type)) {
                errors.push("Missing required member: 'type'");
            }
        }
    }
    // Nested required field: exchange.method (min=1)
    if (resource.exchange && Array.isArray(resource.exchange)) {
        for (const _el of resource.exchange) {
            if ((_el.method === undefined || _el.method === null) || Array.isArray(_el.method)) {
                errors.push("Missing required member: 'method'");
            }
        }
    }
    // Nested required field: exchange.requestTime (min=1)
    if (resource.exchange && Array.isArray(resource.exchange)) {
        for (const _el of resource.exchange) {
            if ((_el.requestTime === undefined || _el.requestTime === null) || Array.isArray(_el.requestTime)) {
                errors.push("Missing required member: 'requestTime'");
            }
        }
    }
    // Nested required field: exchange.httpResponse (min=1)
    if (resource.exchange && Array.isArray(resource.exchange)) {
        for (const _el of resource.exchange) {
            if ((_el.httpResponse === undefined || _el.httpResponse === null) || Array.isArray(_el.httpResponse)) {
                errors.push("Missing required member: 'httpResponse'");
            }
        }
    }
    // Nested required field: issue.code (min=1)
    if (resource.issue && Array.isArray(resource.issue)) {
        for (const _el of resource.issue) {
            if ((_el.code === undefined || _el.code === null) || Array.isArray(_el.code)) {
                errors.push("Missing required member: 'code'");
            }
        }
    }
    // Nested required field: aaaCodes.loopID (min=1)
    if (resource.aaaCodes && Array.isArray(resource.aaaCodes)) {
        for (const _el of resource.aaaCodes) {
            if ((_el.loopID === undefined || _el.loopID === null) || Array.isArray(_el.loopID)) {
                errors.push("Missing required member: 'loopID'");
            }
        }
    }
    // Nested required field: aaaCodes.aaaCode (min=1)
    if (resource.aaaCodes && Array.isArray(resource.aaaCodes)) {
        for (const _el of resource.aaaCodes) {
            if ((_el.aaaCode === undefined || _el.aaaCode === null) || Array.isArray(_el.aaaCode)) {
                errors.push("Missing required member: 'aaaCode'");
            }
        }
    }
    // Nested required field: itemDetail.item (min=1)
    if (resource.itemDetail && Array.isArray(resource.itemDetail)) {
        for (const _el of resource.itemDetail) {
            if ((_el.item === undefined || _el.item === null) || Array.isArray(_el.item)) {
                errors.push("Missing required member: 'item'");
            }
        }
    }
    // Nested required field: itemDetail.aaaCodes.loopID (min=1)
    if (resource.itemDetail && Array.isArray(resource.itemDetail)) {
        for (const _nrEl0 of resource.itemDetail) {
            if (_nrEl0.aaaCodes && Array.isArray(_nrEl0.aaaCodes)) {
                for (const _nrEl1 of _nrEl0.aaaCodes) {
                    if ((_nrEl1.loopID === undefined || _nrEl1.loopID === null) || Array.isArray(_nrEl1.loopID)) {
                        errors.push("Missing required member: 'loopID'");
                    }
                }
            }
        }
    }
    // Nested required field: itemDetail.aaaCodes.aaaCode (min=1)
    if (resource.itemDetail && Array.isArray(resource.itemDetail)) {
        for (const _nrEl0 of resource.itemDetail) {
            if (_nrEl0.aaaCodes && Array.isArray(_nrEl0.aaaCodes)) {
                for (const _nrEl1 of _nrEl0.aaaCodes) {
                    if ((_nrEl1.aaaCode === undefined || _nrEl1.aaaCode === null) || Array.isArray(_nrEl1.aaaCode)) {
                        errors.push("Missing required member: 'aaaCode'");
                    }
                }
            }
        }
    }
    // Nested required field: requestedDoc.docRequest (min=1)
    if (resource.requestedDoc && Array.isArray(resource.requestedDoc)) {
        for (const _el of resource.requestedDoc) {
            if (!_el.docRequest || _el.docRequest.length === 0) {
                errors.push("Missing required member: 'docRequest'");
            }
        }
    }
    // Nested required field: requestedDoc.timeRequested (min=1)
    if (resource.requestedDoc && Array.isArray(resource.requestedDoc)) {
        for (const _el of resource.requestedDoc) {
            if ((_el.timeRequested === undefined || _el.timeRequested === null) || Array.isArray(_el.timeRequested)) {
                errors.push("Missing required member: 'timeRequested'");
            }
        }
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const _bRes = resource;
    // Required ValueSet binding validation for source
    if (_bRes.source !== undefined && !isValidMetricDataSourceCode(_bRes.source)) {
        errors.push("Code '" + _bRes.source + "' does not exist in the value set 'MetricDataSource' (http://hl7.org/fhir/us/davinci-pas/ValueSet/MetricDataSource), but the binding is of strength 'required'");
    }
    // Required ValueSet binding validation for issue.code (nested)
    if (resource.issue && Array.isArray(resource.issue)) {
        for (const _nb0 of resource.issue) {
            if (_nb0.code !== undefined && !isValidIssueTypeCode(_nb0.code)) {
                errors.push("Code '" + _nb0.code + "' does not exist in the value set 'issue-type' (http://hl7.org/fhir/ValueSet/issue-type), but the binding is of strength 'required'");
            }
        }
    }
    // Base FHIR structural validation: extension.url required, ext-1 constraint, empty objects
    {
        const _checkExtensions = (obj, path, depth) => {
            if (!obj || typeof obj !== 'object')
                return;
            if (Array.isArray(obj)) {
                obj.forEach((item, i) => _checkExtensions(item, path + '[' + i + ']', depth + 1));
                return;
            }
            const rec = obj;
            // Empty object check — HL7 validates all FHIR elements must have content
            if (depth > 0 && Object.keys(rec).length === 0) {
                errors.push('Object must have some content');
            }
            // per-1: If present, start SHALL have a lower value than end (Period structural check)
            if (typeof rec.start === 'string' && typeof rec.end === 'string' && rec.start > rec.end) {
                errors.push('If present, start SHALL have a lower value than end');
            }
            // Validate extension arrays
            for (const extKey of ['extension', 'modifierExtension']) {
                const exts = rec[extKey];
                if (Array.isArray(exts)) {
                    for (const ext of exts) {
                        if (ext && typeof ext === 'object' && !Array.isArray(ext)) {
                            const e = ext;
                            if (typeof e.url !== 'string' || !e.url) {
                                errors.push('Extension.url is required in order to identify, use and validate the extension');
                            }
                            // ext-1: Must have either extensions or value[x], not both
                            const hasNestedExt = Array.isArray(e.extension) && e.extension.length > 0;
                            const hasValue = Object.keys(e).some(k => k.startsWith('value') && k !== 'value' && k.length > 5);
                            if (hasNestedExt && hasValue) {
                                errors.push('Must have either extensions or value[x], not both');
                            }
                        }
                    }
                }
            }
            // Recurse into child objects (skip primitive values)
            for (const [_key, _val] of Object.entries(rec)) {
                if (_val && typeof _val === 'object') {
                    _checkExtensions(_val, path + '.' + _key, depth + 1);
                }
            }
        };
        _checkExtensions(resource, '', 0);
    }
    // Standalone contained reference resolution: verify #id references resolve to contained[] entries
    {
        const _res = resource;
        const _containedIds = new Set();
        if (Array.isArray(_res.contained)) {
            for (const _c of _res.contained) {
                if (_c && typeof _c.id === 'string')
                    _containedIds.add(_c.id);
            }
        }
        const _checkContainedRef = (obj) => {
            if (!obj || typeof obj !== 'object')
                return;
            if (Array.isArray(obj)) {
                obj.forEach(_checkContainedRef);
                return;
            }
            const _rec = obj;
            if (typeof _rec.reference === 'string') {
                const _ref = _rec.reference;
                if (_ref.startsWith('#')) {
                    const _id = _ref.substring(1);
                    if (_id && !_containedIds.has(_id)) {
                        errors.push('Contained reference not found: ' + _ref);
                    }
                }
            }
            for (const [_k, _v] of Object.entries(_rec)) {
                if (_k !== 'contained')
                    _checkContainedRef(_v);
            }
        };
        _checkContainedRef(_res);
    }
    return { errors, warnings };
}
