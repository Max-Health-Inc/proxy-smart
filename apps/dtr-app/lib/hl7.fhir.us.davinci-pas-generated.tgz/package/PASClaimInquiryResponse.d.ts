import { AdministrationReferenceNumber } from "./AdministrationReferenceNumber";
import { AuthorizationNumber } from "./AuthorizationNumber";
import { CommunicatedDiagnosis } from "./CommunicatedDiagnosis";
import { ErrorElement } from "./ErrorElement";
import { ErrorFollowupAction } from "./ErrorFollowupAction";
import { ErrorPath } from "./ErrorPath";
import { ItemAuthorizedDetail } from "./ItemAuthorizedDetail";
import { ItemAuthorizedProvider } from "./ItemAuthorizedProvider";
import { ItemPreAuthIssueDate } from "./ItemPreAuthIssueDate";
import { ItemPreAuthPeriod } from "./ItemPreAuthPeriod";
import { ItemRequestedServiceDate } from "./ItemRequestedServiceDate";
import { ItemTraceNumber } from "./ItemTraceNumber";
import { ClaimResponse, ClaimResponseError, ClaimResponseItem, ClaimResponseItemAdjudication, CodeableConcept, Coding, Extension } from "fhir/r4";
import { ReviewAction } from "./ReviewAction";
export interface ExtensionErrorPath extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-errorPath';
}
export interface ExtensionErrorElement extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-errorElement';
}
export interface ExtensionErrorFollowupAction extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-errorFollowupAction';
}
export interface ExtensionCommunicatedDiagnosis extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-communicatedDiagnosis';
}
export interface ExtensionItemAuthorizedProvider extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemAuthorizedProvider';
}
export interface ExtensionItemAuthorizedDetail extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemAuthorizedDetail';
}
export interface ExtensionItemRequestedServiceDate extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemRequestedServiceDate';
}
export interface ExtensionAdministrationReferenceNumber extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-administrationReferenceNumber';
}
export interface ExtensionAuthorizationNumber extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-authorizationNumber';
}
export interface ExtensionItemPreAuthPeriod extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemPreAuthPeriod';
}
export interface ExtensionItemPreAuthIssueDate extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemPreAuthIssueDate';
}
export interface ExtensionItemTraceNumber extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemTraceNumber';
}
export interface ExtensionReviewAction extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-reviewAction';
}
export interface PASClaimInquiryResponseItemAdjudicationCategoryCoding extends Omit<Coding, 'system' | 'code'> {
    system: "http://terminology.hl7.org/CodeSystem/adjudication";
    code: "submitted";
}
export interface PASClaimInquiryResponseItemAdjudication extends Omit<ClaimResponseItemAdjudication, 'category' | 'extension'> {
    category: {
        coding: PASClaimInquiryResponseItemAdjudicationCategoryCoding[];
    };
    extension?: (Extension | ReviewAction)[];
}
export interface PASClaimInquiryResponseItem extends Omit<ClaimResponseItem, 'adjudication' | 'extension'> {
    /** Must Support */
    adjudication: PASClaimInquiryResponseItemAdjudication[];
    extension?: (Extension | ItemTraceNumber | ItemPreAuthIssueDate | ItemPreAuthPeriod | AuthorizationNumber | AdministrationReferenceNumber | ItemRequestedServiceDate | ItemAuthorizedDetail | ItemAuthorizedProvider | CommunicatedDiagnosis)[];
}
export interface PASClaimInquiryResponseError extends Omit<ClaimResponseError, 'code' | 'extension'> {
    /** Must Support */
    code: CodeableConcept;
    extension?: (Extension | ErrorFollowupAction | ErrorElement | ErrorPath)[];
}
export interface PASClaimInquiryResponse extends Omit<ClaimResponse, 'status' | 'use' | 'item' | 'error'> {
    resourceType: 'ClaimResponse';
    status: "active";
    use: "preauthorization";
    /** Must Support */
    item?: PASClaimInquiryResponseItem[];
    /** Must Support */
    error?: PASClaimInquiryResponseError[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASClaimInquiryResponse(resource: PASClaimInquiryResponse, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
