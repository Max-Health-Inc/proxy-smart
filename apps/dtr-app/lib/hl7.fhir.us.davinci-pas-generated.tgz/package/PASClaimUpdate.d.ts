import { PASSupportingInfoTypeCode } from "./valuesets/ValueSet-PASSupportingInfoType";
import { X12278DiagnosisTypeCode } from "./valuesets/ValueSet-X12278DiagnosisType";
import { X12278RequestedServiceTypeCode } from "./valuesets/ValueSet-X12278RequestedServiceType";
import { AdministrationReferenceNumber } from "./AdministrationReferenceNumber";
import { AuthorizationNumber } from "./AuthorizationNumber";
import { CareTeamClaimScope } from "./CareTeamClaimScope";
import { CertificationType } from "./CertificationType";
import { ConditionCode } from "./ConditionCode";
import { DiagnosisRecordedDate } from "./DiagnosisRecordedDate";
import { EPSDTIndicator } from "./EPSDTIndicator";
import { ExtensionClaimEncounter } from "./ExtensionClaimEncounter";
import { HomeHealthCareInformation } from "./HomeHealthCareInformation";
import { Claim, ClaimCareTeam, ClaimDiagnosis, ClaimItem, ClaimSupportingInfo, CodeableConcept, Extension, Money, Reference, SimpleQuantity } from "fhir/r4";
import { InfoChanged } from "./InfoChanged";
import { ItemTraceNumber } from "./ItemTraceNumber";
import { LevelOfServiceCode } from "./LevelOfServiceCode";
import { NursingHomeLevelOfCare } from "./NursingHomeLevelOfCare";
import { NursingHomeResidentialStatus } from "./NursingHomeResidentialStatus";
import { ProductOrServiceCodeEnd } from "./ProductOrServiceCodeEnd";
import { RequestedService } from "./RequestedService";
import { RevenueUnitRateLimit } from "./RevenueUnitRateLimit";
import { ServiceItemRequestType } from "./ServiceItemRequestType";
export interface ExtensionRequestedService extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-requestedService';
}
export interface ExtensionRevenueUnitRateLimit extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-revenueUnitRateLimit';
}
export interface ExtensionNursingHomeLevelOfCare extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-nursingHomeLevelOfCare';
}
export interface ExtensionNursingHomeResidentialStatus extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-nursingHomeResidentialStatus';
}
export interface ExtensionEpsdtIndicator extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-epsdtIndicator';
}
export interface ExtensionProductOrServiceCodeEnd extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-productOrServiceCodeEnd';
}
export interface ExtensionCertificationType extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-certificationType';
}
export interface ExtensionServiceItemRequestType extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-serviceItemRequestType';
}
export interface ExtensionAdministrationReferenceNumber extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-administrationReferenceNumber';
}
export interface ExtensionAuthorizationNumber extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-authorizationNumber';
}
export interface ExtensionItemTraceNumber extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemTraceNumber';
}
export interface ExtensionDiagnosisRecordedDate extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-diagnosisRecordedDate';
}
export interface ExtensionInfoChanged extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-infoChanged';
}
export interface ExtensionCareTeamClaimScope extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-careTeamClaimScope';
}
export interface PASClaimUpdateCareTeam extends Omit<ClaimCareTeam, 'provider' | 'role' | 'qualification' | 'extension'> {
    /** Must Support */
    provider: Reference;
    /** Must Support */
    role?: CodeableConcept;
    /** Must Support */
    qualification?: CodeableConcept;
    extension?: (Extension | CareTeamClaimScope | CareTeamClaimScope | CareTeamClaimScope)[];
}
export interface PASClaimUpdateSupportingInfo extends Omit<ClaimSupportingInfo, 'category' | 'extension'> {
    /** Must Support | @see {@link ./valuesets/ValueSet-PASSupportingInfoType.ts} for valid codes (6 codes) */
    category: CodeableConcept & {
        coding: Array<{
            code: PASSupportingInfoTypeCode;
            system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes";
        }>;
    };
    extension?: (Extension | InfoChanged)[];
}
export interface PASClaimUpdateDiagnosis extends Omit<ClaimDiagnosis, 'type' | 'extension'> {
    /** Must Support | @see {@link ./valuesets/ValueSet-X12278DiagnosisType.ts} for valid codes (3 codes) */
    type?: CodeableConcept & {
        coding: Array<{
            code: X12278DiagnosisTypeCode;
            system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes";
        }>;
    }[];
    extension?: (Extension | DiagnosisRecordedDate)[];
}
export interface PASClaimUpdateItem extends Omit<ClaimItem, 'revenue' | 'category' | 'productOrService' | 'modifier' | 'quantity' | 'unitPrice' | 'extension'> {
    /** Must Support */
    revenue?: CodeableConcept;
    /** Must Support */
    category: CodeableConcept;
    /** Must Support | @see {@link ./valuesets/ValueSet-X12278RequestedServiceType.ts} for valid codes (1 codes) */
    productOrService: CodeableConcept & {
        coding: Array<{
            code: X12278RequestedServiceTypeCode;
            system: "http://terminology.hl7.org/CodeSystem/data-absent-reason";
        }>;
    };
    /** Must Support */
    modifier?: CodeableConcept[];
    /** Must Support */
    quantity?: SimpleQuantity;
    /** Must Support */
    unitPrice?: Money;
    extension?: (Extension | ItemTraceNumber | AuthorizationNumber | AdministrationReferenceNumber | ServiceItemRequestType | CertificationType | ProductOrServiceCodeEnd | EPSDTIndicator | NursingHomeResidentialStatus | NursingHomeLevelOfCare | RevenueUnitRateLimit | RequestedService | InfoChanged)[];
}
export interface PASClaimUpdate extends Omit<Claim, 'status' | 'use' | 'careTeam' | 'supportingInfo' | 'diagnosis' | 'item' | 'extension'> {
    status: "active";
    use: "preauthorization";
    /** Must Support */
    careTeam?: PASClaimUpdateCareTeam[];
    /** Must Support */
    supportingInfo?: PASClaimUpdateSupportingInfo[];
    /** Must Support */
    diagnosis?: PASClaimUpdateDiagnosis[];
    /** Must Support */
    item: PASClaimUpdateItem[];
    extension?: (Extension | LevelOfServiceCode | ConditionCode | HomeHealthCareInformation | ExtensionClaimEncounter)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASClaimUpdate(resource: PASClaimUpdate, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
