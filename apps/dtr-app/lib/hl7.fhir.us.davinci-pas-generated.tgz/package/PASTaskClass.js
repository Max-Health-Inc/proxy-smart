import { validatePASTask } from "./PASTask.js";
// Only import helpers actually referenced below (dynamic based on required fields)
import { randomId, setRandomSeed, enrichResource, skeletonIdentifier, skeletonReference } from "./RandomSupport.js";
import { createRequire } from 'module';
const __require = createRequire(import.meta.url);
function ensureProfile(res, profile) {
    if (!res.meta) {
        res.meta = { profile: [profile] };
        return;
    }
    if (!res.meta.profile) {
        res.meta.profile = [profile];
        return;
    }
    if (!res.meta.profile.includes(profile)) {
        res.meta.profile = [...res.meta.profile, profile];
    }
}
// Internal helper (emitted per class file) to clone without resorting to 'any'.
function safeClone(value) {
    // Use native structuredClone if present; otherwise fallback to JSON round-trip.
    // We intentionally avoid casting through any to satisfy no-explicit-any lint rule.
    const g = globalThis;
    // Narrow globalThis to an object potentially containing structuredClone.
    if (typeof g.structuredClone === 'function') {
        return g.structuredClone(value);
    }
    return JSON.parse(JSON.stringify(value)); // best-effort deep clone
}
export class PASTaskClass {
    constructor(resource) {
        this.resource = resource;
        ensureProfile(this.resource, 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-task');
    }
    /** Validate current resource instance. */
    async validate(options) {
        return validatePASTask(this.resource, options);
    }
    getResource() {
        return this.resource;
    }
    setResource(resource) {
        this.resource = resource;
        ensureProfile(this.resource, 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-task');
    }
    /**
     * Returns a plain JSON clone of the underlying resource ONLY if the last validation succeeded with zero errors.
     * Call validate() first; otherwise this method throws to prevent accidental use of invalid / unchecked data.
     */
    async toJSON() {
        return safeClone(this.resource);
    }
    /**
     * Create an empty instance for parity testing: for true FHIR resources, includes only resourceType; for datatypes, returns an empty object.
     * Note: meta.profile (when applicable) will be ensured by the constructor when wrapping this resource.
     */
    static empty(overrides = {}) {
        // For Resource profiles, include only resourceType. For Extension profiles, include url so the instance is minimally meaningful.
        const base = {
            resourceType: 'Task',
        };
        return { ...base, ...overrides };
    }
    /**
     * Create a minimal randomized instance of PASTask.
     * Populates id, resourceType (if applicable) and primitive required (min>0) top-level fields with placeholders.
     */
    static random(overrides = {}, opts) {
        if (opts?.seed !== undefined) {
            // Direct call (no dynamic require) to ensure deterministic seeding works under ESM.
            setRandomSeed(opts.seed);
        }
        // Start with a Partial to avoid unsafe casting errors; we'll assert at the end.
        const base = { resourceType: 'Task', id: randomId(), identifier: [skeletonIdentifier()], status: "in-progress", intent: "order", code: { coding: [{ system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes", code: "attachment-request-code" }] }, for: skeletonReference(), requester: { reference: 'Device/' + randomId(), identifier: { type: { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/v2-0203', code: 'XX' }] }, system: "urn:ietf:rfc:3986", value: 'urn:uuid:' + randomId() } }, owner: { reference: 'Practitioner/' + randomId(), identifier: { type: { coding: [{ system: 'http://terminology.hl7.org/CodeSystem/v2-0203', code: 'XX' }] }, system: "urn:ietf:rfc:3986", value: 'urn:uuid:' + randomId() } }, reasonCode: { coding: [{ system: "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes", code: "priorAuthorization" }] }, reasonReference: skeletonReference(), input: [{ type: { "coding": [{ "system": "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes", "code": "payer-url" }] }, valueUrl: "https://babelfhir.dev" }], };
        // Always include meta.profile with this profile's canonical URL if available & only for resource profiles
        ensureProfile(base, 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-task');
        // Enrich the base resource with common fields using centralized enrichment logic
        enrichResource(base, 'Task', 'http://hl7.org/fhir/us/davinci-pas/StructureDefinition/profile-task', PASTaskClass._fieldPatterns, PASTaskClass._forbiddenFields, PASTaskClass.valueSetBindings, PASTaskClass._codeResolver, PASTaskClass._fieldOrder);
        // Cast through unknown to acknowledge dynamic enrichment
        return { ...base, ...overrides };
    }
    /** Convenience: returns a class instance wrapping a randomized resource. */
    static randomClass(overrides = {}, opts) {
        return new PASTaskClass(this.random(overrides, opts));
    }
}
/** Pattern constraints for profile fields (used by random() generator) */
PASTaskClass._fieldPatterns = {
    "intent": "order",
    "requester.type": "SearchParameter",
    "owner.type": "SearchParameter",
    "reasonCode": {
        "coding": [
            {
                "system": "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes",
                "code": "priorAuthorization"
            }
        ]
    },
    "PayerURL.type": {
        "coding": [
            {
                "system": "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes",
                "code": "payer-url"
            }
        ]
    },
    "AttachmentsNeeded.type": {
        "coding": [
            {
                "system": "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes",
                "code": "attachments-needed"
            }
        ]
    },
    "QuestionnairesNeeded.type": {
        "coding": [
            {
                "system": "http://hl7.org/fhir/us/davinci-pas/CodeSystem/PASTempCodes",
                "code": "questionnaires-needed"
            }
        ]
    },
    "_refReq_requester": {
        "identifier": true
    },
    "_refReq_owner": {
        "identifier": true
    },
    "_refReq_input": {
        "type": true,
        "valueBase64Binary": true,
        "valueUrl": true,
        "extension": {
            "profile": "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-paLineNumber"
        },
        "valueCodeableConcept": true,
        "valueProfile-identifier": true
    },
    "_refReq_output": {
        "type": true,
        "valueBase64Binary": true
    }
};
/** Fields that are forbidden (max=0) in this profile - must not be generated */
PASTaskClass._forbiddenFields = [];
/** FHIR element ordering for this profile's base resource (used by enrichResource for correct JSON field order) */
PASTaskClass._fieldOrder = ["id", "meta", "implicitRules", "language", "text", "contained", "extension", "modifierExtension", "identifier", "instantiatesCanonical", "instantiatesUri", "basedOn", "groupIdentifier", "partOf", "status", "statusReason", "businessStatus", "intent", "priority", "code", "description", "focus", "for", "encounter", "executionPeriod", "authoredOn", "lastModified", "requester", "performerType", "owner", "location", "reasonCode", "reasonReference", "insurance", "note", "relevantHistory", "restriction", "input", "output"];
/** ValueSet bindings for coded fields - maps field name to ValueSet URL */
PASTaskClass.valueSetBindings = {
    "language": "http://hl7.org/fhir/ValueSet/languages",
    "status": "http://hl7.org/fhir/us/davinci-hrex/ValueSet/hrex-task-status",
    "intent": "http://hl7.org/fhir/ValueSet/task-intent|4.0.1",
    "priority": "http://hl7.org/fhir/ValueSet/request-priority|4.0.1",
    "code": "http://hl7.org/fhir/us/davinci-pas/ValueSet/PASTaskCodes",
    "requester.type": "http://hl7.org/fhir/ValueSet/resource-types",
    "performerType": "http://hl7.org/fhir/ValueSet/performer-role",
    "owner.type": "http://hl7.org/fhir/ValueSet/resource-types",
    "input.value[x]": "http://hl7.org/fhir/us/davinci-pas/ValueSet/AttachmentRequestCodes"
};
/** Code resolver for ValueSet bindings - returns a random valid code from a ValueSet by URL */
PASTaskClass._codeResolver = (() => {
    // Try to load the ValueSetRegistry - it may not exist if no ValueSets were generated
    try {
        const registry = __require('./valuesets/index.js');
        if (registry && typeof registry.getRandomConceptByUrl === 'function') {
            return registry.getRandomConceptByUrl;
        }
    }
    catch { /* ValueSetRegistry not available */ }
    return undefined;
})();
