import { Extension } from "fhir/r4";
export interface USCoreRaceExtension extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/us/core/StructureDefinition/us-core-race";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateUSCoreRaceExtension(resource: USCoreRaceExtension, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
