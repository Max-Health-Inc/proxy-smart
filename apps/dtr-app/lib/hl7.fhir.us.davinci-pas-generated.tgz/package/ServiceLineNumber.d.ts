import { Extension } from "fhir/r4";
export interface ServiceLineNumber extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-serviceLineNumber";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateServiceLineNumber(resource: ServiceLineNumber, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
