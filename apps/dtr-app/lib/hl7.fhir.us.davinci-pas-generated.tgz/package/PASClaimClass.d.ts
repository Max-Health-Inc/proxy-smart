import { PASClaim } from "./PASClaim.js";
import type { ValidatorOptions } from "./ValidatorOptions.js";
export declare class PASClaimClass {
    private resource;
    /** Pattern constraints for profile fields (used by random() generator) */
    protected static readonly _fieldPatterns: {
        "encounter.url": string;
        status: string;
        use: string;
        "related.relationship": string;
        "payee.type": string;
        "careTeam.role": string;
        "careTeam.qualification": string;
        "OverallClaimMember.careTeamClaimScope.url": string;
        "OverallClaimMember.careTeamClaimScope": boolean;
        "ItemClaimMember.careTeamClaimScope.url": string;
        "supportingInfo.category": string;
        "supportingInfo.code": string;
        "supportingInfo.reason": string;
        "PatientEvent.category": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "PatientEvent.code": string;
        "PatientEvent.reason": string;
        "AdmissionDates.category": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "AdmissionDates.code": string;
        "AdmissionDates.reason": string;
        "DischargeDates.category": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "DischargeDates.code": string;
        "DischargeDates.reason": string;
        "AdditionalInformation.category": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "AdditionalInformation.code": string;
        "AdditionalInformation.reason": string;
        "MessageText.category": {
            coding: {
                system: string;
                code: string;
            }[];
        };
        "MessageText.code": string;
        "MessageText.reason": string;
        "diagnosis.type": string;
        "diagnosis.onAdmission": string;
        "diagnosis.packageCode": string;
        "procedure.type": string;
        "insurance.focal": boolean;
        "item.nursingHomeResidentialStatus.url": string;
        "item.productOrService": string;
        "item.programCode": string;
        "item.bodySite": string;
        "item.subSite": string;
        "item.detail.revenue": string;
        "item.detail.category": string;
        "item.detail.productOrService": string;
        "item.detail.modifier": string;
        "item.detail.programCode": string;
        "item.detail.subDetail.revenue": string;
        "item.detail.subDetail.category": string;
        "item.detail.subDetail.productOrService": string;
        "item.detail.subDetail.modifier": string;
        "item.detail.subDetail.programCode": string;
        "item.revenue": string;
        "item.category": string;
        "item.modifier": string;
        _refReq_extension: {
            url: boolean;
            valueReference: boolean;
        };
        _refReq_payee: {
            type: boolean;
        };
        _refReq_careTeam: {
            extension: {
                profile: string;
            };
            sequence: boolean;
            provider: boolean;
            "extension.url": boolean;
        };
        _refReq_supportingInfo: {
            sequence: boolean;
            category: boolean;
            timingDate: boolean;
            valueReference: boolean;
            valueString: boolean;
        };
        _refReq_diagnosis: {
            sequence: boolean;
            diagnosisCodeableConcept: boolean;
        };
        _refReq_procedure: {
            sequence: boolean;
            procedureCodeableConcept: boolean;
        };
        _refReq_insurance: {
            sequence: boolean;
            focal: boolean;
            coverage: boolean;
        };
        _refReq_accident: {
            date: boolean;
        };
        _refReq_item: {
            "extension.url": boolean;
            sequence: boolean;
            category: boolean;
            productOrService: boolean;
            "detail.sequence": boolean;
            "detail.productOrService": boolean;
            "detail.subDetail.sequence": boolean;
            "detail.subDetail.productOrService": boolean;
        };
    };
    /** Fields that are forbidden (max=0) in this profile - must not be generated */
    protected static readonly _forbiddenFields: string[];
    /** FHIR element ordering for this profile's base resource (used by enrichResource for correct JSON field order) */
    protected static readonly _fieldOrder: string[];
    /** ValueSet bindings for coded fields - maps field name to ValueSet URL */
    static readonly valueSetBindings: Record<string, string>;
    /** Code resolver for ValueSet bindings - returns a random valid code from a ValueSet by URL */
    protected static readonly _codeResolver: ((url: string) => {
        code: string;
        system: string;
        display?: string;
    } | undefined) | undefined;
    constructor(resource: PASClaim);
    /** Validate current resource instance. */
    validate(options?: ValidatorOptions): Promise<{
        errors: string[];
        warnings: string[];
    }>;
    getResource(): PASClaim;
    setResource(resource: PASClaim): void;
    /**
     * Returns a plain JSON clone of the underlying resource ONLY if the last validation succeeded with zero errors.
     * Call validate() first; otherwise this method throws to prevent accidental use of invalid / unchecked data.
     */
    toJSON(): Promise<PASClaim>;
    /**
     * Create an empty instance for parity testing: for true FHIR resources, includes only resourceType; for datatypes, returns an empty object.
     * Note: meta.profile (when applicable) will be ensured by the constructor when wrapping this resource.
     */
    static empty(overrides?: Partial<PASClaim>): PASClaim;
    /**
     * Create a minimal randomized instance of PASClaim.
     * Populates id, resourceType (if applicable) and primitive required (min>0) top-level fields with placeholders.
     */
    static random(overrides?: Partial<PASClaim>, opts?: {
        seed?: number;
    }): PASClaim;
    /** Convenience: returns a class instance wrapping a randomized resource. */
    static randomClass(overrides?: Partial<PASClaim>, opts?: {
        seed?: number;
    }): PASClaimClass;
}
