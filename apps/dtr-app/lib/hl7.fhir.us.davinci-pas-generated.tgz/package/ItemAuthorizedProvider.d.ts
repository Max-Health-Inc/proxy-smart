import { Extension } from "fhir/r4";
export interface ItemAuthorizedProvider extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-itemAuthorizedProvider";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateItemAuthorizedProvider(resource: ItemAuthorizedProvider, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
