import { Extension } from "fhir/r4";
export interface DeliveryPattern extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-timingdeliverypattern";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateDeliveryPattern(resource: DeliveryPattern, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
