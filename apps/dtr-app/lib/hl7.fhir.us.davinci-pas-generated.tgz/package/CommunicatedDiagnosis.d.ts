import { Extension } from "fhir/r4";
export interface CommunicatedDiagnosis extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-communicatedDiagnosis";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateCommunicatedDiagnosis(resource: CommunicatedDiagnosis, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
