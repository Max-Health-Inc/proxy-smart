import { CoverageInformation } from "./CoverageInformation.js";
import type { ValidatorOptions } from "./ValidatorOptions.js";
export declare class CoverageInformationClass {
    private resource;
    /** Pattern constraints for profile fields (used by random() generator) */
    protected static readonly _fieldPatterns: {
        "coverage.url": string;
        "covered.url": string;
        "pa-needed.url": string;
        "doc-needed.url": string;
        "doc-purpose.url": string;
        "info-needed.url": string;
        "billingCode.url": string;
        "reason.url": string;
        "detail.code.url": string;
        "detail.code": string;
        "detail.value.url": string;
        "detail.value": string;
        "detail.qualification.url": string;
        "detail.qualification": string;
        "detail.url": string;
        "dependency.url": string;
        "questionnaire.url": string;
        "response.url": string;
        "date.url": string;
        "coverage-assertion-id.url": string;
        "satisfied-pa-id.url": string;
        "contact.url": string;
        url: string;
        _refReq_extension: {
            url: boolean;
            valueReference: boolean;
            valueCode: boolean;
            valueCoding: boolean;
            valueCodeableConcept: boolean;
            extension: boolean;
            "extension.url": boolean;
            valueDate: boolean;
        };
        "_choiceType_value[x]": string[];
    };
    /** Fields that are forbidden (max=0) in this profile - must not be generated */
    protected static readonly _forbiddenFields: string[];
    /** FHIR element ordering for this profile's base resource (used by enrichResource for correct JSON field order) */
    protected static readonly _fieldOrder: string[];
    /** ValueSet bindings for coded fields - maps field name to ValueSet URL */
    static readonly valueSetBindings: Record<string, string>;
    /** Code resolver for ValueSet bindings - returns a random valid code from a ValueSet by URL */
    protected static readonly _codeResolver: ((url: string) => {
        code: string;
        system: string;
        display?: string;
    } | undefined) | undefined;
    constructor(resource: CoverageInformation);
    /** Validate current resource instance. */
    validate(options?: ValidatorOptions): Promise<{
        errors: string[];
        warnings: string[];
    }>;
    getResource(): CoverageInformation;
    setResource(resource: CoverageInformation): void;
    /**
     * Returns a plain JSON clone of the underlying resource ONLY if the last validation succeeded with zero errors.
     * Call validate() first; otherwise this method throws to prevent accidental use of invalid / unchecked data.
     */
    toJSON(): Promise<CoverageInformation>;
    /**
     * Create an empty instance for parity testing: for true FHIR resources, includes only resourceType; for datatypes, returns an empty object.
     * Note: meta.profile (when applicable) will be ensured by the constructor when wrapping this resource.
     */
    static empty(overrides?: Partial<CoverageInformation>): CoverageInformation;
    /**
     * Create a minimal randomized instance of CoverageInformation.
     * Populates id, resourceType (if applicable) and primitive required (min>0) top-level fields with placeholders.
     */
    static random(overrides?: Partial<CoverageInformation>, opts?: {
        seed?: number;
    }): CoverageInformation;
    /** Convenience: returns a class instance wrapping a randomized resource. */
    static randomClass(overrides?: Partial<CoverageInformation>, opts?: {
        seed?: number;
    }): CoverageInformationClass;
}
