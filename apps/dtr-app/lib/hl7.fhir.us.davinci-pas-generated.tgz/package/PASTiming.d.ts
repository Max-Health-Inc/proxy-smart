import { CalendarPattern } from "./CalendarPattern";
import { DeliveryPattern } from "./DeliveryPattern";
import { Extension, Timing } from "fhir/r4";
export interface PASTiming extends Omit<Timing, 'extension'> {
    extension?: (Extension | CalendarPattern | DeliveryPattern)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASTiming(resource: PASTiming, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
