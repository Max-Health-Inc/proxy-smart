import fhirpath from "fhirpath";
import fhirpath_model from "fhirpath/fhir-context/r4/index.js";
export async function validateUSCoreRaceExtension(resource, options) {
    const errors = [];
    const warnings = [];
    const fhirpathOptions = {
        preciseMath: true,
        traceFn: options?.traceFn ?? (() => { }),
        ...(options?.signal ? { signal: options.signal } : {}),
        ...(options?.httpHeaders ? { httpHeaders: options.httpHeaders } : {}),
    };
    const result0 = await fhirpath.evaluate(resource, "Extension.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result0.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result1 = await fhirpath.evaluate(resource, "extension.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result1.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result2 = await fhirpath.evaluate(resource, "value.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result2.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result3 = await fhirpath.evaluate(resource, "Element.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result3.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result4 = await fhirpath.evaluate(resource, "url.exists()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result4.every(Boolean)) {
        errors.push("Constraint violation: url must be present");
    }
    const result5 = await fhirpath.evaluate(resource, "extension.count() >= 1", { resource }, fhirpath_model, fhirpathOptions);
    if (!result5.every(Boolean)) {
        errors.push("Constraint violation: extension must contain at least one element");
    }
    const result6 = await fhirpath.evaluate(resource, "Extension.count() <= 1", { resource }, fhirpath_model, fhirpathOptions);
    if (!result6.every(Boolean)) {
        errors.push("Constraint violation: Extension must contain at most one element");
    }
    const result7 = await fhirpath.evaluate(resource, "value.exists().not()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result7.every(Boolean)) {
        errors.push("Constraint violation: value: max allowed = 0, but found 1");
    }
    // Fixed value constraint for url
    if (resource.url !== undefined && resource.url !== "http://hl7.org/fhir/us/core/StructureDefinition/us-core-race") {
        errors.push("url must have the fixed value 'http://hl7.org/fhir/us/core/StructureDefinition/us-core-race'");
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const _bRes = resource;
    // Prohibited field: Extension.value (max=0)
    if (_bRes.value !== undefined) {
        errors.push("Extension.value: max allowed = 0, but found 1");
    }
    // Required binding system-presence fallback for extension.valueCoding (nested, ValueSet unresolved)
    if (resource.extension && Array.isArray(resource.extension)) {
        for (const _nb0 of resource.extension) {
            if (_nb0.valueCoding !== undefined) {
                const _spC = _nb0.valueCoding;
                const _c = _spC;
                if (_c.code !== undefined && (_c.system === undefined || _c.system === '')) {
                    errors.push("The System URI could not be determined for the code '" + _c.code + "' in the ValueSet 'detailed-race' (http://hl7.org/fhir/us/core/ValueSet/detailed-race)");
                }
            }
        }
    }
    // Required binding system-presence fallback for extension.valueCoding (nested, ValueSet unresolved)
    if (resource.extension && Array.isArray(resource.extension)) {
        for (const _nb0 of resource.extension) {
            if (_nb0.valueCoding !== undefined) {
                const _spC = _nb0.valueCoding;
                const _c = _spC;
                if (_c.code !== undefined && (_c.system === undefined || _c.system === '')) {
                    errors.push("The System URI could not be determined for the code '" + _c.code + "' in the ValueSet 'detailed-race' (http://hl7.org/fhir/us/core/ValueSet/detailed-race)");
                }
            }
        }
    }
    // date format validation for valueDate (choice type)
    if (typeof _bRes.valueDate === 'string' && !/^\d{4}(-\d{2}(-\d{2})?)?$/.test(_bRes.valueDate)) {
        errors.push("Not a valid date format: '" + _bRes.valueDate + "'");
    }
    // dateTime format validation for valueDateTime (choice type)
    if (typeof _bRes.valueDateTime === 'string' && !/^\d{4}(-\d{2}(-\d{2}(T\d{2}:\d{2}(:\d{2}(\.\d+)?)?(Z|[+-]\d{2}:\d{2})?)?)?)?$/.test(_bRes.valueDateTime)) {
        errors.push("Not a valid date/time format: '" + _bRes.valueDateTime + "'");
    }
    // instant format validation for valueInstant (choice type)
    if (typeof _bRes.valueInstant === 'string' && !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2}(\.\d+)?)?(Z|[+-]\d{2}:\d{2})$/.test(_bRes.valueInstant)) {
        errors.push("Not a valid instant format: '" + _bRes.valueInstant + "'");
    }
    // time format validation for valueTime (choice type)
    if (typeof _bRes.valueTime === 'string' && !/^\d{2}:\d{2}(:\d{2}(\.\d+)?)?$/.test(_bRes.valueTime)) {
        errors.push("Not a valid time format: '" + _bRes.valueTime + "'");
    }
    // Required fixedValue slice validation for extension:text (discriminated by url === "text")
    if (resource.extension && Array.isArray(resource.extension)) {
        const textElements = resource.extension.filter((item) => item.url === "text");
        if (textElements.length < 1) {
            errors.push("No elements matched required slice: 'extension:text'");
        }
        for (const _matched of textElements) {
            const _m = _matched;
            if (!Object.keys(_m).some(k => k.startsWith('value'))) {
                errors.push("Extension.extension.value: minimum required = 1, but only found 0");
            }
        }
    }
    else {
        errors.push("No elements matched required slice: 'extension:text'");
    }
    // Slice validation for extension.value[x]:valueCoding skipped: nested value[x] not validatable at resource scope
    // Slice validation for extension.value[x]:valueCoding skipped: nested value[x] not validatable at resource scope
    // Slice validation for extension.value[x]:valueString skipped: nested value[x] not validatable at resource scope
    // Base FHIR structural validation: extension.url required, ext-1 constraint, empty objects
    {
        const _checkExtensions = (obj, path) => {
            if (!obj || typeof obj !== 'object')
                return;
            if (Array.isArray(obj)) {
                obj.forEach((item, i) => _checkExtensions(item, path + '[' + i + ']'));
                return;
            }
            const rec = obj;
            // Validate extension arrays
            for (const extKey of ['extension', 'modifierExtension']) {
                const exts = rec[extKey];
                if (Array.isArray(exts)) {
                    for (const ext of exts) {
                        if (ext && typeof ext === 'object' && !Array.isArray(ext)) {
                            const e = ext;
                            // Empty extension object check
                            if (Object.keys(e).length === 0) {
                                errors.push('Object must have some content');
                                continue;
                            }
                            if (typeof e.url !== 'string' || !e.url) {
                                errors.push('Extension.url is required in order to identify, use and validate the extension');
                            }
                            // ext-1: Must have either extensions or value[x], not both
                            const hasNestedExt = Array.isArray(e.extension) && e.extension.length > 0;
                            const hasValue = Object.keys(e).some(k => k.startsWith('value') && k !== 'value' && k.length > 5);
                            if (hasNestedExt && hasValue) {
                                errors.push('Must have either extensions or value[x], not both');
                            }
                        }
                    }
                }
            }
            // Recurse into child objects (skip primitive values)
            for (const [_key, _val] of Object.entries(rec)) {
                if (_val && typeof _val === 'object') {
                    _checkExtensions(_val, path + '.' + _key);
                }
            }
        };
        _checkExtensions(resource, '');
    }
    // Standalone contained reference resolution: verify #id references resolve to contained[] entries
    {
        const _res = resource;
        const _containedIds = new Set();
        if (Array.isArray(_res.contained)) {
            for (const _c of _res.contained) {
                if (_c && typeof _c.id === 'string')
                    _containedIds.add(_c.id);
            }
        }
        const _checkContainedRef = (obj) => {
            if (!obj || typeof obj !== 'object')
                return;
            if (Array.isArray(obj)) {
                obj.forEach(_checkContainedRef);
                return;
            }
            const _rec = obj;
            if (typeof _rec.reference === 'string') {
                const _ref = _rec.reference;
                if (_ref.startsWith('#')) {
                    const _id = _ref.substring(1);
                    if (_id && !_containedIds.has(_id)) {
                        errors.push('Contained reference not found: ' + _ref);
                    }
                }
            }
            for (const [_k, _v] of Object.entries(_rec)) {
                if (_k !== 'contained')
                    _checkContainedRef(_v);
            }
        };
        _checkContainedRef(_res);
    }
    return { errors, warnings };
}
