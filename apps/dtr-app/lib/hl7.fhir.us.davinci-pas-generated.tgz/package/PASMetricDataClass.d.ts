import { PASMetricData } from "./PASMetricData.js";
import type { ValidatorOptions } from "./ValidatorOptions.js";
export declare class PASMetricDataClass {
    private resource;
    /** Pattern constraints for profile fields (used by random() generator) */
    protected static readonly _fieldPatterns: {
        "providerId.use": string;
        "providerId.system": string;
        "groupId.use": string;
        "groupId.system": string;
        "payerId.use": string;
        _refReq_providerId: {
            value: boolean;
        };
        _refReq_groupId: {
            value: boolean;
        };
        _refReq_payerId: {
            system: boolean;
            value: boolean;
        };
        _refReq_exchange: {
            type: boolean;
            method: boolean;
            requestTime: boolean;
            httpResponse: boolean;
        };
        _refReq_issue: {
            code: boolean;
        };
        _refReq_aaaCodes: {
            loopID: boolean;
            aaaCode: boolean;
        };
        _refReq_itemDetail: {
            item: boolean;
            "aaaCodes.loopID": boolean;
            "aaaCodes.aaaCode": boolean;
        };
        _refReq_requestedDoc: {
            docRequest: boolean;
            timeRequested: boolean;
        };
    };
    /** Fields that are forbidden (max=0) in this profile - must not be generated */
    protected static readonly _forbiddenFields: string[];
    /** FHIR element ordering for this profile's base resource (used by enrichResource for correct JSON field order) */
    protected static readonly _fieldOrder: string[];
    /** ValueSet bindings for coded fields - maps field name to ValueSet URL */
    static readonly valueSetBindings: Record<string, string>;
    /** Code resolver for ValueSet bindings - returns a random valid code from a ValueSet by URL */
    protected static readonly _codeResolver: ((url: string) => {
        code: string;
        system: string;
        display?: string;
    } | undefined) | undefined;
    constructor(resource: PASMetricData);
    /** Validate current resource instance. */
    validate(options?: ValidatorOptions): Promise<{
        errors: string[];
        warnings: string[];
    }>;
    getResource(): PASMetricData;
    setResource(resource: PASMetricData): void;
    /**
     * Returns a plain JSON clone of the underlying resource ONLY if the last validation succeeded with zero errors.
     * Call validate() first; otherwise this method throws to prevent accidental use of invalid / unchecked data.
     */
    toJSON(): Promise<PASMetricData>;
    /**
     * Create an empty instance for parity testing: for true FHIR resources, includes only resourceType; for datatypes, returns an empty object.
     * Note: meta.profile (when applicable) will be ensured by the constructor when wrapping this resource.
     */
    static empty(overrides?: Partial<PASMetricData>): PASMetricData;
    /**
     * Create a minimal randomized instance of PASMetricData.
     * Populates id, resourceType (if applicable) and primitive required (min>0) top-level fields with placeholders.
     */
    static random(overrides?: Partial<PASMetricData>, opts?: {
        seed?: number;
    }): PASMetricData;
    /** Convenience: returns a class instance wrapping a randomized resource. */
    static randomClass(overrides?: Partial<PASMetricData>, opts?: {
        seed?: number;
    }): PASMetricDataClass;
}
