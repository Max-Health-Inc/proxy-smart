import { Extension } from "fhir/r4";
export interface CertificationType extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-certificationType";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateCertificationType(resource: CertificationType, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
