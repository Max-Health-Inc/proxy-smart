import { ReviewActionCode } from "./ReviewActionCode";
import { Extension } from "fhir/r4";
export interface ReviewAction extends Omit<Extension, 'url' | 'extension'> {
    url: "http://hl7.org/fhir/us/davinci-pas/StructureDefinition/extension-reviewAction";
    extension?: (Extension | ReviewActionCode)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateReviewAction(resource: ReviewAction, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
