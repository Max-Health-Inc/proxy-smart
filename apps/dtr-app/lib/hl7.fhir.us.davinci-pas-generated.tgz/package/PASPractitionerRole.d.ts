import { PractitionerRole, Reference } from "fhir/r4";
export interface PASPractitionerRole extends Omit<PractitionerRole, 'practitioner' | 'organization'> {
    /** Must Support */
    practitioner: Reference;
    /** Must Support */
    organization?: Reference;
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASPractitionerRole(resource: PASPractitionerRole, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
