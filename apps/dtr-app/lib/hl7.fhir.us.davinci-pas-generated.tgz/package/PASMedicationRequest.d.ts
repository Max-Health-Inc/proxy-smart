import { CoverageInformation } from "./CoverageInformation";
import { PASTiming } from "./PASTiming";
import { Dosage, Extension, MedicationRequest, MedicationRequestDispenseRequest, Reference, SimpleQuantity } from "fhir/r4";
export interface PASMedicationRequestDosageInstruction extends Omit<Dosage, 'text' | 'timing' | 'maxDosePerAdministration' | 'maxDosePerLifetime'> {
    /** Must Support */
    text?: string;
    /** Must Support */
    timing?: PASTiming;
    maxDosePerAdministration?: SimpleQuantity;
    maxDosePerLifetime?: SimpleQuantity;
}
export interface PASMedicationRequestDispenseRequest extends Omit<MedicationRequestDispenseRequest, 'quantity'> {
    /** Must Support */
    quantity?: SimpleQuantity;
}
export interface PASMedicationRequest extends Omit<MedicationRequest, 'intent' | 'requester' | 'dosageInstruction' | 'dispenseRequest' | 'extension'> {
    intent: "order";
    /** Must Support */
    requester: Reference;
    /** Must Support */
    dosageInstruction?: PASMedicationRequestDosageInstruction[];
    /** Must Support */
    dispenseRequest?: PASMedicationRequestDispenseRequest;
    extension?: (Extension | CoverageInformation)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validatePASMedicationRequest(resource: PASMedicationRequest, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
