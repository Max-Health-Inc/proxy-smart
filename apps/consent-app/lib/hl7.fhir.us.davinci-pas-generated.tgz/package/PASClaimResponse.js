import fhirpath from "fhirpath";
import fhirpath_model from "fhirpath/fhir-context/r4/index.js";
import { isValidFmStatusCode } from './valuesets/ValueSet-FmStatus.js';
import { isValidClaimUseCode } from './valuesets/ValueSet-ClaimUse.js';
import { isValidRemittanceOutcomeCode } from './valuesets/ValueSet-RemittanceOutcome.js';
import { isValidNoteTypeCode } from './valuesets/ValueSet-NoteType.js';
import { validatePASIdentifier } from './PASIdentifier.js';
export async function validatePASClaimResponse(resource, options) {
    const errors = [];
    const warnings = [];
    const fhirpathOptions = {
        preciseMath: true,
        traceFn: options?.traceFn ?? (() => { }),
        ...(options?.signal ? { signal: options.signal } : {}),
        ...(options?.httpHeaders ? { httpHeaders: options.httpHeaders } : {}),
        async: true,
        ...(options?.terminologyUrl ? { terminologyUrl: options.terminologyUrl } : {}),
        ...(options?.fhirServerUrl ? { fhirServerUrl: options.fhirServerUrl } : {}),
    };
    const result0 = await fhirpath.evaluate(resource, "ClaimResponse.all(contained.contained.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result0.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL NOT contain nested Resources");
    }
    const result1 = await fhirpath.evaluate(resource, "ClaimResponse.all(contained.where((('#'+id in (%resource.descendants().reference | %resource.descendants().as(canonical) | %resource.descendants().as(uri) | %resource.descendants().as(url))) or descendants().where(reference = '#').exists() or descendants().where(as(canonical) = '#').exists() or descendants().where(as(canonical) = '#').exists()).not()).trace('unmatched', id).empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result1.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL be referred to from elsewhere in the resource or SHALL refer to the containing resource");
    }
    const result2 = await fhirpath.evaluate(resource, "ClaimResponse.all(contained.meta.versionId.empty() and contained.meta.lastUpdated.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result2.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a meta.versionId or a meta.lastUpdated");
    }
    const result3 = await fhirpath.evaluate(resource, "ClaimResponse.all(contained.meta.security.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result3.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a security label");
    }
    const result4 = await fhirpath.evaluate(resource, "ClaimResponse.all(text.`div`.exists())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result4.every(Boolean)) {
        warnings.push("Constraint violation: A resource should have narrative for robust management");
    }
    const result5 = await fhirpath.evaluate(resource, "meta.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result5.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result6 = await fhirpath.evaluate(resource, "implicitRules.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result6.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result7 = await fhirpath.evaluate(resource, "language.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result7.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result8 = await fhirpath.evaluate(resource, "text.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result8.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result9 = await fhirpath.evaluate(resource, "extension.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result9.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result10 = await fhirpath.evaluate(resource, "modifierExtension.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result10.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result11 = await fhirpath.evaluate(resource, "identifier.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result11.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result12 = await fhirpath.evaluate(resource, "status.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result12.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result13 = await fhirpath.evaluate(resource, "type.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result13.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result14 = await fhirpath.evaluate(resource, "subType.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result14.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result15 = await fhirpath.evaluate(resource, "use.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result15.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result16 = await fhirpath.evaluate(resource, "patient.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result16.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result17 = await fhirpath.evaluate(resource, "created.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result17.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result18 = await fhirpath.evaluate(resource, "insurer.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result18.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result19 = await fhirpath.evaluate(resource, "requestor.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result19.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result20 = await fhirpath.evaluate(resource, "request.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result20.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result21 = await fhirpath.evaluate(resource, "outcome.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result21.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result22 = await fhirpath.evaluate(resource, "disposition.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result22.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result23 = await fhirpath.evaluate(resource, "preAuthRef.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result23.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result24 = await fhirpath.evaluate(resource, "preAuthPeriod.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result24.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result25 = await fhirpath.evaluate(resource, "payeeType.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result25.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result26 = await fhirpath.evaluate(resource, "item.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result26.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result27 = await fhirpath.evaluate(resource, "addItem.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result27.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result28 = await fhirpath.evaluate(resource, "adjudication.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result28.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result29 = await fhirpath.evaluate(resource, "total.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result29.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result30 = await fhirpath.evaluate(resource, "payment.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result30.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result31 = await fhirpath.evaluate(resource, "fundsReserve.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result31.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result32 = await fhirpath.evaluate(resource, "formCode.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result32.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result33 = await fhirpath.evaluate(resource, "form.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result33.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result34 = await fhirpath.evaluate(resource, "processNote.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result34.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result35 = await fhirpath.evaluate(resource, "communicationRequest.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result35.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result36 = await fhirpath.evaluate(resource, "insurance.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result36.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result37 = await fhirpath.evaluate(resource, "error.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result37.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result38 = await fhirpath.evaluate(resource, "DomainResource.all(contained.contained.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result38.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL NOT contain nested Resources");
    }
    const result39 = await fhirpath.evaluate(resource, "DomainResource.all(contained.where((('#'+id in (%resource.descendants().reference | %resource.descendants().as(canonical) | %resource.descendants().as(uri) | %resource.descendants().as(url))) or descendants().where(reference = '#').exists() or descendants().where(as(canonical) = '#').exists() or descendants().where(as(canonical) = '#').exists()).not()).trace('unmatched', id).empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result39.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL be referred to from elsewhere in the resource or SHALL refer to the containing resource");
    }
    const result40 = await fhirpath.evaluate(resource, "DomainResource.all(contained.meta.versionId.empty() and contained.meta.lastUpdated.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result40.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a meta.versionId or a meta.lastUpdated");
    }
    const result41 = await fhirpath.evaluate(resource, "DomainResource.all(contained.meta.security.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result41.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a security label");
    }
    const result42 = await fhirpath.evaluate(resource, "DomainResource.all(text.`div`.exists())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result42.every(Boolean)) {
        warnings.push("Constraint violation: A resource should have narrative for robust management");
    }
    const result43 = await fhirpath.evaluate(resource, "status.exists()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result43.every(Boolean)) {
        errors.push("Constraint violation: status must be present");
    }
    const result44 = await fhirpath.evaluate(resource, "type.exists()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result44.every(Boolean)) {
        errors.push("Constraint violation: type must be present");
    }
    const result45 = await fhirpath.evaluate(resource, "use.exists()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result45.every(Boolean)) {
        errors.push("Constraint violation: use must be present");
    }
    const result46 = await fhirpath.evaluate(resource, "patient.exists()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result46.every(Boolean)) {
        errors.push("Constraint violation: patient must be present");
    }
    const result47 = await fhirpath.evaluate(resource, "created.exists()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result47.every(Boolean)) {
        errors.push("Constraint violation: created must be present");
    }
    const result48 = await fhirpath.evaluate(resource, "insurer.exists()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result48.every(Boolean)) {
        errors.push("Constraint violation: insurer must be present");
    }
    const result49 = await fhirpath.evaluate(resource, "outcome.exists()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result49.every(Boolean)) {
        errors.push("Constraint violation: outcome must be present");
    }
    // Nested required field: item.itemSequence (min=1)
    if (resource.item && Array.isArray(resource.item)) {
        for (const _el of resource.item) {
            if ((_el.itemSequence === undefined || _el.itemSequence === null) || Array.isArray(_el.itemSequence)) {
                errors.push("Missing required member: 'itemSequence'");
            }
        }
    }
    // Nested required field: item.adjudication (min=1)
    if (resource.item && Array.isArray(resource.item)) {
        for (const _el of resource.item) {
            if (!_el.adjudication || _el.adjudication.length === 0) {
                errors.push("Missing required member: 'adjudication'");
            }
        }
    }
    // Nested required field: item.adjudication.category (min=1)
    if (resource.item && Array.isArray(resource.item)) {
        for (const _nrEl0 of resource.item) {
            if (_nrEl0.adjudication && Array.isArray(_nrEl0.adjudication)) {
                for (const _nrEl1 of _nrEl0.adjudication) {
                    if ((_nrEl1.category === undefined || _nrEl1.category === null) || Array.isArray(_nrEl1.category)) {
                        errors.push("Missing required member: 'category'");
                    }
                }
            }
        }
    }
    // Nested required field: item.detail.detailSequence (min=1)
    if (resource.item && Array.isArray(resource.item)) {
        for (const _nrEl0 of resource.item) {
            if (_nrEl0.detail && Array.isArray(_nrEl0.detail)) {
                for (const _nrEl1 of _nrEl0.detail) {
                    if ((_nrEl1.detailSequence === undefined || _nrEl1.detailSequence === null) || Array.isArray(_nrEl1.detailSequence)) {
                        errors.push("Missing required member: 'detailSequence'");
                    }
                }
            }
        }
    }
    // Nested required field: item.detail.adjudication (min=1)
    if (resource.item && Array.isArray(resource.item)) {
        for (const _nrEl0 of resource.item) {
            if (_nrEl0.detail && Array.isArray(_nrEl0.detail)) {
                for (const _nrEl1 of _nrEl0.detail) {
                    if (!_nrEl1.adjudication || _nrEl1.adjudication.length === 0) {
                        errors.push("Missing required member: 'adjudication'");
                    }
                }
            }
        }
    }
    // Nested required field: item.detail.subDetail.subDetailSequence (min=1)
    if (resource.item && Array.isArray(resource.item)) {
        for (const _nrEl0 of resource.item) {
            if (_nrEl0.detail && Array.isArray(_nrEl0.detail)) {
                for (const _nrEl1 of _nrEl0.detail) {
                    if (_nrEl1.subDetail && Array.isArray(_nrEl1.subDetail)) {
                        for (const _nrEl2 of _nrEl1.subDetail) {
                            if ((_nrEl2.subDetailSequence === undefined || _nrEl2.subDetailSequence === null) || Array.isArray(_nrEl2.subDetailSequence)) {
                                errors.push("Missing required member: 'subDetailSequence'");
                            }
                        }
                    }
                }
            }
        }
    }
    // Nested required field: addItem.productOrService (min=1)
    if (resource.addItem && Array.isArray(resource.addItem)) {
        for (const _el of resource.addItem) {
            if ((_el.productOrService === undefined || _el.productOrService === null) || Array.isArray(_el.productOrService)) {
                errors.push("Missing required member: 'productOrService'");
            }
        }
    }
    // Nested required field: addItem.adjudication (min=1)
    if (resource.addItem && Array.isArray(resource.addItem)) {
        for (const _el of resource.addItem) {
            if (!_el.adjudication || _el.adjudication.length === 0) {
                errors.push("Missing required member: 'adjudication'");
            }
        }
    }
    // Nested required field: addItem.detail.productOrService (min=1)
    if (resource.addItem && Array.isArray(resource.addItem)) {
        for (const _nrEl0 of resource.addItem) {
            if (_nrEl0.detail && Array.isArray(_nrEl0.detail)) {
                for (const _nrEl1 of _nrEl0.detail) {
                    if ((_nrEl1.productOrService === undefined || _nrEl1.productOrService === null) || Array.isArray(_nrEl1.productOrService)) {
                        errors.push("Missing required member: 'productOrService'");
                    }
                }
            }
        }
    }
    // Nested required field: addItem.detail.adjudication (min=1)
    if (resource.addItem && Array.isArray(resource.addItem)) {
        for (const _nrEl0 of resource.addItem) {
            if (_nrEl0.detail && Array.isArray(_nrEl0.detail)) {
                for (const _nrEl1 of _nrEl0.detail) {
                    if (!_nrEl1.adjudication || _nrEl1.adjudication.length === 0) {
                        errors.push("Missing required member: 'adjudication'");
                    }
                }
            }
        }
    }
    // Nested required field: addItem.detail.subDetail.productOrService (min=1)
    if (resource.addItem && Array.isArray(resource.addItem)) {
        for (const _nrEl0 of resource.addItem) {
            if (_nrEl0.detail && Array.isArray(_nrEl0.detail)) {
                for (const _nrEl1 of _nrEl0.detail) {
                    if (_nrEl1.subDetail && Array.isArray(_nrEl1.subDetail)) {
                        for (const _nrEl2 of _nrEl1.subDetail) {
                            if ((_nrEl2.productOrService === undefined || _nrEl2.productOrService === null) || Array.isArray(_nrEl2.productOrService)) {
                                errors.push("Missing required member: 'productOrService'");
                            }
                        }
                    }
                }
            }
        }
    }
    // Nested required field: addItem.detail.subDetail.adjudication (min=1)
    if (resource.addItem && Array.isArray(resource.addItem)) {
        for (const _nrEl0 of resource.addItem) {
            if (_nrEl0.detail && Array.isArray(_nrEl0.detail)) {
                for (const _nrEl1 of _nrEl0.detail) {
                    if (_nrEl1.subDetail && Array.isArray(_nrEl1.subDetail)) {
                        for (const _nrEl2 of _nrEl1.subDetail) {
                            if (!_nrEl2.adjudication || _nrEl2.adjudication.length === 0) {
                                errors.push("Missing required member: 'adjudication'");
                            }
                        }
                    }
                }
            }
        }
    }
    // Nested required field: total.category (min=1)
    if (resource.total && Array.isArray(resource.total)) {
        for (const _el of resource.total) {
            if ((_el.category === undefined || _el.category === null) || Array.isArray(_el.category)) {
                errors.push("Missing required member: 'category'");
            }
        }
    }
    // Nested required field: total.amount (min=1)
    if (resource.total && Array.isArray(resource.total)) {
        for (const _el of resource.total) {
            if ((_el.amount === undefined || _el.amount === null) || Array.isArray(_el.amount)) {
                errors.push("Missing required member: 'amount'");
            }
        }
    }
    // Nested required field: processNote.text (min=1)
    if (resource.processNote && Array.isArray(resource.processNote)) {
        for (const _el of resource.processNote) {
            if ((_el.text === undefined || _el.text === null) || Array.isArray(_el.text)) {
                errors.push("Missing required member: 'text'");
            }
        }
    }
    // Nested required field: insurance.sequence (min=1)
    if (resource.insurance && Array.isArray(resource.insurance)) {
        for (const _el of resource.insurance) {
            if ((_el.sequence === undefined || _el.sequence === null) || Array.isArray(_el.sequence)) {
                errors.push("Missing required member: 'sequence'");
            }
        }
    }
    // Nested required field: insurance.focal (min=1)
    if (resource.insurance && Array.isArray(resource.insurance)) {
        for (const _el of resource.insurance) {
            if ((_el.focal === undefined || _el.focal === null) || Array.isArray(_el.focal)) {
                errors.push("Missing required member: 'focal'");
            }
        }
    }
    // Nested required field: insurance.coverage (min=1)
    if (resource.insurance && Array.isArray(resource.insurance)) {
        for (const _el of resource.insurance) {
            if ((_el.coverage === undefined || _el.coverage === null) || Array.isArray(_el.coverage)) {
                errors.push("Missing required member: 'coverage'");
            }
        }
    }
    // Nested required field: error.code (min=1)
    if (resource.error && Array.isArray(resource.error)) {
        for (const _el of resource.error) {
            if ((_el.code === undefined || _el.code === null) || Array.isArray(_el.code)) {
                errors.push("Missing required member: 'code'");
            }
        }
    }
    // Fixed value constraint for status
    if (resource.status !== undefined && resource.status !== "active") {
        errors.push("status must have the fixed value 'active'");
    }
    // Fixed value constraint for use
    if (resource.use !== undefined && resource.use !== "preauthorization") {
        errors.push("use must have the fixed value 'preauthorization'");
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const _bRes = resource;
    // Required ValueSet binding validation for status
    if (_bRes.status !== undefined && !isValidFmStatusCode(_bRes.status)) {
        errors.push("Code '" + _bRes.status + "' does not exist in the value set 'fm-status' (http://hl7.org/fhir/ValueSet/fm-status), but the binding is of strength 'required'");
    }
    // Required ValueSet binding validation for use
    if (_bRes.use !== undefined && !isValidClaimUseCode(_bRes.use)) {
        errors.push("Code '" + _bRes.use + "' does not exist in the value set 'claim-use' (http://hl7.org/fhir/ValueSet/claim-use), but the binding is of strength 'required'");
    }
    // Required ValueSet binding validation for outcome
    if (_bRes.outcome !== undefined && !isValidRemittanceOutcomeCode(_bRes.outcome)) {
        errors.push("Code '" + _bRes.outcome + "' does not exist in the value set 'remittance-outcome' (http://hl7.org/fhir/ValueSet/remittance-outcome), but the binding is of strength 'required'");
    }
    // Required ValueSet binding validation for processNote.type (nested)
    if (resource.processNote && Array.isArray(resource.processNote)) {
        for (const _nb0 of resource.processNote) {
            if (_nb0.type !== undefined && !isValidNoteTypeCode(_nb0.type)) {
                errors.push("Code '" + _nb0.type + "' does not exist in the value set 'note-type' (http://hl7.org/fhir/ValueSet/note-type), but the binding is of strength 'required'");
            }
        }
    }
    // Required ValueSet system-level binding validation for error.code (nested)
    if (resource.error && Array.isArray(resource.error)) {
        for (const _nb0 of resource.error) {
            {
                const _sccCoding = _nb0.code?.coding;
                if (_sccCoding && _sccCoding.some((_c) => _c.code !== undefined)) {
                    const _allowedSystems = ["https://codesystem.x12.org/005010/901"];
                    if (!_sccCoding.some((_c) => _c.system !== undefined && _allowedSystems.includes(_c.system))) {
                        const _codes = _sccCoding.filter((_c) => _c.code !== undefined).map((_c) => (_c.system || "") + "#" + _c.code).join(", ");
                        errors.push("None of the codings provided are in the value set 'X12278RejectReasonCodes' (http://hl7.org/fhir/us/davinci-pas/ValueSet/X12278RejectReasonCodes), and a coding from this value set is required) (codes = " + _codes + ")");
                    }
                }
            }
        }
    }
    // dateTime format validation for created
    if (typeof _bRes.created === 'string' && !/^\d{4}(-\d{2}(-\d{2}(T\d{2}:\d{2}(:\d{2}(\.\d+)?)?(Z|[+-]\d{2}:\d{2})?)?)?)?$/.test(_bRes.created)) {
        errors.push("Not a valid date/time format: '" + _bRes.created + "'");
    }
    // Profiled datatype delegation: identifier → PASIdentifier
    if (resource.identifier && Array.isArray(resource.identifier)) {
        for (const _dtEl of resource.identifier) {
            const _sub = await validatePASIdentifier(_dtEl, options);
            errors.push(..._sub.errors);
            warnings.push(..._sub.warnings);
        }
    }
    // Base FHIR structural validation: extension.url required, ext-1 constraint, empty objects
    {
        const _checkExtensions = (obj, path, depth) => {
            if (!obj || typeof obj !== 'object')
                return;
            if (Array.isArray(obj)) {
                obj.forEach((item, i) => _checkExtensions(item, path + '[' + i + ']', depth + 1));
                return;
            }
            const rec = obj;
            // Empty object check — HL7 validates all FHIR elements must have content
            if (depth > 0 && Object.keys(rec).length === 0) {
                errors.push('Object must have some content');
            }
            // per-1: If present, start SHALL have a lower value than end (Period structural check)
            if (typeof rec.start === 'string' && typeof rec.end === 'string' && rec.start > rec.end) {
                errors.push('If present, start SHALL have a lower value than end');
            }
            // Validate extension arrays
            for (const extKey of ['extension', 'modifierExtension']) {
                const exts = rec[extKey];
                if (Array.isArray(exts)) {
                    for (const ext of exts) {
                        if (ext && typeof ext === 'object' && !Array.isArray(ext)) {
                            const e = ext;
                            if (typeof e.url !== 'string' || !e.url) {
                                errors.push('Extension.url is required in order to identify, use and validate the extension');
                            }
                            // ext-1: Must have either extensions or value[x], not both
                            const hasNestedExt = Array.isArray(e.extension) && e.extension.length > 0;
                            const hasValue = Object.keys(e).some(k => k.startsWith('value') && k !== 'value' && k.length > 5);
                            if (hasNestedExt && hasValue) {
                                errors.push('Must have either extensions or value[x], not both');
                            }
                        }
                    }
                }
            }
            // Recurse into child objects (skip primitive values)
            for (const [_key, _val] of Object.entries(rec)) {
                if (_val && typeof _val === 'object') {
                    _checkExtensions(_val, path + '.' + _key, depth + 1);
                }
            }
        };
        _checkExtensions(resource, '', 0);
    }
    // Standalone contained reference resolution: verify #id references resolve to contained[] entries
    {
        const _res = resource;
        const _containedIds = new Set();
        if (Array.isArray(_res.contained)) {
            for (const _c of _res.contained) {
                if (_c && typeof _c.id === 'string')
                    _containedIds.add(_c.id);
            }
        }
        const _checkContainedRef = (obj) => {
            if (!obj || typeof obj !== 'object')
                return;
            if (Array.isArray(obj)) {
                obj.forEach(_checkContainedRef);
                return;
            }
            const _rec = obj;
            if (typeof _rec.reference === 'string') {
                const _ref = _rec.reference;
                if (_ref.startsWith('#')) {
                    const _id = _ref.substring(1);
                    if (_id && !_containedIds.has(_id)) {
                        errors.push('Contained reference not found: ' + _ref);
                    }
                }
            }
            for (const [_k, _v] of Object.entries(_rec)) {
                if (_k !== 'contained')
                    _checkContainedRef(_v);
            }
        };
        _checkContainedRef(_res);
    }
    return { errors, warnings };
}
