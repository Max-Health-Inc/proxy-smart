/**
 * ValueSet Registry
 * Central registry of all loaded ValueSets with explicit codes
 */
import * as AdministrativeGender from './ValueSet-AdministrativeGender.js';
import * as AllergyIntoleranceType from './ValueSet-AllergyIntoleranceType.js';
import * as BodySite from './ValueSet-BodySite.js';
import * as BundleType from './ValueSet-BundleType.js';
import * as ClinicalFindings from './ValueSet-ClinicalFindings.js';
import * as CompositionStatus from './ValueSet-CompositionStatus.js';
import * as ConditionCode from './ValueSet-ConditionCode.js';
import * as CurrentSmokingStatusUvIps from './ValueSet-CurrentSmokingStatusUvIps.js';
import * as DaysOfWeek from './ValueSet-DaysOfWeek.js';
import * as DiagnosticReportStatusUvIps from './ValueSet-DiagnosticReportStatusUvIps.js';
import * as EventStatus from './ValueSet-EventStatus.js';
import * as FlagStatus from './ValueSet-FlagStatus.js';
import * as HttpVerb from './ValueSet-HttpVerb.js';
import * as ImmunizationStatus from './ValueSet-ImmunizationStatus.js';
import * as LinkType from './ValueSet-LinkType.js';
import * as MedicationrequestStatus from './ValueSet-MedicationrequestStatus.js';
import * as MedicationsExampleUvIps from './ValueSet-MedicationsExampleUvIps.js';
import * as MedicationStatus from './ValueSet-MedicationStatus.js';
import * as NameUse from './ValueSet-NameUse.js';
import * as ObservationCodes from './ValueSet-ObservationCodes.js';
import * as ObservationMethods from './ValueSet-ObservationMethods.js';
import * as ObservationStatus from './ValueSet-ObservationStatus.js';
import * as PersonalRelationshipUvIps from './ValueSet-PersonalRelationshipUvIps.js';
import * as PregnanciesSummaryUvIps from './ValueSet-PregnanciesSummaryUvIps.js';
import * as PregnancyExpectedDeliveryDateMethodUvIps from './ValueSet-PregnancyExpectedDeliveryDateMethodUvIps.js';
import * as PregnancyStatusUvIps from './ValueSet-PregnancyStatusUvIps.js';
import * as ProblemTypeLoinc from './ValueSet-ProblemTypeLoinc.js';
import * as ProblemTypeUvIps from './ValueSet-ProblemTypeUvIps.js';
import * as RequestPriority from './ValueSet-RequestPriority.js';
import * as ResultsRadiologyComponentUvIps from './ValueSet-ResultsRadiologyComponentUvIps.js';
import * as ResultsStatusUvIps from './ValueSet-ResultsStatusUvIps.js';
import * as SpecimenStatus from './ValueSet-SpecimenStatus.js';
import * as VaccineTargetDiseasesUvIps from './ValueSet-VaccineTargetDiseasesUvIps.js';
export declare const ValueSetRegistry: {
    readonly AdministrativeGender: typeof AdministrativeGender;
    readonly AllergyIntoleranceType: typeof AllergyIntoleranceType;
    readonly BodySite: typeof BodySite;
    readonly BundleType: typeof BundleType;
    readonly ClinicalFindings: typeof ClinicalFindings;
    readonly CompositionStatus: typeof CompositionStatus;
    readonly ConditionCode: typeof ConditionCode;
    readonly CurrentSmokingStatusUvIps: typeof CurrentSmokingStatusUvIps;
    readonly DaysOfWeek: typeof DaysOfWeek;
    readonly DiagnosticReportStatusUvIps: typeof DiagnosticReportStatusUvIps;
    readonly EventStatus: typeof EventStatus;
    readonly FlagStatus: typeof FlagStatus;
    readonly HttpVerb: typeof HttpVerb;
    readonly ImmunizationStatus: typeof ImmunizationStatus;
    readonly LinkType: typeof LinkType;
    readonly MedicationrequestStatus: typeof MedicationrequestStatus;
    readonly MedicationsExampleUvIps: typeof MedicationsExampleUvIps;
    readonly MedicationStatus: typeof MedicationStatus;
    readonly NameUse: typeof NameUse;
    readonly ObservationCodes: typeof ObservationCodes;
    readonly ObservationMethods: typeof ObservationMethods;
    readonly ObservationStatus: typeof ObservationStatus;
    readonly PersonalRelationshipUvIps: typeof PersonalRelationshipUvIps;
    readonly PregnanciesSummaryUvIps: typeof PregnanciesSummaryUvIps;
    readonly PregnancyExpectedDeliveryDateMethodUvIps: typeof PregnancyExpectedDeliveryDateMethodUvIps;
    readonly PregnancyStatusUvIps: typeof PregnancyStatusUvIps;
    readonly ProblemTypeLoinc: typeof ProblemTypeLoinc;
    readonly ProblemTypeUvIps: typeof ProblemTypeUvIps;
    readonly RequestPriority: typeof RequestPriority;
    readonly ResultsRadiologyComponentUvIps: typeof ResultsRadiologyComponentUvIps;
    readonly ResultsStatusUvIps: typeof ResultsStatusUvIps;
    readonly SpecimenStatus: typeof SpecimenStatus;
    readonly VaccineTargetDiseasesUvIps: typeof VaccineTargetDiseasesUvIps;
};
export type ValueSetName = keyof typeof ValueSetRegistry;
export declare function getValueSet(name: ValueSetName): typeof AdministrativeGender | typeof AllergyIntoleranceType | typeof BodySite | typeof BundleType | typeof ClinicalFindings | typeof CompositionStatus | typeof ConditionCode | typeof CurrentSmokingStatusUvIps | typeof DaysOfWeek | typeof DiagnosticReportStatusUvIps | typeof EventStatus | typeof FlagStatus | typeof HttpVerb | typeof ImmunizationStatus | typeof LinkType | typeof MedicationrequestStatus | typeof MedicationsExampleUvIps | typeof MedicationStatus | typeof NameUse | typeof ObservationCodes | typeof ObservationMethods | typeof ObservationStatus | typeof PersonalRelationshipUvIps | typeof PregnanciesSummaryUvIps | typeof PregnancyExpectedDeliveryDateMethodUvIps | typeof PregnancyStatusUvIps | typeof ProblemTypeLoinc | typeof ProblemTypeUvIps | typeof RequestPriority | typeof ResultsRadiologyComponentUvIps | typeof ResultsStatusUvIps | typeof SpecimenStatus | typeof VaccineTargetDiseasesUvIps;
/** Map from ValueSet URL to registry name */
export declare const ValueSetUrlMap: Record<string, ValueSetName>;
/**
 * Get a random code from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A random code string, or undefined if ValueSet not found
 */
export declare function getRandomCodeByUrl(url: string): string | undefined;
/**
 * Get a random concept (code, system, display) from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A concept object with code, system, and optional display, or undefined if ValueSet not found
 */
export declare function getRandomConceptByUrl(url: string): {
    code: string;
    system: string;
    display?: string;
} | undefined;
