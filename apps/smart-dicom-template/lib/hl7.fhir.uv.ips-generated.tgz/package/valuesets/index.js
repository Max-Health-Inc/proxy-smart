/**
 * ValueSet Registry
 * Central registry of all loaded ValueSets with explicit codes
 */
import * as AdministrativeGender from './ValueSet-AdministrativeGender.js';
import * as AllergyIntoleranceType from './ValueSet-AllergyIntoleranceType.js';
import * as BodySite from './ValueSet-BodySite.js';
import * as BundleType from './ValueSet-BundleType.js';
import * as ClinicalFindings from './ValueSet-ClinicalFindings.js';
import * as CompositionStatus from './ValueSet-CompositionStatus.js';
import * as ConditionCode from './ValueSet-ConditionCode.js';
import * as CurrentSmokingStatusUvIps from './ValueSet-CurrentSmokingStatusUvIps.js';
import * as DaysOfWeek from './ValueSet-DaysOfWeek.js';
import * as DiagnosticReportStatusUvIps from './ValueSet-DiagnosticReportStatusUvIps.js';
import * as EventStatus from './ValueSet-EventStatus.js';
import * as FlagStatus from './ValueSet-FlagStatus.js';
import * as HttpVerb from './ValueSet-HttpVerb.js';
import * as ImmunizationStatus from './ValueSet-ImmunizationStatus.js';
import * as LinkType from './ValueSet-LinkType.js';
import * as MedicationrequestStatus from './ValueSet-MedicationrequestStatus.js';
import * as MedicationsExampleUvIps from './ValueSet-MedicationsExampleUvIps.js';
import * as MedicationStatus from './ValueSet-MedicationStatus.js';
import * as NameUse from './ValueSet-NameUse.js';
import * as ObservationCodes from './ValueSet-ObservationCodes.js';
import * as ObservationMethods from './ValueSet-ObservationMethods.js';
import * as ObservationStatus from './ValueSet-ObservationStatus.js';
import * as PersonalRelationshipUvIps from './ValueSet-PersonalRelationshipUvIps.js';
import * as PregnanciesSummaryUvIps from './ValueSet-PregnanciesSummaryUvIps.js';
import * as PregnancyExpectedDeliveryDateMethodUvIps from './ValueSet-PregnancyExpectedDeliveryDateMethodUvIps.js';
import * as PregnancyStatusUvIps from './ValueSet-PregnancyStatusUvIps.js';
import * as ProblemTypeLoinc from './ValueSet-ProblemTypeLoinc.js';
import * as ProblemTypeUvIps from './ValueSet-ProblemTypeUvIps.js';
import * as RequestPriority from './ValueSet-RequestPriority.js';
import * as ResultsRadiologyComponentUvIps from './ValueSet-ResultsRadiologyComponentUvIps.js';
import * as ResultsStatusUvIps from './ValueSet-ResultsStatusUvIps.js';
import * as SpecimenStatus from './ValueSet-SpecimenStatus.js';
import * as VaccineTargetDiseasesUvIps from './ValueSet-VaccineTargetDiseasesUvIps.js';
export const ValueSetRegistry = {
    AdministrativeGender,
    AllergyIntoleranceType,
    BodySite,
    BundleType,
    ClinicalFindings,
    CompositionStatus,
    ConditionCode,
    CurrentSmokingStatusUvIps,
    DaysOfWeek,
    DiagnosticReportStatusUvIps,
    EventStatus,
    FlagStatus,
    HttpVerb,
    ImmunizationStatus,
    LinkType,
    MedicationrequestStatus,
    MedicationsExampleUvIps,
    MedicationStatus,
    NameUse,
    ObservationCodes,
    ObservationMethods,
    ObservationStatus,
    PersonalRelationshipUvIps,
    PregnanciesSummaryUvIps,
    PregnancyExpectedDeliveryDateMethodUvIps,
    PregnancyStatusUvIps,
    ProblemTypeLoinc,
    ProblemTypeUvIps,
    RequestPriority,
    ResultsRadiologyComponentUvIps,
    ResultsStatusUvIps,
    SpecimenStatus,
    VaccineTargetDiseasesUvIps,
};
export function getValueSet(name) {
    return ValueSetRegistry[name];
}
/** Map from ValueSet URL to registry name */
export const ValueSetUrlMap = {
    'http://hl7.org/fhir/ValueSet/administrative-gender': 'AdministrativeGender',
    'http://hl7.org/fhir/ValueSet/allergy-intolerance-type': 'AllergyIntoleranceType',
    'http://hl7.org/fhir/ValueSet/body-site': 'BodySite',
    'http://hl7.org/fhir/ValueSet/bundle-type': 'BundleType',
    'http://hl7.org/fhir/ValueSet/clinical-findings': 'ClinicalFindings',
    'http://hl7.org/fhir/ValueSet/composition-status': 'CompositionStatus',
    'http://hl7.org/fhir/ValueSet/condition-code': 'ConditionCode',
    'http://hl7.org/fhir/uv/ips/ValueSet/current-smoking-status-uv-ips': 'CurrentSmokingStatusUvIps',
    'http://hl7.org/fhir/ValueSet/days-of-week': 'DaysOfWeek',
    'http://hl7.org/fhir/uv/ips/ValueSet/diagnostics-report-status-uv-ips': 'DiagnosticReportStatusUvIps',
    'http://hl7.org/fhir/ValueSet/event-status': 'EventStatus',
    'http://hl7.org/fhir/ValueSet/flag-status': 'FlagStatus',
    'http://hl7.org/fhir/ValueSet/http-verb': 'HttpVerb',
    'http://hl7.org/fhir/ValueSet/immunization-status': 'ImmunizationStatus',
    'http://hl7.org/fhir/ValueSet/link-type': 'LinkType',
    'http://hl7.org/fhir/ValueSet/medicationrequest-status': 'MedicationrequestStatus',
    'http://hl7.org/fhir/uv/ips/ValueSet/medication-example-uv-ips': 'MedicationsExampleUvIps',
    'http://hl7.org/fhir/ValueSet/medication-status': 'MedicationStatus',
    'http://hl7.org/fhir/ValueSet/name-use': 'NameUse',
    'http://hl7.org/fhir/ValueSet/observation-codes': 'ObservationCodes',
    'http://hl7.org/fhir/ValueSet/observation-methods': 'ObservationMethods',
    'http://hl7.org/fhir/ValueSet/observation-status': 'ObservationStatus',
    'http://hl7.org/fhir/uv/ips/ValueSet/personal-relationship-uv-ips': 'PersonalRelationshipUvIps',
    'http://hl7.org/fhir/uv/ips/ValueSet/pregnancies-summary-uv-ips': 'PregnanciesSummaryUvIps',
    'http://hl7.org/fhir/uv/ips/ValueSet/edd-method-uv-ips': 'PregnancyExpectedDeliveryDateMethodUvIps',
    'http://hl7.org/fhir/uv/ips/ValueSet/pregnancy-status-uv-ips': 'PregnancyStatusUvIps',
    'http://hl7.org/fhir/uv/ips/ValueSet/problem-type-loinc': 'ProblemTypeLoinc',
    'http://hl7.org/fhir/uv/ips/ValueSet/problem-type-uv-ips': 'ProblemTypeUvIps',
    'http://hl7.org/fhir/ValueSet/request-priority': 'RequestPriority',
    'http://hl7.org/fhir/uv/ips/ValueSet/results-radiology-component-uv-ips': 'ResultsRadiologyComponentUvIps',
    'http://hl7.org/fhir/uv/ips/ValueSet/results-status-uv-ips': 'ResultsStatusUvIps',
    'http://hl7.org/fhir/ValueSet/specimen-status': 'SpecimenStatus',
    'http://hl7.org/fhir/uv/ips/ValueSet/target-diseases-uv-ips': 'VaccineTargetDiseasesUvIps',
};
function stripVersionFromUrl(url) {
    const pipeIndex = url.indexOf('|');
    return pipeIndex >= 0 ? url.substring(0, pipeIndex) : url;
}
/**
 * Get a random code from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A random code string, or undefined if ValueSet not found
 */
export function getRandomCodeByUrl(url) {
    const cleanUrl = stripVersionFromUrl(url);
    const name = ValueSetUrlMap[cleanUrl];
    if (!name)
        return undefined;
    const vs = ValueSetRegistry[name];
    // Each ValueSet exports random<Name>Code() function
    const randomFn = vs['random' + name + 'Code'];
    return randomFn?.();
}
/**
 * Get a random concept (code, system, display) from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A concept object with code, system, and optional display, or undefined if ValueSet not found
 */
export function getRandomConceptByUrl(url) {
    const cleanUrl = stripVersionFromUrl(url);
    const name = ValueSetUrlMap[cleanUrl];
    if (!name)
        return undefined;
    const vs = ValueSetRegistry[name];
    // Each ValueSet exports random<Name>Concept() function
    const randomFn = vs['random' + name + 'Concept'];
    return randomFn?.();
}
