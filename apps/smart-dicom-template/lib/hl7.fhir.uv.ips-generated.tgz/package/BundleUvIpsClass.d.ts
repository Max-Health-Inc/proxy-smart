import { BundleUvIps } from "./BundleUvIps.js";
import type { ValidatorOptions } from "./ValidatorOptions.js";
export declare class BundleUvIpsClass {
    private resource;
    /** Pattern constraints for profile fields (used by random() generator) */
    protected static readonly _fieldPatterns: {
        type: string;
        "entry.request.method": string;
        "composition.request.method": string;
        "patient.request.method": string;
        "allergyintolerance.request.method": string;
        "careplan.request.method": string;
        "clinicalimpression.request.method": string;
        "condition.request.method": string;
        "consent.request.method": string;
        "device.request.method": string;
        "deviceusestatement.request.method": string;
        "diagnosticreport.request.method": string;
        "documentreference.request.method": string;
        "flag.request.method": string;
        "imagingstudy.request.method": string;
        "immunization.request.method": string;
        "immunizationrecommendation.request.method": string;
        "medication.request.method": string;
        "medicationrequest.request.method": string;
        "medicationstatement.request.method": string;
        "practitioner.request.method": string;
        "practitionerrole.request.method": string;
        "procedure.request.method": string;
        "observation-pregnancy-edd.request.method": string;
        "observation-pregnancy-outcome.request.method": string;
        "observation-pregnancy-status.request.method": string;
        "observation-alcohol-use.request.method": string;
        "observation-tobacco-use.request.method": string;
        "observation-results-laboratory-pathology.request.method": string;
        "observation-results-radiology.request.method": string;
        "observation-vital-signs.request.method": string;
        "organization.request.method": string;
        "specimen.request.method": string;
        _refReq_link: {
            relation: boolean;
            url: boolean;
        };
        _refReq_entry: {
            fullUrl: boolean;
            "request.method": boolean;
            "request.url": boolean;
            "response.status": boolean;
            resource: boolean;
        };
        "_entryProfile:Patient": {
            profile: string;
        };
    };
    /** Fields that are forbidden (max=0) in this profile - must not be generated */
    protected static readonly _forbiddenFields: string[];
    /** FHIR element ordering for this profile's base resource (used by enrichResource for correct JSON field order) */
    protected static readonly _fieldOrder: string[];
    /** ValueSet bindings for coded fields - maps field name to ValueSet URL */
    static readonly valueSetBindings: Record<string, string>;
    /** Code resolver for ValueSet bindings - returns a random valid code from a ValueSet by URL */
    protected static readonly _codeResolver: ((url: string) => {
        code: string;
        system: string;
        display?: string;
    } | undefined) | undefined;
    constructor(resource: BundleUvIps);
    /** Validate current resource instance. */
    validate(options?: ValidatorOptions): Promise<{
        errors: string[];
        warnings: string[];
    }>;
    getResource(): BundleUvIps;
    setResource(resource: BundleUvIps): void;
    /**
     * Returns a plain JSON clone of the underlying resource ONLY if the last validation succeeded with zero errors.
     * Call validate() first; otherwise this method throws to prevent accidental use of invalid / unchecked data.
     */
    toJSON(): Promise<BundleUvIps>;
    /**
     * Create an empty instance for parity testing: for true FHIR resources, includes only resourceType; for datatypes, returns an empty object.
     * Note: meta.profile (when applicable) will be ensured by the constructor when wrapping this resource.
     */
    static empty(overrides?: Partial<BundleUvIps>): BundleUvIps;
    /**
     * Create a minimal randomized instance of BundleUvIps.
     * Populates id, resourceType (if applicable) and primitive required (min>0) top-level fields with placeholders.
     */
    static random(overrides?: Partial<BundleUvIps>, opts?: {
        seed?: number;
    }): BundleUvIps;
    /** Convenience: returns a class instance wrapping a randomized resource. */
    static randomClass(overrides?: Partial<BundleUvIps>, opts?: {
        seed?: number;
    }): BundleUvIpsClass;
}
