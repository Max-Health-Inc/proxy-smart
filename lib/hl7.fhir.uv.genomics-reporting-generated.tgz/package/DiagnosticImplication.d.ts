import { BodyStructureReference } from "./BodyStructureReference";
import { CodeableConcept, Coding, Extension, Observation, ObservationComponent } from "fhir/r4";
import { GenomicRiskAssessment } from "./GenomicRiskAssessment";
import { SecondaryFinding } from "./SecondaryFinding";
import { RelatedArtifactComponent } from "./RelatedArtifactComponent";
import { RelatedArtifactExtension } from "./RelatedArtifactExtension";
export interface WorkflowRelatedArtifactComponent extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/workflow-relatedArtifactComponent';
}
export interface DiagnosticImplicationCodeCoding extends Omit<Coding, 'system' | 'code'> {
    system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs";
    code: "diagnostic-implication";
}
export interface DiagnosticImplicationComponent extends Omit<ObservationComponent, 'code' | 'extension'> {
    /** @see {@link ./valuesets/ValueSet-LOINCCodes.ts} for valid codes (100 codes) */
    code: CodeableConcept;
    extension?: (Extension | RelatedArtifactComponent | RelatedArtifactComponent | RelatedArtifactComponent | RelatedArtifactComponent)[];
}
export interface DiagnosticImplication extends Omit<Observation, 'code' | 'component' | 'extension'> {
    resourceType: 'Observation';
    code: {
        coding: DiagnosticImplicationCodeCoding[];
    };
    component?: DiagnosticImplicationComponent[];
    extension?: (Extension | SecondaryFinding | BodyStructureReference | RelatedArtifactExtension | GenomicRiskAssessment)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateDiagnosticImplication(resource: DiagnosticImplication, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
