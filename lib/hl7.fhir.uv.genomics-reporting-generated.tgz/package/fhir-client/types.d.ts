import type * as GeneratedTypes from "../index.js";
/**
 * A FHIR resource with an ID
 */
export type WithId<T> = {
    id: string;
} & T;
/**
 * Search parameter value type — all values are serialized to query strings.
 */
export type SearchParamValue = boolean | number | string | string[] | undefined;
/**
 * Search parameters for FHIR resources (generic untyped version).
 */
export type SearchParams = Record<string, SearchParamValue>;
/**
 * Common search parameters supported by all FHIR resources.
 * Includes an index signature to allow search parameter modifiers (e.g. name:exact).
 */
export interface CommonSearchParams {
    _id?: SearchParamValue;
    _lastUpdated?: SearchParamValue;
    _tag?: SearchParamValue;
    _profile?: SearchParamValue;
    _security?: SearchParamValue;
    _count?: SearchParamValue;
    _sort?: SearchParamValue;
    _include?: SearchParamValue;
    _revinclude?: SearchParamValue;
    _summary?: SearchParamValue;
    _elements?: SearchParamValue;
    _total?: SearchParamValue;
    [key: string]: SearchParamValue;
}
/**
 * Bundle of FHIR resources
 */
export interface Bundle<T> {
    resourceType: "Bundle";
    type: "collection" | "searchset" | "transaction-response" | "transaction";
    total?: number;
    link?: {
        relation: string;
        url: string;
    }[];
    entry?: {
        resource: T;
        fullUrl?: string;
    }[];
}
/**
 * Type-safe FHIR resource types
 */
export type FhirResource = GeneratedTypes.DiagnosticImplication | GeneratedTypes.FollowupRecommendation | GeneratedTypes.GenomicBase | GeneratedTypes.GenomicFinding | GeneratedTypes.GenomicImplication | GeneratedTypes.GenomicReport | GeneratedTypes.GenomicStudy | GeneratedTypes.GenomicStudyAnalysis | GeneratedTypes.Genotype | GeneratedTypes.Haplotype | GeneratedTypes.MedicationRecommendation | GeneratedTypes.MolecularConsequence | GeneratedTypes.SequencePhaseRelationship | GeneratedTypes.TherapeuticImplication | GeneratedTypes.Variant;
/**
 * Typed search parameters for Observation resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface ObservationSearchParams extends CommonSearchParams {
    "amino-acid-change"?: SearchParamValue;
    "based-on"?: SearchParamValue;
    "category"?: SearchParamValue;
    "code"?: SearchParamValue;
    "code-value-concept"?: SearchParamValue;
    "code-value-date"?: SearchParamValue;
    "code-value-quantity"?: SearchParamValue;
    "code-value-string"?: SearchParamValue;
    "combo-code"?: SearchParamValue;
    "combo-code-value-concept"?: SearchParamValue;
    "combo-code-value-quantity"?: SearchParamValue;
    "combo-data-absent-reason"?: SearchParamValue;
    "combo-value-concept"?: SearchParamValue;
    "combo-value-quantity"?: SearchParamValue;
    "component-code"?: SearchParamValue;
    "component-code-value-concept"?: SearchParamValue;
    "component-code-value-quantity"?: SearchParamValue;
    "component-data-absent-reason"?: SearchParamValue;
    "component-value-concept"?: SearchParamValue;
    "component-value-quantity"?: SearchParamValue;
    "data-absent-reason"?: SearchParamValue;
    "date"?: SearchParamValue;
    "derived-from"?: SearchParamValue;
    "device"?: SearchParamValue;
    "dna-variant"?: SearchParamValue;
    "encounter"?: SearchParamValue;
    "focus"?: SearchParamValue;
    "gene-amino-acid-change"?: SearchParamValue;
    "gene-dnavariant"?: SearchParamValue;
    "gene-identifier"?: SearchParamValue;
    "has-member"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "method"?: SearchParamValue;
    "part-of"?: SearchParamValue;
    "patient"?: SearchParamValue;
    "performer"?: SearchParamValue;
    "specimen"?: SearchParamValue;
    "status"?: SearchParamValue;
    "subject"?: SearchParamValue;
    "value-concept"?: SearchParamValue;
    "value-date"?: SearchParamValue;
    "value-quantity"?: SearchParamValue;
    "value-string"?: SearchParamValue;
}
/**
 * Typed search parameters for Task resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface TaskSearchParams extends CommonSearchParams {
    "authored-on"?: SearchParamValue;
    "based-on"?: SearchParamValue;
    "business-status"?: SearchParamValue;
    "code"?: SearchParamValue;
    "encounter"?: SearchParamValue;
    "focus"?: SearchParamValue;
    "group-identifier"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "intent"?: SearchParamValue;
    "modified"?: SearchParamValue;
    "owner"?: SearchParamValue;
    "part-of"?: SearchParamValue;
    "patient"?: SearchParamValue;
    "performer"?: SearchParamValue;
    "period"?: SearchParamValue;
    "priority"?: SearchParamValue;
    "requester"?: SearchParamValue;
    "status"?: SearchParamValue;
    "subject"?: SearchParamValue;
}
/**
 * Typed search parameters for DiagnosticReport resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface DiagnosticReportSearchParams extends CommonSearchParams {
    "assessed-condition"?: SearchParamValue;
    "based-on"?: SearchParamValue;
    "category"?: SearchParamValue;
    "code"?: SearchParamValue;
    "conclusion"?: SearchParamValue;
    "date"?: SearchParamValue;
    "encounter"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "issued"?: SearchParamValue;
    "media"?: SearchParamValue;
    "patient"?: SearchParamValue;
    "performer"?: SearchParamValue;
    "result"?: SearchParamValue;
    "results-interpreter"?: SearchParamValue;
    "specimen"?: SearchParamValue;
    "status"?: SearchParamValue;
    "subject"?: SearchParamValue;
}
/**
 * Typed search parameters for Procedure resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface ProcedureSearchParams extends CommonSearchParams {
    "based-on"?: SearchParamValue;
    "category"?: SearchParamValue;
    "code"?: SearchParamValue;
    "date"?: SearchParamValue;
    "encounter"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "instantiates-canonical"?: SearchParamValue;
    "instantiates-uri"?: SearchParamValue;
    "location"?: SearchParamValue;
    "part-of"?: SearchParamValue;
    "patient"?: SearchParamValue;
    "performer"?: SearchParamValue;
    "reason-code"?: SearchParamValue;
    "reason-reference"?: SearchParamValue;
    "status"?: SearchParamValue;
    "subject"?: SearchParamValue;
}
