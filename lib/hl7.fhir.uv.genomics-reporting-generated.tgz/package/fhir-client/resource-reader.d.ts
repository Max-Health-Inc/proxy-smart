import type * as GeneratedTypes from "../index.js";
import type { Bundle, DiagnosticReportSearchParams, ObservationSearchParams, ProcedureSearchParams, SearchParams, TaskSearchParams, WithId } from "./types.js";
/**
 * Generic FHIR resource searcher/reader
 */
export interface FhirResourceSearcher<T, S extends SearchParams = SearchParams> {
    readonly baseUrl: string;
    readonly resourceType: string;
    /**
     * Read a resource by ID
     */
    read(id: string): Promise<WithId<T>>;
    /**
     * Search for resources
     */
    search(params?: S): Promise<Bundle<WithId<T>>>;
    /**
     * Search and return first result or undefined
     */
    searchOne(params?: S): Promise<undefined | WithId<T>>;
    /**
     * Search and return all results (handles pagination)
     */
    searchAll(params?: S): Promise<WithId<T>[]>;
}
/**
 * Specific reader types for type safety
 */
export type DiagnosticImplicationReader = FhirResourceSearcher<GeneratedTypes.DiagnosticImplication, ObservationSearchParams>;
export type FollowupRecommendationReader = FhirResourceSearcher<GeneratedTypes.FollowupRecommendation, TaskSearchParams>;
export type GenomicBaseReader = FhirResourceSearcher<GeneratedTypes.GenomicBase, ObservationSearchParams>;
export type GenomicFindingReader = FhirResourceSearcher<GeneratedTypes.GenomicFinding, ObservationSearchParams>;
export type GenomicImplicationReader = FhirResourceSearcher<GeneratedTypes.GenomicImplication, ObservationSearchParams>;
export type GenomicReportReader = FhirResourceSearcher<GeneratedTypes.GenomicReport, DiagnosticReportSearchParams>;
export type GenomicStudyReader = FhirResourceSearcher<GeneratedTypes.GenomicStudy, ProcedureSearchParams>;
export type GenomicStudyAnalysisReader = FhirResourceSearcher<GeneratedTypes.GenomicStudyAnalysis, ProcedureSearchParams>;
export type GenotypeReader = FhirResourceSearcher<GeneratedTypes.Genotype, ObservationSearchParams>;
export type HaplotypeReader = FhirResourceSearcher<GeneratedTypes.Haplotype, ObservationSearchParams>;
export type MedicationRecommendationReader = FhirResourceSearcher<GeneratedTypes.MedicationRecommendation, TaskSearchParams>;
export type MolecularConsequenceReader = FhirResourceSearcher<GeneratedTypes.MolecularConsequence, ObservationSearchParams>;
export type SequencePhaseRelationshipReader = FhirResourceSearcher<GeneratedTypes.SequencePhaseRelationship, ObservationSearchParams>;
export type TherapeuticImplicationReader = FhirResourceSearcher<GeneratedTypes.TherapeuticImplication, ObservationSearchParams>;
export type VariantReader = FhirResourceSearcher<GeneratedTypes.Variant, ObservationSearchParams>;
/**
 * Custom fetch function type for injecting auth headers
 */
export type FetchFn = typeof globalThis.fetch;
/**
 * Implementation of FHIR resource reader
 */
export declare class FhirResourceReader<T, S extends SearchParams = SearchParams> implements FhirResourceSearcher<T, S> {
    readonly baseUrl: string;
    readonly resourceType: string;
    private readonly fetchFn;
    constructor(baseUrl: string, resourceType: string, fetchFn?: FetchFn);
    read(id: string): Promise<WithId<T>>;
    search(params?: S): Promise<Bundle<WithId<T>>>;
    searchOne(params?: S): Promise<undefined | WithId<T>>;
    searchAll(params?: S): Promise<WithId<T>[]>;
}
