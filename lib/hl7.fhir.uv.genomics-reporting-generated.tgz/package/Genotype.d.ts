import { BodyStructureReference } from "./BodyStructureReference";
import { CodeableConcept, Coding, Extension, Observation } from "fhir/r4";
import { SecondaryFinding } from "./SecondaryFinding";
export interface GenotypeCodeCoding extends Omit<Coding, 'system' | 'code'> {
    system: "http://loinc.org";
    code: "84413-4";
}
export interface Genotype extends Omit<Observation, 'code' | 'value' | 'extension'> {
    resourceType: 'Observation';
    code: {
        coding: GenotypeCodeCoding[];
    };
    value: CodeableConcept;
    extension?: (Extension | SecondaryFinding | BodyStructureReference)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateGenotype(resource: Genotype, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
