import { SequencePhaseRelationshipVSCode } from "./valuesets/ValueSet-SequencePhaseRelationshipVS";
import { BodyStructureReference } from "./BodyStructureReference";
import { CodeableConcept, Coding, Extension, Observation } from "fhir/r4";
import { SecondaryFinding } from "./SecondaryFinding";
export interface SequencePhaseRelationshipCodeCoding extends Omit<Coding, 'system' | 'code'> {
    system: "http://loinc.org";
    code: "82120-7";
}
export interface SequencePhaseRelationship extends Omit<Observation, 'code' | 'value' | 'extension'> {
    resourceType: 'Observation';
    code: {
        coding: SequencePhaseRelationshipCodeCoding[];
    };
    /** @see {@link ./valuesets/ValueSet-SequencePhaseRelationshipVS.ts} for valid codes (4 codes) */
    value: CodeableConcept & {
        coding: Array<{
            code: SequencePhaseRelationshipVSCode;
            system: "http://terminology.hl7.org/CodeSystem/sequence-phase-relationship-cs";
        }>;
    };
    extension?: (Extension | SecondaryFinding | BodyStructureReference)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateSequencePhaseRelationship(resource: SequencePhaseRelationship, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
