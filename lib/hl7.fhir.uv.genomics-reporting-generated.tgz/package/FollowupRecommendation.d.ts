import { Task } from "fhir/r4";
export interface FollowupRecommendation extends Omit<Task, 'status' | 'intent'> {
    resourceType: 'Task';
    status: "requested";
    intent: "proposal";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateFollowupRecommendation(resource: FollowupRecommendation, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
