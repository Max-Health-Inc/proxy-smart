import { GenomicReportNote } from "./GenomicReportNote";
import { GenomicRiskAssessment } from "./GenomicRiskAssessment";
import { GenomicStudyReference } from "./GenomicStudyReference";
import { AlleleDatabase } from "./AlleleDatabase";
import { Glstring } from "./Glstring";
import { RecommendedAction } from "./RecommendedAction";
import { RelatedArtifactExtension } from "./RelatedArtifactExtension";
import { SupportingInfo } from "./SupportingInfo";
import { Coding, DiagnosticReport, Extension } from "fhir/r4";
export interface GenomicReportCodeCoding extends Omit<Coding, 'system' | 'code'> {
    system: "http://loinc.org";
    code: "51969-4";
}
export interface GenomicReport extends Omit<DiagnosticReport, 'code' | 'extension'> {
    resourceType: 'DiagnosticReport';
    code: {
        coding: GenomicReportCodeCoding[];
    };
    extension?: (Extension | RecommendedAction | GenomicRiskAssessment | GenomicReportNote | SupportingInfo | GenomicStudyReference | AlleleDatabase | Glstring | RelatedArtifactExtension)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateGenomicReport(resource: GenomicReport, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
