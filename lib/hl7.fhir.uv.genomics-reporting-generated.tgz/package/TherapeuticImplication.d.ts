import { BodyStructureReference } from "./BodyStructureReference";
import { CodeableConcept, Coding, Extension, Observation, ObservationComponent } from "fhir/r4";
import { MedicationAssessedReference } from "./MedicationAssessedReference";
import { RelatedArtifactComponent } from "./RelatedArtifactComponent";
import { RelatedArtifactExtension } from "./RelatedArtifactExtension";
import { SecondaryFinding } from "./SecondaryFinding";
import { TherapyAssessedReference } from "./TherapyAssessedReference";
export interface WorkflowRelatedArtifactComponent extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/workflow-relatedArtifactComponent';
}
export interface TherapeuticImplicationCodeCoding extends Omit<Coding, 'system' | 'code'> {
    system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs";
    code: "therapeutic-implication";
}
export interface TherapeuticImplicationComponent extends Omit<ObservationComponent, 'code' | 'extension'> {
    /** @see {@link ./valuesets/ValueSet-LOINCCodes.ts} for valid codes (100 codes) */
    code: CodeableConcept;
    extension?: (Extension | RelatedArtifactComponent | RelatedArtifactComponent | RelatedArtifactComponent | RelatedArtifactComponent | RelatedArtifactComponent | MedicationAssessedReference | RelatedArtifactComponent | TherapyAssessedReference)[];
}
export interface TherapeuticImplication extends Omit<Observation, 'code' | 'component' | 'extension'> {
    resourceType: 'Observation';
    code: {
        coding: TherapeuticImplicationCodeCoding[];
    };
    component?: TherapeuticImplicationComponent[];
    extension?: (Extension | SecondaryFinding | BodyStructureReference | RelatedArtifactExtension)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateTherapeuticImplication(resource: TherapeuticImplication, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
