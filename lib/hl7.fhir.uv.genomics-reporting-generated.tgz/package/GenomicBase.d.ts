import { BodyStructureReference } from "./BodyStructureReference";
import { CodedAnnotation } from "./CodedAnnotation";
import { SecondaryFinding } from "./SecondaryFinding";
import { Extension, Observation } from "fhir/r4";
export interface GenomicBase extends Omit<Observation, 'note' | 'extension'> {
    resourceType: 'Observation';
    note?: CodedAnnotation[];
    extension?: (Extension | SecondaryFinding | BodyStructureReference)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateGenomicBase(resource: GenomicBase, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
