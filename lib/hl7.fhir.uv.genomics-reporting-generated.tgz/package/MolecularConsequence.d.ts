import { BodyStructureReference } from "./BodyStructureReference";
import { CodeableConcept, Coding, Extension, Observation, ObservationComponent } from "fhir/r4";
import { RelatedArtifactComponent } from "./RelatedArtifactComponent";
import { RelatedArtifactExtension } from "./RelatedArtifactExtension";
import { SecondaryFinding } from "./SecondaryFinding";
export interface WorkflowRelatedArtifactComponent extends Omit<Extension, 'url'> {
    url: 'http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/workflow-relatedArtifactComponent';
}
export interface MolecularConsequenceCodeCoding extends Omit<Coding, 'system' | 'code'> {
    system: "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs";
    code: "molecular-consequence";
}
export interface MolecularConsequenceComponent extends Omit<ObservationComponent, 'code' | 'extension'> {
    /** @see {@link ./valuesets/ValueSet-LOINCCodes.ts} for valid codes (100 codes) */
    code: CodeableConcept;
    extension?: (Extension | RelatedArtifactComponent | RelatedArtifactComponent | RelatedArtifactComponent | RelatedArtifactComponent | RelatedArtifactComponent | RelatedArtifactComponent | RelatedArtifactComponent | RelatedArtifactComponent)[];
}
export interface MolecularConsequence extends Omit<Observation, 'code' | 'component' | 'extension'> {
    resourceType: 'Observation';
    code: {
        coding: MolecularConsequenceCodeCoding[];
    };
    component?: MolecularConsequenceComponent[];
    extension?: (Extension | SecondaryFinding | BodyStructureReference | RelatedArtifactExtension)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateMolecularConsequence(resource: MolecularConsequence, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
