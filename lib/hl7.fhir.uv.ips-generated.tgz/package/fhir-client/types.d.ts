import type * as GeneratedTypes from "../index.js";
/**
 * A FHIR resource with an ID
 */
export type WithId<T> = {
    id: string;
} & T;
/**
 * Search parameter value type — all values are serialized to query strings.
 */
export type SearchParamValue = boolean | number | string | string[] | undefined;
/**
 * Search parameters for FHIR resources (generic untyped version).
 */
export type SearchParams = Record<string, SearchParamValue>;
/**
 * Common search parameters supported by all FHIR resources.
 * Includes an index signature to allow search parameter modifiers (e.g. name:exact).
 */
export interface CommonSearchParams {
    _id?: SearchParamValue;
    _lastUpdated?: SearchParamValue;
    _tag?: SearchParamValue;
    _profile?: SearchParamValue;
    _security?: SearchParamValue;
    _count?: SearchParamValue;
    _sort?: SearchParamValue;
    _include?: SearchParamValue;
    _revinclude?: SearchParamValue;
    _summary?: SearchParamValue;
    _elements?: SearchParamValue;
    _total?: SearchParamValue;
    [key: string]: SearchParamValue;
}
/**
 * Bundle of FHIR resources
 */
export interface Bundle<T> {
    resourceType: "Bundle";
    type: "collection" | "searchset" | "transaction-response" | "transaction";
    total?: number;
    link?: {
        relation: string;
        url: string;
    }[];
    entry?: {
        resource: T;
        fullUrl?: string;
    }[];
}
/**
 * Type-safe FHIR resource types
 */
export type FhirResource = GeneratedTypes.AllergyIntoleranceUvIps | GeneratedTypes.BundleUvIps | GeneratedTypes.CompositionUvIps | GeneratedTypes.ConditionUvIps | GeneratedTypes.DeviceObserverUvIps | GeneratedTypes.DeviceUseStatementUvIps | GeneratedTypes.DeviceUvIps | GeneratedTypes.DiagnosticReportUvIps | GeneratedTypes.FlagAlertUvIps | GeneratedTypes.ImagingStudyUvIps | GeneratedTypes.ImmunizationUvIps | GeneratedTypes.MedicationIPS | GeneratedTypes.MedicationRequestIPS | GeneratedTypes.MedicationStatementIPS | GeneratedTypes.ObservationAlcoholUseUvIps | GeneratedTypes.ObservationPregnancyEddUvIps | GeneratedTypes.ObservationPregnancyOutcomeUvIps | GeneratedTypes.ObservationPregnancyStatusUvIps | GeneratedTypes.ObservationResultsLaboratoryPathologyUvIps | GeneratedTypes.ObservationResultsRadiologyUvIps | GeneratedTypes.ObservationTobaccoUseUvIps | GeneratedTypes.OrganizationUvIps | GeneratedTypes.PatientUvIps | GeneratedTypes.PractitionerRoleUvIps | GeneratedTypes.PractitionerUvIps | GeneratedTypes.ProcedureUvIps | GeneratedTypes.SpecimenUvIps;
/**
 * Typed search parameters for AllergyIntolerance resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface AllergyIntoleranceSearchParams extends CommonSearchParams {
    "asserter"?: SearchParamValue;
    "category"?: SearchParamValue;
    "clinical-status"?: SearchParamValue;
    "code"?: SearchParamValue;
    "criticality"?: SearchParamValue;
    "date"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "last-date"?: SearchParamValue;
    "manifestation"?: SearchParamValue;
    "onset"?: SearchParamValue;
    "patient"?: SearchParamValue;
    "recorder"?: SearchParamValue;
    "route"?: SearchParamValue;
    "severity"?: SearchParamValue;
    "type"?: SearchParamValue;
    "verification-status"?: SearchParamValue;
}
/**
 * Typed search parameters for Bundle resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface BundleSearchParams extends CommonSearchParams {
    "composition"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "message"?: SearchParamValue;
    "timestamp"?: SearchParamValue;
    "type"?: SearchParamValue;
}
/**
 * Typed search parameters for Composition resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface CompositionSearchParams extends CommonSearchParams {
    "attester"?: SearchParamValue;
    "author"?: SearchParamValue;
    "category"?: SearchParamValue;
    "confidentiality"?: SearchParamValue;
    "context"?: SearchParamValue;
    "date"?: SearchParamValue;
    "encounter"?: SearchParamValue;
    "entry"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "patient"?: SearchParamValue;
    "period"?: SearchParamValue;
    "related-id"?: SearchParamValue;
    "related-ref"?: SearchParamValue;
    "section"?: SearchParamValue;
    "status"?: SearchParamValue;
    "subject"?: SearchParamValue;
    "title"?: SearchParamValue;
    "type"?: SearchParamValue;
}
/**
 * Typed search parameters for Condition resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface ConditionSearchParams extends CommonSearchParams {
    "abatement-age"?: SearchParamValue;
    "abatement-date"?: SearchParamValue;
    "abatement-string"?: SearchParamValue;
    "asserter"?: SearchParamValue;
    "body-site"?: SearchParamValue;
    "category"?: SearchParamValue;
    "clinical-status"?: SearchParamValue;
    "code"?: SearchParamValue;
    "encounter"?: SearchParamValue;
    "evidence"?: SearchParamValue;
    "evidence-detail"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "onset-age"?: SearchParamValue;
    "onset-date"?: SearchParamValue;
    "onset-info"?: SearchParamValue;
    "patient"?: SearchParamValue;
    "recorded-date"?: SearchParamValue;
    "severity"?: SearchParamValue;
    "stage"?: SearchParamValue;
    "subject"?: SearchParamValue;
    "verification-status"?: SearchParamValue;
}
/**
 * Typed search parameters for Device resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface DeviceSearchParams extends CommonSearchParams {
    "device-name"?: SearchParamValue;
    "din"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "location"?: SearchParamValue;
    "manufacturer"?: SearchParamValue;
    "model"?: SearchParamValue;
    "organization"?: SearchParamValue;
    "patient"?: SearchParamValue;
    "status"?: SearchParamValue;
    "type"?: SearchParamValue;
    "udi-carrier"?: SearchParamValue;
    "udi-di"?: SearchParamValue;
    "url"?: SearchParamValue;
}
/**
 * Typed search parameters for DeviceUseStatement resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface DeviceUseStatementSearchParams extends CommonSearchParams {
    "device"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "patient"?: SearchParamValue;
    "subject"?: SearchParamValue;
}
/**
 * Typed search parameters for DiagnosticReport resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface DiagnosticReportSearchParams extends CommonSearchParams {
    "assessed-condition"?: SearchParamValue;
    "based-on"?: SearchParamValue;
    "category"?: SearchParamValue;
    "code"?: SearchParamValue;
    "conclusion"?: SearchParamValue;
    "date"?: SearchParamValue;
    "encounter"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "issued"?: SearchParamValue;
    "media"?: SearchParamValue;
    "patient"?: SearchParamValue;
    "performer"?: SearchParamValue;
    "result"?: SearchParamValue;
    "results-interpreter"?: SearchParamValue;
    "specimen"?: SearchParamValue;
    "status"?: SearchParamValue;
    "subject"?: SearchParamValue;
}
/**
 * Typed search parameters for Flag resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface FlagSearchParams extends CommonSearchParams {
    "author"?: SearchParamValue;
    "date"?: SearchParamValue;
    "encounter"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "patient"?: SearchParamValue;
    "subject"?: SearchParamValue;
}
/**
 * Typed search parameters for ImagingStudy resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface ImagingStudySearchParams extends CommonSearchParams {
    "basedon"?: SearchParamValue;
    "bodysite"?: SearchParamValue;
    "dicom-class"?: SearchParamValue;
    "encounter"?: SearchParamValue;
    "endpoint"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "instance"?: SearchParamValue;
    "interpreter"?: SearchParamValue;
    "modality"?: SearchParamValue;
    "patient"?: SearchParamValue;
    "performer"?: SearchParamValue;
    "reason"?: SearchParamValue;
    "referrer"?: SearchParamValue;
    "series"?: SearchParamValue;
    "started"?: SearchParamValue;
    "status"?: SearchParamValue;
    "subject"?: SearchParamValue;
}
/**
 * Typed search parameters for Immunization resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface ImmunizationSearchParams extends CommonSearchParams {
    "date"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "location"?: SearchParamValue;
    "lot-number"?: SearchParamValue;
    "manufacturer"?: SearchParamValue;
    "patient"?: SearchParamValue;
    "performer"?: SearchParamValue;
    "reaction"?: SearchParamValue;
    "reaction-date"?: SearchParamValue;
    "reason-code"?: SearchParamValue;
    "reason-reference"?: SearchParamValue;
    "series"?: SearchParamValue;
    "status"?: SearchParamValue;
    "status-reason"?: SearchParamValue;
    "target-disease"?: SearchParamValue;
    "vaccine-code"?: SearchParamValue;
}
/**
 * Typed search parameters for Medication resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface MedicationSearchParams extends CommonSearchParams {
    "code"?: SearchParamValue;
    "expiration-date"?: SearchParamValue;
    "form"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "ingredient"?: SearchParamValue;
    "ingredient-code"?: SearchParamValue;
    "lot-number"?: SearchParamValue;
    "manufacturer"?: SearchParamValue;
    "status"?: SearchParamValue;
}
/**
 * Typed search parameters for MedicationRequest resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface MedicationRequestSearchParams extends CommonSearchParams {
    "authoredon"?: SearchParamValue;
    "category"?: SearchParamValue;
    "code"?: SearchParamValue;
    "date"?: SearchParamValue;
    "encounter"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "intended-dispenser"?: SearchParamValue;
    "intended-performer"?: SearchParamValue;
    "intended-performertype"?: SearchParamValue;
    "intent"?: SearchParamValue;
    "medication"?: SearchParamValue;
    "patient"?: SearchParamValue;
    "priority"?: SearchParamValue;
    "requester"?: SearchParamValue;
    "status"?: SearchParamValue;
    "subject"?: SearchParamValue;
}
/**
 * Typed search parameters for MedicationStatement resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface MedicationStatementSearchParams extends CommonSearchParams {
    "category"?: SearchParamValue;
    "code"?: SearchParamValue;
    "context"?: SearchParamValue;
    "effective"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "medication"?: SearchParamValue;
    "part-of"?: SearchParamValue;
    "patient"?: SearchParamValue;
    "source"?: SearchParamValue;
    "status"?: SearchParamValue;
    "subject"?: SearchParamValue;
}
/**
 * Typed search parameters for Observation resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface ObservationSearchParams extends CommonSearchParams {
    "amino-acid-change"?: SearchParamValue;
    "based-on"?: SearchParamValue;
    "category"?: SearchParamValue;
    "code"?: SearchParamValue;
    "code-value-concept"?: SearchParamValue;
    "code-value-date"?: SearchParamValue;
    "code-value-quantity"?: SearchParamValue;
    "code-value-string"?: SearchParamValue;
    "combo-code"?: SearchParamValue;
    "combo-code-value-concept"?: SearchParamValue;
    "combo-code-value-quantity"?: SearchParamValue;
    "combo-data-absent-reason"?: SearchParamValue;
    "combo-value-concept"?: SearchParamValue;
    "combo-value-quantity"?: SearchParamValue;
    "component-code"?: SearchParamValue;
    "component-code-value-concept"?: SearchParamValue;
    "component-code-value-quantity"?: SearchParamValue;
    "component-data-absent-reason"?: SearchParamValue;
    "component-value-concept"?: SearchParamValue;
    "component-value-quantity"?: SearchParamValue;
    "data-absent-reason"?: SearchParamValue;
    "date"?: SearchParamValue;
    "derived-from"?: SearchParamValue;
    "device"?: SearchParamValue;
    "dna-variant"?: SearchParamValue;
    "encounter"?: SearchParamValue;
    "focus"?: SearchParamValue;
    "gene-amino-acid-change"?: SearchParamValue;
    "gene-dnavariant"?: SearchParamValue;
    "gene-identifier"?: SearchParamValue;
    "has-member"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "method"?: SearchParamValue;
    "part-of"?: SearchParamValue;
    "patient"?: SearchParamValue;
    "performer"?: SearchParamValue;
    "specimen"?: SearchParamValue;
    "status"?: SearchParamValue;
    "subject"?: SearchParamValue;
    "value-concept"?: SearchParamValue;
    "value-date"?: SearchParamValue;
    "value-quantity"?: SearchParamValue;
    "value-string"?: SearchParamValue;
}
/**
 * Typed search parameters for Organization resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface OrganizationSearchParams extends CommonSearchParams {
    "active"?: SearchParamValue;
    "address"?: SearchParamValue;
    "address-city"?: SearchParamValue;
    "address-country"?: SearchParamValue;
    "address-postalcode"?: SearchParamValue;
    "address-state"?: SearchParamValue;
    "address-use"?: SearchParamValue;
    "endpoint"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "name"?: SearchParamValue;
    "partof"?: SearchParamValue;
    "phonetic"?: SearchParamValue;
    "type"?: SearchParamValue;
}
/**
 * Typed search parameters for Patient resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface PatientSearchParams extends CommonSearchParams {
    "active"?: SearchParamValue;
    "address"?: SearchParamValue;
    "address-city"?: SearchParamValue;
    "address-country"?: SearchParamValue;
    "address-postalcode"?: SearchParamValue;
    "address-state"?: SearchParamValue;
    "address-use"?: SearchParamValue;
    "age"?: SearchParamValue;
    "birthdate"?: SearchParamValue;
    "birthOrderBoolean"?: SearchParamValue;
    "death-date"?: SearchParamValue;
    "deceased"?: SearchParamValue;
    "email"?: SearchParamValue;
    "family"?: SearchParamValue;
    "gender"?: SearchParamValue;
    "general-practitioner"?: SearchParamValue;
    "given"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "language"?: SearchParamValue;
    "link"?: SearchParamValue;
    "mothersMaidenName"?: SearchParamValue;
    "name"?: SearchParamValue;
    "organization"?: SearchParamValue;
    "part-agree"?: SearchParamValue;
    "phone"?: SearchParamValue;
    "phonetic"?: SearchParamValue;
    "telecom"?: SearchParamValue;
}
/**
 * Typed search parameters for PractitionerRole resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface PractitionerRoleSearchParams extends CommonSearchParams {
    "active"?: SearchParamValue;
    "date"?: SearchParamValue;
    "email"?: SearchParamValue;
    "endpoint"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "location"?: SearchParamValue;
    "organization"?: SearchParamValue;
    "phone"?: SearchParamValue;
    "practitioner"?: SearchParamValue;
    "role"?: SearchParamValue;
    "service"?: SearchParamValue;
    "specialty"?: SearchParamValue;
    "telecom"?: SearchParamValue;
}
/**
 * Typed search parameters for Practitioner resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface PractitionerSearchParams extends CommonSearchParams {
    "active"?: SearchParamValue;
    "address"?: SearchParamValue;
    "address-city"?: SearchParamValue;
    "address-country"?: SearchParamValue;
    "address-postalcode"?: SearchParamValue;
    "address-state"?: SearchParamValue;
    "address-use"?: SearchParamValue;
    "communication"?: SearchParamValue;
    "email"?: SearchParamValue;
    "family"?: SearchParamValue;
    "gender"?: SearchParamValue;
    "given"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "name"?: SearchParamValue;
    "phone"?: SearchParamValue;
    "phonetic"?: SearchParamValue;
    "telecom"?: SearchParamValue;
}
/**
 * Typed search parameters for Procedure resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface ProcedureSearchParams extends CommonSearchParams {
    "based-on"?: SearchParamValue;
    "category"?: SearchParamValue;
    "code"?: SearchParamValue;
    "date"?: SearchParamValue;
    "encounter"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "instantiates-canonical"?: SearchParamValue;
    "instantiates-uri"?: SearchParamValue;
    "location"?: SearchParamValue;
    "part-of"?: SearchParamValue;
    "patient"?: SearchParamValue;
    "performer"?: SearchParamValue;
    "reason-code"?: SearchParamValue;
    "reason-reference"?: SearchParamValue;
    "status"?: SearchParamValue;
    "subject"?: SearchParamValue;
}
/**
 * Typed search parameters for Specimen resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface SpecimenSearchParams extends CommonSearchParams {
    "accession"?: SearchParamValue;
    "bodysite"?: SearchParamValue;
    "collected"?: SearchParamValue;
    "collector"?: SearchParamValue;
    "container"?: SearchParamValue;
    "container-id"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "parent"?: SearchParamValue;
    "patient"?: SearchParamValue;
    "status"?: SearchParamValue;
    "subject"?: SearchParamValue;
    "type"?: SearchParamValue;
}
