import type * as GeneratedTypes from "../index.js";
import type { Bundle, AllergyIntoleranceSearchParams, BundleSearchParams, CompositionSearchParams, ConditionSearchParams, DeviceSearchParams, DeviceUseStatementSearchParams, DiagnosticReportSearchParams, FlagSearchParams, ImagingStudySearchParams, ImmunizationSearchParams, MedicationRequestSearchParams, MedicationSearchParams, MedicationStatementSearchParams, ObservationSearchParams, OrganizationSearchParams, PatientSearchParams, PractitionerRoleSearchParams, PractitionerSearchParams, ProcedureSearchParams, SearchParams, SpecimenSearchParams, WithId } from "./types.js";
/**
 * Generic FHIR resource searcher/reader
 */
export interface FhirResourceSearcher<T, S extends SearchParams = SearchParams> {
    readonly baseUrl: string;
    readonly resourceType: string;
    /**
     * Read a resource by ID
     */
    read(id: string): Promise<WithId<T>>;
    /**
     * Search for resources
     */
    search(params?: S): Promise<Bundle<WithId<T>>>;
    /**
     * Search and return first result or undefined
     */
    searchOne(params?: S): Promise<undefined | WithId<T>>;
    /**
     * Search and return all results (handles pagination)
     */
    searchAll(params?: S): Promise<WithId<T>[]>;
}
/**
 * Specific reader types for type safety
 */
export type AllergyIntoleranceUvIpsReader = FhirResourceSearcher<GeneratedTypes.AllergyIntoleranceUvIps, AllergyIntoleranceSearchParams>;
export type BundleUvIpsReader = FhirResourceSearcher<GeneratedTypes.BundleUvIps, BundleSearchParams>;
export type CompositionUvIpsReader = FhirResourceSearcher<GeneratedTypes.CompositionUvIps, CompositionSearchParams>;
export type ConditionUvIpsReader = FhirResourceSearcher<GeneratedTypes.ConditionUvIps, ConditionSearchParams>;
export type DeviceObserverUvIpsReader = FhirResourceSearcher<GeneratedTypes.DeviceObserverUvIps, DeviceSearchParams>;
export type DeviceUseStatementUvIpsReader = FhirResourceSearcher<GeneratedTypes.DeviceUseStatementUvIps, DeviceUseStatementSearchParams>;
export type DeviceUvIpsReader = FhirResourceSearcher<GeneratedTypes.DeviceUvIps, DeviceSearchParams>;
export type DiagnosticReportUvIpsReader = FhirResourceSearcher<GeneratedTypes.DiagnosticReportUvIps, DiagnosticReportSearchParams>;
export type FlagAlertUvIpsReader = FhirResourceSearcher<GeneratedTypes.FlagAlertUvIps, FlagSearchParams>;
export type ImagingStudyUvIpsReader = FhirResourceSearcher<GeneratedTypes.ImagingStudyUvIps, ImagingStudySearchParams>;
export type ImmunizationUvIpsReader = FhirResourceSearcher<GeneratedTypes.ImmunizationUvIps, ImmunizationSearchParams>;
export type MedicationIPSReader = FhirResourceSearcher<GeneratedTypes.MedicationIPS, MedicationSearchParams>;
export type MedicationRequestIPSReader = FhirResourceSearcher<GeneratedTypes.MedicationRequestIPS, MedicationRequestSearchParams>;
export type MedicationStatementIPSReader = FhirResourceSearcher<GeneratedTypes.MedicationStatementIPS, MedicationStatementSearchParams>;
export type ObservationAlcoholUseUvIpsReader = FhirResourceSearcher<GeneratedTypes.ObservationAlcoholUseUvIps, ObservationSearchParams>;
export type ObservationPregnancyEddUvIpsReader = FhirResourceSearcher<GeneratedTypes.ObservationPregnancyEddUvIps, ObservationSearchParams>;
export type ObservationPregnancyOutcomeUvIpsReader = FhirResourceSearcher<GeneratedTypes.ObservationPregnancyOutcomeUvIps, ObservationSearchParams>;
export type ObservationPregnancyStatusUvIpsReader = FhirResourceSearcher<GeneratedTypes.ObservationPregnancyStatusUvIps, ObservationSearchParams>;
export type ObservationResultsLaboratoryPathologyUvIpsReader = FhirResourceSearcher<GeneratedTypes.ObservationResultsLaboratoryPathologyUvIps, ObservationSearchParams>;
export type ObservationResultsRadiologyUvIpsReader = FhirResourceSearcher<GeneratedTypes.ObservationResultsRadiologyUvIps, ObservationSearchParams>;
export type ObservationTobaccoUseUvIpsReader = FhirResourceSearcher<GeneratedTypes.ObservationTobaccoUseUvIps, ObservationSearchParams>;
export type OrganizationUvIpsReader = FhirResourceSearcher<GeneratedTypes.OrganizationUvIps, OrganizationSearchParams>;
export type PatientUvIpsReader = FhirResourceSearcher<GeneratedTypes.PatientUvIps, PatientSearchParams>;
export type PractitionerRoleUvIpsReader = FhirResourceSearcher<GeneratedTypes.PractitionerRoleUvIps, PractitionerRoleSearchParams>;
export type PractitionerUvIpsReader = FhirResourceSearcher<GeneratedTypes.PractitionerUvIps, PractitionerSearchParams>;
export type ProcedureUvIpsReader = FhirResourceSearcher<GeneratedTypes.ProcedureUvIps, ProcedureSearchParams>;
export type SpecimenUvIpsReader = FhirResourceSearcher<GeneratedTypes.SpecimenUvIps, SpecimenSearchParams>;
/**
 * Custom fetch function type for injecting auth headers
 */
export type FetchFn = typeof globalThis.fetch;
/**
 * Implementation of FHIR resource reader
 */
export declare class FhirResourceReader<T, S extends SearchParams = SearchParams> implements FhirResourceSearcher<T, S> {
    readonly baseUrl: string;
    readonly resourceType: string;
    private readonly fetchFn;
    constructor(baseUrl: string, resourceType: string, fetchFn?: FetchFn);
    read(id: string): Promise<WithId<T>>;
    search(params?: S): Promise<Bundle<WithId<T>>>;
    searchOne(params?: S): Promise<undefined | WithId<T>>;
    searchAll(params?: S): Promise<WithId<T>[]>;
}
