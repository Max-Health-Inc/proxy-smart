import { validateMaxHealthConsent } from "./MaxHealthConsent.js";
// Only import helpers actually referenced below (dynamic based on required fields)
import { randomId, setRandomSeed, enrichResource, skeletonCodeableConcept, skeletonReference } from "./random/index.js";
import { createRequire } from 'module';
const __require = createRequire(import.meta.url);
function ensureProfile(res, profile) {
    if (!res.meta) {
        res.meta = { profile: [profile] };
        return;
    }
    if (!res.meta.profile) {
        res.meta.profile = [profile];
        return;
    }
    if (!res.meta.profile.includes(profile)) {
        res.meta.profile = [...res.meta.profile, profile];
    }
}
// Internal helper (emitted per class file) to clone without resorting to 'any'.
function safeClone(value) {
    // Use native structuredClone if present; otherwise fallback to JSON round-trip.
    // We intentionally avoid casting through any to satisfy no-explicit-any lint rule.
    const g = globalThis;
    // Narrow globalThis to an object potentially containing structuredClone.
    if (typeof g.structuredClone === 'function') {
        return g.structuredClone(value);
    }
    return JSON.parse(JSON.stringify(value)); // best-effort deep clone
}
export class MaxHealthConsentClass {
    constructor(resource) {
        this.resource = resource;
        ensureProfile(this.resource, 'https://maxhealth.tech/fhir/consent/StructureDefinition/maxhealth-consent');
    }
    /** Validate current resource instance. */
    async validate(options) {
        return validateMaxHealthConsent(this.resource, options);
    }
    getResource() {
        return this.resource;
    }
    setResource(resource) {
        this.resource = resource;
        ensureProfile(this.resource, 'https://maxhealth.tech/fhir/consent/StructureDefinition/maxhealth-consent');
    }
    /**
     * Returns a plain JSON clone of the underlying resource ONLY if the last validation succeeded with zero errors.
     * Call validate() first; otherwise this method throws to prevent accidental use of invalid / unchecked data.
     */
    async toJSON() {
        return safeClone(this.resource);
    }
    /**
     * Create an empty instance for parity testing: for true FHIR resources, includes only resourceType; for datatypes, returns an empty object.
     * Note: meta.profile (when applicable) will be ensured by the constructor when wrapping this resource.
     */
    static empty(overrides = {}) {
        // For Resource profiles, include only resourceType. For Extension profiles, include url so the instance is minimally meaningful.
        const base = {
            resourceType: 'Consent',
        };
        return { ...base, ...overrides };
    }
    /**
     * Create a minimal randomized instance of MaxHealthConsent.
     * Populates id, resourceType (if applicable) and primitive required (min>0) top-level fields with placeholders.
     */
    static random(overrides = {}, opts) {
        if (opts?.seed !== undefined) {
            // Direct call (no dynamic require) to ensure deterministic seeding works under ESM.
            setRandomSeed(opts.seed);
        }
        // Start with a Partial to avoid unsafe casting errors; we'll assert at the end.
        const base = { resourceType: 'Consent', id: randomId(), status: 'active', scope: { coding: [{ system: "http://terminology.hl7.org/CodeSystem/consentscope", code: "patient-privacy" }] }, category: [skeletonCodeableConcept()], patient: skeletonReference(), };
        // Always include meta.profile with this profile's canonical URL if available & only for resource profiles
        ensureProfile(base, 'https://maxhealth.tech/fhir/consent/StructureDefinition/maxhealth-consent');
        // Enrich the base resource with common fields using centralized enrichment logic
        enrichResource(base, 'Consent', 'https://maxhealth.tech/fhir/consent/StructureDefinition/maxhealth-consent', MaxHealthConsentClass._fieldPatterns, MaxHealthConsentClass._forbiddenFields, MaxHealthConsentClass.valueSetBindings, MaxHealthConsentClass._codeResolver, MaxHealthConsentClass._fieldOrder);
        // Cast through unknown to acknowledge dynamic enrichment
        return { ...base, ...overrides };
    }
    /** Convenience: returns a class instance wrapping a randomized resource. */
    static randomClass(overrides = {}, opts) {
        return new MaxHealthConsentClass(this.random(overrides, opts));
    }
}
/** Pattern constraints for profile fields (used by random() generator) */
MaxHealthConsentClass._fieldPatterns = {
    "scope": {
        "coding": [
            {
                "code": "patient-privacy",
                "system": "http://terminology.hl7.org/CodeSystem/consentscope"
            }
        ]
    },
    "_refReq_provision": {
        "actor.role": true,
        "actor.reference": true,
        "data.meaning": true,
        "data.reference": true
    },
    "_refReq_verification": {
        "verified": true
    },
    "_choiceType_source[x]": [
        "Attachment",
        "Reference"
    ]
};
/** Fields that are forbidden (max=0) in this profile - must not be generated */
MaxHealthConsentClass._forbiddenFields = [];
/** FHIR element ordering for this profile's base resource (used by enrichResource for correct JSON field order) */
MaxHealthConsentClass._fieldOrder = ["id", "meta", "implicitRules", "language", "text", "contained", "extension", "modifierExtension", "identifier", "status", "scope", "category", "patient", "dateTime", "performer", "organization", "source[x]", "policy", "policyRule", "verification", "provision"];
/** ValueSet bindings for coded fields - maps field name to ValueSet URL */
MaxHealthConsentClass.valueSetBindings = {
    "status": "http://hl7.org/fhir/ValueSet/consent-state-codes|4.0.1",
    "category": "http://hl7.org/fhir/ValueSet/consent-category",
    "provision.type": "http://hl7.org/fhir/ValueSet/consent-provision-type|4.0.1",
    "provision.actor.role": "http://hl7.org/fhir/ValueSet/security-role-type",
    "provision.action": "http://hl7.org/fhir/ValueSet/consent-action",
    "provision.class": "http://hl7.org/fhir/ValueSet/consent-content-class",
    "language": "http://hl7.org/fhir/ValueSet/languages",
    "scope": "http://hl7.org/fhir/ValueSet/consent-scope",
    "policyRule": "http://hl7.org/fhir/ValueSet/consent-policy",
    "provision.securityLabel": "http://hl7.org/fhir/ValueSet/security-labels",
    "provision.purpose": "http://terminology.hl7.org/ValueSet/v3-PurposeOfUse",
    "provision.code": "http://hl7.org/fhir/ValueSet/consent-content-code",
    "provision.data.meaning": "http://hl7.org/fhir/ValueSet/consent-data-meaning|4.0.1"
};
/** Code resolver for ValueSet bindings - returns a random valid code from a ValueSet by URL */
MaxHealthConsentClass._codeResolver = (() => {
    // Try to load the ValueSetRegistry - it may not exist if no ValueSets were generated
    try {
        const registry = __require('./valuesets/index.js');
        if (registry && typeof registry.getRandomConceptByUrl === 'function') {
            return registry.getRandomConceptByUrl;
        }
    }
    catch { /* ValueSetRegistry not available */ }
    return undefined;
})();
