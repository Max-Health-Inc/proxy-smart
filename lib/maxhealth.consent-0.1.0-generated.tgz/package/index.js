// Auto-generated index file - exports all generated FHIR profiles
export * from './MaxHealthConsent.js';
export * from './MaxHealthConsentClass.js';
export * from './MaxHealthShareConsent.js';
export * from './MaxHealthShareConsentClass.js';
