import { CodeableConcept, Coding, Consent, ConsentProvision, Reference } from "fhir/r4";
export interface MaxHealthConsentScopeCoding extends Omit<Coding, 'system' | 'code'> {
    system: "http://terminology.hl7.org/CodeSystem/consentscope";
    code: "patient-privacy";
}
export interface MaxHealthConsent extends Omit<Consent, 'scope' | 'category' | 'patient' | 'provision'> {
    resourceType: 'Consent';
    scope: {
        coding: MaxHealthConsentScopeCoding[];
    };
    /** Must Support */
    category: CodeableConcept[];
    /** Must Support */
    patient: Reference;
    /** Must Support */
    provision?: ConsentProvision;
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateMaxHealthConsent(resource: MaxHealthConsent, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
