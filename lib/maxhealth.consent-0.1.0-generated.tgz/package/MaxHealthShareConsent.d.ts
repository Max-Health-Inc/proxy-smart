import { Consent, Identifier } from "fhir/r4";
export interface MaxHealthShareConsent extends Omit<Consent, 'identifier'> {
    resourceType: 'Consent';
    /** Must Support */
    identifier: Identifier[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateMaxHealthShareConsent(resource: MaxHealthShareConsent, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
