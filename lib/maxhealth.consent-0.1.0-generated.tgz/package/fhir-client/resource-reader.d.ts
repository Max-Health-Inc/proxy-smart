import type * as GeneratedTypes from "../index.js";
import type { Bundle, ConsentSearchParams, SearchParams, WithId } from "./types.js";
/**
 * Generic FHIR resource searcher/reader
 */
export interface FhirResourceSearcher<T, S extends SearchParams = SearchParams> {
    readonly baseUrl: string;
    readonly resourceType: string;
    /**
     * Read a resource by ID
     */
    read(id: string): Promise<WithId<T>>;
    /**
     * Search for resources
     */
    search(params?: S): Promise<Bundle<WithId<T>>>;
    /**
     * Search and return first result or undefined
     */
    searchOne(params?: S): Promise<undefined | WithId<T>>;
    /**
     * Search and return all results (handles pagination)
     */
    searchAll(params?: S): Promise<WithId<T>[]>;
}
/**
 * Specific reader types for type safety
 */
export type MaxHealthConsentReader = FhirResourceSearcher<GeneratedTypes.MaxHealthConsent, ConsentSearchParams>;
export type MaxHealthShareConsentReader = FhirResourceSearcher<GeneratedTypes.MaxHealthShareConsent, ConsentSearchParams>;
/**
 * Custom fetch function type for injecting auth headers
 */
export type FetchFn = typeof globalThis.fetch;
/**
 * Implementation of FHIR resource reader
 */
export declare class FhirResourceReader<T, S extends SearchParams = SearchParams> implements FhirResourceSearcher<T, S> {
    readonly baseUrl: string;
    readonly resourceType: string;
    private readonly fetchFn;
    constructor(baseUrl: string, resourceType: string, fetchFn?: FetchFn);
    read(id: string): Promise<WithId<T>>;
    search(params?: S): Promise<Bundle<WithId<T>>>;
    searchOne(params?: S): Promise<undefined | WithId<T>>;
    searchAll(params?: S): Promise<WithId<T>[]>;
}
