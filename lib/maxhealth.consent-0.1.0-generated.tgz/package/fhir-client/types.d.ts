import type * as GeneratedTypes from "../index.js";
/**
 * A FHIR resource with an ID
 */
export type WithId<T> = {
    id: string;
} & T;
/**
 * Search parameter value type — all values are serialized to query strings.
 */
export type SearchParamValue = boolean | number | string | string[] | undefined;
/**
 * Search parameters for FHIR resources (generic untyped version).
 */
export type SearchParams = Record<string, SearchParamValue>;
/**
 * Common search parameters supported by all FHIR resources.
 * Includes an index signature to allow search parameter modifiers (e.g. name:exact).
 */
export interface CommonSearchParams {
    _id?: SearchParamValue;
    _lastUpdated?: SearchParamValue;
    _tag?: SearchParamValue;
    _profile?: SearchParamValue;
    _security?: SearchParamValue;
    _count?: SearchParamValue;
    _sort?: SearchParamValue;
    _include?: SearchParamValue;
    _revinclude?: SearchParamValue;
    _summary?: SearchParamValue;
    _elements?: SearchParamValue;
    _total?: SearchParamValue;
    [key: string]: SearchParamValue;
}
/**
 * Bundle of FHIR resources
 */
export interface Bundle<T> {
    resourceType: "Bundle";
    type: "collection" | "searchset" | "transaction-response" | "transaction";
    total?: number;
    link?: {
        relation: string;
        url: string;
    }[];
    entry?: {
        resource: T;
        fullUrl?: string;
    }[];
}
/**
 * Type-safe FHIR resource types
 */
export type FhirResource = GeneratedTypes.MaxHealthConsent | GeneratedTypes.MaxHealthShareConsent;
/**
 * Typed search parameters for Consent resources.
 * Generated from SearchParameter definitions in the base FHIR spec and IG.
 */
export interface ConsentSearchParams extends CommonSearchParams {
    "action"?: SearchParamValue;
    "actor"?: SearchParamValue;
    "category"?: SearchParamValue;
    "consentor"?: SearchParamValue;
    "data"?: SearchParamValue;
    "date"?: SearchParamValue;
    "identifier"?: SearchParamValue;
    "organization"?: SearchParamValue;
    "patient"?: SearchParamValue;
    "period"?: SearchParamValue;
    "purpose"?: SearchParamValue;
    "scope"?: SearchParamValue;
    "security-label"?: SearchParamValue;
    "source-reference"?: SearchParamValue;
    "status"?: SearchParamValue;
}
