import type * as GeneratedTypes from "../index.js";
import type { WithId } from "./types.js";
/**
 * Generic FHIR resource writer
 */
export interface FhirResourceWriter<T> {
    readonly baseUrl: string;
    readonly resourceType: string;
    /**
     * Create a new resource
     */
    create(resource: T): Promise<WithId<T>>;
    /**
     * Update an existing resource
     */
    update(resource: WithId<T>): Promise<WithId<T>>;
    /**
     * Delete a resource
     */
    delete(id: string): Promise<void>;
    /**
     * Create or update (upsert)
     */
    createOrUpdate(resource: T | WithId<T>): Promise<WithId<T>>;
}
/**
 * Specific writer types for type safety
 */
export type MaxHealthConsentWriter = FhirResourceWriter<GeneratedTypes.MaxHealthConsent>;
export type MaxHealthShareConsentWriter = FhirResourceWriter<GeneratedTypes.MaxHealthShareConsent>;
import type { FetchFn } from "./resource-reader.js";
/**
 * Implementation of FHIR resource writer
 */
export declare class FhirResourceWriterImpl<T> implements FhirResourceWriter<T> {
    readonly baseUrl: string;
    readonly resourceType: string;
    private readonly fetchFn;
    constructor(baseUrl: string, resourceType: string, fetchFn?: FetchFn);
    create(resource: T): Promise<WithId<T>>;
    update(resource: WithId<T>): Promise<WithId<T>>;
    delete(id: string): Promise<void>;
    createOrUpdate(resource: T | WithId<T>): Promise<WithId<T>>;
}
