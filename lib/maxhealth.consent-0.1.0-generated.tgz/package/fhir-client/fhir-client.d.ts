import { FhirReadClient as BaseFhirReadClient, FhirWriteClient as BaseFhirWriteClient, type FetchFn } from "@babelfhir-ts/client-r4";
import type * as GeneratedTypes from "../index.js";
import type { ConsentSearchParams } from "./types.js";
/**
 * Profile-specific FHIR Read Client.
 * Extends the base R4 read client with typed profile accessors.
 * Inherits all base R4 resource methods from @babelfhir-ts/client-r4.
 */
export declare class FhirReadClient extends BaseFhirReadClient {
    maxHealthConsent(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.MaxHealthConsent, ConsentSearchParams>;
    maxHealthShareConsent(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.MaxHealthShareConsent, ConsentSearchParams>;
}
/**
 * Profile-specific FHIR Write Client.
 * Extends the base R4 write client with typed profile accessors.
 * Inherits all base R4 resource methods from @babelfhir-ts/client-r4.
 */
export declare class FhirWriteClient extends BaseFhirWriteClient {
    maxHealthConsent(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.MaxHealthConsent>;
    maxHealthShareConsent(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.MaxHealthShareConsent>;
}
/**
 * Main FHIR Client — works with plain fetch or an authenticated fetch wrapper.
 * Provides both base R4 accessors (inherited) and profile-specific accessors.
 *
 * @example
 * // Unauthenticated
 * const client = new FhirClient("https://fhir.example.com");
 *
 * // With custom fetch (e.g. from SmartFhirClient)
 * const client = new FhirClient("https://fhir.example.com", authenticatedFetch);
 *
 * // Base R4 methods (inherited from @babelfhir-ts/client-r4)
 * const pt = await client.read().patient().read("123");
 *
 * // Profile-specific methods (generated)
 * const claim = await client.read().pASClaim().search({ status: "active" });
 */
export declare class FhirClient {
    readonly baseUrl: string;
    private readonly readClient;
    private readonly writeClient;
    constructor(baseUrl: string, fetchFn?: FetchFn);
    /**
     * Get a read client for querying resources
     */
    read(): FhirReadClient;
    /**
     * Get a write client for creating/updating resources
     */
    write(): FhirWriteClient;
}
