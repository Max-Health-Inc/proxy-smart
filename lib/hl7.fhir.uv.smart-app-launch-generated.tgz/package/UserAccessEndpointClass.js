import { validateUserAccessEndpoint } from "./UserAccessEndpoint.js";
// Only import helpers actually referenced below (dynamic based on required fields)
import { randomId, setRandomSeed, enrichResource } from "./random/index.js";
import { createRequire } from 'module';
const __require = createRequire(import.meta.url);
function ensureProfile(res, profile) {
    if (!res.meta) {
        res.meta = { profile: [profile] };
        return;
    }
    if (!res.meta.profile) {
        res.meta.profile = [profile];
        return;
    }
    if (!res.meta.profile.includes(profile)) {
        res.meta.profile = [...res.meta.profile, profile];
    }
}
// Internal helper (emitted per class file) to clone without resorting to 'any'.
function safeClone(value) {
    // Use native structuredClone if present; otherwise fallback to JSON round-trip.
    // We intentionally avoid casting through any to satisfy no-explicit-any lint rule.
    const g = globalThis;
    // Narrow globalThis to an object potentially containing structuredClone.
    if (typeof g.structuredClone === 'function') {
        return g.structuredClone(value);
    }
    return JSON.parse(JSON.stringify(value)); // best-effort deep clone
}
export class UserAccessEndpointClass {
    constructor(resource) {
        this.resource = resource;
        ensureProfile(this.resource, 'http://hl7.org/fhir/smart-app-launch/StructureDefinition/user-access-endpoint');
    }
    /** Validate current resource instance. */
    async validate(options) {
        return validateUserAccessEndpoint(this.resource, options);
    }
    getResource() {
        return this.resource;
    }
    setResource(resource) {
        this.resource = resource;
        ensureProfile(this.resource, 'http://hl7.org/fhir/smart-app-launch/StructureDefinition/user-access-endpoint');
    }
    /**
     * Returns a plain JSON clone of the underlying resource ONLY if the last validation succeeded with zero errors.
     * Call validate() first; otherwise this method throws to prevent accidental use of invalid / unchecked data.
     */
    async toJSON() {
        return safeClone(this.resource);
    }
    /**
     * Create an empty instance for parity testing: for true FHIR resources, includes only resourceType; for datatypes, returns an empty object.
     * Note: meta.profile (when applicable) will be ensured by the constructor when wrapping this resource.
     */
    static empty(overrides = {}) {
        // For Resource profiles, include only resourceType. For Extension profiles, include url so the instance is minimally meaningful.
        const base = {
            resourceType: 'Endpoint',
        };
        return { ...base, ...overrides };
    }
    /**
     * Create a minimal randomized instance of UserAccessEndpoint.
     * Populates id, resourceType (if applicable) and primitive required (min>0) top-level fields with placeholders.
     */
    static random(overrides = {}, opts) {
        if (opts?.seed !== undefined) {
            // Direct call (no dynamic require) to ensure deterministic seeding works under ESM.
            setRandomSeed(opts.seed);
        }
        // Start with a Partial to avoid unsafe casting errors; we'll assert at the end.
        const base = { resourceType: 'Endpoint', id: randomId(), extension: [{ url: "http://hl7.org/fhir/StructureDefinition/endpoint-fhir-version", valueCode: "4.0.1" }], status: "suspended", connectionType: { system: "http://terminology.hl7.org/CodeSystem/endpoint-connection-type", code: "hl7-fhir-rest" }, contact: [{ system: "url", value: "placeholder", use: "old" }], payloadType: [({ coding: [{ system: "http://terminology.hl7.org/CodeSystem/endpoint-payload-type", code: "none" }] })], address: 'https://babelfhir.dev/' + randomId(), };
        // Always include meta.profile with this profile's canonical URL if available & only for resource profiles
        ensureProfile(base, 'http://hl7.org/fhir/smart-app-launch/StructureDefinition/user-access-endpoint');
        // Enrich the base resource with common fields using centralized enrichment logic
        enrichResource(base, 'Endpoint', 'http://hl7.org/fhir/smart-app-launch/StructureDefinition/user-access-endpoint', UserAccessEndpointClass._fieldPatterns, UserAccessEndpointClass._forbiddenFields, UserAccessEndpointClass.valueSetBindings, UserAccessEndpointClass._codeResolver, UserAccessEndpointClass._fieldOrder);
        // Cast through unknown to acknowledge dynamic enrichment
        return { ...base, ...overrides };
    }
    /** Convenience: returns a class instance wrapping a randomized resource. */
    static randomClass(overrides = {}, opts) {
        return new UserAccessEndpointClass(this.random(overrides, opts));
    }
}
/** Pattern constraints for profile fields (used by random() generator) */
UserAccessEndpointClass._fieldPatterns = {
    "connectionType": {
        "system": "http://terminology.hl7.org/CodeSystem/endpoint-connection-type",
        "code": "hl7-fhir-rest"
    },
    "configuration-url.system": "url",
    "configuration-url.use": "old",
    "payloadType": {
        "coding": [
            {
                "system": "http://terminology.hl7.org/CodeSystem/endpoint-payload-type",
                "code": "none"
            }
        ]
    },
    "_refReq_contact": {
        "system": true,
        "value": true
    }
};
/** Fields that are forbidden (max=0) in this profile - must not be generated */
UserAccessEndpointClass._forbiddenFields = [];
/** FHIR element ordering for this profile's base resource (used by enrichResource for correct JSON field order) */
UserAccessEndpointClass._fieldOrder = ["id", "meta", "implicitRules", "language", "text", "contained", "extension", "modifierExtension", "identifier", "status", "connectionType", "name", "managingOrganization", "contact", "period", "payloadType", "payloadMimeType", "address", "header"];
/** ValueSet bindings for coded fields - maps field name to ValueSet URL */
UserAccessEndpointClass.valueSetBindings = {
    "language": "http://hl7.org/fhir/ValueSet/languages",
    "status": "http://hl7.org/fhir/ValueSet/endpoint-status|4.0.1",
    "connectionType": "http://hl7.org/fhir/ValueSet/endpoint-connection-type",
    "contact.system": "http://hl7.org/fhir/ValueSet/contact-point-system|4.0.1",
    "contact.use": "http://hl7.org/fhir/ValueSet/contact-point-use|4.0.1",
    "payloadType": "http://hl7.org/fhir/ValueSet/endpoint-payload-type",
    "payloadMimeType": "http://hl7.org/fhir/ValueSet/mimetypes|4.0.1"
};
/** Code resolver for ValueSet bindings - returns a random valid code from a ValueSet by URL */
UserAccessEndpointClass._codeResolver = (() => {
    // Try to load the ValueSetRegistry - it may not exist if no ValueSets were generated
    try {
        const registry = __require('./valuesets/index.js');
        if (registry && typeof registry.getRandomConceptByUrl === 'function') {
            return registry.getRandomConceptByUrl;
        }
    }
    catch { /* ValueSetRegistry not available */ }
    return undefined;
})();
