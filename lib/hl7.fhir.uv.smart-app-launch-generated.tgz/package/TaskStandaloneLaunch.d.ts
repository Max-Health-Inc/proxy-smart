import { Coding, Task, TaskInput } from "fhir/r4";
export interface TaskStandaloneLaunchCodeCoding extends Omit<Coding, 'system' | 'code'> {
    system: "http://hl7.org/fhir/smart-app-launch/CodeSystem/smart-codes";
    code: "launch-app-standalone";
}
export interface TaskStandaloneLaunch extends Omit<Task, 'code' | 'input'> {
    code: {
        coding: TaskStandaloneLaunchCodeCoding[];
    };
    input: TaskInput[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateTaskStandaloneLaunch(resource: TaskStandaloneLaunch, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
