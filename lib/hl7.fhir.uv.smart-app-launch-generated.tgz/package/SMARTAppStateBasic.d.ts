import { Basic } from "fhir/r4";
export type SMARTAppStateBasic = Basic;
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateSMARTAppStateBasic(resource: SMARTAppStateBasic, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
