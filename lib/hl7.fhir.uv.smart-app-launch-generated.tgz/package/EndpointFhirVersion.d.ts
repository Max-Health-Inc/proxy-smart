import { Extension } from "fhir/r4";
export interface EndpointFhirVersion extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/StructureDefinition/endpoint-fhir-version";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateEndpointFhirVersion(resource: EndpointFhirVersion, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
