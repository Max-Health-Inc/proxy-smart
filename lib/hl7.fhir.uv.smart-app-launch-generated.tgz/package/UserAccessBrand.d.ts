import { UserAccessCategoryValueSetCode } from "./valuesets/ValueSet-UserAccessCategoryValueSet";
import { OrganizationBrand } from "./OrganizationBrand";
import { OrganizationPortal } from "./OrganizationPortal";
import { Address, CodeableConcept, Extension, Identifier, Organization, Reference } from "fhir/r4";
export interface UserAccessBrand extends Omit<Organization, 'identifier' | 'type' | 'address' | 'partOf' | 'endpoint' | 'extension'> {
    /** Must Support */
    identifier?: Identifier[];
    /** Must Support */
    type?: (CodeableConcept & {
        coding: Array<{
            code: UserAccessCategoryValueSetCode;
            system: "http://terminology.hl7.org/CodeSystem/organization-type";
        }>;
    } | CodeableConcept)[];
    /** Must Support */
    address?: Address[];
    /** Must Support */
    partOf?: Reference;
    /** Must Support */
    endpoint?: Reference[];
    extension?: (Extension | OrganizationBrand | OrganizationPortal)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateUserAccessBrand(resource: UserAccessBrand, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
