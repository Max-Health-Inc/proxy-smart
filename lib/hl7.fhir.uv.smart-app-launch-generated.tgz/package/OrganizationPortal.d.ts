import { Extension } from "fhir/r4";
export interface OrganizationPortal extends Omit<Extension, 'extension' | 'url'> {
    extension: Extension[];
    url: "http://hl7.org/fhir/StructureDefinition/organization-portal";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateOrganizationPortal(resource: OrganizationPortal, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
