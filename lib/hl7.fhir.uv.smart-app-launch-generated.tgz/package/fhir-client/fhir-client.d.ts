import { FhirReadClient as BaseFhirReadClient, FhirWriteClient as BaseFhirWriteClient, type FetchFn } from "@babelfhir-ts/client-r4";
import type * as GeneratedTypes from "../index.js";
/**
 * Profile-specific FHIR Read Client.
 * Extends the base R4 read client with typed profile accessors.
 * Inherits all base R4 resource methods from @babelfhir-ts/client-r4.
 */
export declare class FhirReadClient extends BaseFhirReadClient {
    taskEhrLaunch(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.TaskEhrLaunch>;
    taskStandaloneLaunch(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.TaskStandaloneLaunch>;
    userAccessBrand(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.UserAccessBrand>;
    userAccessBrandsBundle(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.UserAccessBrandsBundle>;
    userAccessEndpoint(): import("@babelfhir-ts/client-r4").FhirResourceReader<GeneratedTypes.UserAccessEndpoint>;
}
/**
 * Profile-specific FHIR Write Client.
 * Extends the base R4 write client with typed profile accessors.
 * Inherits all base R4 resource methods from @babelfhir-ts/client-r4.
 */
export declare class FhirWriteClient extends BaseFhirWriteClient {
    taskEhrLaunch(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.TaskEhrLaunch>;
    taskStandaloneLaunch(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.TaskStandaloneLaunch>;
    userAccessBrand(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.UserAccessBrand>;
    userAccessBrandsBundle(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.UserAccessBrandsBundle>;
    userAccessEndpoint(): import("@babelfhir-ts/client-r4").FhirResourceWriter<GeneratedTypes.UserAccessEndpoint>;
}
/**
 * Main FHIR Client — works with plain fetch or an authenticated fetch wrapper.
 * Provides both base R4 accessors (inherited) and profile-specific accessors.
 *
 * @example
 * // Unauthenticated
 * const client = new FhirClient("https://fhir.example.com");
 *
 * // With custom fetch (e.g. from SmartFhirClient)
 * const client = new FhirClient("https://fhir.example.com", authenticatedFetch);
 *
 * // Base R4 methods (inherited from @babelfhir-ts/client-r4)
 * const pt = await client.read().patient().read("123");
 *
 * // Profile-specific methods (generated)
 * const claim = await client.read().pASClaim().search({ status: "active" });
 */
export declare class FhirClient {
    readonly baseUrl: string;
    private readonly readClient;
    private readonly writeClient;
    constructor(baseUrl: string, fetchFn?: FetchFn);
    /**
     * Get a read client for querying resources
     */
    read(): FhirReadClient;
    /**
     * Get a write client for creating/updating resources
     */
    write(): FhirWriteClient;
}
