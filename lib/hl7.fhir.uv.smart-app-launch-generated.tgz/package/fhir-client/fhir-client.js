import { FhirReadClient as BaseFhirReadClient, FhirWriteClient as BaseFhirWriteClient, } from "@babelfhir-ts/client-r4";
/**
 * Profile-specific FHIR Read Client.
 * Extends the base R4 read client with typed profile accessors.
 * Inherits all base R4 resource methods from @babelfhir-ts/client-r4.
 */
export class FhirReadClient extends BaseFhirReadClient {
    taskEhrLaunch() {
        return this.forType("Task");
    }
    taskStandaloneLaunch() {
        return this.forType("Task");
    }
    userAccessBrand() {
        return this.forType("Organization");
    }
    userAccessBrandsBundle() {
        return this.forType("Bundle");
    }
    userAccessEndpoint() {
        return this.forType("Endpoint");
    }
}
/**
 * Profile-specific FHIR Write Client.
 * Extends the base R4 write client with typed profile accessors.
 * Inherits all base R4 resource methods from @babelfhir-ts/client-r4.
 */
export class FhirWriteClient extends BaseFhirWriteClient {
    taskEhrLaunch() {
        return this.forType("Task");
    }
    taskStandaloneLaunch() {
        return this.forType("Task");
    }
    userAccessBrand() {
        return this.forType("Organization");
    }
    userAccessBrandsBundle() {
        return this.forType("Bundle");
    }
    userAccessEndpoint() {
        return this.forType("Endpoint");
    }
}
/**
 * Main FHIR Client — works with plain fetch or an authenticated fetch wrapper.
 * Provides both base R4 accessors (inherited) and profile-specific accessors.
 *
 * @example
 * // Unauthenticated
 * const client = new FhirClient("https://fhir.example.com");
 *
 * // With custom fetch (e.g. from SmartFhirClient)
 * const client = new FhirClient("https://fhir.example.com", authenticatedFetch);
 *
 * // Base R4 methods (inherited from @babelfhir-ts/client-r4)
 * const pt = await client.read().patient().read("123");
 *
 * // Profile-specific methods (generated)
 * const claim = await client.read().pASClaim().search({ status: "active" });
 */
export class FhirClient {
    constructor(baseUrl, fetchFn) {
        this.baseUrl = baseUrl;
        this.readClient = new FhirReadClient(baseUrl, fetchFn);
        this.writeClient = new FhirWriteClient(baseUrl, fetchFn);
    }
    /**
     * Get a read client for querying resources
     */
    read() {
        return this.readClient;
    }
    /**
     * Get a write client for creating/updating resources
     */
    write() {
        return this.writeClient;
    }
}
