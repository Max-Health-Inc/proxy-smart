import { validateUserAccessBrandsBundle } from "./UserAccessBrandsBundle.js";
// Only import helpers actually referenced below (dynamic based on required fields)
import { randomId, setRandomSeed, enrichResource } from "./random/index.js";
import { createRequire } from 'module';
const __require = createRequire(import.meta.url);
function ensureProfile(res, profile) {
    if (!res.meta) {
        res.meta = { profile: [profile] };
        return;
    }
    if (!res.meta.profile) {
        res.meta.profile = [profile];
        return;
    }
    if (!res.meta.profile.includes(profile)) {
        res.meta.profile = [...res.meta.profile, profile];
    }
}
// Internal helper (emitted per class file) to clone without resorting to 'any'.
function safeClone(value) {
    // Use native structuredClone if present; otherwise fallback to JSON round-trip.
    // We intentionally avoid casting through any to satisfy no-explicit-any lint rule.
    const g = globalThis;
    // Narrow globalThis to an object potentially containing structuredClone.
    if (typeof g.structuredClone === 'function') {
        return g.structuredClone(value);
    }
    return JSON.parse(JSON.stringify(value)); // best-effort deep clone
}
export class UserAccessBrandsBundleClass {
    constructor(resource) {
        this.resource = resource;
        ensureProfile(this.resource, 'http://hl7.org/fhir/smart-app-launch/StructureDefinition/user-access-brands-bundle');
    }
    /** Validate current resource instance. */
    async validate(options) {
        return validateUserAccessBrandsBundle(this.resource, options);
    }
    getResource() {
        return this.resource;
    }
    setResource(resource) {
        this.resource = resource;
        ensureProfile(this.resource, 'http://hl7.org/fhir/smart-app-launch/StructureDefinition/user-access-brands-bundle');
    }
    /**
     * Returns a plain JSON clone of the underlying resource ONLY if the last validation succeeded with zero errors.
     * Call validate() first; otherwise this method throws to prevent accidental use of invalid / unchecked data.
     */
    async toJSON() {
        return safeClone(this.resource);
    }
    /**
     * Create an empty instance for parity testing: for true FHIR resources, includes only resourceType; for datatypes, returns an empty object.
     * Note: meta.profile (when applicable) will be ensured by the constructor when wrapping this resource.
     */
    static empty(overrides = {}) {
        // For Resource profiles, include only resourceType. For Extension profiles, include url so the instance is minimally meaningful.
        const base = {
            resourceType: 'Bundle',
        };
        return { ...base, ...overrides };
    }
    /**
     * Create a minimal randomized instance of UserAccessBrandsBundle.
     * Populates id, resourceType (if applicable) and primitive required (min>0) top-level fields with placeholders.
     */
    static random(overrides = {}, opts) {
        if (opts?.seed !== undefined) {
            // Direct call (no dynamic require) to ensure deterministic seeding works under ESM.
            setRandomSeed(opts.seed);
        }
        // Start with a Partial to avoid unsafe casting errors; we'll assert at the end.
        const base = { resourceType: 'Bundle', id: randomId(), type: "collection", };
        // Always include meta.profile with this profile's canonical URL if available & only for resource profiles
        ensureProfile(base, 'http://hl7.org/fhir/smart-app-launch/StructureDefinition/user-access-brands-bundle');
        // Enrich the base resource with common fields using centralized enrichment logic
        enrichResource(base, 'Bundle', 'http://hl7.org/fhir/smart-app-launch/StructureDefinition/user-access-brands-bundle', UserAccessBrandsBundleClass._fieldPatterns, UserAccessBrandsBundleClass._forbiddenFields, UserAccessBrandsBundleClass.valueSetBindings, UserAccessBrandsBundleClass._codeResolver, UserAccessBrandsBundleClass._fieldOrder);
        // Cast through unknown to acknowledge dynamic enrichment
        return { ...base, ...overrides };
    }
    /** Convenience: returns a class instance wrapping a randomized resource. */
    static randomClass(overrides = {}, opts) {
        return new UserAccessBrandsBundleClass(this.random(overrides, opts));
    }
}
/** Pattern constraints for profile fields (used by random() generator) */
UserAccessBrandsBundleClass._fieldPatterns = {
    "type": "collection",
    "entry.request.method": "PATCH",
    "UserAccessEndpoint.request.method": "PATCH",
    "UserAccessBrand.request.method": "PATCH",
    "_refReq_meta": {
        "lastUpdated": true
    },
    "_refReq_link": {
        "relation": true,
        "url": true
    },
    "_refReq_entry": {
        "request.method": true,
        "request.url": true,
        "response.status": true
    }
};
/** Fields that are forbidden (max=0) in this profile - must not be generated */
UserAccessBrandsBundleClass._forbiddenFields = [];
/** FHIR element ordering for this profile's base resource (used by enrichResource for correct JSON field order) */
UserAccessBrandsBundleClass._fieldOrder = ["id", "meta", "implicitRules", "language", "identifier", "type", "timestamp", "total", "link", "entry", "signature"];
/** ValueSet bindings for coded fields - maps field name to ValueSet URL */
UserAccessBrandsBundleClass.valueSetBindings = {
    "meta.security": "http://hl7.org/fhir/ValueSet/security-labels",
    "meta.tag": "http://hl7.org/fhir/ValueSet/common-tags",
    "language": "http://hl7.org/fhir/ValueSet/languages",
    "type": "http://hl7.org/fhir/ValueSet/bundle-type|4.0.1",
    "entry.search.mode": "http://hl7.org/fhir/ValueSet/search-entry-mode|4.0.1",
    "entry.request.method": "http://hl7.org/fhir/ValueSet/http-verb|4.0.1"
};
/** Code resolver for ValueSet bindings - returns a random valid code from a ValueSet by URL */
UserAccessBrandsBundleClass._codeResolver = (() => {
    // Try to load the ValueSetRegistry - it may not exist if no ValueSets were generated
    try {
        const registry = __require('./valuesets/index.js');
        if (registry && typeof registry.getRandomConceptByUrl === 'function') {
            return registry.getRandomConceptByUrl;
        }
    }
    catch { /* ValueSetRegistry not available */ }
    return undefined;
})();
