import { Extension } from "fhir/r4";
export interface OrganizationBrand extends Omit<Extension, 'url'> {
    url: "http://hl7.org/fhir/StructureDefinition/organization-brand";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateOrganizationBrand(resource: OrganizationBrand, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
