import { EndpointFhirVersion } from "./EndpointFhirVersion";
import { Coding, ContactPoint, Endpoint, Extension } from "fhir/r4";
export interface UserAccessEndpointConnectionType extends Omit<Coding, 'system' | 'code'> {
    system: "http://terminology.hl7.org/CodeSystem/endpoint-connection-type";
    code: "hl7-fhir-rest";
}
export interface UserAccessEndpointPayloadTypeCoding extends Omit<Coding, 'system' | 'code'> {
    system: "http://terminology.hl7.org/CodeSystem/endpoint-payload-type";
    code: "none";
}
export interface UserAccessEndpoint extends Omit<Endpoint, 'connectionType' | 'contact' | 'payloadType' | 'extension'> {
    connectionType: UserAccessEndpointConnectionType;
    /** Must Support */
    contact: ContactPoint[];
    payloadType: Array<{
        coding: UserAccessEndpointPayloadTypeCoding[];
    }>;
    extension?: (Extension | EndpointFhirVersion)[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateUserAccessEndpoint(resource: UserAccessEndpoint, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
