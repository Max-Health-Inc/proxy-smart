/**
 * ValueSet Registry
 * Central registry of all loaded ValueSets with explicit codes
 */
import * as AllSecurityLabels from './ValueSet-AllSecurityLabels.js';
import * as BasicResourceTypes from './ValueSet-BasicResourceTypes.js';
import * as BundleType from './ValueSet-BundleType.js';
import * as CommonLanguages from './ValueSet-CommonLanguages.js';
import * as CommonTags from './ValueSet-CommonTags.js';
import * as ContactEntityType from './ValueSet-ContactEntityType.js';
import * as ContactPointSystem from './ValueSet-ContactPointSystem.js';
import * as ContactPointUse from './ValueSet-ContactPointUse.js';
import * as EndpointConnectionType from './ValueSet-EndpointConnectionType.js';
import * as EndpointPayloadType from './ValueSet-EndpointPayloadType.js';
import * as EndpointStatus from './ValueSet-EndpointStatus.js';
import * as HttpVerb from './ValueSet-HttpVerb.js';
import * as OrganizationType from './ValueSet-OrganizationType.js';
import * as ProcedurePerformerRoleCodes from './ValueSet-ProcedurePerformerRoleCodes.js';
import * as RequestPriority from './ValueSet-RequestPriority.js';
import * as ResourceType from './ValueSet-ResourceType.js';
import * as SearchEntryMode from './ValueSet-SearchEntryMode.js';
import * as SmartLaunchInformation from './ValueSet-SmartLaunchInformation.js';
import * as SmartLaunchTypes from './ValueSet-SmartLaunchTypes.js';
import * as TaskIntent from './ValueSet-TaskIntent.js';
import * as TaskStatus from './ValueSet-TaskStatus.js';
import * as UserAccessCategoryValueSet from './ValueSet-UserAccessCategoryValueSet.js';
export declare const ValueSetRegistry: {
    readonly AllSecurityLabels: typeof AllSecurityLabels;
    readonly BasicResourceTypes: typeof BasicResourceTypes;
    readonly BundleType: typeof BundleType;
    readonly CommonLanguages: typeof CommonLanguages;
    readonly CommonTags: typeof CommonTags;
    readonly ContactEntityType: typeof ContactEntityType;
    readonly ContactPointSystem: typeof ContactPointSystem;
    readonly ContactPointUse: typeof ContactPointUse;
    readonly EndpointConnectionType: typeof EndpointConnectionType;
    readonly EndpointPayloadType: typeof EndpointPayloadType;
    readonly EndpointStatus: typeof EndpointStatus;
    readonly HttpVerb: typeof HttpVerb;
    readonly OrganizationType: typeof OrganizationType;
    readonly ProcedurePerformerRoleCodes: typeof ProcedurePerformerRoleCodes;
    readonly RequestPriority: typeof RequestPriority;
    readonly ResourceType: typeof ResourceType;
    readonly SearchEntryMode: typeof SearchEntryMode;
    readonly SmartLaunchInformation: typeof SmartLaunchInformation;
    readonly SmartLaunchTypes: typeof SmartLaunchTypes;
    readonly TaskIntent: typeof TaskIntent;
    readonly TaskStatus: typeof TaskStatus;
    readonly UserAccessCategoryValueSet: typeof UserAccessCategoryValueSet;
};
export type ValueSetName = keyof typeof ValueSetRegistry;
export declare function getValueSet(name: ValueSetName): typeof AllSecurityLabels | typeof BasicResourceTypes | typeof BundleType | typeof CommonLanguages | typeof CommonTags | typeof ContactEntityType | typeof ContactPointSystem | typeof ContactPointUse | typeof EndpointConnectionType | typeof EndpointPayloadType | typeof EndpointStatus | typeof HttpVerb | typeof OrganizationType | typeof ProcedurePerformerRoleCodes | typeof RequestPriority | typeof ResourceType | typeof SearchEntryMode | typeof SmartLaunchInformation | typeof SmartLaunchTypes | typeof TaskIntent | typeof TaskStatus | typeof UserAccessCategoryValueSet;
/** Map from ValueSet URL to registry name */
export declare const ValueSetUrlMap: Record<string, ValueSetName>;
/**
 * Get a random code from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A random code string, or undefined if ValueSet not found
 */
export declare function getRandomCodeByUrl(url: string): string | undefined;
/**
 * Get a random concept (code, system, display) from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A concept object with code, system, and optional display, or undefined if ValueSet not found
 */
export declare function getRandomConceptByUrl(url: string): {
    code: string;
    system: string;
    display?: string;
} | undefined;
