/**
 * ValueSet Registry
 * Central registry of all loaded ValueSets with explicit codes
 */
import * as BundleType from './ValueSet-BundleType.js';
import * as ContactPointSystem from './ValueSet-ContactPointSystem.js';
import * as ContactPointUse from './ValueSet-ContactPointUse.js';
import * as HttpVerb from './ValueSet-HttpVerb.js';
import * as RequestPriority from './ValueSet-RequestPriority.js';
import * as SmartLaunchInformation from './ValueSet-SmartLaunchInformation.js';
import * as SmartLaunchTypes from './ValueSet-SmartLaunchTypes.js';
import * as TaskStatus from './ValueSet-TaskStatus.js';
import * as UserAccessCategoryValueSet from './ValueSet-UserAccessCategoryValueSet.js';
export declare const ValueSetRegistry: {
    readonly BundleType: typeof BundleType;
    readonly ContactPointSystem: typeof ContactPointSystem;
    readonly ContactPointUse: typeof ContactPointUse;
    readonly HttpVerb: typeof HttpVerb;
    readonly RequestPriority: typeof RequestPriority;
    readonly SmartLaunchInformation: typeof SmartLaunchInformation;
    readonly SmartLaunchTypes: typeof SmartLaunchTypes;
    readonly TaskStatus: typeof TaskStatus;
    readonly UserAccessCategoryValueSet: typeof UserAccessCategoryValueSet;
};
export type ValueSetName = keyof typeof ValueSetRegistry;
export declare function getValueSet(name: ValueSetName): typeof BundleType | typeof ContactPointSystem | typeof ContactPointUse | typeof HttpVerb | typeof RequestPriority | typeof SmartLaunchInformation | typeof SmartLaunchTypes | typeof TaskStatus | typeof UserAccessCategoryValueSet;
/** Map from ValueSet URL to registry name */
export declare const ValueSetUrlMap: Record<string, ValueSetName>;
/**
 * Get a random code from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A random code string, or undefined if ValueSet not found
 */
export declare function getRandomCodeByUrl(url: string): string | undefined;
/**
 * Get a random concept (code, system, display) from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A concept object with code, system, and optional display, or undefined if ValueSet not found
 */
export declare function getRandomConceptByUrl(url: string): {
    code: string;
    system: string;
    display?: string;
} | undefined;
