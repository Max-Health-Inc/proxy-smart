/**
 * ValueSet Registry
 * Central registry of all loaded ValueSets with explicit codes
 */
import * as BasicResourceType from './ValueSet-BasicResourceType.js';
import * as BundleType from './ValueSet-BundleType.js';
import * as CommonTags from './ValueSet-CommonTags.js';
import * as ContactentityType from './ValueSet-ContactentityType.js';
import * as ContactPointSystem from './ValueSet-ContactPointSystem.js';
import * as ContactPointUse from './ValueSet-ContactPointUse.js';
import * as EndpointConnectionType from './ValueSet-EndpointConnectionType.js';
import * as EndpointPayloadType from './ValueSet-EndpointPayloadType.js';
import * as EndpointStatus from './ValueSet-EndpointStatus.js';
import * as HttpVerb from './ValueSet-HttpVerb.js';
import * as Languages from './ValueSet-Languages.js';
import * as OrganizationType from './ValueSet-OrganizationType.js';
import * as RequestPriority from './ValueSet-RequestPriority.js';
import * as ResourceTypes from './ValueSet-ResourceTypes.js';
import * as SearchEntryMode from './ValueSet-SearchEntryMode.js';
import * as SecurityLabels from './ValueSet-SecurityLabels.js';
import * as SmartLaunchInformation from './ValueSet-SmartLaunchInformation.js';
import * as SmartLaunchTypes from './ValueSet-SmartLaunchTypes.js';
import * as TaskIntent from './ValueSet-TaskIntent.js';
import * as TaskStatus from './ValueSet-TaskStatus.js';
import * as UserAccessCategoryValueSet from './ValueSet-UserAccessCategoryValueSet.js';
export declare const ValueSetRegistry: {
    readonly BasicResourceType: typeof BasicResourceType;
    readonly BundleType: typeof BundleType;
    readonly CommonTags: typeof CommonTags;
    readonly ContactentityType: typeof ContactentityType;
    readonly ContactPointSystem: typeof ContactPointSystem;
    readonly ContactPointUse: typeof ContactPointUse;
    readonly EndpointConnectionType: typeof EndpointConnectionType;
    readonly EndpointPayloadType: typeof EndpointPayloadType;
    readonly EndpointStatus: typeof EndpointStatus;
    readonly HttpVerb: typeof HttpVerb;
    readonly Languages: typeof Languages;
    readonly OrganizationType: typeof OrganizationType;
    readonly RequestPriority: typeof RequestPriority;
    readonly ResourceTypes: typeof ResourceTypes;
    readonly SearchEntryMode: typeof SearchEntryMode;
    readonly SecurityLabels: typeof SecurityLabels;
    readonly SmartLaunchInformation: typeof SmartLaunchInformation;
    readonly SmartLaunchTypes: typeof SmartLaunchTypes;
    readonly TaskIntent: typeof TaskIntent;
    readonly TaskStatus: typeof TaskStatus;
    readonly UserAccessCategoryValueSet: typeof UserAccessCategoryValueSet;
};
export type ValueSetName = keyof typeof ValueSetRegistry;
export declare function getValueSet(name: ValueSetName): typeof BasicResourceType | typeof BundleType | typeof CommonTags | typeof ContactentityType | typeof ContactPointSystem | typeof ContactPointUse | typeof EndpointConnectionType | typeof EndpointPayloadType | typeof EndpointStatus | typeof HttpVerb | typeof Languages | typeof OrganizationType | typeof RequestPriority | typeof ResourceTypes | typeof SearchEntryMode | typeof SecurityLabels | typeof SmartLaunchInformation | typeof SmartLaunchTypes | typeof TaskIntent | typeof TaskStatus | typeof UserAccessCategoryValueSet;
/** Map from ValueSet URL to registry name */
export declare const ValueSetUrlMap: Record<string, ValueSetName>;
/**
 * Get a random code from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A random code string, or undefined if ValueSet not found
 */
export declare function getRandomCodeByUrl(url: string): string | undefined;
/**
 * Get a random concept (code, system, display) from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A concept object with code, system, and optional display, or undefined if ValueSet not found
 */
export declare function getRandomConceptByUrl(url: string): {
    code: string;
    system: string;
    display?: string;
} | undefined;
