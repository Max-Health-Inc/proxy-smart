/**
 * ValueSet: SmartLaunchTypes
 * URL: http://hl7.org/fhir/smart-app-launch/ValueSet/smart-launch-types
 * Size: 2 concepts
 */
export declare const SmartLaunchTypesConcepts: readonly [{
    readonly code: "launch-app-ehr";
    readonly system: "http://hl7.org/fhir/smart-app-launch/CodeSystem/smart-codes";
    readonly display: "Launch application using the SMART EHR launch";
}, {
    readonly code: "launch-app-standalone";
    readonly system: "http://hl7.org/fhir/smart-app-launch/CodeSystem/smart-codes";
    readonly display: "Launch application using the SMART standalone launch";
}];
/** Union type of all valid codes in this ValueSet */
export type SmartLaunchTypesCode = "launch-app-ehr" | "launch-app-standalone";
/** Type representing a concept from this ValueSet */
export type SmartLaunchTypesConcept = typeof SmartLaunchTypesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidSmartLaunchTypesCode(code: string): code is SmartLaunchTypesCode;
/**
 * Get concept details by code
 */
export declare function getSmartLaunchTypesConcept(code: string): SmartLaunchTypesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const SmartLaunchTypesCodes: ("launch-app-ehr" | "launch-app-standalone")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomSmartLaunchTypesCode(): SmartLaunchTypesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomSmartLaunchTypesConcept(): SmartLaunchTypesConcept;
