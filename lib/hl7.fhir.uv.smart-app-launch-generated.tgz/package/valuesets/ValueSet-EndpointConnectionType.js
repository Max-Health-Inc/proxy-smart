/**
 * ValueSet: EndpointConnectionType
 * URL: http://hl7.org/fhir/ValueSet/endpoint-connection-type
 * Size: 14 concepts
 */
export const EndpointConnectionTypeConcepts = [
    { code: "ihe-xcpd", system: "http://terminology.hl7.org/CodeSystem/endpoint-connection-type", display: "IHE XCPD" },
    { code: "ihe-xca", system: "http://terminology.hl7.org/CodeSystem/endpoint-connection-type", display: "IHE XCA" },
    { code: "ihe-xdr", system: "http://terminology.hl7.org/CodeSystem/endpoint-connection-type", display: "IHE XDR" },
    { code: "ihe-xds", system: "http://terminology.hl7.org/CodeSystem/endpoint-connection-type", display: "IHE XDS" },
    { code: "ihe-iid", system: "http://terminology.hl7.org/CodeSystem/endpoint-connection-type", display: "IHE IID" },
    { code: "dicom-wado-rs", system: "http://terminology.hl7.org/CodeSystem/endpoint-connection-type", display: "DICOM WADO-RS" },
    { code: "dicom-qido-rs", system: "http://terminology.hl7.org/CodeSystem/endpoint-connection-type", display: "DICOM QIDO-RS" },
    { code: "dicom-stow-rs", system: "http://terminology.hl7.org/CodeSystem/endpoint-connection-type", display: "DICOM STOW-RS" },
    { code: "dicom-wado-uri", system: "http://terminology.hl7.org/CodeSystem/endpoint-connection-type", display: "DICOM WADO-URI" },
    { code: "hl7-fhir-rest", system: "http://terminology.hl7.org/CodeSystem/endpoint-connection-type", display: "HL7 FHIR" },
    { code: "hl7-fhir-msg", system: "http://terminology.hl7.org/CodeSystem/endpoint-connection-type", display: "HL7 FHIR Messaging" },
    { code: "hl7v2-mllp", system: "http://terminology.hl7.org/CodeSystem/endpoint-connection-type", display: "HL7 v2 MLLP" },
    { code: "secure-email", system: "http://terminology.hl7.org/CodeSystem/endpoint-connection-type", display: "Secure email" },
    { code: "direct-project", system: "http://terminology.hl7.org/CodeSystem/endpoint-connection-type", display: "Direct Project" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidEndpointConnectionTypeCode(code) {
    return EndpointConnectionTypeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getEndpointConnectionTypeConcept(code) {
    return EndpointConnectionTypeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const EndpointConnectionTypeCodes = EndpointConnectionTypeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomEndpointConnectionTypeCode() {
    return EndpointConnectionTypeCodes[Math.floor(Math.random() * EndpointConnectionTypeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomEndpointConnectionTypeConcept() {
    return EndpointConnectionTypeConcepts[Math.floor(Math.random() * EndpointConnectionTypeConcepts.length)];
}
