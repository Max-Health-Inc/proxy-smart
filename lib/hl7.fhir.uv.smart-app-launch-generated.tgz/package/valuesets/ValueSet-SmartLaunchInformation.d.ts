/**
 * ValueSet: SmartLaunchInformation
 * URL: http://hl7.org/fhir/smart-app-launch/ValueSet/smart-launch-info
 * Size: 2 concepts
 */
export declare const SmartLaunchInformationConcepts: readonly [{
    readonly code: "smartonfhir-application";
    readonly system: "http://hl7.org/fhir/smart-app-launch/CodeSystem/smart-codes";
    readonly display: "SMART on FHIR application URL.";
}, {
    readonly code: "smartonfhir-appcontext";
    readonly system: "http://hl7.org/fhir/smart-app-launch/CodeSystem/smart-codes";
    readonly display: "Application context related to this launch.";
}];
/** Union type of all valid codes in this ValueSet */
export type SmartLaunchInformationCode = "smartonfhir-application" | "smartonfhir-appcontext";
/** Type representing a concept from this ValueSet */
export type SmartLaunchInformationConcept = typeof SmartLaunchInformationConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidSmartLaunchInformationCode(code: string): code is SmartLaunchInformationCode;
/**
 * Get concept details by code
 */
export declare function getSmartLaunchInformationConcept(code: string): SmartLaunchInformationConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const SmartLaunchInformationCodes: ("smartonfhir-application" | "smartonfhir-appcontext")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomSmartLaunchInformationCode(): SmartLaunchInformationCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomSmartLaunchInformationConcept(): SmartLaunchInformationConcept;
