/**
 * ValueSet: task-status
 * URL: http://hl7.org/fhir/ValueSet/task-status
 * Size: 12 concepts
 */
export declare const TaskStatusConcepts: readonly [{
    readonly code: "draft";
    readonly system: "http://hl7.org/fhir/task-status";
}, {
    readonly code: "requested";
    readonly system: "http://hl7.org/fhir/task-status";
}, {
    readonly code: "received";
    readonly system: "http://hl7.org/fhir/task-status";
}, {
    readonly code: "accepted";
    readonly system: "http://hl7.org/fhir/task-status";
}, {
    readonly code: "rejected";
    readonly system: "http://hl7.org/fhir/task-status";
}, {
    readonly code: "ready";
    readonly system: "http://hl7.org/fhir/task-status";
}, {
    readonly code: "cancelled";
    readonly system: "http://hl7.org/fhir/task-status";
}, {
    readonly code: "in-progress";
    readonly system: "http://hl7.org/fhir/task-status";
}, {
    readonly code: "on-hold";
    readonly system: "http://hl7.org/fhir/task-status";
}, {
    readonly code: "failed";
    readonly system: "http://hl7.org/fhir/task-status";
}, {
    readonly code: "completed";
    readonly system: "http://hl7.org/fhir/task-status";
}, {
    readonly code: "entered-in-error";
    readonly system: "http://hl7.org/fhir/task-status";
}];
/** Union type of all valid codes in this ValueSet */
export type TaskStatusCode = "draft" | "requested" | "received" | "accepted" | "rejected" | "ready" | "cancelled" | "in-progress" | "on-hold" | "failed" | "completed" | "entered-in-error";
/** Type representing a concept from this ValueSet */
export type TaskStatusConcept = typeof TaskStatusConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidTaskStatusCode(code: string): code is TaskStatusCode;
/**
 * Get concept details by code
 */
export declare function getTaskStatusConcept(code: string): TaskStatusConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const TaskStatusCodes: ("entered-in-error" | "completed" | "requested" | "draft" | "received" | "accepted" | "rejected" | "ready" | "cancelled" | "in-progress" | "on-hold" | "failed")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomTaskStatusCode(): TaskStatusCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomTaskStatusConcept(): TaskStatusConcept;
