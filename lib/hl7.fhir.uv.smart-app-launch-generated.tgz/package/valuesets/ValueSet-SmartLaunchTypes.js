/**
 * ValueSet: SmartLaunchTypes
 * URL: http://hl7.org/fhir/smart-app-launch/ValueSet/smart-launch-types
 * Size: 2 concepts
 */
export const SmartLaunchTypesConcepts = [
    { code: "launch-app-ehr", system: "http://hl7.org/fhir/smart-app-launch/CodeSystem/smart-codes", display: "Launch application using the SMART EHR launch" },
    { code: "launch-app-standalone", system: "http://hl7.org/fhir/smart-app-launch/CodeSystem/smart-codes", display: "Launch application using the SMART standalone launch" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidSmartLaunchTypesCode(code) {
    return SmartLaunchTypesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getSmartLaunchTypesConcept(code) {
    return SmartLaunchTypesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const SmartLaunchTypesCodes = SmartLaunchTypesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomSmartLaunchTypesCode() {
    return SmartLaunchTypesCodes[Math.floor(Math.random() * SmartLaunchTypesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomSmartLaunchTypesConcept() {
    return SmartLaunchTypesConcepts[Math.floor(Math.random() * SmartLaunchTypesConcepts.length)];
}
