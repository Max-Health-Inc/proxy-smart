/**
 * ValueSet: basic-resource-type
 * URL: http://hl7.org/fhir/ValueSet/basic-resource-type
 * Size: 16 concepts
 */
export declare const BasicResourceTypeConcepts: readonly [{
    readonly code: "consent";
    readonly system: "http://terminology.hl7.org/CodeSystem/basic-resource-type";
}, {
    readonly code: "referral";
    readonly system: "http://terminology.hl7.org/CodeSystem/basic-resource-type";
}, {
    readonly code: "advevent";
    readonly system: "http://terminology.hl7.org/CodeSystem/basic-resource-type";
}, {
    readonly code: "aptmtreq";
    readonly system: "http://terminology.hl7.org/CodeSystem/basic-resource-type";
}, {
    readonly code: "transfer";
    readonly system: "http://terminology.hl7.org/CodeSystem/basic-resource-type";
}, {
    readonly code: "diet";
    readonly system: "http://terminology.hl7.org/CodeSystem/basic-resource-type";
}, {
    readonly code: "adminact";
    readonly system: "http://terminology.hl7.org/CodeSystem/basic-resource-type";
}, {
    readonly code: "exposure";
    readonly system: "http://terminology.hl7.org/CodeSystem/basic-resource-type";
}, {
    readonly code: "investigation";
    readonly system: "http://terminology.hl7.org/CodeSystem/basic-resource-type";
}, {
    readonly code: "account";
    readonly system: "http://terminology.hl7.org/CodeSystem/basic-resource-type";
}, {
    readonly code: "invoice";
    readonly system: "http://terminology.hl7.org/CodeSystem/basic-resource-type";
}, {
    readonly code: "adjudicat";
    readonly system: "http://terminology.hl7.org/CodeSystem/basic-resource-type";
}, {
    readonly code: "predetreq";
    readonly system: "http://terminology.hl7.org/CodeSystem/basic-resource-type";
}, {
    readonly code: "predetermine";
    readonly system: "http://terminology.hl7.org/CodeSystem/basic-resource-type";
}, {
    readonly code: "study";
    readonly system: "http://terminology.hl7.org/CodeSystem/basic-resource-type";
}, {
    readonly code: "protocol";
    readonly system: "http://terminology.hl7.org/CodeSystem/basic-resource-type";
}];
/** Union type of all valid codes in this ValueSet */
export type BasicResourceTypeCode = "consent" | "referral" | "advevent" | "aptmtreq" | "transfer" | "diet" | "adminact" | "exposure" | "investigation" | "account" | "invoice" | "adjudicat" | "predetreq" | "predetermine" | "study" | "protocol";
/** Type representing a concept from this ValueSet */
export type BasicResourceTypeConcept = typeof BasicResourceTypeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidBasicResourceTypeCode(code: string): code is BasicResourceTypeCode;
/**
 * Get concept details by code
 */
export declare function getBasicResourceTypeConcept(code: string): BasicResourceTypeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const BasicResourceTypeCodes: ("study" | "consent" | "referral" | "advevent" | "aptmtreq" | "transfer" | "diet" | "adminact" | "exposure" | "investigation" | "account" | "invoice" | "adjudicat" | "predetreq" | "predetermine" | "protocol")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomBasicResourceTypeCode(): BasicResourceTypeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomBasicResourceTypeConcept(): BasicResourceTypeConcept;
