/**
 * ValueSet: security-labels
 * URL: http://hl7.org/fhir/ValueSet/security-labels
 * Size: 36 concepts
 */
export const SecurityLabelsConcepts = [
    { code: "_Confidentiality", system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality" },
    { code: "L", system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality" },
    { code: "M", system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality" },
    { code: "N", system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality" },
    { code: "R", system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality" },
    { code: "U", system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality" },
    { code: "V", system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality" },
    { code: "_ConfidentialityByAccessKind", system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality" },
    { code: "B", system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality" },
    { code: "D", system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality" },
    { code: "I", system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality" },
    { code: "_ConfidentialityByInfoType", system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality" },
    { code: "ETH", system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality" },
    { code: "HIV", system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality" },
    { code: "PSY", system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality" },
    { code: "SDV", system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality" },
    { code: "_ConfidentialityModifiers", system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality" },
    { code: "C", system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality" },
    { code: "S", system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality" },
    { code: "T", system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality" },
    { code: "COVERAGE", system: "http://terminology.hl7.org/CodeSystem/v3-ActReason" },
    { code: "ETREAT", system: "http://terminology.hl7.org/CodeSystem/v3-ActReason" },
    { code: "HMARKT", system: "http://terminology.hl7.org/CodeSystem/v3-ActReason" },
    { code: "HOPERAT", system: "http://terminology.hl7.org/CodeSystem/v3-ActReason" },
    { code: "HPAYMT", system: "http://terminology.hl7.org/CodeSystem/v3-ActReason" },
    { code: "HRESCH", system: "http://terminology.hl7.org/CodeSystem/v3-ActReason" },
    { code: "PATRQT", system: "http://terminology.hl7.org/CodeSystem/v3-ActReason" },
    { code: "PUBHLTH", system: "http://terminology.hl7.org/CodeSystem/v3-ActReason" },
    { code: "TREAT", system: "http://terminology.hl7.org/CodeSystem/v3-ActReason" },
    { code: "_ActUSPrivacyLaw", system: "http://terminology.hl7.org/CodeSystem/v3-ActUSPrivacyLaw" },
    { code: "42CFRPart2", system: "http://terminology.hl7.org/CodeSystem/v3-ActUSPrivacyLaw" },
    { code: "CommonRule", system: "http://terminology.hl7.org/CodeSystem/v3-ActUSPrivacyLaw" },
    { code: "HIPAANOPP", system: "http://terminology.hl7.org/CodeSystem/v3-ActUSPrivacyLaw" },
    { code: "HIPAAPsyNotes", system: "http://terminology.hl7.org/CodeSystem/v3-ActUSPrivacyLaw" },
    { code: "HIPAASelfPay", system: "http://terminology.hl7.org/CodeSystem/v3-ActUSPrivacyLaw" },
    { code: "Title38Section7332", system: "http://terminology.hl7.org/CodeSystem/v3-ActUSPrivacyLaw" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidSecurityLabelsCode(code) {
    return SecurityLabelsConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getSecurityLabelsConcept(code) {
    return SecurityLabelsConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const SecurityLabelsCodes = SecurityLabelsConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomSecurityLabelsCode() {
    return SecurityLabelsCodes[Math.floor(Math.random() * SecurityLabelsCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomSecurityLabelsConcept() {
    return SecurityLabelsConcepts[Math.floor(Math.random() * SecurityLabelsConcepts.length)];
}
