/**
 * ValueSet: basic-resource-type
 * URL: http://hl7.org/fhir/ValueSet/basic-resource-type
 * Size: 16 concepts
 */
export const BasicResourceTypeConcepts = [
    { code: "consent", system: "http://terminology.hl7.org/CodeSystem/basic-resource-type" },
    { code: "referral", system: "http://terminology.hl7.org/CodeSystem/basic-resource-type" },
    { code: "advevent", system: "http://terminology.hl7.org/CodeSystem/basic-resource-type" },
    { code: "aptmtreq", system: "http://terminology.hl7.org/CodeSystem/basic-resource-type" },
    { code: "transfer", system: "http://terminology.hl7.org/CodeSystem/basic-resource-type" },
    { code: "diet", system: "http://terminology.hl7.org/CodeSystem/basic-resource-type" },
    { code: "adminact", system: "http://terminology.hl7.org/CodeSystem/basic-resource-type" },
    { code: "exposure", system: "http://terminology.hl7.org/CodeSystem/basic-resource-type" },
    { code: "investigation", system: "http://terminology.hl7.org/CodeSystem/basic-resource-type" },
    { code: "account", system: "http://terminology.hl7.org/CodeSystem/basic-resource-type" },
    { code: "invoice", system: "http://terminology.hl7.org/CodeSystem/basic-resource-type" },
    { code: "adjudicat", system: "http://terminology.hl7.org/CodeSystem/basic-resource-type" },
    { code: "predetreq", system: "http://terminology.hl7.org/CodeSystem/basic-resource-type" },
    { code: "predetermine", system: "http://terminology.hl7.org/CodeSystem/basic-resource-type" },
    { code: "study", system: "http://terminology.hl7.org/CodeSystem/basic-resource-type" },
    { code: "protocol", system: "http://terminology.hl7.org/CodeSystem/basic-resource-type" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidBasicResourceTypeCode(code) {
    return BasicResourceTypeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getBasicResourceTypeConcept(code) {
    return BasicResourceTypeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const BasicResourceTypeCodes = BasicResourceTypeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomBasicResourceTypeCode() {
    return BasicResourceTypeCodes[Math.floor(Math.random() * BasicResourceTypeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomBasicResourceTypeConcept() {
    return BasicResourceTypeConcepts[Math.floor(Math.random() * BasicResourceTypeConcepts.length)];
}
