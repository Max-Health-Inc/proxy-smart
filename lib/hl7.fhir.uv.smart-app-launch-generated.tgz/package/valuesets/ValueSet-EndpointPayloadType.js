/**
 * ValueSet: endpoint-payload-type
 * URL: http://hl7.org/fhir/ValueSet/endpoint-payload-type
 * Size: 14 concepts
 */
export const EndpointPayloadTypeConcepts = [
    { code: "urn:hl7-org:sdwg:ccda-structuredBody:1.1", system: "http://terminology.hl7.org/CodeSystem/v3-HL7DocumentFormatCodes" },
    { code: "urn:hl7-org:sdwg:ccda-nonXMLBody:1.1", system: "http://terminology.hl7.org/CodeSystem/v3-HL7DocumentFormatCodes" },
    { code: "urn:hl7-org:sdwg:ccda-structuredBody:2.1", system: "http://terminology.hl7.org/CodeSystem/v3-HL7DocumentFormatCodes" },
    { code: "urn:hl7-org:sdwg:ccda-nonXMLBody:2.1", system: "http://terminology.hl7.org/CodeSystem/v3-HL7DocumentFormatCodes" },
    { code: "urn:hl7-org:sdwg:pacp-structuredBody:1.0", system: "http://terminology.hl7.org/CodeSystem/v3-HL7DocumentFormatCodes" },
    { code: "urn:hl7-org:sdwg:pacp-nonXMLBody:1.0", system: "http://terminology.hl7.org/CodeSystem/v3-HL7DocumentFormatCodes" },
    { code: "urn:hl7-org:sdwg:pacp-structuredBody:1.1", system: "http://terminology.hl7.org/CodeSystem/v3-HL7DocumentFormatCodes" },
    { code: "urn:hl7-org:sdwg:pacp-nonXMLBody:1.1", system: "http://terminology.hl7.org/CodeSystem/v3-HL7DocumentFormatCodes" },
    { code: "urn:hl7-org:sdwg:pacp-structuredBody:1.2", system: "http://terminology.hl7.org/CodeSystem/v3-HL7DocumentFormatCodes" },
    { code: "urn:hl7-org:sdwg:pacp-nonXMLBody:1.2", system: "http://terminology.hl7.org/CodeSystem/v3-HL7DocumentFormatCodes" },
    { code: "urn:hl7-org:sdwg:pacp-structuredBody:1.3", system: "http://terminology.hl7.org/CodeSystem/v3-HL7DocumentFormatCodes" },
    { code: "urn:hl7-org:sdwg:pacp-nonXMLBody:1.3", system: "http://terminology.hl7.org/CodeSystem/v3-HL7DocumentFormatCodes" },
    { code: "urn:hl7-org:sdwg:ccda-structuredBody:2.2", system: "http://terminology.hl7.org/CodeSystem/v3-HL7DocumentFormatCodes" },
    { code: "urn:hl7-org:sdwg:ccda-nonXMLBody:2.2", system: "http://terminology.hl7.org/CodeSystem/v3-HL7DocumentFormatCodes" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidEndpointPayloadTypeCode(code) {
    return EndpointPayloadTypeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getEndpointPayloadTypeConcept(code) {
    return EndpointPayloadTypeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const EndpointPayloadTypeCodes = EndpointPayloadTypeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomEndpointPayloadTypeCode() {
    return EndpointPayloadTypeCodes[Math.floor(Math.random() * EndpointPayloadTypeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomEndpointPayloadTypeConcept() {
    return EndpointPayloadTypeConcepts[Math.floor(Math.random() * EndpointPayloadTypeConcepts.length)];
}
