/**
 * ValueSet: endpoint-payload-type
 * URL: http://hl7.org/fhir/ValueSet/endpoint-payload-type
 * Size: 74 concepts
 */
export const EndpointPayloadTypeConcepts = [
    { code: "any", system: "http://terminology.hl7.org/CodeSystem/endpoint-payload-type" },
    { code: "none", system: "http://terminology.hl7.org/CodeSystem/endpoint-payload-type" },
    { code: "urn:ihe:pcc:handp:2008", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pcc:xphr:2007", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pcc:aps:2007", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pcc:xds-ms:2007", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pcc:xphr:2007", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pcc:edr:2007", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pcc:edes:2007", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pcc:apr:handp:2008", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pcc:apr:lab:2008", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pcc:apr:edu:2008", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pcc:irc:2008", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pcc:crc:2008", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pcc:cm:2008", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pcc:ic:2009", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pcc:tn:2007", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pcc:nn:2007", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pcc:ctn:2007", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pcc:edpn:2007", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pcc:hp:2008", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pcc:ldhp:2009", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pcc:lds:2009", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pcc:mds:2009", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pcc:nds:2010", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pcc:ppvs:2010", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pcc:trs:2011", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pcc:ets:2011", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pcc:its:2011", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:iti:bppc:2007", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:iti:bppc-sd:2007", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:iti:xdw:2011:workflowDoc", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:iti:dsg:detached:2014", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:iti:dsg:enveloping:2014", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:iti:xds-sd:pdf:2008", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:iti:xds-sd:text:2008", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:lab:xd-lab:2008", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:rad:TEXT", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:rad:PDF", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:rad:CDA:ImagingReportStructuredHeadings:2013", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:card:imaging:2011", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:card:CRC:2012", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:card:EPRC-IE:2014", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:dent:TEXT", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:dent:PDF", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:dent:CDA:ImagingReportStructuredHeadings:2013", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pat:apsr:all:2010", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pat:apsr:cancer:all:2010", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pat:apsr:cancer:breast:2010", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pat:apsr:cancer:colon:2010", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pat:apsr:cancer:prostate:2010", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pat:apsr:cancer:thyroid:2010", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pat:apsr:cancer:lung:2010", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pat:apsr:cancer:skin:2010", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pat:apsr:cancer:kidney:2010", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pat:apsr:cancer:cervix:2010", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pat:apsr:cancer:endometrium:2010", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pat:apsr:cancer:ovary:2010", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pat:apsr:cancer:esophagus: 2010", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pat:apsr:cancer:stomach: 2010", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pat:apsr:cancer:liver:2010", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pat:apsr:cancer:pancreas: 2010", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pat:apsr:cancer:testis:2010", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pat:apsr:cancer:urinary_bladder:2010", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pat:apsr:cancer:lip_oral_cavity:2010", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pat:apsr:cancer:pharynx:2010", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pat:apsr:cancer:salivary_gland:2010", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pat:apsr:cancer:larynx:2010", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pharm:pre:2010", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pharm:padv:2010", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pharm:dis:2010", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:ihe:pharm:pml:2013", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:hl7-org:sdwg:ccda-structuredBody:1.1", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
    { code: "urn:hl7-org:sdwg:ccda-nonXMLBody:1.1", system: "urn:oid:1.3.6.1.4.1.19376.1.2.3" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidEndpointPayloadTypeCode(code) {
    return EndpointPayloadTypeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getEndpointPayloadTypeConcept(code) {
    return EndpointPayloadTypeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const EndpointPayloadTypeCodes = EndpointPayloadTypeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomEndpointPayloadTypeCode() {
    return EndpointPayloadTypeCodes[Math.floor(Math.random() * EndpointPayloadTypeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomEndpointPayloadTypeConcept() {
    return EndpointPayloadTypeConcepts[Math.floor(Math.random() * EndpointPayloadTypeConcepts.length)];
}
