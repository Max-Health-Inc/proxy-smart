/**
 * ValueSet: endpoint-payload-type
 * URL: http://hl7.org/fhir/ValueSet/endpoint-payload-type
 * Size: 74 concepts
 */
export declare const EndpointPayloadTypeConcepts: readonly [{
    readonly code: "any";
    readonly system: "http://terminology.hl7.org/CodeSystem/endpoint-payload-type";
}, {
    readonly code: "none";
    readonly system: "http://terminology.hl7.org/CodeSystem/endpoint-payload-type";
}, {
    readonly code: "urn:ihe:pcc:handp:2008";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pcc:xphr:2007";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pcc:aps:2007";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pcc:xds-ms:2007";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pcc:xphr:2007";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pcc:edr:2007";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pcc:edes:2007";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pcc:apr:handp:2008";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pcc:apr:lab:2008";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pcc:apr:edu:2008";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pcc:irc:2008";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pcc:crc:2008";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pcc:cm:2008";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pcc:ic:2009";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pcc:tn:2007";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pcc:nn:2007";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pcc:ctn:2007";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pcc:edpn:2007";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pcc:hp:2008";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pcc:ldhp:2009";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pcc:lds:2009";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pcc:mds:2009";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pcc:nds:2010";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pcc:ppvs:2010";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pcc:trs:2011";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pcc:ets:2011";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pcc:its:2011";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:iti:bppc:2007";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:iti:bppc-sd:2007";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:iti:xdw:2011:workflowDoc";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:iti:dsg:detached:2014";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:iti:dsg:enveloping:2014";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:iti:xds-sd:pdf:2008";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:iti:xds-sd:text:2008";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:lab:xd-lab:2008";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:rad:TEXT";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:rad:PDF";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:rad:CDA:ImagingReportStructuredHeadings:2013";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:card:imaging:2011";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:card:CRC:2012";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:card:EPRC-IE:2014";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:dent:TEXT";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:dent:PDF";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:dent:CDA:ImagingReportStructuredHeadings:2013";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pat:apsr:all:2010";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pat:apsr:cancer:all:2010";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pat:apsr:cancer:breast:2010";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pat:apsr:cancer:colon:2010";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pat:apsr:cancer:prostate:2010";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pat:apsr:cancer:thyroid:2010";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pat:apsr:cancer:lung:2010";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pat:apsr:cancer:skin:2010";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pat:apsr:cancer:kidney:2010";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pat:apsr:cancer:cervix:2010";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pat:apsr:cancer:endometrium:2010";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pat:apsr:cancer:ovary:2010";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pat:apsr:cancer:esophagus: 2010";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pat:apsr:cancer:stomach: 2010";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pat:apsr:cancer:liver:2010";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pat:apsr:cancer:pancreas: 2010";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pat:apsr:cancer:testis:2010";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pat:apsr:cancer:urinary_bladder:2010";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pat:apsr:cancer:lip_oral_cavity:2010";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pat:apsr:cancer:pharynx:2010";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pat:apsr:cancer:salivary_gland:2010";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pat:apsr:cancer:larynx:2010";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pharm:pre:2010";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pharm:padv:2010";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pharm:dis:2010";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:ihe:pharm:pml:2013";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:hl7-org:sdwg:ccda-structuredBody:1.1";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}, {
    readonly code: "urn:hl7-org:sdwg:ccda-nonXMLBody:1.1";
    readonly system: "urn:oid:1.3.6.1.4.1.19376.1.2.3";
}];
/** String type (ValueSet too large for union type) */
export type EndpointPayloadTypeCode = string;
/** Type representing a concept from this ValueSet */
export type EndpointPayloadTypeConcept = typeof EndpointPayloadTypeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidEndpointPayloadTypeCode(code: string): code is EndpointPayloadTypeCode;
/**
 * Get concept details by code
 */
export declare function getEndpointPayloadTypeConcept(code: string): EndpointPayloadTypeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const EndpointPayloadTypeCodes: ("none" | "any" | "urn:ihe:pcc:handp:2008" | "urn:ihe:pcc:xphr:2007" | "urn:ihe:pcc:aps:2007" | "urn:ihe:pcc:xds-ms:2007" | "urn:ihe:pcc:edr:2007" | "urn:ihe:pcc:edes:2007" | "urn:ihe:pcc:apr:handp:2008" | "urn:ihe:pcc:apr:lab:2008" | "urn:ihe:pcc:apr:edu:2008" | "urn:ihe:pcc:irc:2008" | "urn:ihe:pcc:crc:2008" | "urn:ihe:pcc:cm:2008" | "urn:ihe:pcc:ic:2009" | "urn:ihe:pcc:tn:2007" | "urn:ihe:pcc:nn:2007" | "urn:ihe:pcc:ctn:2007" | "urn:ihe:pcc:edpn:2007" | "urn:ihe:pcc:hp:2008" | "urn:ihe:pcc:ldhp:2009" | "urn:ihe:pcc:lds:2009" | "urn:ihe:pcc:mds:2009" | "urn:ihe:pcc:nds:2010" | "urn:ihe:pcc:ppvs:2010" | "urn:ihe:pcc:trs:2011" | "urn:ihe:pcc:ets:2011" | "urn:ihe:pcc:its:2011" | "urn:ihe:iti:bppc:2007" | "urn:ihe:iti:bppc-sd:2007" | "urn:ihe:iti:xdw:2011:workflowDoc" | "urn:ihe:iti:dsg:detached:2014" | "urn:ihe:iti:dsg:enveloping:2014" | "urn:ihe:iti:xds-sd:pdf:2008" | "urn:ihe:iti:xds-sd:text:2008" | "urn:ihe:lab:xd-lab:2008" | "urn:ihe:rad:TEXT" | "urn:ihe:rad:PDF" | "urn:ihe:rad:CDA:ImagingReportStructuredHeadings:2013" | "urn:ihe:card:imaging:2011" | "urn:ihe:card:CRC:2012" | "urn:ihe:card:EPRC-IE:2014" | "urn:ihe:dent:TEXT" | "urn:ihe:dent:PDF" | "urn:ihe:dent:CDA:ImagingReportStructuredHeadings:2013" | "urn:ihe:pat:apsr:all:2010" | "urn:ihe:pat:apsr:cancer:all:2010" | "urn:ihe:pat:apsr:cancer:breast:2010" | "urn:ihe:pat:apsr:cancer:colon:2010" | "urn:ihe:pat:apsr:cancer:prostate:2010" | "urn:ihe:pat:apsr:cancer:thyroid:2010" | "urn:ihe:pat:apsr:cancer:lung:2010" | "urn:ihe:pat:apsr:cancer:skin:2010" | "urn:ihe:pat:apsr:cancer:kidney:2010" | "urn:ihe:pat:apsr:cancer:cervix:2010" | "urn:ihe:pat:apsr:cancer:endometrium:2010" | "urn:ihe:pat:apsr:cancer:ovary:2010" | "urn:ihe:pat:apsr:cancer:esophagus: 2010" | "urn:ihe:pat:apsr:cancer:stomach: 2010" | "urn:ihe:pat:apsr:cancer:liver:2010" | "urn:ihe:pat:apsr:cancer:pancreas: 2010" | "urn:ihe:pat:apsr:cancer:testis:2010" | "urn:ihe:pat:apsr:cancer:urinary_bladder:2010" | "urn:ihe:pat:apsr:cancer:lip_oral_cavity:2010" | "urn:ihe:pat:apsr:cancer:pharynx:2010" | "urn:ihe:pat:apsr:cancer:salivary_gland:2010" | "urn:ihe:pat:apsr:cancer:larynx:2010" | "urn:ihe:pharm:pre:2010" | "urn:ihe:pharm:padv:2010" | "urn:ihe:pharm:dis:2010" | "urn:ihe:pharm:pml:2013" | "urn:hl7-org:sdwg:ccda-structuredBody:1.1" | "urn:hl7-org:sdwg:ccda-nonXMLBody:1.1")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomEndpointPayloadTypeCode(): EndpointPayloadTypeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomEndpointPayloadTypeConcept(): EndpointPayloadTypeConcept;
