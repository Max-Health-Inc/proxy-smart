/**
 * ValueSet: endpoint-payload-type
 * URL: http://hl7.org/fhir/ValueSet/endpoint-payload-type
 * Size: 14 concepts
 */
export declare const EndpointPayloadTypeConcepts: readonly [{
    readonly code: "urn:hl7-org:sdwg:ccda-structuredBody:1.1";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-HL7DocumentFormatCodes";
}, {
    readonly code: "urn:hl7-org:sdwg:ccda-nonXMLBody:1.1";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-HL7DocumentFormatCodes";
}, {
    readonly code: "urn:hl7-org:sdwg:ccda-structuredBody:2.1";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-HL7DocumentFormatCodes";
}, {
    readonly code: "urn:hl7-org:sdwg:ccda-nonXMLBody:2.1";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-HL7DocumentFormatCodes";
}, {
    readonly code: "urn:hl7-org:sdwg:pacp-structuredBody:1.0";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-HL7DocumentFormatCodes";
}, {
    readonly code: "urn:hl7-org:sdwg:pacp-nonXMLBody:1.0";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-HL7DocumentFormatCodes";
}, {
    readonly code: "urn:hl7-org:sdwg:pacp-structuredBody:1.1";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-HL7DocumentFormatCodes";
}, {
    readonly code: "urn:hl7-org:sdwg:pacp-nonXMLBody:1.1";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-HL7DocumentFormatCodes";
}, {
    readonly code: "urn:hl7-org:sdwg:pacp-structuredBody:1.2";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-HL7DocumentFormatCodes";
}, {
    readonly code: "urn:hl7-org:sdwg:pacp-nonXMLBody:1.2";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-HL7DocumentFormatCodes";
}, {
    readonly code: "urn:hl7-org:sdwg:pacp-structuredBody:1.3";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-HL7DocumentFormatCodes";
}, {
    readonly code: "urn:hl7-org:sdwg:pacp-nonXMLBody:1.3";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-HL7DocumentFormatCodes";
}, {
    readonly code: "urn:hl7-org:sdwg:ccda-structuredBody:2.2";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-HL7DocumentFormatCodes";
}, {
    readonly code: "urn:hl7-org:sdwg:ccda-nonXMLBody:2.2";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-HL7DocumentFormatCodes";
}];
/** Union type of all valid codes in this ValueSet */
export type EndpointPayloadTypeCode = "urn:hl7-org:sdwg:ccda-structuredBody:1.1" | "urn:hl7-org:sdwg:ccda-nonXMLBody:1.1" | "urn:hl7-org:sdwg:ccda-structuredBody:2.1" | "urn:hl7-org:sdwg:ccda-nonXMLBody:2.1" | "urn:hl7-org:sdwg:pacp-structuredBody:1.0" | "urn:hl7-org:sdwg:pacp-nonXMLBody:1.0" | "urn:hl7-org:sdwg:pacp-structuredBody:1.1" | "urn:hl7-org:sdwg:pacp-nonXMLBody:1.1" | "urn:hl7-org:sdwg:pacp-structuredBody:1.2" | "urn:hl7-org:sdwg:pacp-nonXMLBody:1.2" | "urn:hl7-org:sdwg:pacp-structuredBody:1.3" | "urn:hl7-org:sdwg:pacp-nonXMLBody:1.3" | "urn:hl7-org:sdwg:ccda-structuredBody:2.2" | "urn:hl7-org:sdwg:ccda-nonXMLBody:2.2";
/** Type representing a concept from this ValueSet */
export type EndpointPayloadTypeConcept = typeof EndpointPayloadTypeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidEndpointPayloadTypeCode(code: string): code is EndpointPayloadTypeCode;
/**
 * Get concept details by code
 */
export declare function getEndpointPayloadTypeConcept(code: string): EndpointPayloadTypeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const EndpointPayloadTypeCodes: ("urn:hl7-org:sdwg:ccda-structuredBody:1.1" | "urn:hl7-org:sdwg:ccda-nonXMLBody:1.1" | "urn:hl7-org:sdwg:ccda-structuredBody:2.1" | "urn:hl7-org:sdwg:ccda-nonXMLBody:2.1" | "urn:hl7-org:sdwg:pacp-structuredBody:1.0" | "urn:hl7-org:sdwg:pacp-nonXMLBody:1.0" | "urn:hl7-org:sdwg:pacp-structuredBody:1.1" | "urn:hl7-org:sdwg:pacp-nonXMLBody:1.1" | "urn:hl7-org:sdwg:pacp-structuredBody:1.2" | "urn:hl7-org:sdwg:pacp-nonXMLBody:1.2" | "urn:hl7-org:sdwg:pacp-structuredBody:1.3" | "urn:hl7-org:sdwg:pacp-nonXMLBody:1.3" | "urn:hl7-org:sdwg:ccda-structuredBody:2.2" | "urn:hl7-org:sdwg:ccda-nonXMLBody:2.2")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomEndpointPayloadTypeCode(): EndpointPayloadTypeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomEndpointPayloadTypeConcept(): EndpointPayloadTypeConcept;
