/**
 * ValueSet: UserAccessCategoryValueSet
 * URL: http://hl7.org/fhir/smart-app-launch/ValueSet/user-access-category
 * Size: 7 concepts
 */
export const UserAccessCategoryValueSetConcepts = [
    { code: "prov", system: "http://terminology.hl7.org/CodeSystem/organization-type", display: "Healthcare Provider" },
    { code: "ins", system: "http://terminology.hl7.org/CodeSystem/organization-type", display: "Insurance Company" },
    { code: "laboratory", system: "http://terminology.hl7.org/CodeSystem/organization-type", display: "Laboratory" },
    { code: "imaging", system: "http://terminology.hl7.org/CodeSystem/organization-type", display: "Imaging Center" },
    { code: "pharmacy", system: "http://terminology.hl7.org/CodeSystem/organization-type", display: "Pharmacy" },
    { code: "health-information-network", system: "http://terminology.hl7.org/CodeSystem/organization-type", display: "Health Information Network" },
    { code: "health-data-aggregator", system: "http://terminology.hl7.org/CodeSystem/organization-type", display: "Health Data Aggregator" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidUserAccessCategoryValueSetCode(code) {
    return UserAccessCategoryValueSetConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getUserAccessCategoryValueSetConcept(code) {
    return UserAccessCategoryValueSetConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const UserAccessCategoryValueSetCodes = UserAccessCategoryValueSetConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomUserAccessCategoryValueSetCode() {
    return UserAccessCategoryValueSetCodes[Math.floor(Math.random() * UserAccessCategoryValueSetCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomUserAccessCategoryValueSetConcept() {
    return UserAccessCategoryValueSetConcepts[Math.floor(Math.random() * UserAccessCategoryValueSetConcepts.length)];
}
