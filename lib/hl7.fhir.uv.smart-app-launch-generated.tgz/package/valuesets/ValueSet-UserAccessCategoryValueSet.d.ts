/**
 * ValueSet: UserAccessCategoryValueSet
 * URL: http://hl7.org/fhir/smart-app-launch/ValueSet/user-access-category
 * Size: 7 concepts
 */
export declare const UserAccessCategoryValueSetConcepts: readonly [{
    readonly code: "prov";
    readonly system: "http://terminology.hl7.org/CodeSystem/organization-type";
    readonly display: "Healthcare Provider";
}, {
    readonly code: "ins";
    readonly system: "http://terminology.hl7.org/CodeSystem/organization-type";
    readonly display: "Insurance Company";
}, {
    readonly code: "laboratory";
    readonly system: "http://terminology.hl7.org/CodeSystem/organization-type";
    readonly display: "Laboratory";
}, {
    readonly code: "imaging";
    readonly system: "http://terminology.hl7.org/CodeSystem/organization-type";
    readonly display: "Imaging Center";
}, {
    readonly code: "pharmacy";
    readonly system: "http://terminology.hl7.org/CodeSystem/organization-type";
    readonly display: "Pharmacy";
}, {
    readonly code: "health-information-network";
    readonly system: "http://terminology.hl7.org/CodeSystem/organization-type";
    readonly display: "Health Information Network";
}, {
    readonly code: "health-data-aggregator";
    readonly system: "http://terminology.hl7.org/CodeSystem/organization-type";
    readonly display: "Health Data Aggregator";
}];
/** Union type of all valid codes in this ValueSet */
export type UserAccessCategoryValueSetCode = "prov" | "ins" | "laboratory" | "imaging" | "pharmacy" | "health-information-network" | "health-data-aggregator";
/** Type representing a concept from this ValueSet */
export type UserAccessCategoryValueSetConcept = typeof UserAccessCategoryValueSetConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidUserAccessCategoryValueSetCode(code: string): code is UserAccessCategoryValueSetCode;
/**
 * Get concept details by code
 */
export declare function getUserAccessCategoryValueSetConcept(code: string): UserAccessCategoryValueSetConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const UserAccessCategoryValueSetCodes: ("laboratory" | "prov" | "ins" | "imaging" | "pharmacy" | "health-information-network" | "health-data-aggregator")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomUserAccessCategoryValueSetCode(): UserAccessCategoryValueSetCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomUserAccessCategoryValueSetConcept(): UserAccessCategoryValueSetConcept;
