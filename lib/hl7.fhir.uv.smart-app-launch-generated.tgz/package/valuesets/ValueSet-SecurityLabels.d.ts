/**
 * ValueSet: security-labels
 * URL: http://hl7.org/fhir/ValueSet/security-labels
 * Size: 36 concepts
 */
export declare const SecurityLabelsConcepts: readonly [{
    readonly code: "_Confidentiality";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality";
}, {
    readonly code: "L";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality";
}, {
    readonly code: "M";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality";
}, {
    readonly code: "N";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality";
}, {
    readonly code: "R";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality";
}, {
    readonly code: "U";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality";
}, {
    readonly code: "V";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality";
}, {
    readonly code: "_ConfidentialityByAccessKind";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality";
}, {
    readonly code: "B";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality";
}, {
    readonly code: "D";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality";
}, {
    readonly code: "I";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality";
}, {
    readonly code: "_ConfidentialityByInfoType";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality";
}, {
    readonly code: "ETH";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality";
}, {
    readonly code: "HIV";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality";
}, {
    readonly code: "PSY";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality";
}, {
    readonly code: "SDV";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality";
}, {
    readonly code: "_ConfidentialityModifiers";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality";
}, {
    readonly code: "C";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality";
}, {
    readonly code: "S";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality";
}, {
    readonly code: "T";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-Confidentiality";
}, {
    readonly code: "COVERAGE";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActReason";
}, {
    readonly code: "ETREAT";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActReason";
}, {
    readonly code: "HMARKT";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActReason";
}, {
    readonly code: "HOPERAT";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActReason";
}, {
    readonly code: "HPAYMT";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActReason";
}, {
    readonly code: "HRESCH";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActReason";
}, {
    readonly code: "PATRQT";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActReason";
}, {
    readonly code: "PUBHLTH";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActReason";
}, {
    readonly code: "TREAT";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActReason";
}, {
    readonly code: "_ActUSPrivacyLaw";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActUSPrivacyLaw";
}, {
    readonly code: "42CFRPart2";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActUSPrivacyLaw";
}, {
    readonly code: "CommonRule";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActUSPrivacyLaw";
}, {
    readonly code: "HIPAANOPP";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActUSPrivacyLaw";
}, {
    readonly code: "HIPAAPsyNotes";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActUSPrivacyLaw";
}, {
    readonly code: "HIPAASelfPay";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActUSPrivacyLaw";
}, {
    readonly code: "Title38Section7332";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ActUSPrivacyLaw";
}];
/** String type (ValueSet too large for union type) */
export type SecurityLabelsCode = string;
/** Type representing a concept from this ValueSet */
export type SecurityLabelsConcept = typeof SecurityLabelsConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidSecurityLabelsCode(code: string): code is SecurityLabelsCode;
/**
 * Get concept details by code
 */
export declare function getSecurityLabelsConcept(code: string): SecurityLabelsConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const SecurityLabelsCodes: ("N" | "_Confidentiality" | "L" | "M" | "R" | "U" | "V" | "_ConfidentialityByAccessKind" | "B" | "D" | "I" | "_ConfidentialityByInfoType" | "ETH" | "HIV" | "PSY" | "SDV" | "_ConfidentialityModifiers" | "C" | "S" | "T" | "COVERAGE" | "ETREAT" | "HMARKT" | "HOPERAT" | "HPAYMT" | "HRESCH" | "PATRQT" | "PUBHLTH" | "TREAT" | "_ActUSPrivacyLaw" | "42CFRPart2" | "CommonRule" | "HIPAANOPP" | "HIPAAPsyNotes" | "HIPAASelfPay" | "Title38Section7332")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomSecurityLabelsCode(): SecurityLabelsCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomSecurityLabelsConcept(): SecurityLabelsConcept;
