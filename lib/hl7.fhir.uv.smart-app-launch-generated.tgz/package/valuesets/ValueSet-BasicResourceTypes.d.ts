/**
 * ValueSet: BasicResourceTypes
 * URL: http://hl7.org/fhir/ValueSet/basic-resource-type
 * Size: 16 concepts
 */
export declare const BasicResourceTypesConcepts: readonly [{
    readonly code: "consent";
    readonly system: "http://terminology.hl7.org/CodeSystem/basic-resource-type";
    readonly display: "Consent";
}, {
    readonly code: "referral";
    readonly system: "http://terminology.hl7.org/CodeSystem/basic-resource-type";
    readonly display: "Referral";
}, {
    readonly code: "advevent";
    readonly system: "http://terminology.hl7.org/CodeSystem/basic-resource-type";
    readonly display: "Adverse Event";
}, {
    readonly code: "aptmtreq";
    readonly system: "http://terminology.hl7.org/CodeSystem/basic-resource-type";
    readonly display: "Appointment Request";
}, {
    readonly code: "transfer";
    readonly system: "http://terminology.hl7.org/CodeSystem/basic-resource-type";
    readonly display: "Transfer";
}, {
    readonly code: "diet";
    readonly system: "http://terminology.hl7.org/CodeSystem/basic-resource-type";
    readonly display: "Diet";
}, {
    readonly code: "adminact";
    readonly system: "http://terminology.hl7.org/CodeSystem/basic-resource-type";
    readonly display: "Administrative Activity";
}, {
    readonly code: "exposure";
    readonly system: "http://terminology.hl7.org/CodeSystem/basic-resource-type";
    readonly display: "Exposure";
}, {
    readonly code: "investigation";
    readonly system: "http://terminology.hl7.org/CodeSystem/basic-resource-type";
    readonly display: "Investigation";
}, {
    readonly code: "account";
    readonly system: "http://terminology.hl7.org/CodeSystem/basic-resource-type";
    readonly display: "Account";
}, {
    readonly code: "invoice";
    readonly system: "http://terminology.hl7.org/CodeSystem/basic-resource-type";
    readonly display: "Invoice";
}, {
    readonly code: "adjudicat";
    readonly system: "http://terminology.hl7.org/CodeSystem/basic-resource-type";
    readonly display: "Invoice Adjudication";
}, {
    readonly code: "predetreq";
    readonly system: "http://terminology.hl7.org/CodeSystem/basic-resource-type";
    readonly display: "Pre-determination Request";
}, {
    readonly code: "predetermine";
    readonly system: "http://terminology.hl7.org/CodeSystem/basic-resource-type";
    readonly display: "Predetermination";
}, {
    readonly code: "study";
    readonly system: "http://terminology.hl7.org/CodeSystem/basic-resource-type";
    readonly display: "Study";
}, {
    readonly code: "protocol";
    readonly system: "http://terminology.hl7.org/CodeSystem/basic-resource-type";
    readonly display: "Protocol";
}];
/** Union type of all valid codes in this ValueSet */
export type BasicResourceTypesCode = "consent" | "referral" | "advevent" | "aptmtreq" | "transfer" | "diet" | "adminact" | "exposure" | "investigation" | "account" | "invoice" | "adjudicat" | "predetreq" | "predetermine" | "study" | "protocol";
/** Type representing a concept from this ValueSet */
export type BasicResourceTypesConcept = typeof BasicResourceTypesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidBasicResourceTypesCode(code: string): code is BasicResourceTypesCode;
/**
 * Get concept details by code
 */
export declare function getBasicResourceTypesConcept(code: string): BasicResourceTypesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const BasicResourceTypesCodes: ("study" | "investigation" | "consent" | "referral" | "advevent" | "aptmtreq" | "transfer" | "diet" | "adminact" | "exposure" | "account" | "invoice" | "adjudicat" | "predetreq" | "predetermine" | "protocol")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomBasicResourceTypesCode(): BasicResourceTypesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomBasicResourceTypesConcept(): BasicResourceTypesConcept;
