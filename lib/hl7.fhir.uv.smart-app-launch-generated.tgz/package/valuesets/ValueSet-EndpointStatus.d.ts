/**
 * ValueSet: EndpointStatus
 * URL: http://hl7.org/fhir/ValueSet/endpoint-status
 * Size: 6 concepts
 */
export declare const EndpointStatusConcepts: readonly [{
    readonly code: "active";
    readonly system: "http://hl7.org/fhir/endpoint-status";
    readonly display: "Active";
}, {
    readonly code: "suspended";
    readonly system: "http://hl7.org/fhir/endpoint-status";
    readonly display: "Suspended";
}, {
    readonly code: "error";
    readonly system: "http://hl7.org/fhir/endpoint-status";
    readonly display: "Error";
}, {
    readonly code: "off";
    readonly system: "http://hl7.org/fhir/endpoint-status";
    readonly display: "Off";
}, {
    readonly code: "entered-in-error";
    readonly system: "http://hl7.org/fhir/endpoint-status";
    readonly display: "Entered in error";
}, {
    readonly code: "test";
    readonly system: "http://hl7.org/fhir/endpoint-status";
    readonly display: "Test";
}];
/** Union type of all valid codes in this ValueSet */
export type EndpointStatusCode = "active" | "suspended" | "error" | "off" | "entered-in-error" | "test";
/** Type representing a concept from this ValueSet */
export type EndpointStatusConcept = typeof EndpointStatusConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidEndpointStatusCode(code: string): code is EndpointStatusCode;
/**
 * Get concept details by code
 */
export declare function getEndpointStatusConcept(code: string): EndpointStatusConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const EndpointStatusCodes: ("active" | "entered-in-error" | "suspended" | "error" | "off" | "test")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomEndpointStatusCode(): EndpointStatusCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomEndpointStatusConcept(): EndpointStatusConcept;
