/**
 * ValueSet Registry
 * Central registry of all loaded ValueSets with explicit codes
 */
import * as AllSecurityLabels from './ValueSet-AllSecurityLabels.js';
import * as BasicResourceTypes from './ValueSet-BasicResourceTypes.js';
import * as BundleType from './ValueSet-BundleType.js';
import * as CommonLanguages from './ValueSet-CommonLanguages.js';
import * as CommonTags from './ValueSet-CommonTags.js';
import * as ContactEntityType from './ValueSet-ContactEntityType.js';
import * as ContactPointSystem from './ValueSet-ContactPointSystem.js';
import * as ContactPointUse from './ValueSet-ContactPointUse.js';
import * as EndpointConnectionType from './ValueSet-EndpointConnectionType.js';
import * as EndpointPayloadType from './ValueSet-EndpointPayloadType.js';
import * as EndpointStatus from './ValueSet-EndpointStatus.js';
import * as HttpVerb from './ValueSet-HttpVerb.js';
import * as OrganizationType from './ValueSet-OrganizationType.js';
import * as ProcedurePerformerRoleCodes from './ValueSet-ProcedurePerformerRoleCodes.js';
import * as RequestPriority from './ValueSet-RequestPriority.js';
import * as ResourceType from './ValueSet-ResourceType.js';
import * as SearchEntryMode from './ValueSet-SearchEntryMode.js';
import * as SmartLaunchInformation from './ValueSet-SmartLaunchInformation.js';
import * as SmartLaunchTypes from './ValueSet-SmartLaunchTypes.js';
import * as TaskIntent from './ValueSet-TaskIntent.js';
import * as TaskStatus from './ValueSet-TaskStatus.js';
import * as UserAccessCategoryValueSet from './ValueSet-UserAccessCategoryValueSet.js';
export const ValueSetRegistry = {
    AllSecurityLabels,
    BasicResourceTypes,
    BundleType,
    CommonLanguages,
    CommonTags,
    ContactEntityType,
    ContactPointSystem,
    ContactPointUse,
    EndpointConnectionType,
    EndpointPayloadType,
    EndpointStatus,
    HttpVerb,
    OrganizationType,
    ProcedurePerformerRoleCodes,
    RequestPriority,
    ResourceType,
    SearchEntryMode,
    SmartLaunchInformation,
    SmartLaunchTypes,
    TaskIntent,
    TaskStatus,
    UserAccessCategoryValueSet,
};
export function getValueSet(name) {
    return ValueSetRegistry[name];
}
/** Map from ValueSet URL to registry name */
export const ValueSetUrlMap = {
    'http://hl7.org/fhir/ValueSet/security-labels': 'AllSecurityLabels',
    'http://hl7.org/fhir/ValueSet/basic-resource-type': 'BasicResourceTypes',
    'http://hl7.org/fhir/ValueSet/bundle-type': 'BundleType',
    'http://hl7.org/fhir/ValueSet/languages': 'CommonLanguages',
    'http://hl7.org/fhir/ValueSet/common-tags': 'CommonTags',
    'http://hl7.org/fhir/ValueSet/contactentity-type': 'ContactEntityType',
    'http://hl7.org/fhir/ValueSet/contact-point-system': 'ContactPointSystem',
    'http://hl7.org/fhir/ValueSet/contact-point-use': 'ContactPointUse',
    'http://hl7.org/fhir/ValueSet/endpoint-connection-type': 'EndpointConnectionType',
    'http://hl7.org/fhir/ValueSet/endpoint-payload-type': 'EndpointPayloadType',
    'http://hl7.org/fhir/ValueSet/endpoint-status': 'EndpointStatus',
    'http://hl7.org/fhir/ValueSet/http-verb': 'HttpVerb',
    'http://hl7.org/fhir/ValueSet/organization-type': 'OrganizationType',
    'http://hl7.org/fhir/ValueSet/performer-role': 'ProcedurePerformerRoleCodes',
    'http://hl7.org/fhir/ValueSet/request-priority': 'RequestPriority',
    'http://hl7.org/fhir/ValueSet/resource-types': 'ResourceType',
    'http://hl7.org/fhir/ValueSet/search-entry-mode': 'SearchEntryMode',
    'http://hl7.org/fhir/smart-app-launch/ValueSet/smart-launch-info': 'SmartLaunchInformation',
    'http://hl7.org/fhir/smart-app-launch/ValueSet/smart-launch-types': 'SmartLaunchTypes',
    'http://hl7.org/fhir/ValueSet/task-intent': 'TaskIntent',
    'http://hl7.org/fhir/ValueSet/task-status': 'TaskStatus',
    'http://hl7.org/fhir/smart-app-launch/ValueSet/user-access-category': 'UserAccessCategoryValueSet',
};
function stripVersionFromUrl(url) {
    const pipeIndex = url.indexOf('|');
    return pipeIndex >= 0 ? url.substring(0, pipeIndex) : url;
}
/**
 * Get a random code from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A random code string, or undefined if ValueSet not found
 */
export function getRandomCodeByUrl(url) {
    const cleanUrl = stripVersionFromUrl(url);
    const name = ValueSetUrlMap[cleanUrl];
    if (!name)
        return undefined;
    const vs = ValueSetRegistry[name];
    // Each ValueSet exports random<Name>Code() function
    const randomFn = vs['random' + name + 'Code'];
    return randomFn?.();
}
/**
 * Get a random concept (code, system, display) from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A concept object with code, system, and optional display, or undefined if ValueSet not found
 */
export function getRandomConceptByUrl(url) {
    const cleanUrl = stripVersionFromUrl(url);
    const name = ValueSetUrlMap[cleanUrl];
    if (!name)
        return undefined;
    const vs = ValueSetRegistry[name];
    // Each ValueSet exports random<Name>Concept() function
    const randomFn = vs['random' + name + 'Concept'];
    return randomFn?.();
}
