/**
 * ValueSet Registry
 * Central registry of all loaded ValueSets with explicit codes
 */
import * as BundleType from './ValueSet-BundleType.js';
import * as ContactPointSystem from './ValueSet-ContactPointSystem.js';
import * as ContactPointUse from './ValueSet-ContactPointUse.js';
import * as HttpVerb from './ValueSet-HttpVerb.js';
import * as RequestPriority from './ValueSet-RequestPriority.js';
import * as SmartLaunchInformation from './ValueSet-SmartLaunchInformation.js';
import * as SmartLaunchTypes from './ValueSet-SmartLaunchTypes.js';
import * as TaskStatus from './ValueSet-TaskStatus.js';
import * as UserAccessCategoryValueSet from './ValueSet-UserAccessCategoryValueSet.js';
export const ValueSetRegistry = {
    BundleType,
    ContactPointSystem,
    ContactPointUse,
    HttpVerb,
    RequestPriority,
    SmartLaunchInformation,
    SmartLaunchTypes,
    TaskStatus,
    UserAccessCategoryValueSet,
};
export function getValueSet(name) {
    return ValueSetRegistry[name];
}
/** Map from ValueSet URL to registry name */
export const ValueSetUrlMap = {
    'http://hl7.org/fhir/ValueSet/bundle-type': 'BundleType',
    'http://hl7.org/fhir/ValueSet/contact-point-system': 'ContactPointSystem',
    'http://hl7.org/fhir/ValueSet/contact-point-use': 'ContactPointUse',
    'http://hl7.org/fhir/ValueSet/http-verb': 'HttpVerb',
    'http://hl7.org/fhir/ValueSet/request-priority': 'RequestPriority',
    'http://hl7.org/fhir/smart-app-launch/ValueSet/smart-launch-info': 'SmartLaunchInformation',
    'http://hl7.org/fhir/smart-app-launch/ValueSet/smart-launch-types': 'SmartLaunchTypes',
    'http://hl7.org/fhir/ValueSet/task-status': 'TaskStatus',
    'http://hl7.org/fhir/smart-app-launch/ValueSet/user-access-category': 'UserAccessCategoryValueSet',
};
function stripVersionFromUrl(url) {
    const pipeIndex = url.indexOf('|');
    return pipeIndex >= 0 ? url.substring(0, pipeIndex) : url;
}
/**
 * Get a random code from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A random code string, or undefined if ValueSet not found
 */
export function getRandomCodeByUrl(url) {
    const cleanUrl = stripVersionFromUrl(url);
    const name = ValueSetUrlMap[cleanUrl];
    if (!name)
        return undefined;
    const vs = ValueSetRegistry[name];
    // Each ValueSet exports random<Name>Code() function
    const randomFn = vs['random' + name + 'Code'];
    return randomFn?.();
}
/**
 * Get a random concept (code, system, display) from a ValueSet by URL
 * @param url - The canonical URL of the ValueSet (may include version like "|4.0.1")
 * @returns A concept object with code, system, and optional display, or undefined if ValueSet not found
 */
export function getRandomConceptByUrl(url) {
    const cleanUrl = stripVersionFromUrl(url);
    const name = ValueSetUrlMap[cleanUrl];
    if (!name)
        return undefined;
    const vs = ValueSetRegistry[name];
    // Each ValueSet exports random<Name>Concept() function
    const randomFn = vs['random' + name + 'Concept'];
    return randomFn?.();
}
