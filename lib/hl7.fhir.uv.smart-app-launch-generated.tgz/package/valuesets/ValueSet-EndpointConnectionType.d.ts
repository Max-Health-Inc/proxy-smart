/**
 * ValueSet: EndpointConnectionType
 * URL: http://hl7.org/fhir/ValueSet/endpoint-connection-type
 * Size: 14 concepts
 */
export declare const EndpointConnectionTypeConcepts: readonly [{
    readonly code: "ihe-xcpd";
    readonly system: "http://terminology.hl7.org/CodeSystem/endpoint-connection-type";
    readonly display: "IHE XCPD";
}, {
    readonly code: "ihe-xca";
    readonly system: "http://terminology.hl7.org/CodeSystem/endpoint-connection-type";
    readonly display: "IHE XCA";
}, {
    readonly code: "ihe-xdr";
    readonly system: "http://terminology.hl7.org/CodeSystem/endpoint-connection-type";
    readonly display: "IHE XDR";
}, {
    readonly code: "ihe-xds";
    readonly system: "http://terminology.hl7.org/CodeSystem/endpoint-connection-type";
    readonly display: "IHE XDS";
}, {
    readonly code: "ihe-iid";
    readonly system: "http://terminology.hl7.org/CodeSystem/endpoint-connection-type";
    readonly display: "IHE IID";
}, {
    readonly code: "dicom-wado-rs";
    readonly system: "http://terminology.hl7.org/CodeSystem/endpoint-connection-type";
    readonly display: "DICOM WADO-RS";
}, {
    readonly code: "dicom-qido-rs";
    readonly system: "http://terminology.hl7.org/CodeSystem/endpoint-connection-type";
    readonly display: "DICOM QIDO-RS";
}, {
    readonly code: "dicom-stow-rs";
    readonly system: "http://terminology.hl7.org/CodeSystem/endpoint-connection-type";
    readonly display: "DICOM STOW-RS";
}, {
    readonly code: "dicom-wado-uri";
    readonly system: "http://terminology.hl7.org/CodeSystem/endpoint-connection-type";
    readonly display: "DICOM WADO-URI";
}, {
    readonly code: "hl7-fhir-rest";
    readonly system: "http://terminology.hl7.org/CodeSystem/endpoint-connection-type";
    readonly display: "HL7 FHIR";
}, {
    readonly code: "hl7-fhir-msg";
    readonly system: "http://terminology.hl7.org/CodeSystem/endpoint-connection-type";
    readonly display: "HL7 FHIR Messaging";
}, {
    readonly code: "hl7v2-mllp";
    readonly system: "http://terminology.hl7.org/CodeSystem/endpoint-connection-type";
    readonly display: "HL7 v2 MLLP";
}, {
    readonly code: "secure-email";
    readonly system: "http://terminology.hl7.org/CodeSystem/endpoint-connection-type";
    readonly display: "Secure email";
}, {
    readonly code: "direct-project";
    readonly system: "http://terminology.hl7.org/CodeSystem/endpoint-connection-type";
    readonly display: "Direct Project";
}];
/** Union type of all valid codes in this ValueSet */
export type EndpointConnectionTypeCode = "ihe-xcpd" | "ihe-xca" | "ihe-xdr" | "ihe-xds" | "ihe-iid" | "dicom-wado-rs" | "dicom-qido-rs" | "dicom-stow-rs" | "dicom-wado-uri" | "hl7-fhir-rest" | "hl7-fhir-msg" | "hl7v2-mllp" | "secure-email" | "direct-project";
/** Type representing a concept from this ValueSet */
export type EndpointConnectionTypeConcept = typeof EndpointConnectionTypeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidEndpointConnectionTypeCode(code: string): code is EndpointConnectionTypeCode;
/**
 * Get concept details by code
 */
export declare function getEndpointConnectionTypeConcept(code: string): EndpointConnectionTypeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const EndpointConnectionTypeCodes: ("hl7-fhir-rest" | "ihe-xcpd" | "ihe-xca" | "ihe-xdr" | "ihe-xds" | "ihe-iid" | "dicom-wado-rs" | "dicom-qido-rs" | "dicom-stow-rs" | "dicom-wado-uri" | "hl7-fhir-msg" | "hl7v2-mllp" | "secure-email" | "direct-project")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomEndpointConnectionTypeCode(): EndpointConnectionTypeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomEndpointConnectionTypeConcept(): EndpointConnectionTypeConcept;
