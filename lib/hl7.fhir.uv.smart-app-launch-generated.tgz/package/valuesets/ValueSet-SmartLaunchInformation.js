/**
 * ValueSet: SmartLaunchInformation
 * URL: http://hl7.org/fhir/smart-app-launch/ValueSet/smart-launch-info
 * Size: 2 concepts
 */
export const SmartLaunchInformationConcepts = [
    { code: "smartonfhir-application", system: "http://hl7.org/fhir/smart-app-launch/CodeSystem/smart-codes", display: "SMART on FHIR application URL." },
    { code: "smartonfhir-appcontext", system: "http://hl7.org/fhir/smart-app-launch/CodeSystem/smart-codes", display: "Application context related to this launch." },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidSmartLaunchInformationCode(code) {
    return SmartLaunchInformationConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getSmartLaunchInformationConcept(code) {
    return SmartLaunchInformationConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const SmartLaunchInformationCodes = SmartLaunchInformationConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomSmartLaunchInformationCode() {
    return SmartLaunchInformationCodes[Math.floor(Math.random() * SmartLaunchInformationCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomSmartLaunchInformationConcept() {
    return SmartLaunchInformationConcepts[Math.floor(Math.random() * SmartLaunchInformationConcepts.length)];
}
