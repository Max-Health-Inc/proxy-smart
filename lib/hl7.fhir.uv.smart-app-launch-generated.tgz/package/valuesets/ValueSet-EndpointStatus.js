/**
 * ValueSet: EndpointStatus
 * URL: http://hl7.org/fhir/ValueSet/endpoint-status
 * Size: 6 concepts
 */
export const EndpointStatusConcepts = [
    { code: "active", system: "http://hl7.org/fhir/endpoint-status", display: "Active" },
    { code: "suspended", system: "http://hl7.org/fhir/endpoint-status", display: "Suspended" },
    { code: "error", system: "http://hl7.org/fhir/endpoint-status", display: "Error" },
    { code: "off", system: "http://hl7.org/fhir/endpoint-status", display: "Off" },
    { code: "entered-in-error", system: "http://hl7.org/fhir/endpoint-status", display: "Entered in error" },
    { code: "test", system: "http://hl7.org/fhir/endpoint-status", display: "Test" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidEndpointStatusCode(code) {
    return EndpointStatusConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getEndpointStatusConcept(code) {
    return EndpointStatusConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const EndpointStatusCodes = EndpointStatusConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomEndpointStatusCode() {
    return EndpointStatusCodes[Math.floor(Math.random() * EndpointStatusCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomEndpointStatusConcept() {
    return EndpointStatusConcepts[Math.floor(Math.random() * EndpointStatusConcepts.length)];
}
