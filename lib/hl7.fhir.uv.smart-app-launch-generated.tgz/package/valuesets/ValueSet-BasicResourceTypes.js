/**
 * ValueSet: BasicResourceTypes
 * URL: http://hl7.org/fhir/ValueSet/basic-resource-type
 * Size: 16 concepts
 */
export const BasicResourceTypesConcepts = [
    { code: "consent", system: "http://terminology.hl7.org/CodeSystem/basic-resource-type", display: "Consent" },
    { code: "referral", system: "http://terminology.hl7.org/CodeSystem/basic-resource-type", display: "Referral" },
    { code: "advevent", system: "http://terminology.hl7.org/CodeSystem/basic-resource-type", display: "Adverse Event" },
    { code: "aptmtreq", system: "http://terminology.hl7.org/CodeSystem/basic-resource-type", display: "Appointment Request" },
    { code: "transfer", system: "http://terminology.hl7.org/CodeSystem/basic-resource-type", display: "Transfer" },
    { code: "diet", system: "http://terminology.hl7.org/CodeSystem/basic-resource-type", display: "Diet" },
    { code: "adminact", system: "http://terminology.hl7.org/CodeSystem/basic-resource-type", display: "Administrative Activity" },
    { code: "exposure", system: "http://terminology.hl7.org/CodeSystem/basic-resource-type", display: "Exposure" },
    { code: "investigation", system: "http://terminology.hl7.org/CodeSystem/basic-resource-type", display: "Investigation" },
    { code: "account", system: "http://terminology.hl7.org/CodeSystem/basic-resource-type", display: "Account" },
    { code: "invoice", system: "http://terminology.hl7.org/CodeSystem/basic-resource-type", display: "Invoice" },
    { code: "adjudicat", system: "http://terminology.hl7.org/CodeSystem/basic-resource-type", display: "Invoice Adjudication" },
    { code: "predetreq", system: "http://terminology.hl7.org/CodeSystem/basic-resource-type", display: "Pre-determination Request" },
    { code: "predetermine", system: "http://terminology.hl7.org/CodeSystem/basic-resource-type", display: "Predetermination" },
    { code: "study", system: "http://terminology.hl7.org/CodeSystem/basic-resource-type", display: "Study" },
    { code: "protocol", system: "http://terminology.hl7.org/CodeSystem/basic-resource-type", display: "Protocol" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidBasicResourceTypesCode(code) {
    return BasicResourceTypesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getBasicResourceTypesConcept(code) {
    return BasicResourceTypesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const BasicResourceTypesCodes = BasicResourceTypesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomBasicResourceTypesCode() {
    return BasicResourceTypesCodes[Math.floor(Math.random() * BasicResourceTypesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomBasicResourceTypesConcept() {
    return BasicResourceTypesConcepts[Math.floor(Math.random() * BasicResourceTypesConcepts.length)];
}
