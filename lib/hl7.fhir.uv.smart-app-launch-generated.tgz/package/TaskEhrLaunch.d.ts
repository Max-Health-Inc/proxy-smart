import { Coding, Task, TaskInput } from "fhir/r4";
export interface TaskEhrLaunchCodeCoding extends Omit<Coding, 'system' | 'code'> {
    system: "http://hl7.org/fhir/smart-app-launch/CodeSystem/smart-codes";
    code: "launch-app-ehr";
}
export interface TaskEhrLaunch extends Omit<Task, 'code' | 'input'> {
    code: {
        coding: TaskEhrLaunchCodeCoding[];
    };
    input: TaskInput[];
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateTaskEhrLaunch(resource: TaskEhrLaunch, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
