import { validateTaskEhrLaunch } from "./TaskEhrLaunch.js";
// Only import helpers actually referenced below (dynamic based on required fields)
import { randomId, setRandomSeed, enrichResource } from "./random/index.js";
import { createRequire } from 'module';
const __require = createRequire(import.meta.url);
function ensureProfile(res, profile) {
    if (!res.meta) {
        res.meta = { profile: [profile] };
        return;
    }
    if (!res.meta.profile) {
        res.meta.profile = [profile];
        return;
    }
    if (!res.meta.profile.includes(profile)) {
        res.meta.profile = [...res.meta.profile, profile];
    }
}
// Internal helper (emitted per class file) to clone without resorting to 'any'.
function safeClone(value) {
    // Use native structuredClone if present; otherwise fallback to JSON round-trip.
    // We intentionally avoid casting through any to satisfy no-explicit-any lint rule.
    const g = globalThis;
    // Narrow globalThis to an object potentially containing structuredClone.
    if (typeof g.structuredClone === 'function') {
        return g.structuredClone(value);
    }
    return JSON.parse(JSON.stringify(value)); // best-effort deep clone
}
export class TaskEhrLaunchClass {
    constructor(resource) {
        this.resource = resource;
        ensureProfile(this.resource, 'http://hl7.org/fhir/smart-app-launch/StructureDefinition/task-ehr-launch');
    }
    /** Validate current resource instance. */
    async validate(options) {
        return validateTaskEhrLaunch(this.resource, options);
    }
    getResource() {
        return this.resource;
    }
    setResource(resource) {
        this.resource = resource;
        ensureProfile(this.resource, 'http://hl7.org/fhir/smart-app-launch/StructureDefinition/task-ehr-launch');
    }
    /**
     * Returns a plain JSON clone of the underlying resource ONLY if the last validation succeeded with zero errors.
     * Call validate() first; otherwise this method throws to prevent accidental use of invalid / unchecked data.
     */
    async toJSON() {
        return safeClone(this.resource);
    }
    /**
     * Create an empty instance for parity testing: for true FHIR resources, includes only resourceType; for datatypes, returns an empty object.
     * Note: meta.profile (when applicable) will be ensured by the constructor when wrapping this resource.
     */
    static empty(overrides = {}) {
        // For Resource profiles, include only resourceType. For Extension profiles, include url so the instance is minimally meaningful.
        const base = {
            resourceType: 'Task',
        };
        return { ...base, ...overrides };
    }
    /**
     * Create a minimal randomized instance of TaskEhrLaunch.
     * Populates id, resourceType (if applicable) and primitive required (min>0) top-level fields with placeholders.
     */
    static random(overrides = {}, opts) {
        if (opts?.seed !== undefined) {
            // Direct call (no dynamic require) to ensure deterministic seeding works under ESM.
            setRandomSeed(opts.seed);
        }
        // Start with a Partial to avoid unsafe casting errors; we'll assert at the end.
        const base = { resourceType: 'Task', id: randomId(), status: "ready", intent: "instance-order", code: { coding: [{ system: "http://hl7.org/fhir/smart-app-launch/CodeSystem/smart-codes", code: "launch-app-ehr" }] }, input: [{ type: { "coding": [{ "system": "http://hl7.org/fhir/smart-app-launch/CodeSystem/smart-codes", "code": "smartonfhir-application" }] }, valueUrl: "https://babelfhir.dev" }], };
        // Always include meta.profile with this profile's canonical URL if available & only for resource profiles
        ensureProfile(base, 'http://hl7.org/fhir/smart-app-launch/StructureDefinition/task-ehr-launch');
        // Enrich the base resource with common fields using centralized enrichment logic
        enrichResource(base, 'Task', 'http://hl7.org/fhir/smart-app-launch/StructureDefinition/task-ehr-launch', TaskEhrLaunchClass._fieldPatterns, TaskEhrLaunchClass._forbiddenFields, TaskEhrLaunchClass.valueSetBindings, TaskEhrLaunchClass._codeResolver, TaskEhrLaunchClass._fieldOrder);
        // Cast through unknown to acknowledge dynamic enrichment
        return { ...base, ...overrides };
    }
    /** Convenience: returns a class instance wrapping a randomized resource. */
    static randomClass(overrides = {}, opts) {
        return new TaskEhrLaunchClass(this.random(overrides, opts));
    }
}
/** Pattern constraints for profile fields (used by random() generator) */
TaskEhrLaunchClass._fieldPatterns = {
    "code": {
        "coding": [
            {
                "system": "http://hl7.org/fhir/smart-app-launch/CodeSystem/smart-codes",
                "code": "launch-app-ehr"
            }
        ]
    },
    "launchurl.type": {
        "coding": [
            {
                "system": "http://hl7.org/fhir/smart-app-launch/CodeSystem/smart-codes",
                "code": "smartonfhir-application"
            }
        ]
    },
    "launchcontext.type": {
        "coding": [
            {
                "system": "http://hl7.org/fhir/smart-app-launch/CodeSystem/smart-codes",
                "code": "smartonfhir-appcontext"
            }
        ]
    },
    "_refReq_input": {
        "type": true,
        "valueBase64Binary": true,
        "valueUrl": true,
        "valueString": true
    },
    "_refReq_output": {
        "type": true,
        "valueBase64Binary": true
    }
};
/** Fields that are forbidden (max=0) in this profile - must not be generated */
TaskEhrLaunchClass._forbiddenFields = [];
/** FHIR element ordering for this profile's base resource (used by enrichResource for correct JSON field order) */
TaskEhrLaunchClass._fieldOrder = ["id", "meta", "implicitRules", "language", "text", "contained", "extension", "modifierExtension", "identifier", "instantiatesCanonical", "instantiatesUri", "basedOn", "groupIdentifier", "partOf", "status", "statusReason", "businessStatus", "intent", "priority", "code", "description", "focus", "for", "encounter", "executionPeriod", "authoredOn", "lastModified", "requester", "performerType", "owner", "location", "reasonCode", "reasonReference", "insurance", "note", "relevantHistory", "restriction", "input", "output"];
/** ValueSet bindings for coded fields - maps field name to ValueSet URL */
TaskEhrLaunchClass.valueSetBindings = {
    "language": "http://hl7.org/fhir/ValueSet/languages",
    "status": "http://hl7.org/fhir/ValueSet/task-status|4.0.1",
    "intent": "http://hl7.org/fhir/ValueSet/task-intent|4.0.1",
    "priority": "http://hl7.org/fhir/ValueSet/request-priority|4.0.1",
    "code": "http://hl7.org/fhir/smart-app-launch/ValueSet/smart-launch-types",
    "performerType": "http://hl7.org/fhir/ValueSet/performer-role"
};
/** Code resolver for ValueSet bindings - returns a random valid code from a ValueSet by URL */
TaskEhrLaunchClass._codeResolver = (() => {
    // Try to load the ValueSetRegistry - it may not exist if no ValueSets were generated
    try {
        const registry = __require('./valuesets/index.js');
        if (registry && typeof registry.getRandomConceptByUrl === 'function') {
            return registry.getRandomConceptByUrl;
        }
    }
    catch { /* ValueSetRegistry not available */ }
    return undefined;
})();
