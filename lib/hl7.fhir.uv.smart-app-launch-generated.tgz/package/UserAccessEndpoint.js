import fhirpath from "fhirpath";
import fhirpath_model from "fhirpath/fhir-context/r4/index.js";
import { isValidContactPointSystemCode } from './valuesets/ValueSet-ContactPointSystem.js';
import { isValidContactPointUseCode } from './valuesets/ValueSet-ContactPointUse.js';
export async function validateUserAccessEndpoint(resource, options) {
    const errors = [];
    const warnings = [];
    const fhirpathOptions = {
        preciseMath: true,
        traceFn: options?.traceFn ?? (() => { }),
        ...(options?.signal ? { signal: options.signal } : {}),
        ...(options?.httpHeaders ? { httpHeaders: options.httpHeaders } : {}),
        async: true,
        ...(options?.terminologyUrl ? { terminologyUrl: options.terminologyUrl } : {}),
        ...(options?.fhirServerUrl ? { fhirServerUrl: options.fhirServerUrl } : {}),
    };
    const result0 = await fhirpath.evaluate(resource, "Endpoint.all(contained.contained.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result0.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL NOT contain nested Resources");
    }
    const result1 = await fhirpath.evaluate(resource, "Endpoint.all(contained.where((('#'+id in (%resource.descendants().reference | %resource.descendants().as(canonical) | %resource.descendants().as(uri) | %resource.descendants().as(url))) or descendants().where(reference = '#').exists() or descendants().where(as(canonical) = '#').exists() or descendants().where(as(canonical) = '#').exists()).not()).trace('unmatched', id).empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result1.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL be referred to from elsewhere in the resource or SHALL refer to the containing resource");
    }
    const result2 = await fhirpath.evaluate(resource, "Endpoint.all(contained.meta.versionId.empty() and contained.meta.lastUpdated.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result2.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a meta.versionId or a meta.lastUpdated");
    }
    const result3 = await fhirpath.evaluate(resource, "Endpoint.all(contained.meta.security.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result3.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a security label");
    }
    const result4 = await fhirpath.evaluate(resource, "Endpoint.all(text.`div`.exists())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result4.every(Boolean)) {
        warnings.push("Constraint violation: A resource should have narrative for robust management");
    }
    const result5 = await fhirpath.evaluate(resource, "meta.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result5.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result6 = await fhirpath.evaluate(resource, "implicitRules.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result6.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result7 = await fhirpath.evaluate(resource, "language.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result7.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result8 = await fhirpath.evaluate(resource, "text.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result8.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result9 = await fhirpath.evaluate(resource, "extension.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result9.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result10 = await fhirpath.evaluate(resource, "modifierExtension.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result10.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result11 = await fhirpath.evaluate(resource, "identifier.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result11.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result12 = await fhirpath.evaluate(resource, "status.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result12.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result13 = await fhirpath.evaluate(resource, "connectionType.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result13.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result14 = await fhirpath.evaluate(resource, "name.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result14.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result15 = await fhirpath.evaluate(resource, "managingOrganization.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result15.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result16 = await fhirpath.evaluate(resource, "contact.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result16.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result17 = await fhirpath.evaluate(resource, "period.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result17.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result18 = await fhirpath.evaluate(resource, "payloadType.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result18.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result19 = await fhirpath.evaluate(resource, "payloadMimeType.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result19.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result20 = await fhirpath.evaluate(resource, "address.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result20.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result21 = await fhirpath.evaluate(resource, "header.all(hasValue() or (children().count() > id.count()))", { resource }, fhirpath_model, fhirpathOptions);
    if (!result21.every(Boolean)) {
        errors.push("Constraint violation: All FHIR elements must have a @value or children");
    }
    const result22 = await fhirpath.evaluate(resource, "DomainResource.all(contained.contained.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result22.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL NOT contain nested Resources");
    }
    const result23 = await fhirpath.evaluate(resource, "DomainResource.all(contained.where((('#'+id in (%resource.descendants().reference | %resource.descendants().as(canonical) | %resource.descendants().as(uri) | %resource.descendants().as(url))) or descendants().where(reference = '#').exists() or descendants().where(as(canonical) = '#').exists() or descendants().where(as(canonical) = '#').exists()).not()).trace('unmatched', id).empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result23.every(Boolean)) {
        errors.push("Constraint violation: If the resource is contained in another resource, it SHALL be referred to from elsewhere in the resource or SHALL refer to the containing resource");
    }
    const result24 = await fhirpath.evaluate(resource, "DomainResource.all(contained.meta.versionId.empty() and contained.meta.lastUpdated.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result24.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a meta.versionId or a meta.lastUpdated");
    }
    const result25 = await fhirpath.evaluate(resource, "DomainResource.all(contained.meta.security.empty())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result25.every(Boolean)) {
        errors.push("Constraint violation: If a resource is contained in another resource, it SHALL NOT have a security label");
    }
    const result26 = await fhirpath.evaluate(resource, "DomainResource.all(text.`div`.exists())", { resource }, fhirpath_model, fhirpathOptions);
    if (!result26.every(Boolean)) {
        warnings.push("Constraint violation: A resource should have narrative for robust management");
    }
    const result27 = await fhirpath.evaluate(resource, "extension.count() >= 1", { resource }, fhirpath_model, fhirpathOptions);
    if (!result27.every(Boolean)) {
        errors.push("Constraint violation: extension must contain at least one element");
    }
    const result28 = await fhirpath.evaluate(resource, "status.exists()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result28.every(Boolean)) {
        errors.push("Constraint violation: status must be present");
    }
    const result29 = await fhirpath.evaluate(resource, "connectionType.exists()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result29.every(Boolean)) {
        errors.push("Constraint violation: connectionType must be present");
    }
    const result30 = await fhirpath.evaluate(resource, "contact.count() >= 1", { resource }, fhirpath_model, fhirpathOptions);
    if (!result30.every(Boolean)) {
        errors.push("Constraint violation: contact must contain at least one element");
    }
    const result31 = await fhirpath.evaluate(resource, "payloadType.count() >= 1", { resource }, fhirpath_model, fhirpathOptions);
    if (!result31.every(Boolean)) {
        errors.push("Constraint violation: payloadType must contain at least one element");
    }
    const result32 = await fhirpath.evaluate(resource, "address.exists()", { resource }, fhirpath_model, fhirpathOptions);
    if (!result32.every(Boolean)) {
        errors.push("Constraint violation: address must be present");
    }
    const result33 = await fhirpath.evaluate(resource, "payloadType.count() <= 1", { resource }, fhirpath_model, fhirpathOptions);
    if (!result33.every(Boolean)) {
        errors.push("Constraint violation: payloadType must contain at most one element");
    }
    if (options?.terminologyUrl) {
        const result34 = await fhirpath.evaluate(resource, "status.all(memberOf('http://hl7.org/fhir/ValueSet/endpoint-status'))", { resource }, fhirpath_model, fhirpathOptions);
        if (!result34.every(Boolean)) {
            errors.push("Constraint violation: The value provided must be in the value set 'endpoint-status' (http://hl7.org/fhir/ValueSet/endpoint-status)");
        }
    }
    else {
        warnings.push("Constraint not evaluated (no terminologyUrl): The value provided must be in the value set 'endpoint-status' (http://hl7.org/fhir/ValueSet/endpoint-status)");
    }
    if (options?.terminologyUrl) {
        const result35 = await fhirpath.evaluate(resource, "payloadMimeType.all(memberOf('http://hl7.org/fhir/ValueSet/mimetypes'))", { resource }, fhirpath_model, fhirpathOptions);
        if (!result35.every(Boolean)) {
            errors.push("Constraint violation: The value provided must be in the value set 'mimetypes' (http://hl7.org/fhir/ValueSet/mimetypes)");
        }
    }
    else {
        warnings.push("Constraint not evaluated (no terminologyUrl): The value provided must be in the value set 'mimetypes' (http://hl7.org/fhir/ValueSet/mimetypes)");
    }
    // Pattern constraint for connectionType: must have system="http://terminology.hl7.org/CodeSystem/endpoint-connection-type" and code="hl7-fhir-rest"
    if (resource.connectionType) {
        if (resource.connectionType.system !== "http://terminology.hl7.org/CodeSystem/endpoint-connection-type") {
            errors.push("Value is '" + resource.connectionType.system + "' but must be 'http://terminology.hl7.org/CodeSystem/endpoint-connection-type' (pattern for connectionType)");
        }
        if (resource.connectionType.code !== "hl7-fhir-rest") {
            errors.push("Value is '" + resource.connectionType.code + "' but must be 'hl7-fhir-rest' (pattern for connectionType)");
        }
    }
    // Pattern constraint for payloadType: at least one element must include coding with system="http://terminology.hl7.org/CodeSystem/endpoint-payload-type" and code="none"
    if (resource.payloadType && Array.isArray(resource.payloadType) && resource.payloadType.length > 0) {
        const payloadType_pattern0Valid = resource.payloadType.some((item) => item?.coding?.some((coding) => coding?.system === "http://terminology.hl7.org/CodeSystem/endpoint-payload-type" && coding?.code === "none"));
        if (!payloadType_pattern0Valid) {
            errors.push("payloadType must include at least one element with a coding with system 'http://terminology.hl7.org/CodeSystem/endpoint-payload-type' and code 'none'");
        }
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const _bRes = resource;
    // Required ValueSet binding validation for contact.system (nested)
    if (resource.contact && Array.isArray(resource.contact)) {
        for (const _nb0 of resource.contact) {
            if (_nb0.system !== undefined && !isValidContactPointSystemCode(_nb0.system)) {
                errors.push("Code '" + _nb0.system + "' does not exist in the value set 'contact-point-system' (http://hl7.org/fhir/ValueSet/contact-point-system), but the binding is of strength 'required'");
            }
        }
    }
    // Required ValueSet binding validation for contact.use (nested)
    if (resource.contact && Array.isArray(resource.contact)) {
        for (const _nb0 of resource.contact) {
            if (_nb0.use !== undefined && !isValidContactPointUseCode(_nb0.use)) {
                errors.push("Code '" + _nb0.use + "' does not exist in the value set 'contact-point-use' (http://hl7.org/fhir/ValueSet/contact-point-use), but the binding is of strength 'required'");
            }
        }
    }
    // Required extension slice validation for extension:fhir-version (url discriminator)
    if (resource.extension && Array.isArray(resource.extension)) {
        const fhir_versionElements = resource.extension.filter((item) => item.url === "http://hl7.org/fhir/StructureDefinition/endpoint-fhir-version");
        if (fhir_versionElements.length < 1) {
            errors.push("Slice 'extension:fhir-version': a matching slice is required, but not found");
        }
        // Extension value type + binding validation
        for (const _ext of fhir_versionElements) {
            const _valEntry = Object.entries(_ext).find(([k]) => k.startsWith("value"));
            if (_valEntry && !["valueCode"].includes(_valEntry[0])) {
                const _found = _valEntry[0].replace("value", "").toLowerCase();
                errors.push("The Profile 'http://hl7.org/fhir/smart-app-launch/StructureDefinition/user-access-endpoint' definition allows for the type code but found type " + _found);
            }
        }
    }
    else {
        errors.push("Slice 'extension:fhir-version': a matching slice is required, but not found");
    }
    // Required fixedValue slice validation for contact:configuration-url (discriminated by system === "url")
    if (resource.contact && Array.isArray(resource.contact)) {
        const configuration_urlElements = resource.contact.filter((item) => item.system === "url");
        if (configuration_urlElements.length < 1) {
            errors.push("No elements matched required slice: 'contact:configuration-url'");
        }
        for (const _matched of configuration_urlElements) {
            const _m = _matched;
            if (_m.value === undefined || _m.value === null) {
                errors.push("Endpoint.contact.value: minimum required = 1, but only found 0");
            }
        }
    }
    else {
        errors.push("No elements matched required slice: 'contact:configuration-url'");
    }
    // Base FHIR structural validation: extension.url required, ext-1 constraint, empty objects
    {
        const _checkExtensions = (obj, path, depth) => {
            if (!obj || typeof obj !== 'object')
                return;
            if (Array.isArray(obj)) {
                obj.forEach((item, i) => _checkExtensions(item, path + '[' + i + ']', depth + 1));
                return;
            }
            const rec = obj;
            // Empty object check — HL7 validates all FHIR elements must have content
            if (depth > 0 && Object.keys(rec).length === 0) {
                errors.push('Object must have some content');
            }
            // per-1: If present, start SHALL have a lower value than end (Period structural check)
            if (typeof rec.start === 'string' && typeof rec.end === 'string' && rec.start > rec.end) {
                errors.push('If present, start SHALL have a lower value than end');
            }
            // Validate extension arrays
            for (const extKey of ['extension', 'modifierExtension']) {
                const exts = rec[extKey];
                if (Array.isArray(exts)) {
                    for (const ext of exts) {
                        if (ext && typeof ext === 'object' && !Array.isArray(ext)) {
                            const e = ext;
                            if (typeof e.url !== 'string' || !e.url) {
                                errors.push('Extension.url is required in order to identify, use and validate the extension');
                            }
                            // ext-1: Must have either extensions or value[x], not both
                            const hasNestedExt = Array.isArray(e.extension) && e.extension.length > 0;
                            const hasValue = Object.keys(e).some(k => k.startsWith('value') && k !== 'value' && k.length > 5);
                            if (hasNestedExt && hasValue) {
                                errors.push('Must have either extensions or value[x], not both');
                            }
                        }
                    }
                }
            }
            // Recurse into child objects (skip primitive values)
            for (const [_key, _val] of Object.entries(rec)) {
                if (_val && typeof _val === 'object') {
                    _checkExtensions(_val, path + '.' + _key, depth + 1);
                }
            }
        };
        _checkExtensions(resource, '', 0);
    }
    // Standalone contained reference resolution: verify #id references resolve to contained[] entries
    {
        const _res = resource;
        const _containedIds = new Set();
        if (Array.isArray(_res.contained)) {
            for (const _c of _res.contained) {
                if (_c && typeof _c.id === 'string')
                    _containedIds.add(_c.id);
            }
        }
        const _checkContainedRef = (obj) => {
            if (!obj || typeof obj !== 'object')
                return;
            if (Array.isArray(obj)) {
                obj.forEach(_checkContainedRef);
                return;
            }
            const _rec = obj;
            if (typeof _rec.reference === 'string') {
                const _ref = _rec.reference;
                if (_ref.startsWith('#')) {
                    const _id = _ref.substring(1);
                    if (_id && !_containedIds.has(_id)) {
                        errors.push('Contained reference not found: ' + _ref);
                    }
                }
            }
            for (const [_k, _v] of Object.entries(_rec)) {
                if (_k !== 'contained')
                    _checkContainedRef(_v);
            }
        };
        _checkContainedRef(_res);
    }
    return { errors, warnings };
}
