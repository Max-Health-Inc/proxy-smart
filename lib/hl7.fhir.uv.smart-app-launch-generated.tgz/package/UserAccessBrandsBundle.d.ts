import { Bundle, Meta } from "fhir/r4";
export interface UserAccessBrandsBundle extends Omit<Bundle, 'meta' | 'type'> {
    /** Must Support */
    meta?: Meta;
    type: "collection";
}
import type { ValidatorOptions } from './ValidatorOptions.js';
export declare function validateUserAccessBrandsBundle(resource: UserAccessBrandsBundle, options?: ValidatorOptions): Promise<{
    errors: string[];
    warnings: string[];
}>;
